package twaver;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D.Double;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import twaver.base.A.E.J;
import twaver.base.A.F.E.B;
import twaver.base.A.F.E.F;
import twaver.base.A.F.E.G;
import twaver.base.A.F.E.H;
import twaver.base.A.F.E.I;
import twaver.base.Direction;
import twaver.base.OrthogonalLinkDirectionType;
import twaver.base.PositionStruct;
import twaver.network.ui.IconAttachmentHolder;
import twaver.network.ui.MessageAttachment;
import twaver.table.Category;
import twaver.table.editor.AlarmSeverityEditor;
import twaver.table.editor.AlarmStateEditor;
import twaver.table.editor.BigDecimalEditor;
import twaver.table.editor.BigIntegerEditor;
import twaver.table.editor.BooleanEditor;
import twaver.table.editor.ByteEditor;
import twaver.table.editor.ColorEditor;
import twaver.table.editor.DirectionEditor;
import twaver.table.editor.DoubleEditor;
import twaver.table.editor.EnumTypeEditor;
import twaver.table.editor.FloatEditor;
import twaver.table.editor.FloatInsetsEditor;
import twaver.table.editor.FontEditor;
import twaver.table.editor.InsetsEditor;
import twaver.table.editor.IntegerEditor;
import twaver.table.editor.LongEditor;
import twaver.table.editor.PointEditor;
import twaver.table.editor.ShortEditor;
import twaver.table.editor.SpinnerDateEditor;
import twaver.table.editor.StringEditor;
import twaver.table.renderer.AlarmSeverityRenderer;
import twaver.table.renderer.AlarmStateRenderer;
import twaver.table.renderer.AlarmTrendIndicationRenderer;
import twaver.table.renderer.BooleanRenderer;
import twaver.table.renderer.CategoryRenderer;
import twaver.table.renderer.ColorRenderer;
import twaver.table.renderer.DateRenderer;
import twaver.table.renderer.DirectionRenderer;
import twaver.table.renderer.FontRenderer;
import twaver.table.renderer.IconRenderer;
import twaver.table.renderer.InsetsRenderer;
import twaver.table.renderer.NumberRenderer;
import twaver.table.renderer.PointRenderer;
import twaver.table.renderer.StringRenderer;

public class TUIManager
{
  private static final Map L = new LinkedHashMap();
  private static final Map R = new LinkedHashMap();
  private static final Map U = new LinkedHashMap();
  private static A A;
  private static Font g;
  private static Font F;
  private static Font E;
  private static Font D;
  private static Font _;
  private static Font b;
  private static Font X;
  private static Font e;
  private static Font W;
  private static Font B;
  private static Font H;
  private static Font Z;
  private static Map M;
  private static Map d;
  private static List c;
  private static Map a;
  private static Map f;
  private static Generator G;
  private static Generator P;
  private static Generator I;
  private static BlinkingRule T;
  private static VisibleFilter K;
  private static Generator V;
  private static Generator C;
  private static Generator N;
  private static Generator S;
  private static Generator O;
  private static Generator J;
  private static Generator Q;
  private static Map Y;
  
  static
  {
    try
    {
      Field[] fields = TWaverConst.class.getFields();
      for (int i = 0; i < fields.length; i++)
      {
        Field field = fields[i];
        String fileName = field.getName();
        if (fileName.startsWith("PROPERTYNAME_"))
        {
          String propertyName = field.get(null).toString();
          L.put(propertyName, Boolean.TRUE);
          if (propertyName.lastIndexOf(".") < 0) {
            R.put(propertyName, null);
          } else if (U.containsKey(propertyName)) {
            TWaverUtil.handleError("'" + propertyName + "' is duplicate!", null);
          } else {
            U.put(propertyName, null);
          }
        }
      }
      L.put("children", Boolean.FALSE);
      L.put("parent", Boolean.FALSE);
      L.put("host", Boolean.FALSE);
      L.put("businessObject", Boolean.FALSE);
      L.put("StateIcon:", Boolean.TRUE);
      L.put("all.clientproperties", Boolean.FALSE);
      L.put("all.userproperties", Boolean.FALSE);
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    A = new A();
    g = null;
    F = null;
    E = null;
    D = null;
    _ = null;
    b = null;
    X = null;
    e = null;
    W = null;
    B = null;
    H = null;
    Z = null;
    updateDefaultFont();
    UIManager.addPropertyChangeListener(new PropertyChangeListener()
    {
      public void propertyChange(PropertyChangeEvent evt)
      {
        if ("lookAndFeel".equals(evt.getPropertyName())) {
          TUIManager.updateDefaultFont();
        }
      }
    });
    A.put("toolbar.icon.undo", "/resource/image/network/undo.png");
    A.put("toolbar.icon.redo", "/resource/image/network/redo.png");
    A.put("toolbar.icon.select", "/resource/image/network/select.png");
    A.put("toolbar.icon.lazymove", "/resource/image/network/lazyMove.png");
    A.put("toolbar.icon.pan", "/resource/image/network/pan.png");
    A.put("toolbar.icon.magnifier", "/resource/image/network/magnify.png");
    A.put("toolbar.icon.up", "/resource/image/network/up.png");
    A.put("toolbar.icon.zoomin", "/resource/image/network/zoomIn.png");
    A.put("toolbar.icon.zoomout", "/resource/image/network/zoomOut.png");
    A.put("toolbar.icon.zoomback", "/resource/image/network/zoomBack.png");
    A.put("toolbar.icon.zoomreset", "/resource/image/network/zoomReset.png");
    A.put("toolbar.icon.zoomtooverview", "/resource/image/network/zoomToOverview.png");
    A.put("toolbar.icon.zoomtorectangle", "/resource/image/network/zoomView.png");
    A.put("toolbar.icon.overview", "/resource/image/network/overview.png");
    A.put("toolbar.icon.fullscreen", "/resource/image/network/fullScreen.png");
    A.put("toolbar.icon.opendatafile", "/resource/image/network/open.png");
    A.put("toolbar.icon.savedatafile", "/resource/image/network/save.png");
    A.put("toolbar.icon.exportimage", "/resource/image/network/exportToImage.png");
    A.put("toolbar.icon.exportsvg", "/resource/image/network/exportToSVG.png");
    A.put("toolbar.icon.print", "/resource/image/network/print.png");
    A.put("toolbar.icon.printpreview", "/resource/image/network/printPreview.png");
    A.put("toolbar.icon.createnode", "/resource/image/twaver/node_icon.png");
    A.put("toolbar.icon.createtext", "/resource/image/twaver/text_icon.png");
    A.put("toolbar.icon.createlink", "/resource/image/twaver/link_icon.png");
    A.put("toolbar.icon.createflexionlink", "/resource/image/twaver/flexionLink_icon.png");
    A.put("toolbar.icon.createorthogonallink", "/resource/image/twaver/orthogonalLink_icon.png");
    A.put("toolbar.icon.createshapelink", "/resource/image/twaver/shapeLink_icon.png");
    A.put("toolbar.icon.createlinksubnetwork", "/resource/image/twaver/linkSubNetwork_icon.png");
    A.put("toolbar.icon.createpoly", "/resource/image/twaver/polySubNetwork_icon.png");
    A.put("toolbar.icon.createshapenode", "/resource/image/twaver/shapeNode_icon.png");
    A.put("toolbar.icon.createshapesubnetwork", "/resource/image/twaver/shapeSubNetwork_icon.png");
    A.put("web.image.format", "png");
    A.put("web.id.prefix.image", "img_");
    A.put("web.id.prefix.definition", "def_");
    A.put("web.id.prefix.gradient", "gra_");
    A.put("web.id.prefix.texture", "tex_");
    A.put("web.svg.use.base64", Boolean.TRUE);
    A.put("web.svg.use.cdata", Boolean.TRUE);
    A.put("web.default.background.color", Color.WHITE);
    A.put("web.svg.show.alarm.on.top", Boolean.TRUE);
    A.put("web.svg.xmlns", "xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'");
    A.put("web.svg.enable.zoomandpan", Boolean.FALSE);
    A.put("web.image.cache", Boolean.FALSE);
    A.put("web.image.file.path", null);
    A.put("web.image.url.prefix", null);
    A.put("web.min.background.size", new Dimension(1024, 768));
    A.put("web.component.attachment.minimizedicon.url", "/resource/image/swing/info.png");
    A.put("web.path.distance", new Float(0.5D));
    A.put("web.path.numberformat", new DecimalFormat("0.#"));
    A.A("sheet.mode", 1);
    A.put("sheet.enable.category.interaction", Boolean.TRUE);
    A.put("sheet.sorting.ascending", Boolean.TRUE);
    A.put("sheet.restore.category.state", Boolean.TRUE);
    A.put("sheet.editable", Boolean.FALSE);
    A.put("sheet.category.font.bold", Boolean.TRUE);
    A.put("sheet.indent.opaque", Boolean.TRUE);
    A.A("sheet.property.distinct.level", 1);
    A.put("sheet.sorting.properties", Boolean.FALSE);
    A.put("sheet.sorting.categories", Boolean.FALSE);
    A.put("sheet.property.sorting.comparator", null);
    A.put("sheet.category.sorting.comparator", null);
    A.put("sheet.single.root.category.visible", Boolean.TRUE);
    A.put("sheet.property.extra.indent", Boolean.FALSE);
    A.put("sheet.description.visible", Boolean.FALSE);
    A.put("sheet.show.value.in.description", Boolean.TRUE);
    A.put("sheet.fill.indent", Boolean.FALSE);
    A.put("table.alignment.alarmseverity", "center");
    A.put("table.alignment.string", "left");
    A.put("table.alignment.number", "right");
    A.put("table.alignment.enumtype", "left");
    A.put("table.alignment.boolean", "center");
    A.put("table.alignment.date", "right");
    A.put("table.alignment.color", "left");
    A.put("table.alignment.font", "right");
    A.put("table.alignment.icon", "center");
    A.put("table.alignment.element", "left");
    A.put("alarm.table.lazy.publish.mode", Boolean.FALSE);
    A.put("table.lazy.publish.mode", Boolean.FALSE);
    A.put("table.show.table.header.icon", Boolean.TRUE);
    A.put("table.sortable", Boolean.TRUE);
    A.put("table.local.sortable", Boolean.TRUE);
    A.put("table.distinct.sortable.header", Boolean.TRUE);
    A.put("table.multi.column.sortable", Boolean.TRUE);
    A.put("table.selectable.on.right.click", Boolean.TRUE);
    A.put("table.clear.selection.on.margin.clicked", Boolean.TRUE);
    A.put("table.show.predefined.columns.in.popupmenu", Boolean.TRUE);
    A.put("table.enable.tristate.sorting", Boolean.TRUE);
    A.put("table.converse.increase.order", Boolean.FALSE);
    A.put("table.ensure.visible.on.selected", Boolean.TRUE);
    A.put("table.tree.column.movable", Boolean.TRUE);
    A.put("table.enable.right.click.event", Boolean.FALSE);
    A.put("tchart.lazy.publish.mode", Boolean.FALSE);
    A.put("tchart.popup.menu.generator", null);
    A.put("tchart.selectable.on.right.click", Boolean.TRUE);
    A.put("tchart.clear.selection.on.margin.clicked", Boolean.TRUE);
    A.put("tchart.enable.double.click.to.reset", Boolean.TRUE);
    A.put("tchart.enable.tooltiptext", Boolean.TRUE);
    A.put("tchart.enable.xtranslate", Boolean.TRUE);
    A.put("tchart.enable.ytranslate", Boolean.TRUE);
    A.put("tchart.xtranslate", TWaverConst.DOUBLE0);
    A.put("tchart.ytranslate", TWaverConst.DOUBLE0);
    A.put("tchart.enable.xzoom", Boolean.TRUE);
    A.put("tchart.enable.yzoom", Boolean.TRUE);
    A.put("tchart.xzoom", TWaverConst.DOUBLE1);
    A.put("tchart.yzoom", TWaverConst.DOUBLE1);
    A.put("tchart.zoom.increment", new Double(1.1D));
    A.put("tchart.max.zoom", new Double(50.0D));
    A.put("tchart.min.zoom", new Double(0.05D));
    A.A("tchart.xgap", 8);
    A.A("tchart.ygap", 8);
    A.A("tchart.text.gap", 2);
    A.A("tchart.icon.width", 10);
    A.A("tchart.icon.height", 10);
    A.put("tchart.upper.limit", new Double(-1.797693134862316E+308D));
    A.put("tchart.lower.limit", new Double(1.7976931348623157E+308D));
    A.put("tchart.legend.font", null);
    A.A("tchart.legend.layout", 1);
    A.A("tchart.legend.orientation", 1);
    A.A("tchart.selected.offset", 3);
    A.put("tchart.selected.color", null);
    A.put("tchart.selected.stroke", "solid.2");
    A.put("tchart.highlight.background", TWaverConst.COLOR_SHADOW);
    A.put("tchart.highlight.foreground", Color.WHITE);
    A.put("tchart.unit", null);
    A.put("tchart.stroke", null);
    A.put("tchart.format", TWaverConst.DEFAULT_DOUBLE_FORMATER);
    A.put("tchart.value.text.visible", Boolean.TRUE);
    A.put("tchart.value.text.center", Boolean.FALSE);
    A.put("tchart.value.text.color", Color.BLACK);
    A.put("tchart.value.text.font", null);
    A.A("tchart.value.text.positon", 5);
    A.put("tchart.antialias", Boolean.TRUE);
    A.put("tchart.gradient", Boolean.FALSE);
    A.put("tchart.gradient.color", Color.WHITE);
    A.put("tchart.background.visible", Boolean.FALSE);
    A.put("tchart.background.fill.color", TWaverConst.COLOR_GRAY);
    A.put("tchart.background.outline.color", Color.GRAY);
    A.put("tchart.background.stroke", "solid.1");
    A.put("tchart.background.gradient", Boolean.TRUE);
    A.put("tchart.background.gradient.color", Color.WHITE);
    A.A("tchart.background.gradient.factory", 5);
    A.put("tchart.xaxis.start.value", new Double(-1.797693134862316E+308D));
    A.put("tchart.yaxis.start.value", new Double(-1.797693134862316E+308D));
    A.put("tchart.xaxis.unit", null);
    A.put("tchart.xaxis.unit.visible", Boolean.TRUE);
    A.put("tchart.xaxis.unit.color", Color.GRAY);
    A.put("tchart.xaxis.unit.font", null);
    A.put("tchart.xaxis.start.position", new Double((-1.0D / 0.0D)));
    A.put("tchart.yaxis.unit", null);
    A.put("tchart.yaxis.unit.visible", Boolean.TRUE);
    A.put("tchart.yaxis.unit.color", Color.GRAY);
    A.put("tchart.yaxis.unit.font", null);
    A.put("tchart.yaxis.start.position", new Double((-1.0D / 0.0D)));
    A.put("tchart.xaxis.visible", Boolean.TRUE);
    A.put("tchart.xaxis.fill.color", TWaverConst.COLOR_GRAY);
    A.put("tchart.xaxis.outline.color", Color.GRAY);
    A.put("tchart.xaxis.text.font", null);
    A.put("tchart.xaxis.text.color", Color.black);
    A.put("tchart.xaxis.text", null);
    A.put("tchart.xaxis.value", new Double(-1.797693134862316E+308D));
    A.put("tchart.xaxis.stroke", "solid.1");
    A.put("tchart.yaxis.visible", Boolean.TRUE);
    A.put("tchart.yaxis.fill.color", TWaverConst.COLOR_GRAY);
    A.put("tchart.yaxis.outline.color", Color.gray);
    A.put("tchart.yaxis.text.font", null);
    A.put("tchart.yaxis.text.color", Color.BLACK);
    A.put("tchart.yaxis.text", null);
    A.put("tchart.yaxis.stroke", "solid.1");
    A.put("tchart.yscale.line.stroke", "square.thinnest");
    A.put("tchart.yscale.line.color", Color.gray);
    A.A("tchart.yscale.pixel.gap", 25);
    A.put("tchart.yscale.value.gap", TWaverConst.DOUBLE0);
    A.put("tchart.yscale.line.visible", Boolean.TRUE);
    A.put("tchart.yscale.min.text.visible", Boolean.FALSE);
    A.put("tchart.yscale.text.visible", Boolean.FALSE);
    A.put("tchart.yscale.text.inside", Boolean.FALSE);
    A.put("tchart.yscale.text.format", null);
    A.put("tchart.yscale.text.color", Color.gray);
    A.put("tchart.yscale.text.font", null);
    A.put("tchart.yscale.hide.value.index", new Integer(-2147483648));
    A.put("tchart.yscale.value.gap.auto.calculate", Boolean.FALSE);
    A.put("tchart.yscale.min.value", new Double(1.7976931348623157E+308D));
    A.put("tchart.yscale.max.value", new Double(-1.797693134862316E+308D));
    A.A("tchart.shadow.offset", 10);
    A.A("tchart.inflexion.style", 1);
    A.put("tchart.inflexion.visible", Boolean.FALSE);
    A.put("tchart.xscale.line.stroke", "square.thinnest");
    A.put("tchart.xscale.line.color", Color.gray);
    A.put("tchart.xscale.line.visible", Boolean.FALSE);
    A.put("tchart.xscale.text.font", null);
    A.put("tchart.xscale.text.color", Color.gray);
    A.put("tchart.xscale.text.visible", Boolean.TRUE);
    A.A("tchart.xscale.text.orientation", 1);
    A.put("tchart.xscale.text.format", null);
    A.put("tchart.xscale.value.gap", new Double(10.0D));
    A.put("tchart.xscale.pixel.gap", new Double(25.0D));
    A.put("tchart.xscale.min.value", new Double(0.0D));
    A.put("tchart.xscale.max.value", new Double(100.0D));
    A.put("tchart.xscale.hide.value.index", new Integer(-2147483648));
    A.put("tchart.xscale.text.ontop", Boolean.FALSE);
    A.put("tchart.value.text.percent", Boolean.FALSE);
    A.put("tchart.start.angle", TWaverConst.DOUBLE0);
    A.put("tchart.shadow.color", Color.GRAY);
    A.A("tchart.percent.gap", 4);
    A.A("tchart.thickness", 18);
    A.A("tchart.segment.count", 10);
    A.put("tchart.segment.section.prorate", new Double(0.5D));
    A.put("tchart.percent.label.visible", Boolean.TRUE);
    A.put("tchart.percent.label.center", Boolean.FALSE);
    A.put("tchart.percent.label.color", Color.BLACK);
    A.put("tchart.percent.label.font", null);
    A.A("tchart.percent.type", 1);
    A.A("tchart.percent.marker.position", 1);
    A.put("tchart.percent.spare.gradient.color", Color.WHITE);
    A.put("tchart.percent.spare.fill", Boolean.FALSE);
    A.put("tchart.spare.color", Color.LIGHT_GRAY);
    A.put("tchart.outline.color", Color.lightGray);
    A.A("tchart.bar.type", 1);
    A.A("tchart.bar.bundle.size", 1);
    A.put("tchart.bar.percent.type.value.visible", Boolean.FALSE);
    A.A("tchart.line.type", 1);
    A.put("tchart.interrupted.when.null.value", Boolean.FALSE);
    A.put("tchart.hollow", Boolean.FALSE);
    A.put("tchart.hollow.percent", new Double(0.35D));
    A.A("tchart.dial.type", 1);
    A.put("tchart.dial.arcrange", new Double(180.0D));
    A.put("tchart.dial.scale.inside", Boolean.FALSE);
    A.put("tchart.dial.start.angle", new Double(0.0D));
    A.put("tchart.dial.end.angle", new Double(360.0D));
    A.put("tchart.dial.max.value", new Double(100.0D));
    A.put("tchart.dial.min.value", new Double(0.0D));
    A.A("tchart.dial.scale.major.count", 10);
    A.A("tchart.dial.scale.minor.count", 3);
    A.put("tchart.dial.scale.minor.visible", Boolean.TRUE);
    A.put("tchart.dial.scale.length", new Double(10.0D));
    A.put("tchart.dial.scale.stroke", "solid.2");
    A.put("tchart.dial.scale.text.font", null);
    A.put("tchart.dial.scale.color", Color.LIGHT_GRAY);
    A.put("tchart.dial.scale.text.color", Color.LIGHT_GRAY.brighter());
    A.put("tchart.dial.scale.text.visible", Boolean.TRUE);
    A.A("tchart.dial.scale.style", 1);
    A.put("tchart.dial.scale.mintext.visible", Boolean.FALSE);
    A.put("tchart.dial.ring.stroke", "solid.2");
    A.put("tchart.dial.ring.color", Color.GRAY);
    A.put("tchart.dial.ring.fill.color", Color.BLACK.darker());
    A.put("tchart.dial.ring.border.color", Color.BLACK);
    A.put("tchart.dial.ring.border.visible", Boolean.TRUE);
    A.put("tchart.dial.ring.gradient.color", Color.LIGHT_GRAY);
    A.put("tchart.dial.ring.gradient", Boolean.TRUE);
    A.A("tchart.dial.ring.gradient.factory", 5);
    A.put("tchart.dial.ball.color", Color.LIGHT_GRAY);
    A.put("tchart.dial.ball.border.color", Color.DARK_GRAY);
    A.put("tchart.dial.ball.size", new Double(15.0D));
    A.put("tchart.dial.ball.percent.size", new Double(0.08D));
    A.put("tchart.dial.ball.gradient.color", Color.GRAY);
    A.put("tchart.dial.ball.gradient", Boolean.TRUE);
    A.A("tchart.dial.ball.gradient.factory", 10);
    A.put("tchart.radar.axis.text.font", null);
    A.put("tchart.radar.axis.text.visible", Boolean.TRUE);
    A.put("tchart.radar.axis.text.color", Color.BLUE);
    A.put("tchart.radar.axis.visible", Boolean.TRUE);
    A.put("tchart.radar.axis.color", Color.LIGHT_GRAY);
    A.put("tchart.radar.axis.stroke", "solid.3");
    A.put("tchart.radar.axis.start.angle", new Double(0.0D));
    A.put("tchart.radar.scale.max.value", new Double(1.0D));
    A.put("tchart.radar.scale.min.value", new Double(0.0D));
    A.put("tchart.radar.scale.major.text.font", null);
    A.put("tchart.radar.scale.major.text.visible", Boolean.TRUE);
    A.A("tchart.radar.scale.major.count", 5);
    A.put("tchart.radar.scale.major.text.color", Color.LIGHT_GRAY);
    A.A("tchart.radar.scale.min.count", 2);
    A.A("tchart.radar.ring.style", 1);
    A.put("tchart.radar.ring.major.color", Color.GRAY);
    A.put("tchart.radar.ring.major.stroke", "solid.1");
    A.put("tchart.radar.ring.min.color", Color.LIGHT_GRAY);
    A.put("tchart.radar.ring.min.stroke", "square.thinnest");
    A.put("tchart.radar.ring.min.visible", Boolean.TRUE);
    A.put("tchart.radar.ring.visible", Boolean.TRUE);
    A.put("tchart.radar.fill", Boolean.FALSE);
    A.put("tchart.radar.fill.color", Color.LIGHT_GRAY);
    A.put("tchart.radar.fill.gradient", Boolean.TRUE);
    A.put("tchart.radar.fill.gradient.color", Color.GRAY);
    A.A("tchart.radar.fill.gradient.factory", 10);
    A.put("tchart.radar.shape.fill.gradient", Boolean.TRUE);
    A.put("tchart.radar.shape.fill.gradient.color", Color.WHITE);
    A.put("tchart.radar.axis.inflexion.visible", Boolean.FALSE);
    A.A("tchart.radar.axis.inflexion.style", 1);
    A.put("tchart.radar.axis.text.tooltip.visible", Boolean.TRUE);
    A.put("tchart.radar.inflexion.visible", Boolean.TRUE);
    A.put("tchart.radar.line.visible", Boolean.TRUE);
    A.put("tchart.radar.area.fill", Boolean.TRUE);
    A.put("tchart.bubble.gradient", Boolean.TRUE);
    A.A("tchart.bubble.gradient.factory", 10);
    A.put("tchart.bubble.gradient.color", Color.WHITE);
    A.put("tchart.bubble.alpha", new Float(0.8F));
    A.A("tchart.bubble.style", 1);
    A.put("tchart.bubble.area.selectable", Boolean.TRUE);
    A.put("tchart.bubble.shape.line.visible", Boolean.TRUE);
    A.put("tchart.bubble.shape.bubble.visible", Boolean.TRUE);
    A.put("tchart.pie.percent.value.format", TWaverConst.DEFAULT_DOUBLE_FORMATER);
    A.put("tchart.pie.value.text.position.scale", new Double(0.7D));
    A.put("tchart.pie.3d", Boolean.FALSE);
    A.A("tchart.percent.marker.start.position", 1);
    A.put("list.enable.right.click.event", Boolean.FALSE);
    A.put("list.lazy.publish.mode", Boolean.FALSE);
    A.put("list.icon.visible", Boolean.TRUE);
    A.put("list.ensure.visible.on.selected", Boolean.TRUE);
    A.put("list.paint.selected.state.when.checked", Boolean.TRUE);
    A.A("list.selection.mode", 0);
    A.A("list.uncheckable.style", 3);
    A.put("list.selectable.on.right.click", Boolean.TRUE);
    A.put("list.clear.selection.on.margin.clicked", Boolean.TRUE);
    A.put("combobox.lazy.publish.mode", Boolean.FALSE);
    A.put("combobox.icon.visible", Boolean.TRUE);
    A.put("combobox.popup.with.preferred.width", Boolean.TRUE);
    A.put("tree.enable.right.click.event", Boolean.FALSE);
    A.put("tree.enable.dnd", Boolean.TRUE);
    A.A("tree.icon.width", -1);
    A.A("tree.icon.height", -1);
    A.put("tree.expanded.icon", null);
    A.put("tree.collapsed.icon", null);
    A.A("tree.selection.mode", 0);
    A.A("tree.uncheckable.style", 1);
    A.put("tree.databox.node.icon", "/resource/image/swing/box.png");
    A.put("tree.databox.label.editable", Boolean.TRUE);
    A.put("tree.icon.visible", Boolean.TRUE);
    A.put("tree.selectable.on.right.click", Boolean.TRUE);
    A.put("tree.clear.selection.on.margin.clicked", Boolean.FALSE);
    A.put("tree.show.plain.icon", Boolean.FALSE);
    A.put("tree.element.draggable", Boolean.FALSE);
    A.put("tree.ensure.visible.on.selected", Boolean.TRUE);
    A.put("tree.element.tooltip.displayable", Boolean.TRUE);
    A.put("tree.enable.tristate.checkbox", Boolean.FALSE);
    A.put("tree.paint.selected.state.when.checked", Boolean.FALSE);
    A.put("tree.checked.when.not.specified", Boolean.TRUE);
    A.put("tree.update.sort.on.property.changed", Boolean.FALSE);
    A.put("network.enable.right.click.event", Boolean.FALSE);
    A.put("network.enable.dnd", Boolean.TRUE);
    A.put("network.animate.component.attachment", Boolean.FALSE);
    A.put("network.animate.subnetwork.enter", Boolean.FALSE);
    A.put("network.animate.element.move", Boolean.FALSE);
    A.put("network.animate.element.delete", Boolean.FALSE);
    A.put("network.animate.element.resize", Boolean.FALSE);
    A.A("network.straight.link.gap", 16);
    A.A("network.straight.link.offset", 32);
    A.A("network.parallel.link.gap", 8);
    A.A("network.parallel.link.offset", 20);
    A.put("network.link.bundle.compact", Boolean.FALSE);
    A.put("network.link.bundle.alternate", Boolean.TRUE);
    A.put("network.enable.attachment.default.action", Boolean.FALSE);
    A.put("network.consider.attachment.on.layout", Boolean.FALSE);
    A.put("network.expand.group.after.layout", Boolean.FALSE);
    A.put("network.show.plain.element", Boolean.FALSE);
    A.put("network.enable.illegal.link.visible", Boolean.FALSE);
    A.put("network.enable.double.click.to.up", Boolean.TRUE);
    A.put("network.enable.enter.empty.subnetwork", Boolean.TRUE);
    A.put("network.enable.auto.scroll", Boolean.TRUE);
    A.put("network.enable.mouse.wheel.to.zoom", Boolean.TRUE);
    A.put("network.show.link.bundle.handler", Boolean.TRUE);
    A.put("network.enable.auto.adjust.canvas.size", Boolean.TRUE);
    A.put("network.limit.element.in.positive.location", Boolean.TRUE);
    A.put("network.selectable.on.right.click", Boolean.TRUE);
    A.put("network.clear.selection.on.margin.clicked", Boolean.TRUE);
    A.put("network.apply.background.through.subnetwork", Boolean.FALSE);
    A.put("network.alarm.balloon.visible", Boolean.TRUE);
    A.put("network.enable.animation", Boolean.TRUE);
    A.put("network.enable.blinking", Boolean.TRUE);
    A.put("network.element.transparent.area.selectable", Boolean.FALSE);
    A.put("network.ensure.visible.on.selected", Boolean.FALSE);
    A.put("network.keyboard.enable.select.all", Boolean.TRUE);
    A.put("network.keyboard.enable.copy.paste", Boolean.FALSE);
    A.put("network.keyboard.enable.undo.redo", Boolean.FALSE);
    A.put("network.keyboard.enable.delete", Boolean.FALSE);
    A.put("network.keyboard.enable.switch.full.screen", Boolean.TRUE);
    A.put("network.keyboard.enable.exit.full.screen", Boolean.TRUE);
    A.put("network.full.screen.keyboard", "F11");
    A.put("network.zoom.increment", new Double(1.5D));
    A.put("network.wheel.zoom.increment", new Double(1.1D));
    A.put("network.magnifier.zoom.factor", new Double(3.0D));
    A.put("network.magnifier.shape", new Ellipse2D.Double(0.0D, 0.0D, 160.0D, 160.0D));
    A.put("network.magnifier.shape.map", new LinkedHashMap() {});
    A.put("network.magnifier.factor.map", new LinkedHashMap() {});
    A.put("xml.output.with.businessobject", Boolean.FALSE);
    A.put("xml.output.with.userproperty", Boolean.FALSE);
    A.put("xml.output.with.elementid", Boolean.FALSE);
    A.put("xml.output.with.layers", Boolean.FALSE);
    A.put("xml.output.with.alarm", Boolean.FALSE);
    A.put("xml.output.with.alarmid", Boolean.TRUE);
    A.put("xml.output.with.alarmstate", Boolean.TRUE);
    A.put("xml.output.with.databoxclientproperty", Boolean.TRUE);
    A.put("xml.output.with.databoxname", Boolean.TRUE);
    A.put("xml.output.with.databoxid", Boolean.TRUE);
    A.put("xml.output.with.databoxversion", Boolean.TRUE);
    A.put("xml.output.with.databoxbackground", Boolean.TRUE);
    A.put("xml.output.elementfilter", null);
    A.put("xml.output.clientpropertyfilter", null);
    A.put("xml.output.elementdelegateinterceptor", null);
    A.put("custom.draw", Boolean.FALSE);
    A.A("custom.draw.shape.factory", 1);
    A.put("custom.draw.default.border", Boolean.FALSE);
    A.put("custom.draw.antialias", Boolean.TRUE);
    A.put("custom.draw.fill", Boolean.TRUE);
    A.put("custom.draw.fill.3d", Boolean.FALSE);
    A.put("custom.draw.fill.color", Color.DARK_GRAY);
    A.put("custom.draw.outline", Boolean.TRUE);
    A.put("custom.draw.outline.3d", Boolean.FALSE);
    A.put("custom.draw.outline.color", Color.BLACK);
    A.put("custom.draw.outline.stroke", "solid.thinnest");
    A.put("custom.draw.gradient", Boolean.TRUE);
    A.A("custom.draw.gradient.factory", 11);
    A.put("custom.draw.gradient.color", Color.WHITE);
    A.put("draw.image.shape", Boolean.FALSE);
    A.put("draw.icon.shape", Boolean.FALSE);
    A.put("render.alpha", new Float(1.0D));
    A.put("render.color", null);
    A.put("state.outline.color", null);
    A.A("state.outline.width", 2);
    A.A("state.outline.insets", 0);
    A.put("element.tree.icon", null);
    A.put("border.antialias", Boolean.TRUE);
    A.put("border.visible", Boolean.TRUE);
    A.put("border.underneath", Boolean.FALSE);
    A.put("border.xormode", Boolean.FALSE);
    A.put("border.stroke", "solid.thin");
    A.put("border.color", TWaverConst.COLOR_DARK);
    A.put("border.fill.color", Color.WHITE);
    A.put("border.fill", Boolean.FALSE);
    A.A("border.insets", 1);
    A.A("border.type", 1);
    A.A("border.shape.factory", 2);
    A.put("shapenode.show.dash.line", Boolean.TRUE);
    A.A("shapenode.joint.point", 1);
    A.put("shapenode.from.arrow", Boolean.FALSE);
    A.put("shapenode.to.arrow", Boolean.FALSE);
    A.A("shapenode.from.arrow.style", 2);
    A.A("shapenode.to.arrow.style", 2);
    A.put("shapenode.from.arrow.color", Color.darkGray);
    A.put("shapenode.to.arrow.color", Color.darkGray);
    A.put("shapenode.from.arrow.outline", Boolean.TRUE);
    A.put("shapenode.to.arrow.outline", Boolean.TRUE);
    A.put("shapenode.from.arrow.outline.color", Color.darkGray.darker());
    A.put("shapenode.to.arrow.outline.color", Color.darkGray.darker());
    A.A("shapenode.to.arrow.xoffset", 0);
    A.A("shapenode.to.arrow.yoffset", 0);
    A.A("shapenode.from.arrow.xoffset", 0);
    A.A("shapenode.from.arrow.yoffset", 0);
    A.put("shapenode.from.arrow.center", Boolean.FALSE);
    A.put("shapenode.to.arrow.center", Boolean.FALSE);
    A.put("label.font", null);
    A.put("label.color", Color.BLACK);
    A.put("label.background", null);
    A.put("label.visible", Boolean.TRUE);
    A.put("label.border", Boolean.FALSE);
    A.put("label.border.stroke", "solid.thinnest");
    A.put("label.border.color", Color.BLACK);
    A.put("label.underline", Boolean.FALSE);
    A.put("label.underline.stroke", "solid.thinnest");
    A.put("label.underline.color", Color.BLACK);
    A.A("label.position", 3);
    A.A("label.yoffset", 0);
    A.A("label.xoffset", 0);
    A.A("label.ygap", 0);
    A.A("label.xgap", 0);
    A.put("label.direction", Direction.VERTICAL);
    A.A("label.orientation", 1);
    A.put("label.selectable", Boolean.TRUE);
    A.put("label.highlightable", Boolean.TRUE);
    A.put("label.highlight.background", TWaverConst.COLOR_SHADOW);
    A.put("label.highlight.foreground", Color.WHITE);
    A.A("label.maxlength", 0);
    A.put("StateIcon:attachment.message", Boolean.FALSE);
    A.put("message.content", null);
    A.A("message.width", -1);
    A.A("message.height", -1);
    A.A("message.component", 1);
    A.A("message.style", 2);
    A.A("message.tail", 15);
    A.A("message.arc", 15);
    A.put("message.closable", Boolean.FALSE);
    A.put("message.shrinkable", Boolean.FALSE);
    A.put("message.minimizable", Boolean.FALSE);
    A.put("message.shrinked", Boolean.FALSE);
    A.put("message.minimized", Boolean.FALSE);
    A.put("message.auto.adjust.direction", Boolean.TRUE);
    A.A("message.position", 15);
    A.A("message.direction", 2);
    A.put("message.font", null);
    A.put("message.foreground", Color.BLACK);
    A.put("message.background", TWaverConst.COLOR_IVORY);
    A.put("message.gradient", Boolean.FALSE);
    A.put("message.gradient.color", Color.WHITE);
    A.A("message.gradient.factory", 5);
    A.put("message.close.url", "/resource/image/swing/close.png");
    A.put("message.minimize.url", "/resource/image/swing/minimize.png");
    A.put("message.info.url", "/resource/image/swing/info.png");
    A.put("message.opaque", Boolean.TRUE);
    A.A("message.xoffset", 0);
    A.A("message.yoffset", 0);
    A.A("message.xgap", 0);
    A.A("message.ygap", 0);
    A.put("message.minimized.icon", "/resource/image/swing/info.png");
    A.put("message.shadow.visible", Boolean.TRUE);
    A.put("message.shadow.color", TWaverConst.COLOR_SHADOW);
    A.put("message.border.visible", Boolean.TRUE);
    A.put("message.border.color", Color.BLACK);
    A.put("message.border.stroke", "solid.thinnest");
    A.put("message.shown.on.top", Boolean.TRUE);
    A.A("attachment.position", 6);
    A.A("attachment.orientation", 3);
    A.A("attachment.xoffset", 0);
    A.A("attachment.yoffset", 0);
    A.A("attachment.xgap", 0);
    A.A("attachment.ygap", 0);
    A.A("blink.body.speed", 500);
    A.A("blink.iconattachment.speed", 500);
    A.A("blink.alarmattachment.speed", 500);
    A.A("alarm.balloon.position", 0);
    A.A("alarm.balloon.direction", 2);
    A.A("alarm.balloon.yoffset", 0);
    A.A("alarm.balloon.xoffset", 0);
    A.put("alarm.balloon.visible", Boolean.TRUE);
    A.put("alarm.balloon.alpha", new Float(1.0D));
    A.put("alarm.balloon.text.font", null);
    A.put("alarm.balloon.text.color", Color.darkGray);
    A.put("alarm.balloon.text.blinkable", Boolean.TRUE);
    A.put("alarm.balloon.outline.color", Color.BLACK);
    A.put("alarm.balloon.shadow.color", TWaverConst.COLOR_SHADOW);
    A.A("alarm.balloon.shadow.offset", 3);
    A.put("alarm.balloon.shown.on.top", Boolean.TRUE);
    A.A("poly.outline.width", 6);
    A.put("poly.outline.color", Color.lightGray);
    A.put("poly.fill", Boolean.TRUE);
    A.put("poly.3d", Boolean.TRUE);
    A.put("link.proportion", new Double(0.5D));
    A.A("link.extend", 20);
    A.put("link.style", "solid");
    A.A("link.to.position", 1);
    A.A("link.to.xoffset", 0);
    A.A("link.to.yoffset", 0);
    A.A("link.from.position", 1);
    A.A("link.from.xoffset", 0);
    A.A("link.from.yoffset", 0);
    A.put("link.hollow", Boolean.FALSE);
    A.put("link.fromArrow", Boolean.FALSE);
    A.put("link.toArrow", Boolean.FALSE);
    A.put("link.color", new Color(180, 180, 180));
    A.put("link.outline.color", new Color(180, 180, 180).darker());
    A.A("link.outline.width", 1);
    A.A("link.width", 3);
    A.A("link.flowing.width", 3);
    A.put("link.flowing", Boolean.FALSE);
    A.A("link.flowing.speed", 5000);
    A.put("link.flowing.converse", Boolean.FALSE);
    A.put("link.blinking", Boolean.FALSE);
    A.put("link.blinking.color", Color.RED);
    A.put("link.flowing.color", new Color(180, 180, 180).darker());
    A.put("link.bundle.expand", Boolean.TRUE);
    A.A("link.bundle.index", 0);
    A.A("link.bundle.size", 1);
    A.put("link.3d", Boolean.FALSE);
    A.put("link.label.rotatable", Boolean.FALSE);
    A.put("link.antialias", Boolean.FALSE);
    A.put("link.from.arrow.center", Boolean.FALSE);
    A.put("link.to.arrow.center", Boolean.FALSE);
    A.A("link.from.arrow.style", 2);
    A.A("link.to.arrow.style", 2);
    A.put("link.from.arrow.color", Color.darkGray);
    A.put("link.to.arrow.color", Color.darkGray);
    A.put("link.from.arrow.outline", Boolean.TRUE);
    A.put("link.to.arrow.outline", Boolean.TRUE);
    A.put("link.from.arrow.outline.color", Color.darkGray.darker());
    A.put("link.to.arrow.outline.color", Color.darkGray.darker());
    A.A("link.to.arrow.xoffset", 0);
    A.A("link.to.arrow.yoffset", 0);
    A.A("link.from.arrow.xoffset", 0);
    A.A("link.from.arrow.yoffset", 0);
    A.put("link.handler.icon", "/resource/image/twaver/groupClose.png");
    A.A("link.handler.position", 0);
    A.A("link.handler.yoffset", 0);
    A.A("link.handler.xoffset", 0);
    A.put("link.handler.visible", Boolean.TRUE);
    A.put("link.handler.font", null);
    A.put("link.handler.foreground", Color.BLACK);
    A.put("link.handler.background", null);
    A.put("link.orthogonal.direction", OrthogonalLinkDirectionType.X_TO_Y);
    A.put("texture.factory", null);
    A.put("body.color", Color.LIGHT_GRAY);
    A.put("body.fill", Boolean.TRUE);
    A.put("body.raised", Boolean.TRUE);
    A.put("equip.direction", Direction.VERTICAL);
    A.A("shelf.border", 2);
    A.A("shelf.inner.border", 1);
    A.A("slot.border", 2);
    A.A("slot.inner.border", 1);
    A.put("card.bolt.top", Boolean.FALSE);
    A.put("card.bolt.bottom", Boolean.FALSE);
    A.put("card.bolt.left", Boolean.FALSE);
    A.put("card.bolt.right", Boolean.FALSE);
    A.put("card.extend.pixel", null);
    A.put("card.extend.percent", null);
    A.put("btsantenna.arrow.show", Boolean.TRUE);
    A.put("btsantenna.arrow.color", Color.black);
    A.put("btsantenna.outline.show", Boolean.TRUE);
    A.put("btsantenna.outline.color", Color.black);
    A.put("btsantenna.outline.stroke", "solid.thinnest");
    A.put("group.outline", Boolean.TRUE);
    A.put("group.outline.stroke", "solid.thinnest");
    A.put("group.fill", Boolean.TRUE);
    A.put("group.opaque", Boolean.FALSE);
    A.put("group.outline.color", Color.black);
    A.put("group.fill.color", new Color(125, 125, 125, 125));
    A.A("group.angle", 30);
    A.put("group.3d", Boolean.FALSE);
    A.put("group.antialias", Boolean.TRUE);
    A.A("group.deep", 20);
    A.put("group.insets", null);
    A.A("group.children.outcrop", -1);
    A.put("group.double.click.enable", Boolean.TRUE);
    A.A("group.chamfer.edge", 60);
    A.put("group.gradient", Boolean.FALSE);
    A.put("group.gradient.color", Color.WHITE);
    A.A("group.gradient.factory", 7);
    A.A("group.handler.position", 0);
    A.A("group.handler.yoffset", 0);
    A.A("group.handler.xoffset", 0);
    A.put("group.handler.visible", Boolean.TRUE);
    A.put("group.handler.expand.icon", "/resource/image/twaver/groupExpand.png");
    A.put("group.handler.close.icon", "/resource/image/twaver/groupClose.png");
    A.put("group.handler.empty.icon", "/resource/image/twaver/groupEmpty.png");
    A.put("padding", new Insets(3, 3, 3, 3));
    A.put("border", new Insets(3, 3, 3, 3));
    A.put("paintCell", Boolean.TRUE);
    A.put("chart.value", TWaverConst.DOUBLE0);
    A.put("chart.min", TWaverConst.DOUBLE0);
    A.put("chart.max", new Double(100.0D));
    A.put("chart.values", null);
    A.put("chart.color", TWaverConst.COLOR_DARK);
    A.put("chart.format", TWaverConst.DEFAULT_DOUBLE_FORMATER);
    A.put("chart.stroke", "solid.thinnest");
    A.A("chart.percent.style", 2);
    A.A("chart.inflexion.style", 1);
    A.put("chart.markers", null);
    A.put("chart.dial.hand.length", new Double(0.85D));
    A.A("chart.dial.hand.style", 2);
    A.put("chart.percent.spare.fill", Boolean.FALSE);
    A.put("chart.percent.spare.color", Color.LIGHT_GRAY);
    A.put("chart.percent.spare.cover.color", Color.LIGHT_GRAY);
    A.A("chart.percent.marker.position", 1);
    A.put("chart.bubble.style", null);
    A.A("chart.value.text.position", 1);
    A.put("chart.bubble.shape.line.visible", Boolean.TRUE);
    A.put("chart.bubble.shape.bubble.visible", Boolean.TRUE);
    AlarmProbableCause.TEMPERATURE_UNACCEPTABLE.getClass();
    AlarmTrendIndication.LESS_SEVERE.getClass();
    AlarmType.COMMUNICATIONS_ALARM.getClass();
    Direction.HORIZONTAL.getClass();
    OrthogonalLinkDirectionType.X_TO_Y.getClass();
    TaskScheduler.getInstance();
    M = new LinkedHashMap();
    d = new LinkedHashMap();
    c = new ArrayList();
    c.add(BaseEquipment.class);
    c.add(ShapeNode.class);
    c.add(PolySubNetwork.class);
    c.add(Text.class);
    M.put(BaseElement.class, "/resource/image/twaver/baseElement_icon.png");
    M.put(Node.class, "/resource/image/twaver/node_icon.png");
    M.put(Card.class, "/resource/image/twaver/card_icon.png");
    M.put(Slot.class, "/resource/image/twaver/slot_icon.png");
    M.put(Grid.class, "/resource/image/twaver/grid_icon.png");
    M.put(Chassis.class, "/resource/image/twaver/chassis_icon.png");
    M.put(Dummy.class, "/resource/image/twaver/dummy_icon.png");
    M.put(Group.class, "/resource/image/twaver/group_icon.png");
    M.put(EllipseGroup.class, "/resource/image/twaver/ellipseGroup_icon.png");
    M.put(ParallelogramGroup.class, "/resource/image/twaver/parallelogramGroup_icon.png");
    M.put(Link.class, "/resource/image/twaver/link_icon.png");
    M.put(LinkSubNetwork.class, "/resource/image/twaver/linkSubNetwork_icon.png");
    M.put(ShapeLink.class, "/resource/image/twaver/shapeLink_icon.png");
    M.put(FlexionLink.class, "/resource/image/twaver/flexionLink_icon.png");
    M.put(OrthogonalLink.class, "/resource/image/twaver/orthogonalLink_icon.png");
    M.put(Port.class, "/resource/image/twaver/port_icon.png");
    M.put(Rack.class, "/resource/image/twaver/rack_icon.png");
    M.put(Shelf.class, "/resource/image/twaver/shelf_icon.png");
    M.put(SubNetwork.class, "/resource/image/twaver/subNetwork_icon.png");
    M.put(ShapeNode.class, "/resource/image/twaver/shapeNode_icon.png");
    M.put(ShapeSubNetwork.class, "/resource/image/twaver/shapeSubNetwork_icon.png");
    M.put(PolySubNetwork.class, "/resource/image/twaver/polySubNetwork_icon.png");
    M.put(TerminalPoint.class, "/resource/image/twaver/terminalPoint_icon.png");
    M.put(BTS.class, "/resource/image/twaver/bts_icon.png");
    M.put(BTSAntenna.class, "/resource/image/twaver/btsAntenna_icon.png");
    M.put(Text.class, "/resource/image/twaver/text_icon.png");
    d.put(Node.class, "/resource/image/twaver/node_image.png");
    d.put(TerminalPoint.class, "/resource/image/twaver/terminalPoint_image.png");
    d.put(Group.class, "/resource/image/twaver/group_image.png");
    d.put(EllipseGroup.class, "/resource/image/twaver/ellipseGroup_image.png");
    d.put(ParallelogramGroup.class, "/resource/image/twaver/parallelogramGroup_image.png");
    d.put(Port.class, "/resource/image/twaver/port_image.png");
    d.put(SubNetwork.class, "/resource/image/twaver/subNetwork_image.png");
    d.put(BTS.class, "/resource/image/twaver/bts_image.png");
    d.put(ShapeImage.class, "/resource/image/twaver/node_image.png");
    a = new LinkedHashMap();
    f = new LinkedHashMap();
    registerTableCellRenderer(Number.class, NumberRenderer.class);
    registerTableCellRenderer(Byte.class, NumberRenderer.class);
    registerTableCellRenderer(Byte.TYPE, NumberRenderer.class);
    registerTableCellRenderer(Short.class, NumberRenderer.class);
    registerTableCellRenderer(Short.TYPE, NumberRenderer.class);
    registerTableCellRenderer(Integer.class, NumberRenderer.class);
    registerTableCellRenderer(Integer.TYPE, NumberRenderer.class);
    registerTableCellRenderer(Long.class, NumberRenderer.class);
    registerTableCellRenderer(Long.TYPE, NumberRenderer.class);
    registerTableCellRenderer(Float.class, NumberRenderer.class);
    registerTableCellRenderer(Float.TYPE, NumberRenderer.class);
    registerTableCellRenderer(Double.class, NumberRenderer.class);
    registerTableCellRenderer(Double.TYPE, NumberRenderer.class);
    registerTableCellRenderer(BigInteger.class, NumberRenderer.class);
    registerTableCellRenderer(BigDecimal.class, NumberRenderer.class);
    registerTableCellRenderer(Boolean.class, BooleanRenderer.class);
    registerTableCellRenderer(Boolean.TYPE, BooleanRenderer.class);
    registerTableCellRenderer(java.util.Date.class, DateRenderer.class);
    registerTableCellRenderer(java.sql.Date.class, DateRenderer.class);
    registerTableCellRenderer(Timestamp.class, DateRenderer.class);
    registerTableCellRenderer(Icon.class, IconRenderer.class);
    registerTableCellRenderer(ImageIcon.class, IconRenderer.class);
    registerTableCellRenderer(Point.class, PointRenderer.class);
    registerTableCellRenderer(Color.class, ColorRenderer.class);
    registerTableCellRenderer(ColorUIResource.class, ColorRenderer.class);
    registerTableCellRenderer(AlarmState.class, AlarmStateRenderer.class);
    registerTableCellRenderer(Font.class, FontRenderer.class);
    registerTableCellRenderer(FontUIResource.class, FontRenderer.class);
    registerTableCellRenderer(Category.class, CategoryRenderer.class);
    registerTableCellRenderer(Direction.class, DirectionRenderer.class);
    registerTableCellRenderer(AlarmSeverity.class, AlarmSeverityRenderer.class);
    registerTableCellRenderer(AlarmTrendIndication.class, AlarmTrendIndicationRenderer.class);
    registerTableCellRenderer(String.class, StringRenderer.class);
    registerTableCellRenderer(Insets.class, InsetsRenderer.class);
    registerTableCellRenderer(FloatInsets.class, InsetsRenderer.class);
    registerTableCellRenderer(Object.class, StringRenderer.class);
    registerTableCellEditor(Byte.class, ByteEditor.class);
    registerTableCellEditor(Byte.TYPE, ByteEditor.class);
    registerTableCellEditor(Short.class, ShortEditor.class);
    registerTableCellEditor(Short.TYPE, ShortEditor.class);
    registerTableCellEditor(Integer.class, IntegerEditor.class);
    registerTableCellEditor(Integer.TYPE, IntegerEditor.class);
    registerTableCellEditor(Long.class, LongEditor.class);
    registerTableCellEditor(Long.TYPE, LongEditor.class);
    registerTableCellEditor(Float.class, FloatEditor.class);
    registerTableCellEditor(Float.TYPE, FloatEditor.class);
    registerTableCellEditor(Double.class, DoubleEditor.class);
    registerTableCellEditor(Double.TYPE, DoubleEditor.class);
    registerTableCellEditor(BigInteger.class, BigIntegerEditor.class);
    registerTableCellEditor(BigDecimal.class, BigDecimalEditor.class);
    registerTableCellEditor(Boolean.class, BooleanEditor.class);
    registerTableCellEditor(Boolean.TYPE, BooleanEditor.class);
    registerTableCellEditor(Color.class, ColorEditor.class);
    registerTableCellEditor(ColorUIResource.class, ColorEditor.class);
    registerTableCellEditor(String.class, StringEditor.class);
    registerTableCellEditor(AlarmState.class, AlarmStateEditor.class);
    registerTableCellEditor(AlarmSeverity.class, AlarmSeverityEditor.class);
    registerTableCellEditor(Point.class, PointEditor.class);
    registerTableCellEditor(Insets.class, InsetsEditor.class);
    registerTableCellEditor(FloatInsets.class, FloatInsetsEditor.class);
    registerTableCellEditor(Font.class, FontEditor.class);
    registerTableCellEditor(FontUIResource.class, FontEditor.class);
    registerTableCellEditor(java.util.Date.class, SpinnerDateEditor.class);
    registerTableCellEditor(java.sql.Date.class, SpinnerDateEditor.class);
    registerTableCellEditor(Timestamp.class, SpinnerDateEditor.class);
    registerTableCellEditor(Direction.class, DirectionEditor.class);
    registerTableCellEditor(OrthogonalLinkDirectionType.class, EnumTypeEditor.class.getName() + "@" + "twaver.orthogonal" + "|false");
    G = new H();
    P = new F();
    I = new twaver.base.A.F.E.D();
    T = null;
    K = null;
    V = new twaver.base.A.F.E.C();
    C = new B();
    N = new twaver.base.A.F.E.A();
    S = G.B;
    O = I.C;
    J = null;
    Q = null;
    registerAttachment("attachment.link.cnet", "/resource/image/twaver/linkCNET.png", 1);
    registerAttachment("attachment.link.electrical", "/resource/image/twaver/linkElectrical.png", 1);
    registerAttachment("attachment.link.fiber", "/resource/image/twaver/linkFiber.png", 1);
    registerAttachment("attachment.message", MessageAttachment.class, 7);
    Y = new LinkedHashMap();
    Y.put("solid.thinnest", A(1.0F, null));
    Y.put("solid.thin", A(2.0F, null));
    Y.put("solid.middle", A(3.0F, null));
    Y.put("solid.thick", A(4.0F, null));
    Y.put("solid.thickest", A(6.0F, null));
    Y.put("dot.thinnest", A(4.0F, 1, new float[] { 0.0F, 7.0F }));
    Y.put("dot.thin", A(5.0F, 1, new float[] { 0.0F, 9.0F }));
    Y.put("dot.middle", A(6.0F, 1, new float[] { 0.0F, 11.0F }));
    Y.put("dot.thick", A(7.0F, 1, new float[] { 0.0F, 13.0F }));
    Y.put("dot.thickest", A(8.0F, 1, new float[] { 0.0F, 15.0F }));
    Y.put("square.thinnest", A(1.0F, new float[] { 2.0F }));
    Y.put("square.thin", A(1.0F, new float[] { 5.0F }));
    Y.put("square.middle", A(3.0F, new float[] { 5.0F }));
    Y.put("square.thick", A(4.0F, new float[] { 5.0F }));
    Y.put("square.thickest", A(6.0F, new float[] { 5.0F }));
    Y.put("dash.thinnest", A(1.0F, new float[] { 20.0F, 5.0F }));
    Y.put("dash.thin", A(2.0F, new float[] { 20.0F, 5.0F }));
    Y.put("dash.middle", A(3.0F, new float[] { 20.0F, 5.0F }));
    Y.put("dash.thick", A(4.0F, new float[] { 20.0F, 5.0F }));
    Y.put("dash.thickest", A(6.0F, new float[] { 20.0F, 5.0F }));
    Y.put("dash.dot.thinnest", A(1.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.thin", A(2.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.middle", A(3.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.thick", A(4.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.thickest", A(6.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.dot.thinnest", A(1.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.dot.thin", A(2.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.dot.middle", A(3.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.dot.thick", A(4.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("dash.dot.dot.thickest", A(6.0F, new float[] { 20.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }));
    Y.put("zigzag.narrowest", new twaver.base.A.D.F.D(TWaverConst.DOUBLE_WIDTH_STROKE, 1.0F, 2.0F));
    Y.put("zigzag.narrow", new twaver.base.A.D.F.D(TWaverConst.DOUBLE_WIDTH_STROKE, 2.0F, 4.0F));
    Y.put("zigzag.middle", new twaver.base.A.D.F.D(TWaverConst.DOUBLE_WIDTH_STROKE, 3.0F, 5.0F));
    Y.put("zigzag.wide", new twaver.base.A.D.F.D(TWaverConst.DOUBLE_WIDTH_STROKE, 5.0F, 5.0F));
    Y.put("zigzag.widest", new twaver.base.A.D.F.D(TWaverConst.DOUBLE_WIDTH_STROKE, 8.0F, 5.0F));
    Y.put("solid.0", A(0.0F, null));
    Y.put("solid.1", A(1.0F, null));
    Y.put("solid.2", A(2.0F, null));
    Y.put("solid.3", A(3.0F, null));
    Y.put("solid.4", A(4.0F, null));
    Y.put("solid.5", A(5.0F, null));
    Y.put("solid.6", A(6.0F, null));
    Y.put("solid.7", A(7.0F, null));
    Y.put("solid.8", A(8.0F, null));
    Y.put("solid.9", A(9.0F, null));
    Y.put("solid.10", A(10.0F, null));
    Y.put("solid.11", A(11.0F, null));
    Y.put("solid.12", A(12.0F, null));
    Y.put("solid.13", A(13.0F, null));
    Y.put("solid.14", A(14.0F, null));
    Y.put("solid.15", A(15.0F, null));
    Y.put("solid.16", A(16.0F, null));
    Y.put("solid.17", A(17.0F, null));
    Y.put("solid.18", A(18.0F, null));
    Y.put("solid.19", A(19.0F, null));
    Y.put("solid.20", A(20.0F, null));
  }
  
  public static void registerPredefinedPropertyCopied(String propertyName, boolean copyOrNot)
  {
    L.put(propertyName, Boolean.valueOf(copyOrNot));
  }
  
  public static boolean isPredefinedPropertyCopied(String propertyName)
  {
    if (propertyName == null) {
      return false;
    }
    if (propertyName.startsWith("StateIcon:"))
    {
      Boolean value = (Boolean)L.get("StateIcon:");
      return value == null ? false : value.booleanValue();
    }
    Boolean value = (Boolean)L.get(propertyName);
    return value == null ? false : value.booleanValue();
  }
  
  public static Iterator getPredefinedJavabeanNames()
  {
    return R.keySet().iterator();
  }
  
  public static boolean isPredefinedJavabeanName(String javaBeanName)
  {
    return R.containsKey(javaBeanName);
  }
  
  public static Iterator getPredefinedClientPropertyKeys()
  {
    return U.keySet().iterator();
  }
  
  public static boolean isPredefinedClientPropertyKey(String clientPropertyKey)
  {
    if (clientPropertyKey == null) {
      return false;
    }
    if (clientPropertyKey.startsWith("StateIcon:")) {
      return true;
    }
    return U.containsKey(clientPropertyKey);
  }
  
  public static void updateDefaultFont()
  {
    g = UIManager.getFont("Label.font");
    if (g == null) {
      g = new Font("default", 1, 12);
    }
    F = g.deriveFont(1);
    E = g.deriveFont(0);
    D = g.deriveFont(2);
    _ = g.deriveFont(3);
    b = g.deriveFont(10.0F);
  }
  
  public static void setDefaultFont(Font font)
  {
    X = font;
    if (X != null)
    {
      e = X.deriveFont(1);
      W = X.deriveFont(0);
      B = X.deriveFont(2);
      H = X.deriveFont(3);
      Z = X.deriveFont(10.0F);
    }
    else
    {
      e = null;
      W = null;
      B = null;
      H = null;
      Z = null;
    }
  }
  
  public static Font getDefaultFont()
  {
    if (X != null) {
      return X;
    }
    return g;
  }
  
  public static Font getDefaultBoldFont()
  {
    if (e != null) {
      return e;
    }
    return F;
  }
  
  public static Font getDefaultPlainFont()
  {
    if (W != null) {
      return W;
    }
    return E;
  }
  
  public static Font getDefaultItalicFont()
  {
    if (B != null) {
      return B;
    }
    return D;
  }
  
  public static Font getDefaultItalicBoldFont()
  {
    if (H != null) {
      return H;
    }
    return _;
  }
  
  public static Font getDefault10SizeFont()
  {
    if (Z != null) {
      return Z;
    }
    return b;
  }
  
  public static Iterator getDefaultkeys()
  {
    return A.keySet().iterator();
  }
  
  public static void registerDefault(String key, Object value)
  {
    A.put(key, value);
  }
  
  public static Object get(String key)
  {
    return A.get(key);
  }
  
  private static Object A(String key, Class clazz)
  {
    Object value = A.get(key);
    if ((value != null) && (!clazz.isAssignableFrom(value.getClass()))) {
      throw new IllegalStateException("\nValue with key '" + key + "' in TUIManager should be instance of " + clazz + "\nactually the value is: " + value + ", an instance of " + value.getClass());
    }
    return value;
  }
  
  public static Font getFont(String key)
  {
    Object value = A(key, Font.class);
    return (Font)value;
  }
  
  public static Shape getShape(String key)
  {
    Object value = A(key, Shape.class);
    return (Shape)value;
  }
  
  public static Map getMap(String key)
  {
    Object value = A(key, Map.class);
    return (Map)value;
  }
  
  public static Color getColor(String key)
  {
    Object value = A(key, Color.class);
    return (Color)value;
  }
  
  public static boolean getBoolean(String key)
  {
    Object value = A(key, Boolean.class);
    return (value instanceof Boolean) ? ((Boolean)value).booleanValue() : false;
  }
  
  public static Comparator getComparator(String key)
  {
    Object value = A(key, Comparator.class);
    return (Comparator)value;
  }
  
  public static List getList(String key)
  {
    Object value = A(key, List.class);
    return (List)value;
  }
  
  public static NumberFormat getNumberFormat(String key)
  {
    Object value = A(key, NumberFormat.class);
    return (NumberFormat)value;
  }
  
  public static PopupMenuGenerator getPopupMenuGenerator(String key)
  {
    Object value = A(key, PopupMenuGenerator.class);
    return (PopupMenuGenerator)value;
  }
  
  public static int getInt(String key)
  {
    Object value = A(key, Integer.class);
    return (value instanceof Integer) ? ((Integer)value).intValue() : 0;
  }
  
  public static float getFloat(String key)
  {
    Object value = A(key, Float.class);
    return (value instanceof Float) ? ((Float)value).floatValue() : 0.0F;
  }
  
  public static double getDouble(String key)
  {
    Object value = A(key, Double.class);
    return (value instanceof Double) ? ((Double)value).doubleValue() : 0.0D;
  }
  
  public static Border getBorder(String key)
  {
    Object value = A(key, Border.class);
    return (Border)value;
  }
  
  public static Icon getIcon(String key)
  {
    Object value = A(key, Icon.class);
    return (Icon)value;
  }
  
  public static Insets getInsets(String key)
  {
    Object value = A(key, Insets.class);
    return (Insets)value;
  }
  
  public static FloatInsets getFloatInsets(String key)
  {
    Object value = A(key, FloatInsets.class);
    return (FloatInsets)value;
  }
  
  public static Dimension getDimension(String key)
  {
    Object value = A(key, Dimension.class);
    return (Dimension)value;
  }
  
  public static String getString(String key)
  {
    Object value = A(key, String.class);
    return (String)value;
  }
  
  public static Stroke getStroke(String key)
  {
    Object value = get(key);
    if ((value instanceof Stroke)) {
      return (Stroke)value;
    }
    if ((value instanceof String)) {
      return getStrokeByType((String)value);
    }
    if ((value instanceof Integer)) {
      return TWaverUtil.createStroke(((Integer)value).intValue());
    }
    return null;
  }
  
  public static Direction getDirection(String key)
  {
    Object value = A(key, Direction.class);
    return (Direction)value;
  }
  
  public static ImageIcon getIcon(Class clazz)
  {
    return B(clazz, M);
  }
  
  public static ImageIcon getImage(Class clazz)
  {
    return B(clazz, d);
  }
  
  public static String getIconUrl(Class clazz)
  {
    return A(clazz, M);
  }
  
  public static String getImageUrl(Class clazz)
  {
    return A(clazz, d);
  }
  
  public static void registerIcon(Class elementClass, String url)
  {
    if (!Element.class.isAssignableFrom(elementClass)) {
      throw new IllegalArgumentException("elementClass must be subclass of twaver.Element");
    }
    M.put(elementClass, url);
  }
  
  public static void registerImage(Class elementClass, String url)
  {
    if (!Element.class.isAssignableFrom(elementClass)) {
      throw new IllegalArgumentException("elementClass must be subclass of twaver.Element");
    }
    d.put(elementClass, url);
  }
  
  public static void registerWithoutImage(Class elementClass)
  {
    c.add(elementClass);
  }
  
  public static Iterator getIconkeys()
  {
    return M.keySet().iterator();
  }
  
  public static Iterator getImageKeys()
  {
    return d.keySet().iterator();
  }
  
  private static ImageIcon B(Class clazz, Map mapper)
  {
    String url = A(clazz, mapper);
    if (url != null) {
      return twaver.base.A.E.C.B(url);
    }
    return null;
  }
  
  private static String A(Class clazz, Map mapper)
  {
    Class searchClazz = clazz;
    String url = null;
    while ((url == null) && (clazz != null))
    {
      if ((mapper == d) && (c.contains(clazz))) {
        break;
      }
      url = (String)mapper.get(clazz);
      clazz = clazz.getSuperclass();
    }
    if (!mapper.containsKey(searchClazz)) {
      mapper.put(searchClazz, url);
    }
    return url;
  }
  
  public static String getTableCellRenderer(Class valueClass)
  {
    return (String)a.get(valueClass);
  }
  
  public static String getTableCellEditor(Class valueClass)
  {
    return (String)f.get(valueClass);
  }
  
  public static void registerTableCellRenderer(Class valueClass, String rendererClass)
  {
    a.put(valueClass, rendererClass);
  }
  
  public static void registerTableCellRenderer(Class valueClass, Class rendererClass)
  {
    if (rendererClass == null) {
      registerTableCellRenderer(valueClass, null);
    } else {
      registerTableCellRenderer(valueClass, rendererClass.getName());
    }
  }
  
  public static void registerTableCellEditor(Class valueClass, String editorClass)
  {
    f.put(valueClass, editorClass);
  }
  
  public static void registerTableCellEditor(Class valueClass, Class editorClass)
  {
    if (editorClass == null) {
      registerTableCellEditor(valueClass, null);
    } else {
      registerTableCellEditor(valueClass, editorClass.getName());
    }
  }
  
  public static Iterator getTableCellRendererKeys()
  {
    return a.keySet().iterator();
  }
  
  public static Iterator getTableCellEditorKeys()
  {
    return f.keySet().iterator();
  }
  
  public static Generator getElementNetworkLabelGenerator()
  {
    return G;
  }
  
  public static void setElementNetworkLabelGenerator(Generator networkElementLabelGenerator)
  {
    G = networkElementLabelGenerator;
  }
  
  public static Generator getElementTreeLabelGenerator()
  {
    return P;
  }
  
  public static void setElementTreeLabelGenerator(Generator treeElementLabelGenerator)
  {
    if (treeElementLabelGenerator == null) {
      throw new NullPointerException("treeElementLabelGenerator cannot be null");
    }
    P = treeElementLabelGenerator;
  }
  
  public static Generator getElementToolTipTextGenerator()
  {
    return I;
  }
  
  public static void setElementToolTipTextGenerator(Generator elementToolTipTextGenerator)
  {
    I = elementToolTipTextGenerator;
  }
  
  public static BlinkingRule getBlinkingRule()
  {
    return T;
  }
  
  public static void setBlinkingRule(BlinkingRule blinkingRule)
  {
    T = blinkingRule;
  }
  
  public static VisibleFilter getLinkBundleFilter()
  {
    return K;
  }
  
  public static void setLinkBundleFilter(VisibleFilter linkBundleFilter)
  {
    K = linkBundleFilter;
  }
  
  public static Generator getLinkBundleAgentGenerator()
  {
    return V;
  }
  
  public static void setLinkBundleAgentGenerator(Generator linkBundleAgentGenerator)
  {
    V = linkBundleAgentGenerator;
  }
  
  public static Generator getElementStateOutlineColorGenerator()
  {
    return C;
  }
  
  public static void setElementStateOutlineColorGenerator(Generator elementOutlineColorGenerator)
  {
    C = elementOutlineColorGenerator;
  }
  
  public static Generator getElementBodyColorGenerator()
  {
    return N;
  }
  
  public static void setElementBodyColorGenerator(Generator elementBodyColorGenerator)
  {
    N = elementBodyColorGenerator;
  }
  
  public static Icon getExpandedIcon()
  {
    return (Icon)UIManager.get("Tree.expandedIcon");
  }
  
  public static Icon getCollapsedIcon()
  {
    return (Icon)UIManager.get("Tree.collapsedIcon");
  }
  
  public static Color getPanelBackground()
  {
    return UIManager.getColor("Panel.background");
  }
  
  public static Generator getAlarmLabelGenerator()
  {
    return S;
  }
  
  public static void setAlarmLabelGenerator(Generator alarmLabelGenerator)
  {
    S = alarmLabelGenerator;
  }
  
  public static Generator getAlarmColorGenerator()
  {
    return O;
  }
  
  public static void setAlarmColorGenerator(Generator alarmColorGenerator)
  {
    O = alarmColorGenerator;
  }
  
  public static Generator getElementHeadCustomAttributeGenerator()
  {
    return J;
  }
  
  public static void setElementHeadCustomAttributeGenerator(Generator customAttributeGenerator)
  {
    J = customAttributeGenerator;
  }
  
  public static Generator getElementBodyCustomAttributeGenerator()
  {
    return Q;
  }
  
  public static void setElementBodyCustomAttributeGenerator(Generator elementBodyAttributeGenerator)
  {
    Q = elementBodyAttributeGenerator;
  }
  
  public static Object getAttachmentInfo(String name)
  {
    return IconAttachmentHolder.getAttachmentInfo(name);
  }
  
  public static PositionStruct getAttachmentPosition(String name)
  {
    return IconAttachmentHolder.getAttachmentPosition(name);
  }
  
  public static void registerAttachment(String name, String iconURL)
  {
    IconAttachmentHolder.addAttachment(name, iconURL);
  }
  
  public static void registerAttachment(String name, String iconURL, int position)
  {
    IconAttachmentHolder.addAttachment(name, iconURL, position, 0, 0);
  }
  
  public static void registerAttachment(String name, String iconURL, int position, int xOffset, int yOffset)
  {
    IconAttachmentHolder.addAttachment(name, iconURL, position, xOffset, yOffset);
  }
  
  public static void registerAttachment(String name, Class clazz)
  {
    IconAttachmentHolder.addAttachment(name, clazz);
  }
  
  public static void registerAttachment(String name, Class clazz, int position)
  {
    IconAttachmentHolder.addAttachment(name, clazz, position, 0, 0);
  }
  
  public static void registerAttachment(String name, Class clazz, int position, int xOffset, int yOffset)
  {
    IconAttachmentHolder.addAttachment(name, clazz, position, xOffset, yOffset);
  }
  
  public static Stroke getStrokeByType(String type)
  {
    return (Stroke)Y.get(type);
  }
  
  public static void registerStroke(String type, Stroke stroke)
  {
    Y.put(type, stroke);
  }
  
  public static Iterator getStrokeTypes()
  {
    return Y.keySet().iterator();
  }
  
  private static BasicStroke A(float width, int cap, float[] dash)
  {
    return new BasicStroke(width, cap, 1, 10.0F, dash, 0.0F);
  }
  
  private static BasicStroke A(float width, float[] dash)
  {
    return new BasicStroke(width, 0, 1, 10.0F, dash, 0.0F);
  }
  
  public static LinkStyleFactory getLinkStyleFactory(String linkStyle)
  {
    return J.A(linkStyle);
  }
  
  public static void registerLinkStyle(String linkStyle, LinkStyleFactory linkStyleFactory)
  {
    J.A(linkStyle, linkStyleFactory);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TUIManager
 * JD-Core Version:    0.7.0.1
 */
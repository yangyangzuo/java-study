package twaver;

import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Alarm
  implements Serializable
{
  public static final String PROPERTY_ALARMID = "alarmID";
  public static final String PROPERTY_ACKED = "acked";
  public static final String PROPERTY_ACKTIME = "ackTime";
  public static final String PROPERTY_ACKUSERID = "ackUserID";
  public static final String PROPERTY_ADDITIONALTEXT = "additionalText";
  public static final String PROPERTY_ALARMSEVERITY = "alarmSeverity";
  public static final String PROPERTY_ALARMTYPE = "alarmType";
  public static final String PROPERTY_CLEAREDTIME = "clearedTime";
  public static final String PROPERTY_CLEARUSERID = "clearUserID";
  public static final String PROPERTY_COMMENTS = "comments";
  public static final String PROPERTY_CORRELATEDALARMS = "correlatedAlarms";
  public static final String PROPERTY_ELEMENTID = "elementID";
  public static final String PROPERTY_TRENDINDICATION = "trendIndication";
  public static final String PROPERTY_SPECIFICPROBLEM = "specificProblem";
  public static final String PROPERTY_RAISEDTIME = "raisedTime";
  public static final String PROPERTY_PROPOSEDREPAIRACTION = "proposedRepairAction";
  public static final String PROPERTY_PROBABLECAUSE = "probableCause";
  public static final String PROPERTY_LASTCHANGEDTIME = "lastChangedTime";
  public static final String PROPERTY_CLEARED = "cleared";
  private PropertyChangeSupport A = new PropertyChangeSupport(this);
  private Map B = new LinkedHashMap();
  private static final Map C = new LinkedHashMap();
  
  static
  {
    try
    {
      Field[] fields = Alarm.class.getFields();
      for (int i = 0; i < fields.length; i++)
      {
        Field field = fields[i];
        String fileName = field.getName();
        if (fileName.startsWith("PROPERTY_"))
        {
          String propertyName = field.get(null).toString();
          C.put(propertyName, null);
        }
      }
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
  }
  
  public static boolean isPredefinedProperty(String propertyName)
  {
    return C.containsKey(propertyName);
  }
  
  public static Iterator getPredefinedProperties()
  {
    return C.keySet().iterator();
  }
  
  public Alarm()
  {
    this(null, null, null);
  }
  
  public Alarm(Object alarmID)
  {
    this(alarmID, null, null);
  }
  
  public Alarm(Object alarmID, Object elementID)
  {
    this(alarmID, elementID, null);
  }
  
  public Alarm(Object elementID, AlarmSeverity severity)
  {
    this(null, elementID, severity);
  }
  
  public Alarm(Object alarmID, Object elementID, AlarmSeverity severity)
  {
    if (alarmID == null) {
      alarmID = TWaverUtil.getIdentifierFactory().getIdentifier(this);
    }
    putClientProperty("alarmID", alarmID);
    putClientProperty("elementID", elementID);
    putClientProperty("alarmSeverity", severity);
  }
  
  public boolean isAcked()
  {
    Object value = getClientProperty("acked");
    return (value instanceof Boolean) ? ((Boolean)value).booleanValue() : false;
  }
  
  public Date getAckTime()
  {
    return (Date)getClientProperty("ackTime");
  }
  
  public String getAckUserID()
  {
    Object value = getClientProperty("ackUserID");
    return value == null ? null : value.toString();
  }
  
  public AlarmSeverity getAlarmSeverity()
  {
    return (AlarmSeverity)getClientProperty("alarmSeverity");
  }
  
  public AlarmType getAlarmType()
  {
    return (AlarmType)getClientProperty("alarmType");
  }
  
  public Date getClearedTime()
  {
    return (Date)getClientProperty("clearedTime");
  }
  
  public String getClearUserID()
  {
    Object value = getClientProperty("clearUserID");
    return value == null ? null : value.toString();
  }
  
  public Collection getComments()
  {
    return (Collection)getClientProperty("comments");
  }
  
  public Collection getCorrelatedAlarmIDs()
  {
    return (Collection)getClientProperty("correlatedAlarms");
  }
  
  public Object getElementID()
  {
    return getClientProperty("elementID");
  }
  
  public Date getLastChangedTime()
  {
    return (Date)getClientProperty("lastChangedTime");
  }
  
  public AlarmProbableCause getProbableCause()
  {
    return (AlarmProbableCause)getClientProperty("probableCause");
  }
  
  public String getProposedRepairAction()
  {
    Object value = getClientProperty("proposedRepairAction");
    return value == null ? null : value.toString();
  }
  
  public Date getRaisedTime()
  {
    return (Date)getClientProperty("raisedTime");
  }
  
  public String getSpecificProblem()
  {
    Object value = getClientProperty("specificProblem");
    return value == null ? null : value.toString();
  }
  
  public AlarmTrendIndication getTrendIndication()
  {
    return (AlarmTrendIndication)getClientProperty("trendIndication");
  }
  
  public void setAcked(boolean acked)
  {
    putClientProperty("acked", Boolean.valueOf(acked));
  }
  
  public void setAckTime(Date ackTime)
  {
    putClientProperty("ackTime", ackTime);
  }
  
  public void setAckUserID(String ackUserID)
  {
    putClientProperty("ackUserID", ackUserID);
  }
  
  public void setAdditionalText(String additionalText)
  {
    putClientProperty("additionalText", additionalText);
  }
  
  public void setAlarmSeverity(AlarmSeverity alarmSeverity)
  {
    putClientProperty("alarmSeverity", alarmSeverity);
  }
  
  public void setAlarmType(AlarmType alarmType)
  {
    putClientProperty("alarmType", alarmType);
  }
  
  public void setClearedTime(Date clearedTime)
  {
    putClientProperty("clearedTime", clearedTime);
  }
  
  public void setClearUserID(String clearUserID)
  {
    putClientProperty("clearUserID", clearUserID);
  }
  
  public void addComment(String comment)
  {
    List value = (List)getClientProperty("comments");
    if (value == null) {
      value = new ArrayList();
    }
    value.add(comment);
    this.B.put("comments", value);
    this.A.firePropertyChange("comments", value, comment);
  }
  
  public void addCorrelatedAlarmID(Object correlatedAlarmID)
  {
    List value = (List)getClientProperty("correlatedAlarms");
    if (value == null) {
      value = new ArrayList();
    }
    value.add(correlatedAlarmID);
    this.B.put("correlatedAlarms", value);
    this.A.firePropertyChange("correlatedAlarms", value, correlatedAlarmID);
  }
  
  public void setElementID(Object elementID)
  {
    putClientProperty("elementID", elementID);
  }
  
  public void setTrendIndication(AlarmTrendIndication trendIndication)
  {
    putClientProperty("trendIndication", trendIndication);
  }
  
  public void setSpecificProblem(String specificProblem)
  {
    putClientProperty("specificProblem", specificProblem);
  }
  
  public void setRaisedTime(Date raisedTime)
  {
    putClientProperty("raisedTime", raisedTime);
  }
  
  public void setProposedRepairAction(String proposedRepairAction)
  {
    putClientProperty("proposedRepairAction", proposedRepairAction);
  }
  
  public void setProbableCause(AlarmProbableCause probableCause)
  {
    putClientProperty("probableCause", probableCause);
  }
  
  public void setLastChangedTime(Date lastChangedTime)
  {
    putClientProperty("lastChangedTime", lastChangedTime);
  }
  
  public String getAdditionalText()
  {
    Object value = getClientProperty("additionalText");
    return value == null ? null : value.toString();
  }
  
  public Object getAlarmID()
  {
    return getClientProperty("alarmID");
  }
  
  public boolean isCleared()
  {
    Object value = getClientProperty("cleared");
    return (value instanceof Boolean) ? ((Boolean)value).booleanValue() : false;
  }
  
  public void setCleared(boolean cleared)
  {
    putClientProperty("cleared", Boolean.valueOf(cleared));
  }
  
  public int hashCode()
  {
    return getAlarmID().hashCode();
  }
  
  public PropertyChangeSupport getPropertyChangeSupport()
  {
    return this.A;
  }
  
  public Object getClientProperty(Object key)
  {
    return this.B.get(key);
  }
  
  public void putClientProperty(Object key, Object value)
  {
    Object oldValue = this.B.get(key);
    if (oldValue != value)
    {
      if (("alarmID".equals(key)) && (oldValue != null)) {
        return;
      }
      this.B.put(key, value);
      this.A.firePropertyChange(key.toString(), oldValue, value);
    }
  }
  
  public void putClientProperty(Object key, int value)
  {
    putClientProperty(key, TWaverUtil.valueOf(value));
  }
  
  public void putClientProperty(Object key, boolean value)
  {
    putClientProperty(key, Boolean.valueOf(value));
  }
  
  public Map getClientProperties()
  {
    return this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Alarm
 * JD-Core Version:    0.7.0.1
 */
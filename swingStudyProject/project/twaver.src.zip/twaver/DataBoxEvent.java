package twaver;

import java.util.EventObject;

public class DataBoxEvent
  extends EventObject
{
  public static final int ELEMENT_ADDED = 1;
  public static final int ELEMENT_REMOVED = 2;
  public static final int ELEMENTS_CLEARED = 3;
  private Element A = null;
  private Element E = null;
  private Node C = null;
  private Node D = null;
  private Node G = null;
  private BTS F = null;
  private int B = 0;
  private Object H = null;
  
  public DataBoxEvent(TDataBox box, Element element, int type)
  {
    this(box, element, null, null, null, null, null, type);
  }
  
  public DataBoxEvent(TDataBox box, Element element, Element parent, Node from, Node to, Node host, BTS bts, int type)
  {
    super(box);
    this.A = element;
    this.E = parent;
    this.C = from;
    this.D = to;
    this.G = host;
    this.F = bts;
    if ((type != 1) && (type != 2) && (type != 3)) {
      throw new IllegalArgumentException("illegal data box event type:" + type);
    }
    this.B = type;
  }
  
  public TDataBox getDataBox()
  {
    return (TDataBox)this.source;
  }
  
  public Element getElement()
  {
    return this.A;
  }
  
  public int getType()
  {
    return this.B;
  }
  
  public Element getParent()
  {
    return this.E;
  }
  
  public Object getUserObject()
  {
    return this.H;
  }
  
  public void setUserObject(Object userObject)
  {
    this.H = userObject;
  }
  
  public Node getFrom()
  {
    return this.C;
  }
  
  public Node getTo()
  {
    return this.D;
  }
  
  public Node getHost()
  {
    return this.G;
  }
  
  public BTS getBTS()
  {
    return this.F;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxEvent
 * JD-Core Version:    0.7.0.1
 */
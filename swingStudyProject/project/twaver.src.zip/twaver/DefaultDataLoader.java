package twaver;

import java.io.IOException;

public class DefaultDataLoader
  implements DataLoader
{
  public void load(TSubNetwork subNetwork, TDataBox box)
  {
    String dataSource = subNetwork.getDataSource();
    if ((!subNetwork.isDataLoaded()) && (dataSource != null) && (!dataSource.trim().equals("")) && (loadData(dataSource, subNetwork, box))) {
      subNetwork.setDataLoaded(true);
    }
  }
  
  protected boolean loadData(String dataSource, TSubNetwork subNetwork, TDataBox box)
  {
    try
    {
      box.parse(dataSource, subNetwork);
      return true;
    }
    catch (IOException e)
    {
      TWaverUtil.handleError(null, e);
    }
    return false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DefaultDataLoader
 * JD-Core Version:    0.7.0.1
 */
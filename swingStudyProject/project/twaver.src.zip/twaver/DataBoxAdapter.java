package twaver;

public class DataBoxAdapter
  implements DataBoxListener
{
  public void elementAdded(DataBoxEvent e) {}
  
  public void elementRemoved(DataBoxEvent e) {}
  
  public void elementsCleared(DataBoxEvent e) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxAdapter
 * JD-Core Version:    0.7.0.1
 */
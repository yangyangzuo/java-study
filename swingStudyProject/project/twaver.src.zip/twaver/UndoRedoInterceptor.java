package twaver;

import java.beans.PropertyChangeEvent;

public abstract interface UndoRedoInterceptor
  extends Interceptor
{
  public abstract void undo(TDataBox paramTDataBox, Object paramObject);
  
  public abstract void redo(TDataBox paramTDataBox, Object paramObject);
  
  public abstract boolean isInterested(DataBoxEvent paramDataBoxEvent);
  
  public abstract boolean isInterested(PropertyChangeEvent paramPropertyChangeEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.UndoRedoInterceptor
 * JD-Core Version:    0.7.0.1
 */
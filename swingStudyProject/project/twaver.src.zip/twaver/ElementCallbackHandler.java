package twaver;

public abstract interface ElementCallbackHandler
{
  public abstract boolean processElement(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementCallbackHandler
 * JD-Core Version:    0.7.0.1
 */
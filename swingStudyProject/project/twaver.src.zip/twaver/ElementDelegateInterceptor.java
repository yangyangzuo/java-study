package twaver;

import java.beans.Encoder;

public abstract interface ElementDelegateInterceptor
  extends Interceptor
{
  public abstract void beforeInitialize(Encoder paramEncoder, Element paramElement1, Element paramElement2);
  
  public abstract void afterInitialize(Encoder paramEncoder, Element paramElement1, Element paramElement2);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementDelegateInterceptor
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipException;

public class DataBoxJarReader
{
  private JarURLConnection A = null;
  
  public DataBoxJarReader(JarURLConnection connection)
  {
    this.A = connection;
    this.A.setDefaultUseCaches(false);
  }
  
  public void read(TDataBox box)
    throws IOException
  {
    read(box, null);
  }
  
  public void read(TDataBox box, Element parentOfRootElement)
    throws IOException
  {
    JarFile jarfile = this.A.getJarFile();
    Vector imageEntryNames = new Vector();
    Enumeration e = jarfile.entries();
    while (e.hasMoreElements())
    {
      JarEntry entry = (JarEntry)e.nextElement();
      String name = entry.getName();
      if (!name.equals("data.xml")) {
        imageEntryNames.addElement(name);
      }
    }
    JarEntry xmlEntry = (JarEntry)jarfile.getEntry("data.xml");
    if (xmlEntry == null) {
      throw new ZipException("Illegal format template jar: \"" + this.A.getJarFileURL().toString() + "\"");
    }
    InputStream xmlInputStream = jarfile.getInputStream(xmlEntry);
    byte[] xmlChars = TWaverUtil.getByteArrayFromInputStream(xmlInputStream);
    String xmlString = new String(xmlChars, "UTF-8");
    Iterator it = imageEntryNames.iterator();
    while (it.hasNext())
    {
      String imageEntryName = (String)it.next();
      String imageURL = "<string>jar:" + this.A.getJarFileURL().toString() + "!/" + imageEntryName + "</string>";
      imageURL = A(imageURL);
      String regex = "<string>" + imageEntryName + "</string>";
      String replacement = imageURL;
      xmlString = xmlString.replaceAll(regex, replacement);
    }
    PersistenceManager.readByXML(box, xmlString, parentOfRootElement);
    xmlInputStream.close();
    jarfile.getInputStream(xmlEntry).close();
    jarfile.close();
  }
  
  private static String A(String text)
  {
    while (text.indexOf("\\") != -1)
    {
      int index = text.indexOf("\\");
      String str1 = text.substring(0, index);
      String str2 = text.substring(index + 1);
      text = str1 + "/" + str2;
    }
    return text;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxJarReader
 * JD-Core Version:    0.7.0.1
 */
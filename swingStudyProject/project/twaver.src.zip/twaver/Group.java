package twaver;

import java.awt.Color;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D.Double;
import java.util.List;
import twaver.base.A.E.E;
import twaver.base.A.E.V;
import twaver.base.A.E.a;
import twaver.base.A.E.i;

public class Group
  extends Node
{
  protected int groupType = 1;
  protected boolean expand = false;
  private boolean O = true;
  private transient Rectangle N = null;
  private boolean M = false;
  
  public Group() {}
  
  public Group(Object id)
  {
    super(id);
  }
  
  public String getUIClassID()
  {
    return "GroupUI";
  }
  
  public String getSVGUIClassID()
  {
    return "GroupSVGUI";
  }
  
  public boolean isExpand()
  {
    return this.expand;
  }
  
  public boolean isAdjustToBottom()
  {
    return (V.C(this)) && (E.A(this));
  }
  
  public void setExpand(boolean expand)
  {
    if (this.expand == expand) {
      return;
    }
    boolean oldValue = this.expand;
    this.expand = expand;
    firePropertyChange("expand", oldValue, expand);
  }
  
  public Rectangle getBounds()
  {
    return (Rectangle)getShape().clone();
  }
  
  public final Point getLocation()
  {
    return getShape().getLocation();
  }
  
  public final int getWidth()
  {
    return getShape().width;
  }
  
  public final int getHeight()
  {
    return getShape().height;
  }
  
  public final Rectangle getShape()
  {
    if ((this.O) || (this.N == null))
    {
      this.O = false;
      Rectangle oldShape = this.N;
      Rectangle rect = i.A(this);
      if (rect == null)
      {
        this.N = V.E(this);
      }
      else if (isExpand())
      {
        this.N = rect;
      }
      else
      {
        int w = V.H(this);
        int h = V.A(this);
        this.N = new Rectangle((int)(rect.getCenterX() - w / 2.0D), (int)(rect.getCenterY() - h / 2.0D), w, h);
      }
      A(this.N.getX(), this.N.getY());
      if (oldShape != null)
      {
        firePropertyChange("width", oldShape.width, this.N.width);
        firePropertyChange("height", oldShape.height, this.N.height);
      }
      else
      {
        firePropertyChange("width", -1, this.N.width);
        firePropertyChange("height", -1, this.N.height);
      }
      firePropertyChange("groupModelShape", -1, this.N.height);
    }
    return this.N;
  }
  
  public void setLocation(Point2D.Double location)
  {
    if ((this.M) || (location == null)) {
      return;
    }
    invalidateGroupShape();
    double xOffset = location.getX() - this.xLocation;
    double yOffset = location.getY() - this.yLocation;
    if ((xOffset == 0.0D) && (yOffset == 0.0D)) {
      return;
    }
    if (F())
    {
      this.M = true;
      TWaverUtil.moveElements(getChildren().iterator(), null, xOffset, yOffset);
      this.M = false;
    }
    else
    {
      A(location.getX(), location.getY());
    }
    invalidateGroupShape();
  }
  
  private boolean F()
  {
    if (!V.D(this)) {
      return false;
    }
    return !TWaverUtil.isXMLParsing();
  }
  
  private void A(double x, double y)
  {
    Point2D.Double oldValue = new Point2D.Double(this.xLocation, this.yLocation);
    this.xLocation = x;
    this.yLocation = y;
    firePropertyChange("location", oldValue, new Point2D.Double(x, y));
  }
  
  public boolean isAdjusting()
  {
    return this.M;
  }
  
  public void invalidateGroupShape()
  {
    if (this.M) {
      return;
    }
    this.O = true;
    getShape();
  }
  
  public int getGroupType()
  {
    return this.groupType;
  }
  
  public void setGroupType(int groupType)
  {
    if ((this.groupType != groupType) && ((groupType == 1) || (groupType == 2) || (groupType == 3) || (groupType == 4) || (groupType == 5) || (groupType == 6)))
    {
      int oldValue = this.groupType;
      this.groupType = groupType;
      firePropertyChange("groupType", oldValue, this.groupType);
    }
  }
  
  public void putClientProperty(Object key, Object value)
  {
    super.putClientProperty(key, value);
    if ((key.equals("group.outline.dash")) && (Boolean.TRUE.equals(value))) {
      putClientProperty("group.outline.stroke", "square.thinnest");
    }
  }
  
  public void putGroupOutline(boolean groupOutline)
  {
    putClientProperty("group.outline", groupOutline);
  }
  
  public void putGroupOutlineStroke(String groupOutlineStroke)
  {
    putClientProperty("group.outline.stroke", groupOutlineStroke);
  }
  
  public void putGroupFill(boolean groupFill)
  {
    putClientProperty("group.fill", groupFill);
  }
  
  public void putGroupOpaque(boolean groupOpaque)
  {
    putClientProperty("group.opaque", groupOpaque);
  }
  
  public void putGroupOutlineColor(Color groupOutlineColor)
  {
    putClientProperty("group.outline.color", groupOutlineColor);
  }
  
  public void putGroupFillColor(Color groupFillColor)
  {
    putClientProperty("group.fill.color", groupFillColor);
  }
  
  public void putGroupChildrenOutcrop(int groupChildrenOutcrop)
  {
    putClientProperty("group.children.outcrop", groupChildrenOutcrop);
  }
  
  public void putGroupInsets(Insets groupInsets)
  {
    putClientProperty("group.insets", groupInsets);
  }
  
  public void putGroupHandlerExpandIcon(String groupHandlerExpandIcon)
  {
    putClientProperty("group.handler.expand.icon", groupHandlerExpandIcon);
  }
  
  public void putGroupHandlerCloseIcon(String groupHandlerCloseIcon)
  {
    putClientProperty("group.handler.close.icon", groupHandlerCloseIcon);
  }
  
  public void putGroupHandlerEmptyIcon(String groupHandlerEmptyIcon)
  {
    putClientProperty("group.handler.empty.icon", groupHandlerEmptyIcon);
  }
  
  public void putGroupDoubleClickEnabled(boolean groupDoubleClickEnabled)
  {
    putClientProperty("group.double.click.enable", groupDoubleClickEnabled);
  }
  
  public void putGroupAngle(int groupAngle)
  {
    putClientProperty("group.angle", groupAngle);
  }
  
  public void putGroup3D(boolean group3D)
  {
    putClientProperty("group.3d", group3D);
  }
  
  public void putGroupAntialias(boolean groupAntialias)
  {
    putClientProperty("group.antialias", groupAntialias);
  }
  
  public void putGroupDeep(int groupDeep)
  {
    putClientProperty("group.deep", groupDeep);
  }
  
  public void putGroupHandlerVisible(boolean groupHandlerVisible)
  {
    putClientProperty("group.handler.visible", groupHandlerVisible);
  }
  
  public void putGroupHandlerPosition(int groupHandlerPosition)
  {
    putClientProperty("group.handler.position", groupHandlerPosition);
  }
  
  public void putGroupHandlerXoffset(int groupHandlerXoffset)
  {
    putClientProperty("group.handler.xoffset", groupHandlerXoffset);
  }
  
  public void putGroupHandlerYoffset(int groupHandlerYoffset)
  {
    putClientProperty("group.handler.yoffset", groupHandlerYoffset);
  }
  
  public void putGroupGradient(boolean groupGradient)
  {
    putClientProperty("group.gradient", groupGradient);
  }
  
  public void putGroupGradientColor(Color groupGradientColor)
  {
    putClientProperty("group.gradient.color", groupGradientColor);
  }
  
  public void putGroupGradientFactory(int groupGradientFactory)
  {
    putClientProperty("group.gradient.factory", groupGradientFactory);
  }
  
  public int getGroupAngle()
  {
    return a.J(this, "group.angle");
  }
  
  public boolean isGroup3D()
  {
    return a.K(this, "group.3d");
  }
  
  public int getGroupDeep()
  {
    return a.J(this, "group.deep");
  }
  
  public boolean isGroupOutline()
  {
    return a.K(this, "group.outline");
  }
  
  public String getGroupOutlineStroke()
  {
    return a.Q(this, "group.outline.stroke");
  }
  
  public boolean isGroupFill()
  {
    return a.K(this, "group.fill");
  }
  
  public boolean isGroupOpaque()
  {
    return a.K(this, "group.opaque");
  }
  
  public Color getGroupOutlineColor()
  {
    return a.P(this, "group.outline.color");
  }
  
  public Color getGroupFillColor()
  {
    return a.P(this, "group.fill.color");
  }
  
  public boolean isGroupAntialias()
  {
    return a.K(this, "group.antialias");
  }
  
  public Insets getGroupInsets()
  {
    return a.B(this, "group.insets");
  }
  
  public int getGroupChildrenOutcrop()
  {
    return a.J(this, "group.children.outcrop");
  }
  
  public boolean isGroupDoubleClickEnable()
  {
    return a.K(this, "group.double.click.enable");
  }
  
  public String getGroupHandlerExpandIcon()
  {
    return a.Q(this, "group.handler.expand.icon");
  }
  
  public String getGroupHandlerCloseIcon()
  {
    return a.Q(this, "group.handler.close.icon");
  }
  
  public String getGroupHandlerEmptyIcon()
  {
    return a.Q(this, "group.handler.empty.icon");
  }
  
  public boolean isGroupHandlerVisible()
  {
    return a.K(this, "group.handler.visible");
  }
  
  public int getGroupHandlerPosition()
  {
    return a.J(this, "group.handler.position");
  }
  
  public int getGroupHandlerXOffset()
  {
    return a.J(this, "group.handler.xoffset");
  }
  
  public int getGroupHandlerYOffset()
  {
    return a.J(this, "group.handler.yoffset");
  }
  
  public boolean isGroupGradient()
  {
    return a.K(this, "group.gradient");
  }
  
  public Color getGroupGradientColor()
  {
    return a.P(this, "group.gradient.color");
  }
  
  public int getGroupGradientFactory()
  {
    return a.J(this, "group.gradient.factory");
  }
  
  public void putGroupChamferEdge(int chamferLength)
  {
    putClientProperty("group.chamfer.edge", chamferLength);
  }
  
  public int getGroupChamferEdge()
  {
    return a.J(this, "group.chamfer.edge");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Group
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.beans.PropertyChangeEvent;

public abstract interface PropertyChangeFilter
  extends Filter
{
  public abstract boolean isInterested(PropertyChangeEvent paramPropertyChangeEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PropertyChangeFilter
 * JD-Core Version:    0.7.0.1
 */
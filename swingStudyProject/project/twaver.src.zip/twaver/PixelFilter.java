package twaver;

import java.awt.Color;

public abstract interface PixelFilter
{
  public abstract int filter(int paramInt, Color paramColor);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PixelFilter
 * JD-Core Version:    0.7.0.1
 */
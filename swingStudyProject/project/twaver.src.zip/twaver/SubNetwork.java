package twaver;

import java.awt.Color;
import java.awt.Point;
import twaver.network.background.Background;
import twaver.network.background.ColorBackground;
import twaver.network.background.ImageBackground;
import twaver.network.background.TextureBackground;

public class SubNetwork
  extends Follower
  implements TSubNetwork
{
  private Background Â = null;
  private String Ä = null;
  private boolean Ã = false;
  private Point Á = null;
  
  public SubNetwork() {}
  
  public SubNetwork(Object id)
  {
    super(id);
  }
  
  public String getUIClassID()
  {
    return "SubNetworkUI";
  }
  
  public String getSVGUIClassID()
  {
    return "SubNetworkSVGUI";
  }
  
  public Point getViewPoint()
  {
    return this.Á;
  }
  
  public void setViewPoint(Point viewPoint)
  {
    Object oldValue = this.Á;
    this.Á = viewPoint;
    firePropertyChange("viewPoint", oldValue, viewPoint);
  }
  
  public Background getBackground()
  {
    return this.Â;
  }
  
  public void setBackground(Background background)
  {
    Background oldvalue = this.Â;
    this.Â = background;
    firePropertyChange("background", oldvalue, this.Â);
  }
  
  public void setTextureBackground(String imageURL)
  {
    setBackground(new TextureBackground(imageURL));
  }
  
  public void setImageBackground(String imageURL)
  {
    setBackground(new ImageBackground(imageURL));
  }
  
  public void setColorBackground(Color color)
  {
    setBackground(new ColorBackground(color));
  }
  
  public String getDataSource()
  {
    return this.Ä;
  }
  
  public void setDataSource(String dataSource)
  {
    Object oldValue = this.Ä;
    this.Ä = dataSource;
    firePropertyChange("dataSource", oldValue, dataSource);
  }
  
  public boolean isDataLoaded()
  {
    return this.Ã;
  }
  
  public void setDataLoaded(boolean dataLoaded)
  {
    boolean oldValue = this.Ã;
    this.Ã = dataLoaded;
    firePropertyChange("dataLoaded", oldValue, dataLoaded);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SubNetwork
 * JD-Core Version:    0.7.0.1
 */
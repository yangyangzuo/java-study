package twaver;

import java.awt.geom.Point2D.Double;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;

public class Follower
  extends ResizableNode
{
  private double a = 0.0D;
  private double d = 0.0D;
  private Node c = null;
  private boolean _ = false;
  private PropertyChangeListener b = null;
  
  public Follower() {}
  
  public Follower(Object id)
  {
    super(id);
  }
  
  public Follower(Object id, Node host)
  {
    super(id);
    setHost(host);
  }
  
  public void setLocation(Point2D.Double location)
  {
    super.setLocation(location);
    calculateOffset();
  }
  
  public Node getHost()
  {
    return this.c;
  }
  
  public void setHost(Node host)
  {
    if ((this == host) || (this.c == host)) {
      return;
    }
    Node oldValue = this.c;
    if (oldValue != null)
    {
      oldValue.B(this);
      if (this.b != null) {
        oldValue.removePropertyChangeListener(this.b);
      }
    }
    this.c = host;
    if (this.c != null)
    {
      this.c.A(this);
      if (this.b == null) {
        this.b = new SerializablePropertyChangeListener()
        {
          public void propertyChange(PropertyChangeEvent evt)
          {
            if (evt.getPropertyName().equals("location")) {
              Follower.this.adjustPosition();
            }
            if (!TWaverUtil.isXMLParsing()) {
              Follower.this.hostPropertyChange(evt);
            }
          }
        };
      }
      this.c.addPropertyChangeListener(this.b);
    }
    else
    {
      this.c = null;
    }
    calculateOffset();
    adjustBounds();
    firePropertyChange("host", oldValue, host);
  }
  
  public void adjustBounds() {}
  
  protected void hostPropertyChange(PropertyChangeEvent evt) {}
  
  protected void calculateOffset()
  {
    Node host = getHost();
    if (host == null) {
      return;
    }
    this.a = (host.getX() - getX());
    this.d = (host.getY() - getY());
  }
  
  protected void adjustPosition()
  {
    if ((TWaverUtil.isXMLParsing()) || (!TWaverUtil.isUpdateFollowerLocationWithHost()))
    {
      calculateOffset();
    }
    else if ((!this._) && (this.c != null))
    {
      this._ = true;
      double x = this.c.getX() - this.a;
      double y = this.c.getY() - this.d;
      setLocation(x, y);
      this._ = false;
    }
  }
  
  public boolean isHostOn(Node node)
  {
    Node tmpHost = getHost();
    if (tmpHost == null) {
      return false;
    }
    Map checkedHost = new HashMap();
    while ((tmpHost != null) && (tmpHost != this) && (!checkedHost.containsKey(tmpHost)))
    {
      if (tmpHost == node)
      {
        checkedHost.clear();
        checkedHost = null;
        return true;
      }
      checkedHost.put(tmpHost, null);
      if ((tmpHost instanceof Follower)) {
        tmpHost = ((Follower)tmpHost).getHost();
      } else {
        tmpHost = null;
      }
    }
    checkedHost = null;
    return false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Follower
 * JD-Core Version:    0.7.0.1
 */
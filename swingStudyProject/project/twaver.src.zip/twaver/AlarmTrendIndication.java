package twaver;

import twaver.base.enumerable.AbstractEnumerable;

public final class AlarmTrendIndication
  extends AbstractEnumerable
{
  public static final AlarmTrendIndication LESS_SEVERE = new AlarmTrendIndication("Less severe");
  public static final AlarmTrendIndication NO_CHANGE = new AlarmTrendIndication("No change");
  public static final AlarmTrendIndication MORE_SEVERE = new AlarmTrendIndication("More severe");
  
  private AlarmTrendIndication(String name)
  {
    super(name);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmTrendIndication
 * JD-Core Version:    0.7.0.1
 */
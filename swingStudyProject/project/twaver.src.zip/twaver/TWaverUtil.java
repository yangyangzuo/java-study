package twaver;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.KeyboardFocusManager;
import java.awt.LayoutManager;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.beans.BeanInfo;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.swing.GrayFilter;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.filechooser.FileFilter;
import twaver.animate.AnimateCenterLocation;
import twaver.animate.AnimateDelete;
import twaver.animate.AnimateLocation;
import twaver.animate.AnimateResize;
import twaver.base.A.B.A;
import twaver.base.A.E.D;
import twaver.base.A.E.K;
import twaver.base.A.E.L;
import twaver.base.A.E.N;
import twaver.base.A.E.P;
import twaver.base.A.E.V;
import twaver.base.A.E._;
import twaver.base.A.E.a;
import twaver.base.A.E.c;
import twaver.base.A.E.j;
import twaver.base.A.E.n;
import twaver.base.A.G.I;
import twaver.base.A.G.J;
import twaver.base.Direction;
import twaver.swing.SingleFiledLayout;
import twaver.web.svg.network.SVGContext;

public final class TWaverUtil
{
  public static int CLICK_COUNT_TO_START = 1;
  private static final twaver.base.A.G.F A = new twaver.base.A.G.F();
  private static final I C = new I();
  private static Method N = null;
  private static Method B = null;
  private static boolean D = true;
  private static Collator Q = null;
  private static Locale U = null;
  private static ResourceBundle I = null;
  private static ResourceBundle W = null;
  private static Class J = null;
  private static String E = null;
  private static DataLoader O = new DefaultDataLoader();
  private static IdentifierFactory V = twaver.base.A.F.H.A();
  private static Generator T = null;
  private static List F = null;
  private static int M = 0;
  private static String P = null;
  private static XMLInterceptor H = null;
  private static int L = 12;
  private static int R = 15;
  public static ClassLoader classLoader = null;
  private static PixelFilter K = new RGBPixelFilter();
  private static boolean S = true;
  public static ErrorHandler errorHandler = new ErrorHandler()
  {
    public void handle(String errorMessage, Throwable exception)
    {
      if (errorMessage != null) {
        System.err.println(errorMessage);
      }
      if (exception != null) {
        exception.printStackTrace();
      }
    }
  };
  private static ExportValuesInterceptor G = new DefaultExportValuesInterceptor();
  
  static
  {
    Locale defaultLocale = Locale.getDefault();
    if ((Locale.CHINESE.equals(defaultLocale)) || (Locale.SIMPLIFIED_CHINESE.equals(defaultLocale))) {
      setLocale(TWaverConst.ZH_CN);
    } else {
      setLocale(TWaverConst.EN_US);
    }
    twaver.base.A.G.C.E();
    validateLicense("/resource/license.dat");
  }
  
  public static boolean isUpdateFollowerLocationWithHost()
  {
    return S;
  }
  
  public static void setUpdateFollowerLocationWithHost(boolean updateFollowerLocationWithHost)
  {
    S = updateFollowerLocationWithHost;
  }
  
  public static PixelFilter getPixelFilter()
  {
    return K;
  }
  
  public static void setPixelFilter(PixelFilter pixelFilter)
  {
    if (pixelFilter == null) {
      throw new NullPointerException("PixelFilter can not be null");
    }
    K = pixelFilter;
  }
  
  public static void handleError(String errorMessage, Throwable exception)
  {
    if (errorHandler != null) {
      errorHandler.handle(errorMessage, exception);
    }
  }
  
  public static List getCopyElements()
  {
    return F;
  }
  
  public static void setCopyElements(List copyElements)
  {
    F = copyElements;
  }
  
  public static int getPasteOffset()
  {
    return M;
  }
  
  public static void setPasteOffset(int pasteOffset)
  {
    M = pasteOffset;
  }
  
  public static final String getVersionString()
  {
    return "3.3";
  }
  
  public static Integer valueOf(int i)
  {
    int offset = 128;
    if ((i >= -128) && (i <= 127)) {
      return _A.A[(i + 128)];
    }
    return new Integer(i);
  }
  
  public static String wrapCDATA(String text)
  {
    if (text == null) {
      return "<![CDATA[]]>";
    }
    return "<![CDATA[" + text + "]]>";
  }
  
  public static String getDataBoxVersion(String xmlData)
  {
    if (xmlData == null) {
      return null;
    }
    int start = xmlData.indexOf("<string>#VERSION{");
    if (start < 0) {
      return null;
    }
    int end = xmlData.indexOf("}VERSION#</string>");
    if (end < 0) {
      return null;
    }
    return xmlData.substring(start + "<string>#VERSION{".length(), end);
  }
  
  public static boolean isXMLParsing()
  {
    return DataBoxParserAgent.getDataBox() != null;
  }
  
  public static boolean isXMLOutputting()
  {
    return P.A();
  }
  
  public static List getAllBeanInfo(Class elementClass)
  {
    return twaver.base.A.F.B.F.A().E(elementClass);
  }
  
  public static BeanInfo getBeanInfo(Class elementClass, String url)
  {
    return twaver.base.A.F.B.F.A().A(elementClass, url, false);
  }
  
  public static void registerBeanInfoWithoutDefault(Class elementClass)
  {
    twaver.base.A.F.B.F.A().A(elementClass);
  }
  
  public static void registerBeanInfo(Class elementClass, BeanInfo beanInfo)
  {
    twaver.base.A.F.B.F.A().A(elementClass, beanInfo);
  }
  
  public static void registerBeanInfo(Class elementClass, List attributes)
  {
    twaver.base.A.F.B.F.A().A(elementClass, attributes);
  }
  
  public static void registerBeanInfo(Class elementClass, String xmlURL)
  {
    twaver.base.A.F.B.F.A().A(elementClass, xmlURL);
  }
  
  public static void registerBeanInfo(Class elementClass, InputStream inputStream)
  {
    List attributes = createElementAttributes(elementClass, inputStream);
    if (attributes != null) {
      registerBeanInfo(elementClass, attributes);
    }
  }
  
  public static Image createDisabledImage(Image image)
  {
    return GrayFilter.createDisabledImage(image);
  }
  
  public static ImageIcon createDisabledImage(String url)
  {
    Image image = GrayFilter.createDisabledImage(getImage(url));
    return new ImageIcon(image);
  }
  
  public static List createElementAttributes(Class elementClass, InputStream inputStream)
  {
    try
    {
      return twaver.base.A.F.B.F.A().A(elementClass, inputStream);
    }
    catch (Exception e)
    {
      handleError("Error occurs when parsing xml from inputStream.", e);
    }
    return null;
  }
  
  public static void fullScreen(Window window)
  {
    twaver.base.A.E.O.A(window);
  }
  
  public static final void centerWindow(Component component)
  {
    twaver.base.A.E.O.A(component);
  }
  
  public static final Icon getIcon(String url)
  {
    return twaver.base.A.E.C.B(url);
  }
  
  public static void registerImageIcon(String url, ImageIcon imageIcon)
  {
    twaver.base.A.E.C.A(url, imageIcon);
  }
  
  public static final ImageIcon getImageIcon(String url)
  {
    return twaver.base.A.E.C.B(url);
  }
  
  public static final ImageIcon getImageIcon(String url, boolean handleError)
  {
    return twaver.base.A.E.C.A(url, handleError);
  }
  
  public static Image getImage(String url)
  {
    ImageIcon imageIcon = twaver.base.A.E.C.B(url);
    if (imageIcon != null) {
      return imageIcon.getImage();
    }
    return null;
  }
  
  public static ImageIcon getImageIcon(String url, Color color)
  {
    return N.A(url, color);
  }
  
  public static void saveImageToFile(ImageIcon icon, String fileName, String format)
  {
    N.A(icon.getImage(), fileName, format, false);
  }
  
  public static void saveImageToFile(ImageIcon icon, String fileName, String format, boolean cache)
  {
    N.A(icon.getImage(), fileName, format, cache);
  }
  
  public static final TSubNetwork getElementSubNetwork(Element element)
  {
    return V.G(element);
  }
  
  public static final String getCurrentLocalTime()
  {
    return getTimeLocalString(new Date());
  }
  
  public static final String getTimeLocalString(Date date)
  {
    if (date == null) {
      return null;
    }
    SimpleDateFormat formatter = new SimpleDateFormat();
    String result = formatter.format(date);
    return result;
  }
  
  public static Locale getLocale()
  {
    return U;
  }
  
  public static Class getResourceAgent()
  {
    return J;
  }
  
  public static void init(Locale locale, Class resourceAgent)
  {
    setLocale(locale);
    setResourceAgent(resourceAgent);
  }
  
  public static void setLocale(Locale locale)
  {
    if (locale == null) {
      locale = Locale.getDefault();
    }
    I = null;
    if (E != null)
    {
      String path = E.substring(1);
      if (path.endsWith("/")) {
        path = path + "i18n/TWaver";
      } else {
        path = path + "/i18n/TWaver";
      }
      try
      {
        I = ResourceBundle.getBundle(path, locale);
      }
      catch (MissingResourceException e)
      {
        I = null;
      }
    }
    if (I == null) {
      I = ResourceBundle.getBundle("resource/i18n/TWaver", locale);
    }
    W = ResourceBundle.getBundle("resource/i18n/TWaver", locale);
    U = locale;
    Q = Collator.getInstance(locale);
    TUIManager.class.getClass();
    twaver.base.A.C.E.B().A();
  }
  
  public static void setResourceAgent(Class resourceAgent)
  {
    J = resourceAgent;
    if (resourceAgent == null)
    {
      E = null;
    }
    else
    {
      E = resourceAgent.getName();
      int i = E.lastIndexOf('.');
      if (i != -1) {
        E = "/" + E.substring(0, i).replace('.', '/') + "/";
      } else {
        E = "/";
      }
    }
    setLocale(U);
  }
  
  public static String getString(String key)
  {
    if (T != null)
    {
      String value = (String)T.generate(key);
      if (value != null) {
        return value;
      }
    }
    try
    {
      return I.getString(key);
    }
    catch (Exception e1)
    {
      try
      {
        return W.getString(key);
      }
      catch (Exception localException1) {}
    }
    return key;
  }
  
  public static Dimension getTextSize(String content, Font font, Graphics2D g2d)
  {
    return c.A(content, font, g2d);
  }
  
  public static int getTextOffset(String content, Font font, Graphics2D g2d)
  {
    return c.B(content, font, g2d);
  }
  
  public static Font getFont(int style)
  {
    return TUIManager.getDefaultFont().deriveFont(style, TUIManager.getDefaultFont().getSize());
  }
  
  public static Font getFont(int style, float size)
  {
    return TUIManager.getDefaultFont().deriveFont(style, size);
  }
  
  public static DataLoader getDataLoader()
  {
    return O;
  }
  
  public static void setDataLoader(DataLoader dataGenerator)
  {
    O = dataGenerator;
  }
  
  public static IdentifierFactory getIdentifierFactory()
  {
    return V;
  }
  
  public static void setIdentifierFactory(IdentifierFactory newIdFactory)
  {
    if (newIdFactory == null) {
      throw new NullPointerException("new IdentifierFactory can't be null.");
    }
    V = newIdFactory;
  }
  
  public static Object getIdentifier(Object object)
  {
    return V.getIdentifier(object);
  }
  
  public static InputStream getInputStream(String url)
  {
    return twaver.base.A.E.C.B(url, true);
  }
  
  public static InputStream getInputStream(String url, boolean handleError)
  {
    return twaver.base.A.E.C.B(url, handleError);
  }
  
  public static byte[] toByte(long value, int size)
  {
    byte[] buffer = new byte[size];
    for (int i = size - 1; i >= 0; i--)
    {
      buffer[i] = ((byte)(int)(value % 256L));
      value /= 256L;
    }
    return buffer;
  }
  
  public static long toLong(byte[] buffer, int size)
  {
    long value = 0L;
    long base = 1L;
    for (int i = size - 1; i >= 0; i--)
    {
      value += base * (buffer[i] & 0xFF);
      base *= 256L;
    }
    return value;
  }
  
  public static byte[] getByteArrayFromImage(Image image, String formatName)
  {
    return N.A(image, formatName);
  }
  
  public static byte[] getByteArrayFromURL(String url)
  {
    return twaver.base.A.E.C.C(url);
  }
  
  public static byte[] getByteArrayFromInputStream(InputStream in)
  {
    return twaver.base.A.E.C.A(in);
  }
  
  public static byte[] toBytes(Object object)
    throws IOException
  {
    return _.A(object);
  }
  
  public static Object toObject(byte[] bytes)
    throws IOException, ClassNotFoundException
  {
    return _.A(bytes);
  }
  
  public static byte[] toByteByGZIP(Object object)
    throws IOException
  {
    return _.B(object);
  }
  
  public static Object toObjectByGZIP(byte[] bytes)
    throws IOException, ClassNotFoundException
  {
    return _.B(bytes);
  }
  
  public static String getPropertyName(PropertyChangeEvent e)
  {
    String propertyName = e.getPropertyName();
    if (propertyName.startsWith("CP:")) {
      propertyName = propertyName.substring("CP:".length());
    } else if (propertyName.startsWith("UP:")) {
      propertyName = propertyName.substring("UP:".length());
    } else if (propertyName.startsWith("BOJP:")) {
      propertyName = propertyName.substring("BOJP:".length());
    } else if (propertyName.startsWith("BOCP:")) {
      propertyName = propertyName.substring("BOCP:".length());
    }
    return propertyName;
  }
  
  public static BasicStroke stringToBasicStroke(String strokeDescription)
  {
    return L.G(strokeDescription);
  }
  
  public static Insets stringToInsets(String insetsDescription)
  {
    return L.A(insetsDescription);
  }
  
  public static Direction stringToDirection(String directionDescription)
  {
    return L.F(directionDescription);
  }
  
  public static Font stringToFont(String value)
  {
    return L.E(value);
  }
  
  public static Color stringToColor(String value)
  {
    return L.D(value);
  }
  
  public static Boolean stringToBoolean(String value)
  {
    return L.C(value);
  }
  
  public static Object stringToObject(String value, Class clazz)
  {
    return L.A(value, clazz);
  }
  
  public static void drawString(String content, Graphics2D g2, double x, double y, double angle)
  {
    c.A(content, g2, x, y, angle);
  }
  
  public static Class forName(String className, String defaultPath)
  {
    return twaver.base.A.E.H.A(className, defaultPath);
  }
  
  public static String getClassNameWithoutPackage(Class clazz)
  {
    return twaver.base.A.E.H.B(clazz);
  }
  
  public static Object createNewInstance(String className)
  {
    return twaver.base.A.E.H.B(className);
  }
  
  public static void native2ascii(String fromFile, String toFile)
    throws IOException
  {
    _.B(fromFile, toFile);
  }
  
  public static void setLookAndFeelWithDefaultFont() {}
  
  public static void setLookAndFeelWithFont(Font font)
  {
    twaver.base.A.E.O.A(font);
  }
  
  public static final Window getWindowForComponent(Component component)
  {
    return twaver.base.A.E.O.B(component);
  }
  
  public static InputStream convertEncoding(InputStream in, String sourceEncoding, String destEncoding)
    throws IOException
  {
    return _.A(in, sourceEncoding, destEncoding);
  }
  
  public static Map getAllDeclaredMethod(Class clazz)
  {
    return twaver.base.A.E.H.C(clazz);
  }
  
  public static String getResourceAgentURL()
  {
    return E;
  }
  
  public static void setEnableAutoScroll(boolean enabled)
  {
    try
    {
      twaver.base.A.A.H.B().A(enabled);
    }
    catch (Exception e)
    {
      handleError(null, e);
    }
  }
  
  public static boolean isEnableAutoScroll()
  {
    return twaver.base.A.A.H.B().A();
  }
  
  public static Window getActiveWindow()
  {
    return KeyboardFocusManager.getCurrentKeyboardFocusManager().getActiveWindow();
  }
  
  public static JPopupMenu showPopupComponet(Component popupComponent, Component parent, Point point)
  {
    return twaver.base.A.E.O.A(popupComponent, parent, point);
  }
  
  public static BasicStroke createStroke(int width)
  {
    return c.B(width);
  }
  
  public static BasicStroke createDashStroke(int width)
  {
    return c.D(width);
  }
  
  public static void outputXML(String fileName, Element element, boolean withElementId)
    throws IOException
  {
    twaver.base.A.E.E.A(fileName, element, withElementId);
  }
  
  public static String outputXML(Element element, boolean withElementId)
    throws IOException
  {
    return twaver.base.A.E.E.B(element, withElementId);
  }
  
  public static Element cloneElement(Element source, boolean withElementId)
  {
    return twaver.base.A.E.E.A(source, withElementId);
  }
  
  public static void setNewCardToSlot(TDataBox box, Slot slot, Card newCard, boolean adjustChildrenBounds)
  {
    twaver.base.A.E.E.A(box, slot, newCard, adjustChildrenBounds);
  }
  
  public static void setHorizontalAlignment(Component component, String alignment)
  {
    L.A(component, alignment);
  }
  
  public static void drawDashShape(Graphics2D g, Shape shape)
  {
    c.A(g, shape);
  }
  
  public static void drawDashLine(Graphics2D g, Point point1, Point point2, double zoom)
  {
    c.C(g, point1, point2, zoom);
  }
  
  public static void drawDashRectangle(Graphics2D g, Point point1, Point point2, double zoom)
  {
    c.B(g, point1, point2, zoom);
  }
  
  public static void drawDashRectangle(Graphics2D g, Rectangle rect, double zoom)
  {
    c.A(g, rect, zoom);
  }
  
  public static void drawDashRound(Graphics2D g, Point point1, Point point2, double zoom)
  {
    c.A(g, point1, point2, zoom);
  }
  
  public static double getDiagonalLength(Rectangle rect)
  {
    return D.A(rect);
  }
  
  public static double getAngle(Point p1, Point p2)
  {
    return D.B(p1, p2);
  }
  
  public static double getDistance(Point2D p1, Point2D p2)
  {
    return D.A(p1, p2);
  }
  
  public static double getDistance(double x1, double y1, double x2, double y2)
  {
    return D.C(x1, y1, x2, y2);
  }
  
  public static Rectangle getRectangle(Point p1, Point p2)
  {
    return D.A(p1, p2);
  }
  
  public static boolean isConnected(Node node1, Node node2)
  {
    return j.C(node1, node2);
  }
  
  public static List getBundledLinks(Node node1, Node node2)
  {
    return j.A(node1, node2);
  }
  
  public static boolean isBundledLinksExpand(Node node1, Node node2)
  {
    List list = j.A(node1, node2);
    if ((list == null) || (list.size() == 0)) {
      return false;
    }
    Link link = (Link)list.get(0);
    return link.isLinkBundleExpand();
  }
  
  public static void setBundledLinksExpand(Node node1, Node node2, boolean isExpanded)
  {
    j.A(node1, node2, isExpanded);
  }
  
  public static void reverseBundledLinksExpand(Link link)
  {
    boolean isExpanded = a.K(link, "link.bundle.expand");
    j.A(link.getFromAgent(), link.getToAgent(), !isExpanded);
  }
  
  public static void getAllDescendant(Element element, List list)
  {
    V.A(element, list);
  }
  
  public static PropertyDescriptor createPropertyDescriptor(Class elementClass, ElementAttribute attribute)
  {
    return twaver.base.A.E.H.A(elementClass, attribute);
  }
  
  public static BeanInfo createBeanInfo(Class elementClass, List attributes)
  {
    return twaver.base.A.E.H.A(elementClass, attributes);
  }
  
  public static void paintIcon(Color lightColor, Color fillColor, Color outlineColor, int shapeType, int gradientType, Rectangle bounds, Graphics2D g2d)
  {
    c.A(lightColor, fillColor, outlineColor, shapeType, gradientType, bounds, g2d);
  }
  
  public static ImageIcon createBallIcon(int width, int height, Color lightColor, Color fillColor, Color outlineColor)
  {
    return c.A(width, height, lightColor, fillColor, outlineColor, 1, 13);
  }
  
  public static ImageIcon createRectIcon(int width, int height, Color lightColor, Color darkColor, Color outlineColor)
  {
    return c.A(width, height, lightColor, darkColor, outlineColor, 2, 5);
  }
  
  public static ImageIcon createIcon(int width, int height, Color lightColor, Color fillColor, Color outlineColor, int shapeType, int gradientType)
  {
    return c.A(width, height, lightColor, fillColor, outlineColor, shapeType, gradientType);
  }
  
  public static double getRandomDouble()
  {
    return n.A();
  }
  
  public static int getRandomInt(int max)
  {
    return n.B(max);
  }
  
  public static Point getRandomPoint(int max)
  {
    return n.A(max);
  }
  
  public static Color getRandomColor()
  {
    return n.E();
  }
  
  public static Color getRandomAlphaColor()
  {
    return n.H();
  }
  
  public static Boolean getRandomBoolean()
  {
    return n.G();
  }
  
  public static boolean getRandomBool()
  {
    return n.B();
  }
  
  public static float getRandomFloat()
  {
    return n.D();
  }
  
  public static long getRandomLong()
  {
    return n.F();
  }
  
  public static double getRandomGaussian()
  {
    return n.C();
  }
  
  public static AlarmSeverity getRandomSeverity()
  {
    return AlarmSeverity.getRandomSeverity();
  }
  
  public static AlarmSeverity getRandomNonClearedSeverity()
  {
    return AlarmSeverity.getNonClearedRandomSeverity();
  }
  
  public static void setResourceLocateInterceptor(ResourceLocateInterceptor interceptor)
  {
    twaver.base.A.E.C.A(interceptor);
  }
  
  public static Shape getImageShape(String url)
  {
    return N.C(url);
  }
  
  public static boolean isImageIconCached(String url)
  {
    return twaver.base.A.E.C.A(url);
  }
  
  public static void fillShapeInAntialias(Graphics g, Shape shape)
  {
    c.B(g, shape);
  }
  
  public static void drawShapeInAntialias(Graphics g, Shape shape)
  {
    c.A(g, shape);
  }
  
  public static String replace(String inString, String oldPattern, String newPattern)
  {
    return L.A(inString, oldPattern, newPattern);
  }
  
  public static Generator getI18nGenerator()
  {
    return T;
  }
  
  public static void setI18nGenerator(Generator generator)
  {
    T = generator;
  }
  
  public static void validateLicense(String licenseLocation)
  {
    twaver.base.A.G.C.C(licenseLocation);
  }
  
  public static byte[] decodeBase64Buffer(byte[] data)
  {
    try
    {
      return A.A(new String(data));
    }
    catch (IOException ex)
    {
      handleError(null, ex);
    }
    return null;
  }
  
  public static String encodeBase64Buffer(byte[] data)
  {
    return C.A(data);
  }
  
  public static void setEnableComponent(Component c, boolean enabled)
  {
    twaver.base.A.E.O.A(c, new ComponentCallbackHandler()
    {
      private final boolean val$enabled;
      
      public void processComponent(Component component)
      {
        component.setEnabled(this.val$enabled);
      }
    });
  }
  
  public static void iteratorComponent(Component c, ComponentCallbackHandler handler)
  {
    twaver.base.A.E.O.A(c, handler);
  }
  
  public static LayoutManager createVerticalLayout(int gap)
  {
    return new SingleFiledLayout(0, 2, gap);
  }
  
  public static LayoutManager createHorizontalLayout(int gap)
  {
    return new SingleFiledLayout(1, 2, gap);
  }
  
  public static JPanel createVerticalPanel(int gap)
  {
    return new JPanel(new SingleFiledLayout(0, 2, gap));
  }
  
  public static JPanel createHorizontalPanel(int gap)
  {
    return new JPanel(new SingleFiledLayout(1, 2, gap));
  }
  
  public static boolean getCurrentBlinkFlag()
  {
    return twaver.base.A.D.A.B.B();
  }
  
  public static void setAnimateBlinkInterval(int interval)
  {
    if (interval <= 0) {
      interval = 1000;
    }
    twaver.base.A.D.A.B.C().setInterval(interval);
    if (TaskScheduler.getInstance().getMinInterval() > interval) {
      TaskScheduler.getInstance().setMinInterval(interval);
    }
    if ((interval >= 500) && (TaskScheduler.getInstance().getMinInterval() < 500)) {
      TaskScheduler.getInstance().setMinInterval(500);
    }
  }
  
  public static void setAnimateGIFInterval(int interval)
  {
    twaver.base.A.D.B.E.B().A().setMinInterval(interval);
  }
  
  public static boolean exportImage(Component component)
  {
    return exportImage(component, twaver.base.A.E.O.C());
  }
  
  public static boolean exportImage(Component component, JFileChooser chooser)
  {
    int returnVal = chooser.showSaveDialog(component);
    if (returnVal != 0) {
      return false;
    }
    String fileName = chooser.getSelectedFile().getAbsolutePath();
    String formatName = chooser.getFileFilter().getDescription();
    return exportImage(component, fileName, formatName);
  }
  
  public static boolean exportImage(Component component, String fileName, String formatName)
  {
    return exportImage(component, fileName, formatName, 1.0D, new Rectangle(component.getSize()));
  }
  
  public static boolean exportImage(Component component, String fileName, String formatName, double zoom, Rectangle logicalBounds)
  {
    twaver.base.A.A.A.C exporter = new twaver.base.A.A.A.C(component, zoom, logicalBounds, formatName, null);
    return exporter.B(fileName);
  }
  
  public static boolean exportToImageIcon(Component component, String iconUrl, String formatName)
  {
    return exportToImageIcon(component, iconUrl, formatName, 1.0D, new Rectangle(component.getSize()));
  }
  
  public static boolean exportToImageIcon(Component component, String iconUrl, String formatName, double zoom, Rectangle logicalBounds)
  {
    twaver.base.A.A.A.C exporter = new twaver.base.A.A.A.C(component, zoom, logicalBounds, formatName, null);
    return exporter.A(iconUrl);
  }
  
  public static boolean exportImage(Component component, OutputStream outputStream, String formatName, double zoom, Rectangle logicalBounds, String tempFileName)
  {
    twaver.base.A.A.A.C exporter = new twaver.base.A.A.A.C(component, zoom, logicalBounds, formatName, tempFileName);
    return exporter.A(outputStream);
  }
  
  public static ExportValuesInterceptor getExportValuesInterceptor()
  {
    return G;
  }
  
  public static void setExportValuesInterceptor(ExportValuesInterceptor exportValuesInterceptor)
  {
    if (exportValuesInterceptor == null) {
      throw new NullPointerException("ExportValuesInterceptor can not be null");
    }
    G = exportValuesInterceptor;
  }
  
  public static Cursor createCustomCursor(Image cursorImage, Point hotSpot, String name)
  {
    Dimension size = Toolkit.getDefaultToolkit().getBestCursorSize(cursorImage.getWidth(null), cursorImage.getHeight(null));
    if ((size.width < cursorImage.getWidth(null)) || (size.height < cursorImage.getHeight(null))) {
      return Toolkit.getDefaultToolkit().createCustomCursor(cursorImage, hotSpot, name);
    }
    BufferedImage bufferImage = new BufferedImage(size.width, size.height, 2);
    for (int x = 0; x < size.width; x++) {
      for (int y = 0; y < size.height; y++) {
        bufferImage.setRGB(x, y, 0);
      }
    }
    bufferImage.getGraphics().drawImage(cursorImage, 0, 0, null);
    return Toolkit.getDefaultToolkit().createCustomCursor(bufferImage, hotSpot, name);
  }
  
  public static JFileChooser createImageFileChooser()
  {
    return twaver.base.A.E.O.C();
  }
  
  public static boolean doLayout(Iterator elements, int layoutType, Runnable runnable, int xOffset, int yOffset, Generator elementSizeGenerator)
  {
    try
    {
      twaver.base.A.D.E.B autoLayouter = new twaver.base.A.D.E.B(null, elements, layoutType, false, runnable, xOffset, yOffset, elementSizeGenerator);
      return autoLayouter.A();
    }
    catch (Exception ex)
    {
      handleError(null, ex);
    }
    return false;
  }
  
  public static int compare(String source, String target)
  {
    return Q.compare(source, target);
  }
  
  public static boolean isGrayImageBeforeDyed()
  {
    return D;
  }
  
  public static void setGrayImageBeforeDyed(boolean grayImageBeforeDyed)
  {
    D = grayImageBeforeDyed;
  }
  
  public static void main(String[] args)
  {
    JOptionPane.showMessageDialog(null, "TWaver " + getVersionString());
    System.exit(0);
  }
  
  public static Method getBocpReadMethod()
  {
    return N;
  }
  
  public static void setBocpReadMethod(Method bocpReadMethod)
  {
    N = bocpReadMethod;
  }
  
  public static Method getBocpWriteMethod()
  {
    return B;
  }
  
  public static void setBocpWriteMethod(Method bocpWriteMethod)
  {
    B = bocpWriteMethod;
  }
  
  public static String getDataBoxVersion()
  {
    return P;
  }
  
  public static void setDataBoxVersion(String dataBoxVersion)
  {
    P = dataBoxVersion;
  }
  
  public static XMLInterceptor getXMLInterceptor()
  {
    return H;
  }
  
  public static void setXMLInterceptor(XMLInterceptor xmlInterceptor)
  {
    H = xmlInterceptor;
  }
  
  public static Rectangle getRectangle(List points)
  {
    return D.A(points);
  }
  
  public static boolean isPermissionGIS()
  {
    return twaver.base.A.G.C.G().M();
  }
  
  public static List filterMovingElements(Iterator iterator)
  {
    return V.A(iterator, null);
  }
  
  public static void moveElements(Iterator iterator, MovableFilter filter, double xOffset, double yOffset)
  {
    if ((xOffset == 0.0D) && (yOffset == 0.0D)) {
      return;
    }
    List elements = V.A(iterator, filter);
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      double x = xOffset + element.getX();
      double y = yOffset + element.getY();
      element.setLocation(x, y);
    }
  }
  
  public static void animateMove(Iterator iterator, double xOffset, double yOffset)
  {
    animateMove(iterator, null, xOffset, yOffset, null, -1, -1);
  }
  
  public static void animateMove(Iterator iterator, MovableFilter filter, double xOffset, double yOffset, Runnable runnable, int step, int sleep)
  {
    if ((xOffset == 0.0D) && (yOffset == 0.0D)) {
      return;
    }
    List elements = V.A(iterator, filter);
    Map map = new HashMap();
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      double x = xOffset + element.getX();
      double y = yOffset + element.getY();
      map.put(element, new Point((int)x, (int)y));
    }
    animateLocation(map, runnable, step, sleep);
  }
  
  public static void animateLocation(Map newLocations)
  {
    new AnimateLocation(newLocations).start();
  }
  
  public static void animateLocation(Map newLocations, Runnable runnable, int step, int sleep)
  {
    new AnimateLocation(newLocations, runnable, step, sleep).start();
  }
  
  public static void animateCenterLocation(Map newCenterLocations)
  {
    new AnimateCenterLocation(newCenterLocations).start();
  }
  
  public static void animateCenterLocation(Map newCenterLocations, Runnable runnable, int step, int sleep)
  {
    new AnimateCenterLocation(newCenterLocations, runnable, step, sleep).start();
  }
  
  public static void animateResize(Map newBounds)
  {
    new AnimateResize(newBounds).start();
  }
  
  public static void animateResize(Map newBounds, Runnable runnable, int step, int sleep)
  {
    new AnimateResize(newBounds, runnable, step, sleep).start();
  }
  
  public static void animateDelete(TDataBox box, List elements)
  {
    animateDelete(box, elements, null, -1, -1);
  }
  
  public static void animateDelete(TDataBox box, List elements, Runnable runnable, int step, int sleep)
  {
    new AnimateDelete(box, elements, runnable, step, sleep).start();
  }
  
  public static int getAnimateStep()
  {
    return L;
  }
  
  public static void setAnimateStep(int animateStep)
  {
    if (animateStep >= 0) {
      L = animateStep;
    }
  }
  
  public static int getAnimateSleep()
  {
    return R;
  }
  
  public static void setAnimateSleep(int animateSleep)
  {
    if (animateSleep >= 0) {
      R = animateSleep;
    }
  }
  
  public static final void layoutElements(List elements, Shape shape)
  {
    layoutElements(elements, shape, true);
  }
  
  public static final void layoutElements(List elements, Shape shape, boolean animate)
  {
    layoutElements(elements, shape, animate, null);
  }
  
  public static final void layoutElements(List elements, Shape shape, boolean animate, Runnable runnable)
  {
    if ((shape == null) || (elements == null) || (elements.size() == 0)) {
      return;
    }
    List points = K.A(shape, elements.size());
    if (animate)
    {
      Map map = new HashMap();
      for (int i = 0; i < points.size(); i++) {
        map.put(elements.get(i), points.get(i));
      }
      animateCenterLocation(map, runnable, -1, -1);
    }
    else
    {
      for (int i = 0; i < points.size(); i++)
      {
        Point2D point = (Point2D)points.get(i);
        Element element = (Element)elements.get(i);
        element.setCenterLocation(point.getX(), point.getY());
      }
      if (runnable != null) {
        runnable.run();
      }
    }
  }
  
  public static final void appendImage(SVGContext context, StringBuffer sb, String url, Color color, Rectangle bounds, float alpha)
  {
    twaver.base.A.H.E.A(context, sb, url, color, bounds, alpha);
  }
  
  public static Rectangle getTextBounds(String text, Font font)
  {
    return c.A(text, font);
  }
  
  public static ImageIcon createShadowImage(Image image)
  {
    return N.A(image);
  }
  
  public static ImageIcon createDistortedImage(Image image, double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3)
  {
    A filter = new A((float)x0, (float)y0, (float)x1, (float)y1, (float)x2, (float)y2, (float)x3, (float)y3);
    BufferedImage bufferedImage = null;
    if ((image instanceof BufferedImage))
    {
      bufferedImage = (BufferedImage)image;
    }
    else
    {
      bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), 2);
      Graphics g2 = bufferedImage.createGraphics();
      g2.drawImage(image, 0, 0, null);
      g2.dispose();
    }
    BufferedImage destination = filter.filter(bufferedImage, null);
    return new ImageIcon(destination);
  }
  
  public static void clearInvalidURLCache() {}
  
  public static void clearImageIconCache() {}
  
  public static double getLength(Shape shape)
  {
    return K.C(shape);
  }
  
  public static List divideShape(Shape shape, int count)
  {
    return K.A(shape, count);
  }
  
  public static String getColorHexString(Color c, boolean isAlpha)
  {
    return L.A(c, isAlpha);
  }
  
  public static Shape createShape(int type, Rectangle bounds)
  {
    return K.B(type, bounds);
  }
  
  public static JComboBox createEnumComboBox(String enumTypeName, boolean nullable, String alignment)
  {
    JComboBox comboBox = new JComboBox();
    comboBox.setRenderer(new twaver.base.A.A.B(alignment));
    Object[] enumTypes = EnumTypeManager.getInstance().getEnumTypes(enumTypeName);
    if (nullable) {
      comboBox.addItem(null);
    }
    for (int i = 0; i < enumTypes.length; i++) {
      comboBox.addItem(enumTypes[i]);
    }
    return comboBox;
  }
  
  public static Paint createTexturePaint(String textureType, Color color)
  {
    twaver.base.A.D.D.C tf = twaver.base.A.E.B.A(textureType);
    if (tf != null) {
      return tf.A(color);
    }
    return null;
  }
  
  public static Paint createGradientPaint(int gradientType, Rectangle bounds, Color gradientColor, Color fillColor)
  {
    twaver.base.A.D.O gf = c.E(gradientType);
    if (gf != null) {
      return gf.A(bounds, gradientColor, fillColor);
    }
    return null;
  }
  
  public static boolean isPointOnLine(double px, double py, double x1, double y1, double x2, double y2, double width)
  {
    return D.A(px, py, x1, y1, x2, y2, width);
  }
  
  private static class _A
  {
    static final Integer[] A = new Integer[256];
    
    static
    {
      for (int i = 0; i < A.length; i++) {
        A[i] = new Integer(i - 128);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TWaverUtil
 * JD-Core Version:    0.7.0.1
 */
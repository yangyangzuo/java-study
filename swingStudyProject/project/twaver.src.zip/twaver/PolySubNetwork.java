package twaver;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D.Double;
import java.util.Map;
import twaver.base.A.E.E;
import twaver.base.A.E.K;
import twaver.base.A.E.a;

public class PolySubNetwork
  extends SubNetwork
{
  private static final GeneralPath Æ = K.A(6, new Dimension(50, 50));
  private GeneralPath Ç = null;
  private GeneralPath Å = null;
  
  public PolySubNetwork()
  {
    setBaseShape(Æ);
    init();
  }
  
  public PolySubNetwork(Object id)
  {
    super(id);
    setBaseShape(Æ);
    init();
  }
  
  public PolySubNetwork(Shape baseShape)
  {
    setBaseShape(baseShape);
    init();
  }
  
  public PolySubNetwork(Object id, Shape baseShape)
  {
    super(id);
    setBaseShape(baseShape);
    init();
  }
  
  public GeneralPath getBaseShape()
  {
    return this.Ç;
  }
  
  public void setBaseShape(Shape baseShape)
  {
    if ((baseShape instanceof GeneralPath)) {
      setBaseShape((GeneralPath)baseShape);
    } else {
      setBaseShape(new GeneralPath(baseShape));
    }
  }
  
  public void setBaseShape(GeneralPath baseShape)
  {
    if (baseShape == null) {
      throw new NullPointerException("baseShape can't be null.");
    }
    Shape oldvalue = this.Ç;
    this.Ç = new GeneralPath(K.A(baseShape));
    firePropertyChange("baseShape", oldvalue, this.Ç);
    createTransformedShape();
  }
  
  protected void init()
  {
    getClientProperties().put("texture.factory", "stipple.loose");
  }
  
  public void setLocation(Point2D.Double location)
  {
    super.setLocation(location);
    createTransformedShape();
  }
  
  public String getUIClassID()
  {
    return "PolySubNetworkUI";
  }
  
  public String getSVGUIClassID()
  {
    return "PolySubNetworkSVGUI";
  }
  
  public int getWidth()
  {
    return getBounds().width;
  }
  
  public int getHeight()
  {
    return getBounds().height;
  }
  
  public Rectangle getBounds()
  {
    return getShape().getBounds();
  }
  
  public GeneralPath getShape()
  {
    return this.Å;
  }
  
  protected void createTransformedShape()
  {
    AffineTransform at = AffineTransform.getTranslateInstance(getLocation().getX(), getLocation().getY());
    Object oldValue = this.Å;
    this.Å = new GeneralPath(at.createTransformedShape(this.Ç));
    firePropertyChange("transformedShape", oldValue, this.Å);
  }
  
  public boolean isAdjustToBottom()
  {
    return E.A(this);
  }
  
  public void putPolyOutlineWidth(int polyOutlineWidth)
  {
    putClientProperty("poly.outline.width", polyOutlineWidth);
  }
  
  public void putPolyOutlineColor(Color polyOutlineColor)
  {
    putClientProperty("poly.outline.color", polyOutlineColor);
  }
  
  public void putPolyFill(boolean polyFill)
  {
    putClientProperty("poly.fill", polyFill);
  }
  
  public void putPoly3D(boolean poly3D)
  {
    putClientProperty("poly.3d", poly3D);
  }
  
  public int getPolyOutlineWidth()
  {
    return a.J(this, "poly.outline.width");
  }
  
  public Color getPolyOutlineColor()
  {
    return a.P(this, "poly.outline.color");
  }
  
  public boolean isPolyFill()
  {
    return a.K(this, "poly.fill");
  }
  
  public boolean isPoly3D()
  {
    return a.K(this, "poly.3d");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PolySubNetwork
 * JD-Core Version:    0.7.0.1
 */
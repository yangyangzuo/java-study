package twaver;

import java.awt.Point;
import javax.swing.JPopupMenu;

public abstract interface PopupMenuFactory
{
  public abstract JPopupMenu getPopupMenu(DataBoxSelectionModel paramDataBoxSelectionModel, Point paramPoint);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PopupMenuFactory
 * JD-Core Version:    0.7.0.1
 */
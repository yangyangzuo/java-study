package twaver;

import java.awt.Color;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Branch
  implements Serializable
{
  private boolean B = true;
  private Color A = null;
  protected List segments = new ArrayList();
  private PolyLine D = null;
  private Map C;
  protected PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
  
  public List getSegments()
  {
    return this.segments;
  }
  
  public void addSegment(Segment segment)
  {
    this.segments.add(segment);
    segment.setVisible(this.B);
    if (this.A != null) {
      segment.setLineColor(this.A);
    }
    segment.setBranch(this);
    firePropertyChange("segment", null, segment);
  }
  
  public void removeSegment(Segment segment)
  {
    this.segments.remove(segment);
    segment.setBranch(null);
    firePropertyChange("segment", segment, null);
  }
  
  public void clearSegments()
  {
    while (this.segments.size() > 0) {
      removeSegment((Segment)this.segments.get(0));
    }
  }
  
  public PropertyChangeSupport getPropertyChangeSupport()
  {
    return this.propertyChangeSupport;
  }
  
  protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
  {
    if (oldValue == newValue) {
      return;
    }
    this.propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
  {
    this.propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  public Object getClientProperty(Object key)
  {
    if (this.C == null) {
      return null;
    }
    return getClientProperties().get(key);
  }
  
  public Map getClientProperties()
  {
    if (this.C == null) {
      this.C = new LinkedHashMap();
    }
    return this.C;
  }
  
  public void putClientProperty(Object key, Object value)
  {
    Object oldValue = getClientProperties().get(key);
    if (value != null) {
      getClientProperties().put(key, value);
    } else if (oldValue != null) {
      getClientProperties().remove(key);
    }
    String propertyName = "CP:" + key.toString();
    firePropertyChange(propertyName, oldValue, value);
  }
  
  public boolean isVisible()
  {
    return this.B;
  }
  
  public void setVisible(boolean visible)
  {
    boolean oldValue = this.B;
    this.B = visible;
    for (int i = 0; i < this.segments.size(); i++)
    {
      Segment segment = (Segment)this.segments.get(i);
      segment.setVisible(this.B);
    }
    firePropertyChange("visible", oldValue, this.B);
  }
  
  public Color getBranchColor()
  {
    return this.A;
  }
  
  public void setBranchColor(Color branchColor)
  {
    Object oldValue = this.A;
    this.A = branchColor;
    for (int i = 0; i < this.segments.size(); i++)
    {
      Segment segment = (Segment)this.segments.get(i);
      segment.setLineColor(this.A);
    }
    firePropertyChange("branchColor", oldValue, this.A);
  }
  
  public PolyLine getPolyLine()
  {
    return this.D;
  }
  
  void A(PolyLine polyLine)
  {
    this.D = polyLine;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Branch
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.Map;
import twaver.base.A.E.E;

public class Rack
  extends BaseEquipment
{
  public Rack()
  {
    O();
  }
  
  public Rack(Object id)
  {
    super(id);
    O();
  }
  
  private void O()
  {
    setSize(150, 150);
    getClientProperties().put("border.insets", TWaverUtil.valueOf(-2));
  }
  
  public boolean isAdjustToBottom()
  {
    return E.A(this);
  }
  
  public String getUIClassID()
  {
    return "RackUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Rack
 * JD-Core Version:    0.7.0.1
 */
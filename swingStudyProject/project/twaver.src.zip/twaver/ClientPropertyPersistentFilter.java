package twaver;

public abstract interface ClientPropertyPersistentFilter
  extends Filter
{
  public abstract boolean isTransient(Element paramElement, Object paramObject);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ClientPropertyPersistentFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Component;

public abstract interface ComponentCallbackHandler
{
  public abstract void processComponent(Component paramComponent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ComponentCallbackHandler
 * JD-Core Version:    0.7.0.1
 */
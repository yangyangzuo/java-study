package twaver;

import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import twaver.network.background.Background;

public class UndoRedoEvent
{
  public static final int MOVE = 1;
  public static final int RESIZE = 2;
  public static final int LINK_INDEX = 3;
  public static final int LINK_BUNDLE = 4;
  public static final int GROUPEXPAND = 5;
  public static final int PARENTCHANGE = 6;
  public static final int SHAPENODE_MOVE = 7;
  public static final int SHAPENODE_ADD = 8;
  public static final int SHAPENODE_REMOVE = 9;
  public static final int SHAPELINK_MOVE = 10;
  public static final int SHAPELINK_ADD = 11;
  public static final int SHAPELINK_REMOVE = 12;
  public static final int ALARMSTATE = 13;
  public static final int TDATABOX = 14;
  public static final int LAYOUT = 15;
  private final int a;
  private List C;
  private double N;
  private double O;
  private ResizableNode U;
  private Rectangle D;
  private Rectangle H;
  private TDataBox G;
  private String _;
  private Object B;
  private Object W;
  private Link E;
  private Group J;
  private Node L;
  private Node K;
  private Element Q;
  private Element T;
  private Element V;
  private ShapeNode A = null;
  private ShapeLink P = null;
  private int I = -1;
  private Point2D R = null;
  private Point2D Z = null;
  private Point2D S = null;
  private List F = null;
  private AlarmState Y = null;
  private Map X = new HashMap();
  private Map M = new HashMap();
  
  public int getType()
  {
    return this.a;
  }
  
  public UndoRedoEvent(TDataBox box, String propertyName, Object oldValue, Object newValue)
  {
    this.a = 14;
    this.G = box;
    this._ = propertyName;
    this.B = oldValue;
    this.W = newValue;
  }
  
  public UndoRedoEvent(ShapeNode shapeNode, int pointIndex, Point2D oldPoint, Point2D newPoint)
  {
    this.a = 7;
    this.A = shapeNode;
    this.I = pointIndex;
    this.Z = ((Point2D)oldPoint.clone());
    this.S = ((Point2D)newPoint.clone());
  }
  
  public UndoRedoEvent(ShapeNode shapeNode, int pointIndex, Point2D point, boolean added)
  {
    if (added) {
      this.a = 8;
    } else {
      this.a = 9;
    }
    this.A = shapeNode;
    this.I = pointIndex;
    this.R = ((Point2D)point.clone());
  }
  
  public UndoRedoEvent(ShapeLink shapeLink, int pointIndex, Point2D oldPoint, Point2D newPoint)
  {
    this.a = 10;
    this.P = shapeLink;
    this.I = pointIndex;
    this.Z = ((Point2D)oldPoint.clone());
    this.S = ((Point2D)newPoint.clone());
  }
  
  public UndoRedoEvent(ShapeLink shapeLink, int pointIndex, Point2D point, boolean added)
  {
    if (added) {
      this.a = 11;
    } else {
      this.a = 12;
    }
    this.P = shapeLink;
    this.I = pointIndex;
    this.R = ((Point2D)point.clone());
  }
  
  public UndoRedoEvent(Element childElement, Element oldParent, Element newParent)
  {
    this.a = 6;
    this.Q = childElement;
    this.T = oldParent;
    this.V = newParent;
  }
  
  public UndoRedoEvent(List elements, double xOffset, double yOffset)
  {
    this.a = 1;
    this.C = elements;
    this.N = xOffset;
    this.O = yOffset;
  }
  
  public UndoRedoEvent(ResizableNode resizableNode, Rectangle oldBounds, Rectangle newBounds)
  {
    this.a = 2;
    this.U = resizableNode;
    this.D = ((Rectangle)oldBounds.clone());
    this.H = ((Rectangle)newBounds.clone());
  }
  
  public UndoRedoEvent(TDataBox box, Node node1, Node node2)
  {
    this.a = 3;
    this.G = box;
    this.L = node1;
    this.K = node2;
  }
  
  public UndoRedoEvent(Link link)
  {
    this.a = 4;
    this.E = link;
  }
  
  public UndoRedoEvent(Group group)
  {
    this.a = 5;
    this.J = group;
  }
  
  public UndoRedoEvent(List elements, List oldAlarmStates, AlarmState newAlarmState)
  {
    this.a = 13;
    this.C = elements;
    this.F = oldAlarmStates;
    this.Y = newAlarmState;
  }
  
  public UndoRedoEvent(Map oldLocations, Map newLocations)
  {
    this.a = 15;
    this.M = oldLocations;
    this.X = newLocations;
  }
  
  public void undo()
  {
    if (this.a == 1)
    {
      TWaverUtil.moveElements(this.C.iterator(), null, -this.N, -this.O);
    }
    else if (this.a == 2)
    {
      this.U.setLocation(this.D.x, this.D.y);
      this.U.setSize(this.D.width, this.D.height);
    }
    else if (this.a == 3)
    {
      this.G.tagLinkIndex(this.L, this.K);
    }
    else if (this.a == 4)
    {
      this.E.setBundleExpand(!this.E.isLinkBundleExpand());
    }
    else if (this.a == 5)
    {
      this.J.setExpand(!this.J.isExpand());
    }
    else if (this.a == 6)
    {
      this.Q.setParent(this.T);
    }
    else if (this.a == 7)
    {
      this.A.setPoint(this.I, (Point2D)this.Z.clone());
    }
    else if (this.a == 8)
    {
      this.A.removePoint(this.I);
    }
    else if (this.a == 9)
    {
      this.A.insertPoint(this.I, (Point2D)this.R.clone());
    }
    else if (this.a == 10)
    {
      this.P.setPoint(this.I, (Point2D)this.Z.clone());
    }
    else if (this.a == 11)
    {
      this.P.removePoint(this.I);
    }
    else if (this.a == 12)
    {
      this.P.insertPoint(this.I, (Point2D)this.R.clone());
    }
    else if (this.a == 13)
    {
      for (int i = 0; i < this.C.size(); i++)
      {
        Element element = (Element)this.C.get(i);
        AlarmState oldAlarmState = (AlarmState)this.F.get(i);
        element.getAlarmState().copyFrom(oldAlarmState);
      }
    }
    else if (this.a == 14)
    {
      if ("name".equals(this._))
      {
        this.G.setName((String)this.B);
      }
      else if ("background".equals(this._))
      {
        this.G.setBackground((Background)this.B);
      }
      else if (this._.startsWith("CP:"))
      {
        String key = this._.substring("CP:".length());
        this.G.putClientProperty(key, this.B);
      }
    }
    else if (this.a == 15)
    {
      Iterator it = this.M.keySet().iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        Point2D newLocation = (Point2D)this.M.get(element);
        element.setCenterLocation(newLocation.getX(), newLocation.getY());
      }
    }
  }
  
  public void redo()
  {
    if (this.a == 1)
    {
      TWaverUtil.moveElements(this.C.iterator(), null, this.N, this.O);
    }
    else if (this.a == 2)
    {
      this.U.setLocation(this.H.x, this.H.y);
      this.U.setSize(this.H.width, this.H.height);
    }
    else if (this.a == 3)
    {
      this.G.tagLinkIndex(this.L, this.K);
    }
    else if (this.a == 4)
    {
      this.E.setBundleExpand(!this.E.isLinkBundleExpand());
    }
    else if (this.a == 5)
    {
      this.J.setExpand(!this.J.isExpand());
    }
    else if (this.a == 6)
    {
      this.Q.setParent(this.V);
    }
    else if (this.a == 7)
    {
      this.A.setPoint(this.I, (Point2D)this.S.clone());
    }
    else if (this.a == 8)
    {
      this.A.insertPoint(this.I, (Point2D)this.R.clone());
    }
    else if (this.a == 9)
    {
      this.A.removePoint(this.I);
    }
    else if (this.a == 10)
    {
      this.P.setPoint(this.I, (Point2D)this.S.clone());
    }
    else if (this.a == 11)
    {
      this.P.insertPoint(this.I, (Point2D)this.R.clone());
    }
    else if (this.a == 12)
    {
      this.P.removePoint(this.I);
    }
    else if (this.a == 13)
    {
      for (int i = 0; i < this.C.size(); i++)
      {
        Element element = (Element)this.C.get(i);
        element.getAlarmState().copyFrom(this.Y);
      }
    }
    else if (this.a == 14)
    {
      if ("name".equals(this._))
      {
        this.G.setName((String)this.W);
      }
      else if ("background".equals(this._))
      {
        this.G.setBackground((Background)this.W);
      }
      else if (this._.startsWith("CP:"))
      {
        String key = this._.substring("CP:".length());
        this.G.putClientProperty(key, this.W);
      }
    }
    else if (this.a == 15)
    {
      Iterator it = this.X.keySet().iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        Point2D newLocation = (Point2D)this.X.get(element);
        element.setCenterLocation(newLocation.getX(), newLocation.getY());
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.UndoRedoEvent
 * JD-Core Version:    0.7.0.1
 */
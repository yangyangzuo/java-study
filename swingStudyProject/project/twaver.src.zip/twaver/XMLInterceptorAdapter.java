package twaver;

import java.io.InputStream;

public class XMLInterceptorAdapter
  implements XMLInterceptor
{
  public InputStream beforeRead(TDataBox box, InputStream in, Element parentOfRootElement)
  {
    return null;
  }
  
  public void afterRead(TDataBox box, InputStream in, Element parentOfRootElement) {}
  
  public void beforeWrite(TDataBox box, DataBoxOutputSetting setting) {}
  
  public void afterWrite(TDataBox box, DataBoxOutputSetting setting) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.XMLInterceptorAdapter
 * JD-Core Version:    0.7.0.1
 */
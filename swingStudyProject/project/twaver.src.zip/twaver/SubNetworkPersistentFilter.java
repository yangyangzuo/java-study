package twaver;

public class SubNetworkPersistentFilter
  implements ElementPersistentFilter
{
  private TSubNetwork B = null;
  
  public SubNetworkPersistentFilter(TSubNetwork subNetwork)
  {
    this.B = subNetwork;
  }
  
  public boolean isTransient(Element element)
  {
    if (((element instanceof Link)) && (!(element instanceof PolyLine)))
    {
      Node from = ((Link)element).getFrom();
      if ((from == null) || (TWaverUtil.getElementSubNetwork(from) != this.B)) {
        return true;
      }
      Node to = ((Link)element).getTo();
      return (to == null) || (TWaverUtil.getElementSubNetwork(to) != this.B);
    }
    TSubNetwork sn = TWaverUtil.getElementSubNetwork(element);
    return sn != this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SubNetworkPersistentFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public class DataBoxSequenceAdapter
  implements DataBoxSequenceListener
{
  public void indexChanged(Element element) {}
  
  public void hiberarchyChanged(Element element) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSequenceAdapter
 * JD-Core Version:    0.7.0.1
 */
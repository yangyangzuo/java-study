package twaver;

public abstract interface ChildrenSortableFilter
  extends Filter
{
  public abstract boolean isChildrenSortable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ChildrenSortableFilter
 * JD-Core Version:    0.7.0.1
 */
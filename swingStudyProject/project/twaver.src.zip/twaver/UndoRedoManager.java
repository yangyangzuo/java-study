package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class UndoRedoManager
{
  private int C = -1;
  private TDataBox F = null;
  private boolean G = true;
  private boolean D = false;
  private int H = -1;
  private LinkedList L = new LinkedList();
  private List K = new ArrayList();
  private UndoRedoInterceptor I = new DefaultUndoRedoInterceptor(this);
  private int E = 0;
  private PropertyChangeListener J = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent event)
    {
      UndoRedoManager.this.addEvent(new UndoRedoEvent(UndoRedoManager.this.F, event.getPropertyName(), event.getOldValue(), event.getNewValue()));
    }
  };
  private PropertyChangeListener B = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent event)
    {
      UndoRedoManager.this.addEvent(event);
    }
  };
  private DataBoxListener A = new DataBoxListener()
  {
    public void elementAdded(DataBoxEvent e)
    {
      UndoRedoManager.this.addEvent(e);
    }
    
    public void elementRemoved(DataBoxEvent e)
    {
      UndoRedoManager.this.addEvent(e);
    }
    
    public void elementsCleared(DataBoxEvent e)
    {
      UndoRedoManager.this.addEvent(e);
    }
  };
  
  public boolean isIgnorePropertyChange()
  {
    return this.E != 0;
  }
  
  public void setIgnorePropertyChange(boolean ignorePropertyChange)
  {
    if (ignorePropertyChange) {
      this.E += 1;
    } else {
      this.E -= 1;
    }
  }
  
  UndoRedoManager(TDataBox box)
  {
    this.F = box;
  }
  
  public TDataBox getDataBox()
  {
    return this.F;
  }
  
  public void addUndoRedoListener(UndoRedoListener l)
  {
    if ((l != null) && (!this.K.contains(l))) {
      this.K.add(l);
    }
  }
  
  public void removeUndoRedoListener(UndoRedoListener l)
  {
    this.K.remove(l);
  }
  
  public List getUndoRedoListeners()
  {
    return new ArrayList(this.K);
  }
  
  public void reset()
  {
    this.L.clear();
    this.H = -1;
    for (int i = 0; i < this.K.size(); i++)
    {
      UndoRedoListener l = (UndoRedoListener)this.K.get(i);
      l.reset();
    }
  }
  
  public boolean canUndo()
  {
    return this.H >= 0;
  }
  
  public boolean canRedo()
  {
    return this.H < this.L.size() - 1;
  }
  
  public void undo()
  {
    if (!canUndo()) {
      return;
    }
    Object event = this.L.get(this.H--);
    this.D = true;
    this.I.undo(this.F, event);
    this.D = false;
    for (int i = 0; i < this.K.size(); i++)
    {
      UndoRedoListener l = (UndoRedoListener)this.K.get(i);
      l.undid(event);
    }
  }
  
  public void redo()
  {
    if (!canRedo()) {
      return;
    }
    Object event = this.L.get(++this.H);
    this.D = true;
    this.I.redo(this.F, event);
    this.D = false;
    for (int i = 0; i < this.K.size(); i++)
    {
      UndoRedoListener l = (UndoRedoListener)this.K.get(i);
      l.redid(event);
    }
  }
  
  public void addEvent(Object event)
  {
    if ((!this.G) || (this.C <= 0) || (this.D)) {
      return;
    }
    if ((event instanceof PropertyChangeEvent))
    {
      PropertyChangeEvent e = (PropertyChangeEvent)event;
      if (isIgnorePropertyChange()) {
        return;
      }
      if (this.I.isInterested(e)) {}
    }
    else if ((event instanceof DataBoxEvent))
    {
      DataBoxEvent e = (DataBoxEvent)event;
      if (!this.I.isInterested(e)) {
        return;
      }
    }
    while (canRedo()) {
      this.L.removeLast();
    }
    this.L.addLast(event);
    this.H = (this.L.size() - 1);
    for (int i = 0; i < this.K.size(); i++)
    {
      UndoRedoListener l = (UndoRedoListener)this.K.get(i);
      l.eventAdded(event);
    }
    A();
  }
  
  private void A()
  {
    while ((this.L.size() > 0) && (this.L.size() > this.C))
    {
      Object event = this.L.removeFirst();
      this.H -= 1;
      for (int i = 0; i < this.K.size(); i++)
      {
        UndoRedoListener l = (UndoRedoListener)this.K.get(i);
        l.eventRemoved(event);
      }
    }
  }
  
  public int getLimit()
  {
    return this.C;
  }
  
  public void setLimit(int limit)
  {
    if (this.C == limit) {
      return;
    }
    int oldValue = this.C;
    this.C = limit;
    A();
    if ((oldValue > 0) && (this.C <= 0))
    {
      this.F.removeElementPropertyChangeListener(this.B);
      this.F.getPropertyChangeSupport().removePropertyChangeListener(this.J);
      this.F.removeDataBoxListener(this.A);
    }
    else if ((oldValue <= 0) && (this.C > 0))
    {
      this.F.addElementPropertyChangeListener(this.B);
      this.F.getPropertyChangeSupport().addPropertyChangeListener(this.J);
      this.F.addDataBoxListener(this.A);
    }
  }
  
  public LinkedList getEvents()
  {
    return this.L;
  }
  
  public int getPosition()
  {
    return this.H;
  }
  
  public UndoRedoInterceptor getInterceptor()
  {
    return this.I;
  }
  
  public void setInterceptor(UndoRedoInterceptor interceptor)
  {
    if (interceptor == null) {
      throw new NullPointerException("UndoRedoInterceptor can not be Null");
    }
    this.I = interceptor;
  }
  
  public boolean isUndoRedoing()
  {
    return this.D;
  }
  
  public boolean isEnable()
  {
    return this.G;
  }
  
  public void setEnable(boolean enable)
  {
    this.G = enable;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.UndoRedoManager
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface Filter {}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Filter
 * JD-Core Version:    0.7.0.1
 */
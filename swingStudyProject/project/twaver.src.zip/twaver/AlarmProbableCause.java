package twaver;

import twaver.base.enumerable.AbstractEnumerable;

public final class AlarmProbableCause
  extends AbstractEnumerable
{
  public static final AlarmProbableCause INDETERMINATE = new AlarmProbableCause("Indeterminate", 0);
  public static final AlarmProbableCause ALARM_INDICATION_SIGNAL = new AlarmProbableCause("Alarm indication signal", 1);
  public static final AlarmProbableCause CALL_SETUP_FAILURE = new AlarmProbableCause("Call setup failure", 2);
  public static final AlarmProbableCause DEGRADED_SIGNAL_M3100 = new AlarmProbableCause("Degraded signal M.3100", 3);
  public static final AlarmProbableCause FAR_END_RECEIVER_FAILURE = new AlarmProbableCause("Far end receiver failure", 4);
  public static final AlarmProbableCause FRAMING_ERROR_M3100 = new AlarmProbableCause("Framing error M.3100", 5);
  public static final AlarmProbableCause LOSS_OF_FRAME = new AlarmProbableCause("Loss of frame", 6);
  public static final AlarmProbableCause LOSS_OF_POINTER = new AlarmProbableCause("Loss of pointer", 7);
  public static final AlarmProbableCause LOSS_OF_SIGNAL = new AlarmProbableCause("Loss of signal", 8);
  public static final AlarmProbableCause PAYLOAD_TYPE_MISMATCH = new AlarmProbableCause("Payload type mismatch", 9);
  public static final AlarmProbableCause TRANSMISSION_ERROR = new AlarmProbableCause("Transmission error", 10);
  public static final AlarmProbableCause REMOTE_ALARM_INTERFACE = new AlarmProbableCause("Remote alarm interface", 11);
  public static final AlarmProbableCause EXCESSIVE_BIT_ERROR_RATE = new AlarmProbableCause("Excessive bit error rate", 12);
  public static final AlarmProbableCause PATH_TRACE_MISMATCH = new AlarmProbableCause("Path trace mismatch", 13);
  public static final AlarmProbableCause UNAVAILABLE = new AlarmProbableCause("Unavailable", 14);
  public static final AlarmProbableCause SIGNAL_LABEL_MISMATCH = new AlarmProbableCause("Siganl label mismatch", 15);
  public static final AlarmProbableCause LOSS_OF_MULTI_FRAME = new AlarmProbableCause("Loss of multi frame", 16);
  public static final AlarmProbableCause BACK_PLANE_FAILURE = new AlarmProbableCause("Back plane failure", 51);
  public static final AlarmProbableCause DATA_SET_PROBLEM = new AlarmProbableCause("Data set problem", 52);
  public static final AlarmProbableCause EQUIPMENT_IDENTIFIER_DUPLICATION = new AlarmProbableCause("Equipment identifier duplication", 53);
  public static final AlarmProbableCause EXTERNAL_DEVICE_PROBLEM = new AlarmProbableCause("External device problem", 54);
  public static final AlarmProbableCause LINE_CARD_PROBLEM = new AlarmProbableCause("Line card problem", 55);
  public static final AlarmProbableCause MULTIPLEXER_PROBLEM_M3100 = new AlarmProbableCause("Multiplexer problem M.3100", 56);
  public static final AlarmProbableCause NE_IDENTIFIER_DUPLICATION = new AlarmProbableCause("NE identifier duplication", 57);
  public static final AlarmProbableCause POWER_PROBLEM_M3100 = new AlarmProbableCause("Power problem M.3100", 58);
  public static final AlarmProbableCause PROCESSOR_PROBLEM_M3100 = new AlarmProbableCause("Processor problem M.3100", 59);
  public static final AlarmProbableCause PROTECTION_PATH_FAILURE = new AlarmProbableCause("Protection path failure", 60);
  public static final AlarmProbableCause RECEIVER_FAILURE_M3100 = new AlarmProbableCause("Receiver failure M.3100", 61);
  public static final AlarmProbableCause REPLACEABLE_UNIT_MISSING = new AlarmProbableCause("Replaceable unit missing", 62);
  public static final AlarmProbableCause REPLACEABLE_UNIT_TYPE_MISMATCH = new AlarmProbableCause("Replaceable unit type mismatch", 63);
  public static final AlarmProbableCause SYNCHRONISATION_SOURCE_MISMATCH = new AlarmProbableCause("Synchronisation source mismatch", 64);
  public static final AlarmProbableCause TERMINAL_PROBLEM = new AlarmProbableCause("Terminal problem", 65);
  public static final AlarmProbableCause TIMING_PROBLEM_M3100 = new AlarmProbableCause("Timing problem M.3100", 66);
  public static final AlarmProbableCause TRANSMITTER_FAILURE_M3100 = new AlarmProbableCause("Transmitter failure M.3100", 67);
  public static final AlarmProbableCause TRUNK_CARD_PROBLEM = new AlarmProbableCause("Trunk card problem", 68);
  public static final AlarmProbableCause REPLACEABLE_UNIT_PROBLEM = new AlarmProbableCause("Replaceable unit problem", 69);
  public static final AlarmProbableCause AIR_COMPRESSOR_FAILURE = new AlarmProbableCause("Air compressor failure", 101);
  public static final AlarmProbableCause AIR_CONDITIONING_FAILURE = new AlarmProbableCause("Air conditioning failure", 102);
  public static final AlarmProbableCause AIR_DRYER_FAILURE = new AlarmProbableCause("Air dryer failure", 103);
  public static final AlarmProbableCause BATTERY_DISCHARGING = new AlarmProbableCause("Battery discharging", 104);
  public static final AlarmProbableCause BATTERY_FAILURE = new AlarmProbableCause("Battery failure", 105);
  public static final AlarmProbableCause COMMERICAL_POWER_FAILURE = new AlarmProbableCause("Commercial power failure", 106);
  public static final AlarmProbableCause COOLING_FAN_FAILURE = new AlarmProbableCause("Cooling fan failure", 107);
  public static final AlarmProbableCause ENGINE_FAILURE = new AlarmProbableCause("Engine failure", 108);
  public static final AlarmProbableCause FIRE_DETECTOR_FAILURE = new AlarmProbableCause("Fire detector failure", 109);
  public static final AlarmProbableCause FUSE_FAILURE = new AlarmProbableCause("Fuse failure", 110);
  public static final AlarmProbableCause GENERATOR_FAILURE = new AlarmProbableCause("Generator failure", 111);
  public static final AlarmProbableCause LOW_BATTERY_THRESHOLD = new AlarmProbableCause("Low battery threshold", 112);
  public static final AlarmProbableCause PUMP_FAILURE_M3100 = new AlarmProbableCause("Pump failure M.3100", 113);
  public static final AlarmProbableCause RECTIFIER_FAILURE = new AlarmProbableCause("Rectifier failure", 114);
  public static final AlarmProbableCause RECTIFIER_HIGH_VOLTAGE = new AlarmProbableCause("Rectifier high voltage", 115);
  public static final AlarmProbableCause RECTIFIER_LOW_F_VOLTAGE = new AlarmProbableCause("Rectifier low F voltage", 116);
  public static final AlarmProbableCause VENTILATION_SYSTEM_FAILURE = new AlarmProbableCause("Ventilation system failure", 117);
  public static final AlarmProbableCause ENCLOSURE_DOOR_OPEN_M3100 = new AlarmProbableCause("Enclosure door open M.3100", 118);
  public static final AlarmProbableCause EXPLOSIVE_GAS = new AlarmProbableCause("Explosive gas", 119);
  public static final AlarmProbableCause FIRE = new AlarmProbableCause("Fire", 120);
  public static final AlarmProbableCause FLOOD = new AlarmProbableCause("Flood", 121);
  public static final AlarmProbableCause HIGH_HUMIDITY = new AlarmProbableCause("High humidity", 122);
  public static final AlarmProbableCause HIGH_TEMPERATURE = new AlarmProbableCause("High temperature", 123);
  public static final AlarmProbableCause HIGH_WIND = new AlarmProbableCause("High wind", 124);
  public static final AlarmProbableCause ICE_BUILD_UP = new AlarmProbableCause("Ice build up", 125);
  public static final AlarmProbableCause LOW_FUEL = new AlarmProbableCause("Low fuel", 127);
  public static final AlarmProbableCause LOW_HUMIDITY = new AlarmProbableCause("Low humidity", 128);
  public static final AlarmProbableCause LOW_CABLE_PRESSURE = new AlarmProbableCause("Low cable pressure", 129);
  public static final AlarmProbableCause LOW_TEMPERATURE = new AlarmProbableCause("Low temperature", 130);
  public static final AlarmProbableCause LOW_WATER = new AlarmProbableCause("Low water", 131);
  public static final AlarmProbableCause SMOKE = new AlarmProbableCause("Smoke", 132);
  public static final AlarmProbableCause TOXIC_GAS = new AlarmProbableCause("Toxic gas", 133);
  public static final AlarmProbableCause STORAGE_CAPACITY_PROBLEM_M3100 = new AlarmProbableCause("Storage capacity problem M.3100", 151);
  public static final AlarmProbableCause MEMORY_MISMATCH = new AlarmProbableCause("Memory mismatch", 152);
  public static final AlarmProbableCause CORRUPT_DATA_M3100 = new AlarmProbableCause("Corrupt data M.3100", 153);
  public static final AlarmProbableCause OUT_OF_CPU_CYCLES = new AlarmProbableCause("Out of CPU cycles", 154);
  public static final AlarmProbableCause SOFTWARE_ENVIRONMENT_PROBLEM = new AlarmProbableCause("Software environment problem", 155);
  public static final AlarmProbableCause SOFTWARE_DOWNLOAD_FAILURE = new AlarmProbableCause("Software download failure", 156);
  public static final AlarmProbableCause ADAPTER_ERROR = new AlarmProbableCause("Adapter error", 301);
  public static final AlarmProbableCause APPLICATION_SUBSYSTEM_FAILURE = new AlarmProbableCause("Application subsystem failure", 302);
  public static final AlarmProbableCause BANDWIDTH_REDUCTION = new AlarmProbableCause("Bandwidth reduction", 303);
  public static final AlarmProbableCause COMMUNICATION_PROTOCOL_ERROR = new AlarmProbableCause("Communication protocol error", 305);
  public static final AlarmProbableCause COMMUNICATION_SUBSYSTEM_FAILURE = new AlarmProbableCause("Communication subsystem failure", 306);
  public static final AlarmProbableCause CONFIGURATION_OR_CUSTOMIZING_ERROR = new AlarmProbableCause("Configration or customizing error", 307);
  public static final AlarmProbableCause CONGESTION = new AlarmProbableCause("Congestion", 308);
  public static final AlarmProbableCause CPU_CYCLES_LIMIT_EXCEEDED = new AlarmProbableCause("CPU cycles limit exceeded", 310);
  public static final AlarmProbableCause DATA_SET_OR_MODEM_ERROR = new AlarmProbableCause("Data set or modem error", 311);
  public static final AlarmProbableCause DTE_DCE_INTERFACE_ERROR = new AlarmProbableCause("DTE DCE interface error", 313);
  public static final AlarmProbableCause EQUIPMENT_MALFUNCTION = new AlarmProbableCause("Equipment malfunction", 315);
  public static final AlarmProbableCause EXCESSIVE_VIBRATION = new AlarmProbableCause("Excessive vibration", 316);
  public static final AlarmProbableCause FILE_ERROR = new AlarmProbableCause("File error", 317);
  public static final AlarmProbableCause HEATING_OR_VENTILATION_OR_COOLING_SYSTEM_PROBLEM = new AlarmProbableCause("Heating or ventilation or cooling system problem", 321);
  public static final AlarmProbableCause HUMIDITY_UNACCEPTABLE = new AlarmProbableCause("Humidity unacceptable", 322);
  public static final AlarmProbableCause INPUT_OUTPUT_DEVICE_ERROR = new AlarmProbableCause("Input/output device error", 323);
  public static final AlarmProbableCause INPUT_DEVICE_ERROR = new AlarmProbableCause("Input device error", 324);
  public static final AlarmProbableCause LAN_ERROR = new AlarmProbableCause("LAN error", 325);
  public static final AlarmProbableCause LEAK_DETECTION = new AlarmProbableCause("Leak detection", 326);
  public static final AlarmProbableCause LOCAL_NODE_TRANSMISSION_ERROR = new AlarmProbableCause("Local node transmission error", 327);
  public static final AlarmProbableCause MATERIAL_SUPPLY_EXHAUSTED = new AlarmProbableCause("Material supply exhausted", 330);
  public static final AlarmProbableCause OUT_OF_MEMORY = new AlarmProbableCause("Out of memory", 332);
  public static final AlarmProbableCause OUTPUT_DEVICE_ERROR = new AlarmProbableCause("Output device error", 333);
  public static final AlarmProbableCause PERFORMANCE_DEGRADED = new AlarmProbableCause("Performance degraded", 334);
  public static final AlarmProbableCause PRESSURE_UNACCEPTABLE = new AlarmProbableCause("Pressure unacceptable", 336);
  public static final AlarmProbableCause QUEUE_SIZE_EXCEEDED = new AlarmProbableCause("Queue size exceeded", 339);
  public static final AlarmProbableCause RECEIVE_FAILURE = new AlarmProbableCause("Receive failure", 340);
  public static final AlarmProbableCause REMOTE_NODE_TRANSMISSION_ERROR = new AlarmProbableCause("Remote node transmission error", 342);
  public static final AlarmProbableCause RESOURCE_AT_OR_NEARING_CAPACITY = new AlarmProbableCause("Resource at or nearing capacity", 343);
  public static final AlarmProbableCause RESPONSE_TIME_EXCESSIVE = new AlarmProbableCause("Response time excessive", 344);
  public static final AlarmProbableCause RETRANSMISSION_RATE_EXCESSIVE = new AlarmProbableCause("Retransmission rate excessive", 345);
  public static final AlarmProbableCause SOFTWARE_ERROR = new AlarmProbableCause("Software error", 346);
  public static final AlarmProbableCause SOFTWARE_PROGRAM_ABNORMALLY_TERMINATED = new AlarmProbableCause("Software program abnormality terminated", 347);
  public static final AlarmProbableCause SOFTWARE_PROGRAM_ERROR = new AlarmProbableCause("Software program error", 348);
  public static final AlarmProbableCause TEMPERATURE_UNACCEPTABLE = new AlarmProbableCause("Temperature unacceptable", 350);
  public static final AlarmProbableCause THRESHOLD_CROSSED = new AlarmProbableCause("Threshold crossed", 351);
  public static final AlarmProbableCause TOXIC_LEAK_DETECTED = new AlarmProbableCause("Toxic leak detected", 353);
  public static final AlarmProbableCause TRANSMIT_FAILURE = new AlarmProbableCause("Transmit failure", 354);
  public static final AlarmProbableCause UNDERLYING_RESOURCE_UNAVAILABLE = new AlarmProbableCause("Underlying resource unavailable", 356);
  public static final AlarmProbableCause VERSION_MISMATCH = new AlarmProbableCause("Version mismatch", 357);
  public static final AlarmProbableCause A_BIS_TO_BTS_INTERFACE_FAILURE = new AlarmProbableCause("A-bis to BTS interface failure", 501);
  public static final AlarmProbableCause A_BIS_TO_TRX_INTERFACE_FAILURE = new AlarmProbableCause("A-bis to TRX interface failure", 502);
  public static final AlarmProbableCause ANTENNA_PROBLEM = new AlarmProbableCause("Antenna problem", 503);
  public static final AlarmProbableCause BATTERY_BREAKDOWN = new AlarmProbableCause("Battery breakdown", 504);
  public static final AlarmProbableCause BATTERY_CHARGING_FAULT = new AlarmProbableCause("Battery charging fault", 505);
  public static final AlarmProbableCause CLOCK_SYNCHRONISATION_PROBLEM = new AlarmProbableCause("Clock synchronisation problem", 506);
  public static final AlarmProbableCause COMBINER_PROBLEM = new AlarmProbableCause("Combiner problem", 507);
  public static final AlarmProbableCause DISK_PROBLEM = new AlarmProbableCause("Disk problem", 508);
  public static final AlarmProbableCause EXCESSIVE_RECEIVER_TEMPERATURE = new AlarmProbableCause("Excessive receiver temperature", 510);
  public static final AlarmProbableCause EXCESSIVE_TRANSMITTER_OUTPUT_POWER = new AlarmProbableCause("Excessive transmitter output power", 511);
  public static final AlarmProbableCause EXCESSIVE_TRANSMITTER_TEMPERATURE = new AlarmProbableCause("Excessive transmitter temperature", 512);
  public static final AlarmProbableCause FREQUENCY_HOPPING_DEGRADED = new AlarmProbableCause("Frequency hopping degraded", 513);
  public static final AlarmProbableCause FREQUENCY_HOPPING_FAILURE = new AlarmProbableCause("Frequency hopping failure", 514);
  public static final AlarmProbableCause FREQUENCY_REDEFINITION_FAILED = new AlarmProbableCause("Frequency redefinition failed", 515);
  public static final AlarmProbableCause LINE_INTERFACE_FAILURE = new AlarmProbableCause("Line interface failure", 516);
  public static final AlarmProbableCause LINK_FAILURE = new AlarmProbableCause("Link failure", 517);
  public static final AlarmProbableCause LOSS_OF_SYNCHRONISATION = new AlarmProbableCause("Loss of synchronisation", 518);
  public static final AlarmProbableCause LOST_REDUNDANCY = new AlarmProbableCause("Lost redundancy", 519);
  public static final AlarmProbableCause MAINS_BREAKDOWN_WITH_BATTERY_BACKUP = new AlarmProbableCause("Mains breakdown with battery backup", 520);
  public static final AlarmProbableCause MAINS_BREAKDOWN_WITHOUT_BATTERY_BACKUP = new AlarmProbableCause("Mains breakdown without battery backup", 521);
  public static final AlarmProbableCause POWER_SUPPLY_FAILURE = new AlarmProbableCause("Power supply failure", 522);
  public static final AlarmProbableCause RECEIVER_ANTENNA_FAULT = new AlarmProbableCause("Receiver antenna fault", 523);
  public static final AlarmProbableCause RECEIVER_MULTICOUPLER_FAILURE = new AlarmProbableCause("Receiver multicoupler failure", 525);
  public static final AlarmProbableCause REDUCED_TRANSMITTER_OUTPUT_POWER = new AlarmProbableCause("Reduced transmitter output power", 526);
  public static final AlarmProbableCause SIGNAL_QUALITY_EVALUATION_FAULT = new AlarmProbableCause("Signal quality evaluation fault", 527);
  public static final AlarmProbableCause TIMESLOT_HARDWARE_FAILURE = new AlarmProbableCause("Timeslot hardware failure", 528);
  public static final AlarmProbableCause TRANSCEIVER_PROBLEM = new AlarmProbableCause("Tranceiver problem", 529);
  public static final AlarmProbableCause TRANSCODER_PROBLEM = new AlarmProbableCause("Transcoder problem", 530);
  public static final AlarmProbableCause TRANSCODER_OR_RATE_ADAPTER_PROBLEM = new AlarmProbableCause("Transcoder or rate adapter problem", 531);
  public static final AlarmProbableCause TRANSMITTER_ANTENNA_FAILURE = new AlarmProbableCause("Transmitter antenna failure", 532);
  public static final AlarmProbableCause TRANSMITTER_ANTENNA_NOT_ADJUSTED = new AlarmProbableCause("Transmitter antenna not adjusted", 533);
  public static final AlarmProbableCause TRANSMITTER_LOW_VOLTAGE_OR_CURRENT = new AlarmProbableCause("Transmitter low voltage or current", 535);
  public static final AlarmProbableCause TRANSMITTER_OFF_FREQUENCY = new AlarmProbableCause("Transmitter off frequency", 536);
  public static final AlarmProbableCause DATABASE_INCONSISTENCY = new AlarmProbableCause("Database inconsistency", 537);
  public static final AlarmProbableCause FILE_SYSTEM_CALL_UNSUCCESSFUL = new AlarmProbableCause("File system call unsuccessful", 538);
  public static final AlarmProbableCause INPUT_PARAMETER_OUT_OF_RANGE = new AlarmProbableCause("Input parameter out of range", 539);
  public static final AlarmProbableCause INVALID_PARAMETER = new AlarmProbableCause("Invalid parameter", 540);
  public static final AlarmProbableCause INVALID_POINTER = new AlarmProbableCause("Invalid pointer", 541);
  public static final AlarmProbableCause MESSAGE_NOT_EXPECTED = new AlarmProbableCause("Message not excepted", 542);
  public static final AlarmProbableCause MESSAGE_NOT_INITIALISED = new AlarmProbableCause("Message not initialized", 543);
  public static final AlarmProbableCause MESSAGE_OUT_OF_SEQUENCE = new AlarmProbableCause("Message out of sequence", 544);
  public static final AlarmProbableCause SYSTEM_CALL_UNSUCCESSFUL = new AlarmProbableCause("System call unsuccessful", 545);
  public static final AlarmProbableCause TIMEOUT_EXPIRED = new AlarmProbableCause("Timeout expired", 546);
  public static final AlarmProbableCause VARIABLE_OUT_OF_RANGE = new AlarmProbableCause("Variable out of range", 547);
  public static final AlarmProbableCause WATCH_DOG_TIMER_EXPIRED = new AlarmProbableCause("Watch dog timer expired", 548);
  public static final AlarmProbableCause COOLING_SYSTEM_FAILURE = new AlarmProbableCause("Cooling system failure", 549);
  public static final AlarmProbableCause EXTERNAL_EQUIPMENT_FAILURE = new AlarmProbableCause("External equipment failure", 550);
  public static final AlarmProbableCause EXTERNAL_POWER_SUPPLY_FAILURE = new AlarmProbableCause("External power supply failure", 551);
  public static final AlarmProbableCause EXTERNAL_TRANSMISSION_DEVICE_FAILURE = new AlarmProbableCause("External transmission device failure", 552);
  public static final AlarmProbableCause REDUCED_ALARM_REPORTING = new AlarmProbableCause("Reduced alarm reporting", 561);
  public static final AlarmProbableCause REDUCED_EVENT_REPORTING = new AlarmProbableCause("Reduced event reporting", 562);
  public static final AlarmProbableCause RECUCED_LOGGING_CAPABILITY = new AlarmProbableCause("Reduced logging capability", 563);
  public static final AlarmProbableCause SYSTEM_RESOURCES_OVERLOAD = new AlarmProbableCause("System resources overload", 564);
  public static final AlarmProbableCause BROADCAST_CHANNEL_FAILURE = new AlarmProbableCause("Broadcast channel failure", 565);
  public static final AlarmProbableCause CALL_ESTABLISHMENT_ERROR = new AlarmProbableCause("Call establishment error", 566);
  public static final AlarmProbableCause INVALID_MESSAGE_RECEIVED = new AlarmProbableCause("Invalid message received", 567);
  public static final AlarmProbableCause INVALID_MSU_RECEIVED = new AlarmProbableCause("Invalid MSU received", 568);
  public static final AlarmProbableCause LAPD_LINK_PROTOCOL_FAILURE = new AlarmProbableCause("LAPD link protocol failure", 569);
  public static final AlarmProbableCause LOCAL_ALARM_INDICATION = new AlarmProbableCause("Local alarm indication", 570);
  public static final AlarmProbableCause REMOTE_ALARM_INDICATION = new AlarmProbableCause("Remote alarm indication", 571);
  public static final AlarmProbableCause ROUTING_FAILURE = new AlarmProbableCause("Routing failure", 572);
  public static final AlarmProbableCause SS7_PROTOCOL_FAILURE = new AlarmProbableCause("SS7 protocol failure", 573);
  public static final AlarmProbableCause TRANSMISSION_FAILURE = new AlarmProbableCause("Transmission failure", 574);
  private int B;
  
  private AlarmProbableCause(String name, int value)
  {
    super(name);
    this.B = value;
  }
  
  public int getValue()
  {
    return this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmProbableCause
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public class DataBoxParserAgent
{
  private static ThreadLocal A = new ThreadLocal();
  
  public static void setDataBox(TDataBox box)
  {
    A.set(box);
  }
  
  public static TDataBox getDataBox()
  {
    return (TDataBox)A.get();
  }
  
  public static Element getElementByID(Object id)
  {
    TDataBox box = (TDataBox)A.get();
    if (box != null) {
      return box.getElementByID(id);
    }
    return null;
  }
  
  public static void removeElementByID(Object id)
  {
    TDataBox box = (TDataBox)A.get();
    if (box != null) {
      box.removeElementByID(id);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxParserAgent
 * JD-Core Version:    0.7.0.1
 */
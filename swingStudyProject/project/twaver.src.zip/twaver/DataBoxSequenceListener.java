package twaver;

import java.util.EventListener;

public abstract interface DataBoxSequenceListener
  extends EventListener
{
  public abstract void indexChanged(Element paramElement);
  
  public abstract void hiberarchyChanged(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSequenceListener
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.geom.Point2D;
import java.beans.PropertyChangeEvent;
import twaver.network.background.Background;

public class DefaultUndoRedoInterceptor
  implements UndoRedoInterceptor
{
  protected UndoRedoManager undoRedoManager = null;
  
  public DefaultUndoRedoInterceptor(UndoRedoManager undoRedoManager)
  {
    this.undoRedoManager = undoRedoManager;
  }
  
  public void undo(TDataBox box, Object event)
  {
    if ((event instanceof PropertyChangeEvent))
    {
      PropertyChangeEvent e = (PropertyChangeEvent)event;
      undoPropertyChange((Element)e.getSource(), e.getPropertyName(), e.getOldValue());
    }
    else if ((event instanceof DataBoxEvent))
    {
      DataBoxEvent e = (DataBoxEvent)event;
      int type = e.getType();
      Element element = e.getElement();
      if (type == 1) {
        box.removeElement(element);
      } else if (type == 2) {
        A(box, element, e);
      }
    }
    else if ((event instanceof UndoRedoEvent))
    {
      UndoRedoEvent undoRedoEvent = (UndoRedoEvent)event;
      undoRedoEvent.undo();
    }
  }
  
  private void A(TDataBox box, Element element, DataBoxEvent e)
  {
    if ((element instanceof Link))
    {
      Link link = (Link)element;
      if ((link.getFrom() == null) || (link.getTo() == null))
      {
        link.setFrom(e.getFrom());
        link.setTo(e.getTo());
      }
    }
    if (e.getParent() != null) {
      element.setParent(e.getParent());
    }
    if ((e.getHost() != null) && ((element instanceof Follower))) {
      ((Follower)element).setHost(e.getHost());
    }
    if ((e.getBTS() != null) && ((element instanceof BTSAntenna))) {
      ((BTSAntenna)element).setBTS(e.getBTS());
    }
    box.addElement(element);
  }
  
  public void redo(TDataBox box, Object event)
  {
    if ((event instanceof PropertyChangeEvent))
    {
      PropertyChangeEvent e = (PropertyChangeEvent)event;
      undoPropertyChange((Element)e.getSource(), e.getPropertyName(), e.getNewValue());
    }
    else if ((event instanceof DataBoxEvent))
    {
      DataBoxEvent e = (DataBoxEvent)event;
      int type = e.getType();
      Element element = e.getElement();
      if (type == 1) {
        A(box, element, e);
      } else if (type == 2) {
        box.removeElement(element);
      }
    }
    else if ((event instanceof UndoRedoEvent))
    {
      UndoRedoEvent undoRedoEvent = (UndoRedoEvent)event;
      undoRedoEvent.redo();
    }
  }
  
  public boolean isInterested(DataBoxEvent event)
  {
    if (event.getType() == 3)
    {
      this.undoRedoManager.reset();
      return false;
    }
    return true;
  }
  
  public boolean isInterested(PropertyChangeEvent event)
  {
    PropertyChangeEvent e = event;
    String propertyName = e.getPropertyName();
    Element element = (Element)e.getSource();
    return handlerable(propertyName, element, e.getOldValue(), e.getNewValue());
  }
  
  private boolean A(Element element)
  {
    return ((element instanceof ResizableNode)) && (!(element instanceof Group)) && (!(element instanceof BTSAntenna));
  }
  
  protected boolean handlerable(String name, Element element, Object oldValue, Object newValue)
  {
    if (name.startsWith("CP:"))
    {
      name = name.substring("CP:".length());
      return TUIManager.isPredefinedClientPropertyKey(name);
    }
    if ("layerID".equals(name)) {
      return true;
    }
    if ("icon".equals(name)) {
      return true;
    }
    if ("image".equals(name)) {
      return true;
    }
    if ("name".equals(name)) {
      return true;
    }
    if ("displayName".equals(name)) {
      return true;
    }
    if ("enableAlarmPropagationFromChildren".equals(name)) {
      return true;
    }
    if ("parent".equals(name)) {
      return true;
    }
    if ("userObject".equals(name)) {
      return true;
    }
    if ("toolTipText".equals(name)) {
      return true;
    }
    if ("visible".equals(name)) {
      return true;
    }
    if ("location".equals(name)) {
      return true;
    }
    if (("width".equals(name)) && (A(element))) {
      return true;
    }
    if (("height".equals(name)) && (A(element))) {
      return true;
    }
    if (("size".equals(name)) && (A(element))) {
      return true;
    }
    if (("host".equals(name)) && ((element instanceof Follower))) {
      return true;
    }
    if (("exist".equals(name)) && ((element instanceof Equipment))) {
      return true;
    }
    if (("tag".equals(name)) && ((element instanceof Equipment))) {
      return true;
    }
    if (("from".equals(name)) && ((element instanceof Link))) {
      return (newValue != null) && (oldValue != null);
    }
    if (("to".equals(name)) && ((element instanceof Link))) {
      return (newValue != null) && (oldValue != null);
    }
    if (("linkType".equals(name)) && ((element instanceof Link))) {
      return true;
    }
    if (("expand".equals(name)) && ((element instanceof Group))) {
      return true;
    }
    if (("groupType".equals(name)) && ((element instanceof Group))) {
      return true;
    }
    if (("shapeNodeType".equals(name)) && ((element instanceof ShapeNode))) {
      return true;
    }
    if (("power".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("beamDirection".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("beamWidth".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("beamAlpha".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("antennaType".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("BTS".equals(name)) && ((element instanceof BTSAntenna))) {
      return true;
    }
    if (("blinkingObject".equals(name)) && ((element instanceof PolyLine))) {
      return true;
    }
    if (("equipIndex".equals(name)) && ((element instanceof Shelf))) {
      return true;
    }
    if (("equipCount".equals(name)) && ((element instanceof Shelf))) {
      return true;
    }
    if (("equipIndex".equals(name)) && ((element instanceof Slot))) {
      return true;
    }
    if (("equipCount".equals(name)) && ((element instanceof Slot))) {
      return true;
    }
    if (("zoom".equals(name)) && ((element instanceof RotatableNode))) {
      return true;
    }
    if (("angle".equals(name)) && ((element instanceof RotatableNode))) {
      return true;
    }
    if (("rowCount".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("columnCount".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("rowIndex".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("columnIndex".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("rowSpan".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("columnSpan".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("padding".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("border".equals(name)) && ((element instanceof Grid))) {
      return true;
    }
    if (("shapeFrozen".equals(name)) && ((element instanceof Link))) {
      return true;
    }
    if (("shapeLinkType".equals(name)) && ((element instanceof ShapeLink))) {
      return true;
    }
    if (("spanCount".equals(name)) && ((element instanceof Card))) {
      return true;
    }
    if (("startIndex".equals(name)) && ((element instanceof Card))) {
      return true;
    }
    return ("background".equals(name)) && ((element instanceof TSubNetwork));
  }
  
  protected void undoPropertyChange(Element element, String name, Object value)
  {
    if (name.startsWith("CP:"))
    {
      name = name.substring("CP:".length());
      if (TUIManager.isPredefinedClientPropertyKey(name)) {
        element.putClientProperty(name, value);
      }
    }
    else if ("layerID".equals(name))
    {
      element.setLayerID(value);
    }
    else if ("icon".equals(name))
    {
      element.setIcon((String)value);
    }
    else if ("image".equals(name))
    {
      element.setImage((String)value);
    }
    else if ("name".equals(name))
    {
      element.setName((String)value);
    }
    else if ("displayName".equals(name))
    {
      element.setDisplayName((String)value);
    }
    else if ("enableAlarmPropagationFromChildren".equals(name))
    {
      element.setEnableAlarmPropagationFromChildren(((Boolean)value).booleanValue());
    }
    else if ("parent".equals(name))
    {
      element.setParent((Element)value);
    }
    else if ("userObject".equals(name))
    {
      element.setUserObject(value);
    }
    else if ("toolTipText".equals(name))
    {
      element.setToolTipText((String)value);
    }
    else if ("visible".equals(name))
    {
      element.setVisible(((Boolean)value).booleanValue());
    }
    else if ("location".equals(name))
    {
      Point2D location = (Point2D)value;
      element.setLocation(location.getX(), location.getY());
    }
    else if (("width".equals(name)) && ((element instanceof ResizableNode)))
    {
      ((ResizableNode)element).setWidthSize(((Integer)value).intValue());
    }
    else if (("height".equals(name)) && ((element instanceof ResizableNode)))
    {
      ((ResizableNode)element).setHeightSize(((Integer)value).intValue());
    }
    else if (("size".equals(name)) && ((element instanceof ResizableNode)))
    {
      ((ResizableNode)element).setSize((Dimension)value);
    }
    else if (("host".equals(name)) && ((element instanceof Follower)))
    {
      ((Follower)element).setHost((Node)value);
    }
    else if (("exist".equals(name)) && ((element instanceof Equipment)))
    {
      ((Equipment)element).setExist(((Boolean)value).booleanValue());
    }
    else if (("tag".equals(name)) && ((element instanceof Equipment)))
    {
      ((Equipment)element).setTag((String)value);
    }
    else if (("from".equals(name)) && ((element instanceof Link)))
    {
      ((Link)element).setFrom((Node)value);
    }
    else if (("to".equals(name)) && ((element instanceof Link)))
    {
      ((Link)element).setTo((Node)value);
    }
    else if (("linkType".equals(name)) && ((element instanceof Link)))
    {
      ((Link)element).setLinkType(((Integer)value).intValue());
    }
    else if (("expand".equals(name)) && ((element instanceof Group)))
    {
      ((Group)element).setExpand(((Boolean)value).booleanValue());
    }
    else if (("groupType".equals(name)) && ((element instanceof Group)))
    {
      ((Group)element).setGroupType(((Integer)value).intValue());
    }
    else if (("shapeNodeType".equals(name)) && ((element instanceof ShapeNode)))
    {
      ((ShapeNode)element).setShapeNodeType(((Integer)value).intValue());
    }
    else if (("power".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setPower(((Integer)value).intValue());
    }
    else if (("beamDirection".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setBeamDirection(((Integer)value).intValue());
    }
    else if (("beamWidth".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setBeamWidth(((Integer)value).intValue());
    }
    else if (("beamAlpha".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setBeamAlpha(((Float)value).floatValue());
    }
    else if (("antennaType".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setAntennaType(((Integer)value).intValue());
    }
    else if (("BTS".equals(name)) && ((element instanceof BTSAntenna)))
    {
      ((BTSAntenna)element).setBTS((BTS)value);
    }
    else if (("blinkingObject".equals(name)) && ((element instanceof PolyLine)))
    {
      ((PolyLine)element).setBlinkingObject(value);
    }
    else if (("equipIndex".equals(name)) && ((element instanceof Shelf)))
    {
      ((Shelf)element).setEquipIndex(((Integer)value).intValue());
    }
    else if (("equipCount".equals(name)) && ((element instanceof Shelf)))
    {
      ((Shelf)element).setEquipCount(((Integer)value).intValue());
    }
    else if (("equipIndex".equals(name)) && ((element instanceof Slot)))
    {
      ((Slot)element).setEquipIndex(((Integer)value).intValue());
    }
    else if (("equipCount".equals(name)) && ((element instanceof Slot)))
    {
      ((Slot)element).setEquipCount(((Integer)value).intValue());
    }
    else if (("zoom".equals(name)) && ((element instanceof RotatableNode)))
    {
      ((RotatableNode)element).setZoom(((Double)value).doubleValue());
    }
    else if (("angle".equals(name)) && ((element instanceof RotatableNode)))
    {
      ((RotatableNode)element).setAngle(((Double)value).doubleValue());
    }
    else if (("rowCount".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setRowCount(((Integer)value).intValue());
    }
    else if (("columnCount".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setColumnCount(((Integer)value).intValue());
    }
    else if (("rowIndex".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setRowIndex(((Integer)value).intValue());
    }
    else if (("columnIndex".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setColumnIndex(((Integer)value).intValue());
    }
    else if (("rowSpan".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setRowSpan(((Integer)value).intValue());
    }
    else if (("columnSpan".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setColumnSpan(((Integer)value).intValue());
    }
    else if (("padding".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setPadding((Insets)value);
    }
    else if (("border".equals(name)) && ((element instanceof Grid)))
    {
      ((Grid)element).setBorder((Insets)value);
    }
    else if (("shapeFrozen".equals(name)) && ((element instanceof Link)))
    {
      ((Link)element).setShapeFrozen(((Boolean)value).booleanValue());
    }
    else if (("shapeLinkType".equals(name)) && ((element instanceof ShapeLink)))
    {
      ((ShapeLink)element).setShapeLinkType(((Integer)value).intValue());
    }
    else if (("spanCount".equals(name)) && ((element instanceof Card)))
    {
      ((Card)element).setSpanCount(((Integer)value).intValue());
    }
    else if (("startIndex".equals(name)) && ((element instanceof Card)))
    {
      ((Card)element).setStartIndex(((Integer)value).intValue());
    }
    else if (("background".equals(name)) && ((element instanceof TSubNetwork)))
    {
      ((TSubNetwork)element).setBackground((Background)value);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DefaultUndoRedoInterceptor
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.EventListener;

public abstract interface DataBoxListener
  extends EventListener
{
  public abstract void elementAdded(DataBoxEvent paramDataBoxEvent);
  
  public abstract void elementRemoved(DataBoxEvent paramDataBoxEvent);
  
  public abstract void elementsCleared(DataBoxEvent paramDataBoxEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxListener
 * JD-Core Version:    0.7.0.1
 */
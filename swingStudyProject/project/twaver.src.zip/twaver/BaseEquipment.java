package twaver;

import java.util.Iterator;

public class BaseEquipment
  extends Follower
  implements Equipment
{
  protected String tag = null;
  protected boolean exist = true;
  
  public BaseEquipment() {}
  
  public BaseEquipment(Object id)
  {
    super(id);
  }
  
  public String getTag()
  {
    return this.tag;
  }
  
  public void setTag(String tag)
  {
    String oldvalue = this.tag;
    this.tag = tag;
    firePropertyChange("tag", oldvalue, tag);
  }
  
  public String getUIClassID()
  {
    return "BaseEquipmentUI";
  }
  
  public boolean isExist()
  {
    return this.exist;
  }
  
  public void setExist(boolean exist)
  {
    if (this.exist != exist)
    {
      boolean oldValue = this.exist;
      this.exist = exist;
      firePropertyChange("exist", oldValue, exist);
      Iterator it = children();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if ((element instanceof Equipment))
        {
          Equipment child = (Equipment)element;
          child.setExist(this.exist);
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BaseEquipment
 * JD-Core Version:    0.7.0.1
 */
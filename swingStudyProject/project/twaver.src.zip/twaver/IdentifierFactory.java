package twaver;

public abstract interface IdentifierFactory
{
  public abstract Object getIdentifier(Object paramObject);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.IdentifierFactory
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.Map;

public class ParallelogramGroup
  extends Group
{
  public ParallelogramGroup()
  {
    H();
  }
  
  public ParallelogramGroup(Object id)
  {
    super(id);
    H();
  }
  
  private void H()
  {
    setGroupType(3);
    getClientProperties().put("group.3d", Boolean.TRUE);
  }
  
  public void putClientProperty(Object key, Object value)
  {
    super.putClientProperty(key, value);
    if ("group.parallelogram.angle".equals(key)) {
      putClientProperty("group.angle", value);
    } else if ("group.parallelogram.deep".equals(key)) {
      putClientProperty("group.deep", value);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ParallelogramGroup
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Point;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.util.Map;
import twaver.base.A.E.a;
import twaver.base.Direction;

public class Slot
  extends BaseEquipment
{
  private int w = 1;
  private int v = -1;
  
  public Slot()
  {
    U();
  }
  
  public Slot(Object id)
  {
    super(id);
    U();
  }
  
  protected void hostPropertyChange(PropertyChangeEvent evt)
  {
    String propertyName = a.A(evt);
    if ((propertyName.equals("location")) || (propertyName.equals("equip.direction")) || (propertyName.equals("equipCount")) || (propertyName.equals("size")) || (propertyName.equals("shelf.border")) || (propertyName.equals("shelf.inner.border")) || (propertyName.equals("slot.border")) || (propertyName.equals("slot.inner.border"))) {
      adjustBounds();
    }
  }
  
  private void U()
  {
    setSize(35, 105);
    getClientProperties().put("body.fill", Boolean.FALSE);
    getClientProperties().put("border.insets", TWaverConst.INTEGER0);
  }
  
  public int getEquipCount()
  {
    return this.w;
  }
  
  public void setEquipCount(int equipCount)
  {
    int oldValue = this.w;
    this.w = equipCount;
    firePropertyChange("equipCount", oldValue, equipCount);
  }
  
  public int getEquipIndex()
  {
    return this.v;
  }
  
  public void setEquipIndex(int equipIndex)
  {
    int oldValue = this.v;
    this.v = equipIndex;
    firePropertyChange("equipIndex", oldValue, equipIndex);
    adjustBounds();
  }
  
  public Rectangle getEquipBoundsByIndex(int equipIndex)
  {
    if ((this.w <= 0) || (equipIndex < 0) || (equipIndex >= this.w)) {
      return null;
    }
    int slotBorder = a.J(this, "slot.border");
    int slotInnerBorder = a.J(this, "slot.inner.border");
    Point location = getLocation();
    int x = location.x + slotBorder;
    int y = location.y + slotBorder;
    int w = getWidth() - slotBorder * 2;
    int h = getHeight() - slotBorder * 2;
    if (Direction.VERTICAL.equals(getEquipDirection()))
    {
      double span = w / this.w;
      x = (int)(x + span * equipIndex);
      return new Rectangle(x + slotInnerBorder, y + slotInnerBorder, (int)span - slotInnerBorder * 2, h - slotInnerBorder * 2);
    }
    double span = h / this.w;
    y = (int)(y + span * equipIndex);
    return new Rectangle(x + slotInnerBorder, y + slotInnerBorder, w - slotInnerBorder * 2, (int)span - slotInnerBorder * 2);
  }
  
  public void adjustBounds()
  {
    Node host = getHost();
    if ((host instanceof Shelf))
    {
      Shelf shelf = (Shelf)host;
      if ((this.v >= 0) && (this.v < shelf.getEquipCount()))
      {
        Rectangle bounds = shelf.getEquipBoundsByIndex(this.v);
        if (bounds != null)
        {
          setLocation(bounds.x, bounds.y);
          setSize(bounds.width, bounds.height);
        }
      }
    }
    if ((host instanceof Slot))
    {
      Slot slot = (Slot)host;
      if ((this.v >= 0) && (this.v < slot.getEquipCount()))
      {
        Rectangle bounds = slot.getEquipBoundsByIndex(this.v);
        if (bounds != null)
        {
          setLocation(bounds.x, bounds.y);
          setSize(bounds.width, bounds.height);
        }
      }
    }
  }
  
  public String getUIClassID()
  {
    return "SlotUI";
  }
  
  public String getSVGUIClassID()
  {
    return "SlotSVGUI";
  }
  
  public void putEquipDirection(Direction equipDirection)
  {
    putClientProperty("equip.direction", equipDirection);
  }
  
  public Direction getEquipDirection()
  {
    return a.E(this, "equip.direction");
  }
  
  public void putSlotBorder(int slotBorder)
  {
    putClientProperty("slot.border", slotBorder);
  }
  
  public int getSlotBorder()
  {
    return a.J(this, "slot.border");
  }
  
  public void putSlotInnerBorder(int slotInnerBorder)
  {
    putClientProperty("slot.inner.border", slotInnerBorder);
  }
  
  public int getSlotInnerBorder()
  {
    return a.J(this, "slot.inner.border");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Slot
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface PaintSelectionStateFilter
  extends Filter
{
  public abstract boolean isPaintable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PaintSelectionStateFilter
 * JD-Core Version:    0.7.0.1
 */
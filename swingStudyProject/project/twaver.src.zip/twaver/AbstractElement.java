package twaver;

import java.awt.Color;
import java.awt.Font;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import twaver.base.A.E.C;
import twaver.base.A.E.H;
import twaver.base.A.E.P;
import twaver.base.A.E.a;
import twaver.chart.Bubble;

public abstract class AbstractElement
  implements Element
{
  protected final Object id;
  protected String name = null;
  protected String displayName = null;
  protected String toolTipText = null;
  protected Object userObject = null;
  protected Object businessObject = null;
  protected boolean selected = false;
  protected AlarmState alarmState = createAlarmState();
  protected boolean visible = true;
  protected Element parent = null;
  protected String iconUrl = null;
  protected String imageUrl = null;
  private Object A = null;
  private boolean C = false;
  private GeoCoordinate B = null;
  protected Map delegate = createChildrenMap();
  protected List elements = createChildrenList();
  protected transient Map clientProperties = new LinkedHashMap();
  protected transient Map userProperties = new LinkedHashMap();
  protected PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
  
  protected AlarmState createAlarmState()
  {
    return new AlarmState(this);
  }
  
  protected List createChildrenList()
  {
    return new LinkedList();
  }
  
  protected Map createChildrenMap()
  {
    return new HashMap();
  }
  
  public PropertyChangeSupport getPropertyChangeSupport()
  {
    return this.propertyChangeSupport;
  }
  
  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    this.propertyChangeSupport.addPropertyChangeListener(listener);
  }
  
  public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
  {
    this.propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    this.propertyChangeSupport.removePropertyChangeListener(listener);
  }
  
  public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
  {
    this.propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
  }
  
  public void firePropertyChange(PropertyChangeEvent evt)
  {
    this.propertyChangeSupport.firePropertyChange(evt);
  }
  
  public void firePropertyChange(String propertyName, Object oldValue, Object newValue)
  {
    if (oldValue == newValue) {
      return;
    }
    this.propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
  {
    this.propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  public void firePropertyChange(String propertyName, int oldValue, int newValue)
  {
    if (oldValue == newValue) {
      return;
    }
    this.propertyChangeSupport.firePropertyChange(propertyName, TWaverUtil.valueOf(oldValue), TWaverUtil.valueOf(newValue));
  }
  
  public AbstractElement()
  {
    this.id = TWaverUtil.getIdentifier(this);
  }
  
  public AbstractElement(Object id)
  {
    this.id = id;
  }
  
  public Object getID()
  {
    return this.id;
  }
  
  public GeoCoordinate getGeoCoordinate()
  {
    return this.B;
  }
  
  public void setGeoCoordinate(GeoCoordinate geoCoordinate)
  {
    GeoCoordinate oldValue = this.B;
    this.B = geoCoordinate;
    firePropertyChange("geoCoordinate", oldValue, geoCoordinate);
  }
  
  public boolean isAdjustToBottom()
  {
    return false;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    String oldValue = this.name;
    this.name = name;
    firePropertyChange("name", oldValue, name);
  }
  
  public String getDisplayName()
  {
    return this.displayName;
  }
  
  public void setDisplayName(String displayName)
  {
    String oldValue = this.displayName;
    this.displayName = displayName;
    firePropertyChange("displayName", oldValue, displayName);
  }
  
  public Object getClientProperty(Object key)
  {
    return this.clientProperties.get(key);
  }
  
  public Map getClientProperties()
  {
    return this.clientProperties;
  }
  
  public Element getParent()
  {
    return this.parent;
  }
  
  public void putClientProperty(Object key, Object value)
  {
    Object oldValue = this.clientProperties.get(key);
    if (value != null) {
      this.clientProperties.put(key, value);
    } else if (oldValue != null) {
      this.clientProperties.remove(key);
    }
    String propertyName = "CP:" + key.toString();
    firePropertyChange(propertyName, oldValue, value);
  }
  
  public void putClientProperty(Object key, int value)
  {
    putClientProperty(key, TWaverUtil.valueOf(value));
  }
  
  public void putClientProperty(Object key, boolean value)
  {
    putClientProperty(key, Boolean.valueOf(value));
  }
  
  public void setUserObject(Object userObject)
  {
    Object oldValue = this.userObject;
    this.userObject = userObject;
    firePropertyChange("userObject", oldValue, userObject);
  }
  
  public Object getUserObject()
  {
    return this.userObject;
  }
  
  public boolean isSelected()
  {
    return this.selected;
  }
  
  public boolean isVisible()
  {
    return this.visible;
  }
  
  public boolean isDescendantOf(Element element)
  {
    if (element == null) {
      return false;
    }
    if (element.isEmpty()) {
      return false;
    }
    for (Element tempParent = getParent(); tempParent != null; tempParent = tempParent.getParent()) {
      if (element == tempParent) {
        return true;
      }
    }
    return false;
  }
  
  public void setSelected(boolean selected)
  {
    boolean oldValue = this.selected;
    this.selected = selected;
    firePropertyChange("selected", oldValue, selected);
  }
  
  public void setVisible(boolean visible)
  {
    boolean oldValue = this.visible;
    this.visible = visible;
    firePropertyChange("visible", oldValue, visible);
  }
  
  public void removeFromParent()
  {
    setParent(null);
  }
  
  public boolean equals(Object obj)
  {
    return this == obj;
  }
  
  public String getToolTipText()
  {
    return this.toolTipText;
  }
  
  public void setToolTipText(String tip)
  {
    String oldValue = this.toolTipText;
    this.toolTipText = tip;
    firePropertyChange("toolTipText", oldValue, this.toolTipText);
  }
  
  public String toString()
  {
    return getClass().getName();
  }
  
  public AlarmState getAlarmState()
  {
    return this.alarmState;
  }
  
  public void setAlarmState(AlarmState newAlarmState)
  {
    if (newAlarmState == null) {
      throw new NullPointerException("alarm state can't be null.");
    }
    AlarmState oldAlarmState = this.alarmState;
    if (oldAlarmState != newAlarmState)
    {
      oldAlarmState.A(null);
      this.alarmState = newAlarmState;
      this.alarmState.A(this);
    }
  }
  
  public Iterator children()
  {
    return this.elements.iterator();
  }
  
  public List getChildren()
  {
    return this.elements;
  }
  
  public void addChild(int index, Element element)
  {
    if (element == null) {
      return;
    }
    if (element == this) {
      return;
    }
    if (this.delegate.containsKey(element.getID())) {
      return;
    }
    if (isDescendantOf(element)) {
      return;
    }
    if (element.getParent() != null) {
      element.getParent().removeChild(element);
    }
    this.elements.add(index, element);
    this.delegate.put(element.getID(), element);
    element.setParent(this);
    firePropertyChange("children", null, element);
  }
  
  public void addChild(Element element)
  {
    addChild(this.elements.size(), element);
  }
  
  public void setParent(Element parent)
  {
    if ((this.C) || (this.parent == parent) || (this == parent)) {
      return;
    }
    if ((parent != null) && (parent.isDescendantOf(this))) {
      return;
    }
    Element oldValue = this.parent;
    this.parent = parent;
    this.C = true;
    if (oldValue != null) {
      oldValue.removeChild(this);
    }
    if (parent != null) {
      parent.addChild(this);
    }
    this.C = false;
    firePropertyChange("parent", oldValue, parent);
  }
  
  public void removeChild(Element element)
  {
    if (element == null) {
      return;
    }
    if (!this.delegate.containsKey(element.getID())) {
      return;
    }
    this.elements.remove(element);
    this.delegate.remove(element.getID());
    firePropertyChange("children", this.elements, element);
    element.setParent(null);
  }
  
  public boolean isParentOf(Element element)
  {
    if (element == null) {
      return false;
    }
    return this.delegate.containsKey(element.getID());
  }
  
  public Element getChildrenByID(Object id)
  {
    return (Element)this.delegate.get(id);
  }
  
  public int childrenSize()
  {
    return this.elements.size();
  }
  
  public void clearChildren()
  {
    while (!this.elements.isEmpty())
    {
      Element child = (Element)this.elements.get(0);
      removeChild(child);
    }
  }
  
  public boolean isEmpty()
  {
    return this.elements.isEmpty();
  }
  
  protected void exportValues(Element element, TDataBox box)
  {
    ExportValuesInterceptor interceptor = TWaverUtil.getExportValuesInterceptor();
    interceptor.exportValues(this, element, box);
  }
  
  public Element copy()
  {
    return copy(null);
  }
  
  public Element copy(Object id)
  {
    return copy(id, null);
  }
  
  public Element copy(TDataBox box)
  {
    try
    {
      Element newElement = (Element)getClass().newInstance();
      exportValues(newElement, box);
      return newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public Element copy(Object id, TDataBox box)
  {
    try
    {
      Constructor constructor = getClass().getConstructor(new Class[] { Object.class });
      Element newElement = (Element)constructor.newInstance(new Object[] { id });
      exportValues(newElement, box);
      return newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public String getIconURL()
  {
    if (this.iconUrl != null) {
      return this.iconUrl;
    }
    return TUIManager.getIconUrl(getClass());
  }
  
  public ImageIcon getIcon()
  {
    String url = getIconURL();
    if (url != null) {
      return C.B(url);
    }
    return TUIManager.getIcon(getClass());
  }
  
  public void setIcon(String url)
  {
    if ((url == null) || (url.trim().equals(""))) {
      url = null;
    }
    String oldIconUrl = this.iconUrl;
    this.iconUrl = url;
    firePropertyChange("icon", oldIconUrl, this.iconUrl);
  }
  
  public String getImageURL()
  {
    if (this.imageUrl != null) {
      return this.imageUrl;
    }
    return TUIManager.getImageUrl(getClass());
  }
  
  public ImageIcon getImage()
  {
    String url = getImageURL();
    if (url != null) {
      return C.B(url);
    }
    return TUIManager.getImage(getClass());
  }
  
  public void setImage(String url)
  {
    if ((url == null) || (url.trim().equals(""))) {
      url = null;
    }
    int oldWidth = getWidth();
    int oldHeight = getHeight();
    String oldUrl = this.imageUrl;
    this.imageUrl = url;
    firePropertyChange("image", oldUrl, this.imageUrl);
    firePropertyChange("width", oldWidth, getWidth());
    firePropertyChange("height", oldHeight, getHeight());
  }
  
  public void updateUI()
  {
    firePropertyChange("element.update.ui", Boolean.FALSE, Boolean.TRUE);
  }
  
  private void writeObject(ObjectOutputStream s)
    throws IOException
  {
    Iterator it = this.clientProperties.keySet().iterator();
    while (it.hasNext())
    {
      Object key = it.next();
      Object value = this.clientProperties.get(key);
      if (((key instanceof Serializable)) && ((value instanceof Serializable)))
      {
        s.writeObject(key);
        s.writeObject(value);
      }
    }
    s.writeObject(null);
    it = this.userProperties.keySet().iterator();
    while (it.hasNext())
    {
      Object key = it.next();
      Object value = this.userProperties.get(key);
      if (((key instanceof Serializable)) && ((value instanceof Serializable)))
      {
        s.writeObject(key);
        s.writeObject(value);
      }
    }
    s.writeObject(null);
    s.defaultWriteObject();
  }
  
  private void readObject(ObjectInputStream s)
    throws ClassNotFoundException, IOException
  {
    this.clientProperties = new LinkedHashMap();
    Object key;
    while ((key = s.readObject()) != null)
    {
      Object key;
      Object value = s.readObject();
      this.clientProperties.put(key, value);
    }
    this.userProperties = new LinkedHashMap();
    while ((key = s.readObject()) != null)
    {
      Object value = s.readObject();
      this.userProperties.put(key, value);
    }
    s.defaultReadObject();
  }
  
  public boolean isEnableAlarmPropagationFromChildren()
  {
    return this.alarmState.isEnablePropagationFromChildren();
  }
  
  public void setPropertyValue(TPropertyDescriptor property, Object newValue)
  {
    try
    {
      H.A(this, property, newValue);
    }
    catch (Exception e)
    {
      TWaverUtil.handleError("can not write key:" + property.getElementAttribute().getKey(), e);
    }
  }
  
  public Object getPropertyValue(TPropertyDescriptor property)
  {
    try
    {
      return H.A(this, property);
    }
    catch (Exception e)
    {
      TWaverUtil.handleError("can not read key:" + property.getElementAttribute().getKey(), e);
    }
    return null;
  }
  
  public Object getBusinessObject()
  {
    return this.businessObject;
  }
  
  public void setBusinessObject(Object businessObject)
  {
    Object oldValue = this.businessObject;
    this.businessObject = businessObject;
    firePropertyChange("businessObject", oldValue, businessObject);
  }
  
  public Object getUserProperty(Object key)
  {
    return this.userProperties.get(key);
  }
  
  public Map getUserProperties()
  {
    return this.userProperties;
  }
  
  public void putUserProperty(Object key, Object value)
  {
    Object oldValue = this.userProperties.get(key);
    if (value != null) {
      this.userProperties.put(key, value);
    } else if (oldValue != null) {
      this.userProperties.remove(key);
    }
    String propertyName = "UP:" + key.toString();
    firePropertyChange(propertyName, oldValue, value);
  }
  
  public void putUserProperty(Object key, int value)
  {
    putUserProperty(key, TWaverUtil.valueOf(value));
  }
  
  public void putUserProperty(Object key, boolean value)
  {
    putUserProperty(key, Boolean.valueOf(value));
  }
  
  public void setEnableAlarmPropagationFromChildren(boolean enableAlarmPropagationFromChildren)
  {
    this.alarmState.setEnablePropagationFromChildren(enableAlarmPropagationFromChildren);
  }
  
  public void addAttachment(String attachmentName)
  {
    putClientProperty("StateIcon:" + attachmentName, Boolean.TRUE);
  }
  
  public void removeAttachment(String attachmentName)
  {
    putClientProperty("StateIcon:" + attachmentName, null);
  }
  
  public boolean containsAttachment(String attachmentName)
  {
    return Boolean.TRUE.equals(getClientProperty("StateIcon:" + attachmentName));
  }
  
  public void putLabelIcon(String labelIcon)
  {
    putClientProperty("label.icon", labelIcon);
  }
  
  public void putLabelFont(Font labelFont)
  {
    putClientProperty("label.font", labelFont);
  }
  
  public void putLabelColor(Color labelColor)
  {
    putClientProperty("label.color", labelColor);
  }
  
  public void putLabelBackground(Color labelBackground)
  {
    putClientProperty("label.background", labelBackground);
  }
  
  public void putLabelVisible(boolean labelVisible)
  {
    putClientProperty("label.visible", labelVisible);
  }
  
  public void putLabelBorder(boolean labelBorder)
  {
    putClientProperty("label.border", labelBorder);
  }
  
  public void putLabelUnderline(boolean labelUnderline)
  {
    putClientProperty("label.underline", labelUnderline);
  }
  
  public void putLabelPosition(int labelPosition)
  {
    putClientProperty("label.position", labelPosition);
  }
  
  public void putLabelOrientation(int labelOrientation)
  {
    putClientProperty("label.orientation", labelOrientation);
  }
  
  public void putLabelXOffset(int labelXOffset)
  {
    putClientProperty("label.xoffset", labelXOffset);
  }
  
  public void putLabelYOffset(int labelYOffset)
  {
    putClientProperty("label.yoffset", labelYOffset);
  }
  
  public void putLabelXGap(int labelXGap)
  {
    putClientProperty("label.xgap", labelXGap);
  }
  
  public void putLabelYGap(int labelYGap)
  {
    putClientProperty("label.ygap", labelYGap);
  }
  
  public void putLabelBorderStroke(String labelBorderStroke)
  {
    putClientProperty("label.border.stroke", labelBorderStroke);
  }
  
  public void putLabelBorderColor(Color labelBorderColor)
  {
    putClientProperty("label.border.color", labelBorderColor);
  }
  
  public void putLabelUnderlineStroke(String labelUnderlineStroke)
  {
    putClientProperty("label.underline.stroke", labelUnderlineStroke);
  }
  
  public void putLabelUnderlineColor(Color labelUnderlineColor)
  {
    putClientProperty("label.underline.color", labelUnderlineColor);
  }
  
  public void putLabelSelectable(boolean labelSelectable)
  {
    putClientProperty("label.selectable", labelSelectable);
  }
  
  public void putLabelHighlightable(boolean labelHighlightable)
  {
    putClientProperty("label.highlightable", labelHighlightable);
  }
  
  public void putLabelHighlightBackground(Color labelHighlightBackground)
  {
    putClientProperty("label.highlight.background", labelHighlightBackground);
  }
  
  public void putLabelHighlightForeground(Color labelHighlightForeground)
  {
    putClientProperty("label.highlight.foreground", labelHighlightForeground);
  }
  
  public void putLabelMaxLength(int labelMaxLength)
  {
    putClientProperty("label.maxlength", labelMaxLength);
  }
  
  public void putDrawIconShape(boolean drawIconShape)
  {
    putClientProperty("draw.icon.shape", drawIconShape);
  }
  
  public void putRenderAlpha(float renderAlpha)
  {
    putClientProperty("render.alpha", new Float(renderAlpha));
  }
  
  public void putElementTreeIcon(Icon elementTreeIcon)
  {
    putClientProperty("element.tree.icon", elementTreeIcon);
  }
  
  public void putRenderColor(Color renderColor)
  {
    putClientProperty("render.color", renderColor);
  }
  
  public void putStateOutlineColor(Color stateOutlineColor)
  {
    putClientProperty("state.outline.color", stateOutlineColor);
  }
  
  public void putStateOutlineWidth(int stateOutlineWidth)
  {
    putClientProperty("state.outline.width", stateOutlineWidth);
  }
  
  public void putAttachmentPosition(int attachmentPosition)
  {
    putClientProperty("attachment.position", attachmentPosition);
  }
  
  public void putAttachmentOrientation(int attachmentOrientation)
  {
    putClientProperty("attachment.orientation", attachmentOrientation);
  }
  
  public void putAttachmentXOffset(int attachmentXOffset)
  {
    putClientProperty("attachment.xoffset", attachmentXOffset);
  }
  
  public void putAttachmentYOffset(int attachmentYOffset)
  {
    putClientProperty("attachment.yoffset", attachmentYOffset);
  }
  
  public void putAttachmentXGap(int attachmentXGap)
  {
    putClientProperty("attachment.xgap", attachmentXGap);
  }
  
  public void putAttachmentYGap(int attachmentYGap)
  {
    putClientProperty("attachment.ygap", attachmentYGap);
  }
  
  public void putAlarmBalloonPosition(int alarmBalloonPosition)
  {
    putClientProperty("alarm.balloon.position", alarmBalloonPosition);
  }
  
  public void putAlarmBalloonDirection(int alarmBalloonDirection)
  {
    putClientProperty("alarm.balloon.direction", alarmBalloonDirection);
  }
  
  public void putAlarmBalloonXoffset(int alarmBalloonXoffset)
  {
    putClientProperty("alarm.balloon.xoffset", alarmBalloonXoffset);
  }
  
  public void putAlarmBalloonYoffset(int alarmBalloonYoffset)
  {
    putClientProperty("alarm.balloon.yoffset", alarmBalloonYoffset);
  }
  
  public void putAlarmBalloonVisible(boolean alarmBalloonVisible)
  {
    putClientProperty("alarm.balloon.visible", alarmBalloonVisible);
  }
  
  public void putAlarmBalloonAlpha(float alarmBalloonAlpha)
  {
    putClientProperty("alarm.balloon.alpha", new Float(alarmBalloonAlpha));
  }
  
  public void putAlarmBalloonTextFont(Font alarmBalloonTextFont)
  {
    putClientProperty("alarm.balloon.text.font", alarmBalloonTextFont);
  }
  
  public void putAlarmBalloonTextColor(Color alarmBalloonTextColor)
  {
    putClientProperty("alarm.balloon.text.color", alarmBalloonTextColor);
  }
  
  public void putAlarmBalloonTextBlinkable(boolean alarmBalloonTextBlinkable)
  {
    putClientProperty("alarm.balloon.text.blinkable", alarmBalloonTextBlinkable);
  }
  
  public void putAlarmBalloonOutlineColor(Color alarmBalloonOutlineColor)
  {
    putClientProperty("alarm.balloon.outline.color", alarmBalloonOutlineColor);
  }
  
  public void putAlarmBalloonShadowColor(Color alarmBalloonShadowColor)
  {
    putClientProperty("alarm.balloon.shadow.color", alarmBalloonShadowColor);
  }
  
  public void putAlarmBalloonShadowOffset(int alarmBalloonShadowOffset)
  {
    putClientProperty("alarm.balloon.shadow.offset", alarmBalloonShadowOffset);
  }
  
  public void putTextureFactory(String textureFactory)
  {
    putClientProperty("texture.factory", textureFactory);
  }
  
  public void putBorderAntialias(boolean borderAntialias)
  {
    putClientProperty("border.antialias", Boolean.valueOf(borderAntialias));
  }
  
  public void putBorderVisible(boolean borderVisible)
  {
    putClientProperty("border.visible", Boolean.valueOf(borderVisible));
  }
  
  public void putBorderFill(boolean borderFill)
  {
    putClientProperty("border.fill", Boolean.valueOf(borderFill));
  }
  
  public void putBorderUnderneath(boolean borderUnderneath)
  {
    putClientProperty("border.underneath", Boolean.valueOf(borderUnderneath));
  }
  
  public void putBorderXormode(boolean borderXormode)
  {
    putClientProperty("border.xormode", Boolean.valueOf(borderXormode));
  }
  
  public void putBorderStroke(String borderStroke)
  {
    putClientProperty("border.stroke", borderStroke);
  }
  
  public void putBorderColor(Color borderColor)
  {
    putClientProperty("border.color", borderColor);
  }
  
  public void putBorderFillColor(Color borderFillColor)
  {
    putClientProperty("border.fill.color", borderFillColor);
  }
  
  public void putBorderInsets(int borderInsets)
  {
    putClientProperty("border.insets", borderInsets);
  }
  
  public void putBorderType(int borderType)
  {
    putClientProperty("border.type", borderType);
  }
  
  public void putBorderShapeFactory(int borderShapeFactory)
  {
    putClientProperty("border.shape.factory", borderShapeFactory);
  }
  
  public void putStateOutlineInsets(int stateOutlineInsets)
  {
    putClientProperty("state.outline.insets", stateOutlineInsets);
  }
  
  public void putMessageContent(String messageContent)
  {
    putClientProperty("message.content", messageContent);
  }
  
  public void putMessageGradient(boolean gradient)
  {
    putClientProperty("message.gradient", gradient);
  }
  
  public void putMessageGradientColor(Color color)
  {
    putClientProperty("message.gradient.color", color);
  }
  
  public void putMessageGradientFactory(int factory)
  {
    putClientProperty("message.gradient.factory", factory);
  }
  
  public boolean isMessageGradient()
  {
    return a.K(this, "message.gradient");
  }
  
  public Color getMessageGradientColor()
  {
    return a.P(this, "message.gradient.color");
  }
  
  public int getMessageGradientFactory()
  {
    return a.J(this, "message.gradient.factory");
  }
  
  public void putMessageStyle(int messageStyle)
  {
    putClientProperty("message.style", messageStyle);
  }
  
  public void putMessageComponent(int messageComponent)
  {
    putClientProperty("message.component", messageComponent);
  }
  
  public void putMessageWidth(int messageWidth)
  {
    putClientProperty("message.width", messageWidth);
  }
  
  public void putMessageHeight(int messageHeight)
  {
    putClientProperty("message.height", messageHeight);
  }
  
  public void putMessageTail(int messageTail)
  {
    putClientProperty("message.tail", messageTail);
  }
  
  public void putMessageArc(int messageArc)
  {
    putClientProperty("message.arc", messageArc);
  }
  
  public void putMessageShrinkable(boolean messageShrinkable)
  {
    putClientProperty("message.shrinkable", messageShrinkable);
  }
  
  public void putMessageMinimized(boolean minimized)
  {
    putClientProperty("message.minimized", minimized);
  }
  
  public void putMessageShrinked(boolean shrinked)
  {
    putClientProperty("message.shrinked", shrinked);
  }
  
  public void putMessageClosable(boolean messageClosable)
  {
    putClientProperty("message.closable", messageClosable);
  }
  
  public void putMessageMinimizable(boolean messageMinimizable)
  {
    putClientProperty("message.minimizable", messageMinimizable);
  }
  
  public void putMessageAutoAdjustDirection(boolean messageAutoAdjustDirection)
  {
    putClientProperty("message.auto.adjust.direction", messageAutoAdjustDirection);
  }
  
  public void putMessagePosition(int messagePosition)
  {
    putClientProperty("message.position", messagePosition);
  }
  
  public void putMessageDirection(int messageDirection)
  {
    putClientProperty("message.direction", messageDirection);
  }
  
  public void putMessageFont(Font messageFont)
  {
    putClientProperty("message.font", messageFont);
  }
  
  public void putMessageForeground(Color messageForeground)
  {
    putClientProperty("message.foreground", messageForeground);
  }
  
  public void putMessageBackground(Color messageBackground)
  {
    putClientProperty("message.background", messageBackground);
  }
  
  public void putMessageOpaque(boolean messageOpaque)
  {
    putClientProperty("message.opaque", messageOpaque);
  }
  
  public void putMessageXOffset(int messageXOffset)
  {
    putClientProperty("message.xoffset", messageXOffset);
  }
  
  public void putMessageYOffset(int messageYOffset)
  {
    putClientProperty("message.yoffset", messageYOffset);
  }
  
  public void putMessageXGap(int messageXGap)
  {
    putClientProperty("message.xgap", messageXGap);
  }
  
  public void putMessageYGap(int messageYGap)
  {
    putClientProperty("message.ygap", messageYGap);
  }
  
  public void putMessageMinimizedIcon(String messageMinimizedIcon)
  {
    putClientProperty("message.minimized.icon", messageMinimizedIcon);
  }
  
  public void putMessageShadowVisible(boolean messageShadowVisible)
  {
    putClientProperty("message.shadow.visible", messageShadowVisible);
  }
  
  public void putMessageShadowColor(Color messageShadowColor)
  {
    putClientProperty("message.shadow.color", messageShadowColor);
  }
  
  public void putMessageBorderColor(Color messageBorderColor)
  {
    putClientProperty("message.border.color", messageBorderColor);
  }
  
  public void putMessageBorderVisible(boolean messageBorderVisible)
  {
    putClientProperty("message.border.visible", messageBorderVisible);
  }
  
  public void putMessageBorderStroke(String messageBorderStroke)
  {
    putClientProperty("message.border.stroke", messageBorderStroke);
  }
  
  public void putChartColor(Color color)
  {
    putClientProperty("chart.color", color);
  }
  
  public void putChartValue(double value)
  {
    putClientProperty("chart.value", new Double(value));
  }
  
  public void putChartMin(double value)
  {
    putClientProperty("chart.min", new Double(value));
  }
  
  public void putChartMax(double value)
  {
    putClientProperty("chart.max", new Double(value));
  }
  
  public void putChartFormat(NumberFormat format)
  {
    putClientProperty("chart.format", format);
  }
  
  public void putChartValues(List values)
  {
    putClientProperty("chart.values", values);
  }
  
  public void putChartStroke(String stroke)
  {
    putClientProperty("chart.stroke", stroke);
  }
  
  public void putChartPercentStyle(int percentStyle)
  {
    putClientProperty("chart.percent.style", percentStyle);
  }
  
  public void putChartMarkers(List markers)
  {
    putClientProperty("chart.markers", markers);
  }
  
  public Icon getElementTreeIcon()
  {
    return a.A(this, "element.tree.icon");
  }
  
  public boolean isDrawIconShape()
  {
    return a.K(this, "draw.icon.shape");
  }
  
  public float getRenderAlpha()
  {
    return a.O(this, "render.alpha");
  }
  
  public Color getRenderColor()
  {
    return a.P(this, "render.color");
  }
  
  public Color getStateOutlineColor()
  {
    return a.P(this, "state.outline.color");
  }
  
  public int getStateOutlineWidth()
  {
    return a.J(this, "state.outline.width");
  }
  
  public String getTextureFactory()
  {
    return a.Q(this, "texture.factory");
  }
  
  public boolean getBorderAntialias()
  {
    return a.K(this, "border.antialias");
  }
  
  public boolean isBorderVisible()
  {
    return a.K(this, "border.visible");
  }
  
  public boolean isBorderFill()
  {
    return a.K(this, "border.fill");
  }
  
  public boolean isBorderUnderneath()
  {
    return a.K(this, "border.underneath");
  }
  
  public boolean isBorderXormode()
  {
    return a.K(this, "border.xormode");
  }
  
  public String getBorderStroke()
  {
    return a.Q(this, "border.stroke");
  }
  
  public Color getBorderColor()
  {
    return a.P(this, "border.color");
  }
  
  public Color getBorderFillColor()
  {
    return a.P(this, "border.fill.color");
  }
  
  public int getBorderInsets()
  {
    return a.J(this, "border.insets");
  }
  
  public int getBorderType()
  {
    return a.J(this, "border.type");
  }
  
  public int getBorderShapeFactory()
  {
    return a.J(this, "border.shape.factory");
  }
  
  public int getStateOutlineInsets()
  {
    return a.J(this, "state.outline.insets");
  }
  
  public String getLabelIcon()
  {
    return a.Q(this, "label.icon");
  }
  
  public Font getLabelFont()
  {
    return a.D(this, "label.font");
  }
  
  public Color getLabelColor()
  {
    return a.P(this, "label.color");
  }
  
  public Color getLabelBackground()
  {
    return a.P(this, "label.background");
  }
  
  public boolean isLabelVisible()
  {
    return a.K(this, "label.visible");
  }
  
  public boolean isLabelBorder()
  {
    return a.K(this, "label.border");
  }
  
  public boolean isLabelUnderline()
  {
    return a.K(this, "label.underline");
  }
  
  public int getLabelPosition()
  {
    return a.J(this, "label.position");
  }
  
  public int getLabelXOffset()
  {
    return a.J(this, "label.xoffset");
  }
  
  public int getLabelYOffset()
  {
    return a.J(this, "label.yoffset");
  }
  
  public int getLabelXGap()
  {
    return a.J(this, "label.xgap");
  }
  
  public int getLabelYGap()
  {
    return a.J(this, "label.ygap");
  }
  
  public int getLabelOrientation()
  {
    return a.J(this, "label.orientation");
  }
  
  public String getLabelBorderStroke()
  {
    return a.Q(this, "label.border.stroke");
  }
  
  public String getLabelUnderlineStroke()
  {
    return a.Q(this, "label.underline.stroke");
  }
  
  public boolean isLabelSelectable()
  {
    return a.K(this, "label.selectable");
  }
  
  public Color getLabelBorderColor()
  {
    return a.P(this, "label.border.color");
  }
  
  public Color getLabelUnderlineColor()
  {
    return a.P(this, "label.underline.color");
  }
  
  public boolean isLabelHighlightable()
  {
    return a.K(this, "label.highlightable");
  }
  
  public Color getLabelHighlightBackground()
  {
    return a.P(this, "label.highlight.background");
  }
  
  public Color getLabelHighlightForeground()
  {
    return a.P(this, "label.highlight.foreground");
  }
  
  public int getLabelMaxLength()
  {
    return a.J(this, "label.maxlength");
  }
  
  public int getAttachmentPosition()
  {
    return a.J(this, "attachment.position");
  }
  
  public int getAttachmentOrientation()
  {
    return a.J(this, "attachment.orientation");
  }
  
  public int getAttachmentXOffset()
  {
    return a.J(this, "attachment.xoffset");
  }
  
  public int getAttachmentYOffset()
  {
    return a.J(this, "attachment.yoffset");
  }
  
  public int getAttachmentXGap()
  {
    return a.J(this, "attachment.xgap");
  }
  
  public int getAttachmentYGap()
  {
    return a.J(this, "attachment.ygap");
  }
  
  public int getAlarmBalloonPosition()
  {
    return a.J(this, "alarm.balloon.position");
  }
  
  public int getAlarmBalloonDirection()
  {
    return a.J(this, "alarm.balloon.direction");
  }
  
  public int getAlarmBalloonXOffset()
  {
    return a.J(this, "alarm.balloon.xoffset");
  }
  
  public int getAlarmBalloonYOffset()
  {
    return a.J(this, "alarm.balloon.yoffset");
  }
  
  public boolean isAlarmBalloonVisible()
  {
    return a.K(this, "alarm.balloon.visible");
  }
  
  public float getAlarmBalloonAlpha()
  {
    return a.O(this, "alarm.balloon.alpha");
  }
  
  public Font getAlarmBalloonTextFont()
  {
    return a.D(this, "alarm.balloon.text.font");
  }
  
  public Color getAlarmBalloonTextColor()
  {
    return a.P(this, "alarm.balloon.text.color");
  }
  
  public boolean isAlarmBalloonTextBlinkable()
  {
    return a.K(this, "alarm.balloon.text.blinkable");
  }
  
  public Color getAlarmBalloonOutlineColor()
  {
    return a.P(this, "alarm.balloon.outline.color");
  }
  
  public Color getAlarmBalloonShadowColor()
  {
    return a.P(this, "alarm.balloon.shadow.color");
  }
  
  public int getAlarmBalloonShadowOffset()
  {
    return a.J(this, "alarm.balloon.shadow.offset");
  }
  
  public String getMessageContent()
  {
    return a.Q(this, "message.content");
  }
  
  public int getMessageWidth()
  {
    return a.J(this, "message.width");
  }
  
  public int getMessageHeight()
  {
    return a.J(this, "message.height");
  }
  
  public int getMessageComponent()
  {
    return a.J(this, "message.component");
  }
  
  public int getMessageStyle()
  {
    return a.J(this, "message.style");
  }
  
  public int getMessageTail()
  {
    return a.J(this, "message.tail");
  }
  
  public int getMessageArc()
  {
    return a.J(this, "message.arc");
  }
  
  public boolean isMessageShrinkable()
  {
    return a.K(this, "message.shrinkable");
  }
  
  public boolean isMessageShrinked()
  {
    return a.K(this, "message.shrinked");
  }
  
  public boolean isMessageClosable()
  {
    return a.K(this, "message.closable");
  }
  
  public boolean isMessageAutoAdjustDirection()
  {
    return a.K(this, "message.auto.adjust.direction");
  }
  
  public boolean isMessageMinimized()
  {
    return a.K(this, "message.minimized");
  }
  
  public boolean isMessageMinimizable()
  {
    return a.K(this, "message.minimizable");
  }
  
  public int getMessagePosition()
  {
    return a.J(this, "message.position");
  }
  
  public int getMessageDirection()
  {
    return a.J(this, "message.direction");
  }
  
  public Font getMessageFont()
  {
    return a.D(this, "message.font");
  }
  
  public Color getMessageForeground()
  {
    return a.P(this, "message.foreground");
  }
  
  public Color getMessageBackground()
  {
    return a.P(this, "message.background");
  }
  
  public boolean isMessageOpaque()
  {
    return a.K(this, "message.opaque");
  }
  
  public int getMessageXOffset()
  {
    return a.J(this, "message.xoffset");
  }
  
  public int getMessageYOffset()
  {
    return a.J(this, "message.yoffset");
  }
  
  public int getMessageXGap()
  {
    return a.J(this, "message.xgap");
  }
  
  public int getMessageYGap()
  {
    return a.J(this, "message.ygap");
  }
  
  public String getMessageMinimizedIcon()
  {
    return a.Q(this, "message.minimized.icon");
  }
  
  public boolean isMessageShadowVisible()
  {
    return a.K(this, "message.shadow.visible");
  }
  
  public Color getMessageShadowColor()
  {
    return a.P(this, "message.shadow.color");
  }
  
  public boolean isMessageBorderVisible()
  {
    return a.K(this, "message.border.visible");
  }
  
  public Color getMessageBorderColor()
  {
    return a.P(this, "message.border.color");
  }
  
  public String getMessageBorderStroke()
  {
    return a.Q(this, "message.border.stroke");
  }
  
  public Color getChartColor()
  {
    return a.P(this, "chart.color");
  }
  
  public double getChartValue()
  {
    return a.M(this, "chart.value");
  }
  
  public double getChartMin()
  {
    return a.M(this, "chart.min");
  }
  
  public double getChartMax()
  {
    return a.M(this, "chart.max");
  }
  
  public NumberFormat getChartFormat()
  {
    return a.G(this, "chart.format");
  }
  
  public void setChartValues(List values)
  {
    putClientProperty("chart.values", values);
  }
  
  public List getChartValues()
  {
    List values = (List)getClientProperty("chart.values");
    if ((values == null) && (!P.A()))
    {
      values = new ArrayList();
      putClientProperty("chart.values", values);
    }
    return values;
  }
  
  public String getChartStroke()
  {
    return a.Q(this, "chart.stroke");
  }
  
  public int getChartPercentStyle()
  {
    return a.J(this, "chart.percent.style");
  }
  
  public List getChartMarkers()
  {
    return a.L(this, "chart.markers");
  }
  
  public void putChartInflexionStyle(int inflexionStyle)
  {
    putClientProperty("chart.inflexion.style", inflexionStyle);
  }
  
  public int getChartInflexionStyle()
  {
    return a.J(this, "chart.inflexion.style");
  }
  
  public Object getLayerID()
  {
    return this.A;
  }
  
  public void setLayerID(Object layerID)
  {
    Object oldValue = this.A;
    this.A = layerID;
    firePropertyChange("layerID", oldValue, layerID);
  }
  
  public void addChartValue(double value)
  {
    List list = getChartValues();
    list.add(new Double(value));
    firePropertyChange("chart.values", null, list);
  }
  
  public void clearChartValues()
  {
    putClientProperty("chart.values", null);
  }
  
  public void addChartValue(Double value)
  {
    List list = getChartValues();
    list.add(value);
    firePropertyChange("chart.values", null, list);
  }
  
  public void putAlarmBalloonShownOnTop(boolean alarmBalloonShownOnTop)
  {
    putClientProperty("alarm.balloon.shown.on.top", alarmBalloonShownOnTop);
  }
  
  public void putMessageShownOnTop(boolean messageShownOnTop)
  {
    putClientProperty("message.shown.on.top", messageShownOnTop);
  }
  
  public boolean isAlarmBalloonShownOnTop()
  {
    return a.K(this, "alarm.balloon.shown.on.top");
  }
  
  public boolean isMessageShownOnTop()
  {
    return a.K(this, "message.shown.on.top");
  }
  
  public void putChartDialHandLength(double chartDialHandLength)
  {
    putClientProperty("chart.dial.hand.length", new Double(chartDialHandLength));
  }
  
  public double getChartDialHandLength()
  {
    return a.M(this, "chart.dial.hand.length");
  }
  
  public void putChartDialHandStyle(int chartDialHandStyle)
  {
    putClientProperty("chart.dial.hand.style", chartDialHandStyle);
  }
  
  public int getChartDialHandStyle()
  {
    return a.J(this, "chart.dial.hand.style");
  }
  
  public void putChartPercentSpareFill(boolean spareFill)
  {
    putClientProperty("chart.percent.spare.fill", spareFill);
  }
  
  public boolean getChartPercentSpareFill()
  {
    return a.K(this, "chart.percent.spare.fill");
  }
  
  public void putChartPercentSpareColor(Color spareColor)
  {
    putClientProperty("chart.percent.spare.color", spareColor);
  }
  
  public Color getChartPercentSpareColor()
  {
    return a.P(this, "chart.percent.spare.color");
  }
  
  public void putChartPercentSpareCoverColor(Color spareCoverColor)
  {
    putClientProperty("chart.percent.spare.cover.color", spareCoverColor);
  }
  
  public Color getChartPercentSpareCoverColor()
  {
    return a.P(this, "chart.percent.spare.cover.color");
  }
  
  public void putChartPercentMarkerPostion(int position)
  {
    putClientProperty("chart.percent.marker.position", position);
  }
  
  public int getChartPercentMarkerPostion()
  {
    return a.J(this, "chart.percent.marker.position");
  }
  
  public void addChartBubble(Bubble bubble)
  {
    List list = getChartValues();
    list.add(bubble);
    firePropertyChange("chart.values", null, list);
  }
  
  public void putChartBubbleStyle(int style)
  {
    putClientProperty("chart.bubble.style", style);
  }
  
  public int getChartBubbleStyle()
  {
    return a.J(this, "chart.bubble.style");
  }
  
  public void putChartBubbleShapeLineVisible(boolean visible)
  {
    putClientProperty("chart.bubble.shape.line.visible", visible);
  }
  
  public boolean getChartBubbleShapeLineVisible()
  {
    return a.K(this, "chart.bubble.shape.line.visible");
  }
  
  public void putChartBubbleShapeBubbleVisible(boolean visible)
  {
    putClientProperty("chart.bubble.shape.bubble.visible", visible);
  }
  
  public boolean getChartBubbleShapeBubbleVisible()
  {
    return a.K(this, "chart.bubble.shape.bubble.visible");
  }
  
  public void putChartValueTextPosition(int position)
  {
    putClientProperty("chart.value.text.position", position);
  }
  
  public int getChartValueTextPosition()
  {
    return a.J(this, "chart.value.text.position");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AbstractElement
 * JD-Core Version:    0.7.0.1
 */
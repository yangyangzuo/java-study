package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class AlarmModelQuickFinder
{
  private Map D = new HashMap();
  private String A = null;
  private AlarmModel C = null;
  private AlarmModelListener E = new AlarmModelListener()
  {
    public void alarmAdded(AlarmModelEvent e)
    {
      AlarmModelQuickFinder.this.addAlarm(e.getAlarm());
    }
    
    public void alarmRemoved(AlarmModelEvent e)
    {
      AlarmModelQuickFinder.this.removeAlarm(e.getAlarm());
    }
    
    public void alarmCleared(AlarmModelEvent e)
    {
      AlarmModelQuickFinder.this.clear();
    }
  };
  private PropertyChangeListener B = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent e)
    {
      AlarmModelQuickFinder.this.A(e);
    }
  };
  
  public AlarmModelQuickFinder(AlarmModel alarmModel, String propertyName)
  {
    this.A = propertyName;
    this.C = alarmModel;
    Iterator it = alarmModel.iterator();
    while (it.hasNext())
    {
      Alarm alarm = (Alarm)it.next();
      addAlarm(alarm);
    }
    this.C.A(this.E);
    this.C.C(this.B);
  }
  
  protected void addAlarm(Alarm alarm)
  {
    if (!interested(alarm)) {
      return;
    }
    Object key = getKey(alarm);
    List list = find(key);
    if (list == null)
    {
      list = new ArrayList(1);
      this.D.put(key, list);
    }
    list.add(alarm);
  }
  
  protected void removeAlarm(Alarm alarm)
  {
    if (!interested(alarm)) {
      return;
    }
    Object key = getKey(alarm);
    List list = find(key);
    if (list != null)
    {
      list.remove(alarm);
      if (list.isEmpty()) {
        this.D.remove(key);
      }
    }
  }
  
  protected void clear()
  {
    this.D.clear();
  }
  
  private void A(PropertyChangeEvent e)
  {
    String name = e.getPropertyName();
    if (name.equals(this.A))
    {
      Alarm alarm = (Alarm)e.getSource();
      Object oldKey = e.getOldValue();
      List list = find(oldKey);
      if (list != null) {
        list.remove(alarm);
      }
      addAlarm(alarm);
      return;
    }
  }
  
  public List find(Object value)
  {
    return (List)this.D.get(value);
  }
  
  public Alarm findFirst(Object value)
  {
    List list = (List)this.D.get(value);
    if ((list != null) && (list.size() > 0)) {
      return (Alarm)list.get(0);
    }
    return null;
  }
  
  protected Object getKey(Alarm alarm)
  {
    return alarm.getClientProperty(this.A);
  }
  
  public boolean interested(Alarm alarm)
  {
    return true;
  }
  
  public void dispose()
  {
    this.A = null;
    this.C = null;
    this.C.B(this.E);
    this.C.D(this.B);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmModelQuickFinder
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import twaver.base.enumerable.AbstractEnumerable;

public final class AlarmType
  extends AbstractEnumerable
{
  public static final AlarmType COMMUNICATIONS_ALARM = new AlarmType("CommunicationsAlarm");
  public static final AlarmType PROCESSING_ERROR_ALARM = new AlarmType("ProcessingErrorAlarm");
  public static final AlarmType ENVIRONMENTAL_ALARM = new AlarmType("EnvironmentalAlarm");
  public static final AlarmType QUALITY_OF_SERVICE_ALARM = new AlarmType("QualityOfServiceAlarm");
  public static final AlarmType EQUIPMENT_ALARM = new AlarmType("EquipmentAlarm");
  public static final AlarmType INTEGRITY_VIOLATION = new AlarmType("IntegrityViolation");
  public static final AlarmType SECURITY_VIOLATION = new AlarmType("SecurityViolation");
  public static final AlarmType TIME_DOMAIN_VIOLATION = new AlarmType("TimeDomainViolation");
  public static final AlarmType OPERATIONAL_VIOLATION = new AlarmType("OperationalViolation");
  public static final AlarmType PHYSICAL_VIOLATION = new AlarmType("PhysicalViolation");
  
  private AlarmType(String name)
  {
    super(name);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmType
 * JD-Core Version:    0.7.0.1
 */
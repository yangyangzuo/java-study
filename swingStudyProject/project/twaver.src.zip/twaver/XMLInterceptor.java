package twaver;

import java.io.InputStream;

public abstract interface XMLInterceptor
  extends Interceptor
{
  public abstract InputStream beforeRead(TDataBox paramTDataBox, InputStream paramInputStream, Element paramElement);
  
  public abstract void afterRead(TDataBox paramTDataBox, InputStream paramInputStream, Element paramElement);
  
  public abstract void beforeWrite(TDataBox paramTDataBox, DataBoxOutputSetting paramDataBoxOutputSetting);
  
  public abstract void afterWrite(TDataBox paramTDataBox, DataBoxOutputSetting paramDataBoxOutputSetting);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.XMLInterceptor
 * JD-Core Version:    0.7.0.1
 */
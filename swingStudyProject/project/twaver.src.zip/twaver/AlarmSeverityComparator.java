package twaver;

import java.util.Comparator;

public class AlarmSeverityComparator
  implements Comparator
{
  public static final Comparator ASCENDING = new AlarmSeverityComparator(true);
  public static final Comparator DESCENDING = new AlarmSeverityComparator(false);
  private boolean A;
  
  private AlarmSeverityComparator(boolean isAscending)
  {
    this.A = isAscending;
  }
  
  public int compare(Object o1, Object o2)
  {
    AlarmSeverity severity1 = (AlarmSeverity)o1;
    AlarmSeverity severity2 = (AlarmSeverity)o2;
    if ((severity1 != null) && (severity2 != null))
    {
      if (this.A) {
        return severity1.getValue() - severity2.getValue();
      }
      return severity2.getValue() - severity1.getValue();
    }
    if ((severity1 != null) && (severity2 == null)) {
      return 1;
    }
    if ((severity1 == null) && (severity2 != null)) {
      return -1;
    }
    return 0;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmSeverityComparator
 * JD-Core Version:    0.7.0.1
 */
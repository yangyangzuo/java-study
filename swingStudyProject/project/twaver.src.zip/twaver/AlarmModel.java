package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import twaver.base.A.E.Q;

public class AlarmModel
  implements Serializable, PropertyChangeListener, DataBoxListener, Batchable
{
  private final TDataBox h;
  private int f = -1;
  private Map o = new LinkedHashMap();
  private transient List j = null;
  private transient List k = new ArrayList();
  private transient List e = null;
  private transient List g = new ArrayList();
  private transient AlarmElementMapping d = new DefaultAlarmElementMapping();
  private boolean i = false;
  private boolean n = true;
  private transient int l = 0;
  private transient List m = new ArrayList();
  
  public boolean isBatching()
  {
    return this.l > 0;
  }
  
  public void startBatch()
  {
    this.l += 1;
    int count = this.m.size();
    if ((this.l == 1) && (count > 0))
    {
      BatchEvent event = new BatchEvent(this);
      for (int i = 0; i < count; i++)
      {
        BatchListener l = (BatchListener)this.m.get(i);
        l.batchStarted(event);
      }
    }
  }
  
  public void endBatch()
  {
    if (this.l == 0) {
      throw new IllegalStateException("batch hasn't started yet.");
    }
    this.l -= 1;
    int count = this.m.size();
    if ((this.l == 0) && (count > 0))
    {
      BatchEvent event = new BatchEvent(this);
      for (int i = 0; i < count; i++)
      {
        BatchListener l = (BatchListener)this.m.get(i);
        l.batchEnded(event);
      }
    }
  }
  
  public void addBatchListener(BatchListener l)
  {
    if (!this.m.contains(l)) {
      this.m.add(l);
    }
  }
  
  public void removeBatchListener(BatchListener l)
  {
    this.m.remove(l);
  }
  
  AlarmModel(TDataBox box)
  {
    if (box == null) {
      throw new NullPointerException("the data box of alarm model can't be null");
    }
    this.h = box;
    box.addDataBoxListener(this);
  }
  
  public TDataBox getDataBox()
  {
    return this.h;
  }
  
  public Iterator iterator()
  {
    return this.o.values().iterator();
  }
  
  public List getAllAlarms()
  {
    List list = new ArrayList(this.o.size());
    Iterator it = this.o.values().iterator();
    while (it.hasNext()) {
      list.add(it.next());
    }
    return list;
  }
  
  public boolean isEmpty()
  {
    return this.o.size() == 0;
  }
  
  public void removeFirstAlarm(int count)
  {
    while ((count > 0) && (this.o.size() > 0))
    {
      Alarm alarm = (Alarm)this.o.values().iterator().next();
      removeAlarm(alarm);
      count--;
    }
  }
  
  public int getLimit()
  {
    return this.f;
  }
  
  public void setLimit(int limit)
  {
    this.f = limit;
    B();
  }
  
  private void B()
  {
    if ((this.f > 0) && (this.o.size() > this.f)) {
      removeFirstAlarm(this.o.size() - this.f);
    }
  }
  
  public int size()
  {
    return this.o.size();
  }
  
  void A(AlarmModelListener l)
  {
    if (l == null) {
      return;
    }
    if (this.j == null) {
      this.j = new ArrayList();
    }
    if (!this.j.contains(l)) {
      this.j.add(l);
    }
  }
  
  void B(AlarmModelListener l)
  {
    if (this.j != null) {
      this.j.remove(l);
    }
  }
  
  void C(PropertyChangeListener l)
  {
    if (this.e == null) {
      this.e = new ArrayList();
    }
    if (!this.e.contains(l)) {
      this.e.add(l);
    }
  }
  
  void D(PropertyChangeListener l)
  {
    if (this.e != null) {
      this.e.remove(l);
    }
  }
  
  public void addAlarmModelListener(AlarmModelListener l)
  {
    if (l != null)
    {
      if (this.k.contains(l)) {
        throw new IllegalArgumentException("listener already exists.");
      }
      this.k.add(l);
    }
  }
  
  public void removeAlarmModelListener(AlarmModelListener l)
  {
    this.k.remove(l);
  }
  
  public void addAlarmPropertyChangeListener(PropertyChangeListener l)
  {
    if (l != null)
    {
      if (this.g.contains(l)) {
        throw new IllegalArgumentException("listener already exists.");
      }
      this.g.add(l);
    }
  }
  
  public void removeAlarmPropertyChangeListener(PropertyChangeListener l)
  {
    this.g.remove(l);
  }
  
  private void A(Alarm alarm, int type)
  {
    AlarmModelEvent e = new AlarmModelEvent(this, alarm, type);
    if (this.j != null)
    {
      Iterator it = this.j.iterator();
      while (it.hasNext())
      {
        AlarmModelListener l = (AlarmModelListener)it.next();
        switch (e.getType())
        {
        case 1: 
          l.alarmAdded(e);
          break;
        case 2: 
          l.alarmRemoved(e);
          break;
        case 3: 
          l.alarmCleared(e);
        }
      }
    }
    Iterator it = this.k.iterator();
    while (it.hasNext())
    {
      AlarmModelListener l = (AlarmModelListener)it.next();
      switch (e.getType())
      {
      case 1: 
        l.alarmAdded(e);
        break;
      case 2: 
        l.alarmRemoved(e);
        break;
      case 3: 
        l.alarmCleared(e);
      }
    }
  }
  
  public void addAlarms(List alarms)
  {
    if (alarms != null)
    {
      Iterator it = alarms.iterator();
      while (it.hasNext())
      {
        Alarm alarm = (Alarm)it.next();
        addAlarm(alarm);
      }
    }
  }
  
  public void addAlarm(Alarm alarm)
  {
    if (alarm == null) {
      throw new NullPointerException("alarm can not null");
    }
    if (isAlarmExists(alarm.getAlarmID())) {
      throw new IllegalArgumentException("alarm with id '" + alarm.getAlarmID() + "' already exist");
    }
    if ((isAutoRemoveAlarmWhenCleared()) && (alarm.isCleared())) {
      return;
    }
    this.o.put(alarm.getAlarmID(), alarm);
    A(alarm, 1);
    C(alarm);
    alarm.getPropertyChangeSupport().addPropertyChangeListener(this);
    B();
  }
  
  private void A(Alarm alarm)
  {
    Q.A(this, alarm, true);
  }
  
  private void B(Alarm alarm)
  {
    Q.A(this, alarm, false);
  }
  
  private void C(Alarm alarm)
  {
    if (!alarm.isCleared()) {
      Q.A(this, alarm, true);
    }
  }
  
  private void D(Alarm alarm)
  {
    if (!alarm.isCleared()) {
      Q.A(this, alarm, false);
    }
  }
  
  public Alarm getAlarmByID(Object id)
  {
    return (Alarm)this.o.get(id);
  }
  
  public void clearAlarmByID(Object alarmID)
  {
    clearAlarmByID(alarmID, null);
  }
  
  public void clearAlarmByID(Object alarmID, Date clearTime)
  {
    if (alarmID == null) {
      throw new NullPointerException("alarm id can not null.");
    }
    if (!isAlarmExists(alarmID)) {
      throw new NullPointerException("alarm with alarmID '" + alarmID + "' not exists.");
    }
    if (clearTime == null) {
      clearTime = new Date();
    }
    Alarm alarm = getAlarmByID(alarmID);
    alarm.setClearedTime(clearTime);
    alarm.setCleared(true);
  }
  
  public void confirmAlarmByID(Object alarmID)
  {
    acknowledgeAlarmByID(alarmID);
  }
  
  public void acknowledgeAlarmByID(Object alarmID)
  {
    acknowledgeAlarmByID(alarmID, null, null);
  }
  
  public void acknowledgeAlarm(Alarm alarm)
  {
    acknowledgeAlarmByID(alarm.getAlarmID(), null, null);
  }
  
  public void confirmAlarmByID(Object alarmID, Date ackTime, String ackUserID)
  {
    acknowledgeAlarmByID(alarmID, ackTime, ackUserID);
  }
  
  public void acknowledgeAlarmByID(Object alarmID, Date ackTime, String ackUserID)
  {
    if (alarmID == null) {
      throw new NullPointerException("alarm id can not null.");
    }
    if (!isAlarmExists(alarmID)) {
      throw new NullPointerException("alarm with alarmID '" + alarmID + "' not exists.");
    }
    Alarm alarm = getAlarmByID(alarmID);
    if (alarm.isAcked()) {
      throw new IllegalStateException("alarm '" + alarm.getAlarmID() + "' already acknowledged.");
    }
    if (ackTime == null) {
      ackTime = new Date();
    }
    alarm.setAckTime(ackTime);
    alarm.setAckUserID(ackUserID);
    alarm.setAcked(true);
  }
  
  public boolean isAlarmExists(Object alarmID)
  {
    return this.o.containsKey(alarmID);
  }
  
  public void removeAllAlarms()
  {
    clear();
  }
  
  public void clear()
  {
    Iterator it = this.o.values().iterator();
    while (it.hasNext())
    {
      Alarm alarm = (Alarm)it.next();
      alarm.getPropertyChangeSupport().removePropertyChangeListener(this);
      D(alarm);
    }
    this.o.clear();
    A(null, 3);
  }
  
  public void removeAlarmByID(Object alarmID)
  {
    Alarm alarm = getAlarmByID(alarmID);
    if (alarm != null)
    {
      this.o.remove(alarm.getAlarmID());
      alarm.getPropertyChangeSupport().removePropertyChangeListener(this);
      D(alarm);
      A(alarm, 2);
    }
  }
  
  public void removeAlarm(Alarm alarm)
  {
    if (alarm != null) {
      removeAlarmByID(alarm.getAlarmID());
    }
  }
  
  public Collection getAlarmsByElement(Element element)
  {
    Object object = this.d.getCorrespondingAlarms(this.h, element);
    if ((object instanceof Alarm))
    {
      List result = new LinkedList();
      result.add(object);
      return result;
    }
    if ((object instanceof Collection)) {
      return (Collection)object;
    }
    return new LinkedList();
  }
  
  public Collection getElementsByAlarm(Alarm alarm)
  {
    Object object = this.d.getCorrespondingElements(this.h, alarm);
    if ((object instanceof Element))
    {
      List result = new LinkedList();
      result.add(object);
      return result;
    }
    if ((object instanceof Collection)) {
      return (Collection)object;
    }
    return new LinkedList();
  }
  
  public void removeAlarmsByElement(Element element)
  {
    if (element != null)
    {
      Object object = this.d.getCorrespondingAlarms(this.h, element);
      if ((object instanceof Alarm))
      {
        removeAlarm((Alarm)object);
      }
      else if ((object instanceof Collection))
      {
        Collection c = (Collection)object;
        Iterator alarms = c.iterator();
        while (alarms.hasNext())
        {
          Alarm alarm = (Alarm)alarms.next();
          removeAlarm(alarm);
        }
      }
    }
  }
  
  private void B(Alarm alarm, PropertyChangeEvent e)
  {
    Object object = this.d.getCorrespondingElements(this.h, alarm);
    if ((object instanceof Element))
    {
      Element element = (Element)object;
      Q.A(element, e, this);
    }
    else if ((object instanceof Collection))
    {
      Collection c = (Collection)object;
      Iterator elements = c.iterator();
      while (elements.hasNext())
      {
        Element element = (Element)elements.next();
        Q.A(element, e, this);
      }
    }
  }
  
  private void A(Alarm alarm, PropertyChangeEvent e)
  {
    Object object = this.d.getCorrespondingElements(this.h, alarm);
    if ((object instanceof Element))
    {
      Element element = (Element)object;
      Q.A(element, e);
    }
    else if ((object instanceof Collection))
    {
      Collection c = (Collection)object;
      Iterator elements = c.iterator();
      while (elements.hasNext())
      {
        Element element = (Element)elements.next();
        Q.A(element, e);
      }
    }
  }
  
  public void propertyChange(PropertyChangeEvent e)
  {
    if (this.e != null)
    {
      Iterator it = this.e.iterator();
      while (it.hasNext())
      {
        PropertyChangeListener l = (PropertyChangeListener)it.next();
        l.propertyChange(e);
      }
    }
    Alarm alarm = (Alarm)e.getSource();
    String propertyName = e.getPropertyName();
    if (!alarm.isCleared()) {
      if (propertyName.equals("alarmSeverity")) {
        B(alarm, e);
      } else if (propertyName.equals("acked")) {
        A(alarm, e);
      }
    }
    if (propertyName.equals("cleared")) {
      if (alarm.isCleared())
      {
        B(alarm);
        if (isAutoRemoveAlarmWhenCleared()) {
          removeAlarm(alarm);
        }
      }
      else
      {
        A(alarm);
      }
    }
    A(e);
  }
  
  private void A(PropertyChangeEvent e)
  {
    Iterator it = this.g.iterator();
    while (it.hasNext())
    {
      PropertyChangeListener l = (PropertyChangeListener)it.next();
      l.propertyChange(e);
    }
  }
  
  public void elementRemoved(DataBoxEvent e)
  {
    if (!this.n) {
      return;
    }
    if (e.getElement() != null) {
      removeAlarmsByElement(e.getElement());
    }
  }
  
  public void elementsCleared(DataBoxEvent e)
  {
    if (!this.n) {
      return;
    }
    removeAllAlarms();
  }
  
  public void elementAdded(DataBoxEvent e)
  {
    if (this.o.size() == 0) {
      return;
    }
    Element element = e.getElement();
    Object object = this.d.getCorrespondingAlarms(this.h, element);
    if ((object instanceof Alarm))
    {
      Alarm alarm = (Alarm)object;
      if (!alarm.isCleared()) {
        Q.A(element, alarm, true);
      }
    }
    else if ((object instanceof Collection))
    {
      Collection c = (Collection)object;
      Iterator alarms = c.iterator();
      while (alarms.hasNext())
      {
        Alarm alarm = (Alarm)alarms.next();
        if (!alarm.isCleared()) {
          Q.A(element, alarm, true);
        }
      }
    }
  }
  
  private void readObject(ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    this.k = new ArrayList();
    this.g = new ArrayList();
    this.d = new DefaultAlarmElementMapping();
    this.m = new ArrayList();
  }
  
  public AlarmElementMapping getAlarmElementMapping()
  {
    return this.d;
  }
  
  public void setAlarmElementMapping(AlarmElementMapping alarmElementMapping)
  {
    this.d = alarmElementMapping;
  }
  
  public boolean isAutoRemoveAlarmWhenCleared()
  {
    return this.i;
  }
  
  public void setAutoRemoveAlarmWhenCleared(boolean autoRemoveAlarmWhenCleared)
  {
    this.i = autoRemoveAlarmWhenCleared;
  }
  
  public AlarmModelQuickFinder createAlarmFinder(String propertyName)
  {
    return new AlarmModelQuickFinder(this, propertyName);
  }
  
  public boolean isAutoRemoveAlarmWhenElementIsRemoved()
  {
    return this.n;
  }
  
  public void setAutoRemoveAlarmWhenElementIsRemoved(boolean autoRemoveAlarmWhenElementIsRemoved)
  {
    this.n = autoRemoveAlarmWhenElementIsRemoved;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmModel
 * JD-Core Version:    0.7.0.1
 */
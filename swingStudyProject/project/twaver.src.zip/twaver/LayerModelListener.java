package twaver;

public abstract interface LayerModelListener
{
  public abstract void layerAdded(Layer paramLayer);
  
  public abstract void layerRemoved(Layer paramLayer);
  
  public abstract void layerIndexChanged();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.LayerModelListener
 * JD-Core Version:    0.7.0.1
 */
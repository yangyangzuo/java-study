package twaver;

public class EllipseGroup
  extends Group
{
  public EllipseGroup()
  {
    G();
  }
  
  public EllipseGroup(Object id)
  {
    super(id);
    G();
  }
  
  private void G()
  {
    setGroupType(2);
  }
  
  public void putGroupEllipse3D(boolean groupEllipse3D)
  {
    putGroup3D(groupEllipse3D);
  }
  
  public void putGroupEllipseDeep(int groupEllipseDeep)
  {
    putGroupDeep(groupEllipseDeep);
  }
  
  public void putClientProperty(Object key, Object value)
  {
    super.putClientProperty(key, value);
    if ("group.ellipse.3d".equals(key)) {
      putClientProperty("group.3d", value);
    } else if ("group.ellipse.deep".equals(key)) {
      putClientProperty("group.deep", value);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.EllipseGroup
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.Map;

public class RoundRect
  extends Node
{
  public RoundRect()
  {
    K();
  }
  
  public RoundRect(Object id)
  {
    super(id);
    K();
  }
  
  private void K()
  {
    getClientProperties().put("border.antialias", Boolean.TRUE);
  }
  
  public String getUIClassID()
  {
    return "RoundRectUI";
  }
  
  public String getSVGUIClassID()
  {
    return "RoundRectSVGUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.RoundRect
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Iterator;

public abstract class AbstractPropertyPropagator
  implements PropertyPropagator
{
  private boolean C = false;
  private TDataBox E;
  private String B;
  private ThreadLocal A = new ThreadLocal();
  private DataBoxListener F = new DataBoxListener()
  {
    public void elementAdded(DataBoxEvent e)
    {
      AbstractPropertyPropagator.this.B(e.getElement());
    }
    
    public void elementRemoved(DataBoxEvent e)
    {
      AbstractPropertyPropagator.this.B(e.getElement());
    }
    
    public void elementsCleared(DataBoxEvent e) {}
  };
  private PropertyChangeListener D = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent evt)
    {
      Element element = (Element)evt.getSource();
      if (evt.getPropertyName().equals(AbstractPropertyPropagator.this.B))
      {
        AbstractPropertyPropagator.this.B(element);
      }
      else if (evt.getPropertyName().equals("parent"))
      {
        Element oldParent = (Element)evt.getOldValue();
        if (oldParent != null) {
          AbstractPropertyPropagator.this.B(oldParent);
        }
        AbstractPropertyPropagator.this.B(element);
      }
    }
  };
  
  public AbstractPropertyPropagator(TDataBox box, String propertyName)
  {
    this.E = box;
    this.B = propertyName;
  }
  
  private void B(Element element)
  {
    if ((element == null) || (this.A.get() != null)) {
      return;
    }
    this.A.set(element);
    A(element);
    this.A.set(null);
  }
  
  private void A(Element element)
  {
    propagateToParent(null, element);
    while ((element != null) && (element.getParent() != null))
    {
      Element parent = element.getParent();
      propagateToParent(element, parent);
      element = parent;
    }
  }
  
  public TDataBox getDataBox()
  {
    return this.E;
  }
  
  public String getPropertyName()
  {
    return this.B;
  }
  
  public void start()
  {
    if (!this.C)
    {
      this.E.addDataBoxListener(this.F);
      this.E.addElementPropertyChangeListener(this.D);
      Iterator it = this.E.iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if (element.childrenSize() == 0) {
          B(element);
        }
      }
      this.C = true;
    }
  }
  
  public void stop()
  {
    if (this.C)
    {
      this.E.removeDataBoxListener(this.F);
      this.E.removeElementPropertyChangeListener(this.D);
      this.C = false;
    }
  }
  
  public boolean isStarted()
  {
    return this.C;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AbstractPropertyPropagator
 * JD-Core Version:    0.7.0.1
 */
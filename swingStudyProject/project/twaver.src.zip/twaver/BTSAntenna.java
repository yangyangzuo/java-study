package twaver;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Arc2D.Float;
import java.awt.geom.Area;
import java.awt.geom.Point2D.Double;
import java.util.Map;
import twaver.base.A.E.K;
import twaver.base.A.E.a;

public class BTSAntenna
  extends BaseEquipment
{
  private BTS º = null;
  private int À = 1;
  private int z = 100;
  private int £ = 0;
  private int ¤ = 60;
  private float ª = 1.0F;
  private Point y = null;
  private transient Shape ¥ = null;
  private transient Shape µ = null;
  private transient Rectangle x = null;
  private boolean ¢ = false;
  
  public BTSAntenna()
  {
    X();
  }
  
  public BTSAntenna(Object id)
  {
    super(id);
    X();
  }
  
  private void X()
  {
    getClientProperties().put("border.antialias", Boolean.TRUE);
    invalidateAntennaShape();
  }
  
  private void V()
  {
    if (this.¥ == null) {
      invalidateAntennaShape();
    }
  }
  
  public String getUIClassID()
  {
    return "BTSAntennaUI";
  }
  
  public String getSVGUIClassID()
  {
    return "BTSAntennaSVGUI";
  }
  
  public void setParent(Element parent)
  {
    super.setParent(parent);
    if (((parent instanceof BTS)) && (this.º != parent)) {
      setBTS((BTS)parent);
    }
  }
  
  public BTS getBTS()
  {
    return this.º;
  }
  
  public void setBTS(BTS bts)
  {
    if (this.º == bts)
    {
      if (bts != null) {
        bts.P();
      }
      return;
    }
    BTS oldValue = this.º;
    if (oldValue != null) {
      oldValue.removeAntenna(this);
    }
    this.º = bts;
    if (this.º != null) {
      this.º.addAntenna(this);
    }
    firePropertyChange("BTS", oldValue, this.º);
    invalidateAntennaShape();
  }
  
  public Shape getAntennaShape()
  {
    V();
    return this.¥;
  }
  
  public float getBeamAlpha()
  {
    return this.ª;
  }
  
  public void setBeamAlpha(float beamAlpha)
  {
    if ((beamAlpha >= 0.0F) && (beamAlpha <= 1.0F) && (this.ª != beamAlpha))
    {
      float oldValue = this.ª;
      this.ª = beamAlpha;
      firePropertyChange("beamAlpha", new Float(oldValue), new Float(beamAlpha));
    }
  }
  
  public Shape getArrowShape()
  {
    V();
    return this.µ;
  }
  
  public int getBeamDirection()
  {
    return this.£;
  }
  
  public Point getHotspot()
  {
    V();
    return (Point)this.y.clone();
  }
  
  public void setBeamDirection(int beamDirection)
  {
    if (this.£ != beamDirection)
    {
      int oldValue = this.£;
      this.£ = beamDirection;
      firePropertyChange("beamDirection", oldValue, this.£);
      invalidateAntennaShape();
    }
  }
  
  public int getBeamWidth()
  {
    return this.¤;
  }
  
  public void setBeamWidth(int beamWidth)
  {
    if (this.¤ != beamWidth)
    {
      int oldValue = this.¤;
      this.¤ = beamWidth;
      firePropertyChange("beamWidth", oldValue, this.¤);
      invalidateAntennaShape();
    }
  }
  
  public int getPower()
  {
    return this.z;
  }
  
  public void setPower(int power)
  {
    if (this.z != power)
    {
      int oldValue = this.z;
      this.z = power;
      firePropertyChange("power", oldValue, this.z);
      invalidateAntennaShape();
    }
  }
  
  public int getAntennaType()
  {
    return this.À;
  }
  
  public void setAntennaType(int antennaType)
  {
    if (((antennaType == 2) || (antennaType == 4) || (antennaType == 1) || (antennaType == 3) || (antennaType == 5)) && (this.À != antennaType))
    {
      int oldValue = this.À;
      this.À = antennaType;
      firePropertyChange("antennaType", oldValue, this.À);
      invalidateAntennaShape();
    }
  }
  
  public void putBTSAntennaArrowShow(boolean show)
  {
    putClientProperty("btsantenna.arrow.show", show);
  }
  
  public void putBTSAntennaArrowColor(Color color)
  {
    putClientProperty("btsantenna.arrow.color", color);
  }
  
  public boolean isBTSAntennaArrowShow()
  {
    return a.K(this, "btsantenna.arrow.show");
  }
  
  public Color getBTSAntennaArrowColor()
  {
    return a.P(this, "btsantenna.arrow.color");
  }
  
  public void putBTSAntennaOutlineShow(boolean show)
  {
    putClientProperty("btsantenna.outline.show", show);
  }
  
  public void putBTSAntennaOutlineColor(Color color)
  {
    putClientProperty("btsantenna.outline.color", color);
  }
  
  public void putBTSAntennaOutlineStroke(String stroke)
  {
    putClientProperty("btsantenna.outline.stroke", stroke);
  }
  
  public boolean isBTSAntennaOutlineShow()
  {
    return a.K(this, "btsantenna.outline.show");
  }
  
  public Color getBTSAntennaOutlineColor()
  {
    return a.P(this, "btsantenna.outline.color");
  }
  
  public Stroke getBTSAntennaOutlineStroke()
  {
    return a.F(this, "btsantenna.outline.stroke");
  }
  
  private void B(double x, double y)
  {
    Point2D.Double oldValue = new Point2D.Double(this.xLocation, this.yLocation);
    this.xLocation = x;
    this.yLocation = y;
    firePropertyChange("location", oldValue, new Point2D.Double(x, y));
  }
  
  public Rectangle getBounds()
  {
    V();
    return (Rectangle)this.x.clone();
  }
  
  public final Point getLocation()
  {
    V();
    return new Point(this.x.x, this.x.y);
  }
  
  public final int getWidth()
  {
    V();
    return this.x.width;
  }
  
  public final int getHeight()
  {
    V();
    return this.x.height;
  }
  
  public void setLocation(Point2D.Double location)
  {
    V();
    super.setLocation(location);
    invalidateAntennaShape();
  }
  
  boolean W()
  {
    return this.¢;
  }
  
  public void invalidateAntennaShape()
  {
    if (this.¢) {
      return;
    }
    this.¢ = true;
    Shape oldShape = this.¥;
    Rectangle oldBounds = this.x;
    float l = this.z * 2;
    double y;
    double x;
    double y;
    if (this.º != null)
    {
      Point point = this.º.getCenterLocation();
      double x = point.x - this.z;
      y = point.y - this.z;
    }
    else
    {
      this.¥ = new Arc2D.Float(0.0F, 0.0F, l, l, this.£ - this.¤ / 2.0F, this.¤, 2);
      Area area = new Area(this.¥);
      this.x = area.getBounds();
      x = this.xLocation - this.x.getX();
      y = this.yLocation - this.x.getY();
    }
    Arc2D arc2D = new Arc2D.Float((float)x, (float)y, l, l, this.£ - this.¤ / 2.0F, this.¤, 2);
    this.¥ = new Area(K.A(arc2D, this.À));
    this.x = this.¥.getBounds();
    this.µ = K.A(arc2D);
    Rectangle arrowBounds = this.µ.getBounds();
    this.y = new Point((int)arrowBounds.getCenterX(), (int)arrowBounds.getCenterY());
    B(this.x.getX(), this.x.getY());
    if (oldBounds != null)
    {
      firePropertyChange("width", oldBounds.width, this.x.width);
      firePropertyChange("height", oldBounds.height, this.x.height);
    }
    else
    {
      firePropertyChange("width", 0, this.x.width);
      firePropertyChange("height", 0, this.x.height);
    }
    firePropertyChange("antennaShape", oldShape, this.¥);
    calculateOffset();
    if (this.º != null) {
      this.º.calculateOffset();
    }
    this.¢ = false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BTSAntenna
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.Icon;
import twaver.base.A.E.c;
import twaver.base.Direction;
import twaver.base.OrthogonalLinkDirectionType;

public class EnumTypeManager
{
  private Map B = new HashMap();
  private static final EnumTypeManager A = new EnumTypeManager();
  private AlarmSeverityChangeListener C = null;
  
  public static EnumTypeManager getInstance()
  {
    return A;
  }
  
  private void A()
  {
    int i = 0;
    EnumType[] types = new EnumType[AlarmSeverity.size()];
    Iterator it = AlarmSeverity.iterator();
    while (it.hasNext())
    {
      AlarmSeverity severity = (AlarmSeverity)it.next();
      types[i] = new EnumType(severity, severity.getDisplayName());
      types[i].setForeground(Color.BLACK);
      types[i].setBackground(severity.getColor());
      i++;
    }
    registerEnumTypes("twaver.alarm.severity", types);
  }
  
  private EnumTypeManager()
  {
    A();
    this.C = new AlarmSeverityChangeListener()
    {
      public boolean alarmSeverityChange()
      {
        EnumTypeManager.this.A();
        return false;
      }
    };
    AlarmSeverity.addAlarmSeverityChangeListener(this.C);
    registerEnumTypes("twaver.inflexion.style", new EnumType[] { C(1, "enum.inflexion.circle"), C(2, "enum.inflexion.diamond"), C(3, "enum.inflexion.rectangle"), C(4, "enum.inflexion.triangle") });
    registerEnumTypes("twaver.direction", new EnumType[] { A(Direction.HORIZONTAL, "enum.direction.horizontal"), A(Direction.VERTICAL, "enum.direction.vertical") });
    registerEnumTypes("twaver.attachment.direction", new EnumType[] { C(1, "enum.attachment.direction.top.left"), C(2, "enum.attachment.direction.top.right"), C(3, "enum.attachment.direction.bottom.left"), C(4, "enum.attachment.direction.bottom.right"), C(5, "enum.attachment.direction.left.top"), C(6, "enum.attachment.direction.left.bottom"), C(7, "enum.attachment.direction.right.top"), C(8, "enum.attachment.direction.right.bottom"), C(9, "enum.attachment.direction.top"), C(10, "enum.attachment.direction.bottom"), C(11, "enum.attachment.direction.left"), C(12, "enum.attachment.direction.right") });
    registerEnumTypes("twaver.joint.point", new EnumType[] { C(1, "enum.joint.point.near"), C(2, "enum.joint.point.north"), C(3, "enum.joint.point.south"), C(4, "enum.joint.point.west"), C(5, "enum.joint.point.east") });
    registerEnumTypes("twaver.message.component", new EnumType[] { C(1, "enum.message.component.label"), C(2, "enum.message.component.textpane") });
    registerEnumTypes("twaver.attachment.style", new EnumType[] { C(1, "enum.attachment.style.default"), C(2, "enum.attachment.style.bubble") });
    registerEnumTypes("twaver.legend.layout", new EnumType[] { C(1, "enum.legend.layout.horizontal"), C(2, "enum.legend.layout.vertical"), C(3, "enum.legend.layout.horizontal.west"), C(4, "enum.legend.layout.horizontal.east"), C(5, "enum.legend.layout.horizontal.north"), C(6, "enum.legend.layout.horizontal.south"), C(7, "enum.legend.layout.vertical.west"), C(8, "enum.legend.layout.vertical.east"), C(9, "enum.legend.layout.vertical.north"), C(10, "enum.legend.layout.vertical.south") });
    registerEnumTypes("twaver.grouptype", new EnumType[] { C(1, "enum.grouptype.rectangle"), C(2, "enum.grouptype.ellipse"), C(3, "enum.grouptype.parallelogram"), C(4, "enum.grouptype.round"), C(5, "enum.grouptype.roundrectangle"), C(6, "enum.grouptype.octagon") });
    registerEnumTypes("twaver.border.type", new EnumType[] { C(1, "enum.bordertype.default"), C(2, "enum.bordertype.point"), C(3, "enum.bordertype.shape") });
    registerEnumTypes("twaver.shapelinktype", new EnumType[] { C(1, "enum.shapelink.straight.line"), C(2, "enum.shapelink.quadratic.curve"), C(3, "enum.shapelink.bezier.curve"), C(4, "enum.shapelink.orthogonal.line") });
    registerEnumTypes("twaver.shapenodetype", new EnumType[] { C(0, "enum.shapenode.none"), C(1, "enum.shapenode.straight.line"), C(2, "enum.shapenode.close.straight.line"), C(3, "enum.shapenode.quadratic.curve"), C(4, "enum.shapenode.close.quadratic.curve"), C(5, "enum.shapenode.bezier.curve"), C(6, "enum.shapenode.close.bezier.curve"), C(7, "enum.shapenode.orthogonal.line"), C(8, "enum.shapenode.ellipse"), C(9, "enum.shapenode.round") });
    registerEnumTypes("twaver.linktype", new EnumType[] { C(0, "enum.linktype.parallel"), C(1, "enum.linktype.straight"), C(2, "enum.linktype.flexional"), C(3, "enum.linktype.orthogonal"), C(4, "enum.linktype.curvous"), C(5, "enum.linktype.zigzag"), C(6, "enum.linktype.xsplit"), C(7, "enum.linktype.ysplit"), C(8, "enum.linktype.top"), C(9, "enum.linktype.bottom"), C(10, "enum.linktype.left"), C(11, "enum.linktype.right") });
    registerEnumTypes("twaver.orientation", new EnumType[] { C(1, "enum.orientation.north"), C(2, "enum.orientation.north.east"), C(3, "enum.orientation.east"), C(4, "enum.orientation.south.east"), C(5, "enum.orientation.south"), C(6, "enum.orientation.south.west"), C(7, "enum.orientation.west"), C(8, "enum.orientation.north.west") });
    registerEnumTypes("twaver.orthogonal", new EnumType[] { new EnumType(OrthogonalLinkDirectionType.X_TO_Y, OrthogonalLinkDirectionType.X_TO_Y.toString()), new EnumType(OrthogonalLinkDirectionType.Y_TO_X, OrthogonalLinkDirectionType.Y_TO_X.toString()) });
    registerEnumTypes("twaver.arrowstyle", new EnumType[] { new EnumType(5, "Delta"), new EnumType(4, "DeltaSmall"), new EnumType(6, "DeltaGreat"), new EnumType(2, "Standard"), new EnumType(1, "StandardSmall"), new EnumType(3, "StandardGreat"), new EnumType(8, "Diamond"), new EnumType(7, "DiamondSmall"), new EnumType(9, "DiamondGreat"), new EnumType(11, "Short"), new EnumType(10, "ShortSmall"), new EnumType(12, "ShortGreat"), new EnumType(14, "Circle"), new EnumType(13, "CircleSmall"), new EnumType(15, "CircleGreat"), new EnumType(17, "Star"), new EnumType(16, "StarSmall"), new EnumType(18, "StarGreat"), new EnumType(20, "Rectangle"), new EnumType(19, "RectangleSmall"), new EnumType(21, "RectangleGreat") });
    registerEnumTypes("twaver.position", new EnumType[] { C(0, "enum.position.hotspot"), C(1, "enum.position.center"), C(3, "enum.position.bottom"), C(2, "enum.position.top"), C(4, "enum.position.left"), C(5, "enum.position.right"), C(6, "enum.position.topleft"), C(7, "enum.position.topright"), C(8, "enum.position.bottomleft"), C(9, "enum.position.bottomright"), C(10, "enum.position.inner.bottom"), C(11, "enum.position.inner.top"), C(12, "enum.position.inner.left"), C(13, "enum.position.inner.right"), C(14, "enum.position.inner.topleft"), C(15, "enum.position.inner.topright"), C(16, "enum.position.inner.bottomleft"), C(17, "enum.position.inner.bottomright") });
    registerEnumTypes("twaver.label.orientation", new EnumType[] { C(1, "enum.label.orientation.horizontal"), C(2, "enum.label.orientation.vertical"), C(3, "enum.label.orientation.left"), C(4, "enum.label.orientation.right") });
    registerEnumTypes("twaver.antennatype", new EnumType[] { C(1, "enum.antennatype.sector"), C(2, "enum.antennatype.ellipse"), C(3, "enum.antennatype.triangle"), C(4, "enum.antennatype.rectangle"), C(5, "enum.antennatype.roundrectangle") });
    registerEnumTypes("twaver.shape", new EnumType[] { A(1, "enum.shape.circle"), A(2, "enum.shape.rectangle"), A(3, "enum.shape.roundrectangle"), A(4, "enum.shape.roundrectangle.half"), A(5, "enum.shape.roundrectangle.quarter"), A(6, "enum.shape.roundvault"), A(7, "enum.shape.roundvault.half"), A(8, "enum.shape.roundvault.quarter"), A(9, "enum.shape.diamond"), A(10, "enum.shape.triangle"), A(11, "enum.shape.star"), A(12, "enum.shape.round"), A(13, "enum.shape.arrow.left"), A(14, "enum.shape.arrow.right"), A(15, "enum.shape.arrow.above"), A(16, "enum.shape.arrow.below"), A(17, "enum.shape.tail.left"), A(18, "enum.shape.tail.right"), A(19, "enum.shape.tail.above"), A(20, "enum.shape.tail.below"), A(21, "enum.shape.card.left"), A(22, "enum.shape.card.right"), A(23, "enum.shape.wave.left"), A(24, "enum.shape.wave.right") });
    registerEnumTypes("twaver.gradient", new EnumType[] { B(1, "enum.gradient.line.sw"), B(2, "enum.gradient.line.se"), B(3, "enum.gradient.line.nw"), B(4, "enum.gradient.line.ne"), B(5, "enum.gradient.line.n"), B(6, "enum.gradient.line.s"), B(7, "enum.gradient.line.w"), B(8, "enum.gradient.line.e"), B(10, "enum.gradient.radial.c"), B(11, "enum.gradient.radial.sw"), B(12, "enum.gradient.radial.se"), B(13, "enum.gradient.radial.nw"), B(14, "enum.gradient.radial.ne"), B(15, "enum.gradient.radial.n"), B(16, "enum.gradient.radial.s"), B(17, "enum.gradient.radial.w"), B(18, "enum.gradient.radial.e"), B(19, "enum.gradient.extend.horizontal"), B(20, "enum.gradient.extend.vertical"), B(21, "enum.gradient.extend.diagonal"), B(22, "enum.gradient.extend.antidiagonal"), B(23, "enum.gradient.extend.n"), B(24, "enum.gradient.extend.s"), B(25, "enum.gradient.extend.w"), B(26, "enum.gradient.extend.e") });
  }
  
  public void registerEnumTypes(String enumTypeName, EnumType[] enumTypes)
  {
    if (enumTypes == null)
    {
      this.B.remove(enumTypeName);
      return;
    }
    Map map = new TreeMap();
    for (int i = 0; i < enumTypes.length; i++) {
      map.put(enumTypes[i].getValue(), enumTypes[i]);
    }
    this.B.put(enumTypeName, map);
  }
  
  public Object[] getEnumTypes(String enumTypeName)
  {
    Map map = (Map)this.B.get(enumTypeName);
    if (map == null) {
      return null;
    }
    return map.values().toArray();
  }
  
  public EnumType getEnumType(String enumTypeName, Object value)
  {
    if (value == null) {
      return null;
    }
    Map map = (Map)this.B.get(enumTypeName);
    if (map == null) {
      return null;
    }
    return (EnumType)map.get(value);
  }
  
  private static EnumType C(int type, String i18nKey)
  {
    return new EnumType(type, TWaverUtil.getString(i18nKey));
  }
  
  private static EnumType A(Comparable type, String i18nKey)
  {
    return new EnumType(type, TWaverUtil.getString(i18nKey));
  }
  
  private static EnumType A(int type, String i18nKey)
  {
    Icon icon = c.A(16, 12, null, null, Color.DARK_GRAY, type, -1);
    return new EnumType(type, TWaverUtil.getString(i18nKey), icon);
  }
  
  private static EnumType B(int type, String i18nKey)
  {
    Icon icon = c.A(16, 12, Color.WHITE, Color.BLACK, null, 2, type);
    return new EnumType(type, TWaverUtil.getString(i18nKey), icon);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.EnumTypeManager
 * JD-Core Version:    0.7.0.1
 */
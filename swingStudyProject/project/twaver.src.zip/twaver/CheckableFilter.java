package twaver;

public abstract interface CheckableFilter
  extends Filter
{
  public abstract boolean isCheckable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.CheckableFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Graphics;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.ImageIcon;

public class ShapeImage
  extends ShapeNode
{
  private ImageIcon U = null;
  private BufferedImage T = null;
  
  public ShapeImage()
  {
    J();
  }
  
  public ShapeImage(Object id)
  {
    super(id);
    J();
  }
  
  private void J()
  {
    setShapeNodeType(2);
    getClientProperties().put("custom.draw.fill", Boolean.FALSE);
    getClientProperties().put("custom.draw.outline", Boolean.FALSE);
    getClientProperties().put("custom.draw.outline.stroke", "solid.middle");
    List points = new ArrayList();
    points.add(new Point2D.Double(50.0D, 50.0D));
    points.add(new Point2D.Double(100.0D, 50.0D));
    points.add(new Point2D.Double(100.0D, 150.0D));
    points.add(new Point2D.Double(50.0D, 150.0D));
    setPoints(points);
  }
  
  public String getUIClassID()
  {
    return "ShapeImageUI";
  }
  
  public ImageIcon getCachedImage()
  {
    if (this.U != null) {
      return this.U;
    }
    if (this.points.size() == 4)
    {
      ImageIcon imageIcon = getImage();
      if (imageIcon != null)
      {
        if (this.T == null)
        {
          this.T = new BufferedImage(imageIcon.getIconWidth(), imageIcon.getIconHeight(), 2);
          Graphics g2 = this.T.createGraphics();
          g2.drawImage(imageIcon.getImage(), 0, 0, null);
          g2.dispose();
        }
        this.U = TWaverUtil.createDistortedImage(this.T, getPoint(0).getX(), getPoint(0).getY(), getPoint(1).getX(), getPoint(1).getY(), getPoint(2).getX(), getPoint(2).getY(), getPoint(3).getX(), getPoint(3).getY());
      }
    }
    return this.U;
  }
  
  public void invalidateCachedImage()
  {
    this.U = null;
    this.T = null;
  }
  
  public void firePointsChange()
  {
    super.firePointsChange();
    this.U = null;
  }
  
  public void setImage(String url)
  {
    super.setImage(url);
    invalidateCachedImage();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ShapeImage
 * JD-Core Version:    0.7.0.1
 */
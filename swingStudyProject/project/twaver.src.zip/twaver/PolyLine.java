package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;

public class PolyLine
  extends Link
{
  protected List segments = new ArrayList();
  protected List branchs = new ArrayList();
  protected Object blinkingObject = null;
  private PropertyChangeListener J = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent evt)
    {
      String propertyName = evt.getPropertyName();
      if ((propertyName.equals("fromNode")) || (propertyName.equals("toNode")))
      {
        Node oldNode = (Node)evt.getOldValue();
        if (oldNode != null) {
          oldNode.removePropertyChangeListener(PolyLine.this.K);
        }
        Node newNode = (Node)evt.getNewValue();
        if (newNode != null)
        {
          newNode.removePropertyChangeListener(PolyLine.this.K);
          newNode.addPropertyChangeListener(PolyLine.this.K);
        }
      }
      PolyLine.this.firePropertyChange("segment", evt.getOldValue(), evt.getNewValue());
    }
  };
  private PropertyChangeListener L = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent evt)
    {
      String propertyName = evt.getPropertyName();
      if (propertyName.equals("segment"))
      {
        Segment segment = (Segment)evt.getOldValue();
        if (segment != null) {
          PolyLine.this.removeSegment(segment);
        }
        segment = (Segment)evt.getNewValue();
        if (segment != null) {
          PolyLine.this.addSegment(segment);
        }
      }
      PolyLine.this.firePropertyChange("segment", evt.getOldValue(), evt.getNewValue());
    }
  };
  private PropertyChangeListener K = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent evt)
    {
      PolyLine.this.handleNodePropertyChange(evt);
    }
  };
  
  protected void handleNodePropertyChange(PropertyChangeEvent evt)
  {
    if (isShapeFrozen()) {
      return;
    }
    if (evt.getPropertyName().equals("location")) {
      firePropertyChange("segment", evt.getOldValue(), evt.getNewValue());
    }
  }
  
  public PolyLine() {}
  
  public PolyLine(Object id)
  {
    super(id);
  }
  
  public PolyLine(Node from, Node to)
  {
    setFrom(from);
    setTo(to);
  }
  
  public PolyLine(Object id, Node from, Node to)
  {
    super(id);
    setFrom(from);
    setTo(to);
  }
  
  public boolean isAdjustToBottom()
  {
    return true;
  }
  
  public void addBranch(Branch branch)
  {
    if (this.branchs.contains(branch)) {
      return;
    }
    branch.getPropertyChangeSupport().addPropertyChangeListener(this.L);
    this.branchs.add(branch);
    branch.A(this);
    List branchSegments = branch.getSegments();
    for (int i = 0; i < branchSegments.size(); i++)
    {
      Segment segment = (Segment)branchSegments.get(i);
      addSegment(segment);
    }
  }
  
  public void removeBranch(Branch branch)
  {
    if (branch == this.blinkingObject) {
      setBlinkingObject(null);
    }
    branch.getPropertyChangeSupport().removePropertyChangeListener(this.L);
    this.branchs.remove(branch);
    branch.A(null);
    List branchSegments = branch.getSegments();
    for (int i = 0; i < branchSegments.size(); i++)
    {
      Segment segment = (Segment)branchSegments.get(i);
      removeSegment(segment);
    }
  }
  
  public void clearBranchs()
  {
    while (this.branchs.size() > 0) {
      removeBranch((Branch)this.branchs.get(0));
    }
  }
  
  public void setBranchs(List branchs)
  {
    clearBranchs();
    for (int i = 0; i < branchs.size(); i++) {
      addBranch((Branch)branchs.get(i));
    }
  }
  
  public void setSegments(List segments)
  {
    clearSegments();
    for (int i = 0; i < segments.size(); i++) {
      addSegment((Segment)segments.get(i));
    }
  }
  
  public void clearSegments()
  {
    while (this.segments.size() > 0) {
      removeSegment((Segment)this.segments.get(0));
    }
  }
  
  public void addSegment(Segment segment)
  {
    if (this.segments.contains(segment)) {
      return;
    }
    this.segments.add(segment);
    segment.setPolyLine(this);
    segment.getPropertyChangeSupport().addPropertyChangeListener(this.J);
    Node node = segment.getFromNode();
    if (node != null)
    {
      node.removePropertyChangeListener(this.K);
      node.addPropertyChangeListener(this.K);
    }
    node = segment.getToNode();
    if (node != null)
    {
      node.removePropertyChangeListener(this.K);
      node.addPropertyChangeListener(this.K);
    }
    firePropertyChange("segment", null, segment);
  }
  
  public void removeSegment(Segment segment)
  {
    if (segment == this.blinkingObject) {
      setBlinkingObject(null);
    }
    this.segments.remove(segment);
    segment.setPolyLine(null);
    segment.getPropertyChangeSupport().removePropertyChangeListener(this.J);
    Node node = segment.getFromNode();
    if (node != null) {
      node.removePropertyChangeListener(this.K);
    }
    node = segment.getToNode();
    if (node != null) {
      node.removePropertyChangeListener(this.K);
    }
    firePropertyChange("segment", segment, null);
  }
  
  public void insertSegment(int index, Segment segment)
  {
    if (this.segments.contains(segment)) {
      return;
    }
    this.segments.add(index, segment);
    segment.setPolyLine(this);
    segment.getPropertyChangeSupport().addPropertyChangeListener(this.J);
    Node node = segment.getFromNode();
    if (node != null)
    {
      node.removePropertyChangeListener(this.K);
      node.addPropertyChangeListener(this.K);
    }
    node = segment.getToNode();
    if (node != null)
    {
      node.removePropertyChangeListener(this.K);
      node.addPropertyChangeListener(this.K);
    }
    firePropertyChange("segment", null, segment);
  }
  
  public List getAllNodes()
  {
    List list = new ArrayList();
    for (int i = 0; i < this.segments.size(); i++)
    {
      Segment segment = (Segment)this.segments.get(i);
      Node node = segment.getFromNode();
      if ((node != null) && (!list.contains(node))) {
        list.add(node);
      }
      node = segment.getToNode();
      if ((node != null) && (!list.contains(node))) {
        list.add(node);
      }
    }
    return list;
  }
  
  public List getOrderSegments()
  {
    if (this.branchs.size() == 0) {
      return getSegments();
    }
    List segments = new ArrayList();
    for (int i = 0; i < this.branchs.size(); i++)
    {
      Branch branch = (Branch)this.branchs.get(i);
      segments.addAll(branch.getSegments());
    }
    return segments;
  }
  
  public String getUIClassID()
  {
    return "PolyLineUI";
  }
  
  public String getSVGUIClassID()
  {
    return "PolyLineSVGUI";
  }
  
  public List getSegments()
  {
    return this.segments;
  }
  
  public List getBranchs()
  {
    return this.branchs;
  }
  
  public Object getBlinkingObject()
  {
    return this.blinkingObject;
  }
  
  public void setBlinkingObject(Object blinkingObject)
  {
    Object oldValue = this.blinkingObject;
    this.blinkingObject = blinkingObject;
    firePropertyChange("blinkingObject", oldValue, this.blinkingObject);
  }
  
  public boolean isBlinking(Segment segment)
  {
    if (this.blinkingObject != null)
    {
      if (this.blinkingObject == this) {
        return true;
      }
      if (segment == this.blinkingObject) {
        return true;
      }
      if (segment.getBranch() == this.blinkingObject) {
        return true;
      }
    }
    return false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PolyLine
 * JD-Core Version:    0.7.0.1
 */
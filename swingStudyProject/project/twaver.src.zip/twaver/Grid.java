package twaver;

import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import java.beans.PropertyChangeEvent;
import java.util.List;
import twaver.base.A.E.a;

public class Grid
  extends BaseEquipment
{
  private int m = 1;
  private int i = 1;
  private int l = -2147483648;
  private int j = -2147483648;
  private int k = 1;
  private int q = 1;
  private Insets n = TUIManager.getInsets("padding");
  private Insets h = TUIManager.getInsets("border");
  private List o = null;
  private List g = null;
  private boolean p = TUIManager.getBoolean("paintCell");
  
  public Grid()
  {
    R();
  }
  
  public Grid(Object id)
  {
    super(id);
    R();
  }
  
  private void R()
  {
    setSize(100, 80);
  }
  
  public String getUIClassID()
  {
    return "GridUI";
  }
  
  public String getSVGUIClassID()
  {
    return "GridSVGUI";
  }
  
  public int getRowCount()
  {
    return this.m;
  }
  
  public void setRowCount(int rowCount)
  {
    int oldValue = this.m;
    this.m = rowCount;
    firePropertyChange("rowCount", oldValue, rowCount);
  }
  
  public int getColumnCount()
  {
    return this.i;
  }
  
  public void setColumnCount(int columnCount)
  {
    int oldValue = this.i;
    this.i = columnCount;
    firePropertyChange("columnCount", oldValue, columnCount);
  }
  
  public int getRowIndex()
  {
    return this.l;
  }
  
  public void setRowIndex(int rowIndex)
  {
    int oldValue = this.l;
    this.l = rowIndex;
    firePropertyChange("rowIndex", oldValue, rowIndex);
    adjustBounds();
  }
  
  public int getColumnIndex()
  {
    return this.j;
  }
  
  public void setColumnIndex(int columnIndex)
  {
    int oldValue = this.j;
    this.j = columnIndex;
    firePropertyChange("columnIndex", oldValue, this.l);
    adjustBounds();
  }
  
  public int getRowSpan()
  {
    return this.k;
  }
  
  public void setRowSpan(int rowSpan)
  {
    int oldValue = this.k;
    this.k = rowSpan;
    firePropertyChange("rowSpan", oldValue, rowSpan);
    adjustBounds();
  }
  
  public int getColumnSpan()
  {
    return this.q;
  }
  
  public void setColumnSpan(int columnSpan)
  {
    int oldValue = this.q;
    this.q = columnSpan;
    firePropertyChange("columnSpan", oldValue, columnSpan);
    adjustBounds();
  }
  
  public Insets getPadding()
  {
    return this.n;
  }
  
  public void setPadding(Insets padding)
  {
    if (padding == null) {
      padding = new Insets(0, 0, 0, 0);
    }
    Insets oldValue = this.n;
    this.n = padding;
    firePropertyChange("padding", oldValue, padding);
  }
  
  public Insets getBorder()
  {
    return this.h;
  }
  
  public void setBorder(Insets border)
  {
    if (border == null) {
      border = new Insets(0, 0, 0, 0);
    }
    Insets oldValue = this.h;
    this.h = border;
    firePropertyChange("border", oldValue, border);
  }
  
  public boolean isPaintCell()
  {
    return this.p;
  }
  
  public void setPaintCell(boolean paintCell)
  {
    boolean oldValue = this.p;
    this.p = paintCell;
    firePropertyChange("paintCell", oldValue, paintCell);
  }
  
  public List getColumnPercents()
  {
    return this.o;
  }
  
  public void setColumnPercents(List columnPercents)
  {
    List oldValue = this.o;
    this.o = columnPercents;
    firePropertyChange("columnPercents", oldValue, columnPercents);
  }
  
  public List getRowPercents()
  {
    return this.g;
  }
  
  public void setRowPercents(List rowPercents)
  {
    List oldValue = this.g;
    this.g = rowPercents;
    firePropertyChange("rowPercents", oldValue, rowPercents);
  }
  
  protected void hostPropertyChange(PropertyChangeEvent evt)
  {
    String propertyName = a.A(evt);
    if ((propertyName.equals("rowCount")) || (propertyName.equals("columnCount")) || (propertyName.equals("padding")) || (propertyName.equals("border")) || (propertyName.equals("columnPercents")) || (propertyName.equals("rowPercents")) || (propertyName.equals("size")) || (propertyName.equals("location"))) {
      adjustBounds();
    }
  }
  
  public void adjustBounds()
  {
    if (!(getHost() instanceof Grid)) {
      return;
    }
    if ((this.l == -2147483648) || (this.j == -2147483648)) {
      return;
    }
    Grid grid = (Grid)getHost();
    Rectangle2D rect = grid.getCellRect(this.j, this.l);
    if (rect == null) {
      return;
    }
    if ((this.k != 1) || (this.q != 1))
    {
      Rectangle2D rect2 = grid.getCellRect(this.j + this.q - 1, this.l + this.k - 1);
      if (rect2 != null) {
        rect.add(rect2);
      }
    }
    setLocation(rect.getX(), rect.getY());
    setWidthSize((int)rect.getWidth());
    setHeightSize((int)rect.getHeight());
  }
  
  public Rectangle2D.Double getCellRectangle(int columnIndex, int rowIndex)
  {
    Point location = getLocation();
    int x = location.x + this.h.left;
    int y = location.y + this.h.top;
    int w = getWidth() - (this.h.left + this.h.right);
    int h = getHeight() - (this.h.top + this.h.bottom);
    double left = A(w, this.i, columnIndex, this.o);
    double top = A(h, this.m, rowIndex, this.g);
    double rx = x + this.n.left + left;
    double ry = y + this.n.top + top;
    double rw = B(w, columnIndex) - (this.n.left + this.n.right);
    double rh = A(h, rowIndex) - (this.n.top + this.n.bottom);
    return new Rectangle2D.Double(rx, ry, rw, rh);
  }
  
  public Rectangle2D.Double getCellBounds(int columnIndex, int rowIndex)
  {
    Point location = getLocation();
    int x = location.x + this.h.left;
    int y = location.y + this.h.top;
    int w = getWidth() - (this.h.left + this.h.right);
    int h = getHeight() - (this.h.top + this.h.bottom);
    double left = A(w, this.i, columnIndex, this.o);
    double top = A(h, this.m, rowIndex, this.g);
    double rx = x + left;
    double ry = y + top;
    double rw = B(w, columnIndex);
    double rh = A(h, rowIndex);
    return new Rectangle2D.Double(rx, ry, rw, rh);
  }
  
  public Rectangle getCellRect(int columnIndex, int rowIndex)
  {
    Point location = getLocation();
    int x = location.x + this.h.left;
    int y = location.y + this.h.top;
    int w = getWidth() - (this.h.left + this.h.right);
    int h = getHeight() - (this.h.top + this.h.bottom);
    double left = A(w, this.i, columnIndex, this.o);
    double top = A(h, this.m, rowIndex, this.g);
    double rx = x + this.n.left + left;
    double ry = y + this.n.top + top;
    double rw = B(w, columnIndex) - (this.n.left + this.n.right);
    double rh = A(h, rowIndex) - (this.n.top + this.n.bottom);
    return new Rectangle((int)rx, (int)ry, (int)rw, (int)rh);
  }
  
  private double A(int width, int columnCount, int columnIndex, List percents)
  {
    if ((percents != null) && (!percents.isEmpty()))
    {
      double leftPercent = 0.0D;
      int size = percents.size();
      for (int i = 0; i < columnIndex; i++)
      {
        if (i >= size) {
          break;
        }
        double percent = ((Double)percents.get(i)).doubleValue();
        leftPercent += percent;
      }
      double allw = width * leftPercent;
      if (columnIndex >= size) {
        if (percents == this.o)
        {
          int restCount = getColumnCount() - size;
          double restCellW = getRestWidth() / restCount;
          allw += restCellW * (columnIndex - size);
        }
        else
        {
          int restCount = getRowCount() - size;
          double restCellH = getRestHeight() / restCount;
          allw += restCellH * (columnIndex - size);
        }
      }
      return allw;
    }
    return width * columnIndex / columnCount;
  }
  
  public double getRestWidth()
  {
    int size = this.o.size();
    int width = getWidth() - (this.h.left + this.h.right);
    double sum = 0.0D;
    for (int i = 0; i < size; i++) {
      sum += Double.parseDouble(this.o.get(i).toString());
    }
    if (sum >= 1.0D) {
      return 0.0D;
    }
    double restPercent = 1.0D - sum;
    double w = width * restPercent;
    return w;
  }
  
  public double getRestHeight()
  {
    int size = this.g.size();
    double sum = 0.0D;
    int height = getHeight() - (this.h.top + this.h.bottom);
    for (int i = 0; i < size; i++) {
      sum += Double.parseDouble(this.g.get(i).toString());
    }
    if (sum >= 1.0D) {
      return 0.0D;
    }
    double restPercent = 1.0D - sum;
    double w = height * restPercent;
    return w;
  }
  
  private double B(int width, int columnIndex)
  {
    if ((this.o != null) && (!this.o.isEmpty()))
    {
      if (columnIndex < this.o.size()) {
        return ((Double)this.o.get(columnIndex)).doubleValue() * width;
      }
      double restW = getRestWidth();
      int restCount = getColumnCount() - this.o.size();
      return restW / restCount;
    }
    return width / this.i;
  }
  
  private double A(int height, int rowIndex)
  {
    if ((this.g != null) && (!this.g.isEmpty()))
    {
      if (rowIndex < this.g.size()) {
        return ((Double)this.g.get(rowIndex)).doubleValue() * height;
      }
      double restH = getRestHeight();
      int restCount = getRowCount() - this.g.size();
      return restH / restCount;
    }
    return height / this.m;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Grid
 * JD-Core Version:    0.7.0.1
 */
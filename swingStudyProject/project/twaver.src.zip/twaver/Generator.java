package twaver;

public abstract interface Generator
{
  public abstract Object generate(Object paramObject);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Generator
 * JD-Core Version:    0.7.0.1
 */
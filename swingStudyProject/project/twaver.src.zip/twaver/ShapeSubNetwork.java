package twaver;

import java.awt.Color;
import java.awt.Point;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import twaver.network.background.Background;
import twaver.network.background.ColorBackground;
import twaver.network.background.ImageBackground;
import twaver.network.background.TextureBackground;

public class ShapeSubNetwork
  extends ShapeNode
  implements TSubNetwork
{
  private Background Q = null;
  private String S = null;
  private boolean R = false;
  private Point P = null;
  
  public ShapeSubNetwork()
  {
    A(null);
  }
  
  public ShapeSubNetwork(Object id)
  {
    super(id);
    A(null);
  }
  
  public ShapeSubNetwork(Shape baseShape)
  {
    A(baseShape);
  }
  
  public ShapeSubNetwork(Object id, Shape baseShape)
  {
    super(id);
    A(baseShape);
  }
  
  private void A(Shape baseShape)
  {
    setShapeNodeType(1);
    getClientProperties().put("texture.factory", "stipple.middle");
    getClientProperties().put("custom.draw.gradient", Boolean.FALSE);
    getClientProperties().put("custom.draw.fill", Boolean.TRUE);
    if (baseShape == null)
    {
      List ps = new ArrayList();
      ps.add(new Point(125, 75));
      ps.add(new Point(100, 118));
      ps.add(new Point(51, 118));
      ps.add(new Point(25, 75));
      ps.add(new Point(50, 32));
      ps.add(new Point(100, 32));
      setPoints(ps);
    }
    else
    {
      setBaseShape(baseShape);
    }
  }
  
  public Point getViewPoint()
  {
    return this.P;
  }
  
  public void setViewPoint(Point viewPoint)
  {
    Object oldValue = this.P;
    this.P = viewPoint;
    firePropertyChange("viewPoint", oldValue, viewPoint);
  }
  
  public Background getBackground()
  {
    return this.Q;
  }
  
  public void setBackground(Background background)
  {
    Background oldvalue = this.Q;
    this.Q = background;
    firePropertyChange("background", oldvalue, this.Q);
  }
  
  public void setTextureBackground(String imageURL)
  {
    setBackground(new TextureBackground(imageURL));
  }
  
  public void setImageBackground(String imageURL)
  {
    setBackground(new ImageBackground(imageURL));
  }
  
  public void setColorBackground(Color color)
  {
    setBackground(new ColorBackground(color));
  }
  
  public String getDataSource()
  {
    return this.S;
  }
  
  public void setDataSource(String dataSource)
  {
    Object oldValue = this.S;
    this.S = dataSource;
    firePropertyChange("dataSource", oldValue, dataSource);
  }
  
  public boolean isDataLoaded()
  {
    return this.R;
  }
  
  public void setDataLoaded(boolean dataLoaded)
  {
    boolean oldValue = this.R;
    this.R = dataLoaded;
    firePropertyChange("dataLoaded", oldValue, dataLoaded);
  }
  
  public String getSVGUIClassID()
  {
    return "ShapeSubNetworkSVGUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ShapeSubNetwork
 * JD-Core Version:    0.7.0.1
 */
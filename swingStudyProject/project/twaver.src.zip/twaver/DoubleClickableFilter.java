package twaver;

public abstract interface DoubleClickableFilter
  extends Filter
{
  public abstract boolean isDoubleClickable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DoubleClickableFilter
 * JD-Core Version:    0.7.0.1
 */
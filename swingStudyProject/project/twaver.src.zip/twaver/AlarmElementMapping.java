package twaver;

public abstract interface AlarmElementMapping
{
  public abstract Object getCorrespondingAlarms(TDataBox paramTDataBox, Element paramElement);
  
  public abstract Object getCorrespondingElements(TDataBox paramTDataBox, Alarm paramAlarm);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmElementMapping
 * JD-Core Version:    0.7.0.1
 */
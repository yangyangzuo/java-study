package twaver;

import java.awt.geom.Point2D.Double;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BTS
  extends BaseEquipment
{
  private List f = new ArrayList();
  private boolean e = true;
  
  public BTS()
  {
    Q();
  }
  
  public BTS(Object id)
  {
    super(id);
    Q();
  }
  
  private void Q()
  {
    setSize(20, 20);
    getClientProperties().put("custom.draw", Boolean.TRUE);
  }
  
  public void addAntenna(BTSAntenna antenna)
  {
    if ((antenna != null) && (!this.f.contains(antenna)))
    {
      this.f.add(antenna);
      antenna.setBTS(this);
      P();
      firePropertyChange("antenna", null, antenna);
    }
  }
  
  public void removeAntenna(BTSAntenna antenna)
  {
    if ((antenna != null) && (this.f.contains(antenna)))
    {
      this.f.remove(antenna);
      antenna.setBTS(null);
      antenna.setHost(null);
      P();
      firePropertyChange("antenna", antenna, null);
    }
  }
  
  public List getAntennas()
  {
    return this.f;
  }
  
  public void setAntennas(List antennas)
  {
    if (antennas != null) {
      for (int i = 0; i < antennas.size(); i++) {
        addAntenna((BTSAntenna)antennas.get(i));
      }
    }
  }
  
  public void clearAntennas()
  {
    while (this.f.size() > 0) {
      removeAntenna((BTSAntenna)this.f.get(0));
    }
  }
  
  public boolean isRingHost()
  {
    return this.e;
  }
  
  public void setRingHost(boolean isRingHost)
  {
    if (this.e == isRingHost) {
      return;
    }
    boolean oldValue = this.e;
    this.e = isRingHost;
    firePropertyChange("ringHost", oldValue, isRingHost);
    P();
  }
  
  void P()
  {
    if (isRingHost())
    {
      Follower host = this;
      for (int i = 0; i < this.f.size(); i++)
      {
        BTSAntenna follower = (BTSAntenna)this.f.get(i);
        follower.setHost(host);
        if (i == this.f.size() - 1) {
          setHost(follower);
        } else {
          host = follower;
        }
      }
    }
    else
    {
      for (int i = 0; i < this.f.size(); i++)
      {
        BTSAntenna follower = (BTSAntenna)this.f.get(i);
        follower.setHost(this);
      }
    }
  }
  
  public void setLocation(Point2D.Double location)
  {
    for (int i = 0; i < this.f.size(); i++)
    {
      BTSAntenna antenna = (BTSAntenna)this.f.get(i);
      if (antenna.W()) {
        return;
      }
    }
    super.setLocation(location);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BTS
 * JD-Core Version:    0.7.0.1
 */
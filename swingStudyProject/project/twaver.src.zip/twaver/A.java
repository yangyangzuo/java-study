package twaver;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

class A
  extends TreeMap
{
  Map C = new HashMap();
  Map A = new HashMap();
  Map B = new HashMap();
  
  public A()
  {
    this.C.put("label.font", null);
    this.C.put("message.font", null);
    this.C.put("link.handler.font", null);
    this.C.put("tchart.legend.font", null);
    this.C.put("tchart.xaxis.text.font", null);
    this.C.put("tchart.yaxis.text.font", null);
    this.C.put("tchart.xaxis.unit.font", null);
    this.C.put("tchart.yaxis.unit.font", null);
    this.B.put("tchart.percent.label.font", null);
    this.B.put("tchart.value.text.font", null);
    this.B.put("tchart.yscale.text.font", null);
    this.B.put("tchart.xscale.text.font", null);
    this.B.put("tchart.dial.scale.text.font", null);
    this.B.put("tchart.radar.axis.text.font", null);
    this.B.put("tchart.radar.scale.major.text.font", null);
    this.A.put("alarm.balloon.text.font", null);
  }
  
  public Object A(Object key, int value)
  {
    return put(key, TWaverUtil.valueOf(value));
  }
  
  public Object get(Object key)
  {
    Object value = super.get(key);
    if (value == null)
    {
      if (this.C.containsKey(key)) {
        return TUIManager.getDefaultFont();
      }
      if (this.A.containsKey(key)) {
        return TUIManager.getDefaultBoldFont();
      }
      if (this.B.containsKey(key)) {
        return TUIManager.getDefault10SizeFont();
      }
    }
    return value;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.A
 * JD-Core Version:    0.7.0.1
 */
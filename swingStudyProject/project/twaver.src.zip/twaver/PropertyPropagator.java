package twaver;

public abstract interface PropertyPropagator
{
  public abstract void propagateToParent(Element paramElement1, Element paramElement2);
  
  public abstract TDataBox getDataBox();
  
  public abstract String getPropertyName();
  
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean isStarted();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PropertyPropagator
 * JD-Core Version:    0.7.0.1
 */
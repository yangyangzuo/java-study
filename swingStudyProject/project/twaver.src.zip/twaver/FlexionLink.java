package twaver;

public class FlexionLink
  extends Link
{
  public FlexionLink()
  {
    B();
  }
  
  public FlexionLink(Object id)
  {
    super(id);
    B();
  }
  
  public FlexionLink(Node from, Node to)
  {
    super(from, to);
    B();
  }
  
  public FlexionLink(Object id, Node from, Node to)
  {
    super(id, from, to);
    B();
  }
  
  private void B()
  {
    setLinkType(2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.FlexionLink
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import twaver.base.A.E.V;
import twaver.base.A.E.a;

public class BaseElement
  extends AbstractElement
  implements Cloneable
{
  protected double xLocation = 0.0D;
  protected double yLocation = 0.0D;
  
  public BaseElement() {}
  
  public BaseElement(Object id)
  {
    super(id);
  }
  
  public Rectangle getBounds()
  {
    return new Rectangle((int)this.xLocation, (int)this.yLocation, getWidth(), getHeight());
  }
  
  public Point getCenterLocation()
  {
    Rectangle rect = getBounds();
    return new Point((int)rect.getCenterX(), (int)rect.getCenterY());
  }
  
  public void setCenterLocation(double x, double y)
  {
    Rectangle rect = getBounds();
    setLocation(x - rect.width / 2, y - rect.height / 2);
  }
  
  public void setCenterLocation(Point2D location)
  {
    setCenterLocation(location.getX(), location.getY());
  }
  
  public Point getLocation()
  {
    return new Point((int)this.xLocation, (int)this.yLocation);
  }
  
  public void setLocation(Point location)
  {
    if (location != null) {
      setLocation(new Point2D.Double(location.x, location.y));
    }
  }
  
  public void setLocation(int x, int y)
  {
    setLocation(new Point2D.Double(x, y));
  }
  
  public void setLocation(double x, double y)
  {
    setLocation(new Point2D.Double(x, y));
  }
  
  public void setLocation(Point2D.Double location)
  {
    if (location != null)
    {
      Point2D.Double oldValue = new Point2D.Double(this.xLocation, this.yLocation);
      this.xLocation = location.getX();
      this.yLocation = location.getY();
      firePropertyChange("location", oldValue, location);
    }
  }
  
  public double getX()
  {
    return this.xLocation;
  }
  
  public double getY()
  {
    return this.yLocation;
  }
  
  public int getWidth()
  {
    return V.H(this);
  }
  
  public int getHeight()
  {
    return V.A(this);
  }
  
  public String getUIClassID()
  {
    return "BaseElementUI";
  }
  
  public String getSVGUIClassID()
  {
    return "BaseElementSVGUI";
  }
  
  public void putBodyColor(Color color)
  {
    putClientProperty("body.color", color);
  }
  
  public void putBodyRaised(boolean bodyRaised)
  {
    putClientProperty("body.raised", Boolean.valueOf(bodyRaised));
  }
  
  public void putBodyFill(boolean bodyFill)
  {
    putClientProperty("body.fill", bodyFill);
  }
  
  public void putCustomDraw(boolean customDraw)
  {
    putClientProperty("custom.draw", customDraw);
  }
  
  public void putCustomDrawShapeFactory(int customDrawShapeFactory)
  {
    putClientProperty("custom.draw.shape.factory", customDrawShapeFactory);
  }
  
  public void putCustomDrawDefaultBorder(boolean customDrawDefaultBorder)
  {
    putClientProperty("custom.draw.default.border", customDrawDefaultBorder);
  }
  
  public void putCustomDrawAntialias(boolean customDrawAntialias)
  {
    putClientProperty("custom.draw.antialias", customDrawAntialias);
  }
  
  public void putCustomDrawFill(boolean customDrawFill)
  {
    putClientProperty("custom.draw.fill", customDrawFill);
  }
  
  public void putCustomDrawFill3D(boolean customDrawFill3D)
  {
    putClientProperty("custom.draw.fill.3d", customDrawFill3D);
  }
  
  public void putCustomDrawFillColor(Color customDrawFillColor)
  {
    putClientProperty("custom.draw.fill.color", customDrawFillColor);
  }
  
  public void putCustomDrawOutline(boolean customDrawOutline)
  {
    putClientProperty("custom.draw.outline", customDrawOutline);
  }
  
  public void putCustomDrawOutline3D(boolean customDrawOutline3D)
  {
    putClientProperty("custom.draw.outline.3d", customDrawOutline3D);
  }
  
  public void putCustomDrawOutlineColor(Color customDrawOutlineColor)
  {
    putClientProperty("custom.draw.outline.color", customDrawOutlineColor);
  }
  
  public void putCustomDrawOutlineStroke(String customDrawOutlineStroke)
  {
    putClientProperty("custom.draw.outline.stroke", customDrawOutlineStroke);
  }
  
  public void putCustomDrawGradient(boolean customDrawGradient)
  {
    putClientProperty("custom.draw.gradient", customDrawGradient);
  }
  
  public void putCustomDrawGradientFactory(int customDrawGradientFactory)
  {
    putClientProperty("custom.draw.gradient.factory", customDrawGradientFactory);
  }
  
  public void putCustomDrawGradientColor(Color customDrawGradientColor)
  {
    putClientProperty("custom.draw.gradient.color", customDrawGradientColor);
  }
  
  public Color getBodyColor()
  {
    return a.P(this, "body.color");
  }
  
  public boolean isBodyFill()
  {
    return a.K(this, "body.fill");
  }
  
  public boolean isCustomDraw()
  {
    return a.K(this, "custom.draw");
  }
  
  public int getCustomDrawShapeFactory()
  {
    return a.J(this, "custom.draw.shape.factory");
  }
  
  public boolean isCustomDrawDefaultBorder()
  {
    return a.K(this, "custom.draw.default.border");
  }
  
  public boolean isCustomDrawAntialias()
  {
    return a.K(this, "custom.draw.antialias");
  }
  
  public boolean isCustomDrawFill()
  {
    return a.K(this, "custom.draw.fill");
  }
  
  public boolean isCustomDrawFill3D()
  {
    return a.K(this, "custom.draw.fill.3d");
  }
  
  public Color getCustomDrawFillColor()
  {
    return a.P(this, "custom.draw.fill.color");
  }
  
  public boolean isCustomDrawOutline()
  {
    return a.K(this, "custom.draw.outline");
  }
  
  public boolean isCustomDrawOutline3D()
  {
    return a.K(this, "custom.draw.outline.3d");
  }
  
  public Color getCustomDrawOutlineColor()
  {
    return a.P(this, "custom.draw.outline.color");
  }
  
  public Stroke getCustomDrawOutlineStroke()
  {
    return a.F(this, "custom.draw.outline.stroke");
  }
  
  public boolean isCustomDrawGradient()
  {
    return a.K(this, "custom.draw.gradient");
  }
  
  public int getCustomDrawGradientFactory()
  {
    return a.J(this, "custom.draw.gradient.factory");
  }
  
  public Color getCustomDrawGradientColor()
  {
    return a.P(this, "custom.draw.gradient.color");
  }
  
  public boolean isBodyRaised()
  {
    return a.K(this, "body.raised");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BaseElement
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface ExportValuesInterceptor
  extends Interceptor
{
  public abstract void exportValues(Element paramElement1, Element paramElement2, TDataBox paramTDataBox);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ExportValuesInterceptor
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DefaultAlarmElementMapping
  implements AlarmElementMapping
{
  public Object getCorrespondingAlarms(TDataBox box, Element element)
  {
    if (element == null) {
      return null;
    }
    List list = new ArrayList();
    Iterator it = box.getAlarmModel().iterator();
    while (it.hasNext())
    {
      Alarm alarm = (Alarm)it.next();
      if (element.getID().equals(alarm.getElementID())) {
        list.add(alarm);
      }
    }
    return list;
  }
  
  public Object getCorrespondingElements(TDataBox box, Alarm alarm)
  {
    if (alarm == null) {
      return null;
    }
    Object elementID = alarm.getElementID();
    if (elementID != null) {
      return box.getElementByID(elementID);
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DefaultAlarmElementMapping
 * JD-Core Version:    0.7.0.1
 */
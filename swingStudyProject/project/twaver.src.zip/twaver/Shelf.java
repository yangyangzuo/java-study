package twaver;

import java.awt.Point;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.util.Map;
import twaver.base.A.E.E;
import twaver.base.A.E.a;
import twaver.base.Direction;

public class Shelf
  extends BaseEquipment
{
  private int u = -1;
  private int t = -1;
  
  public Shelf()
  {
    T();
  }
  
  public Shelf(Object id)
  {
    super(id);
    T();
  }
  
  public boolean isAdjustToBottom()
  {
    return E.A(this);
  }
  
  protected void hostPropertyChange(PropertyChangeEvent evt)
  {
    String propertyName = a.A(evt);
    if ((propertyName.equals("equip.direction")) || (propertyName.equals("equipCount")) || (propertyName.equals("size")) || (propertyName.equals("location")) || (propertyName.equals("shelf.border")) || (propertyName.equals("shelf.inner.border"))) {
      adjustBounds();
    }
  }
  
  private void T()
  {
    setSize(100, 80);
    getClientProperties().put("border.insets", TWaverUtil.valueOf(-2));
  }
  
  public int getEquipCount()
  {
    return this.u;
  }
  
  public void setEquipCount(int equipCount)
  {
    int oldValue = this.u;
    this.u = equipCount;
    firePropertyChange("equipCount", oldValue, equipCount);
  }
  
  public int getEquipIndex()
  {
    return this.t;
  }
  
  public void setEquipIndex(int equipIndex)
  {
    int oldValue = this.t;
    this.t = equipIndex;
    firePropertyChange("equipIndex", oldValue, equipIndex);
    adjustBounds();
  }
  
  public Rectangle getEquipBoundsByIndex(int equipIndex)
  {
    if ((this.u <= 0) || (equipIndex < 0) || (equipIndex >= this.u)) {
      return null;
    }
    int shelfBorder = a.J(this, "shelf.border");
    int shelfInnerBorder = a.J(this, "shelf.inner.border");
    Point location = getLocation();
    int x = location.x + shelfBorder;
    int y = location.y + shelfBorder;
    int w = getWidth() - shelfBorder * 2;
    int h = getHeight() - shelfBorder * 2;
    if (Direction.VERTICAL.equals(getEquipDirection()))
    {
      double span = w / this.u;
      x = (int)(x + span * equipIndex);
      return new Rectangle(x + shelfInnerBorder, y + shelfInnerBorder, (int)span - shelfInnerBorder * 2, h - shelfInnerBorder * 2);
    }
    double span = h / this.u;
    y = (int)(y + span * equipIndex);
    return new Rectangle(x + shelfInnerBorder, y + shelfInnerBorder, w - shelfInnerBorder * 2, (int)span - shelfInnerBorder * 2);
  }
  
  public void adjustBounds()
  {
    Node host = getHost();
    if ((host instanceof Shelf))
    {
      Shelf shelf = (Shelf)host;
      if ((this.t >= 0) && (this.t < shelf.getEquipCount()))
      {
        Rectangle bounds = shelf.getEquipBoundsByIndex(this.t);
        if (bounds != null)
        {
          setLocation(bounds.x, bounds.y);
          setSize(bounds.width, bounds.height);
        }
      }
    }
  }
  
  public String getUIClassID()
  {
    return "ShelfUI";
  }
  
  public String getSVGUIClassID()
  {
    return "ShelfSVGUI";
  }
  
  public void putEquipDirection(Direction equipDirection)
  {
    putClientProperty("equip.direction", equipDirection);
  }
  
  public Direction getEquipDirection()
  {
    return a.E(this, "equip.direction");
  }
  
  public void putShelfBorder(int shelfBorder)
  {
    putClientProperty("shelf.border", shelfBorder);
  }
  
  public int getShelfBorder()
  {
    return a.J(this, "shelf.border");
  }
  
  public void putShelfInnerBorder(int shelfInnerBorder)
  {
    putClientProperty("shelf.inner.border", shelfInnerBorder);
  }
  
  public int getShelfInnerBorder()
  {
    return a.J(this, "shelf.inner.border");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Shelf
 * JD-Core Version:    0.7.0.1
 */
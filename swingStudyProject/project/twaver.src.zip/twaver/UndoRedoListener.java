package twaver;

public abstract interface UndoRedoListener
{
  public abstract void undid(Object paramObject);
  
  public abstract void redid(Object paramObject);
  
  public abstract void eventAdded(Object paramObject);
  
  public abstract void eventRemoved(Object paramObject);
  
  public abstract void reset();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.UndoRedoListener
 * JD-Core Version:    0.7.0.1
 */
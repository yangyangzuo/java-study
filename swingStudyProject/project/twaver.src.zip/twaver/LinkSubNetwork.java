package twaver;

import java.awt.Color;
import java.awt.Point;
import twaver.network.background.Background;
import twaver.network.background.ColorBackground;
import twaver.network.background.ImageBackground;
import twaver.network.background.TextureBackground;

public class LinkSubNetwork
  extends Link
  implements TSubNetwork
{
  private Background É = null;
  private String Ë = null;
  private boolean Ê = false;
  private Point È = null;
  
  public LinkSubNetwork() {}
  
  public LinkSubNetwork(Object id)
  {
    super(id);
  }
  
  public LinkSubNetwork(Node from, Node to)
  {
    super(from, to);
  }
  
  public LinkSubNetwork(Object id, Node from, Node to)
  {
    super(id, from, to);
  }
  
  public Point getViewPoint()
  {
    return this.È;
  }
  
  public void setViewPoint(Point viewPoint)
  {
    Object oldValue = this.È;
    this.È = viewPoint;
    firePropertyChange("viewPoint", oldValue, viewPoint);
  }
  
  public Background getBackground()
  {
    return this.É;
  }
  
  public void setBackground(Background background)
  {
    Background oldvalue = this.É;
    this.É = background;
    firePropertyChange("background", oldvalue, this.É);
  }
  
  public void setTextureBackground(String imageURL)
  {
    setBackground(new TextureBackground(imageURL));
  }
  
  public void setImageBackground(String imageURL)
  {
    setBackground(new ImageBackground(imageURL));
  }
  
  public void setColorBackground(Color color)
  {
    setBackground(new ColorBackground(color));
  }
  
  public String getDataSource()
  {
    return this.Ë;
  }
  
  public void setDataSource(String dataSource)
  {
    Object oldValue = this.Ë;
    this.Ë = dataSource;
    firePropertyChange("dataSource", oldValue, dataSource);
  }
  
  public boolean isDataLoaded()
  {
    return this.Ê;
  }
  
  public void setDataLoaded(boolean dataLoaded)
  {
    boolean oldValue = this.Ê;
    this.Ê = dataLoaded;
    firePropertyChange("dataLoaded", oldValue, dataLoaded);
  }
  
  public String getSVGUIClassID()
  {
    return "LinkSubNetworkSVGUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.LinkSubNetwork
 * JD-Core Version:    0.7.0.1
 */
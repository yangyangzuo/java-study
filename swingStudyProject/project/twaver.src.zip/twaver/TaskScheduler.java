package twaver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.SwingUtilities;
import twaver.base.A.D.A.B;
import twaver.base.A.G.H;

public class TaskScheduler
  extends Thread
{
  private final Object B = new Object();
  private HashMap G = null;
  private List F = null;
  private Runnable C = null;
  private int J = 500;
  private long D = 0L;
  private static TaskScheduler I;
  private boolean K = false;
  private boolean E = false;
  private List H = new ArrayList();
  private List A = new ArrayList();
  
  private TaskScheduler(int minInterval)
  {
    this.J = minInterval;
    this.G = new HashMap();
    this.F = new LinkedList();
    this.C = new Runnable()
    {
      public void run()
      {
        if (!TaskScheduler.this.isRunning()) {
          return;
        }
        synchronized (TaskScheduler.this)
        {
          TaskScheduler.this.E = true;
          TaskScheduler.this.D += 1L;
          Iterator it = TaskScheduler.this.F.iterator();
          while (it.hasNext())
          {
            Task task = (Task)it.next();
            if (task.interested())
            {
              long interval = task.getInterval();
              long multiple = Math.round((float)interval / TaskScheduler.this.J);
              if (multiple < 1L) {
                multiple = 1L;
              }
              if (TaskScheduler.this.D % multiple == 0L) {
                task.run(TaskScheduler.this.D);
              }
            }
          }
          TaskScheduler.this.E = false;
          if (TaskScheduler.this.H.size() > 0)
          {
            for (int i = 0; i < TaskScheduler.this.A.size(); i++)
            {
              Boolean addOrRemove = (Boolean)TaskScheduler.this.A.get(i);
              Task task = (Task)TaskScheduler.this.H.get(i);
              if (addOrRemove.booleanValue()) {
                TaskScheduler.this.register(task);
              } else {
                TaskScheduler.this.unregister(task);
              }
            }
            TaskScheduler.this.H.clear();
            TaskScheduler.this.A.clear();
          }
        }
      }
    };
  }
  
  public void start(String threadName)
  {
    if (this.K) {
      throw new IllegalStateException("Can not restart task scheduler when it's running.");
    }
    this.K = true;
    setName(threadName);
    setPriority(1);
    setDaemon(true);
    start();
  }
  
  public static synchronized TaskScheduler getInstance()
  {
    if ((I == null) || (!I.isRunning()))
    {
      I = new TaskScheduler(500);
      I.start("TaskScheduler Thread");
      I.register(B.C());
      I.register(H.A());
    }
    return I;
  }
  
  public static synchronized TaskScheduler createTaskScheduler(int minInterval)
  {
    return new TaskScheduler(minInterval);
  }
  
  public synchronized boolean register(Task task)
  {
    if (this.E)
    {
      this.A.add(Boolean.TRUE);
      this.H.add(task);
      return false;
    }
    if ((task == null) || (this.G.containsKey(task))) {
      return false;
    }
    this.F.add(task);
    this.G.put(task, this.B);
    return true;
  }
  
  public synchronized boolean unregister(Task task)
  {
    if (this.E)
    {
      this.A.add(Boolean.FALSE);
      this.H.add(task);
      return false;
    }
    if (!this.G.containsKey(task)) {
      return false;
    }
    this.F.remove(task);
    this.G.remove(task);
    return true;
  }
  
  public void run()
  {
    try
    {
      int interval = this.J;
      while (this.K) {
        try
        {
          Thread.sleep(interval + 1);
          synchronized (this)
          {
            if ((!this.F.isEmpty()) || (!this.H.isEmpty()))
            {
              SwingUtilities.invokeLater(this.C);
              interval = this.J;
            }
            else if (interval < 200)
            {
              interval = 200;
            }
          }
        }
        catch (InterruptedException e)
        {
          this.K = false;
        }
      }
    }
    catch (Throwable throwable)
    {
      this.K = false;
    }
  }
  
  public int getMinInterval()
  {
    return this.J;
  }
  
  public void setMinInterval(int minInterval)
  {
    this.J = minInterval;
  }
  
  public boolean isRunning()
  {
    return this.K;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TaskScheduler
 * JD-Core Version:    0.7.0.1
 */
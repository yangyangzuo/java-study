package twaver;

import java.awt.geom.Point2D;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import twaver.base.A.E.K;

public class ShapeLink
  extends Link
{
  protected List points = new ArrayList();
  protected int shapeLinkType = 1;
  
  public ShapeLink() {}
  
  public ShapeLink(Object id)
  {
    super(id);
  }
  
  public ShapeLink(Node from, Node to)
  {
    super(from, to);
  }
  
  public ShapeLink(Object id, Node from, Node to)
  {
    super(id, from, to);
  }
  
  public String getUIClassID()
  {
    return "ShapeLinkUI";
  }
  
  public String getSVGUIClassID()
  {
    return "ShapeLinkSVGUI";
  }
  
  public List getPoints()
  {
    return this.points;
  }
  
  public Point2D[] toPoints()
  {
    Point2D[] ps = (Point2D[])Array.newInstance(Point2D.class, this.points.size());
    this.points.toArray(ps);
    return ps;
  }
  
  public Point2D getPoint(int index)
  {
    if ((index >= 0) && (index < this.points.size())) {
      return (Point2D)this.points.get(index);
    }
    return null;
  }
  
  public void setPoints(List points)
  {
    this.points = K.A(points);
    firePointsChange();
  }
  
  public void setPoint(int index, Point2D point)
  {
    if ((index >= 0) && (index < this.points.size()))
    {
      this.points.set(index, K.A(point));
      firePointsChange();
    }
  }
  
  public void insertPoint(int index, Point2D point)
  {
    if ((index >= 0) && (index <= this.points.size()))
    {
      this.points.add(index, K.A(point));
      firePointsChange();
    }
  }
  
  public void removePoint(int index)
  {
    if ((index >= 0) && (index < this.points.size()))
    {
      this.points.remove(index);
      firePointsChange();
    }
  }
  
  public void addPoint(Point2D point)
  {
    if (point != null)
    {
      this.points.add(K.A(point));
      firePointsChange();
    }
  }
  
  public void clear()
  {
    if (this.points.size() > 0)
    {
      this.points.clear();
      firePointsChange();
    }
  }
  
  public void firePointsChange()
  {
    firePropertyChange("points", null, this.points);
  }
  
  public int getShapeLinkType()
  {
    return this.shapeLinkType;
  }
  
  public void setShapeLinkType(int shapeLinkType)
  {
    if (this.shapeLinkType != shapeLinkType)
    {
      int oldValue = this.shapeLinkType;
      this.shapeLinkType = shapeLinkType;
      firePropertyChange("shapeLinkType", oldValue, shapeLinkType);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ShapeLink
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.EventListener;

public abstract interface DataBoxSelectionListener
  extends EventListener
{
  public abstract void selectionChanged(DataBoxSelectionEvent paramDataBoxSelectionEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSelectionListener
 * JD-Core Version:    0.7.0.1
 */
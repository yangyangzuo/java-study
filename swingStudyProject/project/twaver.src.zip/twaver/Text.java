package twaver;

public class Text
  extends Follower
{
  public Text()
  {
    N();
  }
  
  public Text(Object id)
  {
    super(id);
    N();
  }
  
  private void N()
  {
    setName("text");
    putLabelPosition(1);
  }
  
  public String getUIClassID()
  {
    return "TextUI";
  }
  
  public String getSVGUIClassID()
  {
    return "TextSVGUI";
  }
  
  public int getHeight()
  {
    return 0;
  }
  
  public int getWidth()
  {
    return 0;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Text
 * JD-Core Version:    0.7.0.1
 */
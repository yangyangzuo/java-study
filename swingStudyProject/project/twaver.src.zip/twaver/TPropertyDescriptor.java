package twaver;

import java.lang.reflect.Method;

public abstract interface TPropertyDescriptor
{
  public abstract ElementAttribute getElementAttribute();
  
  public abstract void setElementAttribute(ElementAttribute paramElementAttribute);
  
  public abstract Method getReadMethod();
  
  public abstract Method getWriteMethod();
  
  public abstract String getDisplayName();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TPropertyDescriptor
 * JD-Core Version:    0.7.0.1
 */
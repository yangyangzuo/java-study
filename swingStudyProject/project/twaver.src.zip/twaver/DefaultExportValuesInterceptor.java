package twaver;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DefaultExportValuesInterceptor
  implements ExportValuesInterceptor
{
  protected void exportParent(Element source, Element target, TDataBox box)
  {
    target.setParent(source.getParent());
  }
  
  protected void exportChildren(Element source, Element target, TDataBox box)
  {
    List children = source.getChildren();
    if (children != null) {
      for (int i = 0; i < children.size(); i++)
      {
        Element element = (Element)children.get(i);
        Element copyElement = element.copy(box);
        target.addChild(copyElement);
        if (box != null) {
          box.addElement(copyElement);
        }
      }
    }
  }
  
  protected void exportAlarmState(Element source, Element target, TDataBox box)
  {
    AlarmState sourceState = source.getAlarmState();
    AlarmState targetState = target.getAlarmState();
    Iterator it = AlarmSeverity.iterator();
    while (it.hasNext())
    {
      AlarmSeverity severity = (AlarmSeverity)it.next();
      targetState.setNewAlarmCount(severity, sourceState.getNewAlarmCount(severity));
      targetState.setAcknowledgedAlarmCount(severity, sourceState.getAcknowledgedAlarmCount(severity));
    }
  }
  
  protected void exportHost(Follower source, Follower target, TDataBox box)
  {
    target.setHost(source.getHost());
  }
  
  protected void exportFrom(Link source, Link target, TDataBox box)
  {
    target.setFrom(source.getFrom());
  }
  
  protected void exportTo(Link source, Link target, TDataBox box)
  {
    target.setTo(source.getTo());
  }
  
  protected void exportBTS(BTSAntenna source, BTSAntenna target, TDataBox box)
  {
    target.setBTS(source.getBTS());
  }
  
  public void exportValues(Element source, Element target, TDataBox box)
  {
    if (TUIManager.isPredefinedPropertyCopied("children")) {
      exportChildren(source, target, box);
    }
    if (TUIManager.isPredefinedPropertyCopied("layerID")) {
      target.setLayerID(source.getLayerID());
    }
    if (TUIManager.isPredefinedPropertyCopied("icon")) {
      target.setIcon(source.getIconURL());
    }
    if (TUIManager.isPredefinedPropertyCopied("image")) {
      target.setImage(source.getImageURL());
    }
    if (TUIManager.isPredefinedPropertyCopied("alarmState")) {
      exportAlarmState(source, target, box);
    }
    if (TUIManager.isPredefinedPropertyCopied("name")) {
      target.setName(source.getName());
    }
    if (TUIManager.isPredefinedPropertyCopied("displayName")) {
      target.setDisplayName(source.getDisplayName());
    }
    if (TUIManager.isPredefinedPropertyCopied("enableAlarmPropagationFromChildren")) {
      target.setEnableAlarmPropagationFromChildren(source.isEnableAlarmPropagationFromChildren());
    }
    if (TUIManager.isPredefinedPropertyCopied("parent")) {
      exportParent(source, target, box);
    }
    if (TUIManager.isPredefinedPropertyCopied("userObject")) {
      target.setUserObject(source.getUserObject());
    }
    if (TUIManager.isPredefinedPropertyCopied("toolTipText")) {
      target.setToolTipText(source.getToolTipText());
    }
    if (TUIManager.isPredefinedPropertyCopied("selected")) {
      target.setSelected(source.isSelected());
    }
    if (TUIManager.isPredefinedPropertyCopied("visible")) {
      target.setVisible(source.isVisible());
    }
    if (TUIManager.isPredefinedPropertyCopied("location")) {
      target.setLocation(source.getX(), source.getY());
    }
    if (((target instanceof ResizableNode)) && ((source instanceof ResizableNode)))
    {
      ResizableNode t = (ResizableNode)target;
      ResizableNode s = (ResizableNode)source;
      if (TUIManager.isPredefinedPropertyCopied("size"))
      {
        t.setSize(s.getSize());
      }
      else
      {
        if (TUIManager.isPredefinedPropertyCopied("width")) {
          t.setWidthSize(s.getWidth());
        }
        if (TUIManager.isPredefinedPropertyCopied("height")) {
          t.setHeightSize(s.getHeight());
        }
      }
    }
    if (((target instanceof PolySubNetwork)) && ((source instanceof PolySubNetwork)))
    {
      PolySubNetwork t = (PolySubNetwork)target;
      PolySubNetwork s = (PolySubNetwork)source;
      if (TUIManager.isPredefinedPropertyCopied("baseShape")) {
        t.setBaseShape(s.getBaseShape());
      }
    }
    if (((target instanceof TSubNetwork)) && ((source instanceof TSubNetwork)))
    {
      TSubNetwork t = (TSubNetwork)target;
      TSubNetwork s = (TSubNetwork)source;
      if (TUIManager.isPredefinedPropertyCopied("background")) {
        t.setBackground(s.getBackground());
      }
      if (TUIManager.isPredefinedPropertyCopied("dataSource")) {
        t.setDataSource(s.getDataSource());
      }
      if (TUIManager.isPredefinedPropertyCopied("dataLoaded")) {
        t.setDataLoaded(s.isDataLoaded());
      }
      if (TUIManager.isPredefinedPropertyCopied("viewPoint")) {
        t.setViewPoint(s.getViewPoint());
      }
    }
    if (((target instanceof Follower)) && ((source instanceof Follower)) && (TUIManager.isPredefinedPropertyCopied("host"))) {
      exportHost((Follower)source, (Follower)target, box);
    }
    if (((target instanceof RotatableNode)) && ((source instanceof RotatableNode)))
    {
      RotatableNode s = (RotatableNode)source;
      RotatableNode t = (RotatableNode)target;
      if (TUIManager.isPredefinedPropertyCopied("zoom")) {
        t.setZoom(s.getZoom());
      }
      if (TUIManager.isPredefinedPropertyCopied("angle")) {
        t.setAngle(s.getAngle());
      }
    }
    if (((target instanceof Equipment)) && ((source instanceof Equipment)))
    {
      Equipment t = (Equipment)target;
      Equipment s = (Equipment)source;
      if (TUIManager.isPredefinedPropertyCopied("exist")) {
        t.setExist(s.isExist());
      }
      if (TUIManager.isPredefinedPropertyCopied("tag")) {
        t.setTag(s.getTag());
      }
    }
    if (((target instanceof Link)) && ((source instanceof Link)))
    {
      Link t = (Link)target;
      Link s = (Link)source;
      if (TUIManager.isPredefinedPropertyCopied("from")) {
        exportFrom(s, t, box);
      }
      if (TUIManager.isPredefinedPropertyCopied("to")) {
        exportTo(s, t, box);
      }
      if (TUIManager.isPredefinedPropertyCopied("linkType")) {
        t.setLinkType(s.getLinkType());
      }
    }
    if (((target instanceof Group)) && ((source instanceof Group)))
    {
      Group t = (Group)target;
      Group s = (Group)source;
      if (TUIManager.isPredefinedPropertyCopied("expand")) {
        t.setExpand(s.isExpand());
      }
      if (TUIManager.isPredefinedPropertyCopied("groupType")) {
        t.setGroupType(s.getGroupType());
      }
    }
    if (((target instanceof ShapeNode)) && ((source instanceof ShapeNode)))
    {
      ShapeNode t = (ShapeNode)target;
      ShapeNode s = (ShapeNode)source;
      if (TUIManager.isPredefinedPropertyCopied("shapeNodeType")) {
        t.setShapeNodeType(s.getShapeNodeType());
      }
      if (TUIManager.isPredefinedPropertyCopied("points"))
      {
        List list = new ArrayList();
        List points = s.getPoints();
        for (int i = 0; i < points.size(); i++)
        {
          Point2D point = (Point2D)points.get(i);
          list.add((Point2D)point.clone());
        }
        t.setPoints(list);
        if (s.getSegments() == null) {
          t.setSegments(null);
        } else {
          t.setSegments(new ArrayList(s.getSegments()));
        }
      }
    }
    if (((target instanceof ShapeLink)) && ((source instanceof ShapeLink)))
    {
      ShapeLink t = (ShapeLink)target;
      ShapeLink s = (ShapeLink)source;
      if (TUIManager.isPredefinedPropertyCopied("points"))
      {
        List list = new ArrayList();
        List points = s.getPoints();
        for (int i = 0; i < points.size(); i++)
        {
          Point2D point = (Point2D)points.get(i);
          list.add((Point2D)point.clone());
        }
        t.setPoints(list);
      }
    }
    if (((target instanceof BTSAntenna)) && ((source instanceof BTSAntenna)))
    {
      BTSAntenna t = (BTSAntenna)target;
      BTSAntenna s = (BTSAntenna)source;
      if (TUIManager.isPredefinedPropertyCopied("power")) {
        t.setPower(s.getPower());
      }
      if (TUIManager.isPredefinedPropertyCopied("beamDirection")) {
        t.setBeamDirection(s.getBeamDirection());
      }
      if (TUIManager.isPredefinedPropertyCopied("beamWidth")) {
        t.setBeamWidth(s.getBeamWidth());
      }
      if (TUIManager.isPredefinedPropertyCopied("beamAlpha")) {
        t.setBeamAlpha(s.getBeamAlpha());
      }
      if (TUIManager.isPredefinedPropertyCopied("antennaType")) {
        t.setAntennaType(s.getAntennaType());
      }
      if (TUIManager.isPredefinedPropertyCopied("BTS")) {
        exportBTS(s, t, box);
      }
    }
    if (((target instanceof PolyLine)) && ((source instanceof PolyLine)))
    {
      PolyLine t = (PolyLine)target;
      PolyLine s = (PolyLine)source;
      if (TUIManager.isPredefinedPropertyCopied("blinkingObject")) {
        t.setBlinkingObject(s.getBlinkingObject());
      }
    }
    if (((target instanceof Shelf)) && ((source instanceof Shelf)))
    {
      Shelf t = (Shelf)target;
      Shelf s = (Shelf)source;
      if (TUIManager.isPredefinedPropertyCopied("equipIndex")) {
        t.setEquipIndex(s.getEquipIndex());
      }
      if (TUIManager.isPredefinedPropertyCopied("equipCount")) {
        t.setEquipCount(s.getEquipCount());
      }
    }
    if (((target instanceof Slot)) && ((source instanceof Slot)))
    {
      Slot t = (Slot)target;
      Slot s = (Slot)source;
      if (TUIManager.isPredefinedPropertyCopied("equipIndex")) {
        t.setEquipIndex(s.getEquipIndex());
      }
      if (TUIManager.isPredefinedPropertyCopied("equipCount")) {
        t.setEquipCount(s.getEquipCount());
      }
    }
    if (TUIManager.isPredefinedPropertyCopied("businessObject")) {
      target.setBusinessObject(source.getBusinessObject());
    }
    boolean all = TUIManager.isPredefinedPropertyCopied("all.clientproperties");
    Iterator it = source.getClientProperties().keySet().iterator();
    while (it.hasNext())
    {
      String clientPropertyKey = it.next().toString();
      if ((all) || (TUIManager.isPredefinedPropertyCopied(clientPropertyKey)))
      {
        Object sourceValue = source.getClientProperty(clientPropertyKey);
        target.putClientProperty(clientPropertyKey, sourceValue);
      }
    }
    all = TUIManager.isPredefinedPropertyCopied("all.userproperties");
    if (all)
    {
      it = source.getUserProperties().keySet().iterator();
      while (it.hasNext())
      {
        String userPropertyKey = it.next().toString();
        Object sourceValue = source.getUserProperty(userPropertyKey);
        target.putUserProperty(userPropertyKey, sourceValue);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DefaultExportValuesInterceptor
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.io.Serializable;

public abstract interface DataLoader
  extends Serializable
{
  public abstract void load(TSubNetwork paramTSubNetwork, TDataBox paramTDataBox);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataLoader
 * JD-Core Version:    0.7.0.1
 */
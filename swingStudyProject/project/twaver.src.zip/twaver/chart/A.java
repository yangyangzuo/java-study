package twaver.chart;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;
import javax.swing.JComponent;

class A
  extends JComponent
{
  AbstractChart A;
  
  public A(AbstractChart chart)
  {
    this.A = chart;
    setOpaque(false);
    setToolTipText("");
  }
  
  protected void paintComponent(Graphics g)
  {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D)g;
    Object oldValue = g2d.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
    if (this.A.antialias) {
      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    } else {
      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    }
    this.A.shapeStructs.clear();
    g2d.translate(this.A.getXTranslate(), this.A.getYTranslate());
    this.A.paintChart(g2d, (int)(getWidth() * this.A.getXZoom()), (int)(getHeight() * this.A.getYZoom()));
    g2d.translate(-this.A.getXTranslate(), -this.A.getYTranslate());
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, oldValue);
    if (isShowing()) {
      twaver.base.A.G.C.A(this, (Graphics2D)g);
    }
  }
  
  public String getToolTipText(MouseEvent e)
  {
    if (!this.A.isEnableToolTipText()) {
      return null;
    }
    Point point = e.getPoint();
    Point tmp18_17 = point;
    tmp18_17.x = ((int)(tmp18_17.x - this.A.getXTranslate()));
    Point tmp36_35 = point;
    tmp36_35.y = ((int)(tmp36_35.y - this.A.getYTranslate()));
    Iterator it = this.A.shapeStructs.iterator();
    String text = null;
    while (it.hasNext())
    {
      C shapeStruct = (C)it.next();
      if (shapeStruct.A.contains(point))
      {
        text = shapeStruct.E;
        if ((text != null) && (!text.trim().equals(""))) {
          break;
        }
      }
    }
    return text;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.chart.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.chart;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import twaver.Element;
import twaver.TDataBox;
import twaver.TUIManager;
import twaver.TWaverConst;
import twaver.web.svg.chart.AbstractSVGChart;
import twaver.web.svg.chart.AbstractSVGScaleChart;

public abstract class AbstractScaleChart
  extends AbstractChart
{
  protected boolean xAxisVisible = TUIManager.getBoolean("tchart.xaxis.visible");
  protected Color xAxisFillColor = TUIManager.getColor("tchart.xaxis.fill.color");
  protected Color xAxisOutlineColor = TUIManager.getColor("tchart.xaxis.outline.color");
  protected Font xAxisTextFont = TUIManager.getFont("tchart.xaxis.text.font");
  protected Color xAxisTextColor = TUIManager.getColor("tchart.xaxis.text.color");
  protected String xAxisText = TUIManager.getString("tchart.xaxis.text");
  protected double xAxisValue = TUIManager.getDouble("tchart.xaxis.value");
  protected String xAxisStroke = TUIManager.getString("tchart.xaxis.stroke");
  protected boolean yAxisVisible = TUIManager.getBoolean("tchart.yaxis.visible");
  protected Color yAxisFillColor = TUIManager.getColor("tchart.yaxis.fill.color");
  protected Color yAxisOutlineColor = TUIManager.getColor("tchart.yaxis.outline.color");
  protected Font yAxisTextFont = TUIManager.getFont("tchart.yaxis.text.font");
  protected Color yAxisTextColor = TUIManager.getColor("tchart.yaxis.text.color");
  protected String yAxisText = TUIManager.getString("tchart.yaxis.text");
  protected String yAxisStroke = TUIManager.getString("tchart.yaxis.stroke");
  protected String yScaleLineStroke = TUIManager.getString("tchart.yscale.line.stroke");
  protected Color yScaleLineColor = TUIManager.getColor("tchart.yscale.line.color");
  protected boolean yScaleLineVisible = TUIManager.getBoolean("tchart.yscale.line.visible");
  protected int yScalePixelGap = TUIManager.getInt("tchart.yscale.pixel.gap");
  protected double yScaleValueGap = TUIManager.getDouble("tchart.yscale.value.gap");
  protected boolean yScaleMinTextVisible = TUIManager.getBoolean("tchart.yscale.min.text.visible");
  protected boolean yScaleTextVisible = TUIManager.getBoolean("tchart.yscale.text.visible");
  protected boolean yScaleTextInside = TUIManager.getBoolean("tchart.yscale.text.inside");
  protected NumberFormat yScaleTextFormat = TUIManager.getNumberFormat("tchart.yscale.text.format");
  protected Color yScaleTextColor = TUIManager.getColor("tchart.yscale.text.color");
  protected Font yScaleTextFont = TUIManager.getFont("tchart.yscale.text.font");
  protected Font xScaleTextFont = TUIManager.getFont("tchart.xscale.text.font");
  protected Color xScaleTextColor = TUIManager.getColor("tchart.xscale.text.color");
  protected boolean xScaleTextVisible = TUIManager.getBoolean("tchart.xscale.text.visible");
  protected int xScaleTextOrientation = TUIManager.getInt("tchart.xscale.text.orientation");
  protected List xScaleTextList = null;
  protected boolean yScaleValueGapAutoCalculate = TUIManager.getBoolean("tchart.yscale.value.gap.auto.calculate");
  protected boolean yscaleAutoCaculateFlag = false;
  protected int startIndex = 0;
  protected int endIndex = 2147483647;
  protected int valueSpanCount = 1;
  protected int xScaleTextSpanCount = -1;
  protected List markers = null;
  boolean ɤ = true;
  
  public AbstractScaleChart() {}
  
  public AbstractScaleChart(TDataBox box)
  {
    super(box, null, null);
  }
  
  public AbstractScaleChart(TDataBox box, String title, Color backgroundColor)
  {
    super(box, title, backgroundColor, null);
  }
  
  public AbstractScaleChart(TDataBox box, String title, Color backgroundColor, Color foregroundColor)
  {
    super(box, title, backgroundColor, foregroundColor);
  }
  
  public AbstractScaleChart(List items)
  {
    super(items);
  }
  
  public AbstractScaleChart(List items, String title)
  {
    super(items, title);
  }
  
  public AbstractScaleChart(List items, String title, Color backgroundColor)
  {
    super(items, title, backgroundColor);
  }
  
  public AbstractScaleChart(List items, String title, Color backgroundColor, Color foregroundColor)
  {
    super(items, title, backgroundColor, foregroundColor);
  }
  
  protected double toValidHeight(double height)
  {
    if (this.upperLimit == -1.797693134862316E+308D) {
      return height * 0.9D;
    }
    return height;
  }
  
  protected int getXAxisExtraGap(Graphics2D g2d)
  {
    return 0;
  }
  
  public void paintChart(Graphics2D g2d, int width, int height)
  {
    g2d.setStroke(TWaverConst.BASIC_STROKE);
    boolean drawXAxisText = (this.xAxisText != null) && (!this.xAxisText.trim().equals(""));
    int xAxisTextGap;
    int xAxisTextGap;
    if (drawXAxisText)
    {
      Dimension size = A(this.xAxisText, this.xAxisTextFont);
      xAxisTextGap = size.height + getXAxisExtraGap(g2d);
    }
    else
    {
      xAxisTextGap = getXAxisExtraGap(g2d);
    }
    int baseLine = height - this.yGap - xAxisTextGap - this.shadowOffset;
    int yAxisHeight = height - 2 * this.yGap - this.shadowOffset - xAxisTextGap;
    boolean drawYAxisText = (this.yAxisText != null) && (!this.yAxisText.trim().equals(""));
    int yAxisTextGapTemp;
    int yAxisTextGapTemp;
    if (drawYAxisText)
    {
      Dimension size = A(3, this.yAxisText, this.yAxisTextFont);
      yAxisTextGapTemp = size.width;
    }
    else
    {
      yAxisTextGapTemp = 0;
    }
    double valueGap;
    double pixelGap;
    double valueGap;
    if (this.yScaleValueGap > 0.0D)
    {
      double pixelGap = Math.max(this.yScaleValueGap / this.range * toValidHeight(yAxisHeight), 1.0D);
      valueGap = this.yScaleValueGap;
    }
    else
    {
      pixelGap = Math.max(this.yScalePixelGap, 1);
      valueGap = this.range * (pixelGap / toValidHeight(yAxisHeight));
    }
    int maxYScaleTextGap = 0;
    if ((this.yScaleTextVisible) && (this.yScaleTextColor != null) && (this.yScaleTextFont != null))
    {
      if (!this.yScaleTextInside)
      {
        double lineCursor = this.yScaleMinTextVisible ? 0.0D : pixelGap;
        for (double value = this.min + (this.yScaleMinTextVisible ? 0.0D : valueGap); lineCursor <= yAxisHeight + 1; value += valueGap)
        {
          String text = getFormatedYScaleText(value);
          Dimension size = A(text, this.yScaleTextFont);
          if (size.width > maxYScaleTextGap) {
            maxYScaleTextGap = size.width;
          }
          lineCursor += pixelGap;
        }
      }
      double lineCursor = this.yScaleMinTextVisible ? 0.0D : pixelGap;
      for (double value = this.min + (this.yScaleMinTextVisible ? 0.0D : valueGap); lineCursor <= yAxisHeight + 1; value += valueGap)
      {
        String text = getFormatedYScaleText(value);
        if (this.yScaleTextInside)
        {
          int x = this.xGap + yAxisTextGapTemp + this.shadowOffset;
          int y = baseLine - (int)lineCursor;
          A(g2d, text, this.yScaleTextColor, this.yScaleTextFont, x + this.textGap, y + 2, 7);
        }
        else
        {
          int x = this.xGap + yAxisTextGapTemp + maxYScaleTextGap;
          int y = baseLine - (int)lineCursor + this.shadowOffset;
          A(g2d, text, this.yScaleTextColor, this.yScaleTextFont, x - this.textGap, y, 4);
        }
        lineCursor += pixelGap;
      }
    }
    int yAxisTextGap = yAxisTextGapTemp + maxYScaleTextGap;
    int xAxisWidth = width - 2 * this.xGap - this.shadowOffset - yAxisTextGap;
    this.backgroundBounds.x = (this.xGap + yAxisTextGap + this.shadowOffset);
    this.backgroundBounds.y = this.yGap;
    this.backgroundBounds.width = xAxisWidth;
    this.backgroundBounds.height = yAxisHeight;
    paintBackground(g2d);
    if (drawYAxisText)
    {
      int xText = this.xGap;
      int yText = yAxisHeight / 2 + this.shadowOffset + this.yGap;
      A(g2d, 3, this.yAxisText, this.yAxisTextColor, this.yAxisTextFont, xText, yText, 5);
    }
    if (this.yAxisVisible)
    {
      GeneralPath yAxis = new GeneralPath();
      yAxis.moveTo(this.xGap + yAxisTextGap, this.yGap + this.shadowOffset);
      yAxis.lineTo(this.xGap + yAxisTextGap, height - this.yGap - xAxisTextGap);
      yAxis.lineTo(this.xGap + yAxisTextGap + this.shadowOffset, height - this.yGap - xAxisTextGap - this.shadowOffset);
      yAxis.lineTo(this.xGap + yAxisTextGap + this.shadowOffset, this.yGap);
      yAxis.closePath();
      if ((this.yAxisFillColor != null) && (this.shadowOffset > 0))
      {
        g2d.setColor(this.yAxisFillColor);
        g2d.fill(yAxis);
      }
      if ((this.yAxisStroke != null) && (this.yAxisOutlineColor != null))
      {
        g2d.setStroke(TUIManager.getStrokeByType(this.yAxisStroke));
        g2d.setColor(this.yAxisOutlineColor);
        g2d.draw(yAxis);
      }
    }
    if ((this.yScaleLineVisible) && (this.yScaleLineStroke != null) && (this.yScaleLineColor != null))
    {
      g2d.setStroke(TUIManager.getStrokeByType(this.yScaleLineStroke));
      g2d.setColor(this.yScaleLineColor);
      for (double lineCursor = 0.0D; lineCursor <= yAxisHeight + 1; lineCursor += pixelGap)
      {
        g2d.drawLine(this.xGap + yAxisTextGap + this.shadowOffset, baseLine - (int)lineCursor, width - this.xGap, baseLine - (int)lineCursor);
        if (this.shadowOffset > 0) {
          g2d.drawLine(this.xGap + yAxisTextGap + this.shadowOffset, baseLine - (int)lineCursor, this.xGap + yAxisTextGap, baseLine - (int)lineCursor + this.shadowOffset);
        }
      }
    }
    if (drawXAxisText)
    {
      int xText = xAxisWidth / 2 + this.xGap + yAxisTextGap;
      int yText = height - this.yGap;
      A(g2d, this.xAxisText, this.xAxisTextColor, this.xAxisTextFont, xText, yText, 2);
    }
    if ((this.xAxisVisible) && (this.ɤ)) {
      paintXAxis(g2d, null, width, height, yAxisTextGap, xAxisTextGap, pixelGap, valueGap);
    }
    if (this.markers != null)
    {
      Iterator it = this.markers.iterator();
      while (it.hasNext())
      {
        Marker marker = (Marker)it.next();
        paintXAxis(g2d, marker, width, height, yAxisTextGap, xAxisTextGap, pixelGap, valueGap);
      }
    }
    paintContent(g2d, width, height, yAxisTextGap, xAxisTextGap, xAxisWidth, yAxisHeight, baseLine, pixelGap, valueGap);
  }
  
  protected String getFormatedYScaleText(double value)
  {
    if (this.yScaleTextFormat != null)
    {
      String ret = this.yScaleTextFormat.format(value);
      if (this.unit != null) {
        ret = ret + this.unit;
      }
      return ret;
    }
    if (this.format != null)
    {
      String ret = this.format.format(value);
      if (this.unit != null) {
        ret = ret + this.unit;
      }
      return ret;
    }
    return value + (this.unit == null ? "" : this.unit);
  }
  
  protected void paintXAxis(Graphics2D g2d, Marker marker, int width, int height, int xTextGap, int yTextGap, double pixelGap, double valueGap)
  {
    Color outlineColor;
    double value;
    Stroke stroke;
    Color fillColor;
    Color outlineColor;
    if (marker == null)
    {
      double value;
      double value;
      if (this.xAxisValue == -1.797693134862316E+308D) {
        value = this.min;
      } else {
        value = this.xAxisValue;
      }
      Stroke stroke = TUIManager.getStrokeByType(this.xAxisStroke);
      Color fillColor = this.xAxisFillColor;
      outlineColor = this.xAxisOutlineColor;
    }
    else
    {
      value = marker.getValue();
      stroke = TUIManager.getStrokeByType(marker.getStroke());
      fillColor = null;
      outlineColor = marker.getColor();
    }
    int h = -(int)((value - this.min) / valueGap * pixelGap);
    GeneralPath xAxis = new GeneralPath();
    xAxis.moveTo(this.xGap + xTextGap, height - this.yGap - yTextGap + h);
    xAxis.lineTo(this.xGap + xTextGap + this.shadowOffset, height - this.yGap - yTextGap - this.shadowOffset + h);
    xAxis.lineTo(width - this.xGap, height - this.yGap - yTextGap - this.shadowOffset + h);
    xAxis.lineTo(width - this.xGap - this.shadowOffset, height - this.yGap - yTextGap + h);
    xAxis.closePath();
    if ((fillColor != null) && (this.shadowOffset > 0))
    {
      g2d.setColor(fillColor);
      g2d.fill(xAxis);
    }
    if ((outlineColor != null) && (stroke != null))
    {
      g2d.setColor(outlineColor);
      g2d.setStroke(stroke);
      g2d.draw(xAxis);
    }
    if (marker != null)
    {
      int x = this.xGap + xTextGap + this.shadowOffset + marker.getXOffset();
      int y = height - this.yGap - yTextGap - this.shadowOffset + h + marker.getYOffset() + 2;
      A(g2d, marker.getText(), marker.getTextColor(), marker.getTextFont(), x, y, 7);
    }
  }
  
  protected abstract void paintContent(Graphics2D paramGraphics2D, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble1, double paramDouble2);
  
  public Color getYScaleLineColor()
  {
    return this.yScaleLineColor;
  }
  
  public void setYScaleLineColor(Color yScaleLineColor)
  {
    this.yScaleLineColor = yScaleLineColor;
    this.chartPane.repaint();
  }
  
  public String getYScaleLineStroke()
  {
    return this.yScaleLineStroke;
  }
  
  public void setYScaleLineStroke(String yScaleLineStroke)
  {
    this.yScaleLineStroke = yScaleLineStroke;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleLineVisible()
  {
    return this.yScaleLineVisible;
  }
  
  public void setYScaleLineVisible(boolean yScaleLineVisible)
  {
    this.yScaleLineVisible = yScaleLineVisible;
    this.chartPane.repaint();
  }
  
  public Color getYScaleTextColor()
  {
    return this.yScaleTextColor;
  }
  
  public void setYScaleTextColor(Color yScaleTextColor)
  {
    this.yScaleTextColor = yScaleTextColor;
    this.chartPane.repaint();
  }
  
  public Font getYScaleTextFont()
  {
    return this.yScaleTextFont;
  }
  
  public void setYScaleTextFont(Font yScaleTextFont)
  {
    this.yScaleTextFont = yScaleTextFont;
    this.chartPane.repaint();
  }
  
  public NumberFormat getYScaleTextFormat()
  {
    return this.yScaleTextFormat;
  }
  
  public void setYScaleTextFormat(NumberFormat yScaleTextFormat)
  {
    this.yScaleTextFormat = yScaleTextFormat;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleTextVisible()
  {
    return this.yScaleTextVisible;
  }
  
  public void setYScaleTextVisible(boolean yScaleTextVisible)
  {
    this.yScaleTextVisible = yScaleTextVisible;
    this.chartPane.repaint();
  }
  
  public Color getXAxisFillColor()
  {
    return this.xAxisFillColor;
  }
  
  public void setXAxisFillColor(Color xAxisFillColor)
  {
    this.xAxisFillColor = xAxisFillColor;
    this.chartPane.repaint();
  }
  
  public Color getXAxisOutlineColor()
  {
    return this.xAxisOutlineColor;
  }
  
  public void setXAxisOutlineColor(Color xAxisOutlineColor)
  {
    this.xAxisOutlineColor = xAxisOutlineColor;
    this.chartPane.repaint();
  }
  
  public String getXAxisText()
  {
    return this.xAxisText;
  }
  
  public void setXAxisText(String xAxisText)
  {
    this.xAxisText = xAxisText;
    this.chartPane.repaint();
  }
  
  public Color getXAxisTextColor()
  {
    return this.xAxisTextColor;
  }
  
  public void setXAxisTextColor(Color xAxisTextColor)
  {
    this.xAxisTextColor = xAxisTextColor;
    this.chartPane.repaint();
  }
  
  public Font getXAxisTextFont()
  {
    return this.xAxisTextFont;
  }
  
  public void setXAxisTextFont(Font xAxisTextFont)
  {
    this.xAxisTextFont = xAxisTextFont;
    this.chartPane.repaint();
  }
  
  public Color getYAxisFillColor()
  {
    return this.yAxisFillColor;
  }
  
  public void setYAxisFillColor(Color yAxisFillColor)
  {
    this.yAxisFillColor = yAxisFillColor;
    this.chartPane.repaint();
  }
  
  public Color getYAxisOutlineColor()
  {
    return this.yAxisOutlineColor;
  }
  
  public void setYAxisOutlineColor(Color yAxisOutlineColor)
  {
    this.yAxisOutlineColor = yAxisOutlineColor;
    this.chartPane.repaint();
  }
  
  public String getYAxisText()
  {
    return this.yAxisText;
  }
  
  public void setYAxisText(String yAxisText)
  {
    this.yAxisText = yAxisText;
    this.chartPane.repaint();
  }
  
  public Color getYAxisTextColor()
  {
    return this.yAxisTextColor;
  }
  
  public void setYAxisTextColor(Color yAxisTextColor)
  {
    this.yAxisTextColor = yAxisTextColor;
    this.chartPane.repaint();
  }
  
  public Font getYAxisTextFont()
  {
    return this.yAxisTextFont;
  }
  
  public void setYAxisTextFont(Font axisTextFont)
  {
    this.yAxisTextFont = axisTextFont;
    this.chartPane.repaint();
  }
  
  public double getYScaleValueGap()
  {
    return this.yScaleValueGap;
  }
  
  public void setYScaleValueGap(double yScaleValueGap)
  {
    this.yScaleValueGap = yScaleValueGap;
    this.chartPane.repaint();
  }
  
  public int getYScalePixelGap()
  {
    return this.yScalePixelGap;
  }
  
  public void setYScalePixelGap(int yScalePixelGap)
  {
    this.yScalePixelGap = yScalePixelGap;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleMinTextVisible()
  {
    return this.yScaleMinTextVisible;
  }
  
  public void setYScaleMinTextVisible(boolean yScaleMinTextVisible)
  {
    this.yScaleMinTextVisible = yScaleMinTextVisible;
    this.chartPane.repaint();
  }
  
  public double getXAxisValue()
  {
    return this.xAxisValue;
  }
  
  public void setXAxisValue(double xAxisValue)
  {
    this.xAxisValue = xAxisValue;
    this.chartPane.repaint();
  }
  
  public List getMarkers()
  {
    return this.markers;
  }
  
  public void setMarkers(List markers)
  {
    this.markers = markers;
    this.chartPane.repaint();
  }
  
  public void addMarker(double value, Color color)
  {
    Marker marker = new Marker(value, color);
    addMarker(marker);
  }
  
  public void removeMarker(Marker marker)
  {
    if (this.markers != null) {
      this.markers.remove(marker);
    }
  }
  
  public void addMarker(Marker marker)
  {
    if (marker == null) {
      return;
    }
    if (this.markers == null) {
      this.markers = new ArrayList();
    }
    this.markers.add(marker);
    this.chartPane.repaint();
  }
  
  public String getXAxisStroke()
  {
    return this.xAxisStroke;
  }
  
  public void setXAxisStroke(String xAxisStroke)
  {
    this.xAxisStroke = xAxisStroke;
    this.chartPane.repaint();
  }
  
  public String getYAxisStroke()
  {
    return this.yAxisStroke;
  }
  
  public void setYAxisStroke(String yAxisStroke)
  {
    this.yAxisStroke = yAxisStroke;
    this.chartPane.repaint();
  }
  
  public boolean getXAxisVisible()
  {
    return this.xAxisVisible;
  }
  
  public void setXAxisVisible(boolean xAxisVisible)
  {
    this.xAxisVisible = xAxisVisible;
    this.chartPane.repaint();
  }
  
  public boolean getYAxisVisible()
  {
    return this.yAxisVisible;
  }
  
  public void setYAxisVisible(boolean yAxisVisible)
  {
    this.yAxisVisible = yAxisVisible;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleTextInside()
  {
    return this.yScaleTextInside;
  }
  
  public void setYScaleTextInside(boolean scaleTextInside)
  {
    this.yScaleTextInside = scaleTextInside;
    this.chartPane.repaint();
  }
  
  public Color getXScaleTextColor()
  {
    return this.xScaleTextColor;
  }
  
  public void setXScaleTextColor(Color scaleTextColor)
  {
    this.xScaleTextColor = scaleTextColor;
    this.chartPane.repaint();
  }
  
  public Font getXScaleTextFont()
  {
    return this.xScaleTextFont;
  }
  
  public void setXScaleTextFont(Font scaleTextFont)
  {
    this.xScaleTextFont = scaleTextFont;
    this.chartPane.repaint();
  }
  
  public int getXScaleTextOrientation()
  {
    return this.xScaleTextOrientation;
  }
  
  public void setXScaleTextOrientation(int scaleTextOrientation)
  {
    this.xScaleTextOrientation = scaleTextOrientation;
    this.chartPane.repaint();
  }
  
  public boolean isXScaleTextVisible()
  {
    return this.xScaleTextVisible;
  }
  
  public void setXScaleTextVisible(boolean scaleTextVisible)
  {
    this.xScaleTextVisible = scaleTextVisible;
    this.chartPane.repaint();
  }
  
  public List getXScaleTextList()
  {
    return this.xScaleTextList;
  }
  
  public void setXScaleTextList(List xScaleTextList)
  {
    this.xScaleTextList = xScaleTextList;
    publishData();
  }
  
  public void addXScaleText(String text)
  {
    if (this.xScaleTextList == null) {
      this.xScaleTextList = new ArrayList();
    }
    this.xScaleTextList.add(text);
    publishData();
  }
  
  public String getXScaleText(int index)
  {
    if (this.xScaleTextList == null) {
      return null;
    }
    if ((this.xScaleTextList.size() <= index) || (index < 0)) {
      return null;
    }
    return (String)this.xScaleTextList.get(index);
  }
  
  public String getToolTipText(Element element, double value, int index)
  {
    if (!isEnableToolTipText()) {
      return null;
    }
    String text = getToolTipText(element);
    String xScaleText = getXScaleText(index);
    if (xScaleText != null) {
      if (text == null) {
        text = xScaleText;
      } else {
        text = text + "<br>" + xScaleText;
      }
    }
    String valueText = getFormatedText(element, value, index);
    if (valueText != null) {
      if (text == null) {
        text = valueText;
      } else {
        text = text + "<br>" + valueText;
      }
    }
    if (text != null)
    {
      if (text.indexOf("<html>") >= 0)
      {
        text = text.replaceAll("<html>", "");
        text = text.replaceAll("</html>", "");
      }
      text = "<html>" + text + "</html>";
    }
    return text;
  }
  
  protected void calculateValuesProportionsOfRange(boolean relativeMin, int categoryCount)
  {
    this.proportions.clear();
    int count = this.publishedElements.size();
    this.max = this.upperLimit;
    this.min = this.lowerLimit;
    if ((this.upperLimit == -1.797693134862316E+308D) || (this.lowerLimit == 1.7976931348623157E+308D)) {
      if (categoryCount >= 0) {
        for (int i = 0; i < categoryCount; i++)
        {
          double upSum = 0.0D;
          double lowSum = 0.0D;
          for (int j = 0; j < count; j++)
          {
            Element element = (Element)this.publishedElements.get(j);
            List list = getValues(element);
            if (list.size() > i)
            {
              Object obj = list.get(i);
              if ((obj instanceof Double))
              {
                double value = ((Double)obj).doubleValue();
                if (value > 0.0D) {
                  upSum += value;
                } else {
                  lowSum += value;
                }
              }
            }
          }
          if ((this.upperLimit == -1.797693134862316E+308D) && (upSum > this.max)) {
            this.max = upSum;
          }
          if ((this.lowerLimit == 1.7976931348623157E+308D) && (lowSum < this.min)) {
            this.min = lowSum;
          }
        }
      } else {
        for (int i = 0; i < count; i++)
        {
          Element element = (Element)this.publishedElements.get(i);
          List list = getValues(element);
          int count2 = list.size();
          if (this.endIndex < count2) {
            count2 = this.endIndex;
          }
          int j = this.startIndex;
          while (j < count2)
          {
            Object obj = list.get(j);
            if ((obj instanceof Double))
            {
              double value = ((Double)obj).doubleValue();
              if ((this.upperLimit == -1.797693134862316E+308D) && (value > this.max)) {
                this.max = value;
              }
              if ((this.lowerLimit == 1.7976931348623157E+308D) && (value < this.min)) {
                this.min = value;
              }
            }
            j += this.valueSpanCount;
          }
        }
      }
    }
    if (this.min == 1.7976931348623157E+308D)
    {
      if (this.max != -1.797693134862316E+308D)
      {
        this.min = (this.max * 0.9D);
      }
      else
      {
        this.max = 100.0D;
        this.min = 0.0D;
      }
    }
    else if (this.max == -1.797693134862316E+308D) {
      this.max = (this.min * 1.1D);
    }
    if (this.max == -1.797693134862316E+308D)
    {
      if (this.min == 1.7976931348623157E+308D)
      {
        this.max = 100.0D;
        this.min = 0.0D;
      }
      else
      {
        this.max = (this.min * 1.1D);
      }
    }
    else if (this.min == 1.7976931348623157E+308D) {
      this.min = (this.max * 0.9D);
    }
    if (this.max == this.min) {
      if (this.max == 0.0D)
      {
        this.max = 10.0D;
        this.min = -10.0D;
      }
      else
      {
        double temp = this.max * 0.1D;
        this.max += temp;
        this.min -= temp;
      }
    }
    this.range = Math.abs(this.max - this.min);
    double relative = relativeMin ? this.min : 0.0D;
    for (int i = 0; i < count; i++)
    {
      Element element = (Element)this.publishedElements.get(i);
      List values = getValues(element);
      int count2 = values.size();
      for (int j = 0; j < count2; j++)
      {
        List list = (List)this.proportions.get(element);
        if (list == null)
        {
          list = new ArrayList();
          this.proportions.put(element, list);
        }
        if ((this.range != 0.0D) && (j >= this.startIndex) && (j < this.endIndex) && ((j - this.startIndex) % this.valueSpanCount == 0))
        {
          Object obj = values.get(j);
          if (obj == null)
          {
            list.add(null);
          }
          else
          {
            double value = ((Double)obj).doubleValue();
            list.add(new Double((value - relative) / this.range));
          }
        }
        else
        {
          list.add(null);
        }
      }
    }
  }
  
  protected void calculateYScaleValueGap()
  {
    if (this.yScaleValueGap <= 0.0D) {
      this.yscaleAutoCaculateFlag = true;
    }
    if ((this.yScaleValueGapAutoCalculate) && ((this.yScaleValueGap <= 0.0D) || (this.yscaleAutoCaculateFlag))) {
      this.yScaleValueGap = getAutoScaleValueGap(this.range);
    }
  }
  
  protected double getAutoScaleValueGap(double range)
  {
    double gap = 0.0D;
    double segment = 15.0D;
    if (range <= 0.0D) {
      return gap;
    }
    if (range < segment)
    {
      int ten = 10;
      if (range < 1.0D)
      {
        String[] str = range.split("\\.");
        String after = str[1];
        int length = after.length();
        for (int i = 0; i < length; i++)
        {
          if (!"0".equals(after.substring(i, i + 1))) {
            break;
          }
          ten *= 10;
        }
      }
      else
      {
        ten = 1;
      }
      double rangeTemp = ten * range;
      if (rangeTemp >= 4.0D) {
        gap = 1.0D / ten;
      } else if (rangeTemp >= segment / 10.0D) {
        gap = 0.5D / ten;
      } else if (rangeTemp < segment / 10.0D) {
        gap = 0.1D / ten;
      }
    }
    if ((range < 25.0D) && (range >= segment)) {
      gap = 5.0D;
    }
    if (range >= 25.0D)
    {
      int length = ((int)range).trim().length();
      int ten = 1;
      for (int i = 0; i < length - 1; i++) {
        ten *= 10;
      }
      gap = ten;
      double divisor = range / gap;
      if (divisor < 4.0D)
      {
        gap = ten / 2;
        divisor = range / gap;
        if (divisor < 4.0D)
        {
          gap = ten / 5;
          divisor = range / gap;
          if (divisor < 4.0D) {
            gap = ten / 10;
          }
        }
      }
    }
    return gap;
  }
  
  public boolean isYScaleValueGapAutoCalculate()
  {
    return this.yScaleValueGapAutoCalculate;
  }
  
  public void setYScaleValueGapAutoCalculate(boolean scaleValueGapAutoCaculate)
  {
    this.yScaleValueGapAutoCalculate = scaleValueGapAutoCaculate;
    publishData(false);
  }
  
  protected void setChartSVGAttribute(AbstractSVGChart abschart)
  {
    super.setChartSVGAttribute(abschart);
    AbstractSVGScaleChart chart = (AbstractSVGScaleChart)abschart;
    chart.setXAxisFillColor(getXAxisFillColor());
    chart.setXAxisOutlineColor(getXAxisOutlineColor());
    chart.setXAxisStroke(getXAxisStroke());
    chart.setXAxisText(getXAxisText());
    chart.setXAxisTextColor(getXAxisTextColor());
    chart.setXAxisTextFont(getXAxisTextFont());
    chart.setXAxisValue(getXAxisValue());
    chart.setXAxisVisible(getXAxisVisible());
    chart.setXScaleTextColor(getXScaleTextColor());
    chart.setXScaleTextFont(getXScaleTextFont());
    chart.setXScaleTextList(getXScaleTextList());
    chart.setXScaleTextOrientation(getXScaleTextOrientation());
    chart.setXScaleTextVisible(isXScaleTextVisible());
    chart.setYAxisFillColor(getYAxisFillColor());
    chart.setYAxisOutlineColor(getYAxisOutlineColor());
    chart.setYAxisStroke(getYAxisStroke());
    chart.setYAxisText(getYAxisText());
    chart.setYAxisTextColor(getYAxisTextColor());
    chart.setYAxisTextFont(getYAxisTextFont());
    chart.setYAxisVisible(getYAxisVisible());
    chart.setYScaleLineColor(getYScaleLineColor());
    chart.setYScaleLineStroke(getYScaleLineStroke());
    chart.setYScaleLineVisible(isYScaleLineVisible());
    chart.setYScaleMinTextVisible(isYScaleMinTextVisible());
    chart.setYScalePixelGap(getYScalePixelGap());
    chart.setYScaleTextColor(getYScaleTextColor());
    chart.setYScaleTextFont(chart.getYScaleTextFont());
    chart.setYScaleTextFormat(chart.getYScaleTextFormat());
    chart.setYScaleTextInside(isYScaleTextInside());
    chart.setYScaleTextVisible(isYScaleTextVisible());
    chart.setYScaleValueGap(getYScaleValueGap());
    chart.setYScaleValueGapAutoCalculate(isYScaleValueGapAutoCalculate());
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.chart.AbstractScaleChart
 * JD-Core Version:    0.7.0.1
 */
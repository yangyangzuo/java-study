package twaver.chart;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D.Double;
import java.awt.geom.Rectangle2D.Double;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import twaver.TDataBox;
import twaver.TUIManager;
import twaver.web.svg.chart.AbstractSVGChart;
import twaver.web.svg.chart.AbstractSVGXYScaleChart;

public abstract class AbstractXYScaleChart
  extends AbstractChart
{
  private boolean Π = TUIManager.getBoolean("tchart.xaxis.visible");
  private Color ϒ = TUIManager.getColor("tchart.xaxis.fill.color");
  private Color ΰ = TUIManager.getColor("tchart.xaxis.outline.color");
  private String ξ = TUIManager.getString("tchart.xaxis.stroke");
  private String σ = TUIManager.getString("tchart.xaxis.text");
  private Font Σ = TUIManager.getFont("tchart.xaxis.text.font");
  private Color υ = TUIManager.getColor("tchart.xaxis.text.color");
  private double ν = TUIManager.getDouble("tchart.xaxis.start.position");
  private String ϕ = TUIManager.getString("tchart.xaxis.unit");
  private boolean ά = TUIManager.getBoolean("tchart.xaxis.unit.visible");
  private Color ϋ = TUIManager.getColor("tchart.xaxis.unit.color");
  private Font η = TUIManager.getFont("tchart.xaxis.unit.font");
  private boolean π = TUIManager.getBoolean("tchart.yaxis.visible");
  private Color λ = TUIManager.getColor("tchart.yaxis.fill.color");
  private Color Ρ = TUIManager.getColor("tchart.yaxis.outline.color");
  private String Μ = TUIManager.getString("tchart.yaxis.stroke");
  private String Ο = TUIManager.getString("tchart.yaxis.text");
  private Font ϑ = TUIManager.getFont("tchart.yaxis.text.font");
  private Color α = TUIManager.getColor("tchart.yaxis.text.color");
  private double Λ = TUIManager.getDouble("tchart.yaxis.start.position");
  private String έ = TUIManager.getString("tchart.yaxis.unit");
  private boolean Ϊ = TUIManager.getBoolean("tchart.yaxis.unit.visible");
  private Color θ = TUIManager.getColor("tchart.yaxis.unit.color");
  private Font Υ = TUIManager.getFont("tchart.yaxis.text.font");
  private boolean Ν = TUIManager.getBoolean("tchart.xscale.text.visible");
  private boolean ϣ = TUIManager.getBoolean("tchart.xscale.text.ontop");
  private NumberFormat ύ = TUIManager.getNumberFormat("tchart.xscale.text.format");
  private Color ϓ = TUIManager.getColor("tchart.xscale.text.color");
  private Font ς = TUIManager.getFont("tchart.xscale.text.font");
  private String Ϥ = TUIManager.getString("tchart.xscale.line.stroke");
  private Color Ξ = TUIManager.getColor("tchart.xscale.line.color");
  private boolean Ϛ = TUIManager.getBoolean("tchart.xscale.line.visible");
  private int ό = TUIManager.getInt("tchart.xscale.text.orientation");
  private double Ϡ = TUIManager.getDouble("tchart.xscale.value.gap");
  private double Ϣ = TUIManager.getDouble("tchart.xscale.pixel.gap");
  private double ε = TUIManager.getDouble("tchart.xscale.min.value");
  private double ο = TUIManager.getDouble("tchart.xscale.max.value");
  private boolean ϐ = TUIManager.getBoolean("tchart.yscale.text.visible");
  private boolean ρ = TUIManager.getBoolean("tchart.yscale.text.inside");
  private NumberFormat ϊ = TUIManager.getNumberFormat("tchart.yscale.text.format");
  private Color κ = TUIManager.getColor("tchart.yscale.text.color");
  private Font β = TUIManager.getFont("tchart.yscale.text.font");
  private String Ϟ = TUIManager.getString("tchart.yscale.line.stroke");
  private Color τ = TUIManager.getColor("tchart.yscale.line.color");
  private boolean ω = TUIManager.getBoolean("tchart.yscale.line.visible");
  private int ψ = TUIManager.getInt("tchart.yscale.pixel.gap");
  private double φ = TUIManager.getDouble("tchart.yscale.value.gap");
  private double Φ = TUIManager.getDouble("tchart.yscale.min.value");
  private double ί = TUIManager.getDouble("tchart.yscale.max.value");
  private boolean ώ = TUIManager.getBoolean("tchart.yscale.value.gap.auto.calculate");
  private Rectangle2D.Double Χ = new Rectangle2D.Double();
  private List δ = new ArrayList();
  private List ή = new ArrayList();
  private double Ϋ;
  private double γ;
  private double ι;
  private List Τ = null;
  private double Ω = 0.0D;
  private double ϖ = 0.0D;
  private double Ψ;
  private double Ϝ;
  private double μ = 0.0D;
  private double χ = -1.797693134862316E+308D;
  private double ζ = 0.0D;
  private double ϔ = 0.0D;
  protected List markers = null;
  
  public AbstractXYScaleChart() {}
  
  public AbstractXYScaleChart(TDataBox box)
  {
    super(box);
  }
  
  public AbstractXYScaleChart(TDataBox box, String title, Color backgroundColor)
  {
    super(box, title, backgroundColor);
  }
  
  public AbstractXYScaleChart(TDataBox box, String title, Color backgroundColor, Color foregroundColor)
  {
    super(box, title, backgroundColor, foregroundColor);
  }
  
  public AbstractXYScaleChart(List elements)
  {
    super(elements);
  }
  
  public AbstractXYScaleChart(List elements, String title)
  {
    super(elements, title);
  }
  
  public AbstractXYScaleChart(List elements, String title, Color backgroundColor)
  {
    super(elements, title, backgroundColor);
  }
  
  public AbstractXYScaleChart(List elements, String title, Color backgroundColor, Color foregroundColor)
  {
    super(elements, title, backgroundColor, foregroundColor);
  }
  
  protected void calculate()
  {
    calculateYAxisRange();
    calculateYScaleValueGap();
  }
  
  protected void calculateYAxisRange()
  {
    this.max = this.ί;
    this.min = this.Φ;
    this.range = Math.max(this.max - this.min, 1.0D);
  }
  
  protected void calculateYScaleValueGap()
  {
    this.χ = -1.797693134862316E+308D;
    if ((this.φ <= 0.0D) && (this.ψ <= 0))
    {
      this.χ = B(this.range);
      return;
    }
    if (this.ώ) {
      this.χ = B(this.range);
    }
  }
  
  private double B(double range)
  {
    double gap = 0.0D;
    double segment = 15.0D;
    if (range <= 0.0D) {
      return gap;
    }
    if (range < segment)
    {
      int ten = 10;
      if (range < 1.0D)
      {
        String[] str = range.split("\\.");
        String after = str[1];
        int length = after.length();
        for (int i = 0; i < length; i++)
        {
          if (!"0".equals(after.substring(i, i + 1))) {
            break;
          }
          ten *= 10;
        }
      }
      else
      {
        ten = 1;
      }
      double rangeTemp = ten * range;
      if (rangeTemp >= 4.0D) {
        gap = 1.0D / ten;
      } else if (rangeTemp >= segment / 10.0D) {
        gap = 0.5D / ten;
      } else if (rangeTemp < segment / 10.0D) {
        gap = 0.1D / ten;
      }
    }
    if ((range < 25.0D) && (range >= segment)) {
      gap = 5.0D;
    }
    if (range >= 25.0D)
    {
      int length = ((int)range).trim().length();
      int ten = 1;
      for (int i = 0; i < length - 1; i++) {
        ten *= 10;
      }
      gap = ten;
      double divisor = range / gap;
      if (divisor < 4.0D)
      {
        gap = ten / 2;
        divisor = range / gap;
        if (divisor < 4.0D)
        {
          gap = ten / 5;
          divisor = range / gap;
          if (divisor < 4.0D) {
            gap = ten / 10;
          }
        }
      }
    }
    return gap;
  }
  
  protected void calculateXScaleTextHeight()
  {
    String text = getFormatedXScaleText(this.ο);
    Dimension dim = A(this.ό, text, this.ς);
    this.Ω = dim.getHeight();
    this.ϖ = A(this.ό, getFormatedXScaleText(this.ε), this.ς).width;
    if ((this.δ != null) && (this.δ.contains(new Integer(0))))
    {
      this.ϖ = 0.0D;
      return;
    }
    if ((!this.Π) || (!this.Ν))
    {
      this.Ω = 0.0D;
      this.ϖ = 0.0D;
      return;
    }
    if ((this.Τ != null) && (this.Τ.size() > 0))
    {
      this.Ω = 0.0D;
      this.ϖ = 0.0D;
      int size = this.Τ.size();
      for (int i = 0; i < size; i++) {
        if (!this.δ.contains(new Integer(i)))
        {
          Object object = this.Τ.get(i);
          if (object != null)
          {
            text = object.toString();
            dim = A(this.ό, text, this.ς);
            if (i == 0) {
              this.ϖ = dim.getWidth();
            }
            double textHeight = dim.getHeight();
            if (textHeight > this.Ω) {
              this.Ω = textHeight;
            }
          }
        }
      }
    }
  }
  
  public void paintChart(Graphics2D g, int width, int height)
  {
    calculateXScaleTextHeight();
    this.Ψ = this.ν;
    if (this.ν < this.min) {
      this.Ψ = this.min;
    }
    if (this.ν > this.max) {
      this.Ψ = this.max;
    }
    if (this.Λ < this.ε) {
      this.Ϝ = this.ε;
    } else {
      this.Ϝ = this.Λ;
    }
    this.ϔ = Math.max(this.ο - this.ε, 1.0D);
    F(g, width, height);
    E(g, width, height);
    H(g);
    paintContent(g, width, height);
  }
  
  protected abstract void paintContent(Graphics2D paramGraphics2D, int paramInt1, int paramInt2);
  
  private void F(Graphics2D g, int width, int height)
  {
    boolean drawXAxisText = (this.σ != null) && (!this.σ.trim().equals(""));
    double xAxisTextGap;
    double xAxisTextGap;
    if (drawXAxisText)
    {
      Dimension size = A(this.σ, this.Σ);
      xAxisTextGap = size.getHeight() + getXAxisExtraGap(g) + this.textGap;
    }
    else
    {
      xAxisTextGap = getXAxisExtraGap(g);
    }
    Dimension xUnitSize = new Dimension(0, 0);
    if ((this.Π) && (this.ά) && (this.ϕ != null) && (this.η != null) && (this.ϋ != null))
    {
      Dimension dim = A(this.ϕ, this.η);
      xUnitSize.setSize(dim.getWidth() + this.textGap, dim.getHeight());
    }
    Dimension yUnitSize = new Dimension(0, 0);
    if ((this.π) && (this.Ϊ) && (this.έ != null) && (this.Υ != null) && (this.θ != null))
    {
      Dimension dim = A(this.έ, this.Υ);
      yUnitSize.setSize(dim.getWidth() + this.textGap, dim.getHeight() + this.textGap);
    }
    this.ι = (height - 2 * this.yGap - xAxisTextGap - this.shadowOffset - yUnitSize.getHeight());
    double xScaleTextUseGap = 0.0D;
    if ((this.Π) && (this.Ν))
    {
      double xScaleTextGap = this.Ω;
      if (this.ϣ) {
        xScaleTextGap = 0.0D;
      }
      if ((this.ά) && (xUnitSize.getHeight() > this.shadowOffset)) {
        if (this.ϣ)
        {
          xScaleTextGap = (xUnitSize.getHeight() - this.shadowOffset) / 2.0D;
        }
        else
        {
          xScaleTextGap = this.Ω;
          double xScleAndShdowHeight = this.Ω + this.shadowOffset / 2.0D;
          if (xUnitSize.getHeight() / 2.0D > xScleAndShdowHeight) {
            xScaleTextGap = xUnitSize.getHeight() / 2.0D - xScleAndShdowHeight;
          }
        }
      }
      double xScaleTextOffset = (this.Ψ - this.min) / this.range * (this.ι - xScaleTextGap);
      if (xScaleTextOffset < xScaleTextGap) {
        xScaleTextUseGap = xScaleTextGap - xScaleTextOffset;
      }
      if (this.Ψ == this.min) {
        xScaleTextUseGap = xScaleTextGap;
      }
      this.ι -= xScaleTextUseGap;
    }
    boolean drawYAxisText = false;
    double valueGap;
    double pixelGap;
    double valueGap;
    if (this.χ != -1.797693134862316E+308D)
    {
      double pixelGap = Math.max(this.χ / this.range * this.ι, 1.0D);
      valueGap = this.χ;
    }
    else
    {
      double valueGap;
      if (this.φ > 0.0D)
      {
        double pixelGap = Math.max(this.φ / this.range * this.ι, 1.0D);
        valueGap = this.φ;
      }
      else
      {
        pixelGap = Math.max(this.ψ, 1);
        valueGap = this.range * (pixelGap / this.ι);
      }
    }
    this.ζ = valueGap;
    this.Ϋ = 0.0D;
    if (this.Π) {
      this.Ϋ = (this.ϖ / 2.0D);
    }
    drawYAxisText = (this.Ο != null) && (!this.Ο.trim().equals(""));
    double yAxisTextGapTemp;
    double yAxisTextGapTemp;
    if (drawYAxisText)
    {
      Dimension size = A(3, this.Ο, this.ϑ);
      yAxisTextGapTemp = size.getWidth() + this.textGap;
    }
    else
    {
      yAxisTextGapTemp = 0.0D;
    }
    this.Ϋ += yAxisTextGapTemp;
    if (this.π)
    {
      double maxYScaleTextGap = 0.0D;
      if ((this.ϐ) && (this.κ != null) && (this.β != null))
      {
        if (!this.ρ)
        {
          double lineCursor = 0.0D;
          double value = this.min;
          for (int index = 0; lineCursor <= this.ι + 1.0D; index++)
          {
            if (!this.ή.contains(new Integer(index)))
            {
              String text = getFormatedYScaleText(value);
              Dimension size = A(text, this.β);
              if (size.getWidth() > maxYScaleTextGap) {
                maxYScaleTextGap = size.getWidth();
              }
            }
            lineCursor += pixelGap;
            value += valueGap;
          }
        }
        maxYScaleTextGap += this.textGap;
      }
      if (maxYScaleTextGap < (yUnitSize.getWidth() - this.shadowOffset) / 2.0D) {
        maxYScaleTextGap = (yUnitSize.getWidth() - this.shadowOffset) / 2.0D;
      }
      double maxYScaleTextGapTemp = 0.0D;
      double xAxisTempW = width - 2 * this.xGap - this.shadowOffset - xUnitSize.getWidth() - maxYScaleTextGap;
      double yAxisStartUseGap = (this.Ϝ - this.ε) / this.ϔ;
      if (yAxisStartUseGap * xAxisTempW < maxYScaleTextGap) {
        maxYScaleTextGapTemp = maxYScaleTextGap - yAxisStartUseGap * xAxisTempW;
      }
      if (this.Ϝ == this.ε) {
        maxYScaleTextGapTemp = maxYScaleTextGap;
      }
      if (maxYScaleTextGapTemp < this.ϖ / 2.0D) {
        maxYScaleTextGapTemp = this.ϖ / 2.0D;
      }
      this.Ϋ = (yAxisTextGapTemp + maxYScaleTextGapTemp);
    }
    this.γ = (width - 2 * this.xGap - this.shadowOffset - this.Ϋ - xUnitSize.getWidth());
    this.backgroundBounds.x = ((int)(this.xGap + this.Ϋ + this.shadowOffset));
    this.backgroundBounds.y = ((int)(this.yGap + yUnitSize.getHeight()));
    this.backgroundBounds.width = ((int)this.γ);
    this.backgroundBounds.height = ((int)this.ι);
    paintBackground(g);
    this.Χ.x = (this.xGap + this.Ϋ + this.shadowOffset);
    this.Χ.y = (this.yGap + yUnitSize.getHeight());
    this.Χ.width = this.γ;
    this.Χ.height = this.ι;
    double startX = this.Χ.x - this.shadowOffset;
    double startY = this.Χ.y + this.Χ.height + this.shadowOffset;
    if (drawYAxisText)
    {
      int xText = this.xGap;
      int yText = (int)(this.Χ.y + this.Χ.height / 2.0D);
      A(g, 3, this.Ο, this.α, this.ϑ, xText, yText, 5);
    }
    double lineCursor = 0.0D;
    double value = this.min;
    if ((this.ω) && (this.Ϟ != null) && (this.τ != null)) {
      while (lineCursor <= this.Χ.height + 1.0D) {
        if ((this.Π) && (this.Ψ == value))
        {
          lineCursor += pixelGap;
          value += valueGap;
        }
        else
        {
          g.setStroke(TUIManager.getStrokeByType(this.Ϟ));
          g.setColor(this.τ);
          Line2D.Double line = new Line2D.Double(startX + this.shadowOffset, startY - this.shadowOffset - lineCursor, startX + this.shadowOffset + this.γ, startY - this.shadowOffset - lineCursor);
          g.draw(line);
          lineCursor += pixelGap;
          value += valueGap;
        }
      }
    }
    lineCursor = 0.0D;
    value = this.min;
    if (this.π)
    {
      double yStartX = (float)startX;
      if (this.Ϝ != this.ε) {
        yStartX += (this.Ϝ - this.ε) / this.ϔ * this.γ;
      }
      if (this.Ϊ) {
        A(g, this.έ, this.θ, this.Υ, (int)(yStartX + this.shadowOffset / 2), (int)(this.Χ.getY() - this.textGap), 2);
      }
      GeneralPath yAxis = new GeneralPath();
      yAxis.moveTo((float)yStartX, (float)startY);
      yAxis.lineTo((float)(yStartX + this.shadowOffset), (float)(startY - this.shadowOffset));
      yAxis.lineTo((float)(yStartX + this.shadowOffset), (float)this.Χ.getY());
      yAxis.lineTo((float)yStartX, (float)(this.Χ.getY() + this.shadowOffset));
      yAxis.closePath();
      if ((this.λ != null) && (this.shadowOffset > 0))
      {
        g.setColor(this.λ);
        g.fill(yAxis);
      }
      if ((this.Μ != null) && (this.Ρ != null))
      {
        g.setStroke(TUIManager.getStrokeByType(this.Μ));
        g.setColor(this.Ρ);
        g.draw(yAxis);
      }
      for (int index = 0; lineCursor <= this.ι + 1.0D; index++)
      {
        g.setStroke(TUIManager.getStrokeByType(this.Ϟ));
        g.setColor(this.τ);
        if ((this.ω) && (this.Ϟ != null) && (this.τ != null) && (this.shadowOffset > 0))
        {
          GeneralPath line = new GeneralPath();
          line.moveTo((float)yStartX, (float)(startY - lineCursor));
          line.lineTo((float)(yStartX + this.shadowOffset), (float)(startY - lineCursor - this.shadowOffset));
          g.draw(line);
        }
        if ((this.ϐ) && (!this.ή.contains(new Integer(index))))
        {
          String text = getFormatedYScaleText(value);
          if (this.ρ)
          {
            double x = yStartX + this.shadowOffset + this.textGap;
            double y = startY - lineCursor - this.shadowOffset;
            A(g, text, this.κ, this.β, (int)x, (int)y, 5);
          }
          else
          {
            double x = yStartX - this.textGap;
            double y = startY - lineCursor;
            A(g, text, this.κ, this.β, (int)x, (int)y, 4);
          }
        }
        lineCursor += pixelGap;
        value += valueGap;
      }
    }
  }
  
  private void H(Graphics2D g)
  {
    if ((this.markers == null) || (this.markers.size() < 1)) {
      return;
    }
    int size = this.markers.size();
    for (int i = 0; i < size; i++)
    {
      Marker marker = (Marker)this.markers.get(i);
      double value = marker.getValue();
      if ((value >= this.min) && (value <= this.max))
      {
        double percent = (value - this.min) / this.range;
        double yPosition = this.Χ.y + this.Χ.height - percent * this.Χ.height + marker.getYOffset();
        g.setStroke(TUIManager.getStrokeByType(marker.getStroke()));
        g.setColor(marker.getColor());
        Line2D.Double line = new Line2D.Double(this.Χ.getX() + marker.getXOffset(), yPosition, this.Χ.getX() + this.Χ.getWidth(), yPosition);
        g.draw(line);
        if ((marker.getText() != null) && (marker.getTextColor() != null) && (marker.getTextFont() != null))
        {
          int x = (int)(this.Χ.getX() + marker.getXOffset());
          A(g, marker.getText(), marker.getTextColor(), marker.getTextFont(), x, (int)yPosition, 7);
        }
      }
    }
  }
  
  private void E(Graphics2D g, int width, int height)
  {
    boolean drawXAxisText = (this.σ != null) && (!this.σ.trim().equals(""));
    if (drawXAxisText)
    {
      int xText = (int)(this.Χ.getX() + this.Χ.getWidth() / 2.0D);
      int yText = height - this.yGap;
      A(g, this.σ, this.υ, this.Σ, xText, yText, 2);
    }
    double startX = this.Χ.getX() - this.shadowOffset;
    double endX = this.Χ.getX() + this.Χ.getWidth() - this.shadowOffset;
    double xAxisY = this.Χ.getY() + this.Χ.getHeight() + this.shadowOffset;
    double xValueGap;
    double xPixelGap;
    double xValueGap;
    if (this.Ϡ > 0.0D)
    {
      double xPixelGap = this.Ϡ / this.ϔ * this.γ;
      xValueGap = this.Ϡ;
    }
    else
    {
      xPixelGap = this.Ϣ;
      xValueGap = this.ϔ * (xPixelGap / this.γ);
    }
    boolean useScaleTextList = (this.Τ != null) && (this.Τ.size() > 0);
    if (useScaleTextList)
    {
      xPixelGap = this.Χ.getWidth() / this.Τ.size();
      xValueGap = this.ϔ / this.Τ.size();
    }
    this.μ = xValueGap;
    double xAxisBase = useScaleTextList ? startX + xPixelGap / 2.0D : startX;
    double value = useScaleTextList ? this.ε + xValueGap / 2.0D : this.ε;
    if ((this.Ϛ) && (this.Ϥ != null) && (this.Ξ != null)) {
      while (xAxisBase <= endX + 1.0D) {
        if ((this.π) && (value == this.Ϝ))
        {
          xAxisBase += xPixelGap;
          value += xValueGap;
        }
        else
        {
          GeneralPath line = new GeneralPath();
          line.moveTo((float)(xAxisBase + this.shadowOffset), (float)(this.Χ.getY() + this.Χ.getHeight()));
          line.lineTo((float)(xAxisBase + this.shadowOffset), (float)this.Χ.getY());
          g.setStroke(TUIManager.getStrokeByType(this.Ϥ));
          g.setColor(this.Ξ);
          g.draw(line);
          xAxisBase += xPixelGap;
          value += xValueGap;
        }
      }
    }
    if (this.Π)
    {
      float xStartY = (float)xAxisY;
      if (this.Ψ != this.min) {
        xStartY = (float)(xStartY - (this.Ψ - this.min) / this.range * this.ι);
      }
      if (this.ά) {
        A(g, this.ϕ, this.ϋ, this.η, (int)(this.Χ.getX() + this.Χ.getWidth() + this.textGap), (int)(xStartY - this.shadowOffset / 2.0D), 5);
      }
      GeneralPath xAxis = new GeneralPath();
      xAxis.moveTo((float)startX, xStartY);
      xAxis.lineTo((float)startX + this.shadowOffset, xStartY - this.shadowOffset);
      xAxis.lineTo((float)endX + this.shadowOffset, xStartY - this.shadowOffset);
      xAxis.lineTo((float)endX, xStartY);
      xAxis.closePath();
      if ((this.ϒ != null) && (this.shadowOffset > 0))
      {
        g.setColor(this.ϒ);
        g.fill(xAxis);
      }
      if ((this.ξ != null) && (this.ΰ != null))
      {
        g.setStroke(TUIManager.getStrokeByType(this.ξ));
        g.setColor(this.ΰ);
        g.draw(xAxis);
      }
      xAxisBase = useScaleTextList ? startX + xPixelGap / 2.0D : startX;
      value = useScaleTextList ? this.ε + xValueGap / 2.0D : this.ε;
      for (int index = 0; xAxisBase <= endX + 1.0D; index++)
      {
        double x = xAxisBase;
        double y = xStartY;
        if ((this.Ϛ) && (this.Ϥ != null) && (this.Ξ != null) && (this.shadowOffset > 0))
        {
          GeneralPath line = new GeneralPath();
          line.moveTo((float)x, (float)y);
          line.lineTo((float)(x + this.shadowOffset), (float)(y - this.shadowOffset));
          g.setStroke(TUIManager.getStrokeByType(this.Ϥ));
          g.setColor(this.Ξ);
          g.draw(line);
        }
        if ((this.Ν) && (!this.δ.contains(new Integer(index))))
        {
          String text = getFormatedXScaleText(value);
          if ((this.Τ != null) && (this.Τ.size() > 0)) {
            text = getXScaleTextFromScaleList(index);
          }
          int position = 3;
          if (this.ϣ)
          {
            position = 2;
            x += this.shadowOffset;
            y -= this.shadowOffset + this.textGap;
          }
          else
          {
            y += this.textGap;
          }
          A(g, this.ό, text, this.ϓ, this.ς, (int)x, (int)y, position);
        }
        xAxisBase += xPixelGap;
        value += xValueGap;
      }
    }
  }
  
  protected String getFormatedXScaleText(double value)
  {
    if (this.ύ != null)
    {
      String text = this.ύ.format(value);
      return text;
    }
    if (this.format != null)
    {
      String text = this.format.format(value);
      return text;
    }
    return value;
  }
  
  protected String getFormatedYScaleText(double value)
  {
    if (this.ϊ != null)
    {
      String text = this.ϊ.format(value);
      return text;
    }
    if (this.format != null)
    {
      String text = this.format.format(value);
      return text;
    }
    return value;
  }
  
  protected String getXScaleTextFromScaleList(int index)
  {
    if (this.Τ == null) {
      return null;
    }
    if ((this.Τ.size() <= index) || (index < 0)) {
      return null;
    }
    return (String)this.Τ.get(index);
  }
  
  protected int getXAxisExtraGap(Graphics2D g2d)
  {
    return 0;
  }
  
  public double getXScaleActualValueGap()
  {
    return this.μ;
  }
  
  public double getYScaleActualValueGap()
  {
    return this.ζ;
  }
  
  public boolean isXAxisVisible()
  {
    return this.Π;
  }
  
  public void setXAxisVisible(boolean axisVisible)
  {
    this.Π = axisVisible;
    this.chartPane.repaint();
  }
  
  public Color getXAxisFillColor()
  {
    return this.ϒ;
  }
  
  public void setXAxisFillColor(Color axisFillColor)
  {
    this.ϒ = axisFillColor;
    this.chartPane.repaint();
  }
  
  public Color getXAxisOutlineColor()
  {
    return this.ΰ;
  }
  
  public void setXAxisOutlineColor(Color axisOutlineColor)
  {
    this.ΰ = axisOutlineColor;
    this.chartPane.repaint();
  }
  
  public Font getXAxisTextFont()
  {
    return this.Σ;
  }
  
  public void setXAxisTextFont(Font axisTextFont)
  {
    this.Σ = axisTextFont;
    this.chartPane.repaint();
  }
  
  public Color getXAxisTextColor()
  {
    return this.υ;
  }
  
  public void setXAxisTextColor(Color axisTextColor)
  {
    this.υ = axisTextColor;
    this.chartPane.repaint();
  }
  
  public String getXAxisText()
  {
    return this.σ;
  }
  
  public void setXAxisText(String axisText)
  {
    this.σ = axisText;
    this.chartPane.repaint();
  }
  
  public String getXAxisStroke()
  {
    return this.ξ;
  }
  
  public void setXAxisStroke(String axisStroke)
  {
    this.ξ = axisStroke;
    this.chartPane.repaint();
  }
  
  public String getXAxisUnit()
  {
    return this.ϕ;
  }
  
  public void setXAxisUnit(String axisUnit)
  {
    this.ϕ = axisUnit;
    this.chartPane.repaint();
  }
  
  public Font getYAxisTextFont()
  {
    return this.ϑ;
  }
  
  public void setYAxisTextFont(Font axisTextFont)
  {
    this.ϑ = axisTextFont;
    this.chartPane.repaint();
  }
  
  public boolean isYAxisVisible()
  {
    return this.π;
  }
  
  public void setYAxisVisible(boolean axisVisible)
  {
    this.π = axisVisible;
    this.chartPane.repaint();
  }
  
  public Color getYAxisTextColor()
  {
    return this.α;
  }
  
  public void setYAxisTextColor(Color axisTextColor)
  {
    this.α = axisTextColor;
    this.chartPane.repaint();
  }
  
  public Color getYAxisFillColor()
  {
    return this.λ;
  }
  
  public void setYAxisFillColor(Color axisFillColor)
  {
    this.λ = axisFillColor;
    this.chartPane.repaint();
  }
  
  public Color getYAxisOutlineColor()
  {
    return this.Ρ;
  }
  
  public void setYAxisOutlineColor(Color axisOutlineColor)
  {
    this.Ρ = axisOutlineColor;
    this.chartPane.repaint();
  }
  
  public String getYAxisStroke()
  {
    return this.Μ;
  }
  
  public void setYAxisStroke(String axisStroke)
  {
    this.Μ = axisStroke;
    this.chartPane.repaint();
  }
  
  public String getYAxisText()
  {
    return this.Ο;
  }
  
  public void setYAxisText(String axisText)
  {
    this.Ο = axisText;
    this.chartPane.repaint();
  }
  
  public boolean isXScaleTextVisible()
  {
    return this.Ν;
  }
  
  public void setXScaleTextVisible(boolean scaleTextVisible)
  {
    this.Ν = scaleTextVisible;
    this.chartPane.repaint();
  }
  
  public NumberFormat getXScaleTextFormat()
  {
    return this.ύ;
  }
  
  public void setXScaleTextFormat(NumberFormat scaleTextFormat)
  {
    this.ύ = scaleTextFormat;
    this.chartPane.repaint();
  }
  
  public Color getXScaleTextColor()
  {
    return this.ϓ;
  }
  
  public void setXScaleTextColor(Color scaleTextColor)
  {
    this.ϓ = scaleTextColor;
    this.chartPane.repaint();
  }
  
  public Font getXScaleTextFont()
  {
    return this.ς;
  }
  
  public void setXScaleTextFont(Font scaleTextFont)
  {
    this.ς = scaleTextFont;
    this.chartPane.repaint();
  }
  
  public double getXScaleValueGap()
  {
    return this.Ϡ;
  }
  
  public void setXScaleValueGap(double scaleValueGap)
  {
    this.Ϡ = scaleValueGap;
    this.chartPane.repaint();
  }
  
  public double getXScalePixelGap()
  {
    return this.Ϣ;
  }
  
  public void setXScalePixelGap(double scalePixelGap)
  {
    this.Ϣ = scalePixelGap;
    this.chartPane.repaint();
  }
  
  public double getXScaleMinValue()
  {
    return this.ε;
  }
  
  public void setXScaleMinValue(double scaleMinValue)
  {
    this.ε = scaleMinValue;
    publishData(false);
  }
  
  public double getXScaleMaxValue()
  {
    return this.ο;
  }
  
  public void setXScaleMaxValue(double scaleMaxValue)
  {
    this.ο = scaleMaxValue;
    publishData(false);
  }
  
  public String getXScaleLineStroke()
  {
    return this.Ϥ;
  }
  
  public void setXScaleLineStroke(String scaleLineStroke)
  {
    this.Ϥ = scaleLineStroke;
    this.chartPane.repaint();
  }
  
  public Color getXScaleLineColor()
  {
    return this.Ξ;
  }
  
  public void setXScaleLineColor(Color scaleLineColor)
  {
    this.Ξ = scaleLineColor;
    this.chartPane.repaint();
  }
  
  public boolean isXScaleLineVisible()
  {
    return this.Ϛ;
  }
  
  public void setXScaleLineVisible(boolean scaleLineVisible)
  {
    this.Ϛ = scaleLineVisible;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleTextVisible()
  {
    return this.ϐ;
  }
  
  public void setYScaleTextVisible(boolean scaleTextVisible)
  {
    this.ϐ = scaleTextVisible;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleTextInside()
  {
    return this.ρ;
  }
  
  public void setYScaleTextInside(boolean scaleTextInside)
  {
    this.ρ = scaleTextInside;
    this.chartPane.repaint();
  }
  
  public NumberFormat getYScaleTextFormat()
  {
    return this.ϊ;
  }
  
  public void setYScaleTextFormat(NumberFormat scaleTextFormat)
  {
    this.ϊ = scaleTextFormat;
    this.chartPane.repaint();
  }
  
  public Color getYScaleTextColor()
  {
    return this.κ;
  }
  
  public void setYScaleTextColor(Color scaleTextColor)
  {
    this.κ = scaleTextColor;
    this.chartPane.repaint();
  }
  
  public Font getYScaleTextFont()
  {
    return this.β;
  }
  
  public void setYScaleTextFont(Font scaleTextFont)
  {
    this.β = scaleTextFont;
    this.chartPane.repaint();
  }
  
  public int getYScalePixelGap()
  {
    return this.ψ;
  }
  
  public void setYScalePixelGap(int scalePixelGap)
  {
    this.ψ = scalePixelGap;
    this.chartPane.repaint();
  }
  
  public double getYScaleValueGap()
  {
    return this.φ;
  }
  
  public void setYScaleValueGap(double scaleValueGap)
  {
    this.φ = scaleValueGap;
    this.chartPane.repaint();
  }
  
  public String getYScaleLineStroke()
  {
    return this.Ϟ;
  }
  
  public void setYScaleLineStroke(String scaleLineStroke)
  {
    this.Ϟ = scaleLineStroke;
    this.chartPane.repaint();
  }
  
  public Color getYScaleLineColor()
  {
    return this.τ;
  }
  
  public void setYScaleLineColor(Color scaleLineColor)
  {
    this.τ = scaleLineColor;
    this.chartPane.repaint();
  }
  
  public boolean isYScaleLineVisible()
  {
    return this.ω;
  }
  
  public void setYScaleLineVisible(boolean scaleLineVisible)
  {
    this.ω = scaleLineVisible;
    this.chartPane.repaint();
  }
  
  public Rectangle2D.Double getDrawBound()
  {
    return this.Χ;
  }
  
  public double getXAxisStartPosition()
  {
    return this.ν;
  }
  
  public void setXAxisStartPosition(double axisStartPosition)
  {
    this.ν = axisStartPosition;
    this.chartPane.repaint();
  }
  
  public double getYAxisStartPosition()
  {
    return this.Λ;
  }
  
  public void setYAxisStartPosition(double axisStartValue)
  {
    this.Λ = axisStartValue;
    this.chartPane.repaint();
  }
  
  public List getXScaleTextList()
  {
    return this.Τ;
  }
  
  public void setXScaleTextList(List xScaleTextList)
  {
    this.Τ = xScaleTextList;
    this.chartPane.repaint();
  }
  
  public void addXScaleText(String text)
  {
    if (this.Τ == null) {
      this.Τ = new ArrayList();
    }
    this.Τ.add(text);
    this.chartPane.repaint();
  }
  
  public int getXScaleTextOrientation()
  {
    return this.ό;
  }
  
  public void setXScaleTextOrientation(int scaleTextOrientation)
  {
    this.ό = scaleTextOrientation;
    this.chartPane.repaint();
  }
  
  public List getXScaleHideValueIndex()
  {
    return this.δ;
  }
  
  public void setXScaleHideValueIndex(List scaleHideValueIndex)
  {
    this.δ = scaleHideValueIndex;
    if (scaleHideValueIndex == null) {
      this.δ = new ArrayList();
    }
    publishData(false);
  }
  
  public List getYScaleHideValueIndex()
  {
    return this.ή;
  }
  
  public void setYScaleHideValueIndex(List scaleHideValueIndex)
  {
    this.ή = scaleHideValueIndex;
    if (scaleHideValueIndex == null) {
      this.ή = new ArrayList();
    }
    publishData(false);
  }
  
  public boolean isYScaleValueGapAutoCalculate()
  {
    return this.ώ;
  }
  
  public void setYScaleValueGapAutoCalculate(boolean scaleValueGapAutoCaculate)
  {
    this.ώ = scaleValueGapAutoCaculate;
    publishData(false);
  }
  
  public boolean isXAxisUnitVisible()
  {
    return this.ά;
  }
  
  public void setXAxisUnitVisible(boolean axisUnitVisible)
  {
    this.ά = axisUnitVisible;
    this.chartPane.repaint();
  }
  
  public Color getXAxisUnitColor()
  {
    return this.ϋ;
  }
  
  public void setXAxisUnitColor(Color axisUnitColor)
  {
    this.ϋ = axisUnitColor;
    this.chartPane.repaint();
  }
  
  public Font getXAxisUnitFont()
  {
    return this.η;
  }
  
  public void setXAxisUnitFont(Font axisUnitFont)
  {
    this.η = axisUnitFont;
    this.chartPane.repaint();
  }
  
  public String getYAxisUnit()
  {
    return this.έ;
  }
  
  public void setYAxisUnit(String axisUnit)
  {
    this.έ = axisUnit;
    this.chartPane.repaint();
  }
  
  public boolean isYAxisUnitVisible()
  {
    return this.Ϊ;
  }
  
  public void setYAxisUnitVisible(boolean axisUnitVisible)
  {
    this.Ϊ = axisUnitVisible;
    this.chartPane.repaint();
  }
  
  public Color getYAxisUnitColor()
  {
    return this.θ;
  }
  
  public void setYAxisUnitColor(Color axisUnitColor)
  {
    this.θ = axisUnitColor;
    this.chartPane.repaint();
  }
  
  public Font getYAxisUnitFont()
  {
    return this.Υ;
  }
  
  public void setYAxisUnitFont(Font axisUnitFont)
  {
    this.Υ = axisUnitFont;
    this.chartPane.repaint();
  }
  
  public double getYScaleMinValue()
  {
    return this.Φ;
  }
  
  public void setYScaleMinValue(double scaleMinValue)
  {
    this.Φ = scaleMinValue;
    publishData(false);
  }
  
  public double getYScaleMaxValue()
  {
    return this.ί;
  }
  
  public void setYScaleMaxValue(double scaleMaxValue)
  {
    this.ί = scaleMaxValue;
    publishData(false);
  }
  
  public boolean isXScaleTextOnTop()
  {
    return this.ϣ;
  }
  
  public List getMarkers()
  {
    return this.markers;
  }
  
  public void setMarkers(List markers)
  {
    this.markers = markers;
    this.chartPane.repaint();
  }
  
  public void addMarker(double value, Color color)
  {
    Marker marker = new Marker(value, color);
    addMarker(marker);
  }
  
  public void removeMarker(Marker marker)
  {
    if (this.markers != null) {
      this.markers.remove(marker);
    }
  }
  
  public void addMarker(Marker marker)
  {
    if (marker == null) {
      return;
    }
    if (this.markers == null) {
      this.markers = new ArrayList();
    }
    this.markers.add(marker);
    this.chartPane.repaint();
  }
  
  public void setXScaleTextOnTop(boolean scaleTextOnTop)
  {
    this.ϣ = scaleTextOnTop;
    publishData(false);
  }
  
  protected void setChartSVGAttribute(AbstractSVGChart abschart)
  {
    super.setChartSVGAttribute(abschart);
    AbstractSVGXYScaleChart chart = (AbstractSVGXYScaleChart)abschart;
    chart.setXAxisVisible(isXAxisVisible());
    chart.setXAxisFillColor(getXAxisFillColor());
    chart.setXAxisOutlineColor(getXAxisOutlineColor());
    chart.setXAxisTextFont(getXAxisTextFont());
    chart.setXAxisTextColor(getXAxisTextColor());
    chart.setXAxisText(getXAxisText());
    chart.setXAxisStroke(getXAxisStroke());
    chart.setXAxisUnit(getXAxisUnit());
    chart.setYAxisTextFont(getYAxisTextFont());
    chart.setYAxisVisible(isYAxisVisible());
    chart.setYAxisTextColor(getYAxisTextColor());
    chart.setYAxisFillColor(getYAxisFillColor());
    chart.setYAxisOutlineColor(getYAxisOutlineColor());
    chart.setYAxisStroke(getYAxisStroke());
    chart.setYAxisText(getYAxisText());
    chart.setXScaleTextVisible(isXScaleTextVisible());
    chart.setXScaleTextFormat(getXScaleTextFormat());
    chart.setXScaleTextColor(getXScaleTextColor());
    chart.setXScaleTextFont(getXScaleTextFont());
    chart.setXScaleValueGap(getXScaleValueGap());
    chart.setXScalePixelGap(getXScalePixelGap());
    chart.setXScaleMinValue(getXScaleMinValue());
    chart.setXScaleMaxValue(getXScaleMaxValue());
    chart.setXScaleLineStroke(getXScaleLineStroke());
    chart.setXScaleLineColor(getXScaleLineColor());
    chart.setXScaleLineVisible(isXScaleLineVisible());
    chart.setYScaleTextVisible(isYScaleTextVisible());
    chart.setYScaleTextInside(isYScaleTextInside());
    chart.setYScaleTextFormat(getYScaleTextFormat());
    chart.setYScaleTextColor(getYScaleTextColor());
    chart.setYScaleTextFont(getYScaleTextFont());
    chart.setYScalePixelGap(getYScalePixelGap());
    chart.setYScaleValueGap(getYScaleValueGap());
    chart.setYScaleLineStroke(getYScaleLineStroke());
    chart.setYScaleLineColor(getYScaleLineColor());
    chart.setYScaleLineVisible(isYScaleLineVisible());
    chart.setXAxisStartPosition(getXAxisStartPosition());
    chart.setYAxisStartPosition(getYAxisStartPosition());
    chart.setXScaleTextList(getXScaleTextList());
    chart.setXScaleTextOrientation(getXScaleTextOrientation());
    chart.setXScaleHideValueIndex(getXScaleHideValueIndex());
    chart.setYScaleHideValueIndex(getYScaleHideValueIndex());
    chart.setYScaleValueGapAutoCalculate(isYScaleValueGapAutoCalculate());
    chart.setXAxisUnitVisible(isXAxisUnitVisible());
    chart.setXAxisUnitColor(getXAxisUnitColor());
    chart.setYAxisUnit(getYAxisUnit());
    chart.setYAxisUnitVisible(isYAxisUnitVisible());
    chart.setYAxisUnitColor(getYAxisUnitColor());
    chart.setYAxisUnitFont(getYAxisUnitFont());
    chart.setYScaleMinValue(getYScaleMinValue());
    chart.setYScaleMaxValue(getYScaleMaxValue());
    chart.setXScaleTextOnTop(isXScaleTextOnTop());
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.chart.AbstractXYScaleChart
 * JD-Core Version:    0.7.0.1
 */
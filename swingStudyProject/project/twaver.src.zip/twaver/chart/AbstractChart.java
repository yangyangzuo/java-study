package twaver.chart;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.Rectangle2D.Double;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.CellRendererPane;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.event.MouseInputListener;
import javax.swing.filechooser.FileFilter;
import twaver.BatchAdapter;
import twaver.BatchEvent;
import twaver.BatchListener;
import twaver.DataBoxEvent;
import twaver.DataBoxListener;
import twaver.DataBoxSelectionModel;
import twaver.DataBoxSequenceAdapter;
import twaver.DataBoxSequenceListener;
import twaver.Element;
import twaver.MouseActionEvent;
import twaver.PopupMenuGenerator;
import twaver.SelectableFilter;
import twaver.TDataBox;
import twaver.TUIManager;
import twaver.TView;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.VisibleFilter;
import twaver.base.A.D.O;
import twaver.base.A.E.c;
import twaver.base.A.F.D;
import twaver.swing.RotatableLabel;
import twaver.web.svg.chart.AbstractSVGChart;

public abstract class AbstractChart
  extends JPanel
  implements TView, MouseInputListener, MouseWheelListener
{
  private CellRendererPane ɣ = new CellRendererPane();
  private DataBoxListener ȏ = new DataBoxListener()
  {
    public void elementAdded(DataBoxEvent e)
    {
      AbstractChart.this.publishData(true);
    }
    
    public void elementRemoved(DataBoxEvent e)
    {
      AbstractChart.this.publishData(true);
    }
    
    public void elementsCleared(DataBoxEvent e)
    {
      AbstractChart.this.publishData(true);
    }
  };
  private PropertyChangeListener ɡ = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent evt)
    {
      Element element = (Element)evt.getSource();
      if (("visible".equals(evt.getPropertyName())) && (AbstractChart.this.visibleFilters.size() == 1) && (AbstractChart.this.visibleFilters.get(0) == D.C))
      {
        AbstractChart.this.publishData(true);
      }
      else if (AbstractChart.this.isVisible(element))
      {
        AbstractChart.this.legendPane.A(element);
        AbstractChart.this.publishData(false);
      }
    }
  };
  private DataBoxSequenceListener ȕ = new DataBoxSequenceAdapter()
  {
    public void hiberarchyChanged(Element element)
    {
      if (AbstractChart.this.isIteratorByHiberarchy()) {
        AbstractChart.this.publishData();
      }
    }
  };
  private Point ə = null;
  protected TDataBox box = null;
  protected Comparator sortComparator = null;
  protected List visibleFilters = new ArrayList();
  protected List publishedElements = new ArrayList();
  protected double sum = 0.0D;
  protected double max = 0.0D;
  protected double min = 0.0D;
  protected double range = 0.0D;
  protected List proportionsOfSum = new ArrayList();
  protected List proportionsOfRange = new ArrayList();
  protected Map proportions = new LinkedHashMap();
  protected List shapeStructs = new ArrayList();
  protected JLabel titleLabel = new JLabel();
  protected A chartPane = new A(this);
  protected B legendPane = new B(this);
  protected Rectangle backgroundBounds = new Rectangle();
  protected boolean backgroundVisible = TUIManager.getBoolean("tchart.background.visible");
  protected Color backgroundFillColor = TUIManager.getColor("tchart.background.fill.color");
  protected Color backgroundOutlineColor = TUIManager.getColor("tchart.background.outline.color");
  protected String backgroundStroke = TUIManager.getString("tchart.background.stroke");
  protected boolean backgroundGradient = TUIManager.getBoolean("tchart.background.gradient");
  protected Color backgroundGradientColor = TUIManager.getColor("tchart.background.gradient.color");
  protected int backgroundGradientFactory = TUIManager.getInt("tchart.background.gradient.factory");
  protected Font legendFont = TUIManager.getFont("tchart.legend.font");
  protected int legendLayout = TUIManager.getInt("tchart.legend.layout");
  protected int legendOrientation = TUIManager.getInt("tchart.legend.orientation");
  protected int iconWidth = TUIManager.getInt("tchart.icon.width");
  protected int iconHeight = TUIManager.getInt("tchart.icon.height");
  protected int xGap = TUIManager.getInt("tchart.xgap");
  protected int yGap = TUIManager.getInt("tchart.ygap");
  protected int textGap = TUIManager.getInt("tchart.text.gap");
  protected double upperLimit = TUIManager.getDouble("tchart.upper.limit");
  protected double lowerLimit = TUIManager.getDouble("tchart.lower.limit");
  protected int selectedOffset = TUIManager.getInt("tchart.selected.offset");
  protected Color selectedColor = TUIManager.getColor("tchart.selected.color");
  protected String selectedStroke = TUIManager.getString("tchart.selected.stroke");
  protected Color highlightBackground = TUIManager.getColor("tchart.highlight.background");
  protected Color highlightForeground = TUIManager.getColor("tchart.highlight.foreground");
  protected String unit = TUIManager.getString("tchart.unit");
  protected String stroke = TUIManager.getString("tchart.stroke");
  protected NumberFormat format = TUIManager.getNumberFormat("tchart.format");
  protected boolean valueTextVisible = TUIManager.getBoolean("tchart.value.text.visible");
  protected boolean valueTextCenter = TUIManager.getBoolean("tchart.value.text.center");
  protected Color valueTextColor = TUIManager.getColor("tchart.value.text.color");
  protected Font valueTextFont = TUIManager.getFont("tchart.value.text.font");
  protected int valueTextPosition = TUIManager.getInt("tchart.value.text.positon");
  protected boolean antialias = TUIManager.getBoolean("tchart.antialias");
  protected boolean gradient = TUIManager.getBoolean("tchart.gradient");
  protected int shadowOffset = TUIManager.getInt("tchart.shadow.offset");
  private boolean ɘ = TUIManager.getBoolean("tchart.selectable.on.right.click");
  private boolean ȍ = TUIManager.getBoolean("tchart.clear.selection.on.margin.clicked");
  private boolean ɑ = TUIManager.getBoolean("tchart.enable.double.click.to.reset");
  private boolean ɖ = TUIManager.getBoolean("tchart.enable.tooltiptext");
  private boolean Ȑ = TUIManager.getBoolean("tchart.enable.xtranslate");
  private boolean ɜ = TUIManager.getBoolean("tchart.enable.ytranslate");
  private double ɛ = TUIManager.getDouble("tchart.xtranslate");
  private double ȑ = TUIManager.getDouble("tchart.ytranslate");
  private boolean ɒ = TUIManager.getBoolean("tchart.enable.xzoom");
  private boolean Ȓ = TUIManager.getBoolean("tchart.enable.yzoom");
  private double ɝ = TUIManager.getDouble("tchart.xzoom");
  private double ɔ = TUIManager.getDouble("tchart.yzoom");
  private double Ȗ = TUIManager.getDouble("tchart.zoom.increment");
  private double ɐ = TUIManager.getDouble("tchart.max.zoom");
  private double ɕ = TUIManager.getDouble("tchart.min.zoom");
  protected Color gradientColor = TUIManager.getColor("tchart.gradient.color");
  private PopupMenuGenerator ɠ = TUIManager.getPopupMenuGenerator("tchart.popup.menu.generator");
  private boolean ɗ = TUIManager.getBoolean("tchart.lazy.publish.mode");
  private boolean ɞ = true;
  private boolean ɢ = false;
  private boolean ɟ = false;
  private boolean Ȏ = false;
  private boolean ȓ = false;
  private List ɓ = new ArrayList();
  private List Ȕ = new ArrayList();
  private List ȗ = new LinkedList();
  private BatchListener ɚ = new BatchAdapter()
  {
    public void batchEnded(BatchEvent e)
    {
      AbstractChart.this.publishData(true);
    }
  };
  
  public abstract void paintChart(Graphics2D paramGraphics2D, int paramInt1, int paramInt2);
  
  void A(Graphics2D g, Component c, int x, int y, int w, int h)
  {
    g.setStroke(TWaverConst.BASIC_STROKE);
    this.ɣ.paintComponent(g, c, this.chartPane, x, y, w, h, true);
  }
  
  protected void paintBackground(Graphics2D g)
  {
    if (this.backgroundVisible)
    {
      if (this.backgroundFillColor != null)
      {
        if (this.backgroundGradient)
        {
          O factory = c.E(this.backgroundGradientFactory);
          Paint paint = factory.A(this.backgroundBounds, this.backgroundGradientColor, this.backgroundFillColor);
          g.setPaint(paint);
        }
        else
        {
          g.setColor(this.backgroundFillColor);
        }
        g.fill(this.backgroundBounds);
      }
      if ((this.backgroundOutlineColor != null) && (this.backgroundStroke != null))
      {
        g.setColor(this.backgroundOutlineColor);
        g.setStroke(TUIManager.getStrokeByType(this.backgroundStroke));
        g.draw(this.backgroundBounds);
      }
    }
  }
  
  Dimension A(String text, Font font)
  {
    return A(1, text, font);
  }
  
  Dimension A(int orientation, String text, Font font)
  {
    JLabel label = RotatableLabel.getLabelRenderer(orientation);
    label.setFont(font);
    label.setText(text);
    return label.getPreferredSize();
  }
  
  void A(Graphics2D g, String text, Color color, Font font, int x, int y, int position)
  {
    A(g, 1, text, color, font, x, y, position);
  }
  
  void A(Graphics2D g, LabelStruct s)
  {
    A(g, s.getOrientation(), s.getText(), s.getColor(), s.getFont(), s.getX(), s.getY(), s.getPosition());
  }
  
  void A(Graphics2D g, int orientation, String text, Color color, Font font, int x, int y, int position)
  {
    if ((text == null) || (color == null) || (font == null)) {
      return;
    }
    JLabel label = RotatableLabel.getLabelRenderer(orientation);
    label.setForeground(color);
    label.setFont(font);
    label.setText(text);
    Dimension size = label.getPreferredSize();
    switch (position)
    {
    case 3: 
      A(g, label, x - size.width / 2, y, size.width, size.height);
      break;
    case 8: 
      A(g, label, x - size.width, y, size.width, size.height);
      break;
    case 9: 
      A(g, label, x, y, size.width, size.height);
      break;
    case 1: 
      A(g, label, x - size.width / 2, y - size.height / 2, size.width, size.height);
      break;
    case 2: 
      A(g, label, x - size.width / 2, y - size.height, size.width, size.height);
      break;
    case 4: 
      A(g, label, x - size.width, y - size.height / 2, size.width, size.height);
      break;
    case 5: 
      A(g, label, x, y - size.height / 2, size.width, size.height);
      break;
    case 6: 
      A(g, label, x - size.width, y - size.height, size.width, size.height);
      break;
    case 7: 
      A(g, label, x, y - size.height, size.width, size.height);
      break;
    default: 
      A(g, label, x - size.width / 2, y - size.height / 2, size.width, size.height);
    }
  }
  
  Rectangle2D.Double A(int orientation, String text, Color color, Font font, double x, double y, int position)
  {
    JLabel label = RotatableLabel.getLabelRenderer(orientation);
    label.setForeground(color);
    label.setFont(font);
    label.setText(text);
    Dimension lableSize = label.getPreferredSize();
    Rectangle2D.Double rectangle = null;
    switch (position)
    {
    case 3: 
      rectangle = new Rectangle2D.Double(x - lableSize.width / 2, y, lableSize.width, lableSize.height);
      break;
    case 8: 
      rectangle = new Rectangle2D.Double(x - lableSize.width, y, lableSize.width, lableSize.height);
      break;
    case 9: 
      rectangle = new Rectangle2D.Double(x, y, lableSize.width, lableSize.height);
      break;
    case 1: 
      rectangle = new Rectangle2D.Double(x - lableSize.width / 2, y - lableSize.height / 2, lableSize.width, lableSize.height);
      break;
    case 2: 
      rectangle = new Rectangle2D.Double(x - lableSize.width / 2, y - lableSize.height, lableSize.width, lableSize.height);
      break;
    case 4: 
      rectangle = new Rectangle2D.Double(x - lableSize.width, y - lableSize.height / 2, lableSize.width, lableSize.height);
      break;
    case 5: 
      rectangle = new Rectangle2D.Double(x, y - lableSize.height / 2, lableSize.width, lableSize.height);
      break;
    case 6: 
      rectangle = new Rectangle2D.Double(x - lableSize.width, y - lableSize.height, lableSize.width, lableSize.height);
      break;
    case 7: 
      rectangle = new Rectangle2D.Double(x, y - lableSize.height, lableSize.width, lableSize.height);
      break;
    default: 
      rectangle = new Rectangle2D.Double(x - lableSize.width / 2, y - lableSize.height / 2, lableSize.width, lableSize.height);
    }
    return rectangle;
  }
  
  public void mouseMoved(MouseEvent e) {}
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public void mouseReleased(MouseEvent e)
  {
    this.ə = null;
    this.chartPane.setCursor(Cursor.getPredefinedCursor(0));
    if ((getPopupMenuGenerator() != null) && (SwingUtilities.isRightMouseButton(e)))
    {
      JPopupMenu popMenu = getPopupMenuGenerator().generate(this, e);
      if (popMenu != null)
      {
        popMenu.show(this.chartPane, e.getPoint().x, e.getPoint().y);
        popMenu.requestFocus();
      }
    }
  }
  
  public void mouseDragged(MouseEvent e)
  {
    if ((this.ə != null) && (SwingUtilities.isLeftMouseButton(e)) && ((this.Ȑ) || (this.ɜ)))
    {
      this.chartPane.setCursor(Cursor.getPredefinedCursor(12));
      double x = this.ɛ - (this.ə.x - e.getPoint().x);
      double y = this.ȑ - (this.ə.y - e.getPoint().y);
      setTranslate(x, y);
      this.ə = e.getPoint();
      this.chartPane.repaint();
    }
  }
  
  public void mouseClicked(MouseEvent e)
  {
    if (!SwingUtilities.isLeftMouseButton(e)) {
      return;
    }
    C shapeStruct = A(e.getPoint());
    if (shapeStruct != null)
    {
      MouseActionEvent event = new MouseActionEvent(shapeStruct.C, e, this, shapeStruct.B);
      if (e.getClickCount() == 2) {
        fireElementDoubleClicked(event);
      }
      fireElementClicked(event);
    }
    else if ((this.ɑ) && (e.getClickCount() == 2))
    {
      reset();
    }
  }
  
  public void mousePressed(MouseEvent e)
  {
    this.ə = e.getPoint();
    if (((isSelectableOnRightClick()) && (SwingUtilities.isRightMouseButton(e))) || (SwingUtilities.isLeftMouseButton(e)))
    {
      C shapeStruct = A(e.getPoint());
      Element element;
      Element element;
      if (shapeStruct == null) {
        element = null;
      } else {
        element = shapeStruct.C;
      }
      if (!isSelectable(element)) {
        element = null;
      }
      A(element, e.isControlDown());
    }
  }
  
  public void mouseWheelMoved(MouseWheelEvent e)
  {
    if (e.getWheelRotation() > 0) {
      zoomOut();
    } else {
      zoomIn();
    }
  }
  
  public void lock()
  {
    if (!this.ȓ)
    {
      this.ȓ = true;
      firePropertyChange("locked", false, true);
    }
  }
  
  public boolean isLocked()
  {
    return this.ȓ;
  }
  
  public void unlock()
  {
    if (this.ȓ)
    {
      this.ȓ = false;
      publishData(true);
      firePropertyChange("locked", true, false);
    }
  }
  
  void A(Element element, boolean isControlDown)
  {
    if (element == null)
    {
      if ((!isControlDown) && (this.box.getSelectionModel().size() > 0) && (isClearSelectionOnMarginClicked())) {
        this.box.getSelectionModel().clearSelection();
      }
    }
    else if (!element.isSelected())
    {
      if (isControlDown) {
        this.box.getSelectionModel().appendSelection(element);
      } else {
        this.box.getSelectionModel().setSelection(element);
      }
    }
    else if (isControlDown) {
      this.box.getSelectionModel().removeSelection(element);
    } else {
      this.box.getSelectionModel().setSelection(element);
    }
  }
  
  public AbstractChart()
  {
    this(new TDataBox());
  }
  
  public AbstractChart(TDataBox box)
  {
    this(box, null, null);
  }
  
  public AbstractChart(TDataBox box, String title, Color backgroundColor)
  {
    this(box, title, backgroundColor, null);
  }
  
  public AbstractChart(TDataBox box, String title, Color backgroundColor, Color foregroundColor)
  {
    A(box, title, backgroundColor, foregroundColor);
  }
  
  public AbstractChart(List elements)
  {
    this(elements, null, null, null);
  }
  
  public AbstractChart(List elements, String title)
  {
    this(elements, title, null, null);
  }
  
  public AbstractChart(List elements, String title, Color backgroundColor)
  {
    this(elements, title, backgroundColor, null);
  }
  
  public AbstractChart(List elements, String title, Color backgroundColor, Color foregroundColor)
  {
    TDataBox box = new TDataBox();
    if (elements != null)
    {
      Iterator it = elements.iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        box.addElement(element);
      }
    }
    A(box, title, backgroundColor, foregroundColor);
  }
  
  private void A(TDataBox box, String title, Color backgroundColor, Color foregroundColor)
  {
    this.visibleFilters.add(D.C);
    this.titleLabel.setText(title);
    this.titleLabel.setOpaque(false);
    this.titleLabel.setHorizontalAlignment(0);
    this.titleLabel.setVerticalAlignment(0);
    this.chartPane.add(this.ɣ);
    setOpaque(true);
    setLayout(new BorderLayout());
    add(this.titleLabel, "North");
    add(this.chartPane, "Center");
    f();
    setDataBox(box);
    if (backgroundColor == null) {
      setBackground(Color.WHITE);
    } else {
      setBackground(backgroundColor);
    }
    if (foregroundColor == null) {
      setForeground(Color.BLACK);
    } else {
      setForeground(foregroundColor);
    }
    this.chartPane.addMouseListener(this);
    this.chartPane.addMouseMotionListener(this);
    this.chartPane.addMouseWheelListener(this);
  }
  
  public TDataBox getDataBox()
  {
    return this.box;
  }
  
  public void setDataBox(TDataBox box)
  {
    if (box == null) {
      throw new IllegalArgumentException("DataBox must be non null");
    }
    if (this.box != null) {
      e();
    }
    Object oldValue = this.box;
    this.box = box;
    g();
    publishData(true);
    firePropertyChange("databox", oldValue, this.box);
  }
  
  private void g()
  {
    this.box.addBatchListener(this.ɚ);
    this.box.addDataBoxListener(this.ȏ);
    this.box.addDataBoxSequenceListener(this.ȕ);
    this.box.addElementPropertyChangeListener(this.ɡ);
  }
  
  private void e()
  {
    this.box.removeBatchListener(this.ɚ);
    this.box.removeDataBoxListener(this.ȏ);
    this.box.removeDataBoxSequenceListener(this.ȕ);
    this.box.removeElementPropertyChangeListener(this.ɡ);
  }
  
  public void updateTViewUI()
  {
    publishData(true);
  }
  
  public Element getElementAt(Point point)
  {
    C shapeStruct = A(point);
    if (shapeStruct == null) {
      return null;
    }
    return shapeStruct.C;
  }
  
  C A(Point point)
  {
    point = new Point(point.x - (int)this.ɛ, point.y - (int)this.ȑ);
    Iterator it = this.shapeStructs.iterator();
    while (it.hasNext())
    {
      C shapeStruct = (C)it.next();
      if (shapeStruct.A(point)) {
        return shapeStruct;
      }
    }
    return null;
  }
  
  public void setTitle(String title)
  {
    this.titleLabel.setText(title);
  }
  
  public String getTitle()
  {
    return this.titleLabel.getText();
  }
  
  public void addItem(Item item)
  {
    if (!this.box.contains(item)) {
      this.box.addElement(item);
    }
  }
  
  public void removeItem(Item item)
  {
    this.box.removeElement(item);
  }
  
  public void clearItems()
  {
    this.box.clear();
  }
  
  public int getItemCount()
  {
    return this.publishedElements.size();
  }
  
  public List getItems()
  {
    return this.publishedElements;
  }
  
  public Item getItemByIndex(int index)
  {
    return (Item)this.publishedElements.get(index);
  }
  
  public void setItems(List items)
  {
    this.box.clear();
    this.box.addElements(items);
  }
  
  public void paint(Graphics g)
  {
    cleanDirtyState();
    super.paint(g);
  }
  
  public void cleanDirtyState()
  {
    if (this.ɢ)
    {
      this.ɢ = false;
      this.Ȏ = true;
      publishData(this.ɟ);
      this.Ȏ = false;
      this.ɟ = false;
    }
  }
  
  protected abstract void calculate();
  
  public void publishData()
  {
    publishData(true);
  }
  
  public void publishData(boolean updateLegendLayout)
  {
    if ((isLocked()) || (this.box.isBatching())) {
      return;
    }
    if ((!this.Ȏ) && (isLazyPublishMode()))
    {
      this.ɢ = true;
      if (!this.ɟ) {
        this.ɟ = updateLegendLayout;
      }
      repaint();
      return;
    }
    this.publishedElements.clear();
    if (isIteratorByHiberarchy())
    {
      Enumeration e = this.box.breadthFirstEnumeration();
      while (e.hasMoreElements())
      {
        Element element = (Element)e.nextElement();
        if (isVisible(element)) {
          this.publishedElements.add(element);
        }
      }
    }
    else
    {
      Iterator it = this.box.iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if (isVisible(element)) {
          this.publishedElements.add(element);
        }
      }
    }
    if (this.sortComparator != null) {
      Collections.sort(this.publishedElements, this.sortComparator);
    }
    calculate();
    if (updateLegendLayout) {
      this.legendPane.A();
    } else {
      this.legendPane.B();
    }
    this.chartPane.repaint();
  }
  
  public boolean isIteratorByHiberarchy()
  {
    return this.ɞ;
  }
  
  public void setIteratorByHiberarchy(boolean iteratorByHiberarchy)
  {
    if (this.ɞ != iteratorByHiberarchy)
    {
      this.ɞ = iteratorByHiberarchy;
      publishData(true);
    }
  }
  
  public List getElementDoubleClickedActionListeners()
  {
    return this.ɓ;
  }
  
  public List getElementClickedActionListeners()
  {
    return this.Ȕ;
  }
  
  public void addElementDoubleClickedActionListener(ActionListener l)
  {
    if (!this.ɓ.contains(l)) {
      this.ɓ.add(l);
    }
  }
  
  public void removeElementDoubleClickedActionListener(ActionListener l)
  {
    this.ɓ.remove(l);
  }
  
  public void fireElementDoubleClicked(MouseActionEvent event)
  {
    for (int i = 0; i < this.ɓ.size(); i++)
    {
      ActionListener l = (ActionListener)this.ɓ.get(i);
      l.actionPerformed(event);
    }
  }
  
  public void addElementClickedActionListener(ActionListener l)
  {
    if (!this.Ȕ.contains(l)) {
      this.Ȕ.add(l);
    }
  }
  
  public void removeElementClickedActionListener(ActionListener l)
  {
    this.Ȕ.remove(l);
  }
  
  public void fireElementClicked(MouseActionEvent event)
  {
    for (int i = 0; i < this.Ȕ.size(); i++)
    {
      ActionListener l = (ActionListener)this.Ȕ.get(i);
      l.actionPerformed(event);
    }
  }
  
  public double getUpperLimit()
  {
    return this.upperLimit;
  }
  
  public void setUpperLimit(double upperLimit)
  {
    this.upperLimit = upperLimit;
    publishData(false);
  }
  
  public void setForeground(Color foregroundColor)
  {
    super.setForeground(foregroundColor);
    if (this.legendPane != null) {
      this.legendPane.B();
    }
    if (this.titleLabel != null) {
      this.titleLabel.setForeground(foregroundColor);
    }
  }
  
  public JComponent getChartPane()
  {
    return this.chartPane;
  }
  
  public JPanel getLegendPane()
  {
    return this.legendPane;
  }
  
  public JLabel getTitleLabel()
  {
    return this.titleLabel;
  }
  
  public int getLegendLayout()
  {
    return this.legendLayout;
  }
  
  public void setLegendLayout(int legendLayout)
  {
    if (this.legendLayout != legendLayout)
    {
      this.legendLayout = legendLayout;
      this.legendPane.A();
      remove(this.legendPane);
      f();
      validate();
    }
  }
  
  private void f()
  {
    if ((this.legendLayout == 1) || (this.legendLayout == 6) || (this.legendLayout == 10)) {
      add(this.legendPane, "South");
    } else if ((this.legendLayout == 2) || (this.legendLayout == 4) || (this.legendLayout == 8)) {
      add(this.legendPane, "East");
    } else if ((this.legendLayout == 7) || (this.legendLayout == 3)) {
      add(this.legendPane, "West");
    } else if ((this.legendLayout == 9) || (this.legendLayout == 5)) {
      add(this.legendPane, "North");
    }
  }
  
  public int getIconHeight()
  {
    return this.iconHeight;
  }
  
  public void setIconHeight(int iconHeight)
  {
    this.iconHeight = iconHeight;
    this.legendPane.revalidate();
    this.legendPane.repaint();
  }
  
  public int getIconWidth()
  {
    return this.iconWidth;
  }
  
  public void setIconWidth(int iconWidth)
  {
    this.iconWidth = iconWidth;
    this.legendPane.revalidate();
    this.legendPane.repaint();
  }
  
  public int getXGap()
  {
    return this.xGap;
  }
  
  public void setXGap(int gap)
  {
    this.xGap = gap;
    this.chartPane.repaint();
  }
  
  public int getYGap()
  {
    return this.yGap;
  }
  
  public void setYGap(int gap)
  {
    this.yGap = gap;
    this.chartPane.repaint();
  }
  
  public boolean isValueTextVisible()
  {
    return this.valueTextVisible;
  }
  
  public void setValueTextVisible(boolean valueTextVisible)
  {
    this.valueTextVisible = valueTextVisible;
    this.chartPane.repaint();
  }
  
  public Color getValueTextColor()
  {
    return this.valueTextColor;
  }
  
  public void setValueTextColor(Color valueTextColor)
  {
    this.valueTextColor = valueTextColor;
    this.chartPane.repaint();
  }
  
  public Font getValueTextFont()
  {
    return this.valueTextFont;
  }
  
  public void setValueTextFont(Font valueTextFont)
  {
    this.valueTextFont = valueTextFont;
    this.chartPane.repaint();
  }
  
  public NumberFormat getFormat()
  {
    return this.format;
  }
  
  public void setFormat(NumberFormat format)
  {
    this.format = format;
    this.chartPane.repaint();
  }
  
  public Font getLegendFont()
  {
    return this.legendFont;
  }
  
  public void setLegendFont(Font legendFont)
  {
    this.legendFont = legendFont;
    for (int i = 0; i < this.legendPane.getComponentCount(); i++)
    {
      JLabel label = (JLabel)this.legendPane.getComponent(i);
      if (this.legendFont != null) {
        label.setFont(this.legendFont);
      } else {
        label.setFont(TUIManager.getDefaultFont());
      }
    }
  }
  
  public boolean isAntialias()
  {
    return this.antialias;
  }
  
  public void setAntialias(boolean antialias)
  {
    this.antialias = antialias;
    this.chartPane.repaint();
  }
  
  public Comparator getSortComparator()
  {
    return this.sortComparator;
  }
  
  public void setSortComparator(Comparator sortComparator)
  {
    this.sortComparator = sortComparator;
    publishData(true);
  }
  
  public void addVisibleFilter(VisibleFilter visibleFilter)
  {
    if ((visibleFilter != null) && (!this.visibleFilters.contains(visibleFilter)))
    {
      this.visibleFilters.add(visibleFilter);
      publishData(true);
    }
  }
  
  public void removeVisibleFilter(VisibleFilter visibleFilter)
  {
    if (visibleFilter != null)
    {
      this.visibleFilters.remove(visibleFilter);
      publishData(true);
    }
  }
  
  public List getVisibleFilters()
  {
    return new ArrayList(this.visibleFilters);
  }
  
  public boolean isVisible(Element element)
  {
    if (!this.box.contains(element)) {
      return false;
    }
    Iterator it = this.visibleFilters.iterator();
    while (it.hasNext())
    {
      VisibleFilter filter = (VisibleFilter)it.next();
      if (!filter.isVisible(element)) {
        return false;
      }
    }
    return true;
  }
  
  public void addSelectableFilter(SelectableFilter filter)
  {
    if ((filter != null) && (!this.ȗ.contains(filter))) {
      this.ȗ.add(filter);
    }
  }
  
  public void removeSelectableFilter(SelectableFilter filter)
  {
    if (filter != null) {
      this.ȗ.remove(filter);
    }
  }
  
  public List getSelectableFilters()
  {
    return new ArrayList(this.ȗ);
  }
  
  public void clearSelectableFilters()
  {
    this.ȗ.clear();
  }
  
  public boolean isSelectable(Element element)
  {
    if (element == null) {
      return false;
    }
    Iterator it = this.ȗ.iterator();
    while (it.hasNext())
    {
      SelectableFilter filter = (SelectableFilter)it.next();
      if (!filter.isSelectable(element)) {
        return false;
      }
    }
    return true;
  }
  
  public boolean isLazyPublishMode()
  {
    return this.ɗ;
  }
  
  public void setLazyPublishMode(boolean lazyPublishMode)
  {
    this.ɗ = lazyPublishMode;
  }
  
  public double getLowerLimit()
  {
    return this.lowerLimit;
  }
  
  public void setLowerLimit(double lowerLimit)
  {
    this.lowerLimit = lowerLimit;
    publishData(false);
  }
  
  public Color getSelectedColor()
  {
    return this.selectedColor;
  }
  
  public void setSelectedColor(Color selectedColor)
  {
    this.selectedColor = selectedColor;
    this.chartPane.repaint();
  }
  
  public Color getHighlightBackground()
  {
    return this.highlightBackground;
  }
  
  public void setHighlightBackground(Color highlightBackground)
  {
    this.highlightBackground = highlightBackground;
    this.legendPane.B();
  }
  
  public Color getHighlightForeground()
  {
    return this.highlightForeground;
  }
  
  public void setHighlightForeground(Color highlightForeground)
  {
    this.highlightForeground = highlightForeground;
    this.legendPane.B();
  }
  
  public Color getSelectedColor(Element element)
  {
    if (this.selectedColor == null) {
      return getColor(element).darker();
    }
    return this.selectedColor;
  }
  
  public Stroke getSelectedStroke(Element element)
  {
    if (this.selectedStroke == null) {
      return TWaverConst.DOUBLE_WIDTH_STROKE;
    }
    return TUIManager.getStrokeByType(this.selectedStroke);
  }
  
  protected Color getGradientColor(Element element)
  {
    return this.gradientColor;
  }
  
  protected String getFormatedText(Element element, double value)
  {
    return getFormatedText(element, value, -1);
  }
  
  protected String getFormatedText(Element element, double value, int index)
  {
    NumberFormat format = getFormat(element);
    String ret = format.format(value);
    if (this.unit != null) {
      ret = ret + this.unit;
    }
    return ret;
  }
  
  public Color getColor(Element element)
  {
    return element.getChartColor();
  }
  
  public double getValue(Element element)
  {
    return element.getChartValue();
  }
  
  public double getMax(Element element)
  {
    return element.getChartMax();
  }
  
  public double getMin(Element element)
  {
    return element.getChartMin();
  }
  
  public String getLegendLabel(Element element)
  {
    return element.getName();
  }
  
  public String getToolTipText(Element element)
  {
    if (!isEnableToolTipText()) {
      return null;
    }
    String text = element.getToolTipText();
    if (text == null) {
      text = getLegendLabel(element);
    }
    return text;
  }
  
  public NumberFormat getFormat(Element element)
  {
    NumberFormat format = (NumberFormat)element.getClientProperty("chart.format");
    if (format != null) {
      return format;
    }
    if (this.format != null) {
      return this.format;
    }
    return TUIManager.getNumberFormat("chart.format");
  }
  
  public Stroke getStroke(Element element)
  {
    String value = (String)element.getClientProperty("chart.stroke");
    if (value != null) {
      return TUIManager.getStrokeByType(value);
    }
    if (this.stroke != null) {
      return TUIManager.getStrokeByType(this.stroke);
    }
    return TUIManager.getStrokeByType(TUIManager.getString("chart.stroke"));
  }
  
  public List getValues(Element element)
  {
    return element.getChartValues();
  }
  
  public List getPublishedElements()
  {
    cleanDirtyState();
    return this.publishedElements;
  }
  
  protected List getLegendElements()
  {
    return getPublishedElements();
  }
  
  public String getStroke()
  {
    return this.stroke;
  }
  
  public void setStroke(String stroke)
  {
    this.stroke = stroke;
    this.chartPane.repaint();
  }
  
  public String getUnit()
  {
    return this.unit;
  }
  
  public void setUnit(String unit)
  {
    this.unit = unit;
    this.chartPane.repaint();
  }
  
  public String getSelectedStroke()
  {
    return this.selectedStroke;
  }
  
  public void setSelectedStroke(String selectedStroke)
  {
    this.selectedStroke = selectedStroke;
    this.chartPane.repaint();
  }
  
  public int getSelectedOffset()
  {
    return this.selectedOffset;
  }
  
  public void setSelectedOffset(int selectedOffset)
  {
    this.selectedOffset = selectedOffset;
    this.chartPane.repaint();
  }
  
  public int getShadowOffset()
  {
    return this.shadowOffset;
  }
  
  public void setShadowOffset(int shadowOffset)
  {
    this.shadowOffset = shadowOffset;
    this.chartPane.repaint();
  }
  
  public int getLegendOrientation()
  {
    return this.legendOrientation;
  }
  
  public void setLegendOrientation(int legendOrientation)
  {
    this.legendOrientation = legendOrientation;
    this.legendPane.A();
  }
  
  public boolean isGradient()
  {
    return this.gradient;
  }
  
  public void setGradient(boolean gradient)
  {
    this.gradient = gradient;
    this.chartPane.repaint();
  }
  
  public boolean isValueTextCenter()
  {
    return this.valueTextCenter;
  }
  
  public void setValueTextCenter(boolean valueTextCenter)
  {
    this.valueTextCenter = valueTextCenter;
    this.chartPane.repaint();
  }
  
  public int getTextGap()
  {
    return this.textGap;
  }
  
  public void setTextGap(int textGap)
  {
    this.textGap = textGap;
    this.chartPane.repaint();
  }
  
  public void setTranslate(double x, double y)
  {
    this.ɛ = x;
    this.ȑ = y;
    if (!this.Ȑ) {
      this.ɛ = 0.0D;
    }
    if (!this.ɜ) {
      this.ȑ = 0.0D;
    }
    this.chartPane.repaint();
  }
  
  public double getXZoom()
  {
    return this.ɝ;
  }
  
  public void setXZoom(double zoom)
  {
    if ((this.ɒ) && (zoom >= this.ɕ) && (zoom <= this.ɐ))
    {
      double w = (this.chartPane.getWidth() / 2 - this.ɛ) / this.ɝ;
      double offset = (int)(w * (zoom - this.ɝ));
      this.ɝ = zoom;
      setTranslate(this.ɛ - offset, this.ȑ);
    }
  }
  
  public double getYZoom()
  {
    return this.ɔ;
  }
  
  public void setYZoom(double zoom)
  {
    if ((this.Ȓ) && (zoom >= this.ɕ) && (zoom <= this.ɐ))
    {
      double h = (this.chartPane.getHeight() / 2 - this.ȑ) / this.ɔ;
      int offset = (int)(h * (zoom - this.ɔ));
      this.ɔ = zoom;
      setTranslate(this.ɛ, this.ȑ - offset);
    }
  }
  
  public double getZoomIncrement()
  {
    return this.Ȗ;
  }
  
  public void setZoomIncrement(double zoomIncrement)
  {
    this.Ȗ = zoomIncrement;
  }
  
  public double getMaxZoom()
  {
    return this.ɐ;
  }
  
  public void setMaxZoom(double maxZoom)
  {
    this.ɐ = maxZoom;
    if (this.ɝ > maxZoom)
    {
      this.ɝ = maxZoom;
      this.chartPane.repaint();
    }
    if (this.ɔ > maxZoom)
    {
      this.ɔ = maxZoom;
      this.chartPane.repaint();
    }
  }
  
  public double getMinZoom()
  {
    return this.ɕ;
  }
  
  public void setMinZoom(double minZoom)
  {
    this.ɕ = minZoom;
    if (this.ɝ < minZoom)
    {
      this.ɝ = minZoom;
      this.chartPane.repaint();
    }
    if (this.ɔ < minZoom)
    {
      this.ɔ = minZoom;
      this.chartPane.repaint();
    }
  }
  
  public void reset()
  {
    this.ɝ = 1.0D;
    this.ɔ = 1.0D;
    this.ɛ = 0.0D;
    this.ȑ = 0.0D;
    this.chartPane.repaint();
  }
  
  public boolean isEnableXTranslate()
  {
    return this.Ȑ;
  }
  
  public void setEnableXTranslate(boolean enableXTranslate)
  {
    this.Ȑ = enableXTranslate;
  }
  
  public boolean isEnableXZoom()
  {
    return this.ɒ;
  }
  
  public void setEnableXZoom(boolean enableXZoom)
  {
    this.ɒ = enableXZoom;
  }
  
  public boolean isEnableYTranslate()
  {
    return this.ɜ;
  }
  
  public void setEnableYTranslate(boolean enableYTranslate)
  {
    this.ɜ = enableYTranslate;
  }
  
  public boolean isEnableYZoom()
  {
    return this.Ȓ;
  }
  
  public void setEnableYZoom(boolean enableYZoom)
  {
    this.Ȓ = enableYZoom;
  }
  
  public double getXTranslate()
  {
    return this.ɛ;
  }
  
  public void setXTranslate(double translate)
  {
    this.ɛ = translate;
  }
  
  public double getYTranslate()
  {
    return this.ȑ;
  }
  
  public void setYTranslate(double translate)
  {
    this.ȑ = translate;
  }
  
  public void zoomIn()
  {
    setXZoom(this.ɝ * this.Ȗ);
    setYZoom(this.ɔ * this.Ȗ);
  }
  
  public void zoomOut()
  {
    setXZoom(this.ɝ / this.Ȗ);
    setYZoom(this.ɔ / this.Ȗ);
  }
  
  public PopupMenuGenerator getPopupMenuGenerator()
  {
    return this.ɠ;
  }
  
  public void setPopupMenuGenerator(PopupMenuGenerator popupMenuGenerator)
  {
    this.ɠ = popupMenuGenerator;
  }
  
  public boolean isSelectableOnRightClick()
  {
    return this.ɘ;
  }
  
  public void setSelectableOnRightClick(boolean isSelectableOnRightClick)
  {
    this.ɘ = isSelectableOnRightClick;
  }
  
  public boolean isClearSelectionOnMarginClicked()
  {
    return this.ȍ;
  }
  
  public void setClearSelectionOnMarginClicked(boolean isClearSelectionOnMarginClicked)
  {
    this.ȍ = isClearSelectionOnMarginClicked;
  }
  
  public boolean isEnableDoubleClickToReset()
  {
    return this.ɑ;
  }
  
  public void setEnableDoubleClickToReset(boolean enableDoubleClickToReset)
  {
    this.ɑ = enableDoubleClickToReset;
  }
  
  public boolean isEnableToolTipText()
  {
    return this.ɖ;
  }
  
  public void setEnableToolTipText(boolean enableToolTipText)
  {
    this.ɖ = enableToolTipText;
    this.chartPane.repaint();
  }
  
  public Color getBackgroundFillColor()
  {
    return this.backgroundFillColor;
  }
  
  public void setBackgroundFillColor(Color backgroundFillColor)
  {
    this.backgroundFillColor = backgroundFillColor;
    this.chartPane.repaint();
  }
  
  public Color getBackgroundOutlineColor()
  {
    return this.backgroundOutlineColor;
  }
  
  public void setBackgroundOutlineColor(Color backgroundOutlineColor)
  {
    this.backgroundOutlineColor = backgroundOutlineColor;
    this.chartPane.repaint();
  }
  
  public String getBackgroundStroke()
  {
    return this.backgroundStroke;
  }
  
  public void setBackgroundStroke(String backgroundStroke)
  {
    this.backgroundStroke = backgroundStroke;
    this.chartPane.repaint();
  }
  
  public boolean isBackgroundVisible()
  {
    return this.backgroundVisible;
  }
  
  public void setBackgroundVisible(boolean backgroundVisible)
  {
    this.backgroundVisible = backgroundVisible;
    this.chartPane.repaint();
  }
  
  public Rectangle getBackgroundBounds()
  {
    return (Rectangle)this.backgroundBounds.clone();
  }
  
  public boolean exportImage(String fileName, String formatName, boolean wholeChart)
  {
    if (wholeChart) {
      return TWaverUtil.exportImage(this, fileName, formatName);
    }
    ChartExporter exporter = new ChartExporter(this, formatName, null);
    return exporter.exportToFile(fileName);
  }
  
  public boolean exportToImageIcon(String iconUrl, String formatName, boolean wholeChart)
  {
    if (wholeChart) {
      return TWaverUtil.exportToImageIcon(this, iconUrl, formatName);
    }
    ChartExporter exporter = new ChartExporter(this, formatName, null);
    return exporter.exportToImageIcon(iconUrl);
  }
  
  public boolean exportImage(JFileChooser chooser, boolean wholeChart)
  {
    int returnVal = chooser.showSaveDialog(this);
    if (returnVal != 0) {
      return false;
    }
    String fileName = chooser.getSelectedFile().getAbsolutePath();
    String formatName = chooser.getFileFilter().getDescription();
    return exportImage(fileName, formatName, wholeChart);
  }
  
  public boolean isBackgroundGradient()
  {
    return this.backgroundGradient;
  }
  
  public void setBackgroundGradient(boolean backgroundGradient)
  {
    this.backgroundGradient = backgroundGradient;
    this.chartPane.repaint();
  }
  
  public Color getBackgroundGradientColor()
  {
    return this.backgroundGradientColor;
  }
  
  public void setBackgroundGradientColor(Color backgroundGradientColor)
  {
    this.backgroundGradientColor = backgroundGradientColor;
    this.chartPane.repaint();
  }
  
  public int getBackgroundGradientFactory()
  {
    return this.backgroundGradientFactory;
  }
  
  public void setBackgroundGradientFactory(int backgroundGradientFactory)
  {
    this.backgroundGradientFactory = backgroundGradientFactory;
    this.chartPane.repaint();
  }
  
  public int getValueTextPosition()
  {
    return this.valueTextPosition;
  }
  
  public void setValueTextPosition(int valueTextPosition)
  {
    this.valueTextPosition = valueTextPosition;
    this.chartPane.repaint();
  }
  
  public Color getGradientColor()
  {
    return this.gradientColor;
  }
  
  public void setGradientColor(Color gradientColor)
  {
    this.gradientColor = gradientColor;
    this.chartPane.repaint();
  }
  
  public void exportSVG(String fileName, int width, int height) {}
  
  public void exportSVG(String fileName)
  {
    exportSVG(fileName, getWidth(), getHeight());
  }
  
  protected void setChartSVGAttribute(AbstractSVGChart chart)
  {
    chart.setDataBox(this.box);
    chart.setBackgroundColor(getBackground());
    chart.setGradient(isGradient());
    chart.setLowerLimit(getLowerLimit());
    chart.setSelectedOffset(getSelectedOffset());
    chart.setShadowOffset(getShadowOffset());
    chart.setStroke(getStroke());
    chart.setTextGap(getTextGap());
    chart.setUpperLimit(getUpperLimit());
    chart.setValueTextFont(getValueTextFont());
    chart.setValueTextVisible(isValueTextVisible());
    chart.setXGap(getXGap());
    chart.setYGap(getYGap());
    chart.setSortComparator(getSortComparator());
    chart.setUnit(getUnit());
    chart.setFormat(getFormat());
    chart.setValueTextCenter(isValueTextCenter());
    chart.setValueTextColor(getValueTextColor());
    chart.setBackgroundFillColor(getBackgroundFillColor());
    chart.setBackgroundGradient(isBackgroundGradient());
    chart.setBackgroundGradientColor(getBackgroundGradientColor());
    chart.setBackgroundGradientFactory(getBackgroundGradientFactory());
    chart.setBackgroundOutlineColor(getBackgroundOutlineColor());
    chart.setBackgroundStroke(getBackgroundStroke());
    chart.setBackgroundVisible(isBackgroundVisible());
    chart.setGradient(isGradient());
    int size = getVisibleFilters().size();
    for (int i = 0; i < size; i++) {
      chart.addVisibleFilter((VisibleFilter)this.visibleFilters.get(i));
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.chart.AbstractChart
 * JD-Core Version:    0.7.0.1
 */
package twaver.chart;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.JLabel;
import javax.swing.JPanel;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.MouseActionEvent;
import twaver.TDataBox;
import twaver.TUIManager;
import twaver.swing.RotatableLabel;
import twaver.swing.TableLayout;

class B
  extends JPanel
{
  AbstractChart C;
  Map A = new HashMap();
  Map D = new HashMap();
  MouseAdapter B = new MouseAdapter()
  {
    public void mousePressed(MouseEvent e)
    {
      JLabel label = (JLabel)e.getSource();
      Element element = (Element)B.this.D.get(label);
      if (B.this.C.isSelectable(element)) {
        B.this.C.A(element, e.isControlDown());
      } else {
        B.this.C.A(null, e.isControlDown());
      }
      if (e.getClickCount() == 1) {
        B.this.C.fireElementClicked(new MouseActionEvent(element, e, B.this.C));
      } else if (e.getClickCount() == 2) {
        B.this.C.fireElementDoubleClicked(new MouseActionEvent(element, e, B.this.C));
      }
    }
  };
  
  B(AbstractChart chart)
  {
    this.C = chart;
    setOpaque(false);
    addMouseListener(new MouseAdapter()
    {
      private final AbstractChart val$chart;
      
      public void mouseReleased(MouseEvent e)
      {
        if (!e.isControlDown()) {
          this.val$chart.box.getSelectionModel().clearSelection();
        }
      }
    });
  }
  
  public void setVisible(boolean visible)
  {
    super.setVisible(visible);
    if (!visible) {
      removeAll();
    } else {
      A();
    }
  }
  
  void A()
  {
    removeAll();
    this.A.clear();
    this.D.clear();
    if (!isVisible()) {
      return;
    }
    List elements = this.C.getLegendElements();
    int count = elements.size();
    if ((this.C.legendLayout == 1) || (this.C.legendLayout == 4) || (this.C.legendLayout == 5) || (this.C.legendLayout == 6) || (this.C.legendLayout == 3))
    {
      double[] rows = { -1.0D, -2.0D, -1.0D };
      double[] columns = new double[count + 2];
      columns[0] = -1.0D;
      for (int i = 0; i < count; i++) {
        columns[(i + 1)] = -2.0D;
      }
      columns[(count + 1)] = -1.0D;
      TableLayout layout = new TableLayout(columns, rows);
      layout.setVGap(1);
      layout.setHGap(1);
      setLayout(layout);
    }
    else
    {
      double[] rows = new double[count + 2];
      double[] columns = { -1.0D, -2.0D, -1.0D };
      rows[0] = -1.0D;
      for (int i = 0; i < count; i++) {
        rows[(i + 1)] = -2.0D;
      }
      rows[(count + 1)] = -1.0D;
      TableLayout layout = new TableLayout(columns, rows);
      layout.setVGap(1);
      layout.setHGap(1);
      setLayout(layout);
    }
    for (int i = 0; i < count; i++)
    {
      Element element = (Element)elements.get(i);
      JLabel label;
      JLabel label;
      if (this.C.legendOrientation == 1)
      {
        label = new JLabel();
      }
      else
      {
        label = new RotatableLabel(this.C.legendOrientation);
        if (this.C.legendOrientation == 2)
        {
          label.setHorizontalAlignment(0);
          label.setVerticalAlignment(1);
          label.setHorizontalTextPosition(0);
          label.setVerticalTextPosition(3);
        }
      }
      this.A.put(element, label);
      this.D.put(label, element);
      label.setOpaque(false);
      label.setIconTextGap(1);
      label.addMouseListener(this.B);
      label.setIcon(new D(this.C, element));
      label.setHorizontalAlignment(10);
      A(element, label);
      if ((this.C.legendLayout == 1) || (this.C.legendLayout == 4) || (this.C.legendLayout == 5) || (this.C.legendLayout == 6) || (this.C.legendLayout == 3)) {
        add(label, i + 1 + ",1");
      } else {
        add(label, "1," + (i + 1));
      }
    }
    this.C.validate();
  }
  
  void B()
  {
    Iterator it = this.A.keySet().iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      A(element);
    }
  }
  
  void A(Element element)
  {
    A(element, (JLabel)this.A.get(element));
  }
  
  private void A(Element element, JLabel label)
  {
    if ((element != null) && (label != null))
    {
      label.setText(this.C.getLegendLabel(element));
      label.setToolTipText(this.C.getToolTipText(element));
      if (this.C.legendFont != null) {
        label.setFont(this.C.legendFont);
      } else {
        label.setFont(TUIManager.getDefaultFont());
      }
      if (element.isSelected())
      {
        label.setOpaque(true);
        label.setBackground(this.C.highlightBackground);
        label.setForeground(this.C.highlightForeground);
      }
      else
      {
        label.setOpaque(false);
        label.setForeground(this.C.getForeground());
      }
      repaint();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.chart.B
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface AlarmModelListener
{
  public abstract void alarmAdded(AlarmModelEvent paramAlarmModelEvent);
  
  public abstract void alarmRemoved(AlarmModelEvent paramAlarmModelEvent);
  
  public abstract void alarmCleared(AlarmModelEvent paramAlarmModelEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmModelListener
 * JD-Core Version:    0.7.0.1
 */
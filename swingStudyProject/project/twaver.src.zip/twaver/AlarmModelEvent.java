package twaver;

import java.io.Serializable;
import java.util.EventObject;

public class AlarmModelEvent
  extends EventObject
  implements Serializable
{
  public static final int ALARM_ADDED = 1;
  public static final int ALARM_REMOVED = 2;
  public static final int ALARM_CLEARED = 3;
  private Alarm B = null;
  private int A;
  
  public AlarmModelEvent(AlarmModel model, Alarm alarm, int type)
  {
    super(model);
    this.B = alarm;
    if ((type != 1) && (type != 2) && (type != 3)) {
      throw new IllegalArgumentException("illegal alarm model event type:" + type);
    }
    this.A = type;
  }
  
  public AlarmModel getAlarmModel()
  {
    return (AlarmModel)this.source;
  }
  
  public Alarm getAlarm()
  {
    return this.B;
  }
  
  public int getType()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmModelEvent
 * JD-Core Version:    0.7.0.1
 */
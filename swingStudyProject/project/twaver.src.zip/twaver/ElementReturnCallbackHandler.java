package twaver;

public abstract interface ElementReturnCallbackHandler
  extends ElementCallbackHandler
{
  public abstract Object getReturnValue();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementReturnCallbackHandler
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import twaver.chart.Bubble;

public abstract interface Element
  extends Serializable
{
  public abstract Object getID();
  
  public abstract GeoCoordinate getGeoCoordinate();
  
  public abstract void setGeoCoordinate(GeoCoordinate paramGeoCoordinate);
  
  public abstract String getName();
  
  public abstract String getDisplayName();
  
  public abstract String getUIClassID();
  
  public abstract String getSVGUIClassID();
  
  public abstract Object getUserObject();
  
  public abstract String getIconURL();
  
  public abstract ImageIcon getIcon();
  
  public abstract void setIcon(String paramString);
  
  public abstract String getImageURL();
  
  public abstract ImageIcon getImage();
  
  public abstract void setImage(String paramString);
  
  public abstract Element getParent();
  
  public abstract Point getLocation();
  
  public abstract double getX();
  
  public abstract double getY();
  
  public abstract void setLocation(double paramDouble1, double paramDouble2);
  
  public abstract void setLocation(Point2D.Double paramDouble);
  
  public abstract void setLocation(Point paramPoint);
  
  public abstract int getWidth();
  
  public abstract int getHeight();
  
  public abstract Rectangle getBounds();
  
  public abstract AlarmState getAlarmState();
  
  public abstract boolean isSelected();
  
  public abstract boolean isVisible();
  
  public abstract boolean isDescendantOf(Element paramElement);
  
  public abstract Object getClientProperty(Object paramObject);
  
  public abstract Map getClientProperties();
  
  public abstract void setName(String paramString);
  
  public abstract void setDisplayName(String paramString);
  
  public abstract void setUserObject(Object paramObject);
  
  public abstract void setParent(Element paramElement);
  
  public abstract void setVisible(boolean paramBoolean);
  
  public abstract void setToolTipText(String paramString);
  
  public abstract void setSelected(boolean paramBoolean);
  
  public abstract void setAlarmState(AlarmState paramAlarmState);
  
  public abstract void removeFromParent();
  
  public abstract PropertyChangeSupport getPropertyChangeSupport();
  
  public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void addPropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void firePropertyChange(PropertyChangeEvent paramPropertyChangeEvent);
  
  public abstract void firePropertyChange(String paramString, Object paramObject1, Object paramObject2);
  
  public abstract void firePropertyChange(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract void firePropertyChange(String paramString, int paramInt1, int paramInt2);
  
  public abstract void putClientProperty(Object paramObject1, Object paramObject2);
  
  public abstract void putClientProperty(Object paramObject, int paramInt);
  
  public abstract void putClientProperty(Object paramObject, boolean paramBoolean);
  
  public abstract String getToolTipText();
  
  public abstract void addChild(Element paramElement);
  
  public abstract void addChild(int paramInt, Element paramElement);
  
  public abstract void removeChild(Element paramElement);
  
  public abstract Iterator children();
  
  public abstract List getChildren();
  
  public abstract int childrenSize();
  
  public abstract boolean isEmpty();
  
  public abstract void clearChildren();
  
  public abstract boolean isParentOf(Element paramElement);
  
  public abstract Element getChildrenByID(Object paramObject);
  
  public abstract Point getCenterLocation();
  
  public abstract void setCenterLocation(double paramDouble1, double paramDouble2);
  
  public abstract void setCenterLocation(Point2D paramPoint2D);
  
  public abstract void addAttachment(String paramString);
  
  public abstract void removeAttachment(String paramString);
  
  public abstract Element copy();
  
  public abstract Element copy(Object paramObject);
  
  public abstract Element copy(TDataBox paramTDataBox);
  
  public abstract Element copy(Object paramObject, TDataBox paramTDataBox);
  
  public abstract void updateUI();
  
  public abstract boolean isEnableAlarmPropagationFromChildren();
  
  public abstract void setEnableAlarmPropagationFromChildren(boolean paramBoolean);
  
  public abstract Object getLayerID();
  
  public abstract void setLayerID(Object paramObject);
  
  public abstract boolean isAdjustToBottom();
  
  public abstract void setPropertyValue(TPropertyDescriptor paramTPropertyDescriptor, Object paramObject);
  
  public abstract Object getPropertyValue(TPropertyDescriptor paramTPropertyDescriptor);
  
  public abstract Object getBusinessObject();
  
  public abstract void setBusinessObject(Object paramObject);
  
  public abstract Object getUserProperty(Object paramObject);
  
  public abstract Map getUserProperties();
  
  public abstract void putUserProperty(Object paramObject1, Object paramObject2);
  
  public abstract void putUserProperty(Object paramObject, int paramInt);
  
  public abstract void putUserProperty(Object paramObject, boolean paramBoolean);
  
  public abstract boolean containsAttachment(String paramString);
  
  public abstract void putLabelIcon(String paramString);
  
  public abstract void putLabelFont(Font paramFont);
  
  public abstract void putLabelColor(Color paramColor);
  
  public abstract void putLabelBackground(Color paramColor);
  
  public abstract void putLabelVisible(boolean paramBoolean);
  
  public abstract void putLabelBorder(boolean paramBoolean);
  
  public abstract void putLabelUnderline(boolean paramBoolean);
  
  public abstract void putLabelPosition(int paramInt);
  
  public abstract void putLabelOrientation(int paramInt);
  
  public abstract void putLabelXOffset(int paramInt);
  
  public abstract void putLabelYOffset(int paramInt);
  
  public abstract void putLabelXGap(int paramInt);
  
  public abstract void putLabelYGap(int paramInt);
  
  public abstract void putLabelBorderStroke(String paramString);
  
  public abstract void putLabelBorderColor(Color paramColor);
  
  public abstract void putLabelUnderlineStroke(String paramString);
  
  public abstract void putLabelUnderlineColor(Color paramColor);
  
  public abstract void putLabelSelectable(boolean paramBoolean);
  
  public abstract void putLabelHighlightable(boolean paramBoolean);
  
  public abstract void putLabelHighlightBackground(Color paramColor);
  
  public abstract void putLabelHighlightForeground(Color paramColor);
  
  public abstract void putLabelMaxLength(int paramInt);
  
  public abstract void putDrawIconShape(boolean paramBoolean);
  
  public abstract void putRenderAlpha(float paramFloat);
  
  public abstract void putElementTreeIcon(Icon paramIcon);
  
  public abstract void putRenderColor(Color paramColor);
  
  public abstract void putStateOutlineColor(Color paramColor);
  
  public abstract void putStateOutlineWidth(int paramInt);
  
  public abstract void putAttachmentPosition(int paramInt);
  
  public abstract void putAttachmentOrientation(int paramInt);
  
  public abstract void putAttachmentXOffset(int paramInt);
  
  public abstract void putAttachmentYOffset(int paramInt);
  
  public abstract void putAttachmentXGap(int paramInt);
  
  public abstract void putAttachmentYGap(int paramInt);
  
  public abstract void putAlarmBalloonPosition(int paramInt);
  
  public abstract void putAlarmBalloonDirection(int paramInt);
  
  public abstract void putAlarmBalloonXoffset(int paramInt);
  
  public abstract void putAlarmBalloonYoffset(int paramInt);
  
  public abstract void putAlarmBalloonVisible(boolean paramBoolean);
  
  public abstract void putAlarmBalloonAlpha(float paramFloat);
  
  public abstract void putAlarmBalloonTextFont(Font paramFont);
  
  public abstract void putAlarmBalloonTextColor(Color paramColor);
  
  public abstract void putAlarmBalloonTextBlinkable(boolean paramBoolean);
  
  public abstract void putAlarmBalloonOutlineColor(Color paramColor);
  
  public abstract void putAlarmBalloonShadowColor(Color paramColor);
  
  public abstract void putAlarmBalloonShadowOffset(int paramInt);
  
  public abstract void putAlarmBalloonShownOnTop(boolean paramBoolean);
  
  public abstract void putTextureFactory(String paramString);
  
  public abstract void putBorderAntialias(boolean paramBoolean);
  
  public abstract void putBorderVisible(boolean paramBoolean);
  
  public abstract void putBorderFill(boolean paramBoolean);
  
  public abstract void putBorderUnderneath(boolean paramBoolean);
  
  public abstract void putBorderXormode(boolean paramBoolean);
  
  public abstract void putBorderStroke(String paramString);
  
  public abstract void putBorderColor(Color paramColor);
  
  public abstract void putBorderFillColor(Color paramColor);
  
  public abstract void putBorderInsets(int paramInt);
  
  public abstract void putBorderType(int paramInt);
  
  public abstract void putBorderShapeFactory(int paramInt);
  
  public abstract void putStateOutlineInsets(int paramInt);
  
  public abstract void putMessageContent(String paramString);
  
  public abstract void putMessageStyle(int paramInt);
  
  public abstract void putMessageComponent(int paramInt);
  
  public abstract void putMessageWidth(int paramInt);
  
  public abstract void putMessageHeight(int paramInt);
  
  public abstract void putMessageTail(int paramInt);
  
  public abstract void putMessageArc(int paramInt);
  
  public abstract void putMessageMinimized(boolean paramBoolean);
  
  public abstract void putMessageShrinked(boolean paramBoolean);
  
  public abstract void putMessageShrinkable(boolean paramBoolean);
  
  public abstract void putMessageClosable(boolean paramBoolean);
  
  public abstract void putMessageMinimizable(boolean paramBoolean);
  
  public abstract void putMessageAutoAdjustDirection(boolean paramBoolean);
  
  public abstract void putMessagePosition(int paramInt);
  
  public abstract void putMessageDirection(int paramInt);
  
  public abstract void putMessageFont(Font paramFont);
  
  public abstract void putMessageForeground(Color paramColor);
  
  public abstract void putMessageBackground(Color paramColor);
  
  public abstract void putMessageOpaque(boolean paramBoolean);
  
  public abstract void putMessageXOffset(int paramInt);
  
  public abstract void putMessageYOffset(int paramInt);
  
  public abstract void putMessageXGap(int paramInt);
  
  public abstract void putMessageYGap(int paramInt);
  
  public abstract void putMessageMinimizedIcon(String paramString);
  
  public abstract void putMessageShadowVisible(boolean paramBoolean);
  
  public abstract void putMessageShadowColor(Color paramColor);
  
  public abstract void putMessageBorderColor(Color paramColor);
  
  public abstract void putMessageBorderVisible(boolean paramBoolean);
  
  public abstract void putMessageBorderStroke(String paramString);
  
  public abstract void putMessageShownOnTop(boolean paramBoolean);
  
  public abstract void putChartColor(Color paramColor);
  
  public abstract void putChartValue(double paramDouble);
  
  public abstract void putChartMax(double paramDouble);
  
  public abstract void putChartMin(double paramDouble);
  
  public abstract void putChartInflexionStyle(int paramInt);
  
  public abstract void putChartPercentStyle(int paramInt);
  
  public abstract void putChartFormat(NumberFormat paramNumberFormat);
  
  public abstract void putChartValues(List paramList);
  
  public abstract void putChartStroke(String paramString);
  
  public abstract void putChartMarkers(List paramList);
  
  public abstract Icon getElementTreeIcon();
  
  public abstract boolean isDrawIconShape();
  
  public abstract float getRenderAlpha();
  
  public abstract Color getRenderColor();
  
  public abstract Color getStateOutlineColor();
  
  public abstract int getStateOutlineWidth();
  
  public abstract String getTextureFactory();
  
  public abstract boolean getBorderAntialias();
  
  public abstract boolean isBorderVisible();
  
  public abstract boolean isBorderFill();
  
  public abstract boolean isBorderUnderneath();
  
  public abstract boolean isBorderXormode();
  
  public abstract String getBorderStroke();
  
  public abstract Color getBorderColor();
  
  public abstract Color getBorderFillColor();
  
  public abstract int getBorderInsets();
  
  public abstract int getBorderType();
  
  public abstract int getBorderShapeFactory();
  
  public abstract int getStateOutlineInsets();
  
  public abstract String getLabelIcon();
  
  public abstract Font getLabelFont();
  
  public abstract Color getLabelColor();
  
  public abstract Color getLabelBackground();
  
  public abstract boolean isLabelVisible();
  
  public abstract boolean isLabelBorder();
  
  public abstract boolean isLabelUnderline();
  
  public abstract int getLabelPosition();
  
  public abstract int getLabelXOffset();
  
  public abstract int getLabelYOffset();
  
  public abstract int getLabelXGap();
  
  public abstract int getLabelYGap();
  
  public abstract int getLabelOrientation();
  
  public abstract String getLabelBorderStroke();
  
  public abstract String getLabelUnderlineStroke();
  
  public abstract boolean isLabelSelectable();
  
  public abstract Color getLabelBorderColor();
  
  public abstract Color getLabelUnderlineColor();
  
  public abstract boolean isLabelHighlightable();
  
  public abstract Color getLabelHighlightBackground();
  
  public abstract Color getLabelHighlightForeground();
  
  public abstract int getLabelMaxLength();
  
  public abstract int getAttachmentPosition();
  
  public abstract int getAttachmentOrientation();
  
  public abstract int getAttachmentXOffset();
  
  public abstract int getAttachmentYOffset();
  
  public abstract int getAttachmentXGap();
  
  public abstract int getAttachmentYGap();
  
  public abstract int getAlarmBalloonPosition();
  
  public abstract int getAlarmBalloonDirection();
  
  public abstract int getAlarmBalloonXOffset();
  
  public abstract int getAlarmBalloonYOffset();
  
  public abstract boolean isAlarmBalloonVisible();
  
  public abstract float getAlarmBalloonAlpha();
  
  public abstract Font getAlarmBalloonTextFont();
  
  public abstract Color getAlarmBalloonTextColor();
  
  public abstract boolean isAlarmBalloonTextBlinkable();
  
  public abstract Color getAlarmBalloonOutlineColor();
  
  public abstract Color getAlarmBalloonShadowColor();
  
  public abstract int getAlarmBalloonShadowOffset();
  
  public abstract boolean isAlarmBalloonShownOnTop();
  
  public abstract String getMessageContent();
  
  public abstract int getMessageWidth();
  
  public abstract int getMessageHeight();
  
  public abstract int getMessageComponent();
  
  public abstract int getMessageStyle();
  
  public abstract int getMessageTail();
  
  public abstract int getMessageArc();
  
  public abstract boolean isMessageMinimized();
  
  public abstract boolean isMessageShrinked();
  
  public abstract boolean isMessageShrinkable();
  
  public abstract boolean isMessageClosable();
  
  public abstract boolean isMessageAutoAdjustDirection();
  
  public abstract boolean isMessageMinimizable();
  
  public abstract int getMessagePosition();
  
  public abstract int getMessageDirection();
  
  public abstract Font getMessageFont();
  
  public abstract Color getMessageForeground();
  
  public abstract Color getMessageBackground();
  
  public abstract boolean isMessageOpaque();
  
  public abstract int getMessageXOffset();
  
  public abstract int getMessageYOffset();
  
  public abstract int getMessageXGap();
  
  public abstract int getMessageYGap();
  
  public abstract String getMessageMinimizedIcon();
  
  public abstract boolean isMessageShadowVisible();
  
  public abstract Color getMessageShadowColor();
  
  public abstract boolean isMessageBorderVisible();
  
  public abstract Color getMessageBorderColor();
  
  public abstract String getMessageBorderStroke();
  
  public abstract boolean isMessageShownOnTop();
  
  public abstract Color getChartColor();
  
  public abstract double getChartValue();
  
  public abstract double getChartMax();
  
  public abstract double getChartMin();
  
  public abstract NumberFormat getChartFormat();
  
  public abstract List getChartValues();
  
  public abstract void setChartValues(List paramList);
  
  public abstract String getChartStroke();
  
  public abstract int getChartPercentStyle();
  
  public abstract int getChartInflexionStyle();
  
  public abstract List getChartMarkers();
  
  public abstract void addChartValue(double paramDouble);
  
  public abstract void addChartValue(Double paramDouble);
  
  public abstract void clearChartValues();
  
  public abstract void putChartDialHandLength(double paramDouble);
  
  public abstract double getChartDialHandLength();
  
  public abstract void putChartDialHandStyle(int paramInt);
  
  public abstract int getChartDialHandStyle();
  
  public abstract void putChartPercentSpareFill(boolean paramBoolean);
  
  public abstract boolean getChartPercentSpareFill();
  
  public abstract void putChartPercentSpareColor(Color paramColor);
  
  public abstract Color getChartPercentSpareColor();
  
  public abstract void putChartPercentSpareCoverColor(Color paramColor);
  
  public abstract Color getChartPercentSpareCoverColor();
  
  public abstract void putChartPercentMarkerPostion(int paramInt);
  
  public abstract int getChartPercentMarkerPostion();
  
  public abstract void addChartBubble(Bubble paramBubble);
  
  public abstract void putChartBubbleStyle(int paramInt);
  
  public abstract int getChartBubbleStyle();
  
  public abstract void putChartBubbleShapeLineVisible(boolean paramBoolean);
  
  public abstract boolean getChartBubbleShapeLineVisible();
  
  public abstract void putChartBubbleShapeBubbleVisible(boolean paramBoolean);
  
  public abstract boolean getChartBubbleShapeBubbleVisible();
  
  public abstract void putChartValueTextPosition(int paramInt);
  
  public abstract int getChartValueTextPosition();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Element
 * JD-Core Version:    0.7.0.1
 */
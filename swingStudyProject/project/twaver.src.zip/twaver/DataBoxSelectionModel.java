package twaver;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract interface DataBoxSelectionModel
  extends Serializable
{
  public abstract TDataBox getDataBox();
  
  public abstract void addDataBoxSelectionListener(DataBoxSelectionListener paramDataBoxSelectionListener);
  
  public abstract List getDataBoxSelectionListeners();
  
  public abstract void removeDataBoxSelectionListener(DataBoxSelectionListener paramDataBoxSelectionListener);
  
  public abstract void appendSelection(Element paramElement);
  
  public abstract void appendSelection(Collection paramCollection);
  
  public abstract boolean contains(Element paramElement);
  
  public abstract Element lastElement();
  
  public abstract Element firstElement();
  
  public abstract void setSelection(Element paramElement);
  
  public abstract void setSelection(Collection paramCollection);
  
  public abstract void clearSelection();
  
  public abstract Iterator selection();
  
  public abstract int size();
  
  public abstract boolean isAdjusting();
  
  public abstract boolean isEmpty();
  
  public abstract void removeSelection(Element paramElement);
  
  public abstract void removeSelection(Collection paramCollection);
  
  public abstract List getToppestSelectedElement();
  
  public abstract List getAllSelectedElement();
  
  public abstract SelectionChangedInterceptor getSelectionChangedInterceptor();
  
  public abstract void setSelectionChangedInterceptor(SelectionChangedInterceptor paramSelectionChangedInterceptor);
  
  public abstract void selectAll();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSelectionModel
 * JD-Core Version:    0.7.0.1
 */
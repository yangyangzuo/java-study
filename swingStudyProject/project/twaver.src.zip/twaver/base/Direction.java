package twaver.base;

import twaver.base.enumerable.DefaultEnumerable;

public class Direction
  extends DefaultEnumerable
{
  private final int D;
  public static final Direction HORIZONTAL = new Direction(0, "HORIZONTAL");
  public static final Direction VERTICAL = new Direction(1, "VERTICAL");
  
  protected Direction(int direction, String name)
  {
    super(name);
    this.D = direction;
  }
  
  public int getDirection()
  {
    return this.D;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.Direction
 * JD-Core Version:    0.7.0.1
 */
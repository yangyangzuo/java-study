package twaver.base;

import twaver.base.enumerable.DefaultEnumerable;

public final class OrthogonalLinkDirectionType
  extends DefaultEnumerable
{
  public static final OrthogonalLinkDirectionType X_TO_Y = new OrthogonalLinkDirectionType("X_TO_Y");
  public static final OrthogonalLinkDirectionType Y_TO_X = new OrthogonalLinkDirectionType("Y_TO_X");
  
  protected OrthogonalLinkDirectionType(String name)
  {
    super(name);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.OrthogonalLinkDirectionType
 * JD-Core Version:    0.7.0.1
 */
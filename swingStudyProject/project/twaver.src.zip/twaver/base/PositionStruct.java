package twaver.base;

public class PositionStruct
{
  public String content;
  public int position;
  public int xOffset;
  public int yOffset;
  
  public PositionStruct(int position, int xOffset, int yOffset)
  {
    this.position = position;
    this.xOffset = xOffset;
    this.yOffset = yOffset;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.PositionStruct
 * JD-Core Version:    0.7.0.1
 */
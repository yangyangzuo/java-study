package twaver.base.A.A;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.MouseEvent;
import javax.swing.JRootPane;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import twaver.base.A.E.O;

public class H
  implements AWTEventListener
{
  private boolean B = false;
  private F C = new F();
  private static H A = new H();
  
  public static H B()
  {
    return A;
  }
  
  public boolean A()
  {
    return this.B;
  }
  
  public void A(boolean paramBoolean)
  {
    if (this.B != paramBoolean)
    {
      this.B = paramBoolean;
      if (this.B) {
        Toolkit.getDefaultToolkit().addAWTEventListener(this, 16L);
      } else {
        Toolkit.getDefaultToolkit().removeAWTEventListener(this);
      }
    }
  }
  
  public void eventDispatched(AWTEvent paramAWTEvent)
  {
    if (!MouseEvent.class.isInstance(paramAWTEvent)) {
      return;
    }
    MouseEvent localMouseEvent = (MouseEvent)paramAWTEvent;
    if ((localMouseEvent.getButton() != 2) || (localMouseEvent.getID() != 501)) {
      return;
    }
    Component localComponent = localMouseEvent.getComponent();
    localComponent = SwingUtilities.getDeepestComponentAt(localComponent, localMouseEvent.getX(), localMouseEvent.getY());
    JViewport localJViewport = (JViewport)SwingUtilities.getAncestorOfClass(JViewport.class, localComponent);
    if ((localJViewport == null) || (!O.A(localJViewport))) {
      return;
    }
    JRootPane localJRootPane = SwingUtilities.getRootPane(localJViewport);
    if (localJRootPane == null) {
      return;
    }
    Point localPoint = SwingUtilities.convertPoint(localMouseEvent.getComponent(), localMouseEvent.getPoint(), localJRootPane.getGlassPane());
    this.C.A(localJRootPane, localJViewport, localPoint);
    try
    {
      Robot localRobot = new Robot();
      localRobot.mouseRelease(8);
    }
    catch (Exception localException) {}
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.H
 * JD-Core Version:    0.7.0.1
 */
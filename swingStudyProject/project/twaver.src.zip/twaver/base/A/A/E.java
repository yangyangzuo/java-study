package twaver.base.A.A;

import java.awt.Color;
import java.awt.PaintContext;
import java.awt.geom.Point2D;
import java.awt.image.ColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;

public class E
  implements PaintContext
{
  protected Point2D C;
  protected Point2D D;
  protected Color B;
  protected Color A;
  
  public E(Point2D paramPoint2D1, Color paramColor1, Point2D paramPoint2D2, Color paramColor2)
  {
    this.C = paramPoint2D1;
    this.B = paramColor1;
    this.D = paramPoint2D2;
    this.A = paramColor2;
  }
  
  public void dispose() {}
  
  public ColorModel getColorModel()
  {
    return ColorModel.getRGBdefault();
  }
  
  public Raster getRaster(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    WritableRaster localWritableRaster = getColorModel().createCompatibleWritableRaster(paramInt3, paramInt4);
    int[] arrayOfInt = new int[paramInt3 * paramInt4 * 4];
    for (int i = 0; i < paramInt4; i++) {
      for (int j = 0; j < paramInt3; j++)
      {
        double d1 = this.C.distance(paramInt1 + j, paramInt2 + i);
        double d2 = this.D.distance(0.0D, 0.0D);
        double d3 = d1 / d2;
        if (d3 > 1.0D) {
          d3 = 1.0D;
        }
        int k = (i * paramInt3 + j) * 4;
        arrayOfInt[(k + 0)] = ((int)(this.B.getRed() + d3 * (this.A.getRed() - this.B.getRed())));
        arrayOfInt[(k + 1)] = ((int)(this.B.getGreen() + d3 * (this.A.getGreen() - this.B.getGreen())));
        arrayOfInt[(k + 2)] = ((int)(this.B.getBlue() + d3 * (this.A.getBlue() - this.B.getBlue())));
        arrayOfInt[(k + 3)] = ((int)(this.B.getAlpha() + d3 * (this.A.getAlpha() - this.B.getAlpha())));
      }
    }
    localWritableRaster.setPixels(0, 0, paramInt3, paramInt4, arrayOfInt);
    return localWritableRaster;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.E
 * JD-Core Version:    0.7.0.1
 */
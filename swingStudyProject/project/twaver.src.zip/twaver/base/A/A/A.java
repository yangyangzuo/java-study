package twaver.base.A.A;

import java.awt.Color;
import java.awt.Paint;
import java.awt.PaintContext;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;

public class A
  implements Paint
{
  protected Point2D A;
  protected Point2D D;
  protected Color C;
  protected Color B;
  
  public A(double paramDouble1, double paramDouble2, Color paramColor1, Point2D paramPoint2D, Color paramColor2)
  {
    if (paramPoint2D.distance(0.0D, 0.0D) <= 0.0D) {
      paramPoint2D = new Point2D.Double(0.01D, 0.01D);
    }
    this.A = new Point2D.Double(paramDouble1, paramDouble2);
    this.C = paramColor1;
    this.D = paramPoint2D;
    this.B = paramColor2;
  }
  
  public PaintContext createContext(ColorModel paramColorModel, Rectangle paramRectangle, Rectangle2D paramRectangle2D, AffineTransform paramAffineTransform, RenderingHints paramRenderingHints)
  {
    Point2D localPoint2D1 = paramAffineTransform.transform(this.A, null);
    Point2D localPoint2D2 = paramAffineTransform.deltaTransform(this.D, null);
    return new E(localPoint2D1, this.C, localPoint2D2, this.B);
  }
  
  public int getTransparency()
  {
    int i = this.C.getAlpha();
    int j = this.B.getAlpha();
    return (i & j) == 255 ? 1 : 3;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A
 * JD-Core Version:    0.7.0.1
 */
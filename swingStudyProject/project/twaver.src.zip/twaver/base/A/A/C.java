package twaver.base.A.A;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import javax.swing.border.LineBorder;
import twaver.TWaverConst;

public class C
  extends LineBorder
{
  private Color B = Color.BLACK;
  private boolean D = false;
  private boolean A = false;
  private Stroke E = TWaverConst.BASIC_STROKE;
  private Stroke C = TWaverConst.BASIC_STROKE;
  
  public C(int paramInt)
  {
    super(Color.gray, paramInt, false);
  }
  
  public void paintBorder(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.A)
    {
      ((Graphics2D)paramGraphics).setStroke(this.C);
      paramGraphics.setColor(this.B);
      paramGraphics.drawLine(paramInt1 + 5, paramInt2 + paramInt4 - 3, paramInt1 + paramInt3 - 6, paramInt2 + paramInt4 - 3);
    }
    if (this.D)
    {
      ((Graphics2D)paramGraphics).setStroke(this.E);
      super.paintBorder(paramComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }
  
  public void A(Color paramColor)
  {
    this.lineColor = paramColor;
  }
  
  public boolean D()
  {
    return this.D;
  }
  
  public void B(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public Stroke C()
  {
    return this.E;
  }
  
  public void A(Stroke paramStroke)
  {
    this.E = paramStroke;
  }
  
  public boolean E()
  {
    return this.A;
  }
  
  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public Stroke B()
  {
    return this.C;
  }
  
  public void B(Stroke paramStroke)
  {
    this.C = paramStroke;
  }
  
  public Color A()
  {
    return this.B;
  }
  
  public void B(Color paramColor)
  {
    this.B = paramColor;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.C
 * JD-Core Version:    0.7.0.1
 */
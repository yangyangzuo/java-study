package twaver.base.A.A;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.io.Serializable;
import javax.swing.border.Border;

public class G
  implements Border, Serializable
{
  public static final G A = new G();
  
  public void paintBorder(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramGraphics.setColor(Color.gray);
    paramGraphics.drawLine(paramInt1, paramInt2 + paramInt4 - 3, paramInt1 + paramInt3, paramInt2 + paramInt4 - 3);
  }
  
  public Insets getBorderInsets(Component paramComponent)
  {
    return new Insets(1, 3, 5, 3);
  }
  
  public boolean isBorderOpaque()
  {
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.G
 * JD-Core Version:    0.7.0.1
 */
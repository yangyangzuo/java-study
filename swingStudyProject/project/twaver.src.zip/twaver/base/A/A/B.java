package twaver.base.A.A;

import java.awt.Color;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import twaver.EnumType;
import twaver.TWaverUtil;

public class B
  extends BasicComboBoxRenderer
  implements ListCellRenderer
{
  public B(String paramString)
  {
    if (paramString != null) {
      TWaverUtil.setHorizontalAlignment(this, paramString);
    }
  }
  
  public Component getListCellRendererComponent(JList paramJList, Object paramObject, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    String str = null;
    Icon localIcon = null;
    Color localColor1 = null;
    Color localColor2 = null;
    if ((paramObject instanceof EnumType))
    {
      EnumType localEnumType = (EnumType)paramObject;
      str = localEnumType.toString();
      localIcon = localEnumType.getIcon();
      localColor1 = localEnumType.getBackground();
      localColor2 = localEnumType.getForeground();
      if ((localColor1 != null) && (paramBoolean1)) {
        localColor1 = localColor1.darker();
      }
    }
    super.getListCellRendererComponent(paramJList, str, paramInt, paramBoolean1, paramBoolean2);
    setIcon(localIcon);
    setToolTipText(str);
    if (localColor2 != null) {
      setForeground(localColor2);
    }
    if (localColor1 != null) {
      setBackground(localColor1);
    }
    return this;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.B
 * JD-Core Version:    0.7.0.1
 */
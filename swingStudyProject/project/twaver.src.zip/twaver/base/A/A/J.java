package twaver.base.A.A;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.IllegalPathStateException;
import java.awt.geom.PathIterator;

public class J
  implements PathIterator
{
  private final int A;
  private final double[] C;
  private final int[] E;
  private int D = 0;
  private int B = 0;
  
  public static PathIterator A(Shape paramShape)
  {
    return new J(paramShape.getPathIterator(null));
  }
  
  public static PathIterator A(Shape paramShape, double paramDouble)
  {
    return new J(paramShape.getPathIterator(null, paramDouble));
  }
  
  public static PathIterator A(Shape paramShape, AffineTransform paramAffineTransform)
  {
    return new J(paramShape.getPathIterator(paramAffineTransform));
  }
  
  public static PathIterator A(Shape paramShape, AffineTransform paramAffineTransform, double paramDouble)
  {
    return new J(paramShape.getPathIterator(paramAffineTransform, paramDouble));
  }
  
  public static PathIterator A(Shape paramShape, int paramInt)
  {
    return new J(paramShape.getPathIterator(null), paramInt);
  }
  
  public static PathIterator A(Shape paramShape, double paramDouble, int paramInt)
  {
    return new J(paramShape.getPathIterator(null, paramDouble), paramInt);
  }
  
  public static PathIterator A(Shape paramShape, AffineTransform paramAffineTransform, int paramInt)
  {
    return new J(paramShape.getPathIterator(paramAffineTransform), paramInt);
  }
  
  public static PathIterator A(Shape paramShape, AffineTransform paramAffineTransform, double paramDouble, int paramInt)
  {
    return new J(paramShape.getPathIterator(paramAffineTransform, paramDouble), paramInt);
  }
  
  public J(PathIterator paramPathIterator)
  {
    this(paramPathIterator, paramPathIterator.getWindingRule());
  }
  
  public J(PathIterator paramPathIterator, int paramInt)
  {
    this.A = paramInt;
    Object localObject1 = new double[16];
    int i = 0;
    Object localObject2 = new int[8];
    int j = 0;
    int k = 1;
    double[] arrayOfDouble1 = new double[6];
    int n;
    int i1;
    while (!paramPathIterator.isDone())
    {
      if (j == localObject2.length)
      {
        int[] arrayOfInt = new int[2 * j];
        System.arraycopy(localObject2, 0, arrayOfInt, 0, j);
        localObject2 = arrayOfInt;
      }
      m = localObject2[(j++)] = paramPathIterator.currentSegment(arrayOfDouble1);
      if (k != 0)
      {
        if (m != 0) {
          throw new IllegalPathStateException("missing initial moveto in path definition");
        }
        k = 0;
      }
      switch (m)
      {
      case 0: 
      case 1: 
        n = 2;
        break;
      case 2: 
        n = 4;
        break;
      case 3: 
        n = 6;
        break;
      default: 
        n = 0;
      }
      if (n > 0)
      {
        if (i + n > localObject1.length)
        {
          double[] arrayOfDouble2 = new double[localObject1.length * 2];
          System.arraycopy(localObject1, 0, arrayOfDouble2, 0, localObject1.length);
          localObject1 = arrayOfDouble2;
        }
        for (i1 = 0; i1 < n; i1++) {
          localObject1[(i++)] = arrayOfDouble1[i1];
        }
      }
      paramPathIterator.next();
    }
    this.C = new double[i];
    for (int m = i / 2 - 1; m >= 0; m--)
    {
      this.C[(2 * m)] = localObject1[(i - 2 * m - 2)];
      this.C[(2 * m + 1)] = localObject1[(i - 2 * m - 1)];
    }
    this.E = new int[j];
    if (j > 0)
    {
      m = 0;
      n = 0;
      this.E[(n++)] = 0;
      for (i1 = j - 1; i1 > 0; i1--) {
        switch (localObject2[i1])
        {
        case 0: 
          if (m != 0)
          {
            m = 0;
            this.E[(n++)] = 4;
          }
          this.E[(n++)] = 0;
          break;
        case 4: 
          m = 1;
          break;
        case 1: 
        case 2: 
        case 3: 
        default: 
          this.E[(n++)] = localObject2[i1];
        }
      }
      if (m != 0) {
        this.E[n] = 4;
      }
    }
  }
  
  public int getWindingRule()
  {
    return this.A;
  }
  
  private static final int A(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
    case 1: 
      return 2;
    case 2: 
      return 4;
    case 3: 
      return 6;
    }
    return 0;
  }
  
  public void next()
  {
    this.D += A(this.E[(this.B++)]);
  }
  
  public boolean isDone()
  {
    return this.B >= this.E.length;
  }
  
  public int currentSegment(double[] paramArrayOfDouble)
  {
    int i = this.E[this.B];
    int j = A(i);
    if (j > 0) {
      System.arraycopy(this.C, this.D, paramArrayOfDouble, 0, j);
    }
    return i;
  }
  
  public int currentSegment(float[] paramArrayOfFloat)
  {
    int i = this.E[this.B];
    int j = A(i);
    if (j > 0) {
      for (int k = 0; k < j; k++) {
        paramArrayOfFloat[k] = ((float)this.C[(this.D + k)]);
      }
    }
    return i;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.J
 * JD-Core Version:    0.7.0.1
 */
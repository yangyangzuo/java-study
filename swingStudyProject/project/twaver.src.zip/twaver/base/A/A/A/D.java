package twaver.base.A.A.A;

import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import twaver.TWaverUtil;

public abstract class D
{
  private static List A = null;
  
  public static List getSupportableFormatNames()
  {
    if (A == null)
    {
      A = new ArrayList();
      String[] arrayOfString1 = ImageIO.getWriterFormatNames();
      String[] arrayOfString2 = { "jpg", "bmp", "png", "tif", "jpeg" };
      for (int i = 0; i < arrayOfString2.length; i++)
      {
        String str = arrayOfString2[i].toLowerCase();
        if ((twaver.base.A.E.D.A(arrayOfString1, str) >= 0) && (!A.contains(str))) {
          A.add(str);
        }
      }
    }
    return A;
  }
  
  private static String A(String paramString1, String paramString2)
  {
    int i = paramString1.lastIndexOf(".");
    if ((i >= 0) && (!paramString1.endsWith(".")))
    {
      String str = paramString1.substring(i + 1).toLowerCase();
      if (getSupportableFormatNames().contains(str)) {
        return paramString1;
      }
    }
    return paramString1 + "." + paramString2;
  }
  
  public static String ensureFormatName(String paramString)
  {
    if (getSupportableFormatNames().contains(paramString)) {
      return paramString;
    }
    return "png";
  }
  
  public static int getImageType(String paramString)
  {
    if ("png".equalsIgnoreCase(paramString)) {
      return 2;
    }
    return 1;
  }
  
  protected abstract void paint(Graphics2D paramGraphics2D, int paramInt1, int paramInt2);
  
  public boolean exportToFile(String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3)
  {
    paramString2 = ensureFormatName(paramString2);
    paramString1 = A(paramString1, paramString2);
    ImageOutputStream localImageOutputStream = null;
    try
    {
      File localFile = new File(paramString1);
      localImageOutputStream = ImageIO.createImageOutputStream(localFile);
      if (paramString3 == null) {
        paramString3 = paramString1 + ".tmp";
      }
      exportToTarget(localImageOutputStream, paramString2, paramInt1, paramInt2, paramString3);
      return true;
    }
    catch (Throwable localThrowable)
    {
      TWaverUtil.handleError(null, localThrowable);
      return false;
    }
    finally
    {
      if (localImageOutputStream != null) {
        try
        {
          localImageOutputStream.close();
        }
        catch (IOException localIOException) {}
      }
    }
  }
  
  public boolean exportToImageIcon(String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3)
  {
    try
    {
      exportToTarget(paramString1, paramString2, paramInt1, paramInt2, paramString3);
    }
    catch (Throwable localThrowable)
    {
      TWaverUtil.handleError(null, localThrowable);
      return false;
    }
    return true;
  }
  
  /* Error */
  public void exportToTarget(Object paramObject, String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws java.lang.Exception
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 6
    //   3: aconst_null
    //   4: astore 7
    //   6: aconst_null
    //   7: astore 8
    //   9: aconst_null
    //   10: astore 9
    //   12: new 161	java/awt/image/BufferedImage
    //   15: dup
    //   16: iload_3
    //   17: iload 4
    //   19: aload_2
    //   20: invokestatic 163	twaver/base/A/A/A/D:getImageType	(Ljava/lang/String;)I
    //   23: invokespecial 165	java/awt/image/BufferedImage:<init>	(III)V
    //   26: astore 9
    //   28: goto +5 -> 33
    //   31: astore 10
    //   33: aload 9
    //   35: ifnonnull +194 -> 229
    //   38: aload 5
    //   40: ifnonnull +29 -> 69
    //   43: new 86	java/lang/StringBuffer
    //   46: dup
    //   47: ldc 168
    //   49: invokestatic 170	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   52: invokestatic 88	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   55: invokespecial 92	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   58: invokestatic 175	java/lang/System:currentTimeMillis	()J
    //   61: invokevirtual 179	java/lang/StringBuffer:append	(J)Ljava/lang/StringBuffer;
    //   64: invokevirtual 99	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   67: astore 5
    //   69: new 119	java/io/File
    //   72: dup
    //   73: aload 5
    //   75: invokespecial 121	java/io/File:<init>	(Ljava/lang/String;)V
    //   78: astore 6
    //   80: new 182	java/io/RandomAccessFile
    //   83: dup
    //   84: aload 6
    //   86: ldc 184
    //   88: invokespecial 186	java/io/RandomAccessFile:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   91: astore 7
    //   93: aload 7
    //   95: invokevirtual 189	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   98: astore 8
    //   100: aload 8
    //   102: getstatic 193	java/nio/channels/FileChannel$MapMode:READ_WRITE	Ljava/nio/channels/FileChannel$MapMode;
    //   105: lconst_0
    //   106: bipush 6
    //   108: iload_3
    //   109: imul
    //   110: iload 4
    //   112: imul
    //   113: i2l
    //   114: invokevirtual 199	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   117: astore 10
    //   119: aload 10
    //   121: invokevirtual 205	java/nio/ByteBuffer:asIntBuffer	()Ljava/nio/IntBuffer;
    //   124: astore 11
    //   126: new 211	twaver/base/A/A/A/B
    //   129: dup
    //   130: iconst_3
    //   131: iconst_3
    //   132: iload 4
    //   134: imul
    //   135: iload_3
    //   136: imul
    //   137: invokespecial 213	twaver/base/A/A/A/B:<init>	(II)V
    //   140: astore 12
    //   142: aload 12
    //   144: aload 11
    //   146: invokevirtual 216	twaver/base/A/A/A/B:A	(Ljava/nio/IntBuffer;)V
    //   149: new 220	java/awt/image/DirectColorModel
    //   152: dup
    //   153: bipush 32
    //   155: ldc 222
    //   157: ldc 223
    //   159: sipush 255
    //   162: ldc 224
    //   164: invokespecial 225	java/awt/image/DirectColorModel:<init>	(IIIII)V
    //   167: astore 13
    //   169: aload 13
    //   171: iload_3
    //   172: iload 4
    //   174: invokevirtual 228	java/awt/image/ColorModel:createCompatibleSampleModel	(II)Ljava/awt/image/SampleModel;
    //   177: astore 14
    //   179: new 234	twaver/base/A/A/A/A
    //   182: dup
    //   183: aload 14
    //   185: aload 12
    //   187: new 236	java/awt/Point
    //   190: dup
    //   191: iconst_0
    //   192: iconst_0
    //   193: invokespecial 238	java/awt/Point:<init>	(II)V
    //   196: invokespecial 239	twaver/base/A/A/A/A:<init>	(Ljava/awt/image/SampleModel;Ljava/awt/image/DataBuffer;Ljava/awt/Point;)V
    //   199: astore 15
    //   201: new 161	java/awt/image/BufferedImage
    //   204: dup
    //   205: aload 13
    //   207: aload 15
    //   209: iconst_1
    //   210: aconst_null
    //   211: invokespecial 242	java/awt/image/BufferedImage:<init>	(Ljava/awt/image/ColorModel;Ljava/awt/image/WritableRaster;ZLjava/util/Hashtable;)V
    //   214: astore 9
    //   216: goto +13 -> 229
    //   219: astore 10
    //   221: new 245	java/lang/OutOfMemoryError
    //   224: dup
    //   225: invokespecial 247	java/lang/OutOfMemoryError:<init>	()V
    //   228: athrow
    //   229: aload 9
    //   231: invokevirtual 248	java/awt/image/BufferedImage:createGraphics	()Ljava/awt/Graphics2D;
    //   234: astore 10
    //   236: aload_0
    //   237: aload 10
    //   239: iload_3
    //   240: iload 4
    //   242: invokevirtual 252	twaver/base/A/A/A/D:paint	(Ljava/awt/Graphics2D;II)V
    //   245: aload 10
    //   247: invokevirtual 254	java/awt/Graphics2D:dispose	()V
    //   250: aload_1
    //   251: instanceof 259
    //   254: ifeq +14 -> 268
    //   257: aload 9
    //   259: aload_2
    //   260: aload_1
    //   261: checkcast 259	java/io/OutputStream
    //   264: invokestatic 261	javax/imageio/ImageIO:write	(Ljava/awt/image/RenderedImage;Ljava/lang/String;Ljava/io/OutputStream;)Z
    //   267: pop
    //   268: aload_1
    //   269: instanceof 139
    //   272: ifeq +14 -> 286
    //   275: aload 9
    //   277: aload_2
    //   278: aload_1
    //   279: checkcast 139	javax/imageio/stream/ImageOutputStream
    //   282: invokestatic 265	javax/imageio/ImageIO:write	(Ljava/awt/image/RenderedImage;Ljava/lang/String;Ljavax/imageio/stream/ImageOutputStream;)Z
    //   285: pop
    //   286: aload_1
    //   287: instanceof 30
    //   290: ifeq +75 -> 365
    //   293: aload_1
    //   294: checkcast 30	java/lang/String
    //   297: new 268	javax/swing/ImageIcon
    //   300: dup
    //   301: aload 9
    //   303: invokespecial 270	javax/swing/ImageIcon:<init>	(Ljava/awt/Image;)V
    //   306: invokestatic 273	twaver/TWaverUtil:registerImageIcon	(Ljava/lang/String;Ljavax/swing/ImageIcon;)V
    //   309: goto +56 -> 365
    //   312: astore 9
    //   314: aload 9
    //   316: athrow
    //   317: astore 17
    //   319: jsr +6 -> 325
    //   322: aload 17
    //   324: athrow
    //   325: astore 16
    //   327: aload 8
    //   329: ifnull +13 -> 342
    //   332: aload 8
    //   334: invokevirtual 277	java/nio/channels/FileChannel:close	()V
    //   337: goto +5 -> 342
    //   340: astore 18
    //   342: aload 7
    //   344: ifnull +8 -> 352
    //   347: aload 7
    //   349: invokevirtual 278	java/io/RandomAccessFile:close	()V
    //   352: aload 6
    //   354: ifnull +9 -> 363
    //   357: aload 6
    //   359: invokevirtual 279	java/io/File:delete	()Z
    //   362: pop
    //   363: ret 16
    //   365: jsr -40 -> 325
    //   368: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	369	0	this	D
    //   0	369	1	paramObject	Object
    //   0	369	2	paramString1	String
    //   0	369	3	paramInt1	int
    //   0	369	4	paramInt2	int
    //   0	369	5	paramString2	String
    //   1	357	6	localFile	File
    //   4	344	7	localRandomAccessFile	java.io.RandomAccessFile
    //   7	326	8	localFileChannel	java.nio.channels.FileChannel
    //   10	292	9	localBufferedImage	java.awt.image.BufferedImage
    //   312	3	9	localException	java.lang.Exception
    //   31	1	10	localOutOfMemoryError1	java.lang.OutOfMemoryError
    //   117	3	10	localMappedByteBuffer	java.nio.MappedByteBuffer
    //   219	1	10	localOutOfMemoryError2	java.lang.OutOfMemoryError
    //   234	12	10	localGraphics2D	Graphics2D
    //   124	21	11	localIntBuffer	java.nio.IntBuffer
    //   140	46	12	localB	B
    //   167	39	13	localDirectColorModel	java.awt.image.DirectColorModel
    //   177	7	14	localSampleModel	java.awt.image.SampleModel
    //   199	9	15	localA	A
    //   325	1	16	localObject1	Object
    //   317	6	17	localObject2	Object
    //   340	1	18	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   12	28	31	java/lang/OutOfMemoryError
    //   80	216	219	java/lang/OutOfMemoryError
    //   9	309	312	java/lang/Exception
    //   9	317	317	finally
    //   365	368	317	finally
    //   332	337	340	java/io/IOException
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.D
 * JD-Core Version:    0.7.0.1
 */
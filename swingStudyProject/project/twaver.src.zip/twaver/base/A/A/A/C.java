package twaver.base.A.A.A;

import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.OutputStream;
import twaver.TWaverUtil;

public class C
  extends D
{
  protected Component I;
  protected double K;
  protected Rectangle H;
  protected String G;
  protected String J;
  
  public C(Component paramComponent, double paramDouble, Rectangle paramRectangle, String paramString1, String paramString2)
  {
    this.I = paramComponent;
    this.K = paramDouble;
    this.H = paramRectangle;
    this.G = paramString2;
    this.J = paramString1;
  }
  
  public boolean B(String paramString)
  {
    int i = (int)(this.H.getWidth() * this.K);
    int j = (int)(this.H.getHeight() * this.K);
    return exportToFile(paramString, this.J, i, j, this.G);
  }
  
  public boolean A(String paramString)
  {
    int i = (int)(this.H.getWidth() * this.K);
    int j = (int)(this.H.getHeight() * this.K);
    return exportToImageIcon(paramString, this.J, i, j, this.G);
  }
  
  public boolean A(OutputStream paramOutputStream)
  {
    int i = (int)(this.H.getWidth() * this.K);
    int j = (int)(this.H.getHeight() * this.K);
    try
    {
      exportToTarget(paramOutputStream, this.J, i, j, this.G);
      return true;
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
    return false;
  }
  
  protected void paint(Graphics2D paramGraphics2D, int paramInt1, int paramInt2)
  {
    Rectangle tmp4_1 = this.H;
    tmp4_1.x = ((int)(tmp4_1.x * this.K));
    Rectangle tmp22_19 = this.H;
    tmp22_19.y = ((int)(tmp22_19.y * this.K));
    Rectangle tmp40_37 = this.H;
    tmp40_37.width = ((int)(tmp40_37.width * this.K));
    Rectangle tmp58_55 = this.H;
    tmp58_55.height = ((int)(tmp58_55.height * this.K));
    paramGraphics2D.translate(-this.H.getX(), -this.H.getY());
    paramGraphics2D.setClip(this.H);
    if (!"png".equalsIgnoreCase(this.J))
    {
      paramGraphics2D.setColor(this.I.getBackground());
      paramGraphics2D.fill(this.H);
    }
    A(paramGraphics2D);
  }
  
  protected void A(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.scale(this.K, this.K);
    this.I.print(paramGraphics2D);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.C
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.A.A;

import java.awt.Graphics2D;
import java.awt.Image;

public class F
  extends D
{
  private Image B;
  
  public F(Image paramImage)
  {
    this.B = paramImage;
  }
  
  public boolean A(String paramString1, String paramString2, String paramString3)
  {
    return exportToFile(paramString1, paramString2, this.B.getWidth(null), this.B.getHeight(null), paramString3);
  }
  
  protected void paint(Graphics2D paramGraphics2D, int paramInt1, int paramInt2)
  {
    paramGraphics2D.drawImage(this.B, 0, 0, paramInt1, paramInt2, null);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.F
 * JD-Core Version:    0.7.0.1
 */
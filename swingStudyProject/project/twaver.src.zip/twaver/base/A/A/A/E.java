package twaver.base.A.A.A;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import twaver.network.TNetwork;

public class E
  extends C
{
  private TNetwork L = null;
  
  public E(TNetwork paramTNetwork, double paramDouble, Rectangle paramRectangle, String paramString1, String paramString2)
  {
    super(paramTNetwork.getCanvas(), paramDouble, paramRectangle, paramString1, paramString2);
    this.L = paramTNetwork;
  }
  
  protected void A(Graphics2D paramGraphics2D)
  {
    this.L.setPaintState(2);
    this.L.paintNetworkContent(paramGraphics2D, this.K, this.K, false);
    this.L.setPaintState(0);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.E
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.A.A;

import java.awt.image.DataBuffer;
import java.nio.IntBuffer;

public class B
  extends DataBuffer
{
  private IntBuffer A;
  
  public B(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }
  
  public void A(IntBuffer paramIntBuffer)
  {
    this.A = paramIntBuffer;
  }
  
  public int getElem(int paramInt1, int paramInt2)
  {
    return this.A.get(paramInt2);
  }
  
  public void setElem(int paramInt1, int paramInt2, int paramInt3)
  {
    this.A.put(paramInt2, paramInt3);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.B
 * JD-Core Version:    0.7.0.1
 */
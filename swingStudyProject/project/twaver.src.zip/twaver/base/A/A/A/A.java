package twaver.base.A.A.A;

import java.awt.Point;
import java.awt.image.DataBuffer;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;

public class A
  extends WritableRaster
{
  public A(SampleModel paramSampleModel, DataBuffer paramDataBuffer, Point paramPoint)
  {
    super(paramSampleModel, paramDataBuffer, paramPoint);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.A.A
 * JD-Core Version:    0.7.0.1
 */
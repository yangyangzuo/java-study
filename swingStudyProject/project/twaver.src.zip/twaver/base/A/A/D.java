package twaver.base.A.A;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.awt.dnd.Autoscroll;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

public class D
  implements Autoscroll
{
  private Component C;
  private Insets B;
  private Insets A;
  
  public D(Component paramComponent, Insets paramInsets)
  {
    this(paramComponent, paramInsets, paramInsets);
  }
  
  public D(Component paramComponent, Insets paramInsets1, Insets paramInsets2)
  {
    this.C = paramComponent;
    this.B = paramInsets1;
    this.A = paramInsets2;
  }
  
  public void autoscroll(Point paramPoint)
  {
    JViewport localJViewport = A();
    if (localJViewport == null) {
      return;
    }
    Point localPoint = localJViewport.getViewPosition();
    int i = localJViewport.getExtentSize().height;
    int j = localJViewport.getExtentSize().width;
    if (paramPoint.y - localPoint.y < this.B.top) {
      localJViewport.setViewPosition(new Point(localPoint.x, Math.max(localPoint.y - this.A.top, 0)));
    } else if (localPoint.y + i - paramPoint.y < this.B.bottom) {
      localJViewport.setViewPosition(new Point(localPoint.x, Math.min(localPoint.y + this.A.bottom, this.C.getHeight() - i)));
    } else if (paramPoint.x - localPoint.x < this.B.left) {
      localJViewport.setViewPosition(new Point(Math.max(localPoint.x - this.A.left, 0), localPoint.y));
    } else if (localPoint.x + j - paramPoint.x < this.B.right) {
      localJViewport.setViewPosition(new Point(Math.min(localPoint.x + this.A.right, this.C.getWidth() - j), localPoint.y));
    }
  }
  
  public Insets getAutoscrollInsets()
  {
    int i = this.C.getHeight();
    int j = this.C.getWidth();
    return new Insets(i, j, i, j);
  }
  
  JViewport A()
  {
    return (JViewport)SwingUtilities.getAncestorOfClass(JViewport.class, this.C);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.D
 * JD-Core Version:    0.7.0.1
 */
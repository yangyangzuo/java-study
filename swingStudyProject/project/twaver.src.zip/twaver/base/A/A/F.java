package twaver.base.A.A;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JViewport;
import javax.swing.Timer;
import javax.swing.event.MouseInputListener;
import twaver.TWaverUtil;
import twaver.base.A.E.O;

public class F
  extends JPanel
  implements ActionListener, MouseInputListener
{
  private JRootPane C;
  private Component H;
  private JViewport K;
  private Point I;
  private Point F;
  private Timer B = new Timer(100, this);
  private Image G = TWaverUtil.getImage("/resource/image/swing/scroll.png");
  private Image E = TWaverUtil.getImage("/resource/image/swing/vscroll.png");
  private Image A = TWaverUtil.getImage("/resource/image/swing/hscroll.png");
  private Image D = null;
  private Rectangle J = null;
  
  protected F()
  {
    this.B.setRepeats(true);
    setVisible(false);
    setOpaque(false);
  }
  
  protected void A(JRootPane paramJRootPane, JViewport paramJViewport, Point paramPoint)
  {
    if (this.B.isRunning()) {
      return;
    }
    this.C = paramJRootPane;
    this.H = paramJRootPane.getGlassPane();
    this.K = paramJViewport;
    this.I = (this.F = paramPoint);
    boolean bool1 = O.B(paramJViewport);
    boolean bool2 = O.C(paramJViewport);
    this.D = null;
    if ((bool1) && (bool2)) {
      this.D = this.G;
    } else if (bool1) {
      this.D = this.A;
    } else if (bool2) {
      this.D = this.E;
    }
    if (this.D == null) {
      return;
    }
    int i = this.D.getWidth(this);
    int j = this.D.getHeight(this);
    this.J = new Rectangle(paramPoint.x - i / 2, paramPoint.y - j / 2, i, j);
    H.B().A(false);
    this.C.setGlassPane(this);
    setVisible(true);
    addMouseListener(this);
    addMouseMotionListener(this);
    this.B.start();
  }
  
  protected void A()
  {
    if (!this.B.isRunning()) {
      return;
    }
    this.B.stop();
    removeMouseListener(this);
    removeMouseMotionListener(this);
    setVisible(false);
    this.C.setGlassPane(this.H);
    this.D = null;
    H.B().A(true);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    int i = (this.F.x - this.I.x) / 4;
    int j = (this.F.y - this.I.y) / 4;
    Point localPoint = this.K.getViewPosition();
    localPoint.translate(i, j);
    if (localPoint.x > this.K.getView().getWidth() - this.K.getWidth()) {
      localPoint.x = (this.K.getView().getWidth() - this.K.getWidth());
    }
    if (localPoint.x < 0) {
      localPoint.x = 0;
    }
    if (localPoint.y > this.K.getView().getHeight() - this.K.getHeight()) {
      localPoint.y = (this.K.getView().getHeight() - this.K.getHeight());
    }
    if (localPoint.y < 0) {
      localPoint.y = 0;
    }
    this.K.setViewPosition(localPoint);
    if (this.J.contains(this.F)) {
      setCursor(Cursor.getPredefinedCursor(13));
    } else {
      setCursor(null);
    }
  }
  
  protected void paintComponent(Graphics paramGraphics)
  {
    if (this.D != null) {
      paramGraphics.drawImage(this.D, this.I.x - 15, this.I.y - 15, this);
    }
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    this.F = paramMouseEvent.getPoint();
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent)
  {
    this.F = paramMouseEvent.getPoint();
  }
  
  public void mouseExited(MouseEvent paramMouseEvent)
  {
    this.F = paramMouseEvent.getPoint();
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    this.F = paramMouseEvent.getPoint();
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    this.F = paramMouseEvent.getPoint();
  }
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    A();
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    A();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.F
 * JD-Core Version:    0.7.0.1
 */
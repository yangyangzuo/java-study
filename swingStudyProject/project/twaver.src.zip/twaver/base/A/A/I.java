package twaver.base.A.A;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import twaver.base.A.E.C;

public class I
  implements Icon
{
  private ImageIcon C;
  private int B;
  private int A;
  
  public I(String paramString, int paramInt1, int paramInt2)
  {
    this(C.B(paramString), paramInt1, paramInt2);
  }
  
  public I(ImageIcon paramImageIcon, int paramInt1, int paramInt2)
  {
    this.C = paramImageIcon;
    this.B = paramInt1;
    this.A = paramInt2;
  }
  
  public int getIconHeight()
  {
    if (this.A > 0) {
      return this.A;
    }
    return this.C.getIconHeight();
  }
  
  public int getIconWidth()
  {
    if (this.B > 0) {
      return this.B;
    }
    return this.C.getIconWidth();
  }
  
  public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2)
  {
    paramGraphics.drawImage(this.C.getImage(), paramInt1, paramInt2, getIconWidth(), getIconHeight(), null);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.A.I
 * JD-Core Version:    0.7.0.1
 */
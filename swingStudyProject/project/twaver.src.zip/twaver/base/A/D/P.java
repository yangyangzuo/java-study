package twaver.base.A.D;

import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.GeneralPath;

public class P
  extends E
{
  private GeneralPath I = new GeneralPath();
  private GeneralPath H = new GeneralPath();
  private int G;
  
  public P(E paramE, int paramInt)
  {
    this(paramE.A(), paramE.C(), paramE.D(), paramE.B(), paramInt);
  }
  
  public P(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    this(new Point(paramInt1, paramInt2), paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  public P(Point paramPoint, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super(paramPoint, paramInt1, paramInt2, paramInt3);
    this.G = paramInt4;
    this.G = (this.G > 0 ? paramInt4 : 0);
    if (this.F < 90)
    {
      this.I.moveTo(this.D[1].x, this.D[1].y);
      this.I.lineTo(this.D[2].x, this.D[2].y);
      this.I.lineTo(this.D[2].x, this.D[2].y + paramInt4);
      this.I.lineTo(this.D[1].x, this.D[1].y + paramInt4);
      this.I.closePath();
    }
    else
    {
      this.I.moveTo(this.D[0].x, this.D[0].y);
      this.I.lineTo(this.D[3].x, this.D[3].y);
      this.I.lineTo(this.D[3].x, this.D[3].y + paramInt4);
      this.I.lineTo(this.D[0].x, this.D[0].y + paramInt4);
      this.I.closePath();
    }
    this.H.moveTo(this.D[3].x, this.D[3].y);
    this.H.lineTo(this.D[2].x, this.D[2].y);
    this.H.lineTo(this.D[2].x, this.D[2].y + paramInt4);
    this.H.lineTo(this.D[3].x, this.D[3].y + paramInt4);
    this.H.closePath();
    Area localArea = new Area(this.C);
    localArea.add(new Area(this.I));
    localArea.add(new Area(this.H));
    this.C = localArea;
  }
  
  public Shape E()
  {
    return this.I;
  }
  
  public Shape F()
  {
    return this.H;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.P
 * JD-Core Version:    0.7.0.1
 */
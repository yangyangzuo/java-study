package twaver.base.A.D.D;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D.Float;

public abstract class D
  extends E
{
  public static final C K = new D()
  {
    protected Shape A(int paramAnonymousInt)
    {
      return new Rectangle2D.Float(1.0F, 1.0F, paramAnonymousInt - 2, paramAnonymousInt - 2);
    }
  };
  public static final C J = new D()
  {
    protected Shape A(int paramAnonymousInt)
    {
      GeneralPath localGeneralPath = new GeneralPath();
      localGeneralPath.moveTo(paramAnonymousInt / 2, paramAnonymousInt / 2);
      localGeneralPath.lineTo(0.0F, paramAnonymousInt);
      localGeneralPath.lineTo(paramAnonymousInt, paramAnonymousInt);
      localGeneralPath.closePath();
      return localGeneralPath;
    }
  };
  public static final C L = new D()
  {
    protected Shape A(int paramAnonymousInt)
    {
      GeneralPath localGeneralPath = new GeneralPath();
      localGeneralPath.moveTo(0.0F, paramAnonymousInt / 2);
      localGeneralPath.lineTo(paramAnonymousInt / 2, paramAnonymousInt);
      localGeneralPath.lineTo(paramAnonymousInt, paramAnonymousInt / 2);
      localGeneralPath.lineTo(paramAnonymousInt / 2, 0.0F);
      localGeneralPath.closePath();
      return localGeneralPath;
    }
  };
  private Shape I;
  
  public void A(Graphics2D paramGraphics2D, Color paramColor)
  {
    if (this.I == null) {
      this.I = A(this.B);
    }
    paramGraphics2D.setPaint(A.N.A(paramColor));
    paramGraphics2D.fill(this.I);
  }
  
  protected abstract Shape A(int paramInt);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D.D
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.D;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.TexturePaint;
import java.awt.geom.Rectangle2D.Double;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import twaver.TWaverConst;
import twaver.TWaverUtil;

public abstract class E
  implements C
{
  private static Map A = new HashMap();
  private BufferedImage C;
  protected int B = 10;
  
  public E() {}
  
  public E(int paramInt)
  {
    this.B = paramInt;
  }
  
  public Paint A(Color paramColor)
  {
    if (this.C == null)
    {
      localObject = TWaverUtil.valueOf(this.B);
      this.C = ((BufferedImage)A.get(localObject));
      if (this.C == null)
      {
        this.C = new BufferedImage(this.B, this.B, 2);
        A.put(localObject, this.C);
      }
    }
    Object localObject = this.C.createGraphics();
    ((Graphics2D)localObject).setComposite(AlphaComposite.Clear);
    ((Graphics2D)localObject).fillRect(0, 0, this.B, this.B);
    ((Graphics2D)localObject).setComposite(AlphaComposite.Src);
    ((Graphics2D)localObject).setColor(paramColor);
    ((Graphics2D)localObject).setStroke(TWaverConst.BASIC_STROKE);
    A((Graphics2D)localObject, paramColor);
    ((Graphics2D)localObject).dispose();
    Rectangle2D.Double localDouble = new Rectangle2D.Double(0.0D, 0.0D, this.B, this.B);
    return new TexturePaint(this.C, localDouble);
  }
  
  protected abstract void A(Graphics2D paramGraphics2D, Color paramColor);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D.E
 * JD-Core Version:    0.7.0.1
 */
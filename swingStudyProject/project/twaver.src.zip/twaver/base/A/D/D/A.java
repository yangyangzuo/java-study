package twaver.base.A.D.D;

import java.awt.Color;
import java.awt.Graphics2D;

public class A
  extends E
{
  public static final C O = new A(6);
  public static final C M = new A(3);
  public static final C N = new A(2)
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, Color paramAnonymousColor)
    {
      paramAnonymousGraphics2D.drawLine(0, 1, 0, 1);
      paramAnonymousGraphics2D.drawLine(1, 0, 1, 0);
    }
  };
  
  public A(int paramInt)
  {
    super(paramInt);
  }
  
  protected void A(Graphics2D paramGraphics2D, Color paramColor)
  {
    paramGraphics2D.drawLine(0, 0, 0, 0);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.D;

import java.awt.Color;
import java.awt.Graphics2D;

public abstract class B
  extends E
{
  public static final C H = new B()
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, int paramAnonymousInt)
    {
      paramAnonymousGraphics2D.drawLine(0, paramAnonymousInt, this.B, paramAnonymousInt);
      paramAnonymousGraphics2D.drawLine(paramAnonymousInt, 0, paramAnonymousInt, this.B);
    }
  };
  public static final C E = new B()
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, int paramAnonymousInt)
    {
      paramAnonymousGraphics2D.drawLine(0, paramAnonymousInt, this.B, paramAnonymousInt);
    }
  };
  public static final C G = new B()
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, int paramAnonymousInt)
    {
      paramAnonymousGraphics2D.drawLine(paramAnonymousInt, 0, paramAnonymousInt, this.B);
    }
  };
  public static final C D = new B()
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, int paramAnonymousInt)
    {
      paramAnonymousGraphics2D.drawLine(0, paramAnonymousInt, paramAnonymousInt, 0);
      paramAnonymousGraphics2D.drawLine(this.B - paramAnonymousInt, this.B, this.B, this.B - paramAnonymousInt);
    }
  };
  public static final C F = new B()
  {
    protected void A(Graphics2D paramAnonymousGraphics2D, int paramAnonymousInt)
    {
      paramAnonymousGraphics2D.drawLine(this.B - paramAnonymousInt, 0, this.B, paramAnonymousInt);
      paramAnonymousGraphics2D.drawLine(0, this.B - paramAnonymousInt, paramAnonymousInt, this.B);
    }
  };
  
  protected void A(Graphics2D paramGraphics2D, Color paramColor)
  {
    for (int i = 0; i <= this.B; i += 5) {
      A(paramGraphics2D, i);
    }
  }
  
  protected abstract void A(Graphics2D paramGraphics2D, int paramInt);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.D;

import java.awt.Color;
import java.awt.Paint;

public abstract interface C
{
  public abstract Paint A(Color paramColor);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D.C
 * JD-Core Version:    0.7.0.1
 */
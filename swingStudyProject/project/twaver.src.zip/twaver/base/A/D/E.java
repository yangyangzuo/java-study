package twaver.base.A.D;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class E
  implements Shape
{
  protected Point B = null;
  protected int E;
  protected int A;
  protected Shape C = null;
  protected int F = 45;
  protected Point[] D = new Point[4];
  
  public E(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this(new Point(paramInt1, paramInt2), paramInt3, paramInt4, paramInt5);
  }
  
  public E(Point paramPoint, int paramInt1, int paramInt2, int paramInt3)
  {
    this.B = paramPoint;
    this.E = paramInt1;
    this.A = paramInt2;
    this.F = paramInt3;
    this.F = (this.F > 180 ? 180 : this.F);
    this.F = (this.F < 0 ? 0 : this.F);
    double d = Math.toRadians(paramInt3);
    int i = (int)(paramInt2 / Math.tan(d));
    this.D[0] = paramPoint;
    this.D[1] = new Point(paramPoint.x + paramInt1, paramPoint.y);
    this.D[2] = new Point(paramPoint.x + paramInt1 - i, paramPoint.y + paramInt2);
    this.D[3] = new Point(paramPoint.x - i, paramPoint.y + paramInt2);
    GeneralPath localGeneralPath = new GeneralPath();
    localGeneralPath.moveTo(this.D[0].x, this.D[0].y);
    localGeneralPath.lineTo(this.D[1].x, this.D[1].y);
    localGeneralPath.lineTo(this.D[2].x, this.D[2].y);
    localGeneralPath.lineTo(this.D[3].x, this.D[3].y);
    localGeneralPath.closePath();
    this.C = localGeneralPath;
  }
  
  public Point A()
  {
    return this.B;
  }
  
  public int C()
  {
    return this.E;
  }
  
  public int D()
  {
    return this.A;
  }
  
  public int B()
  {
    return this.F;
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    return this.C.contains(paramDouble1, paramDouble2);
  }
  
  public boolean contains(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    return this.C.contains(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public boolean intersects(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    return this.C.intersects(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public Rectangle getBounds()
  {
    return this.C.getBounds();
  }
  
  public boolean contains(Point2D paramPoint2D)
  {
    return this.C.contains(paramPoint2D);
  }
  
  public Rectangle2D getBounds2D()
  {
    return this.C.getBounds2D();
  }
  
  public boolean contains(Rectangle2D paramRectangle2D)
  {
    return this.C.contains(paramRectangle2D);
  }
  
  public boolean intersects(Rectangle2D paramRectangle2D)
  {
    return this.C.intersects(paramRectangle2D);
  }
  
  public PathIterator getPathIterator(AffineTransform paramAffineTransform)
  {
    return this.C.getPathIterator(paramAffineTransform);
  }
  
  public PathIterator getPathIterator(AffineTransform paramAffineTransform, double paramDouble)
  {
    return this.C.getPathIterator(paramAffineTransform, paramDouble);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.B;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public class B
  implements G
{
  private Reference A = null;
  
  public B(G paramG)
  {
    this.A = new WeakReference(paramG);
  }
  
  public boolean A(F paramF)
  {
    G localG = (G)this.A.get();
    if (localG != null)
    {
      localG.A(paramF);
      return false;
    }
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.B
 * JD-Core Version:    0.7.0.1
 */
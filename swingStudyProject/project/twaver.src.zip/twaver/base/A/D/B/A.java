package twaver.base.A.D.B;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.WritableRaster;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class A
{
  public static final int c = 0;
  public static final int i = 1;
  public static final int f = 2;
  protected BufferedInputStream U;
  protected int X;
  protected int A;
  protected int B;
  protected boolean C;
  protected int Z;
  protected int N = 1;
  protected int[] T;
  protected int[] m;
  protected int[] H;
  protected int h;
  protected int d;
  protected int n;
  protected int k;
  protected boolean E;
  protected boolean K;
  protected int b;
  protected int Q;
  protected int O;
  protected int R;
  protected int _;
  protected Rectangle g;
  protected BufferedImage D;
  protected BufferedImage Y;
  protected byte[] G = new byte[256];
  protected int M = 0;
  protected int S = 0;
  protected int j = 0;
  protected boolean V = false;
  protected int a = 0;
  protected int I;
  protected static final int L = 4096;
  protected short[] e;
  protected byte[] l;
  protected byte[] W;
  protected byte[] F;
  protected ArrayList P;
  protected int J;
  
  public int B(int paramInt)
  {
    this.a = -1;
    if ((paramInt >= 0) && (paramInt < this.J)) {
      this.a = ((_A)this.P.get(paramInt)).A;
    }
    return this.a;
  }
  
  public int E()
  {
    return this.J;
  }
  
  public BufferedImage K()
  {
    return A(0);
  }
  
  public int F()
  {
    return this.N;
  }
  
  protected void A()
  {
    int[] arrayOfInt1 = ((DataBufferInt)this.D.getRaster().getDataBuffer()).getData();
    if (this.j > 0)
    {
      if (this.j == 3)
      {
        int i1 = this.J - 2;
        if (i1 > 0) {
          this.Y = A(i1 - 1);
        } else {
          this.Y = null;
        }
      }
      if (this.Y != null)
      {
        int[] arrayOfInt2 = ((DataBufferInt)this.Y.getRaster().getDataBuffer()).getData();
        System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, this.A * this.B);
        if (this.j == 2)
        {
          Graphics2D localGraphics2D = this.D.createGraphics();
          Color localColor = null;
          if (this.V) {
            localColor = new Color(0, 0, 0, 0);
          } else {
            localColor = new Color(this.n);
          }
          localGraphics2D.setColor(localColor);
          localGraphics2D.setComposite(AlphaComposite.Src);
          localGraphics2D.fill(this.g);
          localGraphics2D.dispose();
        }
      }
    }
    int i2 = 1;
    int i3 = 8;
    int i4 = 0;
    for (int i5 = 0; i5 < this._; i5++)
    {
      int i6 = i5;
      if (this.K)
      {
        if (i4 >= this._)
        {
          i2++;
          switch (i2)
          {
          case 2: 
            i4 = 4;
            break;
          case 3: 
            i4 = 2;
            i3 = 4;
            break;
          case 4: 
            i4 = 1;
            i3 = 2;
          }
        }
        i6 = i4;
        i4 += i3;
      }
      i6 += this.O;
      if (i6 < this.B)
      {
        int i7 = i6 * this.A;
        int i8 = i7 + this.Q;
        int i9 = i8 + this.R;
        if (i7 + this.A < i9) {
          i9 = i7 + this.A;
        }
        int i10 = i5 * this.R;
        while (i8 < i9)
        {
          int i11 = this.F[(i10++)] & 0xFF;
          int i12 = this.H[i11];
          if (i12 != 0) {
            arrayOfInt1[i8] = i12;
          }
          i8++;
        }
      }
    }
  }
  
  public BufferedImage A(int paramInt)
  {
    BufferedImage localBufferedImage = null;
    if ((paramInt >= 0) && (paramInt < this.J)) {
      localBufferedImage = ((_A)this.P.get(paramInt)).B;
    }
    return localBufferedImage;
  }
  
  public Dimension J()
  {
    return new Dimension(this.A, this.B);
  }
  
  public int A(BufferedInputStream paramBufferedInputStream)
  {
    H();
    if (paramBufferedInputStream != null)
    {
      this.U = paramBufferedInputStream;
      D();
      if (!N())
      {
        B();
        if (this.J < 0) {
          this.X = 1;
        }
      }
    }
    else
    {
      this.X = 2;
    }
    try
    {
      paramBufferedInputStream.close();
    }
    catch (IOException localIOException) {}
    return this.X;
  }
  
  public int A(InputStream paramInputStream)
  {
    H();
    if (paramInputStream != null)
    {
      if (!(paramInputStream instanceof BufferedInputStream)) {
        paramInputStream = new BufferedInputStream(paramInputStream);
      }
      this.U = ((BufferedInputStream)paramInputStream);
      D();
      if (!N())
      {
        B();
        if (this.J < 0) {
          this.X = 1;
        }
      }
    }
    else
    {
      this.X = 2;
    }
    try
    {
      paramInputStream.close();
    }
    catch (IOException localIOException) {}
    return this.X;
  }
  
  protected void O()
  {
    int i1 = -1;
    int i2 = this.R * this._;
    if ((this.F == null) || (this.F.length < i2)) {
      this.F = new byte[i2];
    }
    if (this.e == null) {
      this.e = new short[4096];
    }
    if (this.l == null) {
      this.l = new byte[4096];
    }
    if (this.W == null) {
      this.W = new byte[4097];
    }
    int i15 = M();
    int i4 = 1 << i15;
    int i7 = i4 + 1;
    int i3 = i4 + 2;
    int i9 = i1;
    int i6 = i15 + 1;
    int i5 = (1 << i6) - 1;
    for (int i11 = 0; i11 < i4; i11++)
    {
      this.e[i11] = 0;
      this.l[i11] = ((byte)i11);
    }
    int i18;
    int i19;
    int i17;
    int i16;
    int i12;
    int i10;
    int i14 = i10 = i12 = i16 = i17 = i19 = i18 = 0;
    int i13 = 0;
    while (i13 < i2) {
      if (i17 == 0)
      {
        if (i10 < i6)
        {
          if (i12 == 0)
          {
            i12 = Q();
            if (i12 <= 0) {
              break;
            }
            i18 = 0;
          }
          i14 += ((this.G[i18] & 0xFF) << i10);
          i10 += 8;
          i18++;
          i12--;
        }
        else
        {
          i11 = i14 & i5;
          i14 >>= i6;
          i10 -= i6;
          if ((i11 > i3) || (i11 == i7)) {
            break;
          }
          if (i11 == i4)
          {
            i6 = i15 + 1;
            i5 = (1 << i6) - 1;
            i3 = i4 + 2;
            i9 = i1;
          }
          else if (i9 == i1)
          {
            this.W[(i17++)] = this.l[i11];
            i9 = i11;
            i16 = i11;
          }
          else
          {
            int i8 = i11;
            if (i11 == i3) {
              this.W[(i17++)] = ((byte)i16);
            }
            for (i11 = i9; i11 > i4; i11 = this.e[i11]) {
              this.W[(i17++)] = this.l[i11];
            }
            i16 = this.l[i11] & 0xFF;
            if (i3 >= 4096) {
              break;
            }
            this.W[(i17++)] = ((byte)i16);
            this.e[i3] = ((short)i9);
            this.l[i3] = ((byte)i16);
            i3++;
            if (((i3 & i5) == 0) && (i3 < 4096))
            {
              i6++;
              i5 += i3;
            }
            i9 = i8;
          }
        }
      }
      else
      {
        i17--;
        this.F[(i19++)] = this.W[i17];
        i13++;
      }
    }
    for (i13 = i19; i13 < i2; i13++) {
      this.F[i13] = 0;
    }
  }
  
  protected boolean N()
  {
    return this.X != 0;
  }
  
  protected void H()
  {
    this.X = 0;
    this.J = 0;
    this.P = new ArrayList();
    this.T = null;
    this.m = null;
  }
  
  protected int M()
  {
    int i1 = 0;
    try
    {
      i1 = this.U.read();
    }
    catch (IOException localIOException)
    {
      this.X = 1;
    }
    return i1;
  }
  
  protected int Q()
  {
    this.M = M();
    int i1 = 0;
    if (this.M > 0)
    {
      try
      {
        int i2 = 0;
        while (i1 < this.M)
        {
          i2 = this.U.read(this.G, i1, this.M - i1);
          if (i2 == -1) {
            break;
          }
          i1 += i2;
        }
      }
      catch (IOException localIOException) {}
      if (i1 < this.M) {
        this.X = 1;
      }
    }
    return i1;
  }
  
  protected int[] C(int paramInt)
  {
    int i1 = 3 * paramInt;
    int[] arrayOfInt = (int[])null;
    byte[] arrayOfByte = new byte[i1];
    int i2 = 0;
    try
    {
      i2 = this.U.read(arrayOfByte);
    }
    catch (IOException localIOException) {}
    if (i2 < i1)
    {
      this.X = 1;
    }
    else
    {
      arrayOfInt = new int[256];
      int i3 = 0;
      int i4 = 0;
      while (i3 < paramInt)
      {
        int i5 = arrayOfByte[(i4++)] & 0xFF;
        int i6 = arrayOfByte[(i4++)] & 0xFF;
        int i7 = arrayOfByte[(i4++)] & 0xFF;
        arrayOfInt[(i3++)] = (0xFF000000 | i5 << 16 | i6 << 8 | i7);
      }
    }
    return arrayOfInt;
  }
  
  protected void B()
  {
    int i1 = 0;
    while ((i1 == 0) && (!N()))
    {
      int i2 = M();
      switch (i2)
      {
      case 44: 
        P();
        break;
      case 33: 
        i2 = M();
        switch (i2)
        {
        case 249: 
          I();
          break;
        case 255: 
          Q();
          String str = "";
          for (int i3 = 0; i3 < 11; i3++) {
            str = str + (char)this.G[i3];
          }
          if (str.equals("NETSCAPE2.0")) {
            G();
          } else {
            R();
          }
          break;
        default: 
          R();
        }
        break;
      case 59: 
        i1 = 1;
        break;
      case 0: 
        break;
      default: 
        this.X = 1;
      }
    }
  }
  
  protected void I()
  {
    M();
    int i1 = M();
    this.S = ((i1 & 0x1C) >> 2);
    if (this.S == 0) {
      this.S = 1;
    }
    this.V = ((i1 & 0x1) != 0);
    this.a = (L() * 10);
    this.I = M();
    M();
  }
  
  protected void D()
  {
    String str = "";
    for (int i1 = 0; i1 < 6; i1++) {
      str = str + (char)M();
    }
    if (!str.startsWith("GIF"))
    {
      this.X = 1;
      return;
    }
    S();
    if ((this.C) && (!N()))
    {
      this.T = C(this.Z);
      this.d = this.T[this.h];
    }
  }
  
  protected void P()
  {
    this.Q = L();
    this.O = L();
    this.R = L();
    this._ = L();
    int i1 = M();
    this.E = ((i1 & 0x80) != 0);
    this.K = ((i1 & 0x40) != 0);
    this.b = (2 << (i1 & 0x7));
    if (this.E)
    {
      this.m = C(this.b);
      this.H = this.m;
    }
    else
    {
      this.H = this.T;
      if (this.h == this.I) {
        this.d = 0;
      }
    }
    int i2 = 0;
    if (this.V)
    {
      i2 = this.H[this.I];
      this.H[this.I] = 0;
    }
    if (this.H == null) {
      this.X = 1;
    }
    if (N()) {
      return;
    }
    O();
    R();
    if (N()) {
      return;
    }
    this.J += 1;
    this.D = new BufferedImage(this.A, this.B, 3);
    A();
    this.P.add(new _A(this.D, this.a));
    if (this.V) {
      this.H[this.I] = i2;
    }
    C();
  }
  
  protected void S()
  {
    this.A = L();
    this.B = L();
    int i1 = M();
    this.C = ((i1 & 0x80) != 0);
    this.Z = (2 << (i1 & 0x7));
    this.h = M();
    this.k = M();
  }
  
  protected void G()
  {
    do
    {
      Q();
      if (this.G[0] == 1)
      {
        int i1 = this.G[1] & 0xFF;
        int i2 = this.G[2] & 0xFF;
        this.N = (i2 << 8 | i1);
      }
    } while ((this.M > 0) && (!N()));
  }
  
  protected int L()
  {
    return M() | M() << 8;
  }
  
  protected void C()
  {
    this.j = this.S;
    this.g = new Rectangle(this.Q, this.O, this.R, this._);
    this.Y = this.D;
    this.n = this.d;
    this.m = null;
  }
  
  protected void R()
  {
    do
    {
      Q();
    } while ((this.M > 0) && (!N()));
  }
  
  static class _A
  {
    public BufferedImage B;
    public int A;
    
    public _A(BufferedImage paramBufferedImage, int paramInt)
    {
      this.B = paramBufferedImage;
      this.A = paramInt;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.A
 * JD-Core Version:    0.7.0.1
 */
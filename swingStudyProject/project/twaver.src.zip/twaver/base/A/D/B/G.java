package twaver.base.A.D.B;

public abstract interface G
{
  public abstract boolean A(F paramF);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.G
 * JD-Core Version:    0.7.0.1
 */
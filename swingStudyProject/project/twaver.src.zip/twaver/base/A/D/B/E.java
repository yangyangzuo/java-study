package twaver.base.A.D.B;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import twaver.TaskScheduler;

public class E
{
  private List C = new LinkedList();
  private TaskScheduler B = null;
  private HashMap D = new HashMap();
  private static E A = null;
  
  public static synchronized E B()
  {
    if ((A == null) || (!A.B.isRunning()))
    {
      A = new E();
      A.B = TaskScheduler.createTaskScheduler(50);
      A.B.start("GIF Scheduler Thread");
    }
    return A;
  }
  
  public String A(String paramString)
  {
    if ((paramString == null) || (paramString.startsWith("gif:"))) {
      return paramString;
    }
    return C(paramString).G();
  }
  
  public D C(String paramString)
  {
    D localD = (D)this.D.get(paramString);
    if (localD == null)
    {
      localD = new D(paramString);
      this.D.put(paramString, localD);
      if (localD.F()) {
        this.B.register(localD);
      }
    }
    return localD;
  }
  
  public boolean B(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    D localD = C(paramString);
    if (localD == null) {
      return false;
    }
    return localD.F();
  }
  
  public TaskScheduler A()
  {
    return this.B;
  }
  
  public synchronized void A(G paramG)
  {
    this.C.add(new B(paramG));
  }
  
  protected synchronized void A(F paramF)
  {
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      G localG = (G)localIterator.next();
      if (localG.A(paramF)) {
        localIterator.remove();
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.E
 * JD-Core Version:    0.7.0.1
 */
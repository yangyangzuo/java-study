package twaver.base.A.D.B;

import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import twaver.TWaverUtil;
import twaver.TaskAdapter;
import twaver.base.A.E.C;
import twaver.base.A.E.l;

public class D
  extends TaskAdapter
{
  private final String F;
  private final int E;
  private int H = 0;
  private final int[] D;
  private final String[] G;
  
  D(String paramString)
  {
    this.F = paramString;
    if ((paramString == null) || (!paramString.trim().toLowerCase().endsWith(".gif")))
    {
      this.E = 0;
      this.D = null;
      this.G = null;
      return;
    }
    A localA = null;
    try
    {
      localA = new A();
      localA.A(C.B(paramString, false));
    }
    catch (Exception localException)
    {
      this.E = 0;
      this.D = null;
      this.G = null;
      return;
    }
    this.E = localA.E();
    this.D = new int[this.E];
    this.G = new String[this.E];
    if (this.E > 1) {
      for (int i = 0; i < this.E; i++)
      {
        this.D[i] = localA.B(i);
        this.G[i] = ("gif:" + i + "@" + paramString);
        BufferedImage localBufferedImage = localA.A(i);
        TWaverUtil.registerImageIcon(this.G[i], new ImageIcon(localBufferedImage));
      }
    }
  }
  
  public String G()
  {
    if (this.E <= 1) {
      return this.F;
    }
    if (!l.A) {
      return this.G[0];
    }
    return this.G[this.H];
  }
  
  public int getInterval()
  {
    return this.D[this.H];
  }
  
  public void run(long paramLong)
  {
    this.H += 1;
    if (this.H >= this.E) {
      this.H = 0;
    }
    E.B().A(F.B().A(this));
  }
  
  public int E()
  {
    return this.E;
  }
  
  public boolean F()
  {
    return this.E > 1;
  }
  
  public String D()
  {
    return this.F;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.D
 * JD-Core Version:    0.7.0.1
 */
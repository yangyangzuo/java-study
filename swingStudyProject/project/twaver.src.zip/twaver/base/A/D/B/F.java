package twaver.base.A.D.B;

import java.awt.event.ActionEvent;

public class F
  extends ActionEvent
{
  private static final F A = new F();
  
  private F()
  {
    super(new Object(), 0, null, 0L, 0);
  }
  
  public static F B()
  {
    return A;
  }
  
  public F A(D paramD)
  {
    this.source = paramD;
    return A;
  }
  
  public D A()
  {
    return (D)this.source;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.F
 * JD-Core Version:    0.7.0.1
 */
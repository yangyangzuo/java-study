package twaver.base.A.D.B;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import twaver.DataBoxEvent;
import twaver.DataBoxListener;
import twaver.Element;
import twaver.TDataBox;
import twaver.network.ui.IconAttachmentHolder;

public class C
{
  private TDataBox C = null;
  private Map D = new HashMap();
  private Map A = new HashMap();
  private boolean B = false;
  
  public C(TDataBox paramTDataBox, boolean paramBoolean)
  {
    this.C = paramTDataBox;
    this.B = paramBoolean;
    Iterator localIterator = paramTDataBox.iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      B(localElement);
    }
    this.C.addDataBoxListener(new DataBoxListener()
    {
      public void elementAdded(DataBoxEvent paramAnonymousDataBoxEvent)
      {
        C.this.B(paramAnonymousDataBoxEvent.getElement());
      }
      
      public void elementRemoved(DataBoxEvent paramAnonymousDataBoxEvent)
      {
        C.this.A(paramAnonymousDataBoxEvent.getElement());
      }
      
      public void elementsCleared(DataBoxEvent paramAnonymousDataBoxEvent)
      {
        C.this.A();
      }
    });
    this.C.addElementPropertyChangeListener(new PropertyChangeListener()
    {
      public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
      {
        C.this.A(paramAnonymousPropertyChangeEvent);
      }
    });
  }
  
  public List A(String paramString)
  {
    List localList1 = C(paramString);
    List localList2 = B(paramString);
    if ((localList1 != null) && (localList2 == null)) {
      return localList1;
    }
    if ((localList1 == null) && (localList2 != null)) {
      return localList2;
    }
    if ((localList1 != null) && (localList2 != null))
    {
      ArrayList localArrayList = new ArrayList(localList1.size() + localList2.size());
      for (int i = 0; i < localList1.size(); i++) {
        localArrayList.add(localList1.get(i));
      }
      for (i = 0; i < localList2.size(); i++) {
        localArrayList.add(localList2.get(i));
      }
      return localArrayList;
    }
    return null;
  }
  
  public List C(String paramString)
  {
    return (List)this.D.get(paramString);
  }
  
  public List B(String paramString)
  {
    return (List)this.A.get(paramString);
  }
  
  protected void B(Element paramElement)
  {
    if (paramElement == null) {
      return;
    }
    String str1 = this.B ? paramElement.getIconURL() : paramElement.getImageURL();
    if (E.B().B(str1))
    {
      localObject1 = C(str1);
      if (localObject1 == null)
      {
        localObject1 = new ArrayList();
        this.D.put(str1, localObject1);
      }
      ((List)localObject1).add(paramElement);
    }
    if (this.B) {
      return;
    }
    Object localObject1 = "StateIcon:";
    Map localMap = paramElement.getClientProperties();
    if (localMap == null) {
      return;
    }
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str2 = localIterator.next().toString();
      if ((str2 != null) && (str2.startsWith((String)localObject1)))
      {
        Object localObject2 = paramElement.getClientProperty(str2);
        if (Boolean.TRUE.equals(localObject2))
        {
          String str3 = str2.substring(((String)localObject1).length());
          Object localObject3 = IconAttachmentHolder.getAttachmentInfo(str3);
          if ((localObject3 instanceof String))
          {
            str1 = localObject3.toString();
            if (E.B().B(str1))
            {
              Object localObject4 = B(str1);
              if (localObject4 == null)
              {
                localObject4 = new ArrayList();
                this.A.put(str1, localObject4);
              }
              ((List)localObject4).add(paramElement);
            }
          }
        }
      }
    }
  }
  
  protected void A(Element paramElement)
  {
    String str1 = this.B ? paramElement.getIconURL() : paramElement.getImageURL();
    List localList = C(str1);
    if (localList != null)
    {
      localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext()) {
        if (paramElement == ((Iterator)localObject1).next())
        {
          ((Iterator)localObject1).remove();
          break;
        }
      }
    }
    if (this.B) {
      return;
    }
    Object localObject1 = "StateIcon:";
    Iterator localIterator = paramElement.getClientProperties().keySet().iterator();
    while (localIterator.hasNext())
    {
      String str2 = localIterator.next().toString();
      if (str2.startsWith((String)localObject1))
      {
        Object localObject2 = paramElement.getClientProperty(str2);
        if (Boolean.TRUE.equals(localObject2))
        {
          String str3 = str2.substring(((String)localObject1).length());
          Object localObject3 = IconAttachmentHolder.getAttachmentInfo(str3);
          if ((localObject3 instanceof String))
          {
            str1 = localObject3.toString();
            localList = B(str1);
            if (localList != null)
            {
              localIterator = localList.iterator();
              while (localIterator.hasNext()) {
                if (paramElement == localIterator.next())
                {
                  localIterator.remove();
                  break;
                }
              }
            }
          }
        }
      }
    }
  }
  
  protected void A()
  {
    this.D.clear();
    this.A.clear();
  }
  
  protected void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    String str1 = paramPropertyChangeEvent.getPropertyName();
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    Object localObject1;
    Object localObject2;
    if (this.B)
    {
      if (str1.equals("icon"))
      {
        str2 = (String)paramPropertyChangeEvent.getOldValue();
        localObject1 = C(str2);
        if (localObject1 != null)
        {
          localObject2 = ((List)localObject1).iterator();
          while (((Iterator)localObject2).hasNext()) {
            if (localElement == ((Iterator)localObject2).next())
            {
              ((Iterator)localObject2).remove();
              break;
            }
          }
        }
        localObject2 = localElement.getIconURL();
        if (E.B().B((String)localObject2))
        {
          localObject1 = C((String)localObject2);
          if (localObject1 == null)
          {
            localObject1 = new ArrayList();
            this.D.put(localObject2, localObject1);
          }
          ((List)localObject1).add(localElement);
        }
        return;
      }
      return;
    }
    if (str1.equals("image"))
    {
      str2 = (String)paramPropertyChangeEvent.getOldValue();
      localObject1 = C(str2);
      if (localObject1 != null)
      {
        localObject2 = ((List)localObject1).iterator();
        while (((Iterator)localObject2).hasNext()) {
          if (localElement == ((Iterator)localObject2).next())
          {
            ((Iterator)localObject2).remove();
            break;
          }
        }
      }
      localObject2 = localElement.getImageURL();
      if (E.B().B((String)localObject2))
      {
        localObject1 = C((String)localObject2);
        if (localObject1 == null)
        {
          localObject1 = new ArrayList();
          this.D.put(localObject2, localObject1);
        }
        ((List)localObject1).add(localElement);
      }
      return;
    }
    String str2 = "CP:StateIcon:";
    if (str1.startsWith(str2))
    {
      localObject1 = str1.substring(str2.length());
      localObject2 = IconAttachmentHolder.getAttachmentInfo((String)localObject1);
      if ((localObject2 instanceof String))
      {
        String str3 = localObject2.toString();
        Object localObject3;
        if (Boolean.TRUE.equals(paramPropertyChangeEvent.getOldValue()))
        {
          localObject3 = B(str3);
          if (localObject3 != null)
          {
            Iterator localIterator = ((List)localObject3).iterator();
            while (localIterator.hasNext()) {
              if (localElement == localIterator.next())
              {
                localIterator.remove();
                break;
              }
            }
          }
        }
        if ((Boolean.TRUE.equals(paramPropertyChangeEvent.getNewValue())) && (E.B().B(str3)))
        {
          localObject3 = B(str3);
          if (localObject3 == null)
          {
            localObject3 = new ArrayList();
            this.A.put(str3, localObject3);
          }
          ((List)localObject3).add(localElement);
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B.C
 * JD-Core Version:    0.7.0.1
 */
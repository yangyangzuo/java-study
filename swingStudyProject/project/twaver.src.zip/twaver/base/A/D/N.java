package twaver.base.A.D;

import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Area;

public class N
{
  public static final int A = 1;
  
  public static Point A(Shape paramShape, Point paramPoint1, Point paramPoint2)
  {
    if ((paramShape == null) || (paramPoint1 == null) || (paramPoint2 == null)) {
      return null;
    }
    Area localArea = new Area(paramShape);
    if (localArea.contains(paramPoint1) == localArea.contains(paramPoint2)) {
      return null;
    }
    if ((Math.abs(paramPoint2.x - paramPoint1.x) <= 1) && (Math.abs(paramPoint2.y - paramPoint1.y) <= 1)) {
      return new Point((paramPoint2.x + paramPoint1.x) / 2, (paramPoint2.y + paramPoint1.y) / 2);
    }
    Point localPoint = new Point((paramPoint2.x + paramPoint1.x) / 2, (paramPoint2.y + paramPoint1.y) / 2);
    if (localArea.contains(paramPoint1) != localArea.contains(localPoint)) {
      return A(localArea, localPoint, paramPoint1);
    }
    return A(localArea, localPoint, paramPoint2);
  }
  
  public static double C(Point paramPoint1, Point paramPoint2)
  {
    double d1 = paramPoint1.getY() - paramPoint2.getY();
    double d2 = paramPoint1.getX() - paramPoint2.getX();
    double d3 = Math.atan(d1 / d2);
    d3 = Math.toDegrees(d3);
    if (d3 < 0.0D) {
      d3 += 180.0D;
    }
    return d3;
  }
  
  public static double A(Point paramPoint1, Point paramPoint2)
  {
    double d1 = paramPoint2.getY() - paramPoint1.getY();
    double d2 = paramPoint1.getX() - paramPoint2.getX();
    double d3 = Math.atan(d1 / d2);
    d3 = Math.toDegrees(d3);
    if (d3 < 0.0D) {
      d3 += 180.0D;
    }
    return d3;
  }
  
  public static double B(Point paramPoint1, Point paramPoint2)
  {
    double d1 = paramPoint1.getY() - paramPoint2.getY();
    double d2 = paramPoint1.getX() - paramPoint2.getX();
    double d3 = Math.atan(d2 / d1);
    d3 = Math.toDegrees(d3);
    if (d3 < 0.0D) {
      d3 += 180.0D;
    }
    return d3;
  }
  
  public static double D(Point paramPoint1, Point paramPoint2)
  {
    double d1 = paramPoint1.getY() - paramPoint2.getY();
    double d2 = paramPoint2.getX() - paramPoint1.getX();
    double d3 = Math.atan(d2 / d1);
    d3 = Math.toDegrees(d3);
    if (d3 < 0.0D) {
      d3 += 180.0D;
    }
    return d3;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.N
 * JD-Core Version:    0.7.0.1
 */
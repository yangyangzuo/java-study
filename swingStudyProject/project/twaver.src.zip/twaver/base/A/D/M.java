package twaver.base.A.D;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Float;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class M
  implements Shape
{
  private Ellipse2D A = null;
  private Area C = null;
  private Area B = null;
  
  public M(Ellipse2D paramEllipse2D, int paramInt)
  {
    this.A = paramEllipse2D;
    int i = (int)paramEllipse2D.getX();
    int j = (int)paramEllipse2D.getY();
    int k = (int)paramEllipse2D.getWidth();
    int m = (int)paramEllipse2D.getHeight();
    Ellipse2D.Float localFloat = new Ellipse2D.Float(i, j + paramInt, k, m);
    Rectangle localRectangle = new Rectangle(i, j + m / 2, k, paramInt);
    this.C = new Area(localFloat);
    this.C.add(new Area(localRectangle));
    this.C.subtract(new Area(paramEllipse2D));
    this.B = new Area(paramEllipse2D);
    this.B.add(new Area(localFloat));
    this.B.add(new Area(localRectangle));
  }
  
  public M(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this(new Ellipse2D.Float(paramInt1, paramInt2, paramInt3, paramInt4), paramInt5);
  }
  
  public Ellipse2D A()
  {
    return this.A;
  }
  
  public Area B()
  {
    return this.C;
  }
  
  public Rectangle getBounds()
  {
    return this.B.getBounds();
  }
  
  public Rectangle2D getBounds2D()
  {
    return this.B.getBounds2D();
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    return this.B.contains(paramDouble1, paramDouble2);
  }
  
  public boolean contains(Point2D paramPoint2D)
  {
    return this.B.contains(paramPoint2D);
  }
  
  public boolean intersects(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    return this.B.intersects(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public boolean intersects(Rectangle2D paramRectangle2D)
  {
    return this.B.intersects(paramRectangle2D);
  }
  
  public boolean contains(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    return this.B.contains(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public boolean contains(Rectangle2D paramRectangle2D)
  {
    return this.B.contains(paramRectangle2D);
  }
  
  public PathIterator getPathIterator(AffineTransform paramAffineTransform)
  {
    return this.B.getPathIterator(paramAffineTransform);
  }
  
  public PathIterator getPathIterator(AffineTransform paramAffineTransform, double paramDouble)
  {
    return this.B.getPathIterator(paramAffineTransform, paramDouble);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.M
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.JToolBar;
import javax.swing.JWindow;
import twaver.base.A.E.O;
import twaver.network.TNetwork;

public final class L
{
  private TNetwork D = null;
  private JWindow C = null;
  private JToolBar B = null;
  private JComponent E = null;
  private JComponent A = null;
  private Object F = null;
  
  public void A(JComponent paramJComponent1, JComponent paramJComponent2, Object paramObject)
  {
    this.E = paramJComponent1;
    this.A = paramJComponent2;
    this.F = paramObject;
  }
  
  public L(TNetwork paramTNetwork)
  {
    this.D = paramTNetwork;
  }
  
  public void C()
  {
    if (this.C != null) {
      return;
    }
    Window localWindow = O.B(this.D);
    if (localWindow == null) {
      this.C = new JWindow();
    } else {
      this.C = new JWindow(localWindow, localWindow.getGraphicsConfiguration());
    }
    this.C.getContentPane().setLayout(new BorderLayout());
    this.D.remove(this.D.getLayeredPane());
    this.C.getContentPane().add(this.D.getLayeredPane(), "Center");
    if (this.E != null)
    {
      if ((this.E instanceof JToolBar)) {
        ((JToolBar)this.E).setOrientation(0);
      }
      if (this.A != null)
      {
        this.A.remove(this.E);
        this.A.invalidate();
        this.A.repaint();
      }
      this.E.revalidate();
      this.E.repaint();
      this.C.getContentPane().add(this.E, "North");
    }
    else
    {
      this.B = null;
      Component[] arrayOfComponent = this.D.getComponents();
      for (int i = 0; i < arrayOfComponent.length; i++) {
        if ((arrayOfComponent[i] instanceof JToolBar))
        {
          this.B = ((JToolBar)arrayOfComponent[i]);
          break;
        }
      }
      if (this.B != null)
      {
        this.B.setOrientation(0);
        this.D.remove(this.B);
        this.B.revalidate();
        this.B.repaint();
        this.C.getContentPane().add(this.B, "North");
      }
    }
    this.C.setVisible(true);
    O.A(this.C);
    this.D.getCanvas().requestFocus();
  }
  
  public void D()
  {
    if (this.C == null) {
      return;
    }
    this.C.getContentPane().removeAll();
    this.C.setVisible(false);
    this.C.dispose();
    this.C = null;
    this.D.add(this.D.getLayeredPane(), "Center");
    if (this.E != null)
    {
      if ((this.E instanceof JToolBar))
      {
        if ((this.F == "North") || (this.F == "South")) {
          ((JToolBar)this.E).setOrientation(0);
        }
        if ((this.F == "West") || (this.F == "East")) {
          ((JToolBar)this.E).setOrientation(1);
        }
      }
      if (this.A != null)
      {
        if (this.F == null) {
          this.A.add(this.E);
        } else {
          this.A.add(this.E, this.F);
        }
        this.A.revalidate();
        this.A.repaint();
      }
      this.E.revalidate();
      this.E.repaint();
    }
    else if (this.B != null)
    {
      this.B.setOrientation(0);
      this.D.add(this.B, "North");
      this.B.revalidate();
      this.B.repaint();
      this.B = null;
    }
    this.D.getCanvas().requestFocus();
    this.D.revalidate();
  }
  
  public boolean B()
  {
    return this.C != null;
  }
  
  public void A()
  {
    if (B()) {
      D();
    } else {
      C();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.L
 * JD-Core Version:    0.7.0.1
 */
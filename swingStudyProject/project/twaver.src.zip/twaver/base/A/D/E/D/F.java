package twaver.base.A.D.E.D;

import twaver.base.A.D.E.B.G;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.R;
import twaver.base.A.E.T;

public class F
  extends H
{
  L B;
  L D;
  L E;
  L C;
  
  public boolean B(C paramC)
  {
    return C(paramC);
  }
  
  public void A(C paramC)
  {
    I(paramC);
    if (A() != null) {
      D(paramC);
    }
    G(paramC);
  }
  
  protected void I(C paramC)
  {
    L(paramC);
    J(paramC);
    F(paramC);
  }
  
  private void L(C paramC)
  {
    D localD = paramC.J();
    while (localD.C())
    {
      E localE = paramC.N(localD.H());
      paramC.B(localD.H(), localE);
      localD.B();
    }
  }
  
  protected void G(C paramC)
  {
    H(paramC);
    E(paramC);
    K(paramC);
  }
  
  private void H(C paramC)
  {
    D localD = paramC.J();
    while (localD.C())
    {
      E localE = paramC.N(localD.H());
      paramC.B(localD.H(), localE);
      localD.B();
    }
  }
  
  private void E(C paramC)
  {
    R localR = paramC.M();
    while (localR.C())
    {
      K localK = paramC.D(localR.I());
      E localE1 = localK.D();
      localK.B(localE1);
      localE1 = localK.C();
      localK.A(localE1);
      for (int i = 0; i < localK.B(); i++)
      {
        E localE2 = localK.A(i);
        localK.A(i, localE2.B(), localE2.A());
      }
      localR.B();
    }
  }
  
  private void J(C paramC)
  {
    R localR = paramC.M();
    while (localR.C())
    {
      K localK = paramC.D(localR.I());
      E localE1 = localK.D();
      localK.B(localE1);
      localE1 = localK.C();
      localK.A(localE1);
      for (int i = 0; i < localK.B(); i++)
      {
        E localE2 = localK.A(i);
        localK.A(i, localE2.B(), localE2.A());
      }
      localR.B();
    }
  }
  
  private void K(C paramC)
  {
    if (this.B != null)
    {
      paramC.A(T.A, this.B);
      this.B = null;
      this.E = null;
    }
    if (this.D != null)
    {
      paramC.A(T.F, this.D);
      this.D = null;
      this.C = null;
    }
  }
  
  private void F(C paramC)
  {
    this.B = paramC.A(T.A);
    if (this.B != null)
    {
      this.E = new _A(this.B);
      paramC.A(T.A, this.E);
    }
    this.D = paramC.A(T.F);
    if (this.D != null)
    {
      this.C = new _A(this.D);
      paramC.A(T.F, this.C);
    }
  }
  
  private class _A
    extends G
  {
    L B;
    
    public Object D(Object paramObject)
    {
      I localI = (I)this.B.D(paramObject);
      return localI;
    }
    
    _A(L paramL)
    {
      this.B = paramL;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.F
 * JD-Core Version:    0.7.0.1
 */
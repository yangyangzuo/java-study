package twaver.base.A.D.E.E;

import java.util.Comparator;
import java.util.Hashtable;

public class C
{
  P C = new P();
  P A = new P();
  boolean G = false;
  boolean D = false;
  private J F = new J(3, 5);
  private J B = new J(3, 5);
  private Hashtable E = new Hashtable(11);
  
  public O I()
  {
    O localO = new O(this);
    return localO;
  }
  
  public G A(O paramO1, O paramO2)
  {
    return A(paramO1, null, paramO2, null, 0, 0);
  }
  
  public G A(O paramO1, G paramG1, O paramO2, G paramG2, int paramInt1, int paramInt2)
  {
    G localG = new G(this, paramO1, paramG1, paramO2, paramG2, paramInt1, paramInt2);
    return localG;
  }
  
  public void B(O paramO)
  {
    C(paramO);
  }
  
  private void C(O paramO)
  {
    G localG;
    while ((localG = paramO.G[0]) != null) {
      C(localG);
    }
    while ((localG = paramO.G[1]) != null) {
      C(localG);
    }
    this.C.C(paramO);
    paramO.D = null;
    this.G = true;
  }
  
  public void C(G paramG)
  {
    F(paramG);
  }
  
  private void F(G paramG)
  {
    if (paramG.R() != this) {
      throw new IllegalArgumentException();
    }
    O localO1 = paramG.W();
    O localO2 = paramG.T();
    B(paramG, localO1, localO2);
    this.A.C(paramG);
    paramG.B(null);
    this.D = true;
  }
  
  public void A(O paramO)
  {
    paramO.F = this.C.B();
    paramO.A(this);
    paramO.D();
    if (paramO.A.length < this.F.A) {
      this.F.A(paramO, paramO.A.length, this.F.A);
    }
    this.C.A(paramO);
    this.G = true;
  }
  
  public void D(G paramG)
  {
    if (paramG.R() != null) {
      throw new IllegalArgumentException();
    }
    if (paramG.A.length < this.B.A) {
      this.B.A(paramG, paramG.A.length, this.B.A);
    }
    if ((paramG.A() == null) || (((G)paramG.A()).R() != this)) {
      this.A.A(paramG);
    } else {
      this.A.A(paramG, paramG.A());
    }
    paramG.B(this);
    paramG.Q();
    A(paramG, paramG.W(), null, paramG.T(), null, 0, 0);
    this.D = true;
  }
  
  public void A(G paramG, O paramO1, O paramO2)
  {
    O localO1 = paramG.W();
    O localO2 = paramG.T();
    if (paramG.R() == null)
    {
      paramG.K = paramO1;
      paramG.N = paramO2;
    }
    else
    {
      if (localO1 != paramO1)
      {
        localO1.B(paramG, 0, 0);
        paramG.K = paramO1;
        paramO1.A(paramG, null, 0, 0, 0);
      }
      if (localO2 != paramO2)
      {
        localO2.B(paramG, 1, 1);
        paramG.N = paramO2;
        paramO2.A(paramG, null, 1, 1, 0);
      }
    }
  }
  
  public void G(G paramG)
  {
    A(paramG, paramG.T(), paramG.W());
  }
  
  public void E(G paramG)
  {
    F(paramG);
  }
  
  public void B(G paramG)
  {
    D(paramG);
  }
  
  public void F(O paramO)
  {
    B(paramO);
  }
  
  public void G(O paramO)
  {
    A(paramO);
  }
  
  public int C()
  {
    return this.C.B();
  }
  
  public int B()
  {
    return this.C.B();
  }
  
  public int K()
  {
    return this.A.B();
  }
  
  public int A()
  {
    return this.A.B();
  }
  
  public boolean D()
  {
    return this.C.A();
  }
  
  public boolean E(O paramO)
  {
    return paramO.P() == this;
  }
  
  public boolean A(G paramG)
  {
    return paramG.R() == this;
  }
  
  public O G()
  {
    return (O)this.C.D();
  }
  
  public D J()
  {
    return this.C.C();
  }
  
  public R M()
  {
    return this.A.C();
  }
  
  public void A(Comparator paramComparator1, Comparator paramComparator2)
  {
    G[] arrayOfG = new G[K()];
    D localD;
    if ((paramComparator1 != null) && (paramComparator2 != null))
    {
      localD = J();
      while (localD.C())
      {
        localD.H().A(paramComparator1, 1, arrayOfG);
        localD.H().A(paramComparator2, 0, arrayOfG);
        localD.B();
      }
    }
    else if ((paramComparator2 == null) && (paramComparator1 != null))
    {
      localD = J();
      while (localD.C())
      {
        localD.H().A(paramComparator1, 1, arrayOfG);
        localD.B();
      }
    }
    else if ((paramComparator2 != null) && (paramComparator1 == null))
    {
      localD = J();
      while (localD.C())
      {
        localD.H().A(paramComparator2, 0, arrayOfG);
        localD.B();
      }
    }
  }
  
  public I H()
  {
    return this.F.A(this.C);
  }
  
  public K F()
  {
    return this.B.B(this.A);
  }
  
  public void A(I paramI)
  {
    this.F.A(paramI, this.C);
  }
  
  public void A(K paramK)
  {
    this.B.A(paramK, this.A);
  }
  
  public L A(Object paramObject)
  {
    return (L)this.E.get(paramObject);
  }
  
  public void A(Object paramObject, L paramL)
  {
    this.E.put(paramObject, paramL);
  }
  
  public void B(Object paramObject)
  {
    this.E.remove(paramObject);
  }
  
  private void A(G paramG1, O paramO1, G paramG2, O paramO2, G paramG3, int paramInt1, int paramInt2)
  {
    paramO1.A(paramG1, paramG2, 0, 0, paramInt1);
    paramO2.A(paramG1, paramG3, 1, 1, paramInt2);
  }
  
  private void B(G paramG, O paramO1, O paramO2)
  {
    paramO1.B(paramG, 0, 0);
    paramO2.B(paramG, 1, 1);
  }
  
  void L()
  {
    int i = 0;
    D localD = J();
    while (localD.C())
    {
      localD.H().F = (i++);
      localD.B();
    }
    this.G = false;
  }
  
  void E()
  {
    int i = 0;
    R localR = M();
    while (localR.C())
    {
      localR.I().M = (i++);
      localR.B();
    }
    this.D = false;
  }
  
  void D(O paramO)
  {
    paramO.A(this, this.F.A);
    paramO.F = this.C.B();
    this.C.A(paramO);
  }
  
  void B(G paramG1, O paramO1, G paramG2, O paramO2, G paramG3, int paramInt1, int paramInt2)
  {
    paramG1.A(this, paramO1, paramO2, this.B.A);
    paramG1.M = this.A.B();
    this.A.A(paramG1);
    A(paramG1, paramG1.W(), paramG2, paramG1.T(), paramG3, paramInt1, paramInt2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.C
 * JD-Core Version:    0.7.0.1
 */
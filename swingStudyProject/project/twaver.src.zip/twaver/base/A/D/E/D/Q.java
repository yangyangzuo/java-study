package twaver.base.A.D.E.D;

import java.util.Vector;
import twaver.base.A.D.E.C.E;
import twaver.base.A.E.T;

public class Q
  implements K
{
  private Vector C = new Vector();
  private E B = T.D;
  private E A = T.D;
  
  public int B()
  {
    return this.C.size();
  }
  
  public E A(int paramInt)
  {
    return (E)this.C.elementAt(paramInt);
  }
  
  public void A(int paramInt, double paramDouble1, double paramDouble2)
  {
    this.C.setElementAt(new E(paramDouble1, paramDouble2), paramInt);
  }
  
  public void A(double paramDouble1, double paramDouble2)
  {
    this.C.addElement(new E(paramDouble1, paramDouble2));
  }
  
  public void A()
  {
    this.C.removeAllElements();
  }
  
  public E D()
  {
    return this.B;
  }
  
  public E C()
  {
    return this.A;
  }
  
  public void B(E paramE)
  {
    this.B = paramE;
  }
  
  public void A(E paramE)
  {
    this.A = paramE;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.Q
 * JD-Core Version:    0.7.0.1
 */
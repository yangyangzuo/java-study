package twaver.base.A.D.E.F;

import java.util.Arrays;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;

public class F
{
  public static boolean D(twaver.base.A.D.E.E.C paramC)
  {
    _A local_A = new _A();
    local_A.A(paramC);
    return local_A.N;
  }
  
  public static O C(twaver.base.A.D.E.E.C paramC)
  {
    D localD = paramC.J();
    O localO = null;
    int i = 0;
    localD.E();
    while (localD.C())
    {
      if (localD.H().C() == 0)
      {
        localO = localD.H();
        i++;
      }
      localD.B();
    }
    if (i == 1) {
      return localO;
    }
    i = 0;
    localD.E();
    while (localD.C())
    {
      if (localD.H().O() == 0)
      {
        localO = localD.H();
        i++;
      }
      localD.B();
    }
    if (i == 1) {
      return localO;
    }
    return B(paramC);
  }
  
  public static twaver.base.A.D.E.E.A A(twaver.base.A.D.E.E.C paramC)
  {
    return A(paramC, C(paramC));
  }
  
  public static O B(twaver.base.A.D.E.E.C paramC)
  {
    int[] arrayOfInt = new int[paramC.B()];
    I localI = twaver.base.A.D.E.B.A.A(arrayOfInt);
    return A(paramC, localI);
  }
  
  public static O A(twaver.base.A.D.E.E.C paramC, I paramI)
  {
    O localO = paramC.G();
    O[] arrayOfO = new O[1];
    int[] arrayOfInt = new int[paramC.B()];
    Arrays.fill(arrayOfInt, -1);
    twaver.base.A.D.E.E.A localA = A(paramC, localO);
    A(localO, paramI, arrayOfO, arrayOfInt, -1);
    R localR = localA.J();
    while (localR.C())
    {
      paramC.G(localR.I());
      localR.B();
    }
    return arrayOfO[0];
  }
  
  private static int A(O paramO, I paramI, O[] paramArrayOfO, int[] paramArrayOfInt, int paramInt)
  {
    int i = 0;
    for (G localG1 = paramO.K(); localG1 != null; localG1 = localG1.V())
    {
      localObject = localG1.T();
      int k = A((O)localObject, paramI, paramArrayOfO, paramArrayOfInt, paramInt);
      if (k > paramInt) {
        paramInt = k;
      }
      i += paramArrayOfInt[localObject.F()];
    }
    int j = i * (paramO.P().C() - 1 - i);
    for (Object localObject = paramO.K(); localObject != null; localObject = ((G)localObject).V())
    {
      O localO1 = ((G)localObject).T();
      for (G localG2 = ((G)localObject).V(); localG2 != null; localG2 = localG2.V())
      {
        O localO2 = localG2.T();
        j += paramArrayOfInt[localO1.F()] * paramArrayOfInt[localO2.F()];
      }
    }
    paramI.B(paramO, j);
    paramArrayOfInt[paramO.F()] = (i + 1);
    if (j > paramInt)
    {
      paramInt = j;
      paramArrayOfO[0] = paramO;
    }
    return paramInt;
  }
  
  public static twaver.base.A.D.E.E.A A(twaver.base.A.D.E.E.C paramC, O paramO)
  {
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A();
    C local1 = new C()
    {
      protected void A(G paramAnonymousG, O paramAnonymousO, boolean paramAnonymousBoolean)
      {
        if ((paramAnonymousBoolean) && (paramAnonymousG.W() == paramAnonymousO)) {
          F.this.C(paramAnonymousG);
        }
      }
    };
    local1.B(false);
    local1.A(paramC, paramO);
    R localR = localA.J();
    while (localR.C())
    {
      paramC.G(localR.I());
      localR.B();
    }
    return localA;
  }
  
  static class _A
    extends C
  {
    boolean N = true;
    
    protected void A(G paramG, O paramO, boolean paramBoolean)
    {
      if (!paramBoolean) {
        this.N = false;
      }
    }
    
    protected void B(O paramO)
    {
      this.N = false;
    }
    
    _A()
    {
      B(false);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.F
 * JD-Core Version:    0.7.0.1
 */
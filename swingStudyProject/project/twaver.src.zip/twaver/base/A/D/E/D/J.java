package twaver.base.A.D.E.D;

import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;

public class J
  extends H
{
  protected A H = new A();
  public K G;
  protected double F = 10.0D;
  
  public void A(C paramC)
  {
    this.G = paramC.F();
    A(paramC);
    D(paramC);
    B(paramC);
    A(paramC, this.G);
    paramC.A(this.G);
  }
  
  public boolean B(C paramC)
  {
    if (A() == null) {
      return true;
    }
    this.G = paramC.F();
    A(paramC);
    boolean bool = C(paramC);
    B(paramC);
    paramC.A(this.G);
    return bool;
  }
  
  protected void A(C paramC, K paramK)
  {
    R localR = paramC.M();
    while (localR.C())
    {
      G localG = localR.I();
      if (paramK.D(localG) != null)
      {
        A localA = (A)paramK.D(localG);
        L.A(paramC, localG, localA, this.F);
      }
      localR.B();
    }
  }
  
  protected void A(twaver.base.A.D.E.E.C paramC)
  {
    I localI = paramC.H();
    D localD = paramC.J();
    while (localD.C())
    {
      O localO1 = localD.H();
      R localR = localO1.M();
      G localG1;
      O localO2;
      while (localR.C())
      {
        localG1 = localR.I();
        localO2 = localG1.E(localO1);
        G localG2 = (G)localI.D(localO2);
        if (localG2 != localG1) {
          if (localG2 == null)
          {
            localI.B(localO2, localG1);
          }
          else
          {
            if (this.G.D(localG2) == null) {
              this.G.A(localG2, new A());
            }
            A localA = (A)this.G.D(localG2);
            localA.add(localG1);
            this.H.C(localG1);
            paramC.E(localG1);
          }
        }
        localR.B();
      }
      localR = localO1.M();
      while (localR.C())
      {
        localG1 = localR.I();
        localO2 = localG1.E(localO1);
        localI.B(localO2, null);
        localR.B();
      }
      localD.B();
    }
    paramC.A(localI);
  }
  
  private void B(twaver.base.A.D.E.E.C paramC)
  {
    while (!this.H.isEmpty()) {
      paramC.B(this.H.K());
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.J
 * JD-Core Version:    0.7.0.1
 */
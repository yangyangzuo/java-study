package twaver.base.A.D.E.F;

import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;

public class B
{
  public static Q[] B(twaver.base.A.D.E.E.C paramC)
  {
    I localI = twaver.base.A.D.E.B.A.A(new int[paramC.C()]);
    return A(paramC, localI, A(paramC, localI));
  }
  
  public static int A(twaver.base.A.D.E.E.C paramC, I paramI)
  {
    D localD1 = paramC.J();
    while (localD1.C())
    {
      paramI.B(localD1.H(), -1);
      localD1.B();
    }
    int i = 0;
    twaver.base.A.D.E.B.B localB = new twaver.base.A.D.E.B.B(paramC.C());
    D localD2 = paramC.J();
    while (localD2.C())
    {
      O localO = localD2.H();
      if (paramI.A(localO) == -1) {
        A(localO, localB, paramI, i++);
      }
      localD2.B();
    }
    return i;
  }
  
  public static twaver.base.A.D.E.E.A C(twaver.base.A.D.E.E.C paramC)
  {
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A();
    Q[] arrayOfQ = B(paramC);
    for (int i = 0; i < arrayOfQ.length - 1; i++)
    {
      G localG = paramC.A(arrayOfQ[i].O(), arrayOfQ[(i + 1)].Q());
      localA.add(localG);
    }
    return localA;
  }
  
  public static Q[] A(twaver.base.A.D.E.E.C paramC, I paramI, int paramInt)
  {
    Q[] arrayOfQ = new Q[paramInt];
    for (int i = 0; i < paramInt; i++) {
      arrayOfQ[i] = new Q();
    }
    D localD = paramC.J();
    while (localD.C())
    {
      arrayOfQ[paramI.A(localD.H())].D(localD.H());
      localD.B();
    }
    return arrayOfQ;
  }
  
  private static void A(O paramO, twaver.base.A.D.E.B.B paramB, I paramI, int paramInt)
  {
    paramB.A(paramO);
    paramI.B(paramO, paramInt);
    while (!paramB.A())
    {
      paramO = (O)paramB.C();
      O localO;
      for (G localG = paramO.K(); localG != null; localG = localG.V())
      {
        localO = localG.T();
        if (paramI.A(localO) == -1)
        {
          paramI.B(localO, paramInt);
          paramB.A(localO);
        }
      }
      for (localG = paramO.L(); localG != null; localG = localG.S())
      {
        localO = localG.W();
        if (paramI.A(localO) == -1)
        {
          paramI.B(localO, paramInt);
          paramB.A(localO);
        }
      }
    }
  }
  
  public static int A(twaver.base.A.D.E.E.C paramC, K paramK, I paramI)
  {
    _A local_A = new _A(paramK, paramI);
    local_A.A(paramC);
    return local_A.K;
  }
  
  public static twaver.base.A.D.E.E.A[] A(twaver.base.A.D.E.E.C paramC, K paramK, int paramInt)
  {
    twaver.base.A.D.E.E.A[] arrayOfA = new twaver.base.A.D.E.E.A[paramInt];
    for (int i = 0; i < paramInt; i++) {
      arrayOfA[i] = new twaver.base.A.D.E.E.A();
    }
    R localR = paramC.M();
    while (localR.C())
    {
      arrayOfA[paramK.A(localR.I())].add(localR.I());
      localR.B();
    }
    return arrayOfA;
  }
  
  public static twaver.base.A.D.E.E.A A(twaver.base.A.D.E.E.C paramC)
  {
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A();
    I localI = twaver.base.A.D.E.B.A.B(new boolean[paramC.C()]);
    K localK = twaver.base.A.D.E.B.A.B(new int[paramC.K()]);
    int i = A(paramC, localK, localI);
    twaver.base.A.D.E.E.A[] arrayOfA = A(paramC, localK, i);
    if (arrayOfA.length > 1)
    {
      Q localQ = new Q();
      for (int j = 0; j < arrayOfA.length; j++)
      {
        localObject1 = arrayOfA[j];
        O localO2 = null;
        Object localObject2;
        if (((twaver.base.A.D.E.E.A)localObject1).size() == 1)
        {
          localObject2 = ((twaver.base.A.D.E.E.A)localObject1).L();
          if (((G)localObject2).W().G() == 1) {
            localO2 = ((G)localObject2).W();
          } else if (((G)localObject2).T().G() == 1) {
            localO2 = ((G)localObject2).T();
          }
        }
        else
        {
          localObject2 = ((twaver.base.A.D.E.E.A)localObject1).J();
          while (((R)localObject2).C())
          {
            G localG = ((R)localObject2).I();
            if (localI.B(localG.W())) {
              if (localO2 == null)
              {
                localO2 = localG.W();
              }
              else if (localO2 != localG.W())
              {
                localO2 = null;
                break;
              }
            }
            if (localI.B(localG.T())) {
              if (localO2 == null)
              {
                localO2 = localG.T();
              }
              else if (localO2 != localG.T())
              {
                localO2 = null;
                break;
              }
            }
            ((R)localObject2).B();
          }
          if (localO2 != null)
          {
            localObject2 = ((twaver.base.A.D.E.E.A)localObject1).L();
            if (((G)localObject2).W() != localO2) {
              localO2 = ((G)localObject2).W();
            } else {
              localO2 = ((G)localObject2).T();
            }
          }
        }
        if (localO2 != null) {
          localQ.add(localO2);
        }
      }
      O localO1;
      for (Object localObject1 = localQ.N(); !localQ.isEmpty(); localObject1 = localO1)
      {
        localO1 = localQ.N();
        localA.C(paramC.A((O)localObject1, localO1));
      }
    }
    return localA;
  }
  
  static class _A
    extends C
  {
    int[] L;
    int[] I;
    twaver.base.A.D.E.B.B M;
    K J;
    I G;
    boolean H;
    int K;
    
    public void A(twaver.base.A.D.E.E.C paramC)
    {
      this.L = new int[paramC.B()];
      this.I = new int[paramC.B()];
      this.M = new twaver.base.A.D.E.B.B(paramC.K());
      super.A(paramC);
    }
    
    protected void A(O paramO, int paramInt)
    {
      int tmp17_16 = paramInt;
      this.L[paramO.F()] = tmp17_16;
      this.I[paramO.F()] = tmp17_16;
    }
    
    protected void A(G paramG, O paramO, boolean paramBoolean)
    {
      this.M.A(paramG);
      if (!paramBoolean)
      {
        O localO = paramG.E(paramO);
        this.L[localO.F()] = Math.min(this.L[localO.F()], this.I[paramO.F()]);
      }
    }
    
    protected void B(O paramO)
    {
      this.H = false;
    }
    
    protected void A(G paramG, O paramO)
    {
      O localO = paramG.E(paramO);
      if (this.L[paramO.F()] >= this.I[localO.F()])
      {
        while (this.M.B() != paramG) {
          this.J.A(this.M.C(), this.K);
        }
        this.J.A(this.M.C(), this.K);
        this.K += 1;
        if (this.M.A())
        {
          if (this.H) {
            this.G.B(localO, true);
          } else {
            this.H = true;
          }
        }
        else {
          this.G.B(localO, true);
        }
      }
      this.L[localO.F()] = Math.min(this.L[localO.F()], this.L[paramO.F()]);
    }
    
    _A(K paramK, I paramI)
    {
      this.G = paramI;
      this.J = paramK;
      this.H = false;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.B
 * JD-Core Version:    0.7.0.1
 */
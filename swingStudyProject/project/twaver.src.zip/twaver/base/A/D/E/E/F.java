package twaver.base.A.D.E.E;

public abstract interface F
{
  public abstract boolean C();
  
  public abstract void B();
  
  public abstract void G();
  
  public abstract void E();
  
  public abstract void A();
  
  public abstract Object D();
  
  public abstract int F();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.E;

final class H
  implements K
{
  int H;
  boolean I = false;
  J G;
  
  H(int paramInt, J paramJ)
  {
    this.H = paramInt;
    this.G = paramJ;
  }
  
  public void A(Object paramObject1, Object paramObject2)
  {
    try
    {
      ((N)paramObject1).A[this.H] = paramObject2;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject1;
      this.G.A(localN, localN.A.length, this.G.A);
      A(paramObject1, paramObject2);
    }
  }
  
  public Object D(Object paramObject)
  {
    return ((N)paramObject).A[this.H];
  }
  
  public void A(Object paramObject, boolean paramBoolean)
  {
    try
    {
      ((N)paramObject).A[this.H] = (paramBoolean ? Boolean.TRUE : Boolean.FALSE);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.G.A(localN, localN.A.length, this.G.A);
      A(paramObject, paramBoolean);
    }
  }
  
  public boolean B(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.H];
    if (localObject == null) {
      return false;
    }
    return ((Boolean)localObject).booleanValue();
  }
  
  public void A(Object paramObject, int paramInt)
  {
    try
    {
      ((N)paramObject).A[this.H] = new Integer(paramInt);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.G.A(localN, localN.A.length, this.G.A);
      A(paramObject, paramInt);
    }
  }
  
  public int A(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.H];
    if (localObject == null) {
      return 0;
    }
    return ((Integer)localObject).intValue();
  }
  
  public void A(Object paramObject, double paramDouble)
  {
    try
    {
      ((N)paramObject).A[this.H] = new Double(paramDouble);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.G.A(localN, localN.A.length, this.G.A);
      A(paramObject, paramDouble);
    }
  }
  
  public double C(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.H];
    if (localObject == null) {
      return 0.0D;
    }
    return ((Double)localObject).doubleValue();
  }
  
  public boolean B()
  {
    return this.I;
  }
  
  public void A()
  {
    this.I = true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.H
 * JD-Core Version:    0.7.0.1
 */
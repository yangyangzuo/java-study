package twaver.base.A.D.E.E;

public class A
  extends S
{
  public A() {}
  
  public A(R paramR)
  {
    super(paramR);
  }
  
  public R J()
  {
    return new _A();
  }
  
  public G L()
  {
    return (G)E();
  }
  
  public G K()
  {
    return (G)A();
  }
  
  class _A
    extends S._A
    implements R
  {
    _A()
    {
      super();
    }
    
    public G I()
    {
      return (G)D();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.A
 * JD-Core Version:    0.7.0.1
 */
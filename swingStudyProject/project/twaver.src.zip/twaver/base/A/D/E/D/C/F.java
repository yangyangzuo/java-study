package twaver.base.A.D.E.D.C;

import java.util.HashMap;
import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;

class F
{
  Q H;
  C A;
  I D;
  I I;
  K C;
  I F;
  I E;
  HashMap G;
  double B = 20.0D;
  
  F(C paramC, I paramI1, I paramI2, K paramK)
  {
    this.A = paramC;
    this.D = paramI1;
    this.I = paramI2;
    this.C = paramK;
  }
  
  void A(double paramDouble)
  {
    this.B = paramDouble;
  }
  
  Q[] B(Q[] paramArrayOfQ)
  {
    return paramArrayOfQ;
  }
  
  Q[] A(Q[] paramArrayOfQ)
  {
    return paramArrayOfQ;
  }
  
  boolean B(O paramO)
  {
    return this.F == null ? false : this.F.B(paramO);
  }
  
  _A A(O paramO)
  {
    return this.E == null ? null : (_A)this.E.D(paramO);
  }
  
  void A()
  {
    this.A.A(this.E);
    this.A.A(this.F);
  }
  
  static class _A
  {
    A D = new A();
    A A = new A();
    A E = new A();
    A C = new A();
    O B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.F
 * JD-Core Version:    0.7.0.1
 */
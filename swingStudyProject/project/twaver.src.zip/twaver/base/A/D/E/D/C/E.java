package twaver.base.A.D.E.D.C;

class E
{
  double H;
  double B;
  double D;
  double A;
  double E;
  double C;
  double G;
  double F;
  double J;
  double I;
  
  double A()
  {
    return this.H - this.D - this.E - this.J;
  }
  
  double B()
  {
    return this.B + this.A + this.C + this.I;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.E
 * JD-Core Version:    0.7.0.1
 */
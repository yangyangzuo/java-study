package twaver.base.A.D.E.D.C;

import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.Q;

public abstract class A
  implements C
{
  protected double C = 20.0D;
  protected double F = 60.0D;
  protected double E = 5.0D;
  protected double D = 0.0D;
  protected I H;
  protected twaver.base.A.D.E.D.C G;
  
  public void A(double paramDouble)
  {
    this.E = paramDouble;
  }
  
  public void C(double paramDouble)
  {
    this.D = paramDouble;
  }
  
  public void B(double paramDouble)
  {
    this.C = paramDouble;
  }
  
  public void D(double paramDouble)
  {
    this.F = paramDouble;
  }
  
  public void A(I paramI)
  {
    this.H = paramI;
  }
  
  public double A()
  {
    return this.F;
  }
  
  public void A(twaver.base.A.D.E.D.C paramC, Q[] paramArrayOfQ)
  {
    D[] arrayOfD = new D[paramArrayOfQ.length];
    for (int i = 0; i < paramArrayOfQ.length; i++) {
      arrayOfD[i] = paramArrayOfQ[i].P();
    }
    A(paramC, arrayOfD);
  }
  
  public void A(twaver.base.A.D.E.D.C paramC, D[] paramArrayOfD)
  {
    double[] arrayOfDouble = new double[paramArrayOfD.length];
    double d1 = 0.0D;
    for (int i = 0; i < paramArrayOfD.length; i++)
    {
      double d2 = 0.0D;
      D localD = paramArrayOfD[i];
      localD.E();
      while (localD.C())
      {
        d2 = Math.max(d2, paramC.Q(localD.H()));
        localD.B();
      }
      arrayOfDouble[i] = d2;
      localD.E();
      while (localD.C())
      {
        d3 = (arrayOfDouble[i] - paramC.Q(localD.H())) / 2.0D;
        paramC.A(localD.H(), new E(paramC.O(localD.H()), d1 + d3));
        localD.B();
      }
      double d3 = A();
      d1 += arrayOfDouble[i] + d3;
      localD.E();
    }
  }
  
  public void A(twaver.base.A.D.E.D.C paramC, Q[] paramArrayOfQ, L paramL)
  {
    this.G = paramC;
    A(paramArrayOfQ, paramL);
  }
  
  protected abstract void A(Q[] paramArrayOfQ, L paramL);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.A
 * JD-Core Version:    0.7.0.1
 */
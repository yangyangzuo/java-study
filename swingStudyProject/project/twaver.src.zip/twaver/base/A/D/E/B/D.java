package twaver.base.A.D.E.B;

import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.S;

public class D
{
  I C;
  I A;
  C B;
  S E;
  int D;
  
  public D(C paramC)
  {
    this.B = paramC;
    this.C = paramC.H();
    this.A = paramC.H();
    this.E = new S();
    this.D = 0;
  }
  
  public D(C paramC, L paramL, int paramInt1, int paramInt2)
  {
    this(paramC, paramL, paramInt1, paramInt2, null);
  }
  
  public D(C paramC, L paramL1, int paramInt1, int paramInt2, L paramL2)
  {
    this(paramC);
    A(paramL1, paramInt1, paramInt2, paramL2);
  }
  
  void A(L paramL1, int paramInt1, int paramInt2, L paramL2)
  {
    Q[] arrayOfQ = new Q[paramInt2 - paramInt1 + 1];
    for (int i = paramInt1; i <= paramInt2; i++) {
      arrayOfQ[i] = new _A(i);
    }
    twaver.base.A.D.E.E.D localD1 = this.B.J();
    Object localObject;
    while (localD1.C())
    {
      localObject = localD1.H();
      if ((paramL2 == null) || (paramL2.B(localObject)))
      {
        this.C.B(localObject, arrayOfQ[(paramL1.A(localObject) - paramInt1)].A(localObject));
        this.D += 1;
      }
      localD1.B();
    }
    for (int j = 0; j < arrayOfQ.length; j++)
    {
      localObject = arrayOfQ[j];
      M localM = this.E.D(localObject);
      twaver.base.A.D.E.E.D localD2 = ((Q)localObject).P();
      while (localD2.C())
      {
        this.A.B(localD2.H(), localM);
        localD2.B();
      }
    }
  }
  
  public void A()
  {
    this.B.A(this.A);
    this.B.A(this.C);
  }
  
  public boolean C()
  {
    return this.D == 0;
  }
  
  public O B()
  {
    while (((Q)this.E.E()).isEmpty()) {
      this.E.A();
    }
    this.D -= 1;
    O localO = ((Q)this.E.E()).N();
    this.A.B(localO, null);
    this.C.B(localO, null);
    return localO;
  }
  
  public O D()
  {
    while (((Q)this.E.H()).isEmpty()) {
      this.E.D();
    }
    this.D -= 1;
    O localO = ((Q)this.E.H()).N();
    this.A.B(localO, null);
    this.C.B(localO, null);
    return localO;
  }
  
  public void A(O paramO)
  {
    M localM1 = (M)this.C.D(paramO);
    M localM2 = (M)this.A.D(paramO);
    _A local_A = (_A)localM2.B();
    Object localObject = null;
    M localM3 = localM2.A();
    if (localM3 != null)
    {
      localObject = (Q)localM3.B();
      this.A.B(paramO, localM3);
    }
    else
    {
      localObject = new _A(local_A.R() + 1);
      this.A.B(paramO, this.E.D(localObject));
    }
    local_A.F(localM1);
    this.C.B(paramO, ((Q)localObject).A(paramO));
  }
  
  public void B(O paramO)
  {
    M localM1 = (M)this.C.D(paramO);
    M localM2 = (M)this.A.D(paramO);
    _A local_A = (_A)localM2.B();
    Object localObject = null;
    M localM3 = localM2.C();
    if (localM3 != null)
    {
      localObject = (Q)localM3.B();
      this.A.B(paramO, localM3);
    }
    else
    {
      localObject = new _A(local_A.R() - 1);
      this.A.B(paramO, this.E.A(localObject));
    }
    local_A.F(localM1);
    this.C.B(paramO, ((Q)localObject).A(paramO));
  }
  
  static class _A
    extends Q
  {
    int G;
    
    int R()
    {
      return this.G;
    }
    
    _A(int paramInt)
    {
      this.G = paramInt;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.D
 * JD-Core Version:    0.7.0.1
 */
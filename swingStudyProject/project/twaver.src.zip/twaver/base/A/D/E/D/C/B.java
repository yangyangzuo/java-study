package twaver.base.A.D.E.D.C;

import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.Q;

public abstract interface B
{
  public abstract Q[] A(C paramC, I paramI, int paramInt);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.B
 * JD-Core Version:    0.7.0.1
 */
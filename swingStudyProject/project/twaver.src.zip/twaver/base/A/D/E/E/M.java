package twaver.base.A.D.E.E;

public class M
{
  M B;
  M A;
  Object C;
  
  M(Object paramObject)
  {
    this.C = paramObject;
  }
  
  public M A()
  {
    return this.B;
  }
  
  public M C()
  {
    return this.A;
  }
  
  public void A(Object paramObject)
  {
    this.C = paramObject;
  }
  
  public Object B()
  {
    return this.C;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.M
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.C;

import twaver.base.A.D.E.E.F;

public abstract interface B
  extends F
{
  public abstract E J();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.B
 * JD-Core Version:    0.7.0.1
 */
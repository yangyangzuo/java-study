package twaver.base.A.D.E.D.C;

import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.Q;

public abstract interface C
{
  public static final Object B = new Object();
  public static final Object A = new Object();
  
  public abstract void A(twaver.base.A.D.E.D.C paramC, Q[] paramArrayOfQ, L paramL);
  
  public abstract void A(I paramI);
  
  public abstract void B(double paramDouble);
  
  public abstract void A(double paramDouble);
  
  public abstract void C(double paramDouble);
  
  public abstract void D(double paramDouble);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.C
 * JD-Core Version:    0.7.0.1
 */
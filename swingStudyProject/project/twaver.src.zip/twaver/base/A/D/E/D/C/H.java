package twaver.base.A.D.E.D.C;

import java.util.Arrays;
import java.util.Comparator;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;

public class H
  extends A
{
  private int[] K;
  private O[] U;
  private O[] L;
  private boolean[] R;
  private O[] J;
  private O[] N;
  private double[][] Q;
  private double[] T;
  private O[] I;
  private boolean[] S;
  private double[] P;
  private double[] M;
  private L V;
  private L O;
  
  protected void A(Q[] paramArrayOfQ, L paramL)
  {
    twaver.base.A.D.E.D.C localC = this.G;
    this.V = localC.A(C.B);
    this.O = localC.A(C.A);
    A(localC, paramArrayOfQ);
    A(localC, paramArrayOfQ);
    A(paramArrayOfQ, twaver.base.A.D.E.B.A.A(this.R), this.H, this.K);
    A(localC, this.Q[0]);
    C(paramArrayOfQ);
    A(localC, this.Q[0], paramArrayOfQ);
    A(paramArrayOfQ);
    A(localC, this.Q[1]);
    C(paramArrayOfQ);
    A(localC, this.Q[1], paramArrayOfQ);
    A(paramArrayOfQ);
    A(this.Q[1]);
    B(paramArrayOfQ);
    A(localC, this.Q[2]);
    C(paramArrayOfQ);
    A(localC, this.Q[2], paramArrayOfQ);
    A(paramArrayOfQ);
    A(localC, this.Q[3]);
    C(paramArrayOfQ);
    A(localC, this.Q[3], paramArrayOfQ);
    A(paramArrayOfQ);
    A(this.Q[3]);
    B(paramArrayOfQ);
    A(localC);
    B();
  }
  
  void A(double[] paramArrayOfDouble)
  {
    for (int i = 0; i < paramArrayOfDouble.length; i++) {
      paramArrayOfDouble[i] = (-paramArrayOfDouble[i]);
    }
  }
  
  void A(Q[] paramArrayOfQ)
  {
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      Q localQ = paramArrayOfQ[i];
      localQ.C();
    }
    Object localObject3;
    Object localObject4;
    for (i = 0; i < paramArrayOfQ.length; i++)
    {
      int j = 0;
      localObject2 = null;
      localObject3 = paramArrayOfQ[i].P();
      while (((D)localObject3).C())
      {
        localObject4 = ((D)localObject3).H();
        int k = ((O)localObject4).F();
        this.K[k] = (j++);
        this.U[k] = localObject2;
        this.L[k] = null;
        if (localObject2 != null) {
          this.L[localObject2.F()] = localObject4;
        }
        localObject2 = localObject4;
        ((D)localObject3).B();
      }
    }
    L localL = this.V;
    this.V = this.O;
    this.O = localL;
    Object localObject1 = this.G.M();
    while (((R)localObject1).C())
    {
      localObject2 = ((R)localObject1).I();
      localObject3 = this.G.L((G)localObject2);
      this.G.D((G)localObject2, new E(-((E)localObject3).B(), ((E)localObject3).A()));
      localObject4 = this.G.H((G)localObject2);
      this.G.C((G)localObject2, new E(-((E)localObject4).B(), ((E)localObject4).A()));
      ((R)localObject1).B();
    }
    localObject1 = new G._A(this.K, true);
    Object localObject2 = new G._A(this.K, false);
    this.G.A((Comparator)localObject1, (Comparator)localObject2);
  }
  
  void B(Q[] paramArrayOfQ)
  {
    Object localObject1 = this.G.M();
    while (((R)localObject1).C())
    {
      G localG = ((R)localObject1).I();
      this.G.G(localG);
      localObject2 = this.G.L(localG);
      E localE = this.G.H(localG);
      this.G.C(localG, (E)localObject2);
      this.G.D(localG, localE);
      ((R)localObject1).B();
    }
    localObject1 = new S(paramArrayOfQ);
    for (int i = 0; i < paramArrayOfQ.length; i++) {
      paramArrayOfQ[i] = ((Q)((S)localObject1).D());
    }
    G._A local_A = new G._A(this.K, true);
    Object localObject2 = new G._A(this.K, false);
    this.G.A(local_A, (Comparator)localObject2);
  }
  
  protected void A(twaver.base.A.D.E.E.C paramC, Q[] paramArrayOfQ)
  {
    int i = paramC.B();
    int j = paramC.A();
    this.K = new int[i];
    this.U = new O[i];
    this.L = new O[i];
    this.J = new O[i];
    this.N = new O[i];
    this.I = new O[i];
    this.Q = new double[4][i];
    this.T = new double[i];
    this.P = new double[i];
    this.M = new double[i];
    this.S = new boolean[i];
    this.R = new boolean[j];
    for (int k = 0; k < paramArrayOfQ.length; k++)
    {
      int m = 0;
      Object localObject = null;
      D localD = paramArrayOfQ[k].P();
      while (localD.C())
      {
        O localO = localD.H();
        int n = localO.F();
        this.K[n] = (m++);
        this.U[n] = localObject;
        this.L[n] = null;
        if (localObject != null) {
          this.L[localObject.F()] = localO;
        }
        localObject = localO;
        localD.B();
      }
    }
    G._A local_A1 = new G._A(this.K, true);
    G._A local_A2 = new G._A(this.K, false);
    paramC.A(local_A1, local_A2);
  }
  
  protected void A(twaver.base.A.D.E.E.C paramC, double[] paramArrayOfDouble)
  {
    D localD = paramC.J();
    while (localD.C())
    {
      O localO = localD.H();
      int i = localO.F();
      this.J[i] = localO;
      this.N[i] = localO;
      paramArrayOfDouble[i] = 1.7976931348623157E+308D;
      this.I[i] = localO;
      this.T[i] = 1.7976931348623157E+308D;
      this.S[i] = false;
      double tmp88_87 = 0.0D;
      this.P[i] = tmp88_87;
      this.M[i] = tmp88_87;
      localD.B();
    }
  }
  
  public static void A(Q[] paramArrayOfQ, twaver.base.A.D.E.E.K paramK, I paramI, int[] paramArrayOfInt)
  {
    int i = paramArrayOfQ.length;
    for (int j = 2; j < i - 1; j++)
    {
      int k = -1;
      int m = 0;
      int n = 0;
      D localD1 = paramArrayOfQ[j].P();
      D localD2 = paramArrayOfQ[j].P();
      while (localD2.C())
      {
        O localO1 = localD2.H();
        O localO2 = null;
        int i1 = 0;
        if (localO1.C() == 1)
        {
          localO2 = localO1.L().W();
          if ((paramI.D(localO2) != null) && (paramI.D(localO1) != null)) {
            i1 = 1;
          }
        }
        if ((n == paramArrayOfQ[j].size() - 1) || (i1 != 0))
        {
          int i2 = i1 != 0 ? paramArrayOfInt[localO2.F()] : paramArrayOfQ[(j - 1)].size();
          while (m <= n)
          {
            O localO3 = localD1.H();
            R localR = localO3.E();
            while (localR.C())
            {
              G localG = localR.I();
              int i3 = paramArrayOfInt[localG.W().F()];
              if ((i3 < k) || (i3 > i2)) {
                paramK.A(localR.I(), true);
              }
              localR.B();
            }
            localD1.B();
            m++;
          }
          k = i2;
        }
        n++;
        localD2.B();
      }
    }
  }
  
  public void C(Q[] paramArrayOfQ)
  {
    for (int i = 1; i < paramArrayOfQ.length; i++)
    {
      int j = -1;
      for (M localM = paramArrayOfQ[i].G(); localM != null; localM = localM.A())
      {
        O localO1 = (O)localM.B();
        int k = localO1.F();
        int m = localO1.C();
        if (m != 0)
        {
          int n = (int)Math.floor((m + 1.0D) / 2.0D);
          int i1 = (int)Math.ceil((m + 1.0D) / 2.0D);
          int i2 = 1;
          for (G localG = localO1.L(); i2 < n; localG = localG.S()) {
            i2++;
          }
          int i3 = 0;
          while ((i2 <= i1) && (i3 == 0))
          {
            twaver.base.A.D.E.D.K localK = this.G.M(localG);
            O localO2 = localG.W();
            int i4 = localO2.F();
            if ((this.N[k] == localO1) && (this.R[localG.U()] == 0) && (j < this.K[i4]))
            {
              j = this.K[i4];
              this.N[i4] = localO1;
              this.J[k] = this.J[i4];
              this.N[k] = this.J[k];
              i3 = 1;
              this.M[i4] = localK.D().B();
              this.P[k] = localK.C().B();
            }
            localG = localG.S();
            i2++;
          }
        }
      }
    }
  }
  
  protected void A(twaver.base.A.D.E.D.C paramC, double[] paramArrayOfDouble, Q[] paramArrayOfQ)
  {
    D localD1 = paramC.J();
    Object localObject;
    while (localD1.C())
    {
      localObject = localD1.H();
      int j = ((O)localObject).F();
      if (this.J[j] == localObject) {
        B(paramC, (O)localObject, paramArrayOfDouble);
      }
      localD1.B();
    }
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      localObject = paramArrayOfQ[i].P();
      if (((D)localObject).C())
      {
        O localO = paramArrayOfQ[i].P().H();
        int m = localO.F();
        if (this.I[this.J[m].F()] == localO) {
          A(paramC, localO, paramArrayOfDouble);
        }
      }
    }
    D localD2 = paramC.J();
    while (localD2.C())
    {
      localObject = localD2.H();
      int k = ((O)localObject).F();
      double d = this.T[this.I[this.J[k].F()].F()];
      if (d < 1.7976931348623157E+308D) {
        paramArrayOfDouble[k] += d;
      }
      localD2.B();
    }
  }
  
  protected void B(twaver.base.A.D.E.D.C paramC, O paramO, double[] paramArrayOfDouble)
  {
    int i = paramO.F();
    if (paramArrayOfDouble[i] == 1.7976931348623157E+308D)
    {
      paramArrayOfDouble[i] = 0.0D;
      O localO1 = paramO;
      double d = 0.0D;
      int j;
      do
      {
        j = localO1.F();
        if (j != i) {
          d -= this.P[j];
        }
        if (this.K[j] > 0)
        {
          O localO2 = this.U[j];
          O localO3 = this.J[this.U[j].F()];
          int k = localO3.F();
          B(paramC, localO3, paramArrayOfDouble);
          if (this.I[i] == paramO) {
            this.I[i] = this.I[k];
          }
          if (this.I[i] == this.I[k]) {
            paramArrayOfDouble[i] = Math.max(paramArrayOfDouble[i], paramArrayOfDouble[localO2.F()] + A(paramC, localO2, localO1) - d);
          }
        }
        d += this.M[j];
        localO1 = this.N[j];
      } while (localO1 != paramO);
      d = 0.0D;
      localO1 = paramO;
      do
      {
        j = localO1.F();
        if (j != i) {
          d -= this.P[j];
        }
        paramArrayOfDouble[i] += d;
        d += this.M[j];
        localO1 = this.N[j];
      } while (localO1 != paramO);
    }
  }
  
  protected void A(twaver.base.A.D.E.D.C paramC, O paramO, double[] paramArrayOfDouble)
  {
    int i = paramO.F();
    if (this.S[i] != 0) {
      return;
    }
    this.S[i] = true;
    O localO1 = paramO;
    do
    {
      int j = localO1.F();
      O localO2 = this.L[j];
      if (localO2 != null)
      {
        int k = localO2.F();
        O localO3 = this.I[this.J[k].F()];
        if (localO3 != this.I[i])
        {
          double d = paramArrayOfDouble[k] - paramArrayOfDouble[i] - A(paramC, localO1, localO2);
          if (this.T[localO3.F()] != 1.7976931348623157E+308D) {
            d += this.T[localO3.F()];
          }
          this.T[this.I[i].F()] = Math.min(this.T[this.I[i].F()], d);
        }
        else
        {
          A(paramC, this.J[k], paramArrayOfDouble);
        }
      }
      localO1 = this.N[j];
    } while (localO1 != paramO);
  }
  
  protected void A(twaver.base.A.D.E.D.C paramC)
  {
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    D localD = paramC.J();
    O localO;
    int i;
    while (localD.C())
    {
      localO = localD.H();
      i = localO.F();
      arrayOfDouble2[0] += this.Q[0][i];
      arrayOfDouble2[1] += this.Q[1][i];
      arrayOfDouble2[2] += this.Q[2][i];
      arrayOfDouble2[3] += this.Q[3][i];
      localD.B();
    }
    arrayOfDouble2[0] /= paramC.C();
    arrayOfDouble2[1] /= paramC.C();
    arrayOfDouble2[2] /= paramC.C();
    arrayOfDouble2[3] /= paramC.C();
    localD = paramC.J();
    while (localD.C())
    {
      localO = localD.H();
      i = localO.F();
      E localE = paramC.N(localO);
      arrayOfDouble1[0] = (this.Q[0][i] - arrayOfDouble2[0]);
      arrayOfDouble1[1] = (this.Q[1][i] - arrayOfDouble2[1]);
      arrayOfDouble1[2] = (this.Q[2][i] - arrayOfDouble2[2]);
      arrayOfDouble1[3] = (this.Q[3][i] - arrayOfDouble2[3]);
      Arrays.sort(arrayOfDouble1);
      double d = (arrayOfDouble1[1] + arrayOfDouble1[2]) / 2.0D;
      paramC.B(localO, new E(d, localE.A()));
      localD.B();
    }
  }
  
  protected double A(twaver.base.A.D.E.D.C paramC, O paramO1, O paramO2)
  {
    double d1 = paramC.L(paramO1);
    double d2 = paramC.L(paramO2);
    double d3;
    if ((d1 > 1.0D) && (d2 > 1.0D)) {
      d3 = this.C + (d1 + d2) / 2.0D;
    } else {
      d3 = this.E + (d1 + d2) / 2.0D;
    }
    if (this.K[paramO1.F()] < this.K[paramO2.F()])
    {
      if (this.V != null) {
        d3 += this.V.C(paramO2);
      }
      if (this.O != null) {
        d3 += this.O.C(paramO1);
      }
    }
    else
    {
      if (this.V != null) {
        d3 += this.V.C(paramO1);
      }
      if (this.O != null) {
        d3 += this.O.C(paramO2);
      }
    }
    return d3;
  }
  
  protected void B()
  {
    this.K = null;
    this.U = null;
    this.L = null;
    this.R = null;
    this.J = null;
    this.N = null;
    this.Q = null;
    this.T = null;
    this.I = null;
    this.S = null;
    this.M = null;
    this.P = null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.H
 * JD-Core Version:    0.7.0.1
 */
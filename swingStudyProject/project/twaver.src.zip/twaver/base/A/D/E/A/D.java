package twaver.base.A.D.E.A;

import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.D.K;
import twaver.base.A.D.E.E.S;

public abstract class D
  implements K
{
  private G E;
  private G F;
  protected S D;
  
  public D()
  {
    K();
    A(new G());
    B(new G());
  }
  
  public D(D paramD)
  {
    K();
    A(paramD.H().B());
    B(paramD.I().B());
  }
  
  public D E()
  {
    return A(this);
  }
  
  public abstract D A(D paramD);
  
  private void K()
  {
    this.D = new S();
  }
  
  public void A(G paramG)
  {
    paramG.A(this);
    this.E = paramG;
  }
  
  public void B(G paramG)
  {
    paramG.A(this);
    this.F = paramG;
  }
  
  public G H()
  {
    return this.E;
  }
  
  public G I()
  {
    return this.F;
  }
  
  public abstract A A(double paramDouble1, double paramDouble2, A paramA);
  
  public abstract void A(A paramA1, A paramA2);
  
  public A B(double paramDouble1, double paramDouble2)
  {
    return A(paramDouble1, paramDouble2, F());
  }
  
  public int G()
  {
    return this.D.size();
  }
  
  public A B(int paramInt)
  {
    return (A)this.D.A(paramInt);
  }
  
  public A F()
  {
    if (this.D.size() == 0) {
      return null;
    }
    return (A)this.D.H();
  }
  
  public void J()
  {
    this.D.clear();
  }
  
  public E A(int paramInt)
  {
    A localA = B(paramInt);
    if (localA != null) {
      return new E(localA.B(), localA.A());
    }
    return null;
  }
  
  public int B()
  {
    return G();
  }
  
  public E D()
  {
    G localG = H();
    return new E(localG.C(), localG.A());
  }
  
  public E C()
  {
    G localG = I();
    return new E(localG.C(), localG.A());
  }
  
  public void B(E paramE)
  {
    H().A(paramE.B(), paramE.A());
  }
  
  public void A(E paramE)
  {
    I().A(paramE.B(), paramE.A());
  }
  
  public void A(int paramInt, double paramDouble1, double paramDouble2)
  {
    A localA = B(paramInt);
    if (localA != null) {
      localA.A(paramDouble1, paramDouble2);
    }
  }
  
  public void A(double paramDouble1, double paramDouble2)
  {
    B(paramDouble1, paramDouble2);
  }
  
  public void A()
  {
    J();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.D
 * JD-Core Version:    0.7.0.1
 */
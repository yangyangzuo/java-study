package twaver.base.A.D.E.A;

public class G
{
  protected double A;
  protected double C;
  protected D B;
  
  public G()
  {
    this(0.0D, 0.0D);
  }
  
  public G(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.C = paramDouble2;
  }
  
  public G B()
  {
    return new G(this.A, this.C);
  }
  
  void A(D paramD)
  {
    this.B = paramD;
  }
  
  public double C()
  {
    return this.A;
  }
  
  public double A()
  {
    return this.C;
  }
  
  public void A(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.C = paramDouble2;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.G
 * JD-Core Version:    0.7.0.1
 */
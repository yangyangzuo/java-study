package twaver.base.A.D.E.D.C;

import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.E.A;

public abstract interface I
{
  public abstract int A(C paramC, twaver.base.A.D.E.E.I paramI, A paramA);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.I
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

public abstract interface M
{
  public abstract double C();
  
  public abstract double A();
  
  public abstract double B();
  
  public abstract double D();
  
  public abstract void A(double paramDouble1, double paramDouble2);
  
  public abstract void B(double paramDouble1, double paramDouble2);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.M
 * JD-Core Version:    0.7.0.1
 */
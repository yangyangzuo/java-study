package twaver.base.A.D.E;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Shape;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.base.A.D.E.A.I;
import twaver.base.A.D.E.E.O;
import twaver.network.TNetwork;
import twaver.network.ui.ElementUI;
import twaver.network.ui.GroupUI;

class C
  extends I
{
  private Map P = new HashMap();
  
  public Map T()
  {
    return this.P;
  }
  
  public O E(Object paramObject)
  {
    return (O)this.P.get(paramObject);
  }
  
  public C(TNetwork paramTNetwork, Iterator paramIterator, Generator paramGenerator, int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    Object localObject1;
    Object localObject2;
    Object localObject3;
    while (paramIterator.hasNext())
    {
      Element localElement = (Element)paramIterator.next();
      if ((localElement instanceof Link))
      {
        localLinkedList.add(localElement);
      }
      else
      {
        localObject1 = null;
        if ((localElement instanceof Group)) {
          ((Group)localElement).setExpand(true);
        }
        if ((paramTNetwork != null) && ((localElement instanceof Group)))
        {
          localObject2 = (GroupUI)paramTNetwork.getElementUI(localElement);
          if (paramTNetwork.isConsiderAttachmentOnLayout()) {
            localObject1 = ((GroupUI)localObject2).getUIBounds();
          } else {
            localObject1 = ((GroupUI)localObject2).getShape().getBounds();
          }
        }
        else if ((paramTNetwork != null) && (paramTNetwork.isConsiderAttachmentOnLayout()))
        {
          localObject1 = paramTNetwork.getElementUI(localElement).getUIBounds();
        }
        else
        {
          localObject1 = localElement.getBounds();
        }
        if ((localElement instanceof Group)) {
          ((Group)localElement).setExpand(false);
        }
        if (localObject1 != null)
        {
          localObject2 = I();
          localObject3 = null;
          if (paramGenerator != null) {
            localObject3 = (Dimension)paramGenerator.generate(localElement);
          }
          if (localObject3 != null)
          {
            if ((paramInt == 6) || (paramInt == 5)) {
              C((O)localObject2, ((Dimension)localObject3).height, ((Dimension)localObject3).width);
            } else {
              C((O)localObject2, ((Dimension)localObject3).width, ((Dimension)localObject3).height);
            }
          }
          else if ((paramInt == 6) || (paramInt == 5)) {
            C((O)localObject2, ((Rectangle)localObject1).height, ((Rectangle)localObject1).width);
          } else {
            C((O)localObject2, ((Rectangle)localObject1).width, ((Rectangle)localObject1).height);
          }
          this.P.put(localElement, localObject2);
        }
      }
    }
    for (int i = 0; i < localLinkedList.size(); i++)
    {
      localObject1 = (Link)localLinkedList.get(i);
      localObject2 = ((Link)localObject1).getFromAgent();
      localObject3 = ((Link)localObject1).getToAgent();
      O localO1 = (O)this.P.get(localObject2);
      O localO2 = (O)this.P.get(localObject3);
      if ((localO1 != null) && (localO2 != null) && (localO1 != localO2)) {
        A(localO1, localO2);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C
 * JD-Core Version:    0.7.0.1
 */
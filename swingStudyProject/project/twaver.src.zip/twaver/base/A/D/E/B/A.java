package twaver.base.A.D.E.B;

import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;

public class A
{
  public static I A(double[] paramArrayOfDouble)
  {
    return new _A(paramArrayOfDouble, null, null, null);
  }
  
  public static I A(int[] paramArrayOfInt)
  {
    return new _A(null, paramArrayOfInt, null, null);
  }
  
  public static I B(boolean[] paramArrayOfBoolean)
  {
    return new _A(null, null, paramArrayOfBoolean, null);
  }
  
  public static K B(int[] paramArrayOfInt)
  {
    return new _B(null, paramArrayOfInt, null, null);
  }
  
  public static K A(boolean[] paramArrayOfBoolean)
  {
    return new _B(null, null, paramArrayOfBoolean, null);
  }
  
  public static K A(Object[] paramArrayOfObject)
  {
    return new _B(null, null, null, paramArrayOfObject);
  }
  
  private static final class _B
    implements K
  {
    double[] D;
    int[] C;
    boolean[] E;
    Object[] F;
    
    public Object D(Object paramObject)
    {
      return this.F[((twaver.base.A.D.E.E.G)paramObject).U()];
    }
    
    public double C(Object paramObject)
    {
      return this.D[((twaver.base.A.D.E.E.G)paramObject).U()];
    }
    
    public int A(Object paramObject)
    {
      return this.C[((twaver.base.A.D.E.E.G)paramObject).U()];
    }
    
    public boolean B(Object paramObject)
    {
      return this.E[((twaver.base.A.D.E.E.G)paramObject).U()];
    }
    
    public void A(Object paramObject1, Object paramObject2)
    {
      this.F[((twaver.base.A.D.E.E.G)paramObject1).U()] = paramObject2;
    }
    
    public void A(Object paramObject, double paramDouble)
    {
      this.D[((twaver.base.A.D.E.E.G)paramObject).U()] = paramDouble;
    }
    
    public void A(Object paramObject, int paramInt)
    {
      this.C[((twaver.base.A.D.E.E.G)paramObject).U()] = paramInt;
    }
    
    public void A(Object paramObject, boolean paramBoolean)
    {
      this.E[((twaver.base.A.D.E.E.G)paramObject).U()] = paramBoolean;
    }
    
    _B(double[] paramArrayOfDouble, int[] paramArrayOfInt, boolean[] paramArrayOfBoolean, Object[] paramArrayOfObject)
    {
      this.D = paramArrayOfDouble;
      this.C = paramArrayOfInt;
      this.E = paramArrayOfBoolean;
      this.F = paramArrayOfObject;
    }
  }
  
  static final class _A
    implements I
  {
    double[] M;
    int[] P;
    boolean[] N;
    Object[] O;
    
    public Object D(Object paramObject)
    {
      return this.O[((twaver.base.A.D.E.E.O)paramObject).F()];
    }
    
    public double C(Object paramObject)
    {
      return this.M[((twaver.base.A.D.E.E.O)paramObject).F()];
    }
    
    public int A(Object paramObject)
    {
      return this.P[((twaver.base.A.D.E.E.O)paramObject).F()];
    }
    
    public boolean B(Object paramObject)
    {
      return this.N[((twaver.base.A.D.E.E.O)paramObject).F()];
    }
    
    public void B(Object paramObject1, Object paramObject2)
    {
      this.O[((twaver.base.A.D.E.E.O)paramObject1).F()] = paramObject2;
    }
    
    public void B(Object paramObject, double paramDouble)
    {
      this.M[((twaver.base.A.D.E.E.O)paramObject).F()] = paramDouble;
    }
    
    public void B(Object paramObject, int paramInt)
    {
      this.P[((twaver.base.A.D.E.E.O)paramObject).F()] = paramInt;
    }
    
    public void B(Object paramObject, boolean paramBoolean)
    {
      this.N[((twaver.base.A.D.E.E.O)paramObject).F()] = paramBoolean;
    }
    
    _A(double[] paramArrayOfDouble, int[] paramArrayOfInt, boolean[] paramArrayOfBoolean, Object[] paramArrayOfObject)
    {
      this.M = paramArrayOfDouble;
      this.P = paramArrayOfInt;
      this.N = paramArrayOfBoolean;
      this.O = paramArrayOfObject;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.A
 * JD-Core Version:    0.7.0.1
 */
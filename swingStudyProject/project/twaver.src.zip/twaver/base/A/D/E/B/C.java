package twaver.base.A.D.E.B;

import java.util.Comparator;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.L;
import twaver.base.A.D.E.E.O;

public class C
{
  public static Comparator B(L paramL)
  {
    return new _B(paramL);
  }
  
  public static Comparator A(L paramL)
  {
    return new _A(paramL);
  }
  
  private static class _B
    implements Comparator
  {
    L A;
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      O localO1 = ((G)paramObject1).W();
      O localO2 = ((G)paramObject2).W();
      double d = this.A.C(localO1) - this.A.C(localO2);
      return d <= 0.0D ? -1 : d >= 0.0D ? 0 : 1;
    }
    
    public _B(L paramL)
    {
      this.A = paramL;
    }
  }
  
  private static class _A
    implements Comparator
  {
    L A;
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      O localO1 = ((G)paramObject1).T();
      O localO2 = ((G)paramObject2).T();
      double d = this.A.C(localO1) - this.A.C(localO2);
      return d <= 0.0D ? -1 : d >= 0.0D ? 0 : 1;
    }
    
    public _A(L paramL)
    {
      this.A = paramL;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.C
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

public abstract class H
  implements N
{
  private B A;
  
  public void A(B paramB)
  {
    this.A = paramB;
  }
  
  public B A()
  {
    return this.A;
  }
  
  protected void D(C paramC)
  {
    if (this.A != null) {
      this.A.A(paramC);
    }
  }
  
  protected boolean C(C paramC)
  {
    if (this.A != null) {
      return this.A.B(paramC);
    }
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.H
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.A;

import twaver.base.A.D.E.E.S;

public class B
  extends D
{
  public B() {}
  
  public B(D paramD)
  {
    super(paramD);
  }
  
  public D A(D paramD)
  {
    B localB = new B(paramD);
    return localB;
  }
  
  public A A(double paramDouble1, double paramDouble2, A paramA)
  {
    A localA = new A(paramDouble1, paramDouble2);
    A(localA, paramA);
    return localA;
  }
  
  public void A(A paramA1, A paramA2)
  {
    this.D.B(paramA1, this.D.E(paramA2));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.B
 * JD-Core Version:    0.7.0.1
 */
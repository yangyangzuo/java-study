package twaver.base.A.D.E.E;

public abstract interface L
{
  public abstract Object D(Object paramObject);
  
  public abstract int A(Object paramObject);
  
  public abstract double C(Object paramObject);
  
  public abstract boolean B(Object paramObject);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.L
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

public abstract interface N
  extends B
{
  public abstract void A(B paramB);
  
  public abstract B A();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.N
 * JD-Core Version:    0.7.0.1
 */
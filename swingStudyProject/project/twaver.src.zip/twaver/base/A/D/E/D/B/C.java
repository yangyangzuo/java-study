package twaver.base.A.D.E.D.B;

import java.awt.Rectangle;
import java.util.Comparator;
import twaver.base.A.D.E.D.L;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;

public class C
  extends twaver.base.A.D.E.D.E
{
  private twaver.base.A.D.E.D.C _;
  private E a = new E();
  private A b = new A();
  
  public boolean M(twaver.base.A.D.E.D.C paramC)
  {
    return true;
  }
  
  public void N(twaver.base.A.D.E.D.C paramC)
  {
    if (paramC.B() < 2) {
      return;
    }
    this._ = paramC;
    L.A(this._);
    L.B(this._);
    D localD = new D(this._);
    localD.R();
    localD.S();
    twaver.base.A.D.E.B.F localF = new twaver.base.A.D.E.B.F(this._);
    localF.D();
    Object localObject1 = localD.J();
    Object localObject5;
    while (((twaver.base.A.D.E.E.D)localObject1).C())
    {
      localObject2 = ((twaver.base.A.D.E.E.D)localObject1).H();
      localObject3 = localD.T((O)localObject2);
      if (((Q)localObject3).size() > 1)
      {
        localObject4 = localD.S((O)localObject2);
        twaver.base.A.D.E.B.F.B(this._, ((twaver.base.A.D.E.E.A)localObject4).J());
        this.a.N(this._);
        localObject5 = this._.N();
        localD.C((O)localObject2, ((Rectangle)localObject5).getWidth(), ((Rectangle)localObject5).getHeight());
      }
      else if (((Q)localObject3).size() == 1)
      {
        localObject4 = ((Q)localObject3).O();
        localD.A((O)localObject2, this._.R((O)localObject4));
        this._.A((O)localObject4, 0.0D, 0.0D);
      }
      else
      {
        localD.C((O)localObject2, 1.0D, 1.0D);
      }
      twaver.base.A.D.E.B.F.A(this._, this._.M());
      ((twaver.base.A.D.E.E.D)localObject1).B();
    }
    localF.B();
    localObject1 = A(localD);
    twaver.base.A.D.E.F.F.A(localD, (O)localObject1);
    Object localObject2 = localD.H();
    Object localObject3 = localD.F();
    A(localD, (K)localObject3, (I)localObject2);
    A(localD, (K)localObject3);
    A(localD, (O)localObject1, (K)localObject3);
    this.b.A((K)localObject3, (I)localObject2);
    this.b.N(localD);
    A(localD, (O)localObject1, (I)localObject2);
    Object localObject4 = localD.J();
    while (((twaver.base.A.D.E.E.D)localObject4).C())
    {
      localObject5 = ((twaver.base.A.D.E.E.D)localObject4).H();
      twaver.base.A.D.E.C.E localE = localD.N((O)localObject5);
      twaver.base.A.D.E.E.D localD1 = localD.T((O)localObject5).P();
      while (localD1.C())
      {
        O localO = localD1.H();
        this._.A(localO, localE.B() + this._.K(localO), localE.A() + this._.H(localO));
        localD1.B();
      }
      ((twaver.base.A.D.E.E.D)localObject4).B();
    }
  }
  
  O A(D paramD)
  {
    int i = -1;
    Object localObject = null;
    twaver.base.A.D.E.E.D localD = paramD.J();
    while (localD.C())
    {
      O localO = localD.H();
      if (paramD.T(localO).size() > i)
      {
        localObject = localO;
        i = paramD.T(localO).size();
      }
      localD.B();
    }
    return localObject;
  }
  
  void A(twaver.base.A.D.E.E.C paramC, K paramK)
  {
    _A local_A = new _A(paramK);
    twaver.base.A.D.E.E.D localD = paramC.J();
    while (localD.C())
    {
      localD.H().A(local_A);
      localD.B();
    }
  }
  
  void A(D paramD, K paramK, I paramI)
  {
    int[] arrayOfInt = new int[this._.B()];
    Object localObject = paramD.J();
    while (((twaver.base.A.D.E.E.D)localObject).C())
    {
      O localO1 = ((twaver.base.A.D.E.E.D)localObject).H();
      Q localQ = paramD.T(localO1);
      twaver.base.A.D.E.E.D localD = localQ.P();
      while (localD.C())
      {
        O localO2 = localD.H();
        arrayOfInt[localO2.F()] = localO1.F();
        localD.B();
      }
      ((twaver.base.A.D.E.E.D)localObject).B();
    }
    localObject = twaver.base.A.D.E.F.F.C(paramD);
    A(paramD, (O)localObject, arrayOfInt, paramK, paramI);
  }
  
  void A(D paramD, O paramO, K paramK)
  {
    if (paramD.T(paramO).size() > 1)
    {
      double d1 = 0.0D;
      double d2 = 0.0D;
      double d3 = 0.0D;
      R localR = paramO.I();
      G localG;
      double d4;
      while (localR.C())
      {
        localG = localR.I();
        d4 = paramK.C(localG);
        if (d4 - d1 > d2)
        {
          d2 = d4 - d1;
          d3 = (d1 + d4) / 2.0D;
        }
        d1 = d4;
        localR.B();
      }
      if (360.0D - d1 > d2) {
        d3 = (360.0D + d1) / 2.0D;
      }
      A(paramD, paramO, d3);
      localR = paramO.I();
      while (localR.C())
      {
        localG = localR.I();
        d4 = paramK.C(localG);
        for (d4 -= d3; d4 < 0.0D; d4 += 360.0D) {}
        paramK.A(localG, d4);
        localR.B();
      }
      paramO.A(new _A(paramK));
    }
  }
  
  void A(D paramD, O paramO, int[] paramArrayOfInt, K paramK, I paramI)
  {
    int i = paramO.F();
    double d1 = paramI.C(paramO);
    R localR1 = paramO.I();
    while (localR1.C())
    {
      G localG1 = localR1.I();
      twaver.base.A.D.E.E.A localA = paramD.Q(localG1);
      double d2 = 0.0D;
      double d3 = 0.0D;
      double d4 = 0.0D;
      double d5 = 0.0D;
      R localR2 = localA.J();
      while (localR2.C())
      {
        G localG2 = localR2.I();
        O localO1 = null;
        O localO2 = null;
        if (paramArrayOfInt[localG2.W().F()] == i)
        {
          localO1 = localG2.W();
          localO2 = localG2.T();
        }
        else
        {
          localO1 = localG2.T();
          localO2 = localG2.W();
        }
        d4 -= this._.K(localO1);
        d5 += this._.H(localO1);
        d2 -= this._.K(localO2);
        d3 += this._.H(localO2);
        localR2.B();
      }
      double d6;
      if ((d4 != 0.0D) || (d5 != 0.0D))
      {
        for (d6 = Math.toDegrees(Math.atan2(d5, d4)) - d1; d6 < 0.0D; d6 += 360.0D) {}
        paramK.A(localG1, d6);
      }
      if ((d2 != 0.0D) && (d3 != 0.0D))
      {
        d6 = Math.toDegrees(Math.atan2(d3, d2));
        if (d6 < 0.0D) {
          d6 += 360.0D;
        }
        paramI.B(localG1.T(), d6);
      }
      A(paramD, localG1.T(), paramArrayOfInt, paramK, paramI);
      localR1.B();
    }
  }
  
  void A(D paramD, O paramO, I paramI)
  {
    twaver.base.A.D.E.C.E localE1 = paramD.N(paramO);
    R localR = paramO.I();
    while (localR.C())
    {
      G localG = localR.I();
      O localO = localG.T();
      twaver.base.A.D.E.C.E localE2 = paramD.N(localO);
      double d1 = localE2.B() - localE1.B();
      double d2 = localE2.A() - localE1.A();
      double d3 = Math.toDegrees(Math.atan2(d2, d1));
      if (paramI.D(localO) != null)
      {
        double d4 = paramI.C(localO);
        d3 += d4;
      }
      A(paramD, localO, d3);
      A(paramD, localO, paramI);
      localR.B();
    }
  }
  
  void A(D paramD, O paramO, double paramDouble)
  {
    paramDouble = Math.toRadians(paramDouble);
    Q localQ = paramD.T(paramO);
    if (localQ.size() <= 1) {
      return;
    }
    twaver.base.A.D.E.E.D localD = localQ.P();
    while (localD.C())
    {
      O localO = localD.H();
      double d1 = this._.K(localO);
      double d2 = this._.H(localO);
      double d3 = Math.cos(paramDouble);
      double d4 = Math.sin(paramDouble);
      double d5 = d1 * d3 - d4 * d2;
      double d6 = d1 * d4 + d3 * d2;
      this._.A(localO, d5, d6);
      localD.B();
    }
  }
  
  class _A
    implements Comparator
  {
    K A;
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      G localG1 = (G)paramObject1;
      G localG2 = (G)paramObject2;
      double d = this.A.C(localG1) - this.A.C(localG2);
      if (d > 0.0D) {
        return 1;
      }
      return d >= 0.0D ? 0 : -1;
    }
    
    _A(K paramK)
    {
      this.A = paramK;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B.C
 * JD-Core Version:    0.7.0.1
 */
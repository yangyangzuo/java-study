package twaver.base.A.D.E;

import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.JComponent;
import twaver.Element;
import twaver.Generator;
import twaver.TDataBox;
import twaver.UndoRedoEvent;
import twaver.UndoRedoManager;
import twaver.animate.AnimateCenterLocation;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.D.C.N;
import twaver.base.A.D.E.E.O;
import twaver.network.TNetwork;

public class B
{
  private int I;
  private int E;
  private TNetwork D;
  private Iterator A;
  private int J;
  private boolean F;
  private Runnable C;
  private A B;
  private C G;
  private Map H = new HashMap();
  private Generator K = null;
  
  public static AffineTransform A(int paramInt)
  {
    AffineTransform localAffineTransform;
    if (paramInt == 6)
    {
      localAffineTransform = new AffineTransform();
      localAffineTransform.setTransform(1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
      localAffineTransform.rotate(1.570796326794897D);
      return localAffineTransform;
    }
    if (paramInt == 5)
    {
      localAffineTransform = new AffineTransform();
      localAffineTransform.setTransform(1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
      localAffineTransform.rotate(-1.570796326794897D);
      return localAffineTransform;
    }
    if (paramInt == 3)
    {
      localAffineTransform = new AffineTransform();
      localAffineTransform.setTransform(1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
      localAffineTransform.rotate(3.141592653589793D);
      return localAffineTransform;
    }
    return null;
  }
  
  public B(TNetwork paramTNetwork, Iterator paramIterator, int paramInt1, boolean paramBoolean, Runnable paramRunnable, int paramInt2, int paramInt3, Generator paramGenerator)
  {
    this.D = paramTNetwork;
    this.A = paramIterator;
    this.J = paramInt1;
    this.F = paramBoolean;
    this.C = paramRunnable;
    this.I = paramInt2;
    this.E = paramInt3;
    this.K = paramGenerator;
  }
  
  public boolean A()
  {
    twaver.base.A.D.E.D.B localB = B(this.J);
    if (localB == null) {
      return false;
    }
    this.B = new A(this.D, this.A, localB, this.J, this.K);
    this.A = this.B.B();
    this.G = new C(this.D, this.A, this.K, this.J);
    try
    {
      localB.A(this.G);
    }
    catch (Exception localException)
    {
      this.B.A();
      if (this.C != null) {
        this.C.run();
      }
      return false;
    }
    Iterator localIterator1 = this.G.T().keySet().iterator();
    while (localIterator1.hasNext())
    {
      localObject1 = (Element)localIterator1.next();
      O localO1 = this.G.E(localObject1);
      localObject2 = this.G.N(localO1);
      Point2D.Double localDouble1 = new Point2D.Double(((E)localObject2).A + this.I, ((E)localObject2).B + this.E);
      this.H.put(localObject1, localDouble1);
    }
    if ((this.J == 6) || (this.J == 5) || (this.J == 3))
    {
      localObject1 = A(this.J);
      double d1 = 1.7976931348623157E+308D;
      double d2 = 1.7976931348623157E+308D;
      Iterator localIterator3 = this.H.keySet().iterator();
      Element localElement;
      Point2D localPoint2D2;
      while (localIterator3.hasNext())
      {
        localElement = (Element)localIterator3.next();
        localPoint2D2 = (Point2D)this.H.get(localElement);
        Point2D.Double localDouble2 = new Point2D.Double(localPoint2D2.getX(), localPoint2D2.getY());
        Point2D.Double localDouble3 = new Point2D.Double();
        ((AffineTransform)localObject1).transform(localDouble2, localDouble3);
        localPoint2D2.setLocation(localDouble3);
        O localO2 = this.G.E(localElement);
        if ((this.J == 6) || (this.J == 5))
        {
          if (localDouble3.getX() - this.G.Q(localO2) / 2.0D < d1) {
            d1 = localDouble3.getX() - this.G.Q(localO2) / 2.0D;
          }
          if (localDouble3.getY() - this.G.L(localO2) / 2.0D < d2) {
            d2 = localDouble3.getY() - this.G.L(localO2) / 2.0D;
          }
        }
        else
        {
          if (localDouble3.getX() - this.G.L(localO2) / 2.0D < d1) {
            d1 = localDouble3.getX() - this.G.L(localO2) / 2.0D;
          }
          if (localDouble3.getY() - this.G.Q(localO2) / 2.0D < d2) {
            d2 = localDouble3.getY() - this.G.Q(localO2) / 2.0D;
          }
        }
      }
      localIterator3 = this.H.keySet().iterator();
      while (localIterator3.hasNext())
      {
        localElement = (Element)localIterator3.next();
        localPoint2D2 = (Point2D)this.H.get(localElement);
        localPoint2D2.setLocation(localPoint2D2.getX() - d1 + this.I, localPoint2D2.getY() - d2 + this.E);
      }
    }
    if (this.D != null) {
      this.D.getDataBox().getUndoRedoManager().setIgnorePropertyChange(true);
    }
    Object localObject1 = new HashMap();
    Iterator localIterator2 = this.H.keySet().iterator();
    while (localIterator2.hasNext())
    {
      localObject2 = (Element)localIterator2.next();
      ((Map)localObject1).put(localObject2, ((Element)localObject2).getCenterLocation());
    }
    if (!this.F)
    {
      localIterator2 = this.H.keySet().iterator();
      while (localIterator2.hasNext())
      {
        localObject2 = (Element)localIterator2.next();
        Point2D localPoint2D1 = (Point2D)this.H.get(localObject2);
        ((Element)localObject2).setCenterLocation(localPoint2D1.getX(), localPoint2D1.getY());
      }
      if (this.D != null)
      {
        this.D.getDataBox().getUndoRedoManager().setIgnorePropertyChange(false);
        this.D.getDataBox().getUndoRedoManager().addEvent(new UndoRedoEvent((Map)localObject1, this.H));
      }
      this.B.A();
      if (this.D != null)
      {
        this.D.adjustCanvasSize();
        this.D.getCanvas().repaint();
      }
      if (this.C != null) {
        this.C.run();
      }
      return true;
    }
    Object localObject2 = new AnimateCenterLocation(this.H, new Runnable()
    {
      private final Map val$oldLocations;
      
      public void run()
      {
        if (B.this.D != null)
        {
          B.this.D.getDataBox().getUndoRedoManager().setIgnorePropertyChange(false);
          B.this.D.getDataBox().getUndoRedoManager().addEvent(new UndoRedoEvent(this.val$oldLocations, B.this.H));
        }
        B.this.B.A();
        if (B.this.D != null)
        {
          B.this.D.adjustCanvasSize();
          B.this.D.getCanvas().repaint();
        }
        if (B.this.C != null) {
          B.this.C.run();
        }
      }
    });
    ((AnimateCenterLocation)localObject2).start();
    return true;
  }
  
  private static twaver.base.A.D.E.D.B B(int paramInt)
  {
    Object localObject;
    if (paramInt == 4)
    {
      localObject = new twaver.base.A.D.E.D.A();
      ((twaver.base.A.D.E.D.A)localObject).B(2.0D);
      return localObject;
    }
    if (paramInt == 1)
    {
      localObject = new twaver.base.A.D.E.D.B.C();
      return localObject;
    }
    if (paramInt == 7)
    {
      localObject = new N();
      return localObject;
    }
    if ((paramInt == 2) || (paramInt == 3) || (paramInt == 5) || (paramInt == 6))
    {
      localObject = new twaver.base.A.D.E.D.A.A();
      return localObject;
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B
 * JD-Core Version:    0.7.0.1
 */
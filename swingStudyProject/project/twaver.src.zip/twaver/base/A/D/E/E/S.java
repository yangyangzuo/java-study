package twaver.base.A.D.E.E;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import twaver.base.A.D.E.B.H;

public class S
  implements Collection
{
  private int A;
  private M C;
  private M B;
  
  public S() {}
  
  public S(F paramF)
  {
    paramF.E();
    while (paramF.C())
    {
      D(paramF.D());
      paramF.B();
    }
  }
  
  public S(Object[] paramArrayOfObject)
  {
    for (int i = 0; i < paramArrayOfObject.length; i++) {
      D(paramArrayOfObject[i]);
    }
  }
  
  public M A(Object paramObject)
  {
    M localM = B(paramObject);
    if (this.C == null)
    {
      this.C = (this.B = localM);
    }
    else
    {
      this.C.A = localM;
      localM.B = this.C;
      this.C = localM;
    }
    this.A += 1;
    return localM;
  }
  
  public M D(Object paramObject)
  {
    M localM = B(paramObject);
    if (this.B == null)
    {
      this.C = (this.B = localM);
    }
    else
    {
      this.B.B = localM;
      localM.A = this.B;
      this.B = localM;
    }
    this.A += 1;
    return localM;
  }
  
  public void B(M paramM)
  {
    paramM.A = null;
    paramM.B = null;
    if (this.B == null)
    {
      this.C = (this.B = paramM);
    }
    else
    {
      this.B.B = paramM;
      paramM.A = this.B;
      this.B = paramM;
    }
    this.A += 1;
  }
  
  public void C(M paramM)
  {
    paramM.A = null;
    paramM.B = null;
    if (this.C == null)
    {
      this.C = (this.B = paramM);
    }
    else
    {
      this.C.A = paramM;
      paramM.B = this.C;
      this.C = paramM;
    }
    this.A += 1;
  }
  
  public boolean add(Object paramObject)
  {
    D(paramObject);
    return true;
  }
  
  public boolean addAll(Collection paramCollection)
  {
    boolean bool = false;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext()) {
      if (add(localIterator.next())) {
        bool = true;
      }
    }
    return bool;
  }
  
  public void A(F paramF)
  {
    while (paramF.C())
    {
      D(paramF.D());
      paramF.B();
    }
  }
  
  public M A(Object paramObject, M paramM)
  {
    if (paramM == this.C) {
      return A(paramObject);
    }
    if (paramM == null) {
      return D(paramObject);
    }
    M localM = B(paramObject);
    B(localM, paramM);
    return localM;
  }
  
  public void B(M paramM1, M paramM2)
  {
    if (paramM2 == null)
    {
      C(paramM1);
    }
    else if (paramM2 == this.C)
    {
      C(paramM1);
    }
    else
    {
      if (this.B == null)
      {
        paramM1.A = null;
        paramM1.B = null;
        this.C = (this.B = paramM1);
      }
      else
      {
        M localM = paramM2.A;
        paramM2.A = paramM1;
        paramM1.B = paramM2;
        localM.B = paramM1;
        paramM1.A = localM;
      }
      this.A += 1;
    }
  }
  
  public void A(M paramM1, M paramM2)
  {
    if (paramM2 == null)
    {
      B(paramM1);
    }
    else if (paramM2 == this.B)
    {
      B(paramM1);
    }
    else
    {
      if (this.C == null)
      {
        paramM1.A = null;
        paramM1.B = null;
        this.C = (this.B = paramM1);
      }
      else
      {
        M localM = paramM2.B;
        paramM2.B = paramM1;
        paramM1.B = localM;
        localM.A = paramM1;
        paramM1.A = paramM2;
      }
      this.A += 1;
    }
  }
  
  public M B(Object paramObject, M paramM)
  {
    if (paramM == this.B) {
      return D(paramObject);
    }
    if (paramM == null) {
      return A(paramObject);
    }
    M localM = B(paramObject);
    A(localM, paramM);
    return localM;
  }
  
  public int size()
  {
    return this.A;
  }
  
  public boolean isEmpty()
  {
    return this.A == 0;
  }
  
  public void clear()
  {
    this.C = (this.B = null);
    this.A = 0;
  }
  
  public Object E()
  {
    return this.C.C;
  }
  
  public Object A()
  {
    Object localObject = E();
    F(G());
    return localObject;
  }
  
  public M C(Object paramObject)
  {
    return A(paramObject);
  }
  
  public Object H()
  {
    return this.B.C;
  }
  
  public Object D()
  {
    return F(this.B);
  }
  
  public Object A(int paramInt)
  {
    int i = 0;
    M localM = this.C;
    while (localM != null)
    {
      if (paramInt == i) {
        return localM.C;
      }
      localM = localM.B;
      i++;
    }
    return null;
  }
  
  public M G()
  {
    return this.C;
  }
  
  public M I()
  {
    return this.B;
  }
  
  public M E(M paramM)
  {
    if (paramM.B == null) {
      return this.C;
    }
    return paramM.B;
  }
  
  public M D(M paramM)
  {
    if (paramM.A == null) {
      return this.B;
    }
    return paramM.A;
  }
  
  public Object A(M paramM)
  {
    return paramM.C;
  }
  
  public boolean remove(Object paramObject)
  {
    M localM = E(paramObject);
    if (localM != null)
    {
      F(localM);
      return true;
    }
    return false;
  }
  
  public boolean removeAll(Collection paramCollection)
  {
    int i = size();
    HashSet localHashSet = new HashSet(paramCollection);
    for (M localM = G(); localM != null; localM = localM.A()) {
      if (localHashSet.contains(localM.B())) {
        F(localM);
      }
    }
    return i != size();
  }
  
  public boolean retainAll(Collection paramCollection)
  {
    int i = size();
    HashSet localHashSet = new HashSet(paramCollection);
    for (M localM = G(); localM != null; localM = localM.A()) {
      if (!localHashSet.contains(localM.B())) {
        F(localM);
      }
    }
    return i != size();
  }
  
  public Object F(M paramM)
  {
    if (paramM != this.C) {
      paramM.A.B = paramM.B;
    } else {
      this.C = paramM.B;
    }
    if (paramM != this.B) {
      paramM.B.A = paramM.A;
    } else {
      this.B = paramM.A;
    }
    this.A -= 1;
    return paramM.C;
  }
  
  public Object B(F paramF)
  {
    return F(((_A)paramF).A);
  }
  
  public F F()
  {
    return new _A();
  }
  
  public Iterator iterator()
  {
    return H.A(F());
  }
  
  public boolean contains(Object paramObject)
  {
    return E(paramObject) != null;
  }
  
  public boolean containsAll(Collection paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (!contains(localObject)) {
        return false;
      }
    }
    return true;
  }
  
  public M E(Object paramObject)
  {
    for (M localM = this.C; localM != null; localM = localM.B)
    {
      if ((localM.C == null) && (paramObject == null)) {
        return localM;
      }
      if (localM.C.equals(paramObject)) {
        return localM;
      }
    }
    return null;
  }
  
  public Object[] toArray()
  {
    Object[] arrayOfObject = new Object[size()];
    int i = 0;
    M localM = this.C;
    while (localM != null)
    {
      arrayOfObject[i] = localM.C;
      localM = localM.B;
      i++;
    }
    return arrayOfObject;
  }
  
  public Object[] toArray(Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject.length < this.A) {
      paramArrayOfObject = (Object[])Array.newInstance(paramArrayOfObject.getClass().getComponentType(), this.A);
    }
    int i = 0;
    for (M localM = this.C; localM != null; localM = localM.B) {
      paramArrayOfObject[(i++)] = localM.C;
    }
    return paramArrayOfObject;
  }
  
  public void C()
  {
    for (M localM1 = this.C; localM1 != null; localM1 = localM1.A)
    {
      M localM2 = localM1.B;
      localM1.B = localM1.A;
      localM1.A = localM2;
    }
    localM1 = this.C;
    this.C = this.B;
    this.B = localM1;
  }
  
  public void A(Comparator paramComparator)
  {
    Object[] arrayOfObject = toArray();
    Arrays.sort(arrayOfObject, paramComparator);
    int i = 0;
    M localM = this.C;
    while (localM != null)
    {
      localM.C = arrayOfObject[i];
      localM = localM.B;
      i++;
    }
  }
  
  public void B()
  {
    Object[] arrayOfObject = toArray();
    Arrays.sort(arrayOfObject);
    int i = 0;
    M localM = this.C;
    while (localM != null)
    {
      localM.C = arrayOfObject[i];
      localM = localM.B;
      i++;
    }
  }
  
  public void A(S paramS)
  {
    if (this.C == null)
    {
      this.C = paramS.C;
      this.B = paramS.B;
    }
    else if (paramS.C != null)
    {
      this.B.B = paramS.C;
      paramS.C.A = this.B;
      this.B = paramS.B;
    }
    this.A += paramS.A;
    paramS.C = (paramS.B = null);
    paramS.A = 0;
  }
  
  private M B(Object paramObject)
  {
    return new M(paramObject);
  }
  
  public class _A
    implements F
  {
    M A;
    
    public boolean C()
    {
      return this.A != null;
    }
    
    public void B()
    {
      this.A = this.A.B;
    }
    
    public void G()
    {
      this.A = this.A.A;
    }
    
    public void E()
    {
      this.A = S.this.G();
    }
    
    public void A()
    {
      this.A = S.this.I();
    }
    
    public int F()
    {
      return S.this.size();
    }
    
    public Object D()
    {
      return this.A.C;
    }
    
    protected _A()
    {
      E();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.S
 * JD-Core Version:    0.7.0.1
 */
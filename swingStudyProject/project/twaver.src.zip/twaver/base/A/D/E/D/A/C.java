package twaver.base.A.D.E.D.A;

import java.util.Arrays;
import java.util.Comparator;
import twaver.base.A.D.E.D.L;
import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

public class C
  extends twaver.base.A.D.E.D.E
{
  private double T = 340.0D;
  private double S = 360.0D;
  private double V = 40.0D;
  private double Q = 0.5D;
  private _B[] R;
  protected twaver.base.A.D.E.D.C U;
  
  public int D()
  {
    return (int)this.S;
  }
  
  public int F()
  {
    return (int)this.T;
  }
  
  public double C()
  {
    return this.Q;
  }
  
  public void N(twaver.base.A.D.E.D.C paramC)
  {
    if (!twaver.base.A.D.E.F.F.D(paramC)) {
      throw new IllegalArgumentException();
    }
    this.U = paramC;
    O localO1 = E();
    A localA = twaver.base.A.D.E.F.F.A(paramC, localO1);
    L.A(paramC);
    this.R = new _B[paramC.B()];
    Object localObject = paramC.J();
    while (((D)localObject).C())
    {
      O localO2 = ((D)localObject).H();
      if (localO2 != localO1) {
        A(localO2, new _B(this.V + A(localO2.H().H())));
      } else {
        A(localO2, new _B(this.V));
      }
      ((D)localObject).B();
    }
    J(localO1);
    paramC.A(localO1, 0.0D, 0.0D);
    D(localO1);
    while (!localA.isEmpty())
    {
      localObject = localA.K();
      paramC.G((G)localObject);
    }
  }
  
  public boolean M(twaver.base.A.D.E.D.C paramC)
  {
    return twaver.base.A.D.E.F.F.D(paramC);
  }
  
  protected _B B(O paramO)
  {
    return this.R[paramO.F()];
  }
  
  protected O E()
  {
    return twaver.base.A.D.E.F.F.C(this.U);
  }
  
  protected void H(O paramO)
  {
    double d1 = E(paramO);
    for (;;)
    {
      d2 = C(paramO);
      if (d2 <= d1) {
        break;
      }
      D localD1 = paramO.J();
      while (localD1.C())
      {
        O localO = localD1.H();
        B(localO).E *= (1.0D + this.Q);
        localD1.B();
      }
    }
    double d3 = (d1 - d2) / (2 * paramO.O());
    double d2 = 0.0D;
    D localD2 = paramO.J();
    while (localD2.C())
    {
      _B local_B = B(localD2.H());
      local_B.C += d3;
      local_B.D += d3;
      d2 += local_B.C + local_B.D;
      localD2.B();
    }
    I(paramO);
  }
  
  protected void I(O paramO)
  {
    G[] arrayOfG = new G[paramO.O()];
    int i = 0;
    R localR = paramO.I();
    while (localR.C())
    {
      arrayOfG[i] = localR.I();
      localR.B();
      i++;
    }
    Arrays.sort(arrayOfG, new _A());
    for (int j = 0; j < arrayOfG.length; j++) {
      this.U.E(arrayOfG[j]);
    }
    for (j = 0; j < arrayOfG.length; j += 2) {
      this.U.B(arrayOfG[j]);
    }
    i = arrayOfG.length - 1;
    if (i % 2 == 0) {
      i--;
    }
    while (i > 0)
    {
      this.U.B(arrayOfG[i]);
      i -= 2;
    }
  }
  
  protected double E(O paramO)
  {
    if (paramO.C() == 0) {
      return this.S;
    }
    if (paramO.O() == 2) {
      return Math.min(180.0D, this.T);
    }
    return this.T;
  }
  
  protected double C(O paramO)
  {
    double d1 = 0.0D;
    R localR = paramO.I();
    while (localR.C())
    {
      G localG = localR.I();
      O localO = localG.T();
      _B local_B = B(localO);
      double d2 = -local_B.E;
      double d3 = local_B.A;
      S localS = local_B.G;
      double d4 = 0.0D;
      double d5 = d4 + 1.0D;
      M localM = localS.G();
      twaver.base.A.D.E.C.E localE1 = (twaver.base.A.D.E.C.E)localM.B();
      while (d5 > d4)
      {
        twaver.base.A.D.E.C.E localE2 = localE1;
        localM = localS.D(localM);
        localE1 = (twaver.base.A.D.E.C.E)localM.B();
        d4 = (localE1.A() - localE2.A()) / (localE1.B() - localE2.B());
        d5 = (localE2.A() - d3) / (localE2.B() - d2);
      }
      local_B.C = (-Math.toDegrees(Math.atan(d5)));
      d4 = 0.0D;
      d5 = d4 - 1.0D;
      localM = localS.G();
      for (localE1 = (twaver.base.A.D.E.C.E)localM.B(); ((twaver.base.A.D.E.C.E)localM.A().B()).B() == localE1.B(); localE1 = (twaver.base.A.D.E.C.E)localM.B()) {
        localM = localM.A();
      }
      while (d5 < d4)
      {
        twaver.base.A.D.E.C.E localE3 = localE1;
        localM = localS.E(localM);
        localE1 = (twaver.base.A.D.E.C.E)localM.B();
        d4 = (localE1.A() - localE3.A()) / (localE1.B() - localE3.B());
        d5 = (localE3.A() - d3) / (localE3.B() - d2);
      }
      local_B.D = Math.toDegrees(Math.atan(d5));
      d1 += local_B.C + local_B.D;
      localR.B();
    }
    return d1;
  }
  
  void A(O paramO, _B param_B)
  {
    this.R[paramO.F()] = param_B;
  }
  
  void G(O paramO)
  {
    _B local_B = B(paramO);
    S localS = new S();
    double d = 2.0D * A(paramO);
    localS.add(new twaver.base.A.D.E.C.E(0.0D, 0.0D));
    localS.add(new twaver.base.A.D.E.C.E(0.0D, d));
    localS.add(new twaver.base.A.D.E.C.E(d, d));
    localS.add(new twaver.base.A.D.E.C.E(d, 0.0D));
    local_B.G = localS;
    local_B.B = (d / 2.0D);
    local_B.A = (d / 2.0D);
  }
  
  void F(O paramO)
  {
    if (paramO.O() == 0)
    {
      G(paramO);
    }
    else
    {
      _B local_B1 = B(paramO);
      double d1 = A(paramO);
      S localS = new S();
      localS.add(new twaver.base.A.D.E.C.E(-d1, -d1));
      localS.add(new twaver.base.A.D.E.C.E(-d1, d1));
      localS.add(new twaver.base.A.D.E.C.E(d1, -d1));
      localS.add(new twaver.base.A.D.E.C.E(d1, d1));
      Object localObject1 = paramO.J();
      while (((D)localObject1).C())
      {
        _B local_B2 = B(((D)localObject1).H());
        localS.A(local_B2.G);
        ((D)localObject1).B();
      }
      localObject1 = T.A(localS);
      double d2 = 1.7976931348623157E+308D;
      double d3 = 1.7976931348623157E+308D;
      double d4 = -1.797693134862316E+308D;
      double d5 = -1.797693134862316E+308D;
      Object localObject2 = ((S)localObject1).F();
      while (((twaver.base.A.D.E.E.F)localObject2).C())
      {
        localObject3 = (twaver.base.A.D.E.C.E)((twaver.base.A.D.E.E.F)localObject2).D();
        if (((twaver.base.A.D.E.C.E)localObject3).B() < d2) {
          d2 = ((twaver.base.A.D.E.C.E)localObject3).B();
        }
        if (((twaver.base.A.D.E.C.E)localObject3).B() > d4) {
          d4 = ((twaver.base.A.D.E.C.E)localObject3).B();
        }
        if (((twaver.base.A.D.E.C.E)localObject3).A() < d3) {
          d3 = ((twaver.base.A.D.E.C.E)localObject3).A();
        }
        if (((twaver.base.A.D.E.C.E)localObject3).A() > d5) {
          d5 = ((twaver.base.A.D.E.C.E)localObject3).A();
        }
        ((twaver.base.A.D.E.E.F)localObject2).B();
      }
      localObject2 = new S();
      Object localObject3 = ((S)localObject1).F();
      while (((twaver.base.A.D.E.E.F)localObject3).C())
      {
        twaver.base.A.D.E.C.E localE = (twaver.base.A.D.E.C.E)((twaver.base.A.D.E.E.F)localObject3).D();
        ((S)localObject2).add(new twaver.base.A.D.E.C.E(localE.B() - d2, localE.A() - d3));
        ((twaver.base.A.D.E.E.F)localObject3).B();
      }
      local_B1.G = ((S)localObject2);
      local_B1.B = (-d2);
      local_B1.A = (-d3);
    }
  }
  
  void J(O paramO)
  {
    if (paramO.O() == 0)
    {
      F(paramO);
    }
    else
    {
      D localD1 = paramO.J();
      while (localD1.C())
      {
        J(localD1.H());
        localD1.B();
      }
      H(paramO);
      double d1 = 0.0D;
      D localD2 = paramO.J();
      while (localD2.C())
      {
        O localO = localD2.H();
        _B local_B = B(localO);
        double d2 = 180.0D - (360.0D - E(paramO)) / 2.0D - d1 - (local_B.D + local_B.F);
        d1 += local_B.A();
        d2 = Math.toRadians(d2);
        double d3 = Math.sin(d2);
        double d4 = Math.cos(d2);
        for (M localM = local_B.G.G(); localM != null; localM = localM.A())
        {
          twaver.base.A.D.E.C.E localE1 = (twaver.base.A.D.E.C.E)localM.B();
          double d6 = localE1.B() + local_B.E;
          double d7 = localE1.A() - local_B.A;
          twaver.base.A.D.E.C.E localE2 = new twaver.base.A.D.E.C.E(d6 * d4 - d3 * d7, d6 * d3 + d4 * d7);
          localM.A(localE2);
        }
        double d5 = local_B.B + local_B.E;
        local_B.B = (d5 * d4);
        local_B.A = (d5 * d3);
        localD2.B();
      }
      F(paramO);
    }
  }
  
  void D(O paramO)
  {
    twaver.base.A.D.E.C.E localE = this.U.N(paramO);
    double d1 = 0.0D;
    Object localObject2;
    if (paramO.C() > 0)
    {
      localObject1 = paramO.H().H();
      localObject2 = this.U.N((O)localObject1);
      d1 = 3.141592653589793D + Math.atan2(((twaver.base.A.D.E.C.E)localObject2).A() - localE.A(), ((twaver.base.A.D.E.C.E)localObject2).B() - localE.B());
    }
    Object localObject1 = paramO.J();
    while (((D)localObject1).C())
    {
      localObject2 = ((D)localObject1).H();
      _B local_B = B((O)localObject2);
      if (d1 != 0.0D)
      {
        double d2 = Math.cos(d1);
        double d3 = Math.sin(d1);
        double d4 = local_B.B * d2 - d3 * local_B.A;
        double d5 = local_B.B * d3 + d2 * local_B.A;
        local_B.B = d4;
        local_B.A = d5;
      }
      this.U.A((O)localObject2, localE.B() + local_B.B, localE.A() + local_B.A);
      D((O)localObject2);
      ((D)localObject1).B();
    }
  }
  
  double A(O paramO)
  {
    return 1.41D * (Math.max(this.U.L(paramO), this.U.Q(paramO)) / 2.0D);
  }
  
  public static class _B
  {
    S G;
    public double C;
    public double D;
    public double F;
    public double E;
    double B;
    double A;
    
    public double A()
    {
      return this.C + this.D + this.F;
    }
    
    _B(double paramDouble)
    {
      this.E = paramDouble;
      this.G = new S();
    }
  }
  
  class _A
    implements Comparator
  {
    _A() {}
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      O localO1 = ((G)paramObject1).T();
      O localO2 = ((G)paramObject2).T();
      double d = C.this.B(localO1).A() - C.this.B(localO2).A();
      if (d > 0.0D) {
        return 1;
      }
      return d >= 0.0D ? 0 : -1;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.A.C
 * JD-Core Version:    0.7.0.1
 */
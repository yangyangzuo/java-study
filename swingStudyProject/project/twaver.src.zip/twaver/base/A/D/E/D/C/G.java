package twaver.base.A.D.E.D.C;

import java.util.Comparator;

public class G
{
  static class _A
    implements Comparator
  {
    boolean A;
    int[] B;
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      if (this.A)
      {
        i = this.B[((twaver.base.A.D.E.E.G)paramObject1).W().F()];
        j = this.B[((twaver.base.A.D.E.E.G)paramObject2).W().F()];
        return i - j;
      }
      int i = this.B[((twaver.base.A.D.E.E.G)paramObject1).T().F()];
      int j = this.B[((twaver.base.A.D.E.E.G)paramObject2).T().F()];
      return i - j;
    }
    
    _A(int[] paramArrayOfInt, boolean paramBoolean)
    {
      this.B = paramArrayOfInt;
      this.A = paramBoolean;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.G
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.L;
import twaver.base.A.E.T;

public class I
{
  private static final I D = new I((byte)1);
  private static final I A = new I((byte)2);
  private byte C;
  private boolean B;
  
  public I(byte paramByte)
  {
    this.C = paramByte;
  }
  
  public boolean E()
  {
    return this.B;
  }
  
  public byte F()
  {
    return this.C;
  }
  
  public boolean B()
  {
    return this.C == 1;
  }
  
  public boolean A()
  {
    return this.C == 2;
  }
  
  public boolean C()
  {
    return this.C == 4;
  }
  
  public boolean D()
  {
    return this.C == 8;
  }
  
  public boolean G()
  {
    return this.C == 0;
  }
  
  public static I A(C paramC, G paramG)
  {
    L localL = paramC.A(T.A);
    if (localL == null) {
      return null;
    }
    return (I)localL.D(paramG);
  }
  
  public static I B(C paramC, G paramG)
  {
    L localL = paramC.A(T.F);
    if (localL == null) {
      return null;
    }
    return (I)localL.D(paramG);
  }
  
  public static I A(byte paramByte)
  {
    switch (paramByte)
    {
    case 1: 
      return D;
    case 2: 
      return A;
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.I
 * JD-Core Version:    0.7.0.1
 */
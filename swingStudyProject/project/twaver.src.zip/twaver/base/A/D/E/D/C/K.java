package twaver.base.A.D.E.D.C;

import java.util.Comparator;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.D.I;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

class K
  implements Comparator
{
  protected int[] A;
  protected byte B;
  
  public K(int[] paramArrayOfInt, byte paramByte)
  {
    this.A = paramArrayOfInt;
    this.B = paramByte;
  }
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    int i2;
    int i6;
    int i7;
    switch (this.B)
    {
    case 1: 
      G localG1 = (G)paramObject1;
      G localG2 = (G)paramObject2;
      C localC1 = (C)localG1.R();
      O localO1 = localG1.W();
      O localO2 = localG2.W();
      int i = this.A[localO1.F()] - this.A[localO2.F()];
      if (i == 0)
      {
        int j = A(I.A(localC1, localG1), localC1.L(localG1));
        int k = A(I.A(localC1, localG2), localC1.L(localG2));
        int m = j - k;
        if (m == 0)
        {
          int n = this.A[localG1.T().F()] - this.A[localG2.T().F()];
          if (n == 0)
          {
            int i1 = B(I.B(localC1, localG1), localC1.H(localG1));
            i2 = B(I.B(localC1, localG2), localC1.H(localG2));
            return i1 - i2;
          }
          return n;
        }
        return m;
      }
      return i;
    case 0: 
      G localG3 = (G)paramObject1;
      G localG4 = (G)paramObject2;
      C localC2 = (C)localG3.R();
      O localO3 = localG3.T();
      O localO4 = localG4.T();
      i2 = this.A[localO3.F()] - this.A[localO4.F()];
      if (i2 == 0)
      {
        int i3 = B(I.B(localC2, localG3), localC2.H(localG3));
        int i4 = B(I.B(localC2, localG4), localC2.H(localG4));
        int i5 = i3 - i4;
        if (i5 == 0)
        {
          i6 = this.A[localG3.W().F()] - this.A[localG4.W().F()];
          if (i6 == 0)
          {
            i7 = A(I.A(localC2, localG3), localC2.L(localG3));
            int i8 = A(I.A(localC2, localG4), localC2.L(localG4));
            return i7 - i8;
          }
          return i6;
        }
        return i5;
      }
      return i2;
    case 2: 
      return this.A[((O)paramObject1).F()] - this.A[((O)paramObject2).F()];
    case 3: 
      G localG5 = (G)paramObject1;
      G localG6 = (G)paramObject2;
      C localC3 = (C)localG5.R();
      i6 = A(I.A(localC3, localG5), localC3.L(localG5));
      i7 = A(I.A(localC3, localG6), localC3.L(localG6));
      return i6 - i7;
    case 4: 
      G localG7 = (G)paramObject1;
      G localG8 = (G)paramObject2;
      C localC4 = (C)localG7.R();
      int i9 = B(I.B(localC4, localG7), localC4.H(localG7));
      int i10 = B(I.B(localC4, localG8), localC4.H(localG8));
      return i9 - i10;
    }
    throw new IllegalStateException();
  }
  
  private final int A(I paramI, E paramE)
  {
    if (paramI == null) {
      return 0;
    }
    int i = paramI.E() ? (int)paramE.A : 0;
    int j = paramI.E() ? (int)paramE.B : 0;
    if (paramI.C()) {
      return 10000 - j;
    }
    if (paramI.D()) {
      return -10000 + j;
    }
    if (paramI.B()) {
      return -20000 - i;
    }
    return i;
  }
  
  private final int B(I paramI, E paramE)
  {
    if (paramI == null) {
      return 0;
    }
    int i = paramI.E() ? (int)paramE.A : 0;
    int j = paramI.E() ? (int)paramE.B : 0;
    if (paramI.C()) {
      return 10000 + j;
    }
    if (paramI.D()) {
      return -10000 - j;
    }
    if (paramI.A()) {
      return -20000 - i;
    }
    return i;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof K)) {
      return false;
    }
    return (this == paramObject) || ((this.A == ((K)paramObject).A) && (this.B == ((K)paramObject).B));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.K
 * JD-Core Version:    0.7.0.1
 */
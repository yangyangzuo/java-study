package twaver.base.A.D.E.E;

abstract interface E
  extends D, R
{}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.E
 * JD-Core Version:    0.7.0.1
 */
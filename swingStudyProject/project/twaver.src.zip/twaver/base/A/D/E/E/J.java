package twaver.base.A.D.E.E;

import java.util.Stack;
import java.util.Vector;

class J
{
  int A;
  int C;
  Stack B;
  Vector D;
  
  J(int paramInt1, int paramInt2)
  {
    this.A = paramInt1;
    this.C = paramInt2;
    this.B = new Stack();
    for (int i = this.A - 1; i >= 0; i--) {
      this.B.push(new Integer(i));
    }
    this.D = new Vector();
  }
  
  private int C(P paramP)
  {
    int i;
    if (this.B.empty())
    {
      A(paramP, this.A, this.A + this.C);
      for (int j = this.A + this.C - 1; j > this.A; j--) {
        this.B.push(new Integer(j));
      }
      i = this.A;
      this.A += this.C;
    }
    else
    {
      i = ((Integer)this.B.pop()).intValue();
    }
    return i;
  }
  
  I A(P paramP)
  {
    int i = C(paramP);
    B localB = new B(i, this);
    this.D.addElement(localB);
    A(paramP, i);
    return localB;
  }
  
  K B(P paramP)
  {
    int i = C(paramP);
    H localH = new H(i, this);
    this.D.addElement(localH);
    A(paramP, i);
    return localH;
  }
  
  void A(P paramP, int paramInt1, int paramInt2)
  {
    for (N localN = paramP.D(); localN != null; localN = paramP.B(localN))
    {
      Object[] arrayOfObject = new Object[paramInt2];
      System.arraycopy(localN.A, 0, arrayOfObject, 0, paramInt1);
      localN.A = arrayOfObject;
    }
  }
  
  void A(N paramN, int paramInt1, int paramInt2)
  {
    Object[] arrayOfObject = new Object[paramInt2];
    System.arraycopy(paramN.A, 0, arrayOfObject, 0, paramInt1);
    paramN.A = arrayOfObject;
  }
  
  void A(P paramP, int paramInt)
  {
    for (N localN = paramP.D(); localN != null; localN = paramP.B(localN)) {
      localN.A[paramInt] = null;
    }
  }
  
  void A(I paramI, P paramP)
  {
    if ((paramI instanceof B))
    {
      B localB = (B)paramI;
      if (localB.D()) {
        throw new RuntimeException();
      }
      localB.C();
      int i = ((B)paramI).J;
      if (!this.B.contains(new Integer(i)))
      {
        A(paramP, i);
        this.B.push(new Integer(i));
        this.D.removeElement(paramI);
      }
    }
  }
  
  void A(K paramK, P paramP)
  {
    if ((paramK instanceof H))
    {
      H localH = (H)paramK;
      if (localH.B()) {
        throw new RuntimeException();
      }
      localH.A();
      int i = localH.H;
      if (!this.B.contains(new Integer(i)))
      {
        A(paramP, i);
        this.B.push(new Integer(i));
        this.D.removeElement(paramK);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.J
 * JD-Core Version:    0.7.0.1
 */
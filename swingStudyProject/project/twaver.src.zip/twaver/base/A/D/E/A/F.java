package twaver.base.A.D.E.A;

public class F
  extends C
{
  public F()
  {
    super(0.0D, 0.0D);
  }
  
  public F(C paramC)
  {
    super(paramC);
  }
  
  public C A(C paramC)
  {
    return new F(paramC);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.F
 * JD-Core Version:    0.7.0.1
 */
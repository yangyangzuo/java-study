package twaver.base.A.D.E.D.C;

import java.util.Comparator;
import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

class L
{
  private twaver.base.A.D.E.E.I G;
  private twaver.base.A.D.E.E.K M;
  private twaver.base.A.D.E.E.K I;
  private twaver.base.A.D.E.D.C P;
  private twaver.base.A.D.E.E.L E;
  private twaver.base.A.D.E.E.L F;
  private boolean L;
  private F B;
  private J R;
  private twaver.base.A.D.E.E.I Q;
  private twaver.base.A.D.E.E.I K;
  private twaver.base.A.D.E.E.K H;
  private double J = 20.0D;
  private twaver.base.A.D.E.E.I O;
  private twaver.base.A.D.E.E.K S;
  private twaver.base.A.D.E.E.K N;
  private double D = 0.5D;
  private static twaver.base.A.D.E.D.I C = twaver.base.A.D.E.D.I.A();
  private static twaver.base.A.D.E.D.I A = twaver.base.A.D.E.D.I.A((byte)1);
  
  public L(twaver.base.A.D.E.D.C paramC, twaver.base.A.D.E.E.I paramI1, twaver.base.A.D.E.E.I paramI2, twaver.base.A.D.E.E.K paramK)
  {
    this.P = paramC;
    this.Q = paramI1;
    this.K = paramI2;
    this.H = paramK;
    this.L = ((paramC.A(T.A) != null) || (paramC.A(T.F) != null));
    this.B = new F(paramC, paramI1, paramI2, paramK);
    this.R = new J(paramC, this);
  }
  
  public void A(double paramDouble)
  {
    this.J = paramDouble;
    this.B.A(paramDouble);
    this.R.A(paramDouble);
  }
  
  public double C()
  {
    return this.J;
  }
  
  public int A(int paramInt)
  {
    D();
    return paramInt;
  }
  
  public Q[] A(Q[] paramArrayOfQ)
  {
    paramArrayOfQ = this.B.B(paramArrayOfQ);
    B();
    return paramArrayOfQ;
  }
  
  public Q[] B(Q[] paramArrayOfQ)
  {
    D();
    paramArrayOfQ = this.B.A(paramArrayOfQ);
    paramArrayOfQ = C(paramArrayOfQ);
    this.R.C();
    return paramArrayOfQ;
  }
  
  public Q[] F(Q[] paramArrayOfQ)
  {
    this.R.B();
    return paramArrayOfQ;
  }
  
  public void G(Q[] paramArrayOfQ)
  {
    paramArrayOfQ = E(paramArrayOfQ);
    this.R.A();
  }
  
  public void A()
  {
    this.B.A();
    if (this.G != null) {
      this.P.A(this.G);
    }
    B();
    this.P = null;
  }
  
  private void B()
  {
    if (!this.L) {
      return;
    }
    if (this.E != null)
    {
      this.P.A(T.A, this.E);
      this.E = null;
    }
    if (this.F != null)
    {
      this.P.A(T.F, this.F);
      this.F = null;
    }
    if (this.M != null)
    {
      this.P.A(this.M);
      this.M = null;
    }
    if (this.I != null)
    {
      this.P.A(this.I);
      this.I = null;
    }
  }
  
  private void D()
  {
    if (!this.L) {
      return;
    }
    if (this.M == null) {
      this.M = this.P.F();
    }
    if (this.I == null) {
      this.I = this.P.F();
    }
    R localR = this.P.M();
    while (localR.C())
    {
      G localG1 = localR.I();
      int i = this.K.D(localG1.W()) != null ? 1 : 0;
      int j = this.K.D(localG1.T()) != null ? 1 : 0;
      G localG2;
      if ((i != 0) && (j == 0))
      {
        localG2 = (G)this.K.D(localG1.W());
        if (this.H.B(localG2)) {
          this.I.A(localG1, twaver.base.A.D.E.D.I.A(this.P, localG2));
        } else {
          this.I.A(localG1, twaver.base.A.D.E.D.I.B(this.P, localG2));
        }
      }
      else if ((i == 0) && (j != 0))
      {
        localG2 = (G)this.K.D(localG1.T());
        if (this.H.B(localG2)) {
          this.M.A(localG1, twaver.base.A.D.E.D.I.B(this.P, localG2));
        } else {
          this.M.A(localG1, twaver.base.A.D.E.D.I.A(this.P, localG2));
        }
      }
      else if ((i == 0) && (j == 0))
      {
        if (this.H.B(localG1))
        {
          this.M.A(localG1, twaver.base.A.D.E.D.I.B(this.P, localG1));
          this.I.A(localG1, twaver.base.A.D.E.D.I.A(this.P, localG1));
        }
        else
        {
          this.M.A(localG1, twaver.base.A.D.E.D.I.A(this.P, localG1));
          this.I.A(localG1, twaver.base.A.D.E.D.I.B(this.P, localG1));
        }
      }
      localR.B();
    }
    this.E = this.P.A(T.A);
    this.F = this.P.A(T.F);
    this.P.A(T.A, this.M);
    this.P.A(T.F, this.I);
  }
  
  private Q[] C(Q[] paramArrayOfQ)
  {
    this.G = this.P.H();
    this.S = this.P.F();
    this.N = this.P.F();
    A localA1 = new A();
    A localA2 = new A();
    A localA3 = new A();
    A localA4 = new A();
    A localA5 = new A();
    A localA6 = new A();
    A localA7 = new A();
    A localA8 = new A();
    A localA9 = new A();
    twaver.base.A.D.E.E.I localI = this.P.H();
    Object localObject;
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      double d1 = 0.0D;
      localObject = paramArrayOfQ[i].P();
      while (((D)localObject).C())
      {
        localI.B(((D)localObject).H(), d1);
        ((D)localObject).B();
        d1 += 1.0D;
      }
    }
    Comparator localComparator1 = twaver.base.A.D.E.B.C.A(localI);
    Comparator localComparator2 = twaver.base.A.D.E.B.C.B(localI);
    for (int j = 0; j < paramArrayOfQ.length; j++)
    {
      localObject = paramArrayOfQ[j];
      for (twaver.base.A.D.E.E.M localM = ((Q)localObject).G(); localM != null; localM = localM.A())
      {
        O localO1 = (O)localM.B();
        localO1.A(localComparator1);
        localO1.B(localComparator2);
        int k = 0;
        localA1.clear();
        localA2.clear();
        localA3.clear();
        localA4.clear();
        localA5.clear();
        localA6.clear();
        localA7.clear();
        localA8.clear();
        localA9.clear();
        R localR1 = localO1.I();
        G localG1;
        twaver.base.A.D.E.D.I localI1;
        while (localR1.C())
        {
          localG1 = localR1.I();
          localI1 = B(localG1);
          if ((localI1 == null) || (localI1.A()) || (localI1.G()))
          {
            localA3.add(localG1);
          }
          else if (localI1.C())
          {
            localA1.add(localG1);
          }
          else if (localI1.D())
          {
            localA2.add(localG1);
            localA9.add(localG1);
          }
          else if (localI1.B())
          {
            localA8.add(localG1);
            localA9.add(localG1);
          }
          localR1.B();
          k++;
        }
        k = 0;
        localR1 = localO1.E();
        while (localR1.C())
        {
          localG1 = localR1.I();
          localI1 = D(localG1);
          if ((localI1 == null) || (localI1.B()) || (localI1.G()))
          {
            localA4.add(localG1);
          }
          else if (localI1.C())
          {
            localA1.add(localG1);
          }
          else if (localI1.D())
          {
            localA2.add(localG1);
            localA9.add(localG1);
          }
          else if (localI1.A())
          {
            localA6.add(localG1);
            localA9.add(localG1);
          }
          localR1.B();
          k++;
        }
        double d2 = localI.C(localO1);
        double d3;
        double d4;
        G localG2;
        O localO2;
        if (!localA9.isEmpty())
        {
          d3 = 0.1D / localA9.size();
          for (d4 = d2 - 0.4D; !localA9.isEmpty(); d4 += d3)
          {
            localG2 = localA9.K();
            if (localG2.W() == localO1)
            {
              localO2 = this.P.I();
              this.G.B(localO2, localG2.W());
              this.P.C(localO2, 1.0D, 1.0D);
              this.Q.B(localO2, this.Q.D(localO1));
              localI.B(localO2, d4);
              this.S.A(localG2, this.P.L(localG2));
              this.P.D(localG2, T.D);
              this.P.A(localG2, localO2, localG2.T());
              ((Q)localObject).A(localO2, localM);
            }
            else
            {
              localO2 = this.P.I();
              this.G.B(localO2, localG2.T());
              this.P.C(localO2, 1.0D, 1.0D);
              this.Q.B(localO2, this.Q.D(localO1));
              localI.B(localO2, d4);
              this.N.A(localG2, this.P.H(localG2));
              this.P.C(localG2, T.D);
              this.P.A(localG2, localG2.W(), localO2);
              ((Q)localObject).A(localO2, localM);
            }
          }
        }
        if (!localA1.isEmpty())
        {
          d3 = 0.1D / localA1.size();
          for (d4 = d2 + 0.1D; !localA1.isEmpty(); d4 += d3)
          {
            localG2 = localA1.K();
            if (localG2.W() == localO1)
            {
              localO2 = this.P.I();
              this.G.B(localO2, localG2.W());
              this.P.C(localO2, 1.0D, 1.0D);
              this.Q.B(localO2, this.Q.D(localO1));
              localI.B(localO2, d4);
              this.S.A(localG2, this.P.L(localG2));
              this.P.D(localG2, T.D);
              this.P.A(localG2, localO2, localG2.T());
              localM = ((Q)localObject).B(localO2, localM);
            }
            else
            {
              localO2 = this.P.I();
              this.G.B(localO2, localG2.T());
              this.P.C(localO2, 1.0D, 1.0D);
              this.Q.B(localO2, this.Q.D(localO1));
              localI.B(localO2, d4);
              this.N.A(localG2, this.P.H(localG2));
              this.P.C(localG2, T.D);
              this.P.A(localG2, localG2.W(), localO2);
              localM = ((Q)localObject).B(localO2, localM);
            }
          }
        }
        J._A local_A = J.E;
        if (this.R.A(localO1)) {
          local_A = this.R.B(localO1);
        }
        int m = local_A.P.size() + localA6.size() + localO1.O() + localA5.size() + local_A.A.size();
        if (m > 0)
        {
          d4 = this.P.Q(localO1) / 2.0D;
          double d5 = this.P.L(localO1);
          double d6 = A(d5, m);
          double d8 = -0.5D * d5 + A(this.P.L(localO1), m, d6) + d6 * (local_A.P.size() + localA6.size());
          R localR2 = localO1.I();
          while (localR2.C())
          {
            G localG3 = localR2.I();
            if ((!C(localG3)) && (this.K.D(localG3.W()) == null))
            {
              this.P.M(localG3).B(new twaver.base.A.D.E.C.E(d8, d4));
              d8 += d6;
            }
            localR2.B();
          }
        }
        F._A local_A1 = this.B.A(localO1);
        int n = 0;
        int i1 = 0;
        int i2 = 0;
        int i3 = 0;
        if (local_A1 != null)
        {
          n = local_A1.C.size();
          i1 = local_A1.E.size();
          i2 = local_A1.A.size();
          i3 = local_A1.D.size();
        }
        m = local_A.K.size() + n + localA8.size() + localO1.C() + localA7.size() + i1 + local_A.N.size();
        if (m > 0)
        {
          double d7 = this.P.L(localO1);
          double d9 = A(d7, m);
          double d10 = A(d7, m, d9);
          double d11 = -0.5D * d7 + d10 + d9 * (local_A.K.size() + n + localA8.size());
          double d12 = -this.P.Q(localO1) / 2.0D;
          R localR3 = localO1.E();
          while (localR3.C())
          {
            G localG4 = localR3.I();
            if ((!A(localG4)) && (this.K.D(localG4.T()) == null))
            {
              this.P.M(localG4).A(new twaver.base.A.D.E.C.E(d11, d12));
              d11 += d9;
            }
            localR3.B();
          }
          if (local_A1 != null)
          {
            double d13 = -0.5D * d7 + d10 + d9 * (local_A.K.size() + localA8.size() + local_A1.C.size() - 1);
            R localR4 = local_A1.C.J();
            G localG5;
            while (localR4.C())
            {
              localG5 = localR4.I();
              this.P.B(localG5);
              if ((localG5.W() == localO1) && (!C(localG5)))
              {
                this.P.M(localR4.I()).B(new twaver.base.A.D.E.C.E(d13, d12));
                d13 -= d9;
              }
              else if (!A(localG5))
              {
                this.P.M(localR4.I()).A(new twaver.base.A.D.E.C.E(d13, d12));
                d13 -= d9;
              }
              this.P.E(localG5);
              localR4.B();
            }
            d13 = 0.5D * d7 - d10 - d9 * (local_A.N.size() + localA7.size());
            localR4 = local_A1.E.J();
            while (localR4.C())
            {
              localG5 = localR4.I();
              this.P.B(localG5);
              if ((localG5.W() == localO1) && (!C(localG5)))
              {
                this.P.M(localR4.I()).B(new twaver.base.A.D.E.C.E(d13, d12));
                d13 -= d9;
              }
              else if (!A(localG5))
              {
                this.P.M(localR4.I()).A(new twaver.base.A.D.E.C.E(d13, d12));
                d13 -= d9;
              }
              this.P.E(localG5);
              localR4.B();
            }
          }
        }
        if (this.R.A(localO1)) {
          this.R.A(localO1, n + localA8.size() + localO1.C() + localA7.size() + i1, localA6.size() + localO1.O() + localA5.size(), i2 + localA2.size(), i3 + localA1.size());
        }
      }
    }
    this.P.A(localI);
    return paramArrayOfQ;
  }
  
  double A(double paramDouble, int paramInt)
  {
    if (paramInt <= 1) {
      return 0.0D;
    }
    return paramDouble / (paramInt - 1 + 2.0D * this.D);
  }
  
  double A(double paramDouble1, int paramInt, double paramDouble2)
  {
    if (paramInt <= 1) {
      return paramDouble1 * 0.5D;
    }
    return (paramDouble1 - paramDouble2 * (paramInt - 1)) * 0.5D;
  }
  
  private Q[] E(Q[] paramArrayOfQ)
  {
    double d1 = C();
    this.O = this.P.H();
    Object localObject3;
    Object localObject4;
    Object localObject5;
    Object localObject6;
    Object localObject7;
    Q localQ2;
    Object localObject8;
    Object localObject9;
    Object localObject10;
    Object localObject11;
    Object localObject12;
    Object localObject13;
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      Q localQ1 = paramArrayOfQ[i];
      Object localObject1 = localQ1.G();
      while (localObject1 != null)
      {
        O localO1 = (O)((twaver.base.A.D.E.E.M)localObject1).B();
        localObject2 = (O)this.G.D(localO1);
        if ((localObject2 != null) || (this.B.B(localO1)))
        {
          localObject1 = ((twaver.base.A.D.E.E.M)localObject1).A();
        }
        else
        {
          localObject3 = new Q();
          localObject4 = new Q();
          localObject5 = new Q();
          localObject6 = new Q();
          localObject7 = new Q();
          localQ2 = new Q();
          localObject8 = new A();
          localObject9 = new A();
          localObject10 = new _C((Q)localObject3, (Q)localObject4, (Q)localObject5, (Q)localObject6, (Q)localObject7, localQ2, (A)localObject8, (A)localObject9);
          this.O.B(localO1, localObject10);
          ((A)localObject8).A(localO1.E());
          ((A)localObject9).A(localO1.I());
          for (localObject11 = ((twaver.base.A.D.E.E.M)localObject1).C(); (localObject11 != null) && (this.G.D(((twaver.base.A.D.E.E.M)localObject11).B()) == localO1); localObject11 = ((twaver.base.A.D.E.E.M)localObject11).C())
          {
            localObject12 = (O)((twaver.base.A.D.E.E.M)localObject11).B();
            localObject13 = A((O)localObject12);
            if (((twaver.base.A.D.E.D.I)localObject13).D()) {
              ((Q)localObject4).A(localObject12);
            } else if (((twaver.base.A.D.E.D.I)localObject13).B()) {
              ((Q)localObject6).A(localObject12);
            } else if (((twaver.base.A.D.E.D.I)localObject13).A()) {
              localQ2.A(localObject12);
            }
          }
          for (localObject11 = ((twaver.base.A.D.E.E.M)localObject1).A(); (localObject11 != null) && (this.G.D(((twaver.base.A.D.E.E.M)localObject11).B()) == localO1); localObject11 = ((twaver.base.A.D.E.E.M)localObject11).A())
          {
            localObject12 = (O)((twaver.base.A.D.E.E.M)localObject11).B();
            localObject13 = A((O)localObject12);
            if (((twaver.base.A.D.E.D.I)localObject13).C()) {
              ((Q)localObject3).add(localObject12);
            } else if (((twaver.base.A.D.E.D.I)localObject13).B()) {
              ((Q)localObject5).add(localObject12);
            } else if (((twaver.base.A.D.E.D.I)localObject13).A()) {
              ((Q)localObject7).add(localObject12);
            }
          }
          localObject1 = localObject11;
        }
      }
    }
    E[] arrayOfE = D(paramArrayOfQ);
    double d2 = 0.0D;
    for (int j = 0; j < paramArrayOfQ.length; j++)
    {
      localObject2 = arrayOfE[j];
      if (j > 0) {
        d2 += arrayOfE[(j - 1)].A + arrayOfE[(j - 1)].C + arrayOfE[(j - 1)].I;
      }
      d2 += ((E)localObject2).D + ((E)localObject2).E + ((E)localObject2).J + ((E)localObject2).G;
      localObject3 = paramArrayOfQ[j].P();
      while (((D)localObject3).C())
      {
        localObject4 = ((D)localObject3).H();
        this.P.B((O)localObject4, this.P.O((O)localObject4), this.P.I((O)localObject4) + d2);
        ((D)localObject3).B();
      }
      localObject2.H += d2;
      localObject2.B += d2;
    }
    for (j = 0; j < paramArrayOfQ.length; j++)
    {
      localObject2 = paramArrayOfQ[j];
      localObject3 = ((Q)localObject2).P();
      while (((D)localObject3).C())
      {
        localObject4 = ((D)localObject3).H();
        if (this.G.D(localObject4) != null) {
          ((Q)localObject2).B((twaver.base.A.D.E.E.F)localObject3);
        }
        ((D)localObject3).B();
      }
    }
    _B local_B = new _B(null);
    Object localObject2 = new _A(null);
    for (int k = 0; k < paramArrayOfQ.length; k++)
    {
      localObject4 = arrayOfE[k];
      localObject5 = paramArrayOfQ[k].P();
      while (((D)localObject5).C())
      {
        localObject6 = ((D)localObject5).H();
        if (!this.B.B((O)localObject6))
        {
          localObject7 = (_C)this.O.D(localObject6);
          localQ2 = ((_C)localObject7).G;
          localObject8 = ((_C)localObject7).B;
          localObject9 = ((_C)localObject7).A;
          localObject10 = ((_C)localObject7).C;
          localObject11 = ((_C)localObject7).E;
          localObject12 = ((_C)localObject7).H;
          localObject13 = ((_C)localObject7).D;
          A localA = ((_C)localObject7).F;
          int m = 0;
          int n = 0;
          int i1 = 0;
          int i2 = 0;
          int i3 = ((O)localObject6).O();
          int i4 = ((O)localObject6).C();
          double d3 = this.P.O((O)localObject6);
          double d4 = this.P.I((O)localObject6);
          double d5 = this.P.L((O)localObject6);
          double d6 = this.P.Q((O)localObject6);
          F._A local_A = this.B.A((O)localObject6);
          J._A local_A1 = J.E;
          if (this.R.A((O)localObject6)) {
            local_A1 = this.R.B((O)localObject6);
          }
          Object localObject14;
          if (local_A != null)
          {
            m = local_A.D.size();
            n = local_A.A.size();
            i1 = local_A.C.size();
            i2 = local_A.E.size();
            R localR;
            if (m > 0)
            {
              i5 = local_A1.J.size() + localQ2.size() + m + local_A1.G.size();
              d7 = A(d6, i5);
              d8 = A(d6, i5, d7);
              d9 = d4 + d8 + d7 * (local_A1.J.size() + A(localQ2));
              localR = local_A.D.J();
              while (localR.C())
              {
                localObject14 = localR.I();
                this.P.B((G)localObject14);
                if (((G)localObject14).W() == localObject6)
                {
                  if (!C((G)localObject14)) {
                    this.P.B((G)localObject14, new twaver.base.A.D.E.C.E(d3 + d5, d9));
                  }
                }
                else
                {
                  if (A((G)localObject14)) {}
                  this.P.A((G)localObject14, new twaver.base.A.D.E.C.E(d3 + d5, d9));
                }
                d9 += d7;
                this.P.E((G)localObject14);
                localR.B();
              }
            }
            if (n > 0)
            {
              i5 = local_A1.I.size() + ((Q)localObject8).size() + n + local_A1.F.size();
              d7 = A(d6, i5);
              d8 = A(d6, i5, d7);
              d9 = d4 + d8 + d7 * (local_A1.I.size() + A((Q)localObject8));
              localR = local_A.A.J();
              while (localR.C())
              {
                localObject14 = localR.I();
                this.P.B((G)localObject14);
                if (((G)localObject14).W() == localObject6)
                {
                  if (!C((G)localObject14)) {
                    this.P.B((G)localObject14, new twaver.base.A.D.E.C.E(d3, d9));
                  }
                }
                else if (!A((G)localObject14)) {
                  this.P.A((G)localObject14, new twaver.base.A.D.E.C.E(d3, d9));
                }
                d9 += d7;
                this.P.E((G)localObject14);
                localR.B();
              }
            }
          }
          int i6;
          G localG1;
          Object localObject15;
          twaver.base.A.D.E.C.E localE1;
          twaver.base.A.D.E.C.E localE2;
          if (localQ2.size() > 0)
          {
            localQ2.A(local_B);
            i5 = local_A1.J.size() + localQ2.size() + m + local_A1.G.size();
            d7 = A(d6, i5);
            d8 = A(d6, i5, d7);
            d9 = d4 + d8 + d7 * local_A1.J.size();
            i6 = 1;
            while (!localQ2.isEmpty())
            {
              localObject14 = localQ2.N();
              if (C((O)localObject14))
              {
                if (i6 != 0)
                {
                  i6 = 0;
                  d9 += d7 * m;
                }
                localG1 = ((O)localObject14).K();
                localObject15 = this.P.K(localG1);
                localE1 = (twaver.base.A.D.E.C.E)((S)localObject15).A();
                ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE1.B(), ((E)localObject4).B()));
                if (C(localG1))
                {
                  localE2 = (twaver.base.A.D.E.C.E)this.S.D(localG1);
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE1.B(), localE2.A() + this.P.H((O)localObject6)));
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE2.B() + this.P.K((O)localObject6), localE2.A() + this.P.H((O)localObject6)));
                }
                else
                {
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE1.B(), d9));
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(d3 + d5, d9));
                }
                this.P.A(localG1, (O)localObject6, localG1.T());
                this.P.A(localG1, (S)localObject15);
              }
              else
              {
                localG1 = ((O)localObject14).L();
                localObject15 = this.P.K(localG1);
                localE1 = (twaver.base.A.D.E.C.E)((S)localObject15).D();
                ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), ((E)localObject4).A()));
                if (A(localG1))
                {
                  localE2 = (twaver.base.A.D.E.C.E)this.N.D(localG1);
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), localE2.A() + this.P.H((O)localObject6)));
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE2.B() + this.P.K((O)localObject6), localE2.A() + this.P.H((O)localObject6)));
                }
                else
                {
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), d9));
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(d3 + d5, d9));
                }
                this.P.A(localG1, localG1.W(), (O)localObject6);
                this.P.A(localG1, (S)localObject15);
              }
              this.P.B((O)localObject14);
              d9 += d7;
            }
          }
          if (((Q)localObject8).size() > 0)
          {
            ((Q)localObject8).A((Comparator)localObject2);
            i5 = local_A1.I.size() + ((Q)localObject8).size() + n + local_A1.F.size();
            d7 = A(d6, i5);
            d8 = A(d6, i5, d7);
            d9 = d4 + d8 + d7 * local_A1.I.size();
            i6 = 1;
            while (!((Q)localObject8).isEmpty())
            {
              localObject14 = ((Q)localObject8).N();
              if (C((O)localObject14))
              {
                if (i6 != 0)
                {
                  i6 = 0;
                  d9 += d7 * n;
                }
                localG1 = ((O)localObject14).K();
                localObject15 = this.P.K(localG1);
                localE1 = (twaver.base.A.D.E.C.E)((S)localObject15).A();
                ((S)localObject15).C(new twaver.base.A.D.E.C.E(localE1.B(), ((E)localObject4).B()));
                if (C(localG1))
                {
                  localE2 = (twaver.base.A.D.E.C.E)this.S.D(localG1);
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE1.B(), localE2.A() + this.P.H((O)localObject6)));
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE2.B() + this.P.K((O)localObject6), localE2.A() + this.P.H((O)localObject6)));
                }
                else
                {
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(localE1.B(), d9));
                  ((S)localObject15).A(new twaver.base.A.D.E.C.E(d3, d9));
                }
                this.P.A(localG1, (O)localObject6, localG1.T());
                this.P.A(localG1, (S)localObject15);
              }
              else
              {
                localG1 = ((O)localObject14).L();
                localObject15 = this.P.K(localG1);
                localE1 = (twaver.base.A.D.E.C.E)((S)localObject15).D();
                ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), ((E)localObject4).A()));
                if (A(localG1))
                {
                  localE2 = (twaver.base.A.D.E.C.E)this.N.D(localG1);
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), localE2.A() + this.P.H((O)localObject6)));
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE2.B() + this.P.K((O)localObject6), localE2.A() + this.P.H((O)localObject6)));
                }
                else
                {
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(localE1.B(), d9));
                  ((S)localObject15).D(new twaver.base.A.D.E.C.E(d3, d9));
                }
                this.P.A(localG1, localG1.W(), (O)localObject6);
                this.P.A(localG1, (S)localObject15);
              }
              this.P.B((O)localObject14);
              d9 += d7;
            }
          }
          int i5 = local_A1.K.size() + local_A1.N.size() + i4 + ((Q)localObject10).size() + ((Q)localObject9).size() + i1 + i2;
          d5 = this.P.L((O)localObject6);
          double d7 = A(d5, i5);
          double d8 = A(d5, i5, d7);
          i5 = local_A1.P.size() + local_A1.A.size() + i3 + ((Q)localObject12).size() + ((Q)localObject11).size();
          double d9 = A(d5, i5);
          double d10 = A(d5, i5, d9);
          double d11;
          double d12;
          double d13;
          double d14;
          double d15;
          O localO2;
          G localG3;
          S localS2;
          twaver.base.A.D.E.C.E localE3;
          twaver.base.A.D.E.C.E localE4;
          if (((Q)localObject10).size() > 0)
          {
            d11 = d7;
            d12 = d1;
            d13 = this.P.O((O)localObject6) + d8 + d11 * (local_A1.K.size() + ((Q)localObject10).size() - 1);
            d14 = this.P.I((O)localObject6);
            d15 = ((E)localObject4).H - ((E)localObject4).D - ((Q)localObject10).size() * d12;
            while (!((Q)localObject10).isEmpty())
            {
              localO2 = ((Q)localObject10).N();
              localG3 = localO2.K();
              localS2 = this.P.K(localG3);
              localE3 = (twaver.base.A.D.E.C.E)localS2.A();
              localS2.A(new twaver.base.A.D.E.C.E(localE3.B(), ((E)localObject4).B()));
              localS2.A(new twaver.base.A.D.E.C.E(localE3.B(), d15));
              if (C(localG3))
              {
                localE4 = (twaver.base.A.D.E.C.E)this.S.D(localG3);
                localS2.A(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), d15));
                localS2.A(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), localE4.A() + this.P.H((O)localObject6)));
              }
              else
              {
                localS2.A(new twaver.base.A.D.E.C.E(d13, d15));
                localS2.A(new twaver.base.A.D.E.C.E(d13, d14));
                d13 -= d11;
              }
              d15 += d12;
              this.P.A(localG3, (O)localObject6, localG3.T());
              this.P.A(localG3, localS2);
              this.P.B(localO2);
            }
          }
          if (((Q)localObject9).size() > 0)
          {
            d11 = d7;
            d12 = d1;
            d13 = this.P.O((O)localObject6) + this.P.L((O)localObject6) - d8 - d11 * local_A1.N.size();
            d14 = this.P.I((O)localObject6);
            d15 = ((E)localObject4).H - ((E)localObject4).D - d12;
            while (!((Q)localObject9).isEmpty())
            {
              localO2 = ((Q)localObject9).N();
              localG3 = localO2.K();
              localS2 = this.P.K(localG3);
              localE3 = (twaver.base.A.D.E.C.E)localS2.A();
              localS2.A(new twaver.base.A.D.E.C.E(localE3.B(), ((E)localObject4).B()));
              localS2.A(new twaver.base.A.D.E.C.E(localE3.B(), d15));
              if (C(localG3))
              {
                localE4 = (twaver.base.A.D.E.C.E)this.S.D(localG3);
                localS2.A(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), d15));
                localS2.A(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), localE4.A() + this.P.H((O)localObject6)));
              }
              else
              {
                localS2.A(new twaver.base.A.D.E.C.E(d13, d15));
                localS2.A(new twaver.base.A.D.E.C.E(d13, d14));
                d13 -= d11;
              }
              d15 -= d12;
              this.P.A(localG3, (O)localObject6, localG3.T());
              this.P.A(localG3, localS2);
              this.P.B(localO2);
            }
          }
          if (((Q)localObject12).size() > 0)
          {
            d11 = d9;
            d12 = d1;
            d13 = this.P.O((O)localObject6) + d10 + d11 * (local_A1.P.size() + ((Q)localObject12).size() - 1);
            d14 = this.P.I((O)localObject6) + this.P.Q((O)localObject6);
            d15 = d14 + ((Q)localObject12).size() * d12;
            while (!((Q)localObject12).isEmpty())
            {
              localO2 = ((Q)localObject12).N();
              localG3 = localO2.L();
              localS2 = this.P.K(localG3);
              localE3 = (twaver.base.A.D.E.C.E)localS2.D();
              localS2.D(new twaver.base.A.D.E.C.E(localE3.B(), ((E)localObject4).A()));
              localS2.D(new twaver.base.A.D.E.C.E(localE3.B(), d15));
              if (A(localG3))
              {
                localE4 = (twaver.base.A.D.E.C.E)this.N.D(localG3);
                localS2.D(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), d15));
                localS2.D(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), localE4.A() + this.P.H((O)localObject6)));
              }
              else
              {
                localS2.D(new twaver.base.A.D.E.C.E(d13, d15));
                localS2.D(new twaver.base.A.D.E.C.E(d13, d14));
                d13 -= d11;
              }
              d15 -= d12;
              this.P.A(localG3, localG3.W(), (O)localObject6);
              this.P.A(localG3, localS2);
              this.P.B(localO2);
            }
          }
          if (((Q)localObject11).size() > 0)
          {
            d11 = d9;
            d12 = d1;
            d13 = this.P.O((O)localObject6) + this.P.L((O)localObject6) - d10 - d9 * local_A1.A.size();
            d14 = this.P.I((O)localObject6) + this.P.Q((O)localObject6);
            d15 = d14 + d12;
            while (!((Q)localObject11).isEmpty())
            {
              localO2 = ((Q)localObject11).N();
              localG3 = localO2.L();
              localS2 = this.P.K(localG3);
              localE3 = (twaver.base.A.D.E.C.E)localS2.D();
              localS2.D(new twaver.base.A.D.E.C.E(localE3.B(), ((E)localObject4).A()));
              localS2.D(new twaver.base.A.D.E.C.E(localE3.B(), d15));
              if (A(localG3))
              {
                localE4 = (twaver.base.A.D.E.C.E)this.N.D(localG3);
                localS2.D(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), d15));
                localS2.D(new twaver.base.A.D.E.C.E(localE4.B() + this.P.K((O)localObject6), localE4.A() + this.P.H((O)localObject6)));
              }
              else
              {
                localS2.D(new twaver.base.A.D.E.C.E(d13, d15));
                localS2.D(new twaver.base.A.D.E.C.E(d13, d14));
                d13 -= d11;
              }
              d15 += d12;
              this.P.A(localG3, localG3.W(), (O)localObject6);
              this.P.A(localG3, localS2);
              this.P.B(localO2);
            }
          }
          G localG2;
          while (!localA.isEmpty())
          {
            localG2 = localA.K();
            localObject15 = this.P.O(localG2);
            if (((E)localObject4).A() + 12.0D < ((twaver.base.A.D.E.C.E)localObject15).A()) {
              this.P.D(localG2).A(((twaver.base.A.D.E.C.E)localObject15).B(), ((E)localObject4).A());
            }
          }
          while (!((A)localObject13).isEmpty())
          {
            localG2 = ((A)localObject13).K();
            localObject15 = this.P.I(localG2);
            if (((E)localObject4).B() - 12.0D > ((twaver.base.A.D.E.C.E)localObject15).A())
            {
              S localS1 = this.P.P(localG2);
              localS1.A(new twaver.base.A.D.E.C.E(((twaver.base.A.D.E.C.E)localObject15).B(), ((E)localObject4).B()));
              this.P.B(localG2, localS1);
            }
          }
        }
        ((D)localObject5).B();
      }
    }
    for (k = 0; k < paramArrayOfQ.length; k++)
    {
      localObject4 = paramArrayOfQ[k];
      for (localObject5 = ((Q)localObject4).G(); localObject5 != null; localObject5 = ((twaver.base.A.D.E.E.M)localObject5).A())
      {
        localObject6 = (O)((twaver.base.A.D.E.E.M)localObject5).B();
        localObject7 = this.B.A((O)localObject6);
        if ((localObject7 != null) && (((F._A)localObject7).B != null))
        {
          this.P.B(((F._A)localObject7).B);
          ((Q)localObject4).F(((twaver.base.A.D.E.E.M)localObject5).C());
        }
      }
    }
    this.P.A(this.O);
    this.P.A(this.S);
    this.P.A(this.N);
    return paramArrayOfQ;
  }
  
  private twaver.base.A.D.E.D.I A(O paramO)
  {
    if (C(paramO)) {
      return B(paramO.K());
    }
    return D(paramO.L());
  }
  
  private twaver.base.A.D.E.D.I B(G paramG)
  {
    if (this.M == null) {
      return C;
    }
    return (twaver.base.A.D.E.D.I)this.M.D(paramG);
  }
  
  private twaver.base.A.D.E.D.I D(G paramG)
  {
    if (this.I == null) {
      return A;
    }
    return (twaver.base.A.D.E.D.I)this.I.D(paramG);
  }
  
  private boolean C(G paramG)
  {
    if (paramG == null) {
      return false;
    }
    twaver.base.A.D.E.D.I localI = B(paramG);
    return (localI != null) && (localI.E());
  }
  
  private boolean A(G paramG)
  {
    if (paramG == null) {
      return false;
    }
    twaver.base.A.D.E.D.I localI = D(paramG);
    return (localI != null) && (localI.E());
  }
  
  private boolean C(O paramO)
  {
    return paramO.O() == 1;
  }
  
  private boolean B(O paramO)
  {
    return paramO.C() == 1;
  }
  
  private int A(Q paramQ)
  {
    int i = 0;
    for (twaver.base.A.D.E.E.M localM = paramQ.G(); localM != null; localM = localM.A()) {
      if (B((O)localM.B())) {
        i++;
      }
    }
    return i;
  }
  
  E[] D(Q[] paramArrayOfQ)
  {
    double d = this.J;
    E[] arrayOfE = new E[paramArrayOfQ.length + 1];
    Object localObject1;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      localObject1 = paramArrayOfQ[i];
      localObject2 = new E();
      arrayOfE[i] = localObject2;
      ((E)localObject2).H = 1.7976931348623157E+308D;
      ((E)localObject2).B = -1.797693134862316E+308D;
      localObject3 = ((Q)localObject1).P();
      while (((D)localObject3).C())
      {
        localObject4 = ((D)localObject3).H();
        twaver.base.A.D.E.D.M localM = this.P.C(localObject4);
        ((E)localObject2).H = Math.min(((E)localObject2).H, localM.A());
        ((E)localObject2).B = Math.max(((E)localObject2).B, localM.A() + localM.D());
        ((D)localObject3).B();
      }
    }
    this.R.A(paramArrayOfQ, arrayOfE);
    for (i = 0; i < paramArrayOfQ.length; i++)
    {
      localObject1 = arrayOfE[i];
      localObject2 = paramArrayOfQ[i].P();
      while (((D)localObject2).C())
      {
        localObject3 = ((D)localObject2).H();
        localObject4 = (_C)this.O.D(localObject3);
        if (localObject4 != null)
        {
          ((E)localObject1).C = Math.max(((E)localObject1).C, Math.max(((_C)localObject4).E.size() * d, ((_C)localObject4).H.size() * d));
          ((E)localObject1).E = Math.max(((E)localObject1).E, Math.max(((_C)localObject4).A.size() * d, ((_C)localObject4).C.size() * d));
        }
        ((D)localObject2).B();
      }
    }
    return arrayOfE;
  }
  
  private class _B
    implements Comparator
  {
    private _B() {}
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      O localO1 = (O)paramObject1;
      O localO2 = (O)paramObject2;
      if (L.this.C(localO1))
      {
        if (L.this.C(localO2)) {
          return L.this.P.O(localO1) >= L.this.P.O(localO2) ? -1 : 1;
        }
        return 1;
      }
      if (L.this.C(localO2)) {
        return -1;
      }
      return L.this.P.O(localO1) >= L.this.P.O(localO2) ? 1 : -1;
    }
    
    _B(_B param_B)
    {
      this();
    }
  }
  
  private static class _C
  {
    Q G;
    Q B;
    Q A;
    Q C;
    Q E;
    Q H;
    A F;
    A D;
    
    _C(Q paramQ1, Q paramQ2, Q paramQ3, Q paramQ4, Q paramQ5, Q paramQ6, A paramA1, A paramA2)
    {
      this.G = paramQ1;
      this.B = paramQ2;
      this.A = paramQ3;
      this.C = paramQ4;
      this.E = paramQ5;
      this.H = paramQ6;
      this.F = paramA1;
      this.D = paramA2;
    }
  }
  
  private class _A
    implements Comparator
  {
    private _A() {}
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      O localO1 = (O)paramObject1;
      O localO2 = (O)paramObject2;
      if (L.this.C(localO1))
      {
        if (L.this.C(localO2)) {
          return L.this.P.O(localO1) >= L.this.P.O(localO2) ? 1 : -1;
        }
        return 1;
      }
      if (L.this.C(localO2)) {
        return -1;
      }
      return L.this.P.O(localO1) >= L.this.P.O(localO2) ? -1 : 1;
    }
    
    _A(_A param_A)
    {
      this();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.L
 * JD-Core Version:    0.7.0.1
 */
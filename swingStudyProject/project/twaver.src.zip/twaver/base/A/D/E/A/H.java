package twaver.base.A.D.E.A;

import twaver.base.A.D.E.E.O;

class H
  extends O
{
  C I;
  
  protected H(I paramI, C paramC)
  {
    super(paramI);
    if (paramC != null) {
      this.I = paramC;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.H
 * JD-Core Version:    0.7.0.1
 */
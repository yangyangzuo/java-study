package twaver.base.A.D.E.E;

class N
{
  N C;
  N B;
  Object[] A;
  
  void A(int paramInt)
  {
    this.A = new Object[paramInt];
  }
  
  N A()
  {
    return this.C;
  }
  
  N B()
  {
    return this.B;
  }
  
  void B(N paramN)
  {
    this.C = paramN;
  }
  
  void A(N paramN)
  {
    this.B = paramN;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.N
 * JD-Core Version:    0.7.0.1
 */
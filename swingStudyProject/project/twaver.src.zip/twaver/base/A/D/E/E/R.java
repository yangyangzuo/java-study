package twaver.base.A.D.E.E;

public abstract interface R
  extends F
{
  public abstract G I();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.R
 * JD-Core Version:    0.7.0.1
 */
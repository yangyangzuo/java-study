package twaver.base.A.D.E.A;

import java.awt.geom.Rectangle2D;
import twaver.base.A.D.E.D.M;

public abstract class C
  implements M
{
  private boolean H;
  protected double F;
  protected double I;
  protected double G;
  protected double E;
  
  public C(double paramDouble1, double paramDouble2)
  {
    this.H = false;
    this.G = 30.0D;
    this.E = 30.0D;
    this.F = (paramDouble1 - this.G / 2.0D);
    this.I = (paramDouble2 - this.E / 2.0D);
  }
  
  public C(C paramC)
  {
    this.H = paramC.H;
    this.G = paramC.G;
    this.E = paramC.E;
    this.F = paramC.F;
    this.I = paramC.I;
  }
  
  public C F()
  {
    return A(this);
  }
  
  public abstract C A(C paramC);
  
  public double G()
  {
    return this.F + this.G / 2.0D;
  }
  
  public double E()
  {
    return this.I + this.E / 2.0D;
  }
  
  public void C(double paramDouble1, double paramDouble2)
  {
    this.F = (paramDouble1 - this.G / 2.0D);
    this.I = (paramDouble2 - this.E / 2.0D);
  }
  
  public double C()
  {
    return this.F;
  }
  
  public double A()
  {
    return this.I;
  }
  
  public void A(double paramDouble1, double paramDouble2)
  {
    this.F = paramDouble1;
    this.I = paramDouble2;
  }
  
  public double B()
  {
    return this.G;
  }
  
  public double D()
  {
    return this.E;
  }
  
  public void B(double paramDouble1, double paramDouble2)
  {
    double d1 = (this.G - paramDouble1) / 2.0D;
    double d2 = (this.E - paramDouble2) / 2.0D;
    this.F += d1;
    this.I += d2;
    this.G = paramDouble1;
    this.E = paramDouble2;
  }
  
  public void A(Rectangle2D paramRectangle2D)
  {
    double d1;
    double d2;
    double d3;
    double d4;
    if (paramRectangle2D.getWidth() <= 0.0D)
    {
      d1 = this.F;
      d2 = this.F + this.G;
      d3 = this.I;
      d4 = this.I + this.E;
    }
    else
    {
      d1 = Math.min(this.F, paramRectangle2D.getX());
      d2 = Math.max(this.F + this.G, paramRectangle2D.getX() + paramRectangle2D.getWidth());
      d3 = Math.min(this.I, paramRectangle2D.getY());
      d4 = Math.max(this.I + this.E, paramRectangle2D.getY() + paramRectangle2D.getHeight());
    }
    paramRectangle2D.setFrame(d1, d3, d2 - d1, d4 - d3);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.C
 * JD-Core Version:    0.7.0.1
 */
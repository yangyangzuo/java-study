package twaver.base.A.D.E.D.C;

import java.util.HashMap;
import java.util.Map;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

class J
{
  public static _A E = new _A();
  private twaver.base.A.D.E.D.C D;
  private Map C;
  private L B;
  private double A = 20.0D;
  
  public J(twaver.base.A.D.E.D.C paramC, L paramL)
  {
    this.B = paramL;
    this.D = paramC;
    this.C = new HashMap();
  }
  
  public void A(double paramDouble)
  {
    this.A = paramDouble;
  }
  
  public void A(O paramO, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (A(paramO))
    {
      _A local_A = B(paramO);
      local_A.C = paramInt1;
      local_A.E = paramInt4;
      local_A.D = paramInt3;
      local_A.L = paramInt2;
    }
  }
  
  public _A B(O paramO)
  {
    _A local_A = (_A)this.C.get(paramO);
    if (local_A == null)
    {
      local_A = new _A();
      this.C.put(paramO, local_A);
    }
    return local_A;
  }
  
  public boolean A(O paramO)
  {
    return this.C.containsKey(paramO);
  }
  
  public void C()
  {
    twaver.base.A.D.E.E.I localI1 = twaver.base.A.D.E.B.A.A(new double[this.D.C()]);
    twaver.base.A.D.E.E.I localI2 = twaver.base.A.D.E.B.A.A(new double[this.D.C()]);
    D localD = this.D.J();
    while (localD.C())
    {
      O localO = localD.H();
      if (A(localO))
      {
        _A local_A = B(localO);
        localI1.B(localO, this.A * (local_A.A() - 1));
        localI2.B(localO, this.A * (local_A.B() - 1));
      }
      localD.B();
    }
    this.D.A(C.B, localI1);
    this.D.A(C.A, localI2);
  }
  
  public void B()
  {
    this.D.B(C.B);
    this.D.B(C.A);
  }
  
  public void A()
  {
    D localD = this.D.J();
    while (localD.C())
    {
      O localO = localD.H();
      if (A(localO))
      {
        double d1 = this.D.O(localO);
        double d2 = this.D.I(localO);
        double d3 = this.D.L(localO);
        double d4 = this.D.Q(localO);
        _A local_A = B(localO);
        int i = local_A.A.size() + local_A.P.size() + local_A.L;
        int j = local_A.N.size() + local_A.K.size() + local_A.C;
        int k = local_A.I.size() + local_A.F.size() + local_A.D;
        int m = local_A.J.size() + local_A.G.size() + local_A.E;
        double d5 = this.B.A(d3, i);
        double d6 = this.B.A(d3, j);
        double d7 = this.B.A(d4, m);
        double d8 = this.B.A(d4, k);
        local_A.A(this.B.A(d3, i, d5), this.B.A(d3, j, d6), this.B.A(d4, m, d7), this.B.A(d4, k, d8));
        R localR = local_A.H.J();
        while (localR.C())
        {
          G localG = localR.I();
          twaver.base.A.D.E.D.I localI1 = A(localG);
          twaver.base.A.D.E.D.I localI2 = B(localG);
          S localS = new S();
          if (localI1.F() == localI2.F())
          {
            if (localI1.B())
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2 - this.A));
              local_A.K.D += 1.0D;
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2 - this.A));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2));
              local_A.K.D += 1.0D;
              local_A.K.E = Math.max(local_A.K.E, 2);
            }
            else if (localI1.A())
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4 + this.A));
              local_A.P.D += 1.0D;
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4 + this.A));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4));
              local_A.P.D += 1.0D;
              local_A.P.E = Math.max(local_A.P.E, 2);
            }
            else if (localI1.D())
            {
              localS.add(new twaver.base.A.D.E.C.E(d1, d2 + local_A.I.D * d8 + local_A.Q));
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A, d2 + local_A.I.D * d8 + local_A.Q));
              local_A.I.D += 1.0D;
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A, d2 + local_A.I.D * d8 + local_A.Q));
              localS.add(new twaver.base.A.D.E.C.E(d1, d2 + local_A.I.D * d8 + local_A.Q));
              local_A.I.D += 1.0D;
              local_A.I.E = Math.max(local_A.I.E, 2);
            }
            else if (localI1.C())
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3, d2 + local_A.J.D * d7 + local_A.M));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A, d2 + local_A.J.D * d7 + local_A.M));
              local_A.J.D += 1.0D;
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A, d2 + local_A.J.D * d7 + local_A.M));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3, d2 + local_A.J.D * d7 + local_A.M));
              local_A.J.D += 1.0D;
              local_A.J.E = Math.max(local_A.J.E, 2);
            }
            this.D.A(localG, localS);
          }
          else if ((localI1.B()) || (localI2.B()))
          {
            if ((localI1.C()) || (localI2.C()))
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.N.D * d6 - local_A.O, d2));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.N.D * d6 - local_A.O, d2 - this.A * local_A.N.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.J.E, d2 - this.A * local_A.N.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.J.E, d2 + local_A.J.D * d7 + local_A.M));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3, d2 + local_A.J.D * d7 + local_A.M));
              local_A.N.D += 1.0D;
              local_A.N.E += 1;
              local_A.J.D += 1.0D;
              local_A.J.E += 1;
              if (localI2.B()) {
                localS.C();
              }
              this.D.A(localG, localS);
            }
            else if ((localI1.D()) || (localI2.D()))
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.K.D * d6 + local_A.O, d2 - this.A * local_A.K.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.I.E, d2 - this.A * local_A.K.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.I.E, d2 + local_A.I.D * d8 + local_A.Q));
              localS.add(new twaver.base.A.D.E.C.E(d1, d2 + local_A.I.D * d8 + local_A.Q));
              local_A.K.D += 1.0D;
              local_A.K.E += 1;
              local_A.I.D += 1.0D;
              local_A.I.E += 1;
              if (localI2.B()) {
                localS.C();
              }
              this.D.A(localG, localS);
            }
            else if ((localI1.A()) || (localI2.A()))
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.N.D * d6 - local_A.O, d2));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.N.D * d6 - local_A.O, d2 - this.A * local_A.N.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.B(), d2 - this.A * local_A.N.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.B(), d2 + d4 + this.A * local_A.A.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.A.D * d5 - local_A.B, d2 + d4 + this.A * local_A.A.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.A.D * d5 - local_A.B, d2 + d4));
              local_A.N.D += 1.0D;
              local_A.N.E += 1;
              local_A.G.E += 1;
              local_A.J.E += 1;
              local_A.A.E += 1;
              local_A.A.D += 1.0D;
              if (localI2.B()) {
                localS.C();
              }
              this.D.A(localG, localS);
            }
          }
          else if ((localI1.A()) || (localI2.A()))
          {
            if ((localI1.C()) || (localI2.C()))
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.A.D * d5 - local_A.B, d2 + d4));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 - local_A.A.D * d5 - local_A.B, d2 + d4 + this.A * local_A.A.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.G.E, d2 + d4 + this.A * local_A.A.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.G.E, d2 + d4 - local_A.G.D * d7 - local_A.M));
              localS.add(new twaver.base.A.D.E.C.E(d1 + d3, d2 + d4 - local_A.G.D * d7 - local_A.M));
              local_A.A.D += 1.0D;
              local_A.A.E += 1;
              local_A.G.D += 1.0D;
              local_A.G.E += 1;
              if (localI2.A()) {
                localS.C();
              }
              this.D.A(localG, localS);
            }
            else if ((localI1.D()) || (localI2.D()))
            {
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4));
              localS.add(new twaver.base.A.D.E.C.E(d1 + local_A.P.D * d5 + local_A.B, d2 + d4 + this.A * local_A.P.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.F.E, d2 + d4 + this.A * local_A.P.E));
              localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.F.E, d2 + d4 - local_A.F.D * d8 - local_A.Q));
              localS.add(new twaver.base.A.D.E.C.E(d1, d2 + d4 - local_A.F.D * d8 - local_A.Q));
              local_A.P.D += 1.0D;
              local_A.P.E += 1;
              local_A.F.D += 1.0D;
              local_A.F.E += 1;
              if (localI2.A()) {
                localS.C();
              }
              this.D.A(localG, localS);
            }
          }
          else
          {
            localS.add(new twaver.base.A.D.E.C.E(d1, d2 + d4 - local_A.F.D * d8 - local_A.Q));
            localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.F.E, d2 + d4 - local_A.F.D * d8 - local_A.Q));
            localS.add(new twaver.base.A.D.E.C.E(d1 - this.A * local_A.F.E, d2 + d4 + this.A * local_A.C()));
            localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.G.E, d2 + d4 + this.A * local_A.C()));
            localS.add(new twaver.base.A.D.E.C.E(d1 + d3 + this.A * local_A.G.E, d2 + d4 - local_A.G.D * d7 - local_A.M));
            localS.add(new twaver.base.A.D.E.C.E(d1 + d3, d2 + d4 - local_A.G.D * d7 - local_A.M));
            local_A.F.D += 1.0D;
            local_A.F.E += 1;
            local_A.P.E += 1;
            local_A.A.E += 1;
            local_A.G.E += 1;
            local_A.G.D += 1.0D;
            if (localI2.D()) {
              localS.C();
            }
            this.D.A(localG, localS);
          }
          localR.B();
        }
      }
      localD.B();
    }
  }
  
  void A(Q[] paramArrayOfQ, E[] paramArrayOfE)
  {
    for (int i = 0; i < paramArrayOfQ.length; i++)
    {
      Q localQ = paramArrayOfQ[i];
      E localE = paramArrayOfE[i];
      D localD = localQ.P();
      while (localD.C())
      {
        O localO = localD.H();
        if (A(localO))
        {
          _A local_A = B(localO);
          localE.D = Math.max(localE.D, this.A * (local_A.D() - 1));
          localE.A = Math.max(localE.A, this.A * (local_A.C() - 1));
        }
        localD.B();
      }
    }
  }
  
  twaver.base.A.D.E.D.I A(G paramG)
  {
    twaver.base.A.D.E.E.L localL1 = this.D.A(T.A);
    twaver.base.A.D.E.D.I localI1 = null;
    if (localL1 != null) {
      localI1 = (twaver.base.A.D.E.D.I)localL1.D(paramG);
    }
    if ((localI1 == null) || (localI1.G()))
    {
      twaver.base.A.D.E.E.L localL2 = this.D.A(T.F);
      if (localL2 == null) {
        return twaver.base.A.D.E.D.I.A((byte)1);
      }
      twaver.base.A.D.E.D.I localI2 = (twaver.base.A.D.E.D.I)localL2.D(paramG);
      if ((localI2 == null) || (localI2.G())) {
        return twaver.base.A.D.E.D.I.A((byte)1);
      }
      if (localI2.B()) {
        return twaver.base.A.D.E.D.I.A((byte)8);
      }
      if (localI2.D()) {
        return twaver.base.A.D.E.D.I.A((byte)1);
      }
      if (localI2.A()) {
        return twaver.base.A.D.E.D.I.A((byte)4);
      }
      if (localI2.C()) {
        return twaver.base.A.D.E.D.I.A((byte)2);
      }
    }
    return localI1;
  }
  
  twaver.base.A.D.E.D.I B(G paramG)
  {
    twaver.base.A.D.E.E.L localL1 = this.D.A(T.F);
    twaver.base.A.D.E.D.I localI1 = null;
    if (localL1 != null) {
      localI1 = (twaver.base.A.D.E.D.I)localL1.D(paramG);
    }
    if ((localI1 == null) || (localI1.G()))
    {
      twaver.base.A.D.E.E.L localL2 = this.D.A(T.A);
      if (localL2 == null) {
        return twaver.base.A.D.E.D.I.A((byte)8);
      }
      twaver.base.A.D.E.D.I localI2 = (twaver.base.A.D.E.D.I)localL2.D(paramG);
      if ((localI2 == null) || (localI2.G())) {
        return twaver.base.A.D.E.D.I.A((byte)8);
      }
      if (localI2.B()) {
        return twaver.base.A.D.E.D.I.A((byte)8);
      }
      if (localI2.D()) {
        return twaver.base.A.D.E.D.I.A((byte)1);
      }
      if (localI2.A()) {
        return twaver.base.A.D.E.D.I.A((byte)4);
      }
      if (localI2.C()) {
        return twaver.base.A.D.E.D.I.A((byte)2);
      }
    }
    return localI1;
  }
  
  static class _B
    extends twaver.base.A.D.E.E.A
  {
    int E;
    double D;
    double F;
    
    void M()
    {
      this.E = 1;
      this.D = 0.0D;
    }
    
    _B()
    {
      M();
    }
  }
  
  static class _A
  {
    twaver.base.A.D.E.E.A H = new twaver.base.A.D.E.E.A();
    J._B K = new J._B();
    J._B N = new J._B();
    J._B P = new J._B();
    J._B A = new J._B();
    J._B J = new J._B();
    J._B G = new J._B();
    J._B I = new J._B();
    J._B F = new J._B();
    int C;
    int L;
    int D;
    int E;
    double O;
    double B;
    double M;
    double Q;
    
    int C()
    {
      return Math.max(this.A.E, this.P.E);
    }
    
    int D()
    {
      return Math.max(this.N.E, this.K.E);
    }
    
    int B()
    {
      return Math.max(this.G.E, this.J.E);
    }
    
    int A()
    {
      return Math.max(this.F.E, this.I.E);
    }
    
    void A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
    {
      this.O = paramDouble2;
      this.Q = paramDouble4;
      this.B = paramDouble1;
      this.M = paramDouble3;
      this.K.M();
      this.N.M();
      this.P.M();
      this.A.M();
      this.G.M();
      this.J.M();
      this.F.M();
      this.I.M();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.J
 * JD-Core Version:    0.7.0.1
 */
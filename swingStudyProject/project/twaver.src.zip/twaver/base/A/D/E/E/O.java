package twaver.base.A.D.E.E;

import java.util.Arrays;
import java.util.Comparator;

public class O
  extends N
{
  C D;
  G[] G;
  G[] E;
  int[] H;
  int F;
  
  protected O(C paramC)
  {
    paramC.D(this);
  }
  
  public int G()
  {
    return this.H[0] + this.H[1];
  }
  
  public int C()
  {
    return this.H[1];
  }
  
  public int O()
  {
    return this.H[0];
  }
  
  public int F()
  {
    if (this.D.G) {
      this.D.L();
    }
    return this.F;
  }
  
  public C P()
  {
    return this.D;
  }
  
  public G K()
  {
    return this.G[0];
  }
  
  public G L()
  {
    return this.G[1];
  }
  
  public R M()
  {
    return new _D();
  }
  
  public R E()
  {
    return new _B(1);
  }
  
  public R I()
  {
    return new _B(0);
  }
  
  public D N()
  {
    return new _A();
  }
  
  public D H()
  {
    return new _C(1);
  }
  
  public D J()
  {
    return new _C(0);
  }
  
  public G A(O paramO)
  {
    for (G localG = this.G[0]; localG != null; localG = localG.J[0]) {
      if (localG.T() == paramO) {
        return localG;
      }
    }
    return null;
  }
  
  public G B(O paramO)
  {
    for (G localG = this.G[1]; localG != null; localG = localG.J[1]) {
      if (localG.W() == paramO) {
        return localG;
      }
    }
    return null;
  }
  
  public G C(O paramO)
  {
    G localG = A(paramO);
    if (localG == null) {
      localG = B(paramO);
    }
    return localG;
  }
  
  public void B(Comparator paramComparator)
  {
    A(paramComparator, 1, new G[C()]);
  }
  
  public void A(Comparator paramComparator)
  {
    A(paramComparator, 0, new G[O()]);
  }
  
  void A(C paramC, int paramInt)
  {
    A(paramInt);
    this.D = paramC;
    this.G = new G[2];
    this.E = new G[2];
    this.H = new int[2];
  }
  
  void A(C paramC)
  {
    this.D = paramC;
  }
  
  O B(G paramG)
  {
    return paramG.K;
  }
  
  O A(G paramG)
  {
    return paramG.N;
  }
  
  void A(G paramG1, G paramG2, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramG2 == null)
    {
      A(paramG1, paramInt1, paramInt2);
      return;
    }
    int i;
    if (B(paramG2) == A(paramG2)) {
      i = paramInt2;
    } else {
      i = this != B(paramG2) ? 1 : 0;
    }
    G localG;
    if (paramInt3 == 0)
    {
      localG = paramG2.J[i];
      paramG1.L[paramInt2] = paramG2;
      paramG1.J[paramInt2] = localG;
      paramG2.J[i] = paramG1;
      if (localG == null) {
        this.E[paramInt1] = paramG1;
      } else if (B(localG) == A(localG)) {
        localG.L[paramInt2] = paramG1;
      } else {
        localG.L[(this != B(localG) ? 1 : 0)] = paramG1;
      }
    }
    else
    {
      localG = paramG2.L[i];
      paramG1.J[paramInt2] = paramG2;
      paramG1.L[paramInt2] = localG;
      paramG2.L[i] = paramG1;
      if (localG == null) {
        this.G[paramInt1] = paramG1;
      } else if (B(localG) == A(localG)) {
        localG.J[paramInt2] = paramG1;
      } else {
        localG.J[(this != B(localG) ? 1 : 0)] = paramG1;
      }
    }
    this.H[paramInt1] += 1;
  }
  
  void A(G paramG, int paramInt1, int paramInt2)
  {
    G localG = this.E[paramInt1];
    paramG.J[paramInt2] = null;
    if (localG == null)
    {
      this.G[paramInt1] = paramG;
      paramG.L[paramInt2] = null;
    }
    else
    {
      paramG.L[paramInt2] = localG;
      if (B(localG) == A(localG)) {
        localG.J[paramInt2] = paramG;
      } else {
        localG.J[(this != B(localG) ? 1 : 0)] = paramG;
      }
    }
    this.E[paramInt1] = paramG;
    this.H[paramInt1] += 1;
  }
  
  void B(G paramG, int paramInt1, int paramInt2)
  {
    G localG1 = paramG.J[paramInt2];
    G localG2 = paramG.L[paramInt2];
    if (localG1 == null) {
      this.E[paramInt1] = localG2;
    } else {
      localG1.L[(!localG1.D(this) ? 1 : 0)] = localG2;
    }
    if (localG2 == null) {
      this.G[paramInt1] = localG1;
    } else {
      localG2.J[(!localG2.D(this) ? 1 : 0)] = localG1;
    }
    this.H[paramInt1] -= 1;
  }
  
  void D()
  {
    for (int i = 0; i <= 1; i++)
    {
      this.G[i] = null;
      this.E[i] = null;
      this.H[i] = 0;
    }
  }
  
  void A(Comparator paramComparator, int paramInt, G[] paramArrayOfG)
  {
    if (this.H[paramInt] < 2) {
      return;
    }
    int i = this.H[paramInt];
    int j = 0;
    for (G localG1 = this.G[paramInt]; localG1 != null; localG1 = localG1.J[paramInt])
    {
      paramArrayOfG[j] = localG1;
      j++;
    }
    Arrays.sort(paramArrayOfG, 0, i, paramComparator);
    G localG2 = this.G[paramInt] =  = paramArrayOfG[0];
    localG2.L[paramInt] = null;
    int k = 1;
    while (k < i)
    {
      localG1 = paramArrayOfG[k];
      localG1.L[paramInt] = localG2;
      localG2.J[paramInt] = localG1;
      k++;
      localG2 = localG1;
    }
    this.E[paramInt] = localG1;
    localG1.J[paramInt] = null;
  }
  
  class _B
    implements R
  {
    int B;
    G C;
    
    public boolean C()
    {
      return this.C != null;
    }
    
    public void B()
    {
      this.C = this.C.J[this.B];
    }
    
    public void G()
    {
      this.C = this.C.L[this.B];
    }
    
    public void E()
    {
      this.C = O.this.G[this.B];
    }
    
    public void A()
    {
      this.C = O.this.E[this.B];
    }
    
    public int F()
    {
      return O.this.H[this.B];
    }
    
    public Object D()
    {
      return this.C;
    }
    
    public G I()
    {
      return this.C;
    }
    
    _B(int paramInt)
    {
      this.B = paramInt;
      this.C = O.this.G[paramInt];
    }
  }
  
  class _C
    extends O._B
    implements D
  {
    int D = paramInt != 1 ? 1 : 0;
    
    public Object D()
    {
      return H();
    }
    
    public O H()
    {
      return this.D != 0 ? this.C.N : this.C.K;
    }
    
    _C(int paramInt)
    {
      super(paramInt);
    }
  }
  
  class _D
    implements R
  {
    int E;
    G F;
    
    public void B()
    {
      this.F = this.F.J[this.E];
      if ((this.F == null) && (this.E == 0))
      {
        this.F = O.this.G[1];
        this.E = 1;
      }
    }
    
    public void G()
    {
      this.F = this.F.L[this.E];
      if ((this.F == null) && (this.E == 1))
      {
        this.F = O.this.E[0];
        this.E = 0;
      }
    }
    
    public void E()
    {
      this.F = O.this.G[0];
      if (this.F == null)
      {
        this.F = O.this.G[1];
        this.E = 1;
      }
      else
      {
        this.E = 0;
      }
    }
    
    public void A()
    {
      this.F = O.this.E[1];
      if (this.F == null)
      {
        this.F = O.this.E[0];
        this.E = 0;
      }
      else
      {
        this.E = 1;
      }
    }
    
    public boolean C()
    {
      return this.F != null;
    }
    
    public Object D()
    {
      return this.F;
    }
    
    public G I()
    {
      return this.F;
    }
    
    public int F()
    {
      return O.this.G();
    }
    
    _D()
    {
      E();
    }
  }
  
  class _A
    extends O._D
    implements D
  {
    _A()
    {
      super();
    }
    
    public Object D()
    {
      return this.F.E(O.this);
    }
    
    public O H()
    {
      return this.F.E(O.this);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.O
 * JD-Core Version:    0.7.0.1
 */
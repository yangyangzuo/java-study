package twaver.base.A.D.E.B;

public class I
{
  private long A;
  private long B;
  private boolean C = true;
  
  public I()
  {
    this(true);
  }
  
  public I(boolean paramBoolean)
  {
    if (paramBoolean) {
      D();
    }
  }
  
  public void D()
  {
    if (this.C)
    {
      this.A = B();
      this.C = false;
    }
  }
  
  public void A()
  {
    if (!this.C)
    {
      this.B += B() - this.A;
      this.C = true;
    }
  }
  
  public long C()
  {
    if (this.C) {
      return this.B;
    }
    return this.B + B() - this.A;
  }
  
  private long B()
  {
    return System.currentTimeMillis();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.I
 * JD-Core Version:    0.7.0.1
 */
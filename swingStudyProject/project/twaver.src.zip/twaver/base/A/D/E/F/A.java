package twaver.base.A.D.E.F;

import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.D;

public abstract interface A
{
  public abstract D A(C paramC);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.A
 * JD-Core Version:    0.7.0.1
 */
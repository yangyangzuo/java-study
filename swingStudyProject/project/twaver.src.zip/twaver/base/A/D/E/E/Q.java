package twaver.base.A.D.E.E;

public class Q
  extends S
{
  public Q() {}
  
  public Q(D paramD)
  {
    super(paramD);
  }
  
  public Q(O[] paramArrayOfO)
  {
    for (int i = 0; i < paramArrayOfO.length; i++) {
      D(paramArrayOfO[i]);
    }
  }
  
  public D P()
  {
    return new _A();
  }
  
  public O O()
  {
    return (O)E();
  }
  
  public O Q()
  {
    return (O)H();
  }
  
  public O N()
  {
    return (O)A();
  }
  
  class _A
    extends S._A
    implements D
  {
    _A()
    {
      super();
    }
    
    public O H()
    {
      return (O)D();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.Q
 * JD-Core Version:    0.7.0.1
 */
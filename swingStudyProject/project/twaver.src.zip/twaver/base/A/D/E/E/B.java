package twaver.base.A.D.E.E;

final class B
  implements I
{
  int J;
  boolean K = false;
  J L;
  
  B(int paramInt, J paramJ)
  {
    this.J = paramInt;
    this.L = paramJ;
  }
  
  public void B(Object paramObject1, Object paramObject2)
  {
    try
    {
      ((N)paramObject1).A[this.J] = paramObject2;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject1;
      this.L.A(localN, localN.A.length, this.L.A);
      B(paramObject1, paramObject2);
    }
  }
  
  public Object D(Object paramObject)
  {
    return ((N)paramObject).A[this.J];
  }
  
  public void B(Object paramObject, boolean paramBoolean)
  {
    try
    {
      ((N)paramObject).A[this.J] = (paramBoolean ? Boolean.TRUE : Boolean.FALSE);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.L.A(localN, localN.A.length, this.L.A);
      B(paramObject, paramBoolean);
    }
  }
  
  public boolean B(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.J];
    if (localObject == null) {
      return false;
    }
    return ((Boolean)localObject).booleanValue();
  }
  
  public void B(Object paramObject, int paramInt)
  {
    try
    {
      ((N)paramObject).A[this.J] = new Integer(paramInt);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.L.A(localN, localN.A.length, this.L.A);
      B(paramObject, paramInt);
    }
  }
  
  public int A(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.J];
    if (localObject == null) {
      return 0;
    }
    return ((Integer)localObject).intValue();
  }
  
  public void B(Object paramObject, double paramDouble)
  {
    try
    {
      ((N)paramObject).A[this.J] = new Double(paramDouble);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      N localN = (N)paramObject;
      this.L.A(localN, localN.A.length, this.L.A);
      B(paramObject, paramDouble);
    }
  }
  
  public double C(Object paramObject)
  {
    Object localObject = ((N)paramObject).A[this.J];
    if (localObject == null) {
      return 0.0D;
    }
    return ((Double)localObject).doubleValue();
  }
  
  public boolean D()
  {
    return this.K;
  }
  
  public void C()
  {
    this.K = true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.util.Comparator;
import java.util.Vector;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

public class L
{
  public static void A(K paramK)
  {
    if (paramK.B() > 0)
    {
      localObject = new Vector(paramK.B());
      for (int i = paramK.B() - 1; i >= 0; i--) {
        ((Vector)localObject).add(paramK.A(i));
      }
      paramK.A();
      for (i = 0; i < ((Vector)localObject).size(); i++)
      {
        E localE = (E)((Vector)localObject).get(i);
        paramK.A(localE.B(), localE.A());
      }
    }
    Object localObject = paramK.D();
    paramK.B(paramK.C());
    paramK.A((E)localObject);
  }
  
  public static void A(C paramC)
  {
    A(paramC, true);
  }
  
  public static void A(C paramC, boolean paramBoolean)
  {
    R localR;
    if (paramBoolean)
    {
      localR = paramC.M();
      while (localR.C())
      {
        twaver.base.A.D.E.E.G localG = localR.I();
        paramC.D(localG, T.G);
        paramC.C(localG, T.G);
        paramC.A(localG, T.E);
        localR.B();
      }
    }
    else
    {
      localR = paramC.M();
      while (localR.C())
      {
        paramC.A(localR.I(), T.E);
        localR.B();
      }
    }
  }
  
  public static void B(C paramC)
  {
    E localE = new E(0.0D, 0.0D);
    R localR = paramC.M();
    while (localR.C())
    {
      twaver.base.A.D.E.E.G localG = localR.I();
      paramC.D(localG, localE);
      paramC.C(localG, localE);
      localR.B();
    }
  }
  
  public static void A(C paramC, twaver.base.A.D.E.E.G paramG1, twaver.base.A.D.E.E.G paramG2, double paramDouble)
  {
    int i = paramC.J(paramG1).D();
    E[] arrayOfE = new E[i];
    int j = 0;
    Object localObject1 = paramC.J(paramG1).B();
    while (((twaver.base.A.D.E.E.F)localObject1).C())
    {
      localObject2 = (E)((twaver.base.A.D.E.E.F)localObject1).D();
      if ((j <= 0) || (!((E)localObject2).equals(arrayOfE[(j - 1)])))
      {
        arrayOfE[j] = new E(((E)localObject2).B(), ((E)localObject2).A());
        j++;
      }
      ((twaver.base.A.D.E.E.F)localObject1).B();
    }
    i = j;
    if (i < 2) {
      return;
    }
    localObject1 = new Vector(i);
    Object localObject2 = new twaver.base.A.D.E.C.F(arrayOfE[1], arrayOfE[0]);
    twaver.base.A.D.E.C.F localF1 = twaver.base.A.D.E.C.F.A((twaver.base.A.D.E.C.F)localObject2);
    localF1.A(paramDouble);
    E localE1 = twaver.base.A.D.E.C.F.A(arrayOfE[0], localF1);
    E localE2 = twaver.base.A.D.E.C.F.A(arrayOfE[1], localF1);
    twaver.base.A.D.E.C.C localC = new twaver.base.A.D.E.C.C(localE1, localE2);
    for (int k = 1; k < i - 1; k++)
    {
      localObject3 = localC;
      localObject4 = twaver.base.A.D.E.C.F.A(new twaver.base.A.D.E.C.F(arrayOfE[(k + 1)], arrayOfE[k]));
      ((twaver.base.A.D.E.C.F)localObject4).A(paramDouble);
      E localE3 = twaver.base.A.D.E.C.F.A(arrayOfE[k], (twaver.base.A.D.E.C.F)localObject4);
      E localE4 = twaver.base.A.D.E.C.F.A(arrayOfE[(k + 1)], (twaver.base.A.D.E.C.F)localObject4);
      localC = new twaver.base.A.D.E.C.C(localE3, localE4);
      E localE5 = twaver.base.A.D.E.C.C.A((twaver.base.A.D.E.C.C)localObject3, localC);
      if (localE5 != null) {
        ((Vector)localObject1).addElement(new E(localE5.B(), localE5.A()));
      }
    }
    twaver.base.A.D.E.C.F localF2 = new twaver.base.A.D.E.C.F(arrayOfE[(i - 1)], arrayOfE[(i - 2)]);
    localF2 = twaver.base.A.D.E.C.F.A(localF2);
    localF2.A(paramDouble);
    Object localObject3 = twaver.base.A.D.E.C.F.A(arrayOfE[(i - 1)], localF2);
    Object localObject4 = new twaver.base.A.D.E.C.G((Vector)localObject1);
    if (paramG1.W().equals(paramG2.W()))
    {
      paramC.A(paramG2, (twaver.base.A.D.E.C.G)localObject4);
      paramC.A(paramG2, localE1, (E)localObject3);
    }
    else
    {
      paramC.A(paramG2, ((twaver.base.A.D.E.C.G)localObject4).A());
      paramC.A(paramG2, (E)localObject3, localE1);
    }
  }
  
  public static void A(C paramC, twaver.base.A.D.E.E.G paramG, A paramA, double paramDouble)
  {
    double d = paramDouble;
    R localR = paramA.J();
    while (localR.C())
    {
      twaver.base.A.D.E.E.G localG = localR.I();
      A(paramC, paramG, localG, d);
      if (d < 0.0D) {
        d -= paramDouble;
      }
      d = -d;
      localR.B();
    }
  }
  
  public static final int A(Rectangle2D[] paramArrayOfRectangle2D, Rectangle2D paramRectangle2D, double paramDouble)
  {
    return A(paramArrayOfRectangle2D, paramRectangle2D, paramDouble, 1);
  }
  
  public static final Dimension B(Rectangle2D[] paramArrayOfRectangle2D, Rectangle2D paramRectangle2D, double paramDouble)
  {
    if ((paramArrayOfRectangle2D == null) || (paramArrayOfRectangle2D.length < 1))
    {
      if (paramRectangle2D != null) {
        paramRectangle2D.setFrame(0.0D, 0.0D, 0.0D, 0.0D);
      }
      return new Dimension(0, 0);
    }
    double d1 = 0.0D;
    double d2 = 0.0D;
    for (int i = 0; i < paramArrayOfRectangle2D.length; i++)
    {
      Rectangle2D localRectangle2D = paramArrayOfRectangle2D[i];
      d1 = Math.max(d1, localRectangle2D.getWidth());
      d2 = Math.max(d2, localRectangle2D.getHeight());
    }
    double d3 = d1 * d2 * paramArrayOfRectangle2D.length;
    double d4 = Math.sqrt(d3 / paramDouble);
    double d5 = d3 / d4;
    int j = (int)Math.floor(d5 / d1);
    int k = (int)Math.ceil(d5 / d1);
    int m = (int)Math.ceil(paramArrayOfRectangle2D.length / j);
    int n = (int)Math.ceil(paramArrayOfRectangle2D.length / k);
    int i1;
    int i2;
    if (j * m < k * n)
    {
      i1 = j;
      i2 = m;
    }
    else
    {
      i1 = k;
      i2 = n;
    }
    int i3 = 0;
    int i4 = 0;
    double d6 = 0.0D;
    double d7 = 0.0D;
    int i5;
    if (d1 > d2) {
      for (i5 = 0; i5 < paramArrayOfRectangle2D.length; i5++)
      {
        paramArrayOfRectangle2D[i5].setFrame(i4 * d1, i3 * d2, paramArrayOfRectangle2D[i5].getWidth(), paramArrayOfRectangle2D[i5].getHeight());
        d6 = Math.max(d6, paramArrayOfRectangle2D[i5].getMaxX());
        d7 = Math.max(d7, paramArrayOfRectangle2D[i5].getMaxY());
        i4++;
        if (i4 >= i1)
        {
          i3++;
          i4 = 0;
        }
      }
    } else {
      for (i5 = 0; i5 < paramArrayOfRectangle2D.length; i5++)
      {
        paramArrayOfRectangle2D[i5].setFrame(i4 * d1, i3 * d2, paramArrayOfRectangle2D[i5].getWidth(), paramArrayOfRectangle2D[i5].getHeight());
        d6 = Math.max(d6, paramArrayOfRectangle2D[i5].getMaxX());
        d7 = Math.max(d7, paramArrayOfRectangle2D[i5].getMaxY());
        i3++;
        if (i3 >= i2)
        {
          i4++;
          i3 = 0;
        }
      }
    }
    if (paramRectangle2D != null) {
      paramRectangle2D.setFrame(0.0D, 0.0D, d6, d7);
    }
    return new Dimension(i2, i1);
  }
  
  public static final int A(Rectangle2D[] paramArrayOfRectangle2D, Rectangle2D paramRectangle2D, double paramDouble, int paramInt)
  {
    if ((paramArrayOfRectangle2D == null) || (paramArrayOfRectangle2D.length < 1))
    {
      if (paramRectangle2D != null) {
        paramRectangle2D.setFrame(0.0D, 0.0D, 0.0D, 0.0D);
      }
      return 0;
    }
    double d1;
    double d2 = d1 = paramArrayOfRectangle2D[0].getWidth();
    double d3;
    double d4 = d3 = paramArrayOfRectangle2D[0].getHeight();
    for (int i = 1; i < paramArrayOfRectangle2D.length; i++)
    {
      double d5 = paramArrayOfRectangle2D[i].getWidth();
      d2 = Math.min(d2, d5);
      d1 = Math.max(d1, d5);
      double d7 = paramArrayOfRectangle2D[i].getHeight();
      d4 = Math.min(d4, d7);
      d3 = Math.max(d3, d7);
    }
    if ((d4 / d3 > 0.95D) && (d2 / d1 > 0.95D)) {
      return B(paramArrayOfRectangle2D, paramRectangle2D, paramDouble).width;
    }
    S localS1 = new S();
    int j = 0;
    for (int k = 0; k < paramArrayOfRectangle2D.length; k++)
    {
      Rectangle2D localRectangle2D1 = paramArrayOfRectangle2D[k];
      localS1.add(paramArrayOfRectangle2D[k]);
      j = (int)(j + localRectangle2D1.getWidth() * localRectangle2D1.getHeight());
    }
    localS1.A(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Rectangle2D localRectangle2D1 = (Rectangle2D)paramAnonymousObject1;
        Rectangle2D localRectangle2D2 = (Rectangle2D)paramAnonymousObject2;
        int i = (int)localRectangle2D2.getHeight() - (int)localRectangle2D1.getHeight();
        if (i == 0) {
          return (int)localRectangle2D2.getWidth() - (int)localRectangle2D1.getWidth();
        }
        return i;
      }
    });
    double d6 = 0.0D;
    double d8 = 0.0D;
    int m = (int)(paramDouble * Math.sqrt(j / paramDouble));
    int n = m;
    int i1 = 0;
    S localS2 = new S();
    Object localObject;
    do
    {
      S localS3 = new S();
      localS2.add(localS3);
      int i2;
      int i4 = i2 = i3 = 0;
      twaver.base.A.D.E.E.F localF2 = localS1.F();
      while (localF2.C())
      {
        localObject = (Rectangle2D)localF2.D();
        if ((i4 + ((Rectangle2D)localObject).getWidth() > n) && (localS3.size() > 0))
        {
          i3 = Math.max(i3, i4);
          localS3 = new S();
          localS3.add(localObject);
          localS2.add(localS3);
          i4 = (int)((Rectangle2D)localObject).getWidth();
        }
        else
        {
          localS3.add(localObject);
          i4 = (int)(i4 + ((Rectangle2D)localObject).getWidth());
        }
        if (localS3.size() == 1) {
          i2 = (int)(i2 + ((Rectangle2D)localS3.E()).getHeight());
        }
        localF2.B();
      }
      int i3 = Math.max(i3, i4);
      if ((paramDouble * i2 > i3) && (i1 != i3))
      {
        localS2.clear();
        n = (int)(n * 1.1D);
        i1 = i3;
      }
    } while (localS2.isEmpty());
    double d9 = 0.0D;
    twaver.base.A.D.E.E.F localF1 = localS2.F();
    while (localF1.C())
    {
      double d10 = 0.0D;
      localObject = (S)localF1.D();
      twaver.base.A.D.E.E.F localF3 = ((S)localObject).F();
      while (localF3.C())
      {
        Rectangle2D localRectangle2D2 = (Rectangle2D)localF3.D();
        localRectangle2D2.setFrame(d10, d9, localRectangle2D2.getWidth(), localRectangle2D2.getHeight());
        d10 += localRectangle2D2.getWidth();
        localF3.B();
      }
      d6 = Math.max(d6, d10);
      d9 += A((S)localObject);
      d8 = Math.max(d8, d9);
      localF1.B();
    }
    if (paramRectangle2D != null) {
      paramRectangle2D.setFrame(0.0D, 0.0D, d6, d8);
    }
    return localS2.size();
  }
  
  private static double A(S paramS)
  {
    double d = 0.0D;
    twaver.base.A.D.E.E.F localF = paramS.F();
    while (localF.C())
    {
      d = Math.max(((Rectangle2D)localF.D()).getHeight(), d);
      localF.B();
    }
    return d;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.L
 * JD-Core Version:    0.7.0.1
 */
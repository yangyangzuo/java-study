package twaver.base.A.D.E.A;

import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

class E
  extends G
{
  D P;
  
  protected E(I paramI, O paramO1, G paramG1, O paramO2, G paramG2, int paramInt1, int paramInt2, D paramD)
  {
    super(paramI, paramO1, paramG1, paramO2, paramG2, paramInt1, paramInt2);
    if (paramD != null) {
      this.P = paramD;
    }
  }
  
  protected void Q()
  {
    super.Q();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.E
 * JD-Core Version:    0.7.0.1
 */
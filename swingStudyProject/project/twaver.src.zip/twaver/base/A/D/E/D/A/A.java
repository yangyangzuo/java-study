package twaver.base.A.D.E.D.A;

import java.util.Comparator;
import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.D.E;
import twaver.base.A.D.E.D.L;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.S;

public class A
  extends E
{
  private D Ì;
  private C Í;
  private double Ë = 20.0D;
  private double Ê = 40.0D;
  private Comparator É = new B();
  private I È;
  
  public boolean M(C paramC)
  {
    return twaver.base.A.D.E.F.F.D(paramC);
  }
  
  public void N(C paramC)
  {
    if (!M(paramC)) {
      throw new IllegalArgumentException();
    }
    twaver.base.A.D.E.E.A localA = twaver.base.A.D.E.F.F.A(paramC);
    this.Í = paramC;
    this.Ì = new D(paramC);
    L.A(paramC);
    this.È = paramC.H();
    Object localObject;
    if (!paramC.D())
    {
      I();
      localObject = this.Ì.A();
      N((O)localObject);
      A(this.Ì);
      B(this.Ì);
    }
    while (!localA.isEmpty())
    {
      localObject = localA.K();
      L.A(paramC.M((G)localObject));
      paramC.G((G)localObject);
    }
  }
  
  private void I()
  {
    if (this.É != null)
    {
      twaver.base.A.D.E.E.D localD = this.Í.J();
      while (localD.C())
      {
        localD.H().A(this.É);
        localD.B();
      }
    }
  }
  
  private void B(D paramD)
  {
    S[] arrayOfS = C(paramD);
    double[] arrayOfDouble = new double[arrayOfS.length];
    twaver.base.A.D.E.E.F localF;
    O localO;
    for (int i = 0; i < arrayOfS.length; i++)
    {
      S localS1 = arrayOfS[i];
      double d2 = 0.0D;
      localF = localS1.F();
      while (localF.C())
      {
        localO = (O)localF.D();
        d2 = Math.max(d2, this.Í.Q(localO));
        localF.B();
      }
      arrayOfDouble[i] = d2;
    }
    double d1 = -this.Ê;
    for (int j = 0; j < arrayOfS.length; j++)
    {
      d1 += this.Ê + arrayOfDouble[j];
      S localS2 = arrayOfS[j];
      localF = localS2.F();
      while (localF.C())
      {
        localO = (O)localF.D();
        this.Í.A(localO, this.Í.K(localO), d1 - arrayOfDouble[j] / 2.0D);
        localF.B();
      }
    }
  }
  
  private S[] C(D paramD)
  {
    S[] arrayOfS = new S[paramD.B()];
    for (int i = 0; i < arrayOfS.length; i++) {
      arrayOfS[i] = new S();
    }
    paramD.A();
    A(paramD.A(), 0, arrayOfS);
    return arrayOfS;
  }
  
  private void A(O paramO, int paramInt, S[] paramArrayOfS)
  {
    paramArrayOfS[paramInt].D(paramO);
    twaver.base.A.D.E.E.D localD = paramO.J();
    while (localD.C())
    {
      A(localD.H(), paramInt + 1, paramArrayOfS);
      localD.B();
    }
  }
  
  private void A(D paramD)
  {
    O localO = paramD.A();
    this.Í.A(localO, 0.0D, this.Í.H(localO));
    M(localO);
  }
  
  private void M(O paramO)
  {
    twaver.base.A.D.E.E.D localD = paramO.J();
    while (localD.C())
    {
      O localO = localD.H();
      _A local_A = (_A)this.È.D(localO);
      this.Í.A(localO, this.Í.K(paramO) + local_A.C, this.Í.H(localO));
      M(localO);
      localD.B();
    }
  }
  
  private void N(O paramO)
  {
    if (this.Ì.A(paramO))
    {
      this.È.B(paramO, new _A(paramO));
      return;
    }
    twaver.base.A.D.E.E.D localD1 = paramO.J();
    O localO1 = localD1.H();
    localD1.B();
    N(localO1);
    _A local_A1 = (_A)this.È.D(localO1);
    _A local_A2 = new _A(local_A1.B, local_A1.A, 0.0D);
    if (!localD1.C())
    {
      local_A2.B.A(new _B(this.Í.L(paramO) / 2.0D, 0.0D));
      local_A2.A.A(new _B(this.Í.L(paramO) / 2.0D, 0.0D));
      this.È.B(paramO, local_A2);
      return;
    }
    while (localD1.C())
    {
      localO1 = localD1.H();
      localD1.B();
      N(localO1);
      local_A1 = (_A)this.È.D(localO1);
      twaver.base.A.D.E.E.F localF1 = local_A2.A.F();
      twaver.base.A.D.E.E.F localF2 = local_A1.B.F();
      double d2 = 2147483647.0D;
      double d3 = 0.0D;
      double d4 = 0.0D;
      while ((localF1.C()) && (localF2.C()))
      {
        local_B2 = (_B)localF1.D();
        localF1.B();
        _B local_B3 = (_B)localF2.D();
        localF2.B();
        d4 += local_B2.B;
        d3 += local_B3.B;
        d2 = Math.min(d2, d3 - d4 - local_B2.A - local_B3.A);
      }
      local_A1.C = (this.Ë - d2);
      d3 += local_A1.C;
      _B local_B2 = (_B)local_A1.A.E();
      local_B2.B = local_A1.C;
      double d5;
      _B local_B4;
      if ((localF1.C()) && (!localF2.C()))
      {
        for (d5 = d4 - A(local_A1.A); localF1.C(); d5 = 0.0D)
        {
          local_B4 = (_B)localF1.D();
          localF1.B();
          local_A1.A.D(new _B(local_B4.A, local_B4.B + d5));
        }
      }
      else if ((!localF1.C()) && (localF2.C()))
      {
        d5 = A(local_A2.B);
        for (d5 = d3 - d5; localF2.C(); d5 = 0.0D)
        {
          local_B4 = (_B)localF2.D();
          localF2.B();
          local_A2.B.D(new _B(local_B4.A, local_B4.B + d5));
        }
      }
      local_A2.A = local_A1.A;
    }
    this.È.B(paramO, local_A2);
    double d1 = -local_A1.C / 2.0D;
    twaver.base.A.D.E.E.D localD2 = paramO.J();
    while (localD2.C())
    {
      O localO2 = localD2.H();
      localD2.B();
      _A local_A3 = (_A)this.È.D(localO2);
      local_A3.C += d1;
      _B local_B1 = (_B)local_A3.A.E();
      local_B1.B += d1;
      local_B1 = (_B)local_A3.B.E();
      local_B1.B += d1;
    }
    local_A2.B.A(new _B(this.Í.L(paramO) / 2.0D, 0.0D));
    local_A2.A.A(new _B(this.Í.L(paramO) / 2.0D, 0.0D));
  }
  
  private double A(S paramS)
  {
    double d = 0.0D;
    twaver.base.A.D.E.E.F localF = paramS.F();
    while (localF.C())
    {
      _B local_B = (_B)localF.D();
      d += local_B.B;
      localF.B();
    }
    return d;
  }
  
  class _B
  {
    double A;
    double B;
    
    _B(double paramDouble1, double paramDouble2)
    {
      this.A = paramDouble1;
      this.B = paramDouble2;
    }
  }
  
  class _A
  {
    double C;
    S A;
    S B;
    
    _A()
    {
      this(new S(), new S(), 0.0D);
    }
    
    _A(O paramO)
    {
      this();
      A._B local_B = new A._B(A.this, A.this.Í.L(paramO) / 2.0D, 0.0D);
      this.B.A(local_B);
      local_B = new A._B(A.this, A.this.Í.L(paramO) / 2.0D, 0.0D);
      this.A.A(local_B);
    }
    
    _A(S paramS1, S paramS2, double paramDouble)
    {
      this.B = paramS1;
      this.A = paramS2;
      this.C = paramDouble;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.A.A
 * JD-Core Version:    0.7.0.1
 */
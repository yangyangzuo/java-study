package twaver.base.A.D.E.C;

public class A
  extends D
{
  public final double C;
  public final double D;
  
  public A(E paramE, D paramD)
  {
    this(paramE.A, paramE.B, paramD.B, paramD.A);
  }
  
  public A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    super(paramDouble3, paramDouble4);
    this.C = paramDouble1;
    this.D = paramDouble2;
  }
  
  public final double D()
  {
    return this.C;
  }
  
  public final double C()
  {
    return this.D;
  }
  
  public int hashCode()
  {
    long l = Double.doubleToRawLongBits(this.C) >> 1 ^ Double.doubleToRawLongBits(this.D);
    return super.hashCode() << 1 ^ (int)(l ^ l >> 32);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof A)) {
      return false;
    }
    A localA = (A)paramObject;
    return (localA.C == this.C) && (localA.D == this.D) && (localA.B == this.B) && (localA.A == this.A);
  }
  
  public int compareTo(Object paramObject)
  {
    A localA = (A)paramObject;
    if (this.C < localA.C) {
      return -1;
    }
    if (this.C > localA.C) {
      return 1;
    }
    if (this.D < localA.D) {
      return -1;
    }
    if (this.D > localA.D) {
      return 1;
    }
    return super.compareTo(paramObject);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.A
 * JD-Core Version:    0.7.0.1
 */
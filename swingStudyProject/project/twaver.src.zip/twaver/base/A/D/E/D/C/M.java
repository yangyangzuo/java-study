package twaver.base.A.D.E.D.C;

import java.util.Arrays;
import java.util.Comparator;
import twaver.base.A.D.E.B.A;
import twaver.base.A.D.E.B.E;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

public class M
  implements B
{
  private I K;
  private twaver.base.A.D.E.E.M[] B;
  private int[] L;
  private O[] G;
  private double[] E;
  private Comparator C;
  private twaver.base.A.D.E.E.C O;
  private Q[] N;
  private E A;
  private long M;
  private long J;
  private Comparator F;
  private Comparator D;
  private Comparator I;
  private Comparator H;
  
  public void A(long paramLong)
  {
    this.M = paramLong;
  }
  
  public Q[] A(twaver.base.A.D.E.D.C paramC, I paramI, int paramInt)
  {
    A(paramC, paramI, paramInt);
    A(false);
    int i = J();
    if ((H()) && (i > 0))
    {
      int[] arrayOfInt = D();
      for (int j = 0; (j < 20) && (i > 0) && (H()); j++)
      {
        A(true);
        int k = J();
        if (k < i)
        {
          A(arrayOfInt);
          i = k;
        }
      }
      B(arrayOfInt);
      I();
    }
    return A();
  }
  
  private void A(twaver.base.A.D.E.E.C paramC, I paramI, int paramInt)
  {
    this.J = System.currentTimeMillis();
    this.O = paramC;
    this.K = paramI;
    this.C = new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        double d = M.this.E[((O)paramAnonymousObject1).F()] - M.this.E[((O)paramAnonymousObject2).F()];
        if (d > 0.0D) {
          return 1;
        }
        return d >= 0.0D ? 0 : -1;
      }
    };
    this.A = new E();
    this.N = new Q[paramInt];
    for (int i = 0; i < this.N.length; i++) {
      this.N[i] = new Q();
    }
    this.L = new int[this.O.B()];
    this.G = new O[this.O.B()];
    this.E = new double[this.O.B() + 1];
    this.D = new K(this.L, (byte)1);
    this.F = new K(this.L, (byte)0);
    this.I = new K(this.L, (byte)3);
    this.H = new K(this.L, (byte)4);
    this.O.A(this.H, this.I);
  }
  
  private Q[] A()
  {
    this.K = null;
    this.B = null;
    this.G = null;
    this.E = null;
    this.C = null;
    this.D = null;
    this.F = null;
    this.O = null;
    Q[] arrayOfQ = this.N;
    this.N = null;
    return arrayOfQ;
  }
  
  private boolean H()
  {
    long l = System.currentTimeMillis() - this.J;
    return l <= this.M;
  }
  
  private void F()
  {
    D localD1 = this.O.J();
    while (localD1.C())
    {
      D localD2 = localD1.H().J();
      while (localD2.C())
      {
        this.E[localD2.H().F()] = this.A.nextInt();
        localD2.B();
      }
      localD1.H().A(new Comparator()
      {
        public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
        {
          return (int)M.this.E[((G)paramAnonymousObject1).T().F()] - (int)M.this.E[((G)paramAnonymousObject2).T().F()];
        }
      });
      localD1.B();
    }
  }
  
  private void A(boolean paramBoolean)
  {
    for (int i = 0; i < this.N.length; i++) {
      this.N[i].clear();
    }
    if (paramBoolean)
    {
      F();
      Arrays.fill(this.L, 0);
      this.O.A(null, this.I);
    }
    O localO = this.O.I();
    this.K.B(localO, 0);
    Object localObject = this.O.J();
    while (((D)localObject).C())
    {
      if ((((D)localObject).H().C() == 0) && (((D)localObject).H() != localO)) {
        this.O.A(localO, ((D)localObject).H());
      }
      ((D)localObject).B();
    }
    localObject = new twaver.base.A.D.E.F.C()
    {
      public void A(O paramAnonymousO, int paramAnonymousInt)
      {
        int i = M.this.K.A(paramAnonymousO);
        M.this.N[i].D(paramAnonymousO);
      }
    };
    ((twaver.base.A.D.E.F.C)localObject).B(true);
    ((twaver.base.A.D.E.F.C)localObject).A(this.O, localO);
    this.N[0].A();
    this.O.B(localO);
    B();
  }
  
  private int M()
  {
    this.O.A(this.D, this.F);
    int i = 0;
    for (int j = 1; j < this.N.length; j++)
    {
      int k = A(this.N[(j - 1)], this.N[j]);
      i += k;
    }
    j = 0;
    i += j;
    return i;
  }
  
  private int A(S paramS1, S paramS2)
  {
    F localF1 = paramS1.F();
    F localF2 = paramS2.F();
    S localS1 = new S();
    S localS2 = new S();
    this.B = new twaver.base.A.D.E.E.M[this.O.B()];
    int i = 0;
    do
    {
      i += A((O)localF1.D(), localS1, localS2, true);
      i += A((O)localF2.D(), localS2, localS1, false);
      localF1.B();
      localF2.B();
      if (!localF1.C()) {
        break;
      }
    } while (localF2.C());
    while (localF1.C())
    {
      i += A((O)localF1.D(), localS1, localS2, true);
      localF1.B();
    }
    while (localF2.C())
    {
      i += A((O)localF2.D(), localS2, localS1, false);
      localF2.B();
    }
    return i;
  }
  
  private int A(O paramO, S paramS1, S paramS2, boolean paramBoolean)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    Object localObject;
    O localO;
    if (this.B[paramO.F()] != null)
    {
      twaver.base.A.D.E.E.M localM = this.B[paramO.F()].A();
      for (localObject = paramS1.G(); localObject != localM; localObject = ((twaver.base.A.D.E.E.M)localObject).A())
      {
        localO = (O)paramS1.A((twaver.base.A.D.E.E.M)localObject);
        if (localO == paramO)
        {
          i++;
          k += j;
          paramS1.F((twaver.base.A.D.E.E.M)localObject);
        }
        else
        {
          j++;
        }
      }
    }
    int m = i * paramS2.size() + k;
    if (paramBoolean) {
      for (localObject = paramO.K(); localObject != null; localObject = ((G)localObject).V())
      {
        localO = ((G)localObject).T();
        if (this.L[localO.F()] >= this.L[paramO.F()]) {
          this.B[localO.F()] = paramS2.D(localO);
        }
      }
    } else {
      for (localObject = paramO.L(); localObject != null; localObject = ((G)localObject).S())
      {
        localO = ((G)localObject).W();
        if (this.L[localO.F()] > this.L[paramO.F()]) {
          this.B[localO.F()] = paramS2.D(localO);
        }
      }
    }
    return m;
  }
  
  private int J()
  {
    T.A();
    int[] arrayOfInt = D();
    int i = M();
    int j = 1;
    int k = 0;
    int m;
    while ((k < 3) && (H()) && (i > 0))
    {
      m = E();
      if (m < i)
      {
        A(arrayOfInt);
        i = m;
      }
      else
      {
        k++;
      }
      j = j != 0 ? 0 : 1;
    }
    B(arrayOfInt);
    I();
    if (i > 0)
    {
      k = 1;
      for (m = 0; (k == 1) && (i > 0); m++)
      {
        C();
        K();
        int n = M();
        if (n < i)
        {
          k = 1;
          A(arrayOfInt);
        }
        else
        {
          k = -1;
        }
        i = n;
      }
      B(arrayOfInt);
      I();
    }
    return i;
  }
  
  private void C()
  {
    twaver.base.A.D.E.E.K localK = G();
    int[] arrayOfInt = D();
    S[][] arrayOfS; = new S[this.O.B()][];
    Object localObject1;
    Object localObject2;
    Object localObject3;
    int j;
    int k;
    for (int i = this.N.length - 1; i >= 0; i--)
    {
      localObject1 = this.N[i].F();
      while (((F)localObject1).C())
      {
        localObject2 = (O)((F)localObject1).D();
        if ((((O)localObject2).C() == 1) && (((O)localObject2).O() == 1))
        {
          localObject3 = (O)localK.D(((O)localObject2).K());
          if ((localObject3 != null) && (arrayOfS;[localObject3.F()] == null))
          {
            j = A((O)localObject2, (O)localObject3);
            k = ((O)localObject3).F();
            S[] arrayOfS = arrayOfS;[k] =  = new S[j + 1];
            for (int n = arrayOfS.length - 1; n >= 0; n--) {
              arrayOfS[n] = new S();
            }
          }
        }
        ((F)localObject1).B();
      }
    }
    Object localObject4;
    for (i = 0; i < this.N.length; i++)
    {
      localObject1 = this.N[i].F();
      while (((F)localObject1).C())
      {
        localObject2 = (O)((F)localObject1).D();
        if ((((O)localObject2).C() == 1) && (((O)localObject2).O() == 1))
        {
          localObject3 = (O)localK.D(((O)localObject2).K());
          if (localObject3 != null)
          {
            j = ((O)localObject3).F();
            k = A((O)localObject2, (O)localObject3) - 1;
            arrayOfS;[j][k].D(((O)localObject2).L());
          }
        }
        else
        {
          for (localObject3 = ((O)localObject2).L(); localObject3 != null; localObject3 = ((G)localObject3).S())
          {
            localObject4 = (O)localK.D(localObject3);
            if (localObject4 != null)
            {
              k = ((O)localObject4).F();
              int m = A((O)localObject2, (O)localObject4) - 1;
              arrayOfS;[k][m].D(localObject3);
            }
          }
        }
        ((F)localObject1).B();
      }
    }
    D localD = this.O.J();
    while (localD.C())
    {
      localObject1 = localD.H();
      if (arrayOfS;[localObject1.F()] != null) {
        for (localObject2 = ((O)localObject1).K(); localObject2 != null; localObject2 = ((G)localObject2).V())
        {
          localObject3 = (O)localK.D(localObject2);
          if (localObject3 != null)
          {
            localObject4 = arrayOfS;[localObject3.F()];
            while (localObject4[0].size() > 0)
            {
              for (k = 0;; k++)
              {
                localG1 = (G)localObject4[k].E();
                localO1 = localG1.T();
                if ((localO1.C() != 1) || (localO1.O() != 1)) {
                  break;
                }
              }
              O localO1 = ((G)localObject4[k].A()).T();
              k--;
              localO1 = localG1.W();
              G localG1 = (G)localObject4[k].A();
              O localO2 = localG1.T();
              while (k >= 0)
              {
                if (arrayOfInt[localO1.F()] != arrayOfInt[localO2.F()]) {
                  this.L[localO1.F()] = arrayOfInt[localO2.F()];
                }
                localO1 = localO1.L().W();
                k--;
                if (k >= 0)
                {
                  G localG2 = (G)localObject4[k].A();
                  localO2 = localG2.T();
                }
              }
            }
          }
        }
      }
      localD.B();
    }
    I();
    this.O.A(localK);
  }
  
  private void K()
  {
    twaver.base.A.D.E.E.K localK = L();
    int[] arrayOfInt = D();
    S[][] arrayOfS; = new S[this.O.B()][];
    Object localObject1;
    Object localObject2;
    Object localObject3;
    int j;
    int k;
    for (int i = 0; i < this.N.length; i++)
    {
      localObject1 = this.N[i].F();
      while (((F)localObject1).C())
      {
        localObject2 = (O)((F)localObject1).D();
        if ((((O)localObject2).C() == 1) && (((O)localObject2).O() == 1))
        {
          localObject3 = (O)localK.D(((O)localObject2).L());
          if ((localObject3 != null) && (arrayOfS;[localObject3.F()] == null))
          {
            j = A((O)localObject3, (O)localObject2);
            k = ((O)localObject3).F();
            S[] arrayOfS = arrayOfS;[k] =  = new S[j + 1];
            for (int n = arrayOfS.length - 1; n >= 0; n--) {
              arrayOfS[n] = new S();
            }
          }
        }
        ((F)localObject1).B();
      }
    }
    Object localObject4;
    for (i = this.N.length - 1; i >= 0; i--)
    {
      localObject1 = this.N[i].F();
      while (((F)localObject1).C())
      {
        localObject2 = (O)((F)localObject1).D();
        if ((((O)localObject2).C() == 1) && (((O)localObject2).O() == 1))
        {
          localObject3 = (O)localK.D(((O)localObject2).L());
          if (localObject3 != null)
          {
            j = ((O)localObject3).F();
            k = A((O)localObject3, (O)localObject2) - 1;
            arrayOfS;[j][k].D(((O)localObject2).K());
          }
        }
        else
        {
          for (localObject3 = ((O)localObject2).K(); localObject3 != null; localObject3 = ((G)localObject3).V())
          {
            localObject4 = (O)localK.D(localObject3);
            if (localObject4 != null)
            {
              k = ((O)localObject4).F();
              int m = A((O)localObject4, (O)localObject2) - 1;
              arrayOfS;[k][m].D(localObject3);
            }
          }
        }
        ((F)localObject1).B();
      }
    }
    D localD = this.O.J();
    while (localD.C())
    {
      localObject1 = localD.H();
      if (arrayOfS;[localObject1.F()] != null) {
        for (localObject2 = ((O)localObject1).L(); localObject2 != null; localObject2 = ((G)localObject2).S())
        {
          localObject3 = (O)localK.D(localObject2);
          if (localObject3 != null)
          {
            localObject4 = arrayOfS;[localObject3.F()];
            while (localObject4[0].size() > 0)
            {
              for (k = 0;; k++)
              {
                localG1 = (G)localObject4[k].E();
                localO1 = localG1.W();
                if ((localO1.C() != 1) || (localO1.O() != 1)) {
                  break;
                }
              }
              O localO1 = ((G)localObject4[k].A()).W();
              k--;
              localO1 = localG1.T();
              G localG1 = (G)localObject4[k].A();
              O localO2 = localG1.W();
              while (k >= 0)
              {
                if (arrayOfInt[localO1.F()] != arrayOfInt[localO2.F()]) {
                  this.L[localO1.F()] = arrayOfInt[localO2.F()];
                }
                localO1 = localO1.K().T();
                k--;
                if (k >= 0)
                {
                  G localG2 = (G)localObject4[k].A();
                  localO2 = localG2.W();
                }
              }
            }
          }
        }
      }
      localD.B();
    }
    I();
    this.O.A(localK);
  }
  
  private int A(O paramO1, O paramO2)
  {
    return this.K.A(paramO1) - this.K.A(paramO2);
  }
  
  private twaver.base.A.D.E.E.K G()
  {
    twaver.base.A.D.E.E.K localK = A.A(new O[this.O.A()]);
    D localD = this.O.J();
    while (localD.C())
    {
      O localO1 = localD.H();
      if (localO1.O() > 1)
      {
        int i = 0;
        Object localObject;
        for (G localG = localO1.K(); localG != null; localG = localG.V())
        {
          localObject = localG.T();
          if ((((O)localObject).C() == 1) && (((O)localObject).O() == 1)) {
            i++;
          }
        }
        if (i > 1) {
          for (localG = localO1.K(); localG != null; localG = localG.V())
          {
            localObject = localG;
            O localO2 = ((G)localObject).T();
            if ((localO2.C() == 1) && (localO2.O() == 1))
            {
              while ((localO2.C() == 1) && (localO2.O() == 1))
              {
                localK.A(localObject, localO1);
                localObject = localO2.K();
                localO2 = ((G)localObject).T();
              }
              localK.A(localObject, localO1);
            }
          }
        }
      }
      localD.B();
    }
    return localK;
  }
  
  private twaver.base.A.D.E.E.K L()
  {
    twaver.base.A.D.E.E.K localK = A.A(new O[this.O.A()]);
    D localD = this.O.J();
    while (localD.C())
    {
      O localO1 = localD.H();
      if (localO1.C() > 1)
      {
        int i = 0;
        Object localObject;
        for (G localG = localO1.L(); localG != null; localG = localG.S())
        {
          localObject = localG.W();
          if ((((O)localObject).C() == 1) && (((O)localObject).O() == 1)) {
            i++;
          }
        }
        if (i > 1) {
          for (localG = localO1.L(); localG != null; localG = localG.S())
          {
            localObject = localG;
            O localO2 = ((G)localObject).W();
            if ((localO2.C() == 1) && (localO2.O() == 1))
            {
              while ((localO2.C() == 1) && (localO2.O() == 1))
              {
                localK.A(localObject, localO1);
                localObject = localO2.L();
                localO2 = ((G)localObject).W();
              }
              localK.A(localObject, localO1);
            }
          }
        }
      }
      localD.B();
    }
    return localK;
  }
  
  private int E()
  {
    for (int i = 1; i < this.N.length; i++)
    {
      Q localQ = this.N[i];
      F localF = localQ.F();
      while (localF.C())
      {
        O localO = (O)localF.D();
        this.E[localO.F()] = A(localO, localQ.size(), localO.E(), this.N[(i - 1)].size());
        this.E[localO.F()] += this.L[localO.F()] / (this.N[(i - 1)].size() * 3);
        localF.B();
      }
      A(localQ, this.C);
    }
    return M();
  }
  
  private double A(O paramO, int paramInt1, R paramR, int paramInt2)
  {
    double d = 0.0D;
    if (paramR.F() == 0)
    {
      d = paramInt2 * this.L[paramO.F()] / paramInt1;
    }
    else
    {
      while (paramR.C())
      {
        G localG = paramR.I();
        if (localG.W() == paramO) {
          d += this.L[localG.T().F()];
        } else {
          d += this.L[localG.W().F()];
        }
        paramR.B();
      }
      d /= paramR.F();
    }
    return d;
  }
  
  private void A(int[] paramArrayOfInt)
  {
    System.arraycopy(this.L, 0, paramArrayOfInt, 0, paramArrayOfInt.length);
  }
  
  private void B(int[] paramArrayOfInt)
  {
    System.arraycopy(paramArrayOfInt, 0, this.L, 0, paramArrayOfInt.length);
  }
  
  private int[] D()
  {
    int[] arrayOfInt = new int[this.L.length];
    A(arrayOfInt);
    return arrayOfInt;
  }
  
  private void B()
  {
    for (int i = 0; i < this.N.length; i++)
    {
      int j = 0;
      F localF = this.N[i].F();
      while (localF.C())
      {
        this.L[((O)localF.D()).F()] = j;
        localF.B();
        j++;
      }
    }
  }
  
  private void I()
  {
    for (int i = 0; i < this.N.length; i++)
    {
      Q localQ = this.N[i];
      for (twaver.base.A.D.E.E.M localM = localQ.G(); localM != null; localM = localM.A())
      {
        localObject = (O)localM.B();
        this.G[this.L[localObject.F()]] = localObject;
      }
      int j = 0;
      Object localObject = localQ.G();
      while (localObject != null)
      {
        ((twaver.base.A.D.E.E.M)localObject).A(this.G[j]);
        localObject = ((twaver.base.A.D.E.E.M)localObject).A();
        j++;
      }
    }
  }
  
  private void A(S paramS, Comparator paramComparator)
  {
    F localF = paramS.F();
    int i = 0;
    while (i < paramS.size())
    {
      this.G[i] = ((O)localF.D());
      i++;
      localF.B();
    }
    Arrays.sort(this.G, 0, paramS.size(), paramComparator);
    i = 0;
    twaver.base.A.D.E.E.M localM = paramS.G();
    while (localM != null)
    {
      localM.A(this.G[i]);
      this.L[this.G[i].F()] = i;
      localM = localM.A();
      i++;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.M
 * JD-Core Version:    0.7.0.1
 */
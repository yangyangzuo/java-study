package twaver.base.A.D.E.D;

import twaver.base.A.D.E.B.I;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

public class A
  extends E
{
  private double x = 0.65D;
  private double t = Math.max(0.1D, 1.0D);
  private double ª = 80.0D;
  private double µ;
  private double À;
  private _A y;
  private double ¤;
  private double w = 3.0D;
  private int ¥;
  private C Ä;
  private _B[] Æ;
  private int z;
  private _B[] u;
  private twaver.base.A.D.E.B.E ¢;
  private boolean Á = true;
  private long s = 300000L;
  private double q = 0.0D;
  private double Ã;
  private I v;
  private double Å;
  private double £;
  private double[] Ç;
  private double[] p;
  private double º = 2.0D;
  private double r;
  private int Â = 1000;
  
  public void B(double paramDouble)
  {
    this.q = paramDouble;
  }
  
  public boolean M(C paramC)
  {
    return true;
  }
  
  /* Error */
  public void N(C paramC)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +4 -> 5
    //   4: return
    //   5: aload_0
    //   6: aload_1
    //   7: putfield 94	twaver/base/A/D/E/D/A:Ä	Ltwaver/base/A/D/E/D/C;
    //   10: aload_0
    //   11: aload_1
    //   12: invokespecial 96	twaver/base/A/D/E/D/A:P	(Ltwaver/base/A/D/E/D/C;)Z
    //   15: ifne +4 -> 19
    //   18: return
    //   19: new 99	twaver/base/A/D/E/D/A$_A
    //   22: dup
    //   23: invokespecial 101	twaver/base/A/D/E/D/A$_A:<init>	()V
    //   26: astore_2
    //   27: lconst_0
    //   28: lstore_3
    //   29: aload_0
    //   30: getfield 66	twaver/base/A/D/E/D/A:w	D
    //   33: aload_0
    //   34: getfield 102	twaver/base/A/D/E/D/A:u	[Ltwaver/base/A/D/E/D/A$_B;
    //   37: arraylength
    //   38: invokestatic 104	twaver/base/A/D/E/D/A:B	(I)I
    //   41: i2d
    //   42: dmul
    //   43: bipush 20
    //   45: aload_0
    //   46: getfield 102	twaver/base/A/D/E/D/A:u	[Ltwaver/base/A/D/E/D/A$_B;
    //   49: arraylength
    //   50: imul
    //   51: i2d
    //   52: dadd
    //   53: d2l
    //   54: lstore 5
    //   56: lload 5
    //   58: ldc2_w 108
    //   61: invokestatic 110	java/lang/Math:max	(JJ)J
    //   64: lstore 5
    //   66: aload_0
    //   67: getfield 58	twaver/base/A/D/E/D/A:t	D
    //   70: aload_0
    //   71: getfield 58	twaver/base/A/D/E/D/A:t	D
    //   74: dmul
    //   75: aload_0
    //   76: getfield 102	twaver/base/A/D/E/D/A:u	[Ltwaver/base/A/D/E/D/A$_B;
    //   79: arraylength
    //   80: i2d
    //   81: dmul
    //   82: dstore 7
    //   84: aload_0
    //   85: getfield 80	twaver/base/A/D/E/D/A:Â	I
    //   88: istore 9
    //   90: goto +165 -> 255
    //   93: aload_0
    //   94: lload_3
    //   95: ldc2_w 113
    //   98: land
    //   99: l2i
    //   100: invokespecial 115	twaver/base/A/D/E/D/A:A	(I)Ltwaver/base/A/D/E/D/A$_B;
    //   103: astore 10
    //   105: iload 9
    //   107: iinc 9 255
    //   110: ifne +30 -> 140
    //   113: aload_0
    //   114: getfield 119	twaver/base/A/D/E/D/A:v	Ltwaver/base/A/D/E/B/I;
    //   117: invokevirtual 121	twaver/base/A/D/E/B/I:C	()J
    //   120: aload_0
    //   121: getfield 72	twaver/base/A/D/E/D/A:s	J
    //   124: lcmp
    //   125: ifle +6 -> 131
    //   128: lload 5
    //   130: lstore_3
    //   131: invokestatic 127	twaver/base/A/E/T:A	()V
    //   134: aload_0
    //   135: getfield 80	twaver/base/A/D/E/D/A:Â	I
    //   138: istore 9
    //   140: aload_0
    //   141: aload 10
    //   143: aload_2
    //   144: invokespecial 132	twaver/base/A/D/E/D/A:E	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   147: aload_0
    //   148: aload 10
    //   150: aload_2
    //   151: invokespecial 136	twaver/base/A/D/E/D/A:F	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   154: aload_0
    //   155: aload 10
    //   157: aload_2
    //   158: invokespecial 139	twaver/base/A/D/E/D/A:A	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   161: aload_0
    //   162: getfield 68	twaver/base/A/D/E/D/A:Á	Z
    //   165: ifeq +20 -> 185
    //   168: aload_0
    //   169: aload 10
    //   171: aload_2
    //   172: invokespecial 142	twaver/base/A/D/E/D/A:B	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   175: aload_0
    //   176: aload 10
    //   178: aload_2
    //   179: invokespecial 145	twaver/base/A/D/E/D/A:D	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   182: goto +17 -> 199
    //   185: aload_0
    //   186: aload 10
    //   188: aload_2
    //   189: invokespecial 148	twaver/base/A/D/E/D/A:G	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   192: aload_0
    //   193: aload 10
    //   195: aload_2
    //   196: invokespecial 151	twaver/base/A/D/E/D/A:C	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;)V
    //   199: aload_2
    //   200: getfield 153	twaver/base/A/D/E/D/A$_A:B	D
    //   203: aload_2
    //   204: getfield 153	twaver/base/A/D/E/D/A$_A:B	D
    //   207: dmul
    //   208: aload_2
    //   209: getfield 156	twaver/base/A/D/E/D/A$_A:C	D
    //   212: aload_2
    //   213: getfield 156	twaver/base/A/D/E/D/A$_A:C	D
    //   216: dmul
    //   217: dadd
    //   218: aload_2
    //   219: getfield 158	twaver/base/A/D/E/D/A$_A:A	D
    //   222: aload_2
    //   223: getfield 158	twaver/base/A/D/E/D/A$_A:A	D
    //   226: dmul
    //   227: dadd
    //   228: invokestatic 160	java/lang/Math:sqrt	(D)D
    //   231: dstore 11
    //   233: aload_0
    //   234: aload 10
    //   236: aload_2
    //   237: dload 11
    //   239: invokevirtual 164	twaver/base/A/D/E/D/A:A	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;D)V
    //   242: aload_0
    //   243: aload 10
    //   245: aload_2
    //   246: dload 11
    //   248: invokevirtual 168	twaver/base/A/D/E/D/A:B	(Ltwaver/base/A/D/E/D/A$_B;Ltwaver/base/A/D/E/D/A$_A;D)V
    //   251: lload_3
    //   252: lconst_1
    //   253: ladd
    //   254: lstore_3
    //   255: aload_0
    //   256: getfield 171	twaver/base/A/D/E/D/A:µ	D
    //   259: dload 7
    //   261: dcmpl
    //   262: ifle +29 -> 291
    //   265: lload_3
    //   266: lload 5
    //   268: lcmp
    //   269: iflt -176 -> 93
    //   272: goto +19 -> 291
    //   275: astore 14
    //   277: jsr +6 -> 283
    //   280: aload 14
    //   282: athrow
    //   283: astore 13
    //   285: aload_0
    //   286: invokespecial 173	twaver/base/A/D/E/D/A:H	()V
    //   289: ret 13
    //   291: jsr -8 -> 283
    //   294: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	295	0	this	A
    //   0	295	1	paramC	C
    //   26	220	2	local_A	_A
    //   28	238	3	l1	long
    //   54	213	5	l2	long
    //   82	178	7	d1	double
    //   88	51	9	i	int
    //   103	141	10	local_B	_B
    //   231	16	11	d2	double
    //   283	1	13	localObject1	Object
    //   275	6	14	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   90	275	275	finally
    //   291	294	275	finally
  }
  
  private boolean P(C paramC)
  {
    if ((paramC == null) || (paramC.C() < 1)) {
      return false;
    }
    this.Ä = paramC;
    this.¥ = 1;
    this.v = new I();
    this.z = paramC.B();
    this.Æ = new _B[this.z];
    this.Â = (1 + 100000 / this.z);
    this.r = (1.0D / (2.0D * this.º));
    this.Ã = (this.r * this.q / (this.ª * 0.05D));
    this.Å = (Math.pow(this.ª, -1.0D) * this.r);
    this.£ = (Math.pow(this.ª, 3.0D) * this.r);
    this.µ = 0.0D;
    this.y = new _A();
    this.¤ = Math.max(20.0D * this.ª, 10.0D);
    this.¢ = new twaver.base.A.D.E.B.E(879L);
    double d = Math.max(0.1D, Math.min(this.x * this.ª, this.¤));
    int i = this.z;
    L.A(paramC);
    this.u = new _B[i];
    D localD = paramC.J();
    while (localD.C())
    {
      O localO = localD.H();
      _B local_B = new _B(localO, d, this.ª, this.z, this.¢, paramC);
      this.u[(--i)] = local_B;
      this.µ += local_B.A;
      this.À += A(local_B.A);
      this.y.B += local_B.E;
      this.y.C += local_B.G;
      this.y.A += local_B.H;
      this.Æ[localO.F()] = local_B;
      localD.B();
    }
    this.Á = false;
    return this.u.length > 0;
  }
  
  private _B A(int paramInt)
  {
    int i = this.u.length;
    int j = i - paramInt % i - 1;
    int k = this.¢.nextInt(j + 1);
    _B local_B = this.u[k];
    this.u[k] = this.u[j];
    this.u[j] = local_B;
    return local_B;
  }
  
  private void G(_B param_B, _A param_A)
  {
    double d2;
    double d1;
    double d3 = d1 = d2 = 0.0D;
    _B local_B;
    double d4;
    double d5;
    double d6;
    double d7;
    double d9;
    double d10;
    double d8;
    for (G localG = param_B.L.L(); localG != null; localG = localG.S())
    {
      local_B = this.Æ[localG.W().F()];
      d4 = local_B.E - param_B.E;
      d5 = local_B.G - param_B.G;
      d6 = local_B.H - param_B.H;
      d7 = d4 * d4 + d5 * d5 + d6 * d6;
      d9 = Math.sqrt(d7);
      d10 = d9 - (local_B.J + param_B.J);
      if (d10 > 0.0D)
      {
        d8 = d10 * d10 * this.Å / d9;
        d3 += d4 * d8;
        d1 += d5 * d8;
        d2 += d6 * d8;
      }
    }
    for (localG = param_B.L.K(); localG != null; localG = localG.V())
    {
      local_B = this.Æ[localG.T().F()];
      d4 = local_B.E - param_B.E;
      d5 = local_B.G - param_B.G;
      d6 = local_B.H - param_B.H;
      d7 = d4 * d4 + d5 * d5 + d6 * d6;
      d9 = Math.sqrt(d7);
      d10 = d9 - (local_B.J + param_B.J);
      if (d10 > 0.0D)
      {
        d8 = d10 * d10 * this.Å / d9;
        d3 += d4 * d8;
        d1 += d5 * d8;
        d2 += d6 * d8;
      }
    }
    param_A.B += d3;
    param_A.C += d1;
    param_A.A += d2;
  }
  
  private void B(_B param_B, _A param_A)
  {
    double d2;
    double d1;
    double d3 = d1 = d2 = 0.0D;
    this.¥ += 1;
    param_B.I = this.¥;
    _B local_B;
    double d4;
    double d5;
    double d6;
    double d7;
    double d8;
    double d9;
    double d10;
    for (G localG = param_B.L.L(); localG != null; localG = localG.S())
    {
      local_B = this.Æ[localG.W().F()];
      local_B.I = this.¥;
      d4 = local_B.E - param_B.E;
      d5 = local_B.G - param_B.G;
      d6 = local_B.H - param_B.H;
      d7 = d4 * d4 + d5 * d5 + d6 * d6;
      d8 = Math.sqrt(d7);
      if (d8 != 0.0D)
      {
        d9 = Math.max(1.0E-006D, d8 - (param_B.J + local_B.J));
        d10 = -this.p[localG.U()] / (d9 * d9);
        d10 += d9 * d9 * this.Ç[localG.U()];
        d10 /= d8;
        d3 += d4 * d10;
        d1 += d5 * d10;
        d2 += d6 * d10;
      }
    }
    for (localG = param_B.L.K(); localG != null; localG = localG.V())
    {
      local_B = this.Æ[localG.T().F()];
      local_B.I = this.¥;
      d4 = local_B.E - param_B.E;
      d5 = local_B.G - param_B.G;
      d6 = local_B.H - param_B.H;
      d7 = d4 * d4 + d5 * d5 + d6 * d6;
      d8 = Math.sqrt(d7);
      if (d8 != 0.0D)
      {
        d9 = Math.max(1.0E-006D, d8 - (param_B.J + local_B.J));
        d10 = -this.p[localG.U()] / (d9 * d9);
        d10 += d9 * d9 * this.Ç[localG.U()];
        d10 /= d8;
        d3 += d4 * d10;
        d1 += d5 * d10;
        d2 += d6 * d10;
      }
    }
    param_A.B += d3;
    param_A.C += d1;
    param_A.A += d2;
  }
  
  private void D(_B param_B, _A param_A)
  {
    double d2;
    double d1;
    double d3 = d1 = d2 = 0.0D;
    for (int i = this.z - 1; i >= 0; i--)
    {
      _B local_B = this.Æ[i];
      if (local_B.I != param_B.I)
      {
        double d4 = param_B.E - local_B.E;
        double d5 = param_B.G - local_B.G;
        double d6 = param_B.H - local_B.H;
        double d7 = d4 * d4 + d5 * d5 + d6 * d6;
        if (d7 != 0.0D)
        {
          double d8 = Math.sqrt(d7);
          double d9 = Math.max(1.0E-006D, d8 - (param_B.J + local_B.J));
          double d10 = this.£ / (d9 * d9 * d8);
          d3 += d4 * d10;
          d1 += d5 * d10;
          d2 += d6 * d10;
        }
      }
    }
    param_A.B += d3;
    param_A.C += d1;
    param_A.A += d2;
  }
  
  private void C(_B param_B, _A param_A)
  {
    double d2;
    double d1;
    double d3 = d1 = d2 = 0.0D;
    for (int i = this.z - 1; i >= 0; i--)
    {
      _B local_B = this.Æ[i];
      double d4 = param_B.E - local_B.E;
      double d5 = param_B.G - local_B.G;
      double d6 = param_B.H - local_B.H;
      double d7 = d4 * d4 + d5 * d5 + d6 * d6;
      if (d7 != 0.0D)
      {
        double d8 = Math.sqrt(d7);
        double d10 = d8 - (param_B.J + local_B.J);
        double d9;
        if (d10 <= 0.0D) {
          d9 = this.£ / (1.0E-008D * d8);
        } else {
          d9 = this.£ / (d10 * d10 * d8);
        }
        d3 += d4 * d9;
        d1 += d5 * d9;
        d2 += d6 * d9;
      }
    }
    param_A.B += d3;
    param_A.C += d1;
    param_A.A += d2;
  }
  
  private void A(_B param_B, _A param_A)
  {
    double d = this.y.A / this.z - param_B.H;
    param_A.A += d * this.ª * this.z / this.À;
  }
  
  private void F(_B param_B, _A param_A)
  {
    if (this.Ã != 0.0D)
    {
      double d1 = this.y.B / this.z - param_B.E;
      double d2 = this.y.C / this.z - param_B.G;
      double d3 = this.y.A / this.z - param_B.H;
      param_A.B += d1 * this.Ã;
      param_A.C += d2 * this.Ã;
      param_A.A += d3 * this.Ã;
    }
  }
  
  private void E(_B param_B, _A param_A)
  {
    double d = 0.05D * (param_B.A + 2.0D);
    if (d > 0.0D)
    {
      param_A.B = this.¢.A(-d, d);
      param_A.C = this.¢.A(-d, d);
      param_A.A = this.¢.A(-d, d);
    }
  }
  
  protected void A(_B param_B, _A param_A, double paramDouble)
  {
    if ((paramDouble != 0.0D) && (param_B.M != 0.0D))
    {
      double d1 = param_A.B * param_B.C + param_A.C * param_B.D + param_A.A * param_B.F;
      double d2 = d1 / (paramDouble * param_B.M);
      this.À -= param_B.A * param_B.A;
      this.µ -= param_B.A;
      if (param_B.B * d2 > 0.0D) {
        param_B.A += d2 * 0.45D;
      } else {
        param_B.A += d2 * 0.15D;
      }
      if (param_B.A > this.¤) {
        param_B.A = this.¤;
      } else if (param_B.A < 0.1D) {
        param_B.A = 0.1D;
      }
      this.µ += param_B.A;
      this.À += param_B.A * param_B.A;
      param_B.B = d2;
    }
  }
  
  protected void B(_B param_B, _A param_A, double paramDouble)
  {
    if (paramDouble > 0.0D)
    {
      double d1 = param_B.A / paramDouble;
      double d2 = param_A.B * d1;
      double d3 = param_A.C * d1;
      double d4 = param_A.A * d1;
      param_B.E += d2;
      param_B.G += d3;
      param_B.H += d4;
      this.y.B += d2;
      this.y.C += d3;
      this.y.A += d4;
      param_B.M = paramDouble;
      param_B.C = param_A.B;
      param_B.D = param_A.C;
      param_B.F = param_A.A;
    }
  }
  
  private void H()
  {
    for (int i = this.Æ.length - 1; i >= 0; i--)
    {
      _B local_B = this.Æ[i];
      this.Ä.A(local_B.L, local_B.E, local_B.G);
    }
  }
  
  private static final int B(int paramInt)
  {
    return paramInt * paramInt;
  }
  
  private static final double A(double paramDouble)
  {
    return paramDouble * paramDouble;
  }
  
  static class _B
  {
    public O L;
    public double C;
    public double D;
    public double F;
    public double M;
    public double K;
    public int I;
    public double A;
    public double E;
    public double G;
    public double H;
    public double J;
    public double B;
    
    _B(O paramO, double paramDouble1, double paramDouble2, int paramInt, twaver.base.A.D.E.B.E paramE, C paramC)
    {
      this.L = paramO;
      this.M = 0.0001D;
      this.A = paramDouble1;
      this.B = 1.0D;
      this.J = ((paramC.L(paramO) + paramC.Q(paramO)) / 4.0D);
      double d = 0.45D * paramDouble2 * Math.sqrt(paramInt);
      this.E = paramE.A(-d, d);
      this.G = paramE.A(-d, d);
      this.H = paramE.A(-d, d);
    }
  }
  
  static final class _A
  {
    double B;
    double C;
    double A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.A
 * JD-Core Version:    0.7.0.1
 */
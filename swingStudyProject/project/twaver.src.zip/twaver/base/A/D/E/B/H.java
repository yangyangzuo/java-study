package twaver.base.A.D.E.B;

import java.util.Iterator;
import java.util.NoSuchElementException;
import twaver.base.A.D.E.E.F;

public final class H
{
  public static Iterator A(F paramF)
  {
    return new _A(paramF);
  }
  
  private static final class _A
    implements Iterator
  {
    private F A;
    
    public boolean hasNext()
    {
      return this.A.C();
    }
    
    public Object next()
    {
      if (!this.A.C()) {
        throw new NoSuchElementException();
      }
      Object localObject = this.A.D();
      this.A.B();
      return localObject;
    }
    
    public void remove()
    {
      throw new UnsupportedOperationException();
    }
    
    public _A(F paramF)
    {
      this.A = paramF;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.H
 * JD-Core Version:    0.7.0.1
 */
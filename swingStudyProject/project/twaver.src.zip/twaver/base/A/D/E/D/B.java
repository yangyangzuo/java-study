package twaver.base.A.D.E.D;

public abstract interface B
{
  public abstract boolean B(C paramC);
  
  public abstract void A(C paramC);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B
 * JD-Core Version:    0.7.0.1
 */
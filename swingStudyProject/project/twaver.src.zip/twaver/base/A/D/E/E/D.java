package twaver.base.A.D.E.E;

public abstract interface D
  extends F
{
  public abstract O H();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.D
 * JD-Core Version:    0.7.0.1
 */
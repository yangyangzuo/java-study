package twaver.base.A.D.E.A;

import java.awt.Rectangle;
import twaver.base.A.D.E.D.K;
import twaver.base.A.D.E.D.M;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

public class I
  extends twaver.base.A.D.E.D.C
{
  private C O;
  private D N;
  
  public I()
  {
    A(new F(), new B());
  }
  
  private void A(C paramC, D paramD)
  {
    this.O = paramC;
    this.N = paramD;
  }
  
  public G A(O paramO1, O paramO2)
  {
    return A(paramO1, paramO2, this.N.E());
  }
  
  public G A(O paramO1, O paramO2, D paramD)
  {
    return A(paramO1, null, paramO2, null, 0, 0, paramD);
  }
  
  public G A(O paramO1, G paramG1, O paramO2, G paramG2, int paramInt1, int paramInt2)
  {
    return A(paramO1, paramG1, paramO2, paramG2, paramInt1, paramInt2, this.N.E());
  }
  
  public G A(O paramO1, G paramG1, O paramO2, G paramG2, int paramInt1, int paramInt2, D paramD)
  {
    E localE = new E(this, paramO1, paramG1, paramO2, paramG2, paramInt1, paramInt2, paramD);
    return localE;
  }
  
  public O I()
  {
    return A(this.O.F());
  }
  
  public O A(C paramC)
  {
    return new H(this, paramC);
  }
  
  public Rectangle N()
  {
    Rectangle localRectangle = new Rectangle(0, 0, -1, -1);
    twaver.base.A.D.E.E.D localD = J();
    while (localD.C())
    {
      U(localD.H()).A(localRectangle);
      localD.B();
    }
    return localRectangle;
  }
  
  public C U(O paramO)
  {
    return ((H)paramO).I;
  }
  
  public D R(G paramG)
  {
    return ((E)paramG).P;
  }
  
  public M J(O paramO)
  {
    return U(paramO);
  }
  
  public K M(G paramG)
  {
    return R(paramG);
  }
  
  public double K(O paramO)
  {
    return U(paramO).G();
  }
  
  public double H(O paramO)
  {
    return U(paramO).E();
  }
  
  public double O(O paramO)
  {
    return U(paramO).C();
  }
  
  public double I(O paramO)
  {
    return U(paramO).A();
  }
  
  public double L(O paramO)
  {
    return U(paramO).B();
  }
  
  public double Q(O paramO)
  {
    return U(paramO).D();
  }
  
  public void A(O paramO, double paramDouble1, double paramDouble2)
  {
    U(paramO).C(paramDouble1, paramDouble2);
  }
  
  public void C(O paramO, double paramDouble1, double paramDouble2)
  {
    U(paramO).B(paramDouble1, paramDouble2);
  }
  
  public void B(O paramO, double paramDouble1, double paramDouble2)
  {
    U(paramO).A(paramDouble1, paramDouble2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.I
 * JD-Core Version:    0.7.0.1
 */
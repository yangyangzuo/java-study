package twaver.base.A.D.E.B;

import twaver.base.A.D.E.E.L;

public abstract class G
  implements L
{
  public Object D(Object paramObject)
  {
    throw new UnsupportedOperationException();
  }
  
  public int A(Object paramObject)
  {
    throw new UnsupportedOperationException();
  }
  
  public double C(Object paramObject)
  {
    throw new UnsupportedOperationException();
  }
  
  public boolean B(Object paramObject)
  {
    throw new UnsupportedOperationException();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.G
 * JD-Core Version:    0.7.0.1
 */
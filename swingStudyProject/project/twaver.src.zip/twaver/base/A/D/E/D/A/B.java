package twaver.base.A.D.E.D.A;

import java.util.Comparator;
import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

public class B
  implements Comparator
{
  public int compare(Object paramObject1, Object paramObject2)
  {
    O localO1 = ((G)paramObject1).T();
    O localO2 = ((G)paramObject2).T();
    C localC = (C)localO1.P();
    return (int)(100.0D * (localC.K(localO1) - localC.K(localO2)));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.A.B
 * JD-Core Version:    0.7.0.1
 */
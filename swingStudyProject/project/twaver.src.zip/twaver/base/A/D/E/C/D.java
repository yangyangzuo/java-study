package twaver.base.A.D.E.C;

public class D
  implements Comparable
{
  public final double B;
  public final double A;
  
  public D(double paramDouble1, double paramDouble2)
  {
    this.B = paramDouble1;
    this.A = paramDouble2;
  }
  
  public final double A()
  {
    return this.B;
  }
  
  public final double B()
  {
    return this.A;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof D)) {
      return false;
    }
    D localD = (D)paramObject;
    return (localD.B == this.B) && (localD.A == this.A);
  }
  
  public int hashCode()
  {
    long l = Double.doubleToRawLongBits(this.B) << 1 ^ Double.doubleToRawLongBits(this.A);
    return (int)(l ^ l >> 32);
  }
  
  public int compareTo(Object paramObject)
  {
    D localD = (D)paramObject;
    if (equals(localD)) {
      return 0;
    }
    if (localD.B > this.B) {
      return -1;
    }
    if (localD.B < this.B) {
      return 1;
    }
    if (localD.A > this.A) {
      return -1;
    }
    return localD.A >= this.A ? 0 : 1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.D
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D.C;

import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.F.E;

public class D
  implements I
{
  public int A(twaver.base.A.D.E.D.C paramC, twaver.base.A.D.E.E.I paramI, A paramA)
  {
    int i = B(paramC, paramI);
    A(paramC, paramI, paramA);
    return i;
  }
  
  int B(twaver.base.A.D.E.E.C paramC, twaver.base.A.D.E.E.I paramI)
  {
    Q localQ = E.A(paramC);
    localQ.C();
    int i = 0;
    twaver.base.A.D.E.E.D localD1 = localQ.P();
    while (localD1.C())
    {
      paramI.B(localD1.H(), -1);
      localD1.B();
    }
    localD1 = localQ.P();
    while (localD1.C())
    {
      O localO = localD1.H();
      int j = -1;
      twaver.base.A.D.E.E.D localD2 = localO.H();
      while (localD2.C())
      {
        j = Math.max(j, paramI.A(localD2.H()));
        localD2.B();
      }
      paramI.B(localO, j + 1);
      i = Math.max(i, j + 1);
      localD1.B();
    }
    return i + 1;
  }
  
  private void A(twaver.base.A.D.E.E.C paramC, twaver.base.A.D.E.E.I paramI, A paramA)
  {
    paramA.A(A(paramC, paramI));
  }
  
  public static A A(twaver.base.A.D.E.E.C paramC, twaver.base.A.D.E.E.I paramI)
  {
    A localA = new A();
    R localR = paramC.M();
    while (localR.C())
    {
      G localG = localR.I();
      if (paramI.A(localG.W()) > paramI.A(localG.T()))
      {
        paramC.G(localG);
        localA.C(localG);
      }
      localR.B();
    }
    return localA;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.D
 * JD-Core Version:    0.7.0.1
 */
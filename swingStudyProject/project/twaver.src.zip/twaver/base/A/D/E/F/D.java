package twaver.base.A.D.E.F;

import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;

public class D
{
  public static A A(twaver.base.A.D.E.E.C paramC)
  {
    _A[] arrayOf_A = new _A[paramC.B()];
    for (int i = 0; i < arrayOf_A.length; i++) {
      arrayOf_A[i] = new _A(null);
    }
    C local1 = new C()
    {
      protected void A(G paramAnonymousG, O paramAnonymousO)
      {
        O localO = paramAnonymousG.E(paramAnonymousO);
        D._A local_A1 = D.this[localO.F()];
        D._A local_A2 = D.this[paramAnonymousO.F()];
        if (local_A2.B + 1 > local_A1.B)
        {
          local_A1.D = local_A1.B;
          local_A1.A = local_A1.C;
          local_A2.B += 1;
          local_A1.C = paramAnonymousG;
        }
        else if (local_A2.B + 1 > local_A1.D)
        {
          local_A1.D = (local_A2.B + 1);
          local_A1.A = paramAnonymousG;
        }
      }
    };
    local1.B(false);
    local1.A(paramC);
    int j = -1;
    Object localObject1 = null;
    Object localObject2 = paramC.J();
    while (((twaver.base.A.D.E.E.D)localObject2).C())
    {
      localObject3 = ((twaver.base.A.D.E.E.D)localObject2).H();
      localObject4 = arrayOf_A[localObject3.F()];
      if (((_A)localObject4).B + ((_A)localObject4).D > j)
      {
        j = ((_A)localObject4).B + ((_A)localObject4).D;
        localObject1 = localObject3;
      }
      ((twaver.base.A.D.E.E.D)localObject2).B();
    }
    localObject2 = new A();
    Object localObject3 = localObject1;
    for (Object localObject4 = arrayOf_A[localObject3.F()].C; localObject4 != null; localObject4 = arrayOf_A[localObject3.F()].C)
    {
      ((A)localObject2).A(localObject4);
      localObject3 = ((G)localObject4).E((O)localObject3);
    }
    localObject3 = localObject1;
    for (localObject4 = arrayOf_A[localObject3.F()].A; localObject4 != null; localObject4 = arrayOf_A[localObject3.F()].C)
    {
      ((A)localObject2).D(localObject4);
      localObject3 = ((G)localObject4).E((O)localObject3);
    }
    return localObject2;
  }
  
  private static class _A
  {
    G C;
    G A;
    int B;
    int D;
    
    private _A() {}
    
    _A(_A param_A)
    {
      this();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.D
 * JD-Core Version:    0.7.0.1
 */
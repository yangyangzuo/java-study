package twaver.base.A.D.E;

import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.Node;
import twaver.TDataBox;
import twaver.UndoRedoEvent;
import twaver.UndoRedoManager;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.O;
import twaver.network.TNetwork;

class A
{
  private twaver.base.A.D.E.D.B F;
  private int D;
  private TNetwork E = null;
  private Iterator B = null;
  private Generator C = null;
  private Map A = new HashMap();
  
  public A(TNetwork paramTNetwork, Iterator paramIterator, twaver.base.A.D.E.D.B paramB, int paramInt, Generator paramGenerator)
  {
    this.F = paramB;
    this.D = paramInt;
    this.E = paramTNetwork;
    this.B = paramIterator;
    this.C = paramGenerator;
  }
  
  public void A()
  {
    Iterator localIterator = this.A.keySet().iterator();
    while (localIterator.hasNext())
    {
      Group localGroup = (Group)localIterator.next();
      if ((this.E != null) && (this.E.isExpandGroupAfterLayout()))
      {
        localGroup.setExpand(true);
      }
      else
      {
        Boolean localBoolean = (Boolean)this.A.get(localGroup);
        if (localBoolean != null) {
          localGroup.setExpand(localBoolean.booleanValue());
        }
      }
    }
  }
  
  public Iterator B()
  {
    LinkedList localLinkedList = new LinkedList();
    while (this.B.hasNext())
    {
      Element localElement = (Element)this.B.next();
      if ((localElement instanceof Link))
      {
        if (!((Link)localElement).isLoop()) {
          localLinkedList.add(localElement);
        }
      }
      else if (!(localElement.getParent() instanceof Group))
      {
        localLinkedList.add(localElement);
        if ((localElement instanceof Group)) {
          A((Group)localElement);
        }
      }
    }
    return localLinkedList.iterator();
  }
  
  public void A(Group paramGroup)
  {
    if (this.A.containsKey(paramGroup)) {
      return;
    }
    this.A.put(paramGroup, Boolean.valueOf(paramGroup.isExpand()));
    paramGroup.setExpand(true);
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    Iterator localIterator1 = paramGroup.children();
    Object localObject2;
    while (localIterator1.hasNext())
    {
      localObject1 = (Element)localIterator1.next();
      if ((localObject1 instanceof Group))
      {
        localObject2 = (Group)localObject1;
        A((Group)localObject2);
        ((Group)localObject2).setExpand(false);
      }
      if (!(localObject1 instanceof Link)) {
        localLinkedHashSet.add(localObject1);
      }
      if ((localObject1 instanceof Node))
      {
        localObject2 = ((Node)localObject1).getAllLinks();
        if (localObject2 != null) {
          localLinkedHashSet.addAll((Collection)localObject2);
        }
      }
    }
    Object localObject1 = new C(this.E, localLinkedHashSet.iterator(), this.C, this.D);
    Object localObject3;
    try
    {
      this.F.A((twaver.base.A.D.E.D.C)localObject1);
      localObject2 = B.A(this.D);
      if (this.E != null) {
        this.E.getDataBox().getUndoRedoManager().setIgnorePropertyChange(true);
      }
      localObject3 = new HashMap();
      HashMap localHashMap = new HashMap();
      Iterator localIterator2 = ((C)localObject1).T().keySet().iterator();
      while (localIterator2.hasNext())
      {
        Element localElement2 = (Element)localIterator2.next();
        O localO = ((C)localObject1).E(localElement2);
        E localE = ((C)localObject1).N(localO);
        ((Map)localObject3).put(localElement2, localElement2.getCenterLocation());
        if (localObject2 != null)
        {
          Point2D.Double localDouble1 = new Point2D.Double(localE.A, localE.B);
          Point2D.Double localDouble2 = new Point2D.Double();
          ((AffineTransform)localObject2).transform(localDouble1, localDouble2);
          localElement2.setCenterLocation(localDouble2.getX(), localDouble2.getY());
        }
        else
        {
          localElement2.setCenterLocation(localE.A, localE.B);
        }
        localHashMap.put(localElement2, localElement2.getCenterLocation());
      }
      if (this.E != null)
      {
        this.E.getDataBox().getUndoRedoManager().setIgnorePropertyChange(false);
        this.E.getDataBox().getUndoRedoManager().addEvent(new UndoRedoEvent((Map)localObject3, localHashMap));
      }
    }
    catch (Exception localException) {}
    localIterator1 = paramGroup.children();
    while (localIterator1.hasNext())
    {
      Element localElement1 = (Element)localIterator1.next();
      if ((localElement1 instanceof Group))
      {
        localObject3 = (Group)localElement1;
        ((Group)localObject3).setExpand(true);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A
 * JD-Core Version:    0.7.0.1
 */
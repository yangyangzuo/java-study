package twaver.base.A.D.E.D.B;

import java.util.Hashtable;
import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.F.B;

class D
  extends twaver.base.A.D.E.D.O
{
  I J;
  I K;
  K M;
  C L;
  
  public D(C paramC)
  {
    this.L = paramC;
    this.J = H();
    this.M = F();
  }
  
  Q T(twaver.base.A.D.E.E.O paramO)
  {
    Q localQ = (Q)this.J.D(paramO);
    return localQ;
  }
  
  void A(twaver.base.A.D.E.E.O paramO, Q paramQ)
  {
    this.J.B(paramO, paramQ);
  }
  
  public void S()
  {
    if (this.K == null) {
      this.K = H();
    }
    int[] arrayOfInt = new int[this.L.B() + 1];
    int i = 1;
    twaver.base.A.D.E.E.D localD = J();
    while (localD.C())
    {
      Q localQ = T(localD.H());
      Object localObject1 = localQ.P();
      while (((twaver.base.A.D.E.E.D)localObject1).C())
      {
        localObject2 = ((twaver.base.A.D.E.E.D)localObject1).H();
        arrayOfInt[localObject2.F()] = i;
        ((twaver.base.A.D.E.E.D)localObject1).B();
      }
      localObject1 = new twaver.base.A.D.E.E.A();
      Object localObject2 = localQ.P();
      while (((twaver.base.A.D.E.E.D)localObject2).C())
      {
        twaver.base.A.D.E.E.O localO1 = ((twaver.base.A.D.E.E.D)localObject2).H();
        int j = arrayOfInt[localO1.F()];
        R localR = localO1.I();
        while (localR.C())
        {
          G localG = localR.I();
          twaver.base.A.D.E.E.O localO2 = localG.T();
          int k = arrayOfInt[localO2.F()];
          if (k == j) {
            ((twaver.base.A.D.E.E.A)localObject1).C(localG);
          }
          localR.B();
        }
        ((twaver.base.A.D.E.E.D)localObject2).B();
      }
      this.K.B(localD.H(), localObject1);
      localD.B();
      i++;
    }
  }
  
  twaver.base.A.D.E.E.A S(twaver.base.A.D.E.E.O paramO)
  {
    return (twaver.base.A.D.E.E.A)this.K.D(paramO);
  }
  
  twaver.base.A.D.E.E.A Q(G paramG)
  {
    return (twaver.base.A.D.E.E.A)this.M.D(paramG);
  }
  
  void A(G paramG, twaver.base.A.D.E.E.A paramA)
  {
    this.M.A(paramG, paramA);
  }
  
  public void R()
  {
    I localI = this.L.H();
    K localK = twaver.base.A.D.E.B.A.B(new int[this.L.K()]);
    int i = B.A(this.L, localK, localI);
    twaver.base.A.D.E.E.A[] arrayOfA = B.A(this.L, localK, i);
    A(localI, arrayOfA);
    this.L.A(localI);
  }
  
  twaver.base.A.D.E.E.A A(twaver.base.A.D.E.E.A[] paramArrayOfA)
  {
    Object localObject = null;
    int i = -1;
    for (int j = 0; j < paramArrayOfA.length; j++)
    {
      twaver.base.A.D.E.E.A localA = paramArrayOfA[j];
      if (localA.size() > i)
      {
        localObject = localA;
        i = localA.size();
      }
    }
    return localObject;
  }
  
  void A(I paramI, twaver.base.A.D.E.E.A[] paramArrayOfA)
  {
    K localK = this.L.F();
    I localI = this.L.H();
    for (int i = 0; i < paramArrayOfA.length; i++)
    {
      localObject1 = paramArrayOfA[i];
      R localR = ((twaver.base.A.D.E.E.A)localObject1).J();
      while (localR.C())
      {
        localK.A(localR.I(), localObject1);
        localR.B();
      }
    }
    twaver.base.A.D.E.E.A localA1 = A(paramArrayOfA);
    A(localA1, paramI, localK, new Hashtable(), localI);
    Object localObject1 = new Hashtable();
    Object localObject3;
    Object localObject5;
    for (int j = 0; j < paramArrayOfA.length; j++)
    {
      localObject3 = paramArrayOfA[j];
      if (((twaver.base.A.D.E.E.A)localObject3).size() > 1)
      {
        localObject5 = I();
        ((Hashtable)localObject1).put(localObject3, localObject5);
      }
    }
    Object localObject2 = this.L.J();
    Object localObject6;
    while (((twaver.base.A.D.E.E.D)localObject2).C())
    {
      localObject3 = ((twaver.base.A.D.E.E.D)localObject2).H();
      if ((paramI.B(localObject3)) && (localI.D(localObject3) == null))
      {
        localObject5 = I();
        ((Hashtable)localObject1).put(localObject3, localObject5);
        localObject6 = new Q();
        ((Q)localObject6).add(localObject3);
        A((twaver.base.A.D.E.E.O)localObject5, (Q)localObject6);
      }
      ((twaver.base.A.D.E.E.D)localObject2).B();
    }
    localObject2 = new twaver.base.A.D.E.E.O[2];
    Object localObject8;
    Object localObject9;
    Object localObject10;
    for (int k = 0; k < paramArrayOfA.length; k++)
    {
      localObject5 = paramArrayOfA[k];
      if (((twaver.base.A.D.E.E.A)localObject5).size() == 1)
      {
        localObject6 = ((twaver.base.A.D.E.E.A)localObject5).L();
        localObject2[0] = ((G)localObject6).W();
        localObject2[1] = ((G)localObject6).T();
        for (int i1 = 0; i1 < 2; i1++)
        {
          localObject8 = localObject2[i1];
          if (((twaver.base.A.D.E.E.O)localObject8).G() == 1)
          {
            localObject9 = I();
            ((Hashtable)localObject1).put(localObject8, localObject9);
            localObject10 = new Q();
            ((Q)localObject10).add(localObject8);
            A((twaver.base.A.D.E.E.O)localObject9, (Q)localObject10);
          }
        }
      }
    }
    Object localObject4 = this.L.J();
    Object localObject7;
    Object localObject11;
    Object localObject12;
    while (((twaver.base.A.D.E.E.D)localObject4).C())
    {
      localObject5 = ((twaver.base.A.D.E.E.D)localObject4).H();
      if (localI.D(localObject5) != null)
      {
        localObject6 = (twaver.base.A.D.E.E.A)localI.D(localObject5);
        localObject7 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject6);
        localObject8 = ((twaver.base.A.D.E.E.O)localObject5).M();
        while (((R)localObject8).C())
        {
          localObject9 = ((R)localObject8).I();
          if (localK.D(localObject9) != localObject6)
          {
            localObject10 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localK.D(localObject9));
            if (localObject10 == null)
            {
              localObject11 = ((G)localObject9).E((twaver.base.A.D.E.E.O)localObject5);
              localObject12 = (twaver.base.A.D.E.E.A)localI.D(localObject11);
              if (localObject12 != null) {
                localObject10 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject12);
              } else {
                localObject10 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject11);
              }
            }
            localObject11 = ((twaver.base.A.D.E.E.O)localObject7).C((twaver.base.A.D.E.E.O)localObject10);
            localObject12 = null;
            if (localObject11 == null)
            {
              localObject11 = A((twaver.base.A.D.E.E.O)localObject7, (twaver.base.A.D.E.E.O)localObject10);
              localObject12 = new twaver.base.A.D.E.E.A();
            }
            else
            {
              localObject12 = Q((G)localObject11);
            }
            ((twaver.base.A.D.E.E.A)localObject12).add(localObject9);
            A((G)localObject11, (twaver.base.A.D.E.E.A)localObject12);
          }
          ((R)localObject8).B();
        }
      }
      else if (paramI.B(localObject5))
      {
        localObject6 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject5);
        localObject7 = ((twaver.base.A.D.E.E.O)localObject5).M();
        while (((R)localObject7).C())
        {
          localObject8 = ((R)localObject7).I();
          localObject9 = ((G)localObject8).E((twaver.base.A.D.E.E.O)localObject5);
          localObject10 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject9);
          if (localObject10 != null)
          {
            localObject11 = ((twaver.base.A.D.E.E.O)localObject6).C((twaver.base.A.D.E.E.O)localObject10);
            if (localObject11 == null)
            {
              localObject12 = A((twaver.base.A.D.E.E.O)localObject6, (twaver.base.A.D.E.E.O)localObject10);
              twaver.base.A.D.E.E.A localA2 = new twaver.base.A.D.E.E.A();
              localA2.add(localObject8);
              A((G)localObject12, localA2);
            }
          }
          ((R)localObject7).B();
        }
      }
      ((twaver.base.A.D.E.E.D)localObject4).B();
    }
    if ((this.L.B() == 2) && (this.L.A() == 1))
    {
      localObject4 = this.L.M().I();
      localObject5 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(((G)localObject4).W());
      localObject6 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(((G)localObject4).T());
      if ((localObject6 != null) && (localObject5 != null) && (((twaver.base.A.D.E.E.O)localObject6).C((twaver.base.A.D.E.E.O)localObject5) == null))
      {
        localObject7 = A((twaver.base.A.D.E.E.O)localObject5, (twaver.base.A.D.E.E.O)localObject6);
        localObject8 = new twaver.base.A.D.E.E.A();
        ((twaver.base.A.D.E.E.A)localObject8).add(localObject4);
        A((G)localObject7, (twaver.base.A.D.E.E.A)localObject8);
      }
    }
    localObject4 = new int[this.L.B()];
    int m = 1;
    for (int n = 0; n < paramArrayOfA.length; n++)
    {
      localObject7 = paramArrayOfA[n];
      localObject8 = (twaver.base.A.D.E.E.O)((Hashtable)localObject1).get(localObject7);
      if (localObject8 != null)
      {
        localObject9 = T((twaver.base.A.D.E.E.O)localObject8);
        if (localObject9 == null)
        {
          localObject9 = new Q();
          A((twaver.base.A.D.E.E.O)localObject8, (Q)localObject9);
        }
        localObject10 = ((twaver.base.A.D.E.E.A)localObject7).J();
        while (((R)localObject10).C())
        {
          localObject11 = ((R)localObject10).I();
          localObject12 = ((G)localObject11).W();
          if ((localObject4[localObject12.F()] != m) && ((!paramI.B(localObject12)) || (localI.D(localObject12) == localObject7)))
          {
            localObject4[localObject12.F()] = m;
            ((Q)localObject9).add(localObject12);
          }
          localObject12 = ((G)localObject11).T();
          if ((localObject4[localObject12.F()] != m) && ((!paramI.B(localObject12)) || (localI.D(localObject12) == localObject7)))
          {
            localObject4[localObject12.F()] = m;
            ((Q)localObject9).add(localObject12);
          }
          ((R)localObject10).B();
        }
      }
    }
    this.L.A(localK);
    this.L.A(localI);
  }
  
  void A(twaver.base.A.D.E.E.A paramA, I paramI1, K paramK, Hashtable paramHashtable, I paramI2)
  {
    if (paramHashtable.containsKey(paramA)) {
      return;
    }
    paramHashtable.put(paramA, Boolean.TRUE);
    twaver.base.A.D.E.E.O[] arrayOfO = new twaver.base.A.D.E.E.O[2];
    R localR1 = paramA.J();
    while (localR1.C())
    {
      G localG = localR1.I();
      arrayOfO[0] = localG.W();
      arrayOfO[1] = localG.T();
      for (int i = 0; i < 2; i++)
      {
        twaver.base.A.D.E.E.O localO = arrayOfO[i];
        if ((paramI1.B(localO)) && (paramI2.D(localO) == null))
        {
          if (paramA.size() > 1) {
            paramI2.B(localO, paramA);
          }
          R localR2 = localO.M();
          while (localR2.C())
          {
            twaver.base.A.D.E.E.A localA = (twaver.base.A.D.E.E.A)paramK.D(localR2.I());
            A(localA, paramI1, paramK, paramHashtable, paramI2);
            localR2.B();
          }
        }
      }
      localR1.B();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B.D
 * JD-Core Version:    0.7.0.1
 */
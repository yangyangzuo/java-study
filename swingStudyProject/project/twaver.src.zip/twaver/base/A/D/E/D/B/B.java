package twaver.base.A.D.E.D.B;

import twaver.base.A.D.E.B.F;
import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;

class B
  implements twaver.base.A.D.E.F.A
{
  C A;
  
  public twaver.base.A.D.E.E.D A(C paramC)
  {
    this.A = paramC;
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A();
    localA = twaver.base.A.D.E.F.B.C(paramC);
    localA.A(twaver.base.A.D.E.F.B.A(paramC));
    Q localQ = A();
    while (!localA.isEmpty()) {
      paramC.C(localA.K());
    }
    return localQ.P();
  }
  
  Q A()
  {
    if (this.A.B() < 3) {
      return new Q(this.A.J());
    }
    I localI1 = this.A.H();
    I localI2 = this.A.H();
    K localK = this.A.F();
    twaver.base.A.D.E.B.D localD = new twaver.base.A.D.E.B.D(this.A, new _A(), 0, B(this.A));
    int i = this.A.B();
    twaver.base.A.D.E.E.A localA1 = new twaver.base.A.D.E.E.A();
    twaver.base.A.D.E.E.A localA2 = new twaver.base.A.D.E.E.A();
    F localF = new F(this.A);
    Object localObject7;
    while (i > 3)
    {
      localObject1 = localD.B();
      localObject2 = new Integer(i);
      localObject3 = ((O)localObject1).N();
      while (((twaver.base.A.D.E.E.D)localObject3).C())
      {
        localI1.B(((twaver.base.A.D.E.E.D)localObject3).H(), localObject2);
        localI2.B(((twaver.base.A.D.E.E.D)localObject3).H(), false);
        ((twaver.base.A.D.E.E.D)localObject3).B();
      }
      localObject3 = ((O)localObject1).N();
      Object localObject4;
      while (((twaver.base.A.D.E.E.D)localObject3).C())
      {
        localObject4 = ((twaver.base.A.D.E.E.D)localObject3).H();
        localObject5 = ((O)localObject4).I();
        while (((R)localObject5).C())
        {
          localObject6 = ((R)localObject5).I();
          if (localI1.A(((twaver.base.A.D.E.E.G)localObject6).T()) == i)
          {
            localA2.add(localObject6);
            localI2.B(((twaver.base.A.D.E.E.G)localObject6).W(), true);
            localI2.B(((twaver.base.A.D.E.E.G)localObject6).T(), true);
          }
          ((R)localObject5).B();
        }
        ((twaver.base.A.D.E.E.D)localObject3).B();
      }
      if (localA2.size() < ((O)localObject1).G() - 1)
      {
        localObject3 = null;
        localObject4 = ((O)localObject1).N();
        while (((twaver.base.A.D.E.E.D)localObject4).C())
        {
          localObject5 = ((twaver.base.A.D.E.E.D)localObject4).H();
          if ((localI1.A(localObject5) == i) && (!localI2.B(localObject5))) {
            if (localObject3 == null)
            {
              localObject3 = localObject5;
            }
            else
            {
              localObject6 = this.A.A((O)localObject3, (O)localObject5);
              localK.A(localObject6, true);
              localA2.add(localObject6);
              localObject3 = null;
            }
          }
          ((twaver.base.A.D.E.E.D)localObject4).B();
        }
        if (localObject3 != null)
        {
          localObject4 = ((O)localObject1).N();
          while (((twaver.base.A.D.E.E.D)localObject4).C())
          {
            localObject5 = ((twaver.base.A.D.E.E.D)localObject4).H();
            if ((localObject5 != localObject3) && (((O)localObject5).C((O)localObject3) == null))
            {
              localObject6 = this.A.A((O)localObject3, (O)localObject5);
              localK.A(localObject6, true);
              localA2.add(localObject6);
              break;
            }
            ((twaver.base.A.D.E.E.D)localObject4).B();
          }
        }
        if (localA2.size() < ((O)localObject1).G() - 1)
        {
          int j = 2147483647;
          localObject5 = null;
          localObject6 = ((O)localObject1).N();
          while (((twaver.base.A.D.E.E.D)localObject6).C())
          {
            localObject7 = ((twaver.base.A.D.E.E.D)localObject6).H();
            if (((O)localObject7).G() < j)
            {
              localObject5 = localObject7;
              j = ((O)localObject7).G();
            }
            ((twaver.base.A.D.E.E.D)localObject6).B();
          }
          localObject6 = ((O)localObject1).N();
          while (((twaver.base.A.D.E.E.D)localObject6).C())
          {
            localObject7 = ((twaver.base.A.D.E.E.D)localObject6).H();
            if ((((O)localObject5).C((O)localObject7) == null) && (localObject5 != localObject7))
            {
              twaver.base.A.D.E.E.G localG2 = this.A.A((O)localObject5, (O)localObject7);
              localK.A(localG2, true);
              localA2.add(localG2);
              if (localA2.size() >= ((O)localObject1).G() - 1) {
                break;
              }
            }
            ((twaver.base.A.D.E.E.D)localObject6).B();
          }
        }
      }
      localObject3 = ((O)localObject1).N();
      while (((twaver.base.A.D.E.E.D)localObject3).C())
      {
        localD.B(((twaver.base.A.D.E.E.D)localObject3).H());
        ((twaver.base.A.D.E.E.D)localObject3).B();
      }
      localObject3 = localA2.J();
      while (((R)localObject3).C())
      {
        localG1 = ((R)localObject3).I();
        if (localK.B(localG1))
        {
          localD.A(localG1.W());
          localD.A(localG1.T());
        }
        ((R)localObject3).B();
      }
      localA1.A(localA2);
      localF.B((O)localObject1);
      i--;
    }
    localF.B();
    localD.A();
    Object localObject1 = localA1.J();
    while (((R)localObject1).C())
    {
      localObject2 = ((R)localObject1).I();
      if (((twaver.base.A.D.E.E.G)localObject2).R() != null) {
        if (localK.B(localObject2)) {
          this.A.C((twaver.base.A.D.E.E.G)localObject2);
        } else {
          this.A.E((twaver.base.A.D.E.E.G)localObject2);
        }
      }
      ((R)localObject1).B();
    }
    localObject1 = twaver.base.A.D.E.F.D.A(this.A);
    Object localObject2 = new Q();
    Object localObject3 = (twaver.base.A.D.E.E.G)((twaver.base.A.D.E.E.A)localObject1).A(0);
    twaver.base.A.D.E.E.G localG1 = (twaver.base.A.D.E.E.G)((twaver.base.A.D.E.E.A)localObject1).A(1);
    Object localObject5 = null;
    if ((((twaver.base.A.D.E.E.G)localObject3).W() == localG1.W()) || (((twaver.base.A.D.E.E.G)localObject3).W() == localG1.T())) {
      localObject5 = ((twaver.base.A.D.E.E.G)localObject3).T();
    } else {
      localObject5 = ((twaver.base.A.D.E.E.G)localObject3).W();
    }
    ((Q)localObject2).add(localObject5);
    Object localObject6 = ((twaver.base.A.D.E.E.A)localObject1).J();
    while (((R)localObject6).C())
    {
      localObject7 = ((R)localObject6).I();
      localObject5 = ((twaver.base.A.D.E.E.G)localObject7).E((O)localObject5);
      ((Q)localObject2).add(localObject5);
      ((R)localObject6).B();
    }
    localObject6 = localA1.J();
    while (((R)localObject6).C())
    {
      localObject7 = ((R)localObject6).I();
      if ((!localK.B(localObject7)) && (((twaver.base.A.D.E.E.G)localObject7).R() == null)) {
        this.A.B((twaver.base.A.D.E.E.G)localObject7);
      }
      ((R)localObject6).B();
    }
    this.A.A(localI2);
    this.A.A(localK);
    this.A.A(localI1);
    A((Q)localObject2);
    return localObject2;
  }
  
  void A(Q paramQ)
  {
    if (paramQ.size() < this.A.B())
    {
      I localI = this.A.H();
      O localO1;
      for (Object localObject = paramQ.G(); localObject != null; localObject = ((M)localObject).A())
      {
        localO1 = (O)((M)localObject).B();
        localI.B(localO1, localObject);
      }
      localObject = new twaver.base.A.D.E.B.D(this.A, new _B(localI), 0, paramQ.size(), new _B(localI));
      while (!((twaver.base.A.D.E.B.D)localObject).C())
      {
        localO1 = ((twaver.base.A.D.E.B.D)localObject).D();
        twaver.base.A.D.E.E.D localD = localO1.N();
        O localO2;
        while (localD.C())
        {
          localO2 = localD.H();
          if (localI.D(localO2) != null)
          {
            M localM1 = (M)localI.D(localO2);
            O localO3 = (O)paramQ.D(localM1).B();
            M localM2 = null;
            if (localO1.C(localO3) != null) {
              localM2 = paramQ.A(localO1, localM1);
            } else {
              localM2 = paramQ.B(localO1, localM1);
            }
            localI.B(localO1, localM2);
            break;
          }
          localD.B();
        }
        localD = localO1.N();
        while (localD.C())
        {
          localO2 = localD.H();
          if (localI.D(localO2) == null) {
            ((twaver.base.A.D.E.B.D)localObject).A(localO2);
          }
          localD.B();
        }
      }
      this.A.A(localI);
      ((twaver.base.A.D.E.B.D)localObject).A();
    }
  }
  
  int B(C paramC)
  {
    int i = 0;
    twaver.base.A.D.E.E.D localD = paramC.J();
    while (localD.C())
    {
      i = Math.max(i, localD.H().G());
      localD.B();
    }
    return i;
  }
  
  class _B
    extends twaver.base.A.D.E.B.G
  {
    I A;
    
    public int A(Object paramObject)
    {
      int i = 0;
      twaver.base.A.D.E.E.D localD = ((O)paramObject).N();
      while (localD.C())
      {
        if (this.A.D(localD.H()) != null) {
          i++;
        }
        localD.B();
      }
      return i;
    }
    
    public boolean B(Object paramObject)
    {
      return this.A.D((O)paramObject) == null;
    }
    
    _B(I paramI)
    {
      this.A = paramI;
    }
  }
  
  static class _A
    extends twaver.base.A.D.E.B.G
  {
    public int A(Object paramObject)
    {
      return ((O)paramObject).G();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B.B
 * JD-Core Version:    0.7.0.1
 */
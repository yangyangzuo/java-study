package twaver.base.A.D.E.E;

public class G
  extends N
{
  G[] J;
  G[] L;
  O K;
  O N;
  int M;
  C O;
  
  protected G(C paramC, O paramO1, G paramG1, O paramO2, G paramG2, int paramInt1, int paramInt2)
  {
    paramC.B(this, paramO1, paramG1, paramO2, paramG2, paramInt1, paramInt2);
  }
  
  public C R()
  {
    return this.O;
  }
  
  public int U()
  {
    if (this.O.D) {
      this.O.E();
    }
    return this.M;
  }
  
  public O W()
  {
    return this.K;
  }
  
  public O T()
  {
    return this.N;
  }
  
  public O E(O paramO)
  {
    return this.K != paramO ? this.K : this.N;
  }
  
  protected void Q()
  {
    for (int i = 0; i <= 1; i++)
    {
      this.J[i] = null;
      this.L[i] = null;
    }
  }
  
  public G V()
  {
    return this.J[0];
  }
  
  public G S()
  {
    return this.J[1];
  }
  
  void A(C paramC, O paramO1, O paramO2, int paramInt)
  {
    A(paramInt);
    this.O = paramC;
    this.J = new G[2];
    this.L = new G[2];
    this.K = paramO1;
    this.N = paramO2;
  }
  
  void B(C paramC)
  {
    this.O = paramC;
  }
  
  boolean D(O paramO)
  {
    return this.K == paramO;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.G
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D;

import java.awt.Rectangle;
import java.util.Vector;
import twaver.base.A.D.E.C.B;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;

public abstract class C
  extends twaver.base.A.D.E.E.C
  implements G
{
  public abstract M J(O paramO);
  
  public abstract K M(twaver.base.A.D.E.E.G paramG);
  
  public M C(Object paramObject)
  {
    return J((O)paramObject);
  }
  
  public K D(Object paramObject)
  {
    return M((twaver.base.A.D.E.E.G)paramObject);
  }
  
  public double K(O paramO)
  {
    M localM = J(paramO);
    return localM.C() + localM.B() / 2.0D;
  }
  
  public double H(O paramO)
  {
    M localM = J(paramO);
    return localM.A() + localM.D() / 2.0D;
  }
  
  public E N(O paramO)
  {
    return new E(K(paramO), H(paramO));
  }
  
  public double O(O paramO)
  {
    return J(paramO).C();
  }
  
  public double I(O paramO)
  {
    return J(paramO).A();
  }
  
  public E P(O paramO)
  {
    M localM = J(paramO);
    return new E(localM.C(), localM.A());
  }
  
  public double L(O paramO)
  {
    return J(paramO).B();
  }
  
  public double Q(O paramO)
  {
    return J(paramO).D();
  }
  
  public twaver.base.A.D.E.C.D R(O paramO)
  {
    return new twaver.base.A.D.E.C.D(L(paramO), Q(paramO));
  }
  
  public twaver.base.A.D.E.C.A M(O paramO)
  {
    return new twaver.base.A.D.E.C.A(P(paramO), R(paramO));
  }
  
  public void B(O paramO, E paramE)
  {
    A(paramO, paramE.B(), paramE.A());
  }
  
  public void A(O paramO, double paramDouble1, double paramDouble2)
  {
    M localM = J(paramO);
    localM.A(paramDouble1 - localM.B() / 2.0D, paramDouble2 - localM.D() / 2.0D);
  }
  
  public void C(O paramO, double paramDouble1, double paramDouble2)
  {
    J(paramO).B(paramDouble1, paramDouble2);
  }
  
  public void A(O paramO, twaver.base.A.D.E.C.D paramD)
  {
    C(paramO, paramD.A(), paramD.B());
  }
  
  public void B(O paramO, double paramDouble1, double paramDouble2)
  {
    J(paramO).A(paramDouble1, paramDouble2);
  }
  
  public void A(O paramO, E paramE)
  {
    B(paramO, paramE.B(), paramE.A());
  }
  
  public twaver.base.A.D.E.C.G N(twaver.base.A.D.E.E.G paramG)
  {
    K localK = M(paramG);
    Vector localVector = new Vector(localK.B());
    for (int i = 0; i < localK.B(); i++) {
      localVector.addElement(localK.A(i));
    }
    return new twaver.base.A.D.E.C.G(localVector);
  }
  
  public S P(twaver.base.A.D.E.E.G paramG)
  {
    K localK = M(paramG);
    S localS = new S();
    for (int i = 0; i < localK.B(); i++) {
      localS.add(localK.A(i));
    }
    return localS;
  }
  
  public twaver.base.A.D.E.C.G J(twaver.base.A.D.E.E.G paramG)
  {
    Vector localVector = new Vector();
    localVector.addElement(I(paramG));
    B localB = N(paramG).C();
    while (localB.C())
    {
      localVector.addElement(localB.D());
      localB.B();
    }
    localVector.addElement(O(paramG));
    return new twaver.base.A.D.E.C.G(localVector);
  }
  
  public S K(twaver.base.A.D.E.E.G paramG)
  {
    S localS = new S();
    localS.add(I(paramG));
    B localB = N(paramG).C();
    while (localB.C())
    {
      localS.add(localB.D());
      localB.B();
    }
    localS.add(O(paramG));
    return localS;
  }
  
  public void A(twaver.base.A.D.E.E.G paramG, S paramS)
  {
    K localK = M(paramG);
    localK.A();
    F localF = paramS.F();
    E localE1 = (E)localF.D();
    B(paramG, localE1);
    E localE2 = (E)paramS.H();
    localF.B();
    while (localF.D() != localE2)
    {
      E localE3 = (E)localF.D();
      localK.A(localE3.B(), localE3.A());
      localF.B();
    }
    A(paramG, localE2);
  }
  
  public void A(twaver.base.A.D.E.E.G paramG, twaver.base.A.D.E.C.G paramG1)
  {
    K localK = M(paramG);
    localK.A();
    B localB = paramG1.C();
    while (localB.C())
    {
      E localE = localB.J();
      localK.A(localE.B(), localE.A());
      localB.B();
    }
  }
  
  public void B(twaver.base.A.D.E.E.G paramG, S paramS)
  {
    K localK = M(paramG);
    localK.A();
    F localF = paramS.F();
    while (localF.C())
    {
      E localE = (E)localF.D();
      localK.A(localE.B(), localE.A());
      localF.B();
    }
  }
  
  public void A(twaver.base.A.D.E.E.G paramG, E paramE1, E paramE2)
  {
    B(paramG, paramE1);
    A(paramG, paramE2);
  }
  
  public E L(twaver.base.A.D.E.E.G paramG)
  {
    return M(paramG).D();
  }
  
  public E H(twaver.base.A.D.E.E.G paramG)
  {
    return M(paramG).C();
  }
  
  public void D(twaver.base.A.D.E.E.G paramG, E paramE)
  {
    M(paramG).B(paramE);
  }
  
  public void C(twaver.base.A.D.E.E.G paramG, E paramE)
  {
    M(paramG).A(paramE);
  }
  
  public E I(twaver.base.A.D.E.E.G paramG)
  {
    E localE1 = M(paramG).D();
    if (localE1 == null) {
      return N(paramG.W());
    }
    E localE2 = new E(K(paramG.W()) + localE1.B(), H(paramG.W()) + localE1.A());
    return localE2;
  }
  
  public E O(twaver.base.A.D.E.E.G paramG)
  {
    E localE1 = M(paramG).C();
    if (localE1 == null) {
      return N(paramG.T());
    }
    E localE2 = new E(K(paramG.T()) + localE1.B(), H(paramG.T()) + localE1.A());
    return localE2;
  }
  
  public void B(twaver.base.A.D.E.E.G paramG, E paramE)
  {
    E localE = new E(paramE.B() - K(paramG.W()), paramE.A() - H(paramG.W()));
    M(paramG).B(localE);
  }
  
  public void A(twaver.base.A.D.E.E.G paramG, E paramE)
  {
    E localE = new E(paramE.B() - K(paramG.T()), paramE.A() - H(paramG.T()));
    M(paramG).A(localE);
  }
  
  public twaver.base.A.D.E.E.A O()
  {
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A();
    R localR = M();
    while (localR.C())
    {
      localA.add(localR.I());
      localR.B();
    }
    return localA;
  }
  
  public Rectangle N()
  {
    double d1;
    double d2 = d1 = 1.7976931348623157E+308D;
    double d3;
    double d4 = d3 = -1.797693134862316E+308D;
    Object localObject1 = J();
    Object localObject2;
    Object localObject3;
    while (((twaver.base.A.D.E.E.D)localObject1).C())
    {
      localObject2 = P(((twaver.base.A.D.E.E.D)localObject1).H());
      localObject3 = R(((twaver.base.A.D.E.E.D)localObject1).H());
      d2 = Math.min(((E)localObject2).B(), d2);
      d1 = Math.min(((E)localObject2).A(), d1);
      d4 = Math.max(((E)localObject2).B() + ((twaver.base.A.D.E.C.D)localObject3).A(), d4);
      d3 = Math.max(((E)localObject2).A() + ((twaver.base.A.D.E.C.D)localObject3).B(), d3);
      ((twaver.base.A.D.E.E.D)localObject1).B();
    }
    localObject1 = M();
    while (((R)localObject1).C())
    {
      localObject2 = N(((R)localObject1).I()).B();
      while (((F)localObject2).C())
      {
        localObject3 = (E)((F)localObject2).D();
        d2 = Math.min(((E)localObject3).B(), d2);
        d1 = Math.min(((E)localObject3).A(), d1);
        d4 = Math.max(((E)localObject3).B(), d4);
        d3 = Math.max(((E)localObject3).A(), d3);
        ((F)localObject2).B();
      }
      ((R)localObject1).B();
    }
    return new Rectangle((int)d2, (int)d1, (int)(d4 - d2), (int)(d3 - d1));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.D.C;

import java.util.Vector;
import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.E.S;
import twaver.base.A.E.T;

public class N
  extends twaver.base.A.D.E.D.E
{
  private long i;
  private long l = 2147483647L;
  private double o = 60.0D;
  private double j = 20.0D;
  private double m = 20.0D;
  private double k = 20.0D;
  private I h;
  private B n;
  private C g;
  
  public N()
  {
    A(false);
    this.h = new D();
    this.n = new M();
    this.g = new H();
  }
  
  public double G()
  {
    return this.m;
  }
  
  public boolean M(twaver.base.A.D.E.D.C paramC)
  {
    return true;
  }
  
  public void N(twaver.base.A.D.E.D.C paramC)
  {
    this.i = System.currentTimeMillis();
    twaver.base.A.D.E.D.L.A(paramC, false);
    twaver.base.A.D.E.E.I localI1 = paramC.H();
    twaver.base.A.D.E.E.I localI2 = paramC.H();
    twaver.base.A.D.E.E.K localK = paramC.F();
    A localA = new A();
    L localL = new L(paramC, localI1, localI2, localK);
    localL.A(G());
    this.g.B(this.j);
    this.g.D(this.o);
    this.g.A(this.m);
    this.g.C(this.k);
    this.g.A(localI2);
    int i1 = this.h.A(paramC, localI1, localA);
    Object localObject = localA.J();
    while (((R)localObject).C())
    {
      twaver.base.A.D.E.E.G localG = ((R)localObject).I();
      localK.A(localG, true);
      twaver.base.A.D.E.C.E localE = paramC.L(localG);
      paramC.D(localG, paramC.H(localG));
      paramC.C(localG, localE);
      ((R)localObject).B();
    }
    A(paramC, localI1, localI2);
    i1 = localL.A(i1);
    localObject = A(paramC, localI1, i1);
    localObject = localL.A((Q[])localObject);
    localObject = localL.B((Q[])localObject);
    this.g.A(paramC, (Q[])localObject, localI1);
    localObject = localL.F((Q[])localObject);
    localL.G((Q[])localObject);
    A(paramC, localI2);
    O(paramC);
    A(paramC, localA);
    localL.A();
    paramC.A(localK);
    paramC.A(localI2);
    paramC.A(localI1);
  }
  
  protected Q[] A(twaver.base.A.D.E.D.C paramC, twaver.base.A.D.E.E.I paramI, int paramInt)
  {
    if ((this.n instanceof M))
    {
      localObject = (M)this.n;
      long l1 = System.currentTimeMillis() - this.i;
      ((M)localObject).A(this.l - l1);
    }
    Object localObject = this.n.A(paramC, paramI, paramInt);
    return localObject;
  }
  
  private void A(twaver.base.A.D.E.D.C paramC, A paramA)
  {
    R localR = paramA.J();
    while (localR.C())
    {
      twaver.base.A.D.E.E.G localG = localR.I();
      twaver.base.A.D.E.C.E localE1 = paramC.I(localG);
      twaver.base.A.D.E.C.E localE2 = paramC.O(localG);
      paramC.G(localG);
      twaver.base.A.D.E.C.G localG1 = paramC.N(localG);
      paramC.A(localG, localG1.A());
      paramC.A(localG, localE1);
      paramC.B(localG, localE2);
      localR.B();
    }
  }
  
  private void A(twaver.base.A.D.E.D.C paramC, twaver.base.A.D.E.E.I paramI)
  {
    twaver.base.A.D.E.E.D localD = paramC.J();
    while (localD.C())
    {
      Object localObject1 = localD.H();
      twaver.base.A.D.E.E.G localG = (twaver.base.A.D.E.E.G)paramI.D(localObject1);
      if ((localG != null) && (!paramC.A(localG)))
      {
        for (Object localObject2 = ((O)localObject1).E().I().W(); paramI.D(localObject2) != null; localObject2 = ((O)localObject1).E().I().W()) {
          localObject1 = localObject2;
        }
        paramC.B(localG);
        localObject2 = ((O)localObject1).L();
        S localS = new S();
        while (paramI.D(((twaver.base.A.D.E.E.G)localObject2).T()) != null)
        {
          localE1 = paramC.I((twaver.base.A.D.E.E.G)localObject2);
          localS.add(localE1);
          localS.A(paramC.P((twaver.base.A.D.E.E.G)localObject2));
          localE2 = paramC.O((twaver.base.A.D.E.E.G)localObject2);
          if (!localE2.equals(localE1)) {
            localS.add(localE2);
          }
          localObject2 = ((twaver.base.A.D.E.E.G)localObject2).T().K();
        }
        twaver.base.A.D.E.C.E localE1 = paramC.I((twaver.base.A.D.E.E.G)localObject2);
        localS.add(localE1);
        localS.A(paramC.P((twaver.base.A.D.E.E.G)localObject2));
        twaver.base.A.D.E.C.E localE2 = paramC.O((twaver.base.A.D.E.E.G)localObject2);
        if (!localE2.equals(localE1)) {
          localS.add(localE2);
        }
        paramC.A(localG, localS);
      }
      localD.B();
    }
    localD = paramC.J();
    while (localD.C())
    {
      if (paramI.D(localD.H()) != null) {
        paramC.B(localD.H());
      }
      localD.B();
    }
  }
  
  private void O(twaver.base.A.D.E.D.C paramC)
  {
    R localR = paramC.M();
    while (localR.C())
    {
      twaver.base.A.D.E.E.G localG = localR.I();
      twaver.base.A.D.E.D.K localK = paramC.M(localG);
      if (localK.B() > 0)
      {
        Vector localVector = new Vector(localK.B());
        twaver.base.A.D.E.C.G localG1 = paramC.J(localG);
        F localF = localG1.B();
        twaver.base.A.D.E.C.E localE1 = (twaver.base.A.D.E.C.E)localF.D();
        localF.B();
        double d1 = localE1.B();
        double d2 = localE1.A();
        if (localF.C())
        {
          Object localObject = (twaver.base.A.D.E.C.E)localF.D();
          double d3 = ((twaver.base.A.D.E.C.E)localObject).B();
          double d4 = ((twaver.base.A.D.E.C.E)localObject).A();
          localF.B();
          while (localF.C())
          {
            twaver.base.A.D.E.C.E localE2 = (twaver.base.A.D.E.C.E)localF.D();
            double d5 = localE2.B();
            double d6 = localE2.A();
            double d7 = (d1 - d5) * (d4 - d6) / (d2 - d6) + d5;
            if (Math.abs(d7 - d3) >= 1.0D)
            {
              localVector.add(localObject);
              d1 = d3;
              d2 = d4;
            }
            localObject = localE2;
            d3 = d5;
            d4 = d6;
            localF.B();
          }
        }
        if (localVector.size() < localK.B()) {
          paramC.A(localG, new twaver.base.A.D.E.C.G(localVector));
        }
      }
      localR.B();
    }
  }
  
  private void A(twaver.base.A.D.E.D.C paramC, twaver.base.A.D.E.E.I paramI1, twaver.base.A.D.E.E.I paramI2)
  {
    R localR = paramC.O().J();
    localR.A();
    while (localR.C())
    {
      O localO1 = localR.I().W();
      O localO2 = localR.I().T();
      int i1 = paramI1.A(localO2) - paramI1.A(localO1);
      if (i1 > 1)
      {
        O localO3 = null;
        twaver.base.A.D.E.E.G localG = null;
        O localO4 = localO1;
        while (i1 > 1)
        {
          localO3 = paramC.I();
          paramC.C(localO3, 1.0D, 1.0D);
          paramC.A(localO3, T.D);
          localG = paramC.A(localO4, localO3);
          if (localO4 == localO1) {
            paramC.D(localG, paramC.L(localR.I()));
          }
          paramI1.B(localO3, paramI1.A(localO4) + 1);
          paramI2.B(localO3, localR.I());
          localO4 = localO3;
          i1--;
        }
        localG = paramC.A(localO3, localO2);
        paramC.C(localG, paramC.H(localR.I()));
        paramC.E(localR.I());
      }
      localR.G();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.C.N
 * JD-Core Version:    0.7.0.1
 */
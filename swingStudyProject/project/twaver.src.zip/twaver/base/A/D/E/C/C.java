package twaver.base.A.D.E.C;

public class C
{
  private double A;
  private double B;
  private double C;
  
  public C(E paramE1, E paramE2)
  {
    if (A(paramE1.B(), paramE2.B()))
    {
      this.A = 1.0D;
      this.B = 0.0D;
      this.C = (-paramE1.B());
      return;
    }
    this.B = -1.0D;
    double d1 = (paramE2.A() - paramE1.A()) / (paramE2.B() - paramE1.B());
    double d2 = paramE1.A() - paramE1.B() * d1;
    this.A = d1;
    this.C = d2;
  }
  
  public double C()
  {
    return this.A;
  }
  
  public double B()
  {
    return this.B;
  }
  
  public double A()
  {
    return this.C;
  }
  
  public static E A(C paramC1, C paramC2)
  {
    if ((A(paramC1.C())) && (A(paramC2.C()))) {
      return null;
    }
    if ((A(paramC1.B())) && (A(paramC2.B()))) {
      return null;
    }
    if (A(paramC2.B()))
    {
      C localC = paramC1;
      paramC1 = paramC2;
      paramC2 = localC;
    }
    double d1 = paramC1.C();
    double d2 = paramC1.B();
    double d3 = -paramC1.A();
    double d4;
    double d5;
    if (!A(paramC1.C()))
    {
      d4 = paramC2.B() - paramC2.C() / paramC1.C() * paramC1.B();
      d5 = -paramC2.A() - paramC2.C() / paramC1.C() * -paramC1.A();
    }
    else
    {
      d4 = paramC2.B();
      d5 = -paramC2.A();
    }
    double d6 = d5 / d4;
    double d7 = (d3 - d6 * d2) / d1;
    return new E(d7, d6);
  }
  
  private static boolean A(double paramDouble)
  {
    return A(paramDouble, 0.0D);
  }
  
  private static boolean A(double paramDouble1, double paramDouble2)
  {
    return Math.abs(paramDouble1 - paramDouble2) < 1.E-005D;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.C
 * JD-Core Version:    0.7.0.1
 */
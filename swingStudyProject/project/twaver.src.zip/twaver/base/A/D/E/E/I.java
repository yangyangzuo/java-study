package twaver.base.A.D.E.E;

public abstract interface I
  extends L
{
  public abstract void B(Object paramObject1, Object paramObject2);
  
  public abstract Object D(Object paramObject);
  
  public abstract void B(Object paramObject, boolean paramBoolean);
  
  public abstract boolean B(Object paramObject);
  
  public abstract void B(Object paramObject, double paramDouble);
  
  public abstract double C(Object paramObject);
  
  public abstract void B(Object paramObject, int paramInt);
  
  public abstract int A(Object paramObject);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.I
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.F;

import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;

public class E
{
  public static Q A(C paramC)
  {
    int[] arrayOfInt = new int[paramC.C()];
    new _A(null).A(paramC, arrayOfInt);
    return A(paramC, arrayOfInt);
  }
  
  public static Q A(C paramC, int[] paramArrayOfInt)
  {
    O[] arrayOfO = new O[paramC.B()];
    D localD = paramC.J();
    while (localD.C())
    {
      O localO = localD.H();
      int i = localO.F();
      arrayOfO[paramArrayOfInt[i]] = localO;
      localD.B();
    }
    return new Q(arrayOfO);
  }
  
  private static class _A
  {
    int A;
    
    private _A() {}
    
    private void A(C paramC, int[] paramArrayOfInt)
    {
      this.A = 0;
      for (int i = paramArrayOfInt.length - 1; i >= 0; i--) {
        paramArrayOfInt[i] = -1;
      }
      D localD = paramC.J();
      O localO;
      while (localD.C())
      {
        localO = localD.H();
        if (localO.C() == 0)
        {
          A(localO, localO.F(), paramArrayOfInt);
          break;
        }
        localD.B();
      }
      localD = paramC.J();
      while (localD.C())
      {
        localO = localD.H();
        int j = localO.F();
        if (paramArrayOfInt[j] == -1) {
          A(localO, j, paramArrayOfInt);
        }
        localD.B();
      }
    }
    
    private void A(O paramO, int paramInt, int[] paramArrayOfInt)
    {
      paramArrayOfInt[paramInt] = -2;
      for (G localG = paramO.K(); localG != null; localG = localG.V())
      {
        O localO = localG.T();
        int i = localO.F();
        switch (paramArrayOfInt[i])
        {
        case -1: 
          A(localO, i, paramArrayOfInt);
        }
      }
      paramArrayOfInt[paramInt] = (this.A++);
    }
    
    _A(_A param_A)
    {
      this();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.E
 * JD-Core Version:    0.7.0.1
 */
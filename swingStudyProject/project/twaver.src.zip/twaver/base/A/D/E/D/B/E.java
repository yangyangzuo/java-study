package twaver.base.A.D.E.D.B;

import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.D.L;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.F.A;

public class E
  extends twaver.base.A.D.E.D.E
{
  private C e;
  private A c = new B();
  private int d = 30;
  private double f = 5.0D;
  
  public boolean M(C paramC)
  {
    return true;
  }
  
  public void N(C paramC)
  {
    this.e = paramC;
    L.A(paramC);
    D localD1 = this.c.A(paramC);
    double d1 = 0.0D;
    D localD2 = paramC.J();
    while (localD2.C())
    {
      d1 = Math.max(d1, L(localD2.H()));
      localD2.B();
    }
    if (d1 < this.f) {
      d1 = this.f;
    }
    A(localD1, d1);
  }
  
  double A(D paramD, double paramDouble)
  {
    int i = paramD.F();
    double d1 = Math.toRadians(360.0D / i);
    double d2 = 0.0D;
    double[] arrayOfDouble = new double[i];
    paramD.E();
    int j = 0;
    while (j < i)
    {
      arrayOfDouble[j] = (L(paramD.H()) + this.d);
      d2 += arrayOfDouble[j];
      j++;
      paramD.B();
    }
    double d3 = d2 / i;
    double d4 = d2 / 6.283185307179586D;
    if (d4 < paramDouble) {
      d4 = paramDouble;
    }
    paramD.E();
    double d5 = 0.0D;
    int k = 0;
    while (k < i)
    {
      double d6 = d1 / d3 * arrayOfDouble[k];
      d5 += d6 / 2.0D;
      double d7 = Math.cos(d5) * d4;
      double d8 = Math.sin(d5) * d4;
      d5 += d6 / 2.0D;
      this.e.A(paramD.H(), d7, d8);
      k++;
      paramD.B();
    }
    return d4;
  }
  
  double L(O paramO)
  {
    double d1 = this.e.L(paramO);
    double d2 = this.e.Q(paramO);
    return d1 <= d2 ? d2 : d1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B.E
 * JD-Core Version:    0.7.0.1
 */
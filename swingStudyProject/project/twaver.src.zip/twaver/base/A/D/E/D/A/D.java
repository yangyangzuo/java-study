package twaver.base.A.D.E.D.A;

import twaver.base.A.D.E.D.C;
import twaver.base.A.D.E.E.O;

class D
{
  C A;
  O B;
  
  public D(C paramC)
  {
    this.A = paramC;
    C();
  }
  
  public O A()
  {
    if (this.B == null) {
      C();
    }
    return this.B;
  }
  
  public int B()
  {
    if (this.B == null) {
      return -1;
    }
    return B(this.B);
  }
  
  private int B(O paramO)
  {
    int i = 0;
    twaver.base.A.D.E.E.D localD = paramO.J();
    while (localD.C())
    {
      i = Math.max(i, B(localD.H()));
      localD.B();
    }
    return i + 1;
  }
  
  public boolean A(O paramO)
  {
    return paramO.O() == 0;
  }
  
  private void C()
  {
    twaver.base.A.D.E.E.D localD = this.A.J();
    while (localD.C())
    {
      if (localD.H().C() == 0)
      {
        this.B = localD.H();
        return;
      }
      localD.B();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.A.D
 * JD-Core Version:    0.7.0.1
 */
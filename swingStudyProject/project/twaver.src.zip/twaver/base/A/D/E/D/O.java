package twaver.base.A.D.E.D;

import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;

public class O
  extends C
{
  private I I = H();
  private twaver.base.A.D.E.E.K H = F();
  
  public M J(twaver.base.A.D.E.E.O paramO)
  {
    M localM = (M)this.I.D(paramO);
    if (localM == null)
    {
      localM = Q();
      this.I.B(paramO, localM);
    }
    return localM;
  }
  
  public K M(G paramG)
  {
    K localK = (K)this.H.D(paramG);
    if (localK == null)
    {
      localK = P();
      this.H.A(paramG, localK);
    }
    return localK;
  }
  
  protected K P()
  {
    return new Q();
  }
  
  protected M Q()
  {
    return new D();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.O
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.F;

import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;
import twaver.base.A.E.T;

public class C
{
  private K F;
  private int E;
  private int D;
  private boolean A = true;
  private boolean C = false;
  protected I B;
  
  public void B(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }
  
  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public void A(twaver.base.A.D.E.E.C paramC)
  {
    if (paramC.B() == 0) {
      return;
    }
    A(paramC, paramC.J().H());
  }
  
  public void A(twaver.base.A.D.E.E.C paramC, O paramO)
  {
    this.B = paramC.H();
    this.F = paramC.F();
    this.E = 0;
    this.D = 0;
    A(paramO);
    if (this.A)
    {
      D localD = paramC.J();
      while (localD.C())
      {
        O localO = localD.H();
        if (this.B.D(localO) == null)
        {
          B(localO);
          A(localO);
        }
        localD.B();
      }
    }
    paramC.A(this.B);
    paramC.A(this.F);
  }
  
  private void A(O paramO)
  {
    int i = ++this.E;
    this.B.B(paramO, T.C);
    A(paramO, i);
    R localR = this.C ? paramO.I() : paramO.M();
    while (localR.C())
    {
      G localG = localR.I();
      if (!this.F.B(localG))
      {
        this.F.A(localG, true);
        O localO = localG.E(paramO);
        if (this.B.D(localO) == null)
        {
          A(localG, localO, true);
          A(localO);
          A(localG, localO);
        }
        else
        {
          A(localG, localO, false);
        }
      }
      localR.B();
    }
    A(paramO, i, ++this.D);
    this.B.B(paramO, T.B);
  }
  
  protected void A(O paramO, int paramInt) {}
  
  protected void A(O paramO, int paramInt1, int paramInt2) {}
  
  protected void A(G paramG, O paramO, boolean paramBoolean) {}
  
  protected void A(G paramG, O paramO) {}
  
  protected void B(O paramO) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.F.C
 * JD-Core Version:    0.7.0.1
 */
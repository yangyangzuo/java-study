package twaver.base.A.D.E.D.B;

import twaver.base.A.D.E.D.A.C;
import twaver.base.A.D.E.D.A.C._B;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.K;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.R;

class A
  extends C
{
  I W;
  K Z;
  boolean X = false;
  double Y = 90.0D;
  
  void A(K paramK, I paramI)
  {
    this.W = paramI;
    this.Z = paramK;
    this.X = true;
  }
  
  protected void H(O paramO)
  {
    if (!K(paramO))
    {
      super.H(paramO);
      return;
    }
    double d1 = C();
    double d2 = E(paramO);
    double d3 = (360.0D - d2) / 2.0D + d2;
    twaver.base.A.D.E.E.A localA = new twaver.base.A.D.E.E.A(paramO.I());
    for (;;)
    {
      double d4 = C(paramO);
      d4 = (360.0D - d2) / 2.0D;
      Object localObject1 = null;
      Object localObject2 = null;
      Object localObject3;
      for (M localM = localA.G(); localM != null; localM = localM.A())
      {
        localObject3 = (G)localM.B();
        O localO1 = ((G)localObject3).T();
        C._B local_B1 = B(localO1);
        double d7 = this.Z.C(localObject3);
        double d8 = d7 - (d4 + local_B1.D);
        if ((d8 >= 0.0D) && (d7 + local_B1.C >= d3)) {
          if (d4 + local_B1.A() <= d3) {
            d8 = d3 - d4 - local_B1.A();
          } else {
            d8 = 2.0D * (d3 - (d7 + local_B1.C));
          }
        }
        local_B1.F = 0.0D;
        if (d8 >= 0.0D)
        {
          local_B1.F = d8;
          localObject1 = localM;
          localObject2 = local_B1;
        }
        else
        {
          if (-d8 > local_B1.C + local_B1.D) {
            d8 = (local_B1.C + local_B1.D) / 2.0D;
          } else {
            d8 /= -2.0D;
          }
          d4 -= d8;
          if ((d4 <= d3) && (d4 + local_B1.A() > d3))
          {
            d4 += d8;
            d8 = d4 + local_B1.A() - d3;
            d4 -= d8;
          }
          while ((localObject1 != null) && (d8 > ((C._B)localObject2).F))
          {
            d8 -= ((C._B)localObject2).F;
            ((C._B)localObject2).F = 0.0D;
            localObject1 = ((M)localObject1).C();
            if (localObject1 == null)
            {
              localObject2 = null;
              break;
            }
            localObject2 = B(((G)((M)localObject1).B()).T());
          }
          if (localObject1 != null) {
            localObject2.F -= d8;
          } else {
            d4 += d8;
          }
        }
        d4 += local_B1.A();
      }
      if (d4 <= d3)
      {
        double d5 = 0.0D;
        double d6 = (360.0D - d2) / 2.0D;
        R localR = paramO.I();
        while (localR.C())
        {
          G localG = localR.I();
          O localO2 = localG.T();
          double d9 = this.Z.C(localG);
          C._B local_B2 = B(localO2);
          double d10 = d6 + local_B2.F + local_B2.D;
          if (d5 < Math.abs(d10 - d9)) {
            d5 = Math.abs(d10 - d9);
          }
          d6 += local_B2.A();
          localR.B();
        }
        if (d5 <= this.Y) {
          break;
        }
      }
      D localD = paramO.J();
      while (localD.C())
      {
        localObject3 = localD.H();
        B((O)localObject3).E *= (1.0D + d1);
        localD.B();
      }
    }
  }
  
  protected double E(O paramO)
  {
    if (!K(paramO)) {
      return super.E(paramO);
    }
    if (paramO.C() == 0) {
      return D();
    }
    return F();
  }
  
  boolean K(O paramO)
  {
    if ((!this.X) || (paramO.O() == 0)) {
      return false;
    }
    return this.Z.D(paramO.K()) != null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.B.A
 * JD-Core Version:    0.7.0.1
 */
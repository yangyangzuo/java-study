package twaver.base.A.D.E.B;

import twaver.base.A.D.E.E.A;
import twaver.base.A.D.E.E.C;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.G;
import twaver.base.A.D.E.E.O;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;

public class F
{
  private C A;
  protected A C;
  protected Q B;
  
  public F(C paramC)
  {
    this.A = paramC;
    this.C = new A();
    this.B = new Q();
  }
  
  public void D()
  {
    D localD = this.A.J();
    while (localD.C())
    {
      B(localD.H());
      localD.B();
    }
  }
  
  public void B()
  {
    A();
    C();
  }
  
  public void A()
  {
    while (!this.B.isEmpty())
    {
      O localO = this.B.N();
      if (!this.A.E(localO)) {
        A(localO);
      }
    }
  }
  
  public void C()
  {
    while (!this.C.isEmpty())
    {
      G localG = this.C.K();
      if (!this.A.A(localG)) {
        A(localG);
      }
    }
  }
  
  public void B(O paramO)
  {
    R localR = paramO.M();
    while (localR.C())
    {
      this.C.C(localR.I());
      this.A.E(localR.I());
      localR.B();
    }
    this.B.C(paramO);
    this.A.F(paramO);
  }
  
  public static void B(C paramC, R paramR)
  {
    paramR.E();
    while (paramR.C())
    {
      G localG = paramR.I();
      if (!paramC.E(localG.W())) {
        paramC.G(localG.W());
      }
      if (!paramC.E(localG.T())) {
        paramC.G(localG.T());
      }
      if (!paramC.A(localG)) {
        paramC.B(localG);
      }
      paramR.B();
    }
  }
  
  public static void A(C paramC, R paramR)
  {
    paramR.E();
    while (paramR.C())
    {
      G localG = paramR.I();
      if (paramC.A(localG)) {
        paramC.E(localG);
      }
      if (localG.W().G() == 0) {
        paramC.F(localG.W());
      }
      if (localG.T().G() == 0) {
        paramC.F(localG.T());
      }
      paramR.B();
    }
  }
  
  protected void A(G paramG)
  {
    this.A.B(paramG);
  }
  
  protected void A(O paramO)
  {
    this.A.G(paramO);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.F
 * JD-Core Version:    0.7.0.1
 */
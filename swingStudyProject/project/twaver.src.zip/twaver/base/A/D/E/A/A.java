package twaver.base.A.D.E.A;

public class A
{
  double A;
  double B;
  
  public void A(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.B = paramDouble2;
  }
  
  public double B()
  {
    return this.A;
  }
  
  public double A()
  {
    return this.B;
  }
  
  protected A(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.B = paramDouble2;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.A.A
 * JD-Core Version:    0.7.0.1
 */
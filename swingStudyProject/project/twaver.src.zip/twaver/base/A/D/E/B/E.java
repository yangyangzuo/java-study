package twaver.base.A.D.E.B;

import java.util.Random;

public class E
  extends Random
{
  public E() {}
  
  public E(long paramLong)
  {
    super(paramLong);
  }
  
  public int nextInt(int paramInt)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException();
    }
    int i;
    int j;
    do
    {
      i = next(31);
      j = i % paramInt;
    } while (i - j + (paramInt - 1) < 0);
    return j;
  }
  
  public double A(double paramDouble1, double paramDouble2)
  {
    return nextDouble() * (paramDouble2 - paramDouble1) + paramDouble1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.E
 * JD-Core Version:    0.7.0.1
 */
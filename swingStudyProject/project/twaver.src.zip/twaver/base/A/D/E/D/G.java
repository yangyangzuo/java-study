package twaver.base.A.D.E.D;

import java.awt.Rectangle;

public abstract interface G
{
  public abstract M C(Object paramObject);
  
  public abstract K D(Object paramObject);
  
  public abstract Rectangle N();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.G
 * JD-Core Version:    0.7.0.1
 */
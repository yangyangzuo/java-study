package twaver.base.A.D.E.D;

import twaver.base.A.D.E.C.E;

public abstract interface K
{
  public abstract int B();
  
  public abstract E A(int paramInt);
  
  public abstract void A(int paramInt, double paramDouble1, double paramDouble2);
  
  public abstract void A(double paramDouble1, double paramDouble2);
  
  public abstract void A();
  
  public abstract E D();
  
  public abstract E C();
  
  public abstract void B(E paramE);
  
  public abstract void A(E paramE);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.K
 * JD-Core Version:    0.7.0.1
 */
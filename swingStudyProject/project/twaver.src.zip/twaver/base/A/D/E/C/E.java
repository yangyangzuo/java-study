package twaver.base.A.D.E.C;

public final class E
  implements Comparable
{
  public final double A;
  public final double B;
  
  public E(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.B = paramDouble2;
  }
  
  public final double B()
  {
    return this.A;
  }
  
  public final double A()
  {
    return this.B;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof E)) {
      return false;
    }
    E localE = (E)paramObject;
    return (localE.A == this.A) && (localE.B == this.B);
  }
  
  public int hashCode()
  {
    long l = Double.doubleToRawLongBits(this.A) << 1 ^ Double.doubleToRawLongBits(this.B);
    return (int)(l >> 32 ^ l);
  }
  
  public int compareTo(Object paramObject)
  {
    if (this == paramObject) {
      return 0;
    }
    E localE = (E)paramObject;
    if (this.A < localE.A) {
      return -1;
    }
    if (this.A > localE.A) {
      return 1;
    }
    if (this.B < localE.B) {
      return -1;
    }
    return this.B <= localE.B ? 0 : 1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.E
 * JD-Core Version:    0.7.0.1
 */
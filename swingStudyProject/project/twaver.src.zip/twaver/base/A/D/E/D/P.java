package twaver.base.A.D.E.D;

import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import java.util.Vector;
import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.E.D;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.I;
import twaver.base.A.D.E.E.Q;
import twaver.base.A.D.E.E.R;
import twaver.base.A.D.E.F.B;

public class P
  extends H
{
  private double L = 400.0D;
  private double I = 400.0D;
  private double K;
  private double J = 45.0D;
  
  public boolean B(C paramC)
  {
    if (A() != null)
    {
      boolean bool = true;
      I localI = paramC.H();
      int i = B.A(paramC, localI);
      Q[] arrayOfQ = new Q[i];
      twaver.base.A.D.E.E.A[] arrayOfA = new twaver.base.A.D.E.E.A[i];
      for (int j = 0; j < i; j++)
      {
        arrayOfQ[j] = new Q();
        arrayOfA[j] = new twaver.base.A.D.E.E.A();
      }
      Object localObject1 = paramC.M();
      Object localObject2;
      while (((R)localObject1).C())
      {
        localObject2 = ((R)localObject1).I();
        arrayOfA[localI.A(localObject2.W())].add(localObject2);
        paramC.E((twaver.base.A.D.E.E.G)localObject2);
        ((R)localObject1).B();
      }
      localObject1 = paramC.J();
      while (((D)localObject1).C())
      {
        localObject2 = ((D)localObject1).H();
        arrayOfQ[localI.A(localObject2)].add(localObject2);
        paramC.F(((D)localObject1).H());
        ((D)localObject1).B();
      }
      for (int k = 0; k < i; k++)
      {
        localObject2 = arrayOfQ[k].P();
        while (((D)localObject2).C())
        {
          paramC.G(((D)localObject2).H());
          ((D)localObject2).B();
        }
        localObject2 = arrayOfA[k].J();
        while (((R)localObject2).C())
        {
          paramC.B(((R)localObject2).I());
          ((R)localObject2).B();
        }
        bool = C(paramC);
        localObject2 = arrayOfA[k].J();
        while (((R)localObject2).C())
        {
          paramC.E(((R)localObject2).I());
          ((R)localObject2).B();
        }
        localObject2 = arrayOfQ[k].P();
        while (((D)localObject2).C())
        {
          paramC.F(((D)localObject2).H());
          ((D)localObject2).B();
        }
        if (!bool) {
          break;
        }
      }
      for (k = 0; k < i; k++)
      {
        localObject2 = arrayOfQ[k].P();
        while (((D)localObject2).C())
        {
          paramC.G(((D)localObject2).H());
          ((D)localObject2).B();
        }
      }
      for (k = 0; k < i; k++)
      {
        localObject2 = arrayOfA[k].J();
        while (((R)localObject2).C())
        {
          paramC.B(((R)localObject2).I());
          ((R)localObject2).B();
        }
      }
      paramC.A(localI);
      return bool;
    }
    return true;
  }
  
  public void A(C paramC)
  {
    if (paramC.D()) {
      return;
    }
    I localI = paramC.H();
    int i = B.A(paramC, localI);
    Q[] arrayOfQ = new Q[i];
    twaver.base.A.D.E.E.A[] arrayOfA = new twaver.base.A.D.E.E.A[i];
    twaver.base.A.D.E.C.A[] arrayOfA1 = new twaver.base.A.D.E.C.A[i];
    Rectangle2D[] arrayOfRectangle2D = new Rectangle2D[i];
    for (int j = 0; j < i; j++)
    {
      arrayOfQ[j] = new Q();
      arrayOfA[j] = new twaver.base.A.D.E.E.A();
    }
    Object localObject1 = paramC.M();
    Object localObject2;
    while (((R)localObject1).C())
    {
      localObject2 = ((R)localObject1).I();
      arrayOfA[localI.A(localObject2.W())].add(localObject2);
      paramC.E((twaver.base.A.D.E.E.G)localObject2);
      ((R)localObject1).B();
    }
    localObject1 = paramC.J();
    while (((D)localObject1).C())
    {
      localObject2 = ((D)localObject1).H();
      arrayOfQ[localI.A(localObject2)].add(localObject2);
      paramC.F(((D)localObject1).H());
      ((D)localObject1).B();
    }
    for (int k = 0; k < i; k++)
    {
      localObject2 = arrayOfQ[k].P();
      while (((D)localObject2).C())
      {
        paramC.G(((D)localObject2).H());
        ((D)localObject2).B();
      }
      localObject2 = arrayOfA[k].J();
      while (((R)localObject2).C())
      {
        paramC.B(((R)localObject2).I());
        ((R)localObject2).B();
      }
      D(paramC);
      localObject2 = paramC.N();
      arrayOfA1[k] = new twaver.base.A.D.E.C.A(((Rectangle)localObject2).x, ((Rectangle)localObject2).y, ((Rectangle)localObject2).width, ((Rectangle)localObject2).height);
      arrayOfRectangle2D[k] = new Rectangle2D.Double();
      if (this.K > 0.0D)
      {
        double d2 = this.J + Math.ceil((((Rectangle)localObject2).getWidth() + 1.0D) / this.K) * this.K;
        double d4 = this.J + Math.ceil((((Rectangle)localObject2).getHeight() + 1.0D) / this.K) * this.K;
        arrayOfRectangle2D[k].setFrame(((Rectangle)localObject2).getX(), ((Rectangle)localObject2).getY(), d2, d4);
      }
      else
      {
        arrayOfRectangle2D[k].setFrame(((Rectangle)localObject2).getX(), ((Rectangle)localObject2).getY(), ((Rectangle)localObject2).getWidth() + this.J, ((Rectangle)localObject2).getHeight() + this.J);
      }
      Object localObject3 = arrayOfA[k].J();
      while (((R)localObject3).C())
      {
        paramC.E(((R)localObject3).I());
        ((R)localObject3).B();
      }
      localObject3 = arrayOfQ[k].P();
      while (((D)localObject3).C())
      {
        paramC.F(((D)localObject3).H());
        ((D)localObject3).B();
      }
    }
    for (k = 0; k < i; k++)
    {
      localObject2 = arrayOfQ[k].P();
      while (((D)localObject2).C())
      {
        paramC.G(((D)localObject2).H());
        ((D)localObject2).B();
      }
    }
    for (k = 0; k < i; k++)
    {
      localObject2 = arrayOfA[k].J();
      while (((R)localObject2).C())
      {
        paramC.B(((R)localObject2).I());
        ((R)localObject2).B();
      }
    }
    L.A(arrayOfRectangle2D, null, this.L / this.I);
    if (this.K <= 0.0D) {
      for (k = 0; k < arrayOfRectangle2D.length; k++) {
        A(paramC, arrayOfQ[k], arrayOfA[k], new E(arrayOfRectangle2D[k].getX(), arrayOfRectangle2D[k].getY()), arrayOfA1[k]);
      }
    } else {
      for (k = 0; k < arrayOfRectangle2D.length; k++)
      {
        double d1 = Math.floor((arrayOfRectangle2D[k].getX() - arrayOfA1[k].D()) / this.K) * this.K;
        double d3 = Math.floor((arrayOfRectangle2D[k].getY() - arrayOfA1[k].C()) / this.K) * this.K;
        double d5 = arrayOfA1[k].D() + d1;
        double d6 = arrayOfA1[k].C() + d3;
        A(paramC, arrayOfQ[k], arrayOfA[k], new E(d5, d6), arrayOfA1[k]);
      }
    }
    paramC.A(localI);
  }
  
  protected void A(C paramC, Q paramQ, twaver.base.A.D.E.E.A paramA, E paramE, twaver.base.A.D.E.C.A paramA1)
  {
    double d1 = -paramA1.D() + paramE.B();
    double d2 = -paramA1.C() + paramE.A();
    Object localObject1 = paramQ.P();
    Object localObject2;
    while (((D)localObject1).C())
    {
      localObject2 = paramC.P(((D)localObject1).H());
      paramC.A(((D)localObject1).H(), new E(((E)localObject2).B() + d1, ((E)localObject2).A() + d2));
      ((D)localObject1).B();
    }
    localObject1 = paramA.J();
    while (((R)localObject1).C())
    {
      localObject2 = ((R)localObject1).I();
      Vector localVector = new Vector();
      F localF = paramC.N((twaver.base.A.D.E.E.G)localObject2).B();
      while (localF.C())
      {
        E localE = (E)localF.D();
        localVector.addElement(new E(localE.B() + d1, localE.A() + d2));
        localF.B();
      }
      paramC.A((twaver.base.A.D.E.E.G)localObject2, new twaver.base.A.D.E.C.G(localVector));
      ((R)localObject1).B();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.P
 * JD-Core Version:    0.7.0.1
 */
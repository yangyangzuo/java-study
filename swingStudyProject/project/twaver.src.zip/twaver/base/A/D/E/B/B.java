package twaver.base.A.D.E.B;

public class B
{
  private Object[] B;
  private int A;
  
  public B(int paramInt)
  {
    this.B = new Object[paramInt];
    this.A = -1;
  }
  
  public Object B()
  {
    return this.B[this.A];
  }
  
  public Object C()
  {
    return this.B[(this.A--)];
  }
  
  public void A(Object paramObject)
  {
    this.B[(++this.A)] = paramObject;
  }
  
  public boolean A()
  {
    return this.A < 0;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.B.B
 * JD-Core Version:    0.7.0.1
 */
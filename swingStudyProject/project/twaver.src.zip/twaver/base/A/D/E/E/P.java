package twaver.base.A.D.E.E;

class P
{
  private N C;
  private N A;
  private int B;
  
  public int B()
  {
    return this.B;
  }
  
  boolean A()
  {
    return this.B == 0;
  }
  
  N D()
  {
    return this.C;
  }
  
  N B(N paramN)
  {
    return paramN.A();
  }
  
  public void A(N paramN)
  {
    this.B += 1;
    paramN.A(this.A);
    paramN.B(null);
    if (this.A != null)
    {
      this.A.B(paramN);
      this.A = paramN;
    }
    else
    {
      this.A = (this.C = paramN);
    }
  }
  
  void A(N paramN1, N paramN2)
  {
    if (paramN2 == null)
    {
      A(paramN1);
      return;
    }
    N localN = paramN2.B();
    if (localN != null) {
      localN.B(paramN1);
    } else {
      this.C = paramN1;
    }
    paramN1.A(localN);
    paramN1.B(paramN2);
    paramN2.A(paramN1);
    this.B += 1;
  }
  
  void C(N paramN)
  {
    N localN1 = paramN.A();
    N localN2 = paramN.B();
    this.B -= 1;
    if (localN1 != null) {
      localN1.A(localN2);
    } else {
      this.A = localN2;
    }
    if (localN2 != null) {
      localN2.B(localN1);
    } else {
      this.C = localN1;
    }
  }
  
  E C()
  {
    return new _A();
  }
  
  class _A
    implements E
  {
    private N G = P.this.C;
    
    public boolean C()
    {
      return this.G != null;
    }
    
    public void B()
    {
      this.G = this.G.C;
    }
    
    public void G()
    {
      this.G = this.G.B;
    }
    
    public void A()
    {
      this.G = P.this.A;
    }
    
    public void E()
    {
      this.G = P.this.C;
    }
    
    public int F()
    {
      return P.this.B;
    }
    
    public Object D()
    {
      return this.G;
    }
    
    public O H()
    {
      return (O)this.G;
    }
    
    public G I()
    {
      return (G)this.G;
    }
    
    _A() {}
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.E.P
 * JD-Core Version:    0.7.0.1
 */
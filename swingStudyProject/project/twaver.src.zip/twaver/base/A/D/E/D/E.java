package twaver.base.A.D.E.D;

public abstract class E
  implements B
{
  private N P = new J();
  private N O = new P();
  private N N = new F();
  boolean M = true;
  
  protected abstract void N(C paramC);
  
  protected abstract boolean M(C paramC);
  
  public void A(boolean paramBoolean)
  {
    this.M = paramBoolean;
  }
  
  private B B()
  {
    Object localObject = new _A();
    if (this.M)
    {
      this.P.A((B)localObject);
      localObject = this.P;
    }
    this.N.A((B)localObject);
    localObject = this.N;
    this.O.A((B)localObject);
    localObject = this.O;
    return (B)localObject;
  }
  
  public void A(C paramC)
  {
    B localB = B();
    localB.A(paramC);
  }
  
  public boolean B(C paramC)
  {
    B localB = B();
    return localB.B(paramC);
  }
  
  class _A
    implements B
  {
    _A() {}
    
    public void A(C paramC)
    {
      E.this.N(paramC);
    }
    
    public boolean B(C paramC)
    {
      return E.this.M(paramC);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.E
 * JD-Core Version:    0.7.0.1
 */
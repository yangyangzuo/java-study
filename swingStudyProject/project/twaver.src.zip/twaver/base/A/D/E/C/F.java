package twaver.base.A.D.E.C;

public class F
{
  private double A;
  private double B;
  
  public F(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.B = paramDouble2;
  }
  
  public F(E paramE1, E paramE2)
  {
    this.A = (paramE1.B() - paramE2.B());
    this.B = (paramE1.A() - paramE2.A());
  }
  
  public double B()
  {
    return this.A;
  }
  
  public double A()
  {
    return this.B;
  }
  
  public static E A(E paramE, F paramF)
  {
    E localE = new E(paramE.B() + paramF.B(), paramE.A() + paramF.A());
    return localE;
  }
  
  public void A(double paramDouble)
  {
    this.A *= paramDouble;
    this.B *= paramDouble;
  }
  
  public double C()
  {
    return Math.sqrt(this.A * this.A + this.B * this.B);
  }
  
  public static F A(F paramF)
  {
    double d = paramF.C();
    F localF = new F(-paramF.A() / d, paramF.B() / d);
    return localF;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.F
 * JD-Core Version:    0.7.0.1
 */
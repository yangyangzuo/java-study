package twaver.base.A.D.E.D;

public class D
  implements M
{
  protected double A;
  protected double D;
  protected double B;
  protected double C;
  
  public void A(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.D = paramDouble2;
  }
  
  public void B(double paramDouble1, double paramDouble2)
  {
    this.B = paramDouble1;
    this.C = paramDouble2;
  }
  
  public double D()
  {
    return this.C;
  }
  
  public double B()
  {
    return this.B;
  }
  
  public double C()
  {
    return this.A;
  }
  
  public double A()
  {
    return this.D;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.D.D
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.E.C;

import java.util.Vector;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.S;

public final class G
{
  S A;
  
  public G()
  {
    this.A = new S();
  }
  
  public G(Vector paramVector)
  {
    if (paramVector == null)
    {
      this.A = new S();
    }
    else
    {
      this.A = new S();
      for (int i = 0; i < paramVector.size(); i++) {
        this.A.add(paramVector.elementAt(i));
      }
    }
  }
  
  public F B()
  {
    return this.A.F();
  }
  
  public B C()
  {
    return new _A(this.A.F());
  }
  
  public G A()
  {
    Vector localVector = new Vector();
    F localF = B();
    while (localF.C())
    {
      localVector.insertElementAt(localF.D(), 0);
      localF.B();
    }
    return new G(localVector);
  }
  
  public int D()
  {
    return this.A.size();
  }
  
  class _A
    implements B
  {
    F H;
    
    public boolean C()
    {
      return this.H.C();
    }
    
    public void B()
    {
      this.H.B();
    }
    
    public void G()
    {
      this.H.G();
    }
    
    public void E()
    {
      this.H.E();
    }
    
    public void A()
    {
      this.H.A();
    }
    
    public Object D()
    {
      return this.H.D();
    }
    
    public int F()
    {
      return this.H.F();
    }
    
    public E J()
    {
      return (E)this.H.D();
    }
    
    _A(F paramF)
    {
      this.H = paramF;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.E.C.G
 * JD-Core Version:    0.7.0.1
 */
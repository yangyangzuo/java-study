package twaver.base.A.D;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.GeneralPath;
import java.awt.geom.RoundRectangle2D.Float;

public class H
{
  public Rectangle A = null;
  public Shape B = null;
  
  public H(Point paramPoint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean)
  {
    this.A = new Rectangle(0, 0, paramInt1, paramInt2);
    paramInt1 += paramInt4 * 2;
    Point localPoint = A(paramPoint, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    if ((paramBoolean) && ((localPoint.x < 0) || ((localPoint.y < 0) && (paramInt3 != 8))))
    {
      paramInt3 = 8;
      localPoint = A(paramPoint, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    int i = localPoint.x;
    int j = localPoint.y;
    this.A.x = (i + paramInt4);
    this.A.y = j;
    RoundRectangle2D.Float localFloat = new RoundRectangle2D.Float(i, j, paramInt1, paramInt2, paramInt4, paramInt4);
    GeneralPath localGeneralPath = A(i, j, paramInt1, paramInt2, paramInt3, paramInt5, paramInt4);
    Area localArea = new Area(localFloat);
    localArea.add(new Area(localGeneralPath));
    this.B = localArea;
  }
  
  public static Point A(Point paramPoint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = 0;
    int j = 0;
    switch (paramInt3)
    {
    case 2: 
      i = paramPoint.x - paramInt4;
      j = paramPoint.y - paramInt2 - paramInt5;
      break;
    case 4: 
      i = paramPoint.x - paramInt4;
      j = paramPoint.y + paramInt5;
      break;
    case 3: 
      i = paramPoint.x - paramInt1 + paramInt4;
      j = paramPoint.y + paramInt5;
      break;
    case 1: 
      i = paramPoint.x - paramInt1 + paramInt4;
      j = paramPoint.y - paramInt2 - paramInt5;
      break;
    case 6: 
      i = paramPoint.x - paramInt5 - paramInt1;
      j = paramPoint.y - Math.min(paramInt4, Math.min(paramInt1, paramInt2) / 4);
      break;
    case 5: 
      i = paramPoint.x - paramInt5 - paramInt1;
      j = paramPoint.y + Math.min(paramInt4, Math.min(paramInt1, paramInt2) / 4) - paramInt2;
      break;
    case 7: 
      i = paramPoint.x + paramInt5;
      j = paramPoint.y + Math.min(paramInt4, Math.min(paramInt1, paramInt2) / 4) - paramInt2;
      break;
    case 8: 
      i = paramPoint.x + paramInt5;
      j = paramPoint.y - Math.min(paramInt4, Math.min(paramInt1, paramInt2) / 4);
      break;
    case 10: 
      i = paramPoint.x - paramInt1 / 2;
      j = paramPoint.y + paramInt5;
      break;
    case 9: 
      i = paramPoint.x - paramInt1 / 2;
      j = paramPoint.y - paramInt5 - paramInt2;
      break;
    case 12: 
      i = paramPoint.x + paramInt5;
      j = paramPoint.y - paramInt2 / 2;
      break;
    case 11: 
      i = paramPoint.x - paramInt5 - paramInt1;
      j = paramPoint.y - paramInt2 / 2;
    }
    return new Point(i, j);
  }
  
  public static GeneralPath A(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    int i = Math.min(paramInt3, paramInt4);
    int j = paramInt6;
    if (j > i / 4)
    {
      j = i / 4;
      if (j < 5) {
        j = 5;
      }
    }
    switch (paramInt5)
    {
    case 2: 
      localGeneralPath.moveTo(paramInt1 + paramInt7, paramInt2 + paramInt4);
      localGeneralPath.lineTo(paramInt1 + paramInt7, paramInt2 + paramInt4 + paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt7 + j, paramInt2 + paramInt4);
      localGeneralPath.closePath();
      break;
    case 4: 
      localGeneralPath.moveTo(paramInt1 + paramInt7, paramInt2);
      localGeneralPath.lineTo(paramInt1 + paramInt7, paramInt2 - paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt7 + j, paramInt2);
      localGeneralPath.closePath();
      break;
    case 3: 
      localGeneralPath.moveTo(paramInt1 + paramInt3 - paramInt7, paramInt2);
      localGeneralPath.lineTo(paramInt1 + paramInt3 - paramInt7, paramInt2 - paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt3 - paramInt7 - j, paramInt2);
      localGeneralPath.closePath();
      break;
    case 1: 
      localGeneralPath.moveTo(paramInt1 + paramInt3 - paramInt7, paramInt2 + paramInt4);
      localGeneralPath.lineTo(paramInt1 + paramInt3 - paramInt7, paramInt2 + paramInt4 + paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt3 - paramInt7 - j, paramInt2 + paramInt4);
      localGeneralPath.closePath();
      break;
    case 6: 
      paramInt7 = Math.min(paramInt7, Math.min(paramInt3, paramInt4) / 4);
      localGeneralPath.moveTo(paramInt1 + paramInt3, paramInt2 + paramInt7);
      localGeneralPath.lineTo(paramInt1 + paramInt3, paramInt2 + paramInt7 + j);
      localGeneralPath.lineTo(paramInt1 + paramInt3 + paramInt6, paramInt2 + paramInt7);
      localGeneralPath.closePath();
      break;
    case 5: 
      paramInt7 = Math.min(paramInt7, Math.min(paramInt3, paramInt4) / 4);
      localGeneralPath.moveTo(paramInt1 + paramInt3, paramInt2 + paramInt4 - paramInt7);
      localGeneralPath.lineTo(paramInt1 + paramInt3, paramInt2 + paramInt4 - paramInt7 - j);
      localGeneralPath.lineTo(paramInt1 + paramInt3 + paramInt6, paramInt2 + paramInt4 - paramInt7);
      localGeneralPath.closePath();
      break;
    case 7: 
      paramInt7 = Math.min(paramInt7, Math.min(paramInt3, paramInt4) / 4);
      localGeneralPath.moveTo(paramInt1, paramInt2 + paramInt4 - paramInt7);
      localGeneralPath.lineTo(paramInt1, paramInt2 + paramInt4 - paramInt7 - j);
      localGeneralPath.lineTo(paramInt1 - paramInt6, paramInt2 + paramInt4 - paramInt7);
      localGeneralPath.closePath();
      break;
    case 8: 
      paramInt7 = Math.min(paramInt7, Math.min(paramInt3, paramInt4) / 4);
      localGeneralPath.moveTo(paramInt1, paramInt2 + paramInt7);
      localGeneralPath.lineTo(paramInt1, paramInt2 + paramInt7 + j);
      localGeneralPath.lineTo(paramInt1 - paramInt6, paramInt2 + paramInt7);
      localGeneralPath.closePath();
      break;
    case 10: 
      localGeneralPath.moveTo(paramInt1 + paramInt3 / 2, paramInt2 - paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt3 / 2 - j / 2, paramInt2);
      localGeneralPath.lineTo(paramInt1 + paramInt3 / 2 + j / 2, paramInt2);
      localGeneralPath.closePath();
      break;
    case 9: 
      localGeneralPath.moveTo(paramInt1 + paramInt3 / 2, paramInt2 + paramInt4 + paramInt6);
      localGeneralPath.lineTo(paramInt1 + paramInt3 / 2 - j / 2, paramInt2 + paramInt4);
      localGeneralPath.lineTo(paramInt1 + paramInt3 / 2 + j / 2, paramInt2 + paramInt4);
      localGeneralPath.closePath();
      break;
    case 11: 
      localGeneralPath.moveTo(paramInt1 + paramInt3 + paramInt6, paramInt2 + paramInt4 / 2);
      localGeneralPath.lineTo(paramInt1 + paramInt3, paramInt2 + paramInt4 / 2 - j / 2);
      localGeneralPath.lineTo(paramInt1 + paramInt3, paramInt2 + paramInt4 / 2 + j / 2);
      localGeneralPath.closePath();
      break;
    case 12: 
      localGeneralPath.moveTo(paramInt1 - paramInt6, paramInt2 + paramInt4 / 2);
      localGeneralPath.lineTo(paramInt1, paramInt2 + paramInt4 / 2 - j / 2);
      localGeneralPath.lineTo(paramInt1, paramInt2 + paramInt4 / 2 + j / 2);
      localGeneralPath.closePath();
    }
    return localGeneralPath;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.H
 * JD-Core Version:    0.7.0.1
 */
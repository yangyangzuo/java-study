package twaver.base.A.D;

import twaver.Chassis;
import twaver.Dummy;
import twaver.Element;
import twaver.Group;
import twaver.Link;
import twaver.Node;
import twaver.TSubNetwork;
import twaver.TWaverUtil;
import twaver.VisibleFilter;
import twaver.base.A.E.V;
import twaver.network.TNetwork;
import twaver.network.ui.LinkUI;

public class B
  implements VisibleFilter
{
  private twaver.base.A.I.B D;
  
  public B(twaver.base.A.I.B paramB)
  {
    this.D = paramB;
  }
  
  public boolean isVisible(Element paramElement)
  {
    boolean bool = V.B(paramElement);
    TSubNetwork localTSubNetwork = this.D.getCurrentSubNetwork();
    Object localObject;
    if (localTSubNetwork == null)
    {
      localObject = TWaverUtil.getElementSubNetwork(paramElement);
      if (localObject != null) {
        return false;
      }
    }
    else
    {
      if (paramElement == localTSubNetwork) {
        return false;
      }
      localObject = TWaverUtil.getElementSubNetwork(paramElement);
      if (localObject != localTSubNetwork) {
        return false;
      }
    }
    if (bool)
    {
      localObject = (Link)paramElement;
      Node localNode1 = ((Link)localObject).getFromAgent();
      Node localNode2 = ((Link)localObject).getToAgent();
      if ((localNode1 == null) || (localNode2 == null)) {
        return false;
      }
      if ((this.D instanceof TNetwork))
      {
        TNetwork localTNetwork = (TNetwork)this.D;
        LinkUI localLinkUI = (LinkUI)localTNetwork.getElementUI(paramElement);
        if (localLinkUI == null) {
          return false;
        }
        if ((localLinkUI.getBundleIndex() > 0) && (localLinkUI.getBundleSize() > 1) && (!localLinkUI.isBundleExpand()) && (!localLinkUI.isBundleAgent())) {
          return false;
        }
      }
      else if ((((Link)localObject).getLinkBundleIndex() > 0) && (((Link)localObject).getLinkBundleSize() > 1) && (!((Link)localObject).isLinkBundleExpand()) && (!((Link)localObject).isBundleAgent()))
      {
        return false;
      }
      if ((!this.D.isEnableIllegalLinkVisible()) && ((!this.D.isVisible(localNode1)) || (!this.D.isVisible(localNode2)))) {
        return false;
      }
    }
    if (!bool) {
      for (localObject = paramElement.getParent(); (localObject != null) && (!(localObject instanceof TSubNetwork)); localObject = ((Element)localObject).getParent()) {
        if (((localObject instanceof Group)) && ((!((Group)localObject).isExpand()) || (!this.D.isVisible((Element)localObject)))) {
          return false;
        }
      }
    }
    if (((paramElement instanceof Dummy)) || ((paramElement instanceof Chassis))) {
      return false;
    }
    return paramElement.isVisible();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.B
 * JD-Core Version:    0.7.0.1
 */
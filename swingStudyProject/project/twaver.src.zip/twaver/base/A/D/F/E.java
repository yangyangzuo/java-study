package twaver.base.A.D.F;

import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Area;

public class E
  implements Stroke
{
  public static final int F = 0;
  public static final int E = 1;
  public static final int G = 2;
  public static final int D = 3;
  private Stroke B;
  private Stroke A;
  private int C;
  
  public E(Stroke paramStroke1, Stroke paramStroke2, int paramInt)
  {
    this.B = paramStroke1;
    this.A = paramStroke2;
    this.C = paramInt;
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    Area localArea1 = new Area(this.B.createStrokedShape(paramShape));
    Area localArea2 = new Area(this.A.createStrokedShape(paramShape));
    switch (this.C)
    {
    case 0: 
      localArea1.add(localArea2);
      break;
    case 1: 
      localArea1.subtract(localArea2);
      break;
    case 2: 
      localArea1.intersect(localArea2);
      break;
    case 3: 
      localArea1.exclusiveOr(localArea2);
    }
    return localArea1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.E
 * JD-Core Version:    0.7.0.1
 */
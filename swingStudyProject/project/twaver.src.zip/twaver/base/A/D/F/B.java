package twaver.base.A.D.F;

import java.awt.Shape;
import java.awt.Stroke;

public class B
  implements Stroke
{
  private Stroke B;
  private Stroke A;
  
  public B(Stroke paramStroke1, Stroke paramStroke2)
  {
    this.B = paramStroke1;
    this.A = paramStroke2;
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    return this.A.createStrokedShape(this.B.createStrokedShape(paramShape));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.B
 * JD-Core Version:    0.7.0.1
 */
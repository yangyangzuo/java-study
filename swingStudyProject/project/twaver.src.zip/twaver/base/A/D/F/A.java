package twaver.base.A.D.F;

import java.awt.BasicStroke;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;

public class A
  implements Stroke
{
  private float C = 2.0F;
  private float B = 2.0F;
  private static final float A = 1.0F;
  
  public A(float paramFloat1, float paramFloat2)
  {
    this.C = paramFloat1;
    this.B = paramFloat2;
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    paramShape = new BasicStroke(10.0F).createStrokedShape(paramShape);
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    float f7 = 0.0F;
    while (!localFlatteningPathIterator.isDone())
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = A(arrayOfFloat[0]);
        f2 = f4 = A(arrayOfFloat[1]);
        localGeneralPath.moveTo(f1, f2);
        f7 = 0.0F;
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = A(arrayOfFloat[0]);
        f6 = A(arrayOfFloat[1]);
        float f8 = f5 - f3;
        float f9 = f6 - f4;
        float f10 = (float)Math.sqrt(f8 * f8 + f9 * f9);
        if (f10 >= f7)
        {
          float f11 = 1.0F / f10;
          while (f10 >= f7)
          {
            float f12 = f3 + f7 * f8 * f11;
            float f13 = f4 + f7 * f9 * f11;
            localGeneralPath.lineTo(A(f12), A(f13));
            f7 += this.C;
          }
        }
        f7 -= f10;
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    return localGeneralPath;
  }
  
  private float A(float paramFloat)
  {
    return paramFloat + (float)Math.random() * this.B * 2.0F - 1.0F;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.F;

import java.awt.Font;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphMetrics;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class C
  implements Stroke
{
  private String F;
  private Font B;
  private boolean A = false;
  private boolean E = false;
  private AffineTransform D = new AffineTransform();
  private static final float C = 1.0F;
  
  public C(String paramString, Font paramFont)
  {
    this(paramString, paramFont, true, false);
  }
  
  public C(String paramString, Font paramFont, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.F = paramString;
    this.B = paramFont;
    this.A = paramBoolean1;
    this.E = paramBoolean2;
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    FontRenderContext localFontRenderContext = new FontRenderContext(null, true, true);
    GlyphVector localGlyphVector = this.B.createGlyphVector(localFontRenderContext, this.F);
    GeneralPath localGeneralPath = new GeneralPath();
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    float f7 = 0.0F;
    int j = 0;
    int k = localGlyphVector.getNumGlyphs();
    if (k == 0) {
      return localGeneralPath;
    }
    float f8 = this.A ? A(paramShape) / (float)localGlyphVector.getLogicalBounds().getWidth() : 1.0F;
    float f9 = 0.0F;
    while ((j < k) && (!localFlatteningPathIterator.isDone()))
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        localGeneralPath.moveTo(f1, f2);
        f9 = localGlyphVector.getGlyphMetrics(j).getAdvance() * 0.5F;
        f7 = f9;
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f10 = f5 - f3;
        float f11 = f6 - f4;
        float f12 = (float)Math.sqrt(f10 * f10 + f11 * f11);
        if (f12 >= f7)
        {
          float f13 = 1.0F / f12;
          float f14 = (float)Math.atan2(f11, f10);
          while ((j < k) && (f12 >= f7))
          {
            Shape localShape = localGlyphVector.getGlyphOutline(j);
            Point2D localPoint2D = localGlyphVector.getGlyphPosition(j);
            float f15 = (float)localPoint2D.getX();
            float f16 = (float)localPoint2D.getY();
            float f17 = f3 + f7 * f10 * f13;
            float f18 = f4 + f7 * f11 * f13;
            float f19 = f9;
            f9 = j < k - 1 ? localGlyphVector.getGlyphMetrics(j + 1).getAdvance() * 0.5F : 0.0F;
            this.D.setToTranslation(f17, f18);
            this.D.rotate(f14);
            this.D.translate(-f15 - f19, -f16);
            localGeneralPath.append(this.D.createTransformedShape(localShape), false);
            f7 += (f19 + f9) * f8;
            j++;
            if (this.E) {
              j %= k;
            }
          }
        }
        f7 -= f12;
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    return localGeneralPath;
  }
  
  public float A(Shape paramShape)
  {
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    float f7 = 0.0F;
    while (!localFlatteningPathIterator.isDone())
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f8 = f5 - f3;
        float f9 = f6 - f4;
        f7 += (float)Math.sqrt(f8 * f8 + f9 * f9);
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    return f7;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.C
 * JD-Core Version:    0.7.0.1
 */
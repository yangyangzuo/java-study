package twaver.base.A.D.F;

import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;

public class D
  implements Stroke
{
  private float C = 10.0F;
  private float B = 10.0F;
  private Stroke D;
  private static final float A = 1.0F;
  
  public D(Stroke paramStroke, float paramFloat1, float paramFloat2)
  {
    this.D = paramStroke;
    this.C = paramFloat1;
    this.B = paramFloat2;
  }
  
  public Stroke C()
  {
    return this.D;
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    float f7 = 0.0F;
    int j = 0;
    while (!localFlatteningPathIterator.isDone())
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        localGeneralPath.moveTo(f1, f2);
        f7 = this.B / 2.0F;
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f8 = f5 - f3;
        float f9 = f6 - f4;
        float f10 = (float)Math.sqrt(f8 * f8 + f9 * f9);
        if (f10 >= f7)
        {
          float f11 = 1.0F / f10;
          while (f10 >= f7)
          {
            float f12 = f3 + f7 * f8 * f11;
            float f13 = f4 + f7 * f9 * f11;
            if ((j & 0x1) == 0) {
              localGeneralPath.lineTo(f12 + this.C * f9 * f11, f13 - this.C * f8 * f11);
            } else {
              localGeneralPath.lineTo(f12 - this.C * f9 * f11, f13 + this.C * f8 * f11);
            }
            f7 += this.B;
            j++;
          }
        }
        f7 -= f10;
        f3 = f5;
        f4 = f6;
        if (i == 4) {
          localGeneralPath.closePath();
        }
        break;
      }
      localFlatteningPathIterator.next();
    }
    return this.D.createStrokedShape(localGeneralPath);
  }
  
  public float A()
  {
    return this.C;
  }
  
  public float B()
  {
    return this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.D
 * JD-Core Version:    0.7.0.1
 */
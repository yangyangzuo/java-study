package twaver.base.A.D.F;

import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;

public class F
  implements Stroke
{
  private Shape[] A;
  private float E;
  private boolean D = true;
  private AffineTransform C = new AffineTransform();
  private static final float B = 1.0F;
  
  public F(Shape paramShape, float paramFloat)
  {
    this(new Shape[] { paramShape }, paramFloat);
  }
  
  public F(Shape[] paramArrayOfShape, float paramFloat)
  {
    this.E = paramFloat;
    this.A = new Shape[paramArrayOfShape.length];
    for (int i = 0; i < this.A.length; i++)
    {
      Rectangle2D localRectangle2D = paramArrayOfShape[i].getBounds2D();
      this.C.setToTranslation(-localRectangle2D.getCenterX(), -localRectangle2D.getCenterY());
      this.A[i] = this.C.createTransformedShape(paramArrayOfShape[i]);
    }
  }
  
  public Shape createStrokedShape(Shape paramShape)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    float f7 = 0.0F;
    int j = 0;
    int k = this.A.length;
    while ((j < k) && (!localFlatteningPathIterator.isDone()))
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        localGeneralPath.moveTo(f1, f2);
        f7 = 0.0F;
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f8 = f5 - f3;
        float f9 = f6 - f4;
        float f10 = (float)Math.sqrt(f8 * f8 + f9 * f9);
        if (f10 >= f7)
        {
          float f11 = 1.0F / f10;
          float f12 = (float)Math.atan2(f9, f8);
          while ((j < k) && (f10 >= f7))
          {
            float f13 = f3 + f7 * f8 * f11;
            float f14 = f4 + f7 * f9 * f11;
            this.C.setToTranslation(f13, f14);
            this.C.rotate(f12);
            localGeneralPath.append(this.C.createTransformedShape(this.A[j]), false);
            f7 += this.E;
            j++;
            if (this.D) {
              j %= k;
            }
          }
        }
        f7 -= f10;
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    return localGeneralPath;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F.F
 * JD-Core Version:    0.7.0.1
 */
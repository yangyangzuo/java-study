package twaver.base.A.D;

import twaver.Element;
import twaver.Equipment;
import twaver.MovableFilter;

public class F
  implements MovableFilter
{
  public static final F A = new F();
  
  public boolean isMovable(Element paramElement)
  {
    return !(paramElement instanceof Equipment);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.A;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public class A
  implements D
{
  private Reference A = null;
  
  public A(D paramD)
  {
    this.A = new WeakReference(paramD);
  }
  
  public boolean A()
  {
    D localD = (D)this.A.get();
    if (localD != null) {
      return localD.A();
    }
    return true;
  }
  
  public boolean B()
  {
    D localD = (D)this.A.get();
    if (localD != null) {
      return localD.B();
    }
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.A.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.D.A;

import twaver.BlinkingRule;
import twaver.Element;
import twaver.network.TNetwork;

public final class C
{
  private TNetwork D = null;
  private Element B = null;
  private boolean A = false;
  private boolean C = false;
  
  public C(TNetwork paramTNetwork, Element paramElement)
  {
    this.D = paramTNetwork;
    this.B = paramElement;
  }
  
  public final boolean C()
  {
    BlinkingRule localBlinkingRule = this.D.getBlinkingRule();
    if ((localBlinkingRule == null) || (!this.D.isEnableBlinking()))
    {
      this.A = false;
      this.C = false;
    }
    else
    {
      this.A = ((localBlinkingRule.isEnableBodyBlinking()) && (localBlinkingRule.isBodyBlinking(this.B)));
      this.C = ((localBlinkingRule.isEnableOutlineBlinking()) && (localBlinkingRule.isOutlineBlinking(this.B)));
    }
    return (this.A) || (this.C);
  }
  
  public final boolean A()
  {
    if (this.A) {
      return B.B();
    }
    return false;
  }
  
  public final boolean B()
  {
    if (this.C) {
      return B.B();
    }
    return false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.A.C
 * JD-Core Version:    0.7.0.1
 */
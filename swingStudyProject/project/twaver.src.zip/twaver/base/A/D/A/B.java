package twaver.base.A.D.A;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import twaver.TaskAdapter;
import twaver.TaskScheduler;

public class B
  extends TaskAdapter
{
  private static final B A = new B();
  private static boolean C = false;
  private List B = new LinkedList();
  
  public static B C()
  {
    TaskScheduler.getInstance();
    return A;
  }
  
  private B()
  {
    setInterval(1000);
  }
  
  public synchronized void A(D paramD)
  {
    this.B.add(new A(paramD));
  }
  
  public void run(long paramLong)
  {
    synchronized (this)
    {
      C = !C;
      Iterator localIterator = this.B.iterator();
      while (localIterator.hasNext())
      {
        D localD = (D)localIterator.next();
        if (localD.A()) {
          localIterator.remove();
        }
      }
    }
  }
  
  public static boolean B()
  {
    return C;
  }
  
  public void A()
  {
    C = false;
    synchronized (this)
    {
      Iterator localIterator = this.B.iterator();
      while (localIterator.hasNext())
      {
        D localD = (D)localIterator.next();
        localD.A();
        if (localD.B()) {
          localIterator.remove();
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.A.B
 * JD-Core Version:    0.7.0.1
 */
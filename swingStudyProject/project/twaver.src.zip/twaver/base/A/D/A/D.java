package twaver.base.A.D.A;

public abstract interface D
{
  public abstract boolean A();
  
  public abstract boolean B();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.A.D
 * JD-Core Version:    0.7.0.1
 */
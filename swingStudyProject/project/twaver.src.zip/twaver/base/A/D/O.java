package twaver.base.A.D;

import java.awt.Color;
import java.awt.Paint;
import java.awt.Rectangle;

public abstract interface O
{
  public abstract Paint A(Rectangle paramRectangle, Color paramColor1, Color paramColor2);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.O
 * JD-Core Version:    0.7.0.1
 */
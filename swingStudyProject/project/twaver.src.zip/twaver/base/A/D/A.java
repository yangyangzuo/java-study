package twaver.base.A.D;

import java.awt.Point;
import twaver.TSubNetwork;

public class A
{
  private TSubNetwork B = null;
  private double C = 1.0D;
  private Point A = new Point(0, 0);
  
  public A(TSubNetwork paramTSubNetwork, double paramDouble, Point paramPoint)
  {
    this.B = paramTSubNetwork;
    this.C = paramDouble;
    this.A = paramPoint;
  }
  
  public TSubNetwork A()
  {
    return this.B;
  }
  
  public Point C()
  {
    return this.A;
  }
  
  public double B()
  {
    return this.C;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject == null) || (!(paramObject instanceof A))) {
      return false;
    }
    A localA = (A)paramObject;
    return (localA.A().equals(this.B)) && (localA.B() == this.C) && (localA.C().equals(this.A));
  }
  
  public String toString()
  {
    String str = "";
    if (this.B != null) {
      if (this.B.getName() != null) {
        str = str + this.B.getName();
      } else {
        str = str + this.B.getID().toString();
      }
    }
    str = str + "|" + this.C;
    if (this.A != null) {
      str = str + "|" + this.A.toString();
    }
    return str;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.A
 * JD-Core Version:    0.7.0.1
 */
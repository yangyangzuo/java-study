package twaver.base.A.D;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import twaver.network.ui.ElementUI;

public abstract interface K
{
  public abstract Shape D(ElementUI paramElementUI, Rectangle paramRectangle);
  
  public abstract Shape C(ElementUI paramElementUI, Rectangle paramRectangle);
  
  public abstract Shape A(ElementUI paramElementUI, Rectangle paramRectangle);
  
  public abstract Point B(ElementUI paramElementUI, Rectangle paramRectangle);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.K
 * JD-Core Version:    0.7.0.1
 */
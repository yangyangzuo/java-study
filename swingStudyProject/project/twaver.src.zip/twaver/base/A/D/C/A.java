package twaver.base.A.D.C;

import java.beans.PropertyChangeEvent;
import twaver.Element;
import twaver.network.NetworkElementRenderer;
import twaver.network.TNetwork;
import twaver.network.layout.LinkLayouter;

public class A
  extends D
{
  public A(NetworkElementRenderer paramNetworkElementRenderer)
  {
    super(paramNetworkElementRenderer);
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    this.M.getLinkLayouter().layout();
    this.M.adjustCanvasSize((Element)paramPropertyChangeEvent.getSource());
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    String str = paramPropertyChangeEvent.getPropertyName();
    return str.equals("location");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.C.A
 * JD-Core Version:    0.7.0.1
 */
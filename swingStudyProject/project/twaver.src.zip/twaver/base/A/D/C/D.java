package twaver.base.A.D.C;

import java.beans.PropertyChangeEvent;
import twaver.base.A.F.E;
import twaver.network.NetworkElementRenderer;
import twaver.network.TNetwork;

public abstract class D
  implements E
{
  protected final NetworkElementRenderer N;
  protected final TNetwork M;
  
  public D(NetworkElementRenderer paramNetworkElementRenderer)
  {
    if (paramNetworkElementRenderer == null) {
      throw new NullPointerException("NetworkElementRenderer can't be null.");
    }
    this.N = paramNetworkElementRenderer;
    this.M = paramNetworkElementRenderer.getNetwork();
  }
  
  public abstract void A(PropertyChangeEvent paramPropertyChangeEvent);
  
  public abstract boolean B(PropertyChangeEvent paramPropertyChangeEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.C.D
 * JD-Core Version:    0.7.0.1
 */
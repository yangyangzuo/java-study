package twaver.base.A.D.C;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import twaver.Dummy;
import twaver.Element;
import twaver.ElementPropertyChangeRepaintFilter;
import twaver.Group;
import twaver.Link;
import twaver.Node;
import twaver.base.A.E.V;
import twaver.base.A.E.a;
import twaver.base.A.E.l;
import twaver.network.ElementBoundsInvalidatableFilter;
import twaver.network.NetworkElementRenderer;
import twaver.network.TNetwork;
import twaver.network.ui.GroupUI;
import twaver.network.ui.LinkUI;

public class C
  extends D
{
  private Map O = null;
  
  public C(NetworkElementRenderer paramNetworkElementRenderer, Map paramMap)
  {
    super(paramNetworkElementRenderer);
    this.O = paramMap;
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    C(paramPropertyChangeEvent);
    D(paramPropertyChangeEvent);
  }
  
  private void C(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    String str = paramPropertyChangeEvent.getPropertyName();
    Object localObject;
    if (((localElement instanceof Link)) && (a.A(str, paramPropertyChangeEvent)))
    {
      localObject = (LinkUI)this.M.getElementUI(localElement);
      if (localObject != null) {
        ((LinkUI)localObject).invalidateShape();
      }
    }
    else if (((localElement instanceof Group)) && (a.B(str)))
    {
      localObject = (GroupUI)this.M.getElementUI(localElement);
      if (localObject != null) {
        ((GroupUI)localObject).invalidateShape();
      }
      if (str.equals("expand"))
      {
        this.M.getCanvas().repaint();
        if (V.C(localElement))
        {
          this.M.adjustCanvasSize(localElement);
          l.B(this.M, localElement);
        }
      }
    }
    else if ((this.M.getCurrentSubNetwork() == localElement) && (str.equals("background")))
    {
      this.M.adjustCanvasSize();
      this.M.getCanvas().repaint();
    }
    else
    {
      localObject = this.M.getElementBoundsInvalidatableFilter();
      if ((localObject == null) || (((ElementBoundsInvalidatableFilter)localObject).isElementBoundsInvalidatable(this.M, localElement, paramPropertyChangeEvent)))
      {
        this.M.invalidateElementBounds(localElement);
      }
      else if (str.equals("location"))
      {
        Point2D localPoint2D1 = (Point2D)paramPropertyChangeEvent.getNewValue();
        Point2D localPoint2D2 = (Point2D)paramPropertyChangeEvent.getOldValue();
        double d1 = localPoint2D1.getX() - localPoint2D2.getX();
        double d2 = localPoint2D1.getY() - localPoint2D2.getY();
        A(localElement, d1, d2);
      }
      else
      {
        this.M.repaint(localElement);
      }
    }
  }
  
  private void D(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    String str = paramPropertyChangeEvent.getPropertyName();
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if (((localElement instanceof Node)) && (((Node)localElement).hasAgentLinks())) {
      if (a.A(str))
      {
        localObject1 = ((Node)localElement).getAllAgentLinks();
        for (int i = 0; i < ((List)localObject1).size(); i++)
        {
          localObject2 = (Link)((List)localObject1).get(i);
          localObject3 = (LinkUI)this.M.getElementUI((Element)localObject2);
          if (localObject3 != null) {
            ((LinkUI)localObject3).invalidateShape();
          }
        }
      }
      else if (("visible".equals(str)) || ("layerID".equals(str)))
      {
        this.M.getCanvas().repaint();
      }
    }
    if ((!(localElement instanceof Link)) && (!(localElement instanceof Dummy)))
    {
      localObject1 = localElement.getParent();
      if (((localObject1 instanceof Group)) && (!((Group)localObject1).isAdjusting()))
      {
        Group localGroup = (Group)localObject1;
        localObject2 = (GroupUI)this.M.getElementUI(localGroup);
        if (localObject2 != null) {
          ((GroupUI)localObject2).invalidateShape();
        }
        if (localGroup.hasAgentLinks())
        {
          localObject3 = localGroup.getAllAgentLinks();
          for (int j = 0; j < ((List)localObject3).size(); j++)
          {
            Link localLink = (Link)((List)localObject3).get(j);
            LinkUI localLinkUI = (LinkUI)this.M.getElementUI(localLink);
            if (localLinkUI != null) {
              localLinkUI.invalidateShape();
            }
          }
        }
      }
    }
  }
  
  private void A(Element paramElement, double paramDouble1, double paramDouble2)
  {
    Rectangle2D localRectangle2D = (Rectangle2D)this.O.get(paramElement);
    if (localRectangle2D != null)
    {
      double d1 = localRectangle2D.getX() + paramDouble1;
      double d2 = localRectangle2D.getY() + paramDouble2;
      double d3 = localRectangle2D.getWidth();
      double d4 = localRectangle2D.getHeight();
      localRectangle2D.setFrame(d1, d2, d3, d4);
    }
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    ElementPropertyChangeRepaintFilter localElementPropertyChangeRepaintFilter = this.M.getElementPropertyChangeRepaintFilter();
    return (localElementPropertyChangeRepaintFilter == null) || (localElementPropertyChangeRepaintFilter.isInterested((Element)paramPropertyChangeEvent.getSource(), paramPropertyChangeEvent));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.C.C
 * JD-Core Version:    0.7.0.1
 */
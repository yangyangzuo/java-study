package twaver.base.A.D.C;

import java.beans.PropertyChangeEvent;
import twaver.Element;
import twaver.network.NetworkElementRenderer;
import twaver.network.ui.ElementUI;

public class B
  extends D
{
  public B(NetworkElementRenderer paramNetworkElementRenderer)
  {
    super(paramNetworkElementRenderer);
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    ElementUI localElementUI = this.N.getElementUI(localElement);
    if (localElementUI == null) {
      return;
    }
    String str1 = paramPropertyChangeEvent.getPropertyName();
    if (str1.startsWith("CP:"))
    {
      String str2 = str1.substring("CP:".length());
      localElementUI.updateClientProperty(str2);
    }
    localElementUI.elementPropertyChange(paramPropertyChangeEvent);
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.C.B
 * JD-Core Version:    0.7.0.1
 */
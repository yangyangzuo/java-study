package twaver.base.A.D;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Float;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Float;
import java.awt.image.BufferedImage;

public class I
{
  public static Shape A(Image paramImage)
  {
    return A(paramImage, 2147483647);
  }
  
  public static Shape A(Image paramImage, int paramInt)
  {
    if (paramImage == null) {
      return null;
    }
    BufferedImage localBufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    localGraphics2D.drawImage(paramImage, 0, 0, null);
    localGraphics2D.dispose();
    return A(localBufferedImage, paramInt);
  }
  
  public static Shape A(BufferedImage paramBufferedImage, int paramInt)
  {
    float f1 = paramBufferedImage.getWidth();
    float f2 = paramBufferedImage.getHeight();
    if ((f1 > paramInt) || (f2 > paramInt))
    {
      BufferedImage localBufferedImage = new BufferedImage(paramInt, paramInt, 2);
      Graphics2D localGraphics2D1 = localBufferedImage.createGraphics();
      AffineTransform localAffineTransform1 = AffineTransform.getScaleInstance(paramInt / f1, paramInt / f2);
      AffineTransform localAffineTransform2 = AffineTransform.getScaleInstance(f1 / paramInt, f2 / paramInt);
      Graphics2D localGraphics2D2 = (Graphics2D)localGraphics2D1;
      localGraphics2D2.drawImage(paramBufferedImage, localAffineTransform1, null);
      localGraphics2D2.dispose();
      return localAffineTransform2.createTransformedShape(B(localBufferedImage));
    }
    return B(paramBufferedImage);
  }
  
  public static Shape B(BufferedImage paramBufferedImage)
  {
    Area localArea = new Area(D(paramBufferedImage));
    localArea.intersect(new Area(E(paramBufferedImage)));
    localArea.intersect(new Area(C(paramBufferedImage)));
    localArea.intersect(new Area(A(paramBufferedImage)));
    return localArea;
  }
  
  private static Point2D A(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, Line2D paramLine2D, GeneralPath paramGeneralPath)
  {
    if (paramPoint2D2 == null)
    {
      paramPoint2D2 = paramPoint2D3;
      paramLine2D.setLine(paramPoint2D1, paramPoint2D2);
    }
    else if (paramLine2D.ptLineDistSq(paramPoint2D3) < 1.0D)
    {
      paramPoint2D2.setLocation(paramPoint2D3);
    }
    else
    {
      paramPoint2D1.setLocation(paramPoint2D2);
      paramPoint2D2.setLocation(paramPoint2D3);
      paramLine2D.setLine(paramPoint2D1, paramPoint2D2);
      paramGeneralPath.lineTo((float)paramPoint2D1.getX(), (float)paramPoint2D1.getY());
    }
    return paramPoint2D2;
  }
  
  private static Shape D(BufferedImage paramBufferedImage)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = new Point2D.Float(paramBufferedImage.getWidth() - 1, 0.0F);
    Point2D localPoint2D = null;
    Line2D.Float localFloat = new Line2D.Float();
    Point2D.Float localFloat2 = new Point2D.Float();
    localGeneralPath.moveTo(paramBufferedImage.getWidth() - 1, 0.0F);
    for (int i = 0; i < paramBufferedImage.getHeight(); i++)
    {
      localFloat2.setLocation(paramBufferedImage.getWidth() - 1, i);
      for (int j = 0; j < paramBufferedImage.getWidth(); j++) {
        if ((paramBufferedImage.getRGB(j, i) & 0xFF000000) != 0)
        {
          localFloat2.setLocation(j, i);
          break;
        }
      }
      localPoint2D = A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    }
    localFloat2.setLocation(paramBufferedImage.getWidth() - 1, paramBufferedImage.getHeight() - 1);
    A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    localGeneralPath.closePath();
    return localGeneralPath;
  }
  
  private static Shape E(BufferedImage paramBufferedImage)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = new Point2D.Float(0.0F, 0.0F);
    Point2D localPoint2D = null;
    Line2D.Float localFloat = new Line2D.Float();
    Point2D.Float localFloat2 = new Point2D.Float();
    localGeneralPath.moveTo(0.0F, 0.0F);
    for (int i = 0; i < paramBufferedImage.getWidth(); i++)
    {
      localFloat2.setLocation(i, 0.0D);
      for (int j = paramBufferedImage.getHeight() - 1; j >= 0; j--) {
        if ((paramBufferedImage.getRGB(i, j) & 0xFF000000) != 0)
        {
          localFloat2.setLocation(i, j);
          break;
        }
      }
      localPoint2D = A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    }
    localFloat2.setLocation(paramBufferedImage.getWidth() - 1, 0.0D);
    A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    localGeneralPath.closePath();
    return localGeneralPath;
  }
  
  private static Shape C(BufferedImage paramBufferedImage)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = new Point2D.Float(0.0F, paramBufferedImage.getHeight() - 1);
    Point2D localPoint2D = null;
    Line2D.Float localFloat = new Line2D.Float();
    Point2D.Float localFloat2 = new Point2D.Float();
    localGeneralPath.moveTo(0.0F, paramBufferedImage.getHeight() - 1);
    for (int i = paramBufferedImage.getHeight() - 1; i >= 0; i--)
    {
      localFloat2.setLocation(0.0D, i);
      for (int j = paramBufferedImage.getWidth() - 1; j >= 0; j--) {
        if ((paramBufferedImage.getRGB(j, i) & 0xFF000000) != 0)
        {
          localFloat2.setLocation(j, i);
          break;
        }
      }
      localPoint2D = A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    }
    localFloat2.setLocation(0.0D, 0.0D);
    A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    localGeneralPath.closePath();
    return localGeneralPath;
  }
  
  private static Shape A(BufferedImage paramBufferedImage)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = new Point2D.Float(paramBufferedImage.getWidth() - 1, paramBufferedImage.getHeight() - 1);
    Point2D localPoint2D = null;
    Line2D.Float localFloat = new Line2D.Float();
    Point2D.Float localFloat2 = new Point2D.Float();
    localGeneralPath.moveTo(paramBufferedImage.getWidth() - 1, paramBufferedImage.getHeight() - 1);
    for (int i = paramBufferedImage.getWidth() - 1; i >= 0; i--)
    {
      localFloat2.setLocation(i, paramBufferedImage.getHeight() - 1);
      for (int j = 0; j < paramBufferedImage.getHeight(); j++) {
        if ((paramBufferedImage.getRGB(i, j) & 0xFF000000) != 0)
        {
          localFloat2.setLocation(i, j);
          break;
        }
      }
      localPoint2D = A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    }
    localFloat2.setLocation(0.0D, paramBufferedImage.getHeight() - 1);
    A(localFloat1, localPoint2D, localFloat2, localFloat, localGeneralPath);
    localGeneralPath.closePath();
    return localGeneralPath;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.I
 * JD-Core Version:    0.7.0.1
 */
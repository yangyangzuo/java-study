package twaver.base.A.D;

import java.util.Vector;

public class G
  extends Vector
{
  private int B = 0;
  private boolean A = false;
  
  public void addElement(Object paramObject)
  {
    super.addElement(paramObject);
    this.B = (size() - 1);
  }
  
  public int B()
  {
    return this.B;
  }
  
  public void C()
  {
    this.B -= 1;
    remove(size() - 1);
  }
  
  public boolean A()
  {
    return this.A;
  }
  
  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.G
 * JD-Core Version:    0.7.0.1
 */
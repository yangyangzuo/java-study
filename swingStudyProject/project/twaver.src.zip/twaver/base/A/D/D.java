package twaver.base.A.D;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;

public class D
  extends Rectangle
{
  private Point B = null;
  private int A = 0;
  private int E = 0;
  private Shape C = null;
  private double D = 0.0D;
  
  public D(Rectangle paramRectangle)
  {
    super(paramRectangle);
  }
  
  public double A()
  {
    return this.D;
  }
  
  public void A(double paramDouble)
  {
    this.D = paramDouble;
  }
  
  public Shape B()
  {
    return this.C;
  }
  
  public void A(Shape paramShape)
  {
    this.C = paramShape;
  }
  
  public Point D()
  {
    return this.B;
  }
  
  public void A(Point paramPoint)
  {
    this.B = paramPoint;
  }
  
  public int C()
  {
    return this.E;
  }
  
  public void A(int paramInt)
  {
    this.E = paramInt;
  }
  
  public int E()
  {
    return this.A;
  }
  
  public void B(int paramInt)
  {
    this.A = paramInt;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.D
 * JD-Core Version:    0.7.0.1
 */
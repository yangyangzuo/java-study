package twaver.base.A.D;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import twaver.TSubNetwork;
import twaver.TWaverUtil;
import twaver.network.TNetwork;

public class J
  implements ActionListener
{
  private TNetwork A = null;
  
  public J(TNetwork paramTNetwork)
  {
    this.A = paramTNetwork;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (!this.A.isEnableDoubleClickToUp()) {
      return;
    }
    TSubNetwork localTSubNetwork1 = this.A.getCurrentSubNetwork();
    TSubNetwork localTSubNetwork2 = TWaverUtil.getElementSubNetwork(localTSubNetwork1);
    if (localTSubNetwork1 != localTSubNetwork2) {
      if (this.A.isAnimateSubnetworkEnter()) {
        this.A.animateCurrentSubNetwork(localTSubNetwork2);
      } else {
        this.A.setCurrentSubNetwork(localTSubNetwork2);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.D.J
 * JD-Core Version:    0.7.0.1
 */
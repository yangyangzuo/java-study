package twaver.base.A.F;

import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import twaver.Element;

public class C
  implements Enumeration
{
  private LinkedList A = null;
  
  public C(Element paramElement)
  {
    this.A = new LinkedList();
    this.A.add(paramElement);
  }
  
  public C(List paramList)
  {
    this.A = new LinkedList(paramList);
  }
  
  public boolean hasMoreElements()
  {
    return this.A.size() > 0;
  }
  
  public Object nextElement()
  {
    Element localElement = (Element)this.A.removeFirst();
    this.A.addAll(localElement.getChildren());
    return localElement;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C
 * JD-Core Version:    0.7.0.1
 */
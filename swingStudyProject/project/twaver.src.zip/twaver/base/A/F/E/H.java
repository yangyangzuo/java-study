package twaver.base.A.F.E;

import twaver.Element;
import twaver.Generator;

public class H
  implements Generator
{
  public Object generate(Object paramObject)
  {
    if (!(paramObject instanceof Element)) {
      return null;
    }
    Element localElement = (Element)paramObject;
    String str = localElement.getDisplayName();
    if (str != null) {
      return str;
    }
    return localElement.getName();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.H
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.E;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.Generator;
import twaver.Link;

public class C
  implements Generator
{
  public Object generate(Object paramObject)
  {
    List localList = (List)paramObject;
    if (localList.size() == 0) {
      return null;
    }
    Object localObject1 = null;
    Object localObject2 = null;
    Comparator localComparator = AlarmSeverity.getSeverityComparator();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Link localLink = (Link)localIterator.next();
      AlarmSeverity localAlarmSeverity = localLink.getAlarmState().getHighestOverallAlarmSeverity();
      if ((localAlarmSeverity != null) && ((localObject1 == null) || (localComparator.compare(localAlarmSeverity, localObject1) > 0)))
      {
        localObject2 = localLink;
        localObject1 = localAlarmSeverity;
      }
    }
    if (localObject2 == null) {
      return localList.get(0);
    }
    return localObject2;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.C
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.E;

import twaver.Element;
import twaver.Generator;
import twaver.base.A.E.a;

public class E
  implements Generator
{
  public static final E A = new E();
  
  public Object generate(Object paramObject)
  {
    return a.C((Element)paramObject, "border.color");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.E
 * JD-Core Version:    0.7.0.1
 */
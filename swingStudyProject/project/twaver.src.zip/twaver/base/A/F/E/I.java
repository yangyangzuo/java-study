package twaver.base.A.F.E;

import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.Element;
import twaver.Generator;
import twaver.network.ui.ElementUI;

public class I
  implements Generator
{
  public static final I C = new I();
  
  public Object generate(Object paramObject)
  {
    Element localElement = null;
    if ((paramObject instanceof ElementUI))
    {
      localObject = (ElementUI)paramObject;
      localElement = ((ElementUI)localObject).getElement();
    }
    else
    {
      localElement = (Element)paramObject;
    }
    Object localObject = localElement.getAlarmState().getHighestNewAlarmSeverity();
    if (localObject != null) {
      return ((AlarmSeverity)localObject).getColor();
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.I
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.E;

import twaver.Element;
import twaver.Generator;

public class F
  implements Generator
{
  public Object generate(Object paramObject)
  {
    if (!(paramObject instanceof Element)) {
      return null;
    }
    Element localElement = (Element)paramObject;
    if (localElement.getName() != null) {
      return localElement.getName();
    }
    String str = localElement.getClass().getName();
    return str.substring(str.lastIndexOf(".") + 1);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.E;

import java.awt.Color;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.Element;
import twaver.Generator;

public class A
  implements Generator
{
  public Object generate(Object paramObject)
  {
    if (!(paramObject instanceof Element)) {
      return null;
    }
    Element localElement = (Element)paramObject;
    AlarmSeverity localAlarmSeverity = localElement.getAlarmState().getHighestNativeAlarmSeverity();
    if (localAlarmSeverity != null) {
      return localAlarmSeverity.getColor();
    }
    Color localColor = (Color)localElement.getClientProperty("render.color");
    if (localColor != null) {
      return localColor;
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E.A
 * JD-Core Version:    0.7.0.1
 */
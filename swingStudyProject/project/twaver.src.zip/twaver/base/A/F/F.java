package twaver.base.A.F;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import twaver.Element;

public class F
  implements Enumeration
{
  private Enumeration B = null;
  private Iterator C = null;
  private Element A = null;
  
  public F(Element paramElement)
  {
    if (paramElement != null)
    {
      ArrayList localArrayList = new ArrayList(1);
      localArrayList.add(paramElement);
      this.C = localArrayList.iterator();
    }
  }
  
  public F(List paramList)
  {
    if ((paramList != null) && (paramList.size() > 0)) {
      this.C = paramList.iterator();
    }
  }
  
  public boolean hasMoreElements()
  {
    return (this.A != null) || ((this.C != null) && (this.C.hasNext())) || ((this.B != null) && (this.B.hasMoreElements()));
  }
  
  public Object nextElement()
  {
    if ((this.B != null) && (this.B.hasMoreElements())) {
      return this.B.nextElement();
    }
    this.B = null;
    Element localElement;
    if (this.A != null)
    {
      localElement = this.A;
      this.A = null;
      return localElement;
    }
    this.A = ((Element)this.C.next());
    if (this.A.childrenSize() == 0)
    {
      localElement = this.A;
      this.A = null;
      return localElement;
    }
    this.B = new F(this.A.getChildren());
    return this.B.nextElement();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.F
 * JD-Core Version:    0.7.0.1
 */
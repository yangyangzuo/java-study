package twaver.base.A.F;

import twaver.Element;
import twaver.VisibleFilter;

public class D
  implements VisibleFilter
{
  public static final D C = new D();
  
  public boolean isVisible(Element paramElement)
  {
    return paramElement.isVisible();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D
 * JD-Core Version:    0.7.0.1
 */
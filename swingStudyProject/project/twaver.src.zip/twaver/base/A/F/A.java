package twaver.base.A.F;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import twaver.AlarmSeverityChangeListener;

public class A
  implements AlarmSeverityChangeListener
{
  private Reference A = null;
  
  public A(AlarmSeverityChangeListener paramAlarmSeverityChangeListener)
  {
    this.A = new WeakReference(paramAlarmSeverityChangeListener);
  }
  
  public boolean alarmSeverityChange()
  {
    AlarmSeverityChangeListener localAlarmSeverityChangeListener = (AlarmSeverityChangeListener)this.A.get();
    if (localAlarmSeverityChangeListener != null) {
      return localAlarmSeverityChangeListener.alarmSeverityChange();
    }
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.A
 * JD-Core Version:    0.7.0.1
 */
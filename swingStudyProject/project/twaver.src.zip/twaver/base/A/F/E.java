package twaver.base.A.F;

import java.beans.PropertyChangeEvent;

public abstract interface E
{
  public abstract boolean B(PropertyChangeEvent paramPropertyChangeEvent);
  
  public abstract void A(PropertyChangeEvent paramPropertyChangeEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.E
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F;

import java.awt.BasicStroke;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D.Double;
import java.awt.geom.Rectangle2D.Float;
import java.beans.PersistenceDelegate;
import java.beans.XMLEncoder;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import twaver.Layer;
import twaver.PersistenceManager;
import twaver.base.A.F.D.C;
import twaver.base.A.F.D.D;
import twaver.base.A.F.D.F;
import twaver.base.A.F.D.H;
import twaver.base.A.F.D.K;
import twaver.base.SerializablePoint2D;

public class G
{
  private static G B = null;
  private Map A = new HashMap();
  
  public static G A()
  {
    if (B == null)
    {
      B = new G();
      B.A(Timestamp.class, new K());
      B.A(BasicStroke.class, new F());
      B.A(Rectangle2D.Double.class, new D());
      B.A(Rectangle2D.Float.class, new D());
      B.A(Layer.class, new C());
      B.A(Point2D.Double.class, new H());
      B.A(SerializablePoint2D.class, new twaver.base.A.F.D.G());
    }
    return B;
  }
  
  public void A(Class paramClass, PersistenceDelegate paramPersistenceDelegate)
  {
    if (paramClass == null) {
      return;
    }
    this.A.put(paramClass, paramPersistenceDelegate);
  }
  
  public void A(Class paramClass)
  {
    if (paramClass == null) {
      return;
    }
    this.A.put(paramClass, PersistenceManager.DEFAULT_DElEGATE);
  }
  
  public void A(XMLEncoder paramXMLEncoder)
  {
    Iterator localIterator = this.A.keySet().iterator();
    while (localIterator.hasNext())
    {
      Class localClass = (Class)localIterator.next();
      PersistenceDelegate localPersistenceDelegate = (PersistenceDelegate)this.A.get(localClass);
      if (localPersistenceDelegate != null) {
        paramXMLEncoder.setPersistenceDelegate(localClass, localPersistenceDelegate);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.G
 * JD-Core Version:    0.7.0.1
 */
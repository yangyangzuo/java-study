package twaver.base.A.F.A;

import java.util.Comparator;
import twaver.Element;
import twaver.Generator;
import twaver.base.A.J.G;
import twaver.tree.TTree;

public class B
  implements Comparator
{
  private G A;
  
  public B(G paramG)
  {
    this.A = paramG;
  }
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    Element localElement1 = (Element)paramObject1;
    Element localElement2 = (Element)paramObject2;
    Generator localGenerator = this.A.E().getElementLabelGenerator();
    if (localGenerator == null) {
      return -1;
    }
    Object localObject1 = localGenerator.generate(localElement1);
    Object localObject2 = localGenerator.generate(localElement2);
    return A.A().compare(localObject1, localObject2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.A.B
 * JD-Core Version:    0.7.0.1
 */
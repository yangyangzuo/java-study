package twaver.base.A.F.A;

import java.util.Comparator;
import twaver.ElementAttribute;
import twaver.TPropertyDescriptor;
import twaver.TWaverUtil;

public class C
  implements Comparator
{
  public static final C A = new C();
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    TPropertyDescriptor localTPropertyDescriptor1 = (TPropertyDescriptor)paramObject1;
    TPropertyDescriptor localTPropertyDescriptor2 = (TPropertyDescriptor)paramObject2;
    String str1 = localTPropertyDescriptor1.getDisplayName();
    String str2 = localTPropertyDescriptor2.getDisplayName();
    int i = TWaverUtil.compare(str1, str2);
    if (i == 0)
    {
      str1 = str1 + localTPropertyDescriptor1.getElementAttribute().getKey();
      str2 = str2 + localTPropertyDescriptor2.getElementAttribute().getKey();
      i = TWaverUtil.compare(str1, str2);
    }
    return i;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.A.C
 * JD-Core Version:    0.7.0.1
 */
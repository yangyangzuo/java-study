package twaver.base.A.F.A;

import java.util.Comparator;
import twaver.TWaverUtil;

public class A
  implements Comparator
{
  private static final A B = new A();
  private String A = "NULL";
  
  public static final Comparator A()
  {
    return B;
  }
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == paramObject2) {
      return 0;
    }
    if ((paramObject1 == null) && (paramObject2 != null)) {
      return -1;
    }
    if ((paramObject1 != null) && (paramObject2 == null)) {
      return 1;
    }
    if (((paramObject1 instanceof String)) && ((paramObject2 instanceof String))) {
      TWaverUtil.compare((String)paramObject1, (String)paramObject2);
    }
    if (((paramObject1 instanceof Comparable)) && ((paramObject2 instanceof Comparable))) {
      return ((Comparable)paramObject1).compareTo(paramObject2);
    }
    if (((paramObject1 instanceof Boolean)) && ((paramObject2 instanceof Boolean)))
    {
      if (paramObject1.equals(paramObject2)) {
        return 0;
      }
      if (paramObject1.equals(Boolean.TRUE)) {
        return 1;
      }
      return -1;
    }
    String str1 = paramObject1.toString();
    String str2 = paramObject2.toString();
    if (str1 == null) {
      str1 = this.A;
    }
    if (str2 == null) {
      str2 = this.A;
    }
    return TWaverUtil.compare(str1, str2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.A.A
 * JD-Core Version:    0.7.0.1
 */
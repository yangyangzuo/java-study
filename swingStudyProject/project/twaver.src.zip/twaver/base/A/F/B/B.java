package twaver.base.A.F.B;

import java.beans.IntrospectionException;
import twaver.ElementAttribute;

public class B
  extends C
{
  public B(ElementAttribute paramElementAttribute, String paramString1, Class paramClass, String paramString2, String paramString3)
    throws IntrospectionException
  {
    super(paramElementAttribute, paramString1, paramClass, paramString2, paramString3);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.B;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import twaver.ElementAttribute;
import twaver.TPropertyDescriptor;
import twaver.base.A.E.L;

public abstract class C
  extends PropertyDescriptor
  implements TPropertyDescriptor
{
  protected ElementAttribute A = null;
  
  C(ElementAttribute paramElementAttribute, String paramString1, Class paramClass, String paramString2, String paramString3)
    throws IntrospectionException
  {
    super(paramString1, paramClass, paramString2, paramString3);
    this.A = paramElementAttribute;
    setDisplayName(L.A(paramElementAttribute, paramClass));
  }
  
  public ElementAttribute getElementAttribute()
  {
    return this.A;
  }
  
  public void setElementAttribute(ElementAttribute paramElementAttribute)
  {
    this.A = paramElementAttribute;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof TPropertyDescriptor))
    {
      TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)paramObject;
      localTPropertyDescriptor.getElementAttribute().getKey().equals(this.A.getKey());
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.A.getKey().hashCode();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.C
 * JD-Core Version:    0.7.0.1
 */
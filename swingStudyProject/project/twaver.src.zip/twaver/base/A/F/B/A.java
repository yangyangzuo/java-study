package twaver.base.A.F.B;

import java.beans.IntrospectionException;
import java.lang.reflect.Method;
import twaver.ElementAttribute;
import twaver.TWaverConst;

public class A
  extends C
{
  private Method D;
  private Method E;
  
  public A(ElementAttribute paramElementAttribute, Class paramClass)
    throws IntrospectionException, NoSuchMethodException
  {
    super(paramElementAttribute, "name", paramClass, null, null);
    setName(paramElementAttribute.getClientPropertyKey());
    setReadMethod(paramClass.getMethod("getClientProperty", TWaverConst.CLIENT_PROPERTY_GETTER_METHOD_PARAM));
    setWriteMethod(paramClass.getMethod("putClientProperty", TWaverConst.CLIENT_PROPERTY_SETTER_METHOD_PARAM));
  }
  
  public void setReadMethod(Method paramMethod)
    throws IntrospectionException
  {
    this.D = paramMethod;
  }
  
  public void setWriteMethod(Method paramMethod)
    throws IntrospectionException
  {
    this.E = paramMethod;
  }
  
  public Method getReadMethod()
  {
    return this.D;
  }
  
  public Method getWriteMethod()
  {
    return this.E;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.B;

import java.beans.IntrospectionException;
import java.lang.reflect.Method;
import twaver.ElementAttribute;
import twaver.TWaverConst;

public class D
  extends C
{
  private Method B;
  private Method C;
  
  public D(ElementAttribute paramElementAttribute, Class paramClass)
    throws IntrospectionException, NoSuchMethodException
  {
    super(paramElementAttribute, "name", paramClass, null, null);
    setName(paramElementAttribute.getClientPropertyKey());
    setReadMethod(paramClass.getMethod("getUserProperty", TWaverConst.CLIENT_PROPERTY_GETTER_METHOD_PARAM));
    setWriteMethod(paramClass.getMethod("putUserProperty", TWaverConst.CLIENT_PROPERTY_SETTER_METHOD_PARAM));
  }
  
  public void setReadMethod(Method paramMethod)
    throws IntrospectionException
  {
    this.B = paramMethod;
  }
  
  public void setWriteMethod(Method paramMethod)
    throws IntrospectionException
  {
    this.C = paramMethod;
  }
  
  public Method getReadMethod()
  {
    return this.B;
  }
  
  public Method getWriteMethod()
  {
    return this.C;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.D
 * JD-Core Version:    0.7.0.1
 */
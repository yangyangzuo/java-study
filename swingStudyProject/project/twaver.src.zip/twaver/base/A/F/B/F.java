package twaver.base.A.F.B;

import java.beans.BeanInfo;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import twaver.ElementAttribute;
import twaver.TWaverUtil;
import twaver.base.A.E.C;
import twaver.base.A.E.H;
import twaver.base.A.E.L;

public class F
{
  private static final F A = new F();
  private Set C = new HashSet();
  private Map E = new HashMap();
  private Map D = new HashMap();
  private Map B = new HashMap();
  
  public static F A()
  {
    return A;
  }
  
  public void A(Class paramClass)
  {
    this.C.add(paramClass);
  }
  
  public void A(Class paramClass, BeanInfo paramBeanInfo)
  {
    this.D.put(paramClass, paramBeanInfo);
    this.B.put(paramClass, paramBeanInfo);
  }
  
  public void A(Class paramClass, List paramList)
  {
    A(paramClass, H.A(paramClass, paramList));
  }
  
  public void A(Class paramClass, String paramString)
  {
    this.E.put(paramClass, paramString);
  }
  
  public List E(Class paramClass)
  {
    boolean bool = C(paramClass);
    Map localMap = null;
    if (bool) {
      localMap = this.D;
    } else {
      localMap = this.B;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = D(paramClass).iterator();
    while (localIterator.hasNext())
    {
      BeanInfo localBeanInfo = null;
      Class localClass = (Class)localIterator.next();
      if (localMap.containsKey(localClass))
      {
        localBeanInfo = (BeanInfo)localMap.get(localClass);
      }
      else
      {
        String str;
        if (this.E.containsKey(localClass))
        {
          str = (String)this.E.get(localClass);
          localBeanInfo = A(localClass, str, false);
          this.D.put(localClass, localBeanInfo);
          this.B.put(localClass, localBeanInfo);
        }
        else
        {
          str = TWaverUtil.getClassNameWithoutPackage(localClass) + ".xml";
          localBeanInfo = A(localClass, str, bool);
          localMap.put(localClass, localBeanInfo);
        }
      }
      if (localBeanInfo != null) {
        localArrayList.add(0, localBeanInfo);
      }
    }
    return localArrayList;
  }
  
  private boolean C(Class paramClass)
  {
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      Class localClass = (Class)localIterator.next();
      if (localClass.isAssignableFrom(paramClass)) {
        return false;
      }
    }
    return true;
  }
  
  private Set D(Class paramClass)
  {
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    localLinkedHashSet.add(paramClass);
    localLinkedHashSet.addAll(B(paramClass));
    return localLinkedHashSet;
  }
  
  private Set B(Class paramClass)
  {
    LinkedHashSet localLinkedHashSet1 = new LinkedHashSet();
    if (paramClass.getSuperclass() != null) {
      localLinkedHashSet1.add(paramClass.getSuperclass());
    }
    if (paramClass.getInterfaces() != null) {
      localLinkedHashSet1.addAll(Arrays.asList(paramClass.getInterfaces()));
    }
    Iterator localIterator = localLinkedHashSet1.iterator();
    LinkedHashSet localLinkedHashSet2 = new LinkedHashSet();
    while (localIterator.hasNext())
    {
      Class localClass = (Class)localIterator.next();
      if (twaver.Element.class.isAssignableFrom(localClass)) {
        localLinkedHashSet2.addAll(B(localClass));
      } else {
        localIterator.remove();
      }
    }
    localLinkedHashSet1.addAll(localLinkedHashSet2);
    return localLinkedHashSet1;
  }
  
  /* Error */
  public BeanInfo A(Class paramClass, String paramString, boolean paramBoolean)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_2
    //   4: iload_3
    //   5: invokestatic 211	twaver/base/A/F/B/F:A	(Ljava/lang/String;Z)Ljava/io/InputStream;
    //   8: astore 4
    //   10: aload 4
    //   12: ifnull +90 -> 102
    //   15: aload_0
    //   16: aload_1
    //   17: aload 4
    //   19: invokevirtual 215	twaver/base/A/F/B/F:A	(Ljava/lang/Class;Ljava/io/InputStream;)Ljava/util/List;
    //   22: astore 5
    //   24: aload_1
    //   25: aload 5
    //   27: invokestatic 65	twaver/base/A/E/H:A	(Ljava/lang/Class;Ljava/util/List;)Ljava/beans/BeanInfo;
    //   30: astore 8
    //   32: jsr +45 -> 77
    //   35: aload 8
    //   37: areturn
    //   38: astore 5
    //   40: new 118	java/lang/StringBuffer
    //   43: dup
    //   44: ldc 219
    //   46: invokespecial 130	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   49: aload_2
    //   50: invokevirtual 135	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   53: ldc 221
    //   55: invokevirtual 135	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   58: invokevirtual 139	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   61: aload 5
    //   63: invokestatic 223	twaver/TWaverUtil:handleError	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   66: goto +36 -> 102
    //   69: astore 7
    //   71: jsr +6 -> 77
    //   74: aload 7
    //   76: athrow
    //   77: astore 6
    //   79: aload 4
    //   81: ifnull +19 -> 100
    //   84: aload 4
    //   86: invokevirtual 227	java/io/InputStream:close	()V
    //   89: goto +11 -> 100
    //   92: astore 9
    //   94: aconst_null
    //   95: aload 9
    //   97: invokestatic 223	twaver/TWaverUtil:handleError	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   100: ret 6
    //   102: jsr -25 -> 77
    //   105: aconst_null
    //   106: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	107	0	this	F
    //   0	107	1	paramClass	Class
    //   0	107	2	paramString	String
    //   0	107	3	paramBoolean	boolean
    //   1	84	4	localInputStream	InputStream
    //   22	4	5	localList	List
    //   38	24	5	localException1	Exception
    //   77	1	6	localObject1	Object
    //   69	6	7	localObject2	Object
    //   30	6	8	localBeanInfo	BeanInfo
    //   92	4	9	localException2	Exception
    // Exception table:
    //   from	to	target	type
    //   3	35	38	java/lang/Exception
    //   3	35	69	finally
    //   38	66	69	finally
    //   102	105	69	finally
    //   84	89	92	java/lang/Exception
  }
  
  private boolean A(org.w3c.dom.Element paramElement, String paramString)
  {
    String str = paramElement.getAttribute(paramString);
    return (str != null) && (!str.equals(""));
  }
  
  public List A(Class paramClass, InputStream paramInputStream)
    throws Exception
  {
    DocumentBuilder localDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    Document localDocument = localDocumentBuilder.parse(paramInputStream);
    NodeList localNodeList = localDocument.getElementsByTagName("attribute");
    ArrayList localArrayList = new ArrayList(localNodeList.getLength());
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      org.w3c.dom.Element localElement = (org.w3c.dom.Element)localNodeList.item(i);
      localArrayList.add(A(localElement));
    }
    return localArrayList;
  }
  
  private ElementAttribute A(org.w3c.dom.Element paramElement)
    throws Exception
  {
    ElementAttribute localElementAttribute = new ElementAttribute();
    org.w3c.dom.Element localElement1 = (org.w3c.dom.Element)paramElement.getParentNode();
    Object localObject;
    if ((localElement1 != null) && (localElement1.getTagName().equals("category")))
    {
      localObject = new ArrayList();
      while ((localElement1 != null) && (localElement1.getTagName().equals("category")))
      {
        ((List)localObject).add(0, localElement1.getAttribute("name"));
        localElement1 = (org.w3c.dom.Element)localElement1.getParentNode();
      }
      localElementAttribute.setCategoryNames((List)localObject);
    }
    else if (A(paramElement, "categoryName"))
    {
      localElementAttribute.setCategoryName(paramElement.getAttribute("categoryName"));
    }
    if (A(paramElement, "userPropertyKey"))
    {
      localElementAttribute.setUserPropertyKey(paramElement.getAttribute("userPropertyKey"));
    }
    else
    {
      if (A(paramElement, "businessProperty")) {
        localElementAttribute.setBusinessProperty(Boolean.valueOf(paramElement.getAttribute("businessProperty")).booleanValue());
      }
      if (A(paramElement, "clientPropertyKey")) {
        localElementAttribute.setClientPropertyKey(paramElement.getAttribute("clientPropertyKey"));
      } else {
        localElementAttribute.setName(paramElement.getAttribute("name"));
      }
      if (A(paramElement, "readMethod")) {
        localElementAttribute.setReadMethod(paramElement.getAttribute("readMethod"));
      }
      if (A(paramElement, "writeMethod")) {
        localElementAttribute.setWriteMethod(paramElement.getAttribute("writeMethod"));
      }
    }
    if (A(paramElement, "javaClass")) {
      localElementAttribute.setJavaClass(H.A(paramElement.getAttribute("javaClass")));
    }
    if (A(paramElement, "renderer")) {
      localElementAttribute.setRendererClass(paramElement.getAttribute("renderer"));
    }
    if (A(paramElement, "editor")) {
      localElementAttribute.setEditorClass(paramElement.getAttribute("editor"));
    }
    if (A(paramElement, "write")) {
      localElementAttribute.setEditable(Boolean.valueOf(paramElement.getAttribute("write")).booleanValue());
    }
    if (A(paramElement, "editable")) {
      localElementAttribute.setEditable(Boolean.valueOf(paramElement.getAttribute("editable")).booleanValue());
    }
    if (A(paramElement, "sortable")) {
      localElementAttribute.setSortable(Boolean.valueOf(paramElement.getAttribute("sortable")).booleanValue());
    }
    if (A(paramElement, "visible")) {
      localElementAttribute.setVisible(Boolean.valueOf(paramElement.getAttribute("visible")).booleanValue());
    }
    if (A(paramElement, "enableBatch")) {
      localElementAttribute.setEnableBatch(Boolean.valueOf(paramElement.getAttribute("enableBatch")).booleanValue());
    }
    if (A(paramElement, "width")) {
      localElementAttribute.setWidth(Integer.parseInt(paramElement.getAttribute("width")));
    }
    if (A(paramElement, "minWidth")) {
      localElementAttribute.setMinWidth(Integer.parseInt(paramElement.getAttribute("minWidth")));
    }
    if (A(paramElement, "maxWidth")) {
      localElementAttribute.setMaxWidth(Integer.parseInt(paramElement.getAttribute("maxWidth")));
    }
    if (A(paramElement, "icon")) {
      localElementAttribute.setIcon(C.E(paramElement.getAttribute("icon")));
    }
    if (A(paramElement, "foreColor")) {
      localElementAttribute.setForeColor(TWaverUtil.stringToColor(paramElement.getAttribute("foreColor")));
    }
    if (A(paramElement, "fillColor")) {
      localElementAttribute.setFillColor(TWaverUtil.stringToColor(paramElement.getAttribute("fillColor")));
    }
    if (A(paramElement, "fontStyle"))
    {
      localObject = paramElement.getAttribute("fontStyle").toLowerCase();
      if ("bold".equals(localObject)) {
        localElementAttribute.setFontStyle(3);
      } else if ("default".equals(localObject)) {
        localElementAttribute.setFontStyle(1);
      } else if ("italic".equals(localObject)) {
        localElementAttribute.setFontStyle(4);
      } else if ("italicbold".equals(localObject)) {
        localElementAttribute.setFontStyle(5);
      } else if ("plain".equals(localObject)) {
        localElementAttribute.setFontStyle(2);
      }
    }
    if (A(paramElement, "tooltipText")) {
      localElementAttribute.setDescription(paramElement.getAttribute("tooltipText"));
    }
    if (A(paramElement, "description"))
    {
      localObject = paramElement.getAttribute("description");
      if (localObject != null) {
        localObject = L.A((String)localObject, "\\n", "\n");
      }
      localElementAttribute.setDescription((String)localObject);
    }
    if (A(paramElement, "sortComparator")) {
      try
      {
        localObject = (Comparator)H.A(paramElement.getAttribute("sortComparator")).newInstance();
        localElementAttribute.setSortComparator((Comparator)localObject);
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError(null, localException);
      }
    }
    if (A(paramElement, "displayName")) {
      localElementAttribute.setDisplayName(paramElement.getAttribute("displayName"));
    }
    if (A(paramElement, "rowPackParticipable")) {
      localElementAttribute.setRowPackParticipable(TWaverUtil.stringToBoolean(paramElement.getAttribute("rowPackParticipable")).booleanValue());
    }
    if (A(paramElement, "extraWidthAssignable")) {
      localElementAttribute.setExtraWidthAssignable(TWaverUtil.stringToBoolean(paramElement.getAttribute("extraWidthAssignable")).booleanValue());
    }
    if (A(paramElement, "minPackWidth")) {
      localElementAttribute.setMinPackWidth(Integer.parseInt(paramElement.getAttribute("minPackWidth")));
    }
    if (A(paramElement, "maxPackWidth")) {
      localElementAttribute.setMaxPackWidth(Integer.parseInt(paramElement.getAttribute("maxPackWidth")));
    }
    if (A(paramElement, "minPackHeight")) {
      localElementAttribute.setMinPackHeight(Integer.parseInt(paramElement.getAttribute("minPackHeight")));
    }
    if (A(paramElement, "maxPackHeight")) {
      localElementAttribute.setMaxPackHeight(Integer.parseInt(paramElement.getAttribute("maxPackHeight")));
    }
    NodeList localNodeList1 = paramElement.getElementsByTagName("displayName");
    if (localNodeList1.getLength() > 0) {
      localElementAttribute.setDisplayName(localNodeList1.item(0).getFirstChild().getNodeValue());
    }
    NodeList localNodeList2 = paramElement.getElementsByTagName("param");
    for (int i = 0; i < localNodeList2.getLength(); i++)
    {
      org.w3c.dom.Element localElement2 = (org.w3c.dom.Element)localNodeList2.item(i);
      localElementAttribute.addParam(localElement2.getAttribute("key"), localElement2.getAttribute("value"));
    }
    return localElementAttribute;
  }
  
  private static InputStream A(String paramString, boolean paramBoolean)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return null;
    }
    InputStream localInputStream = null;
    if ((paramString.startsWith("/")) || (paramString.indexOf(":") > 0))
    {
      localInputStream = C.B(paramString, true);
    }
    else
    {
      localInputStream = C.A(TWaverUtil.getResourceAgentURL() + "bean/" + paramString, TWaverUtil.class, true);
      if ((localInputStream == null) && (paramBoolean)) {
        localInputStream = C.A("/resource/bean/" + paramString, TWaverUtil.class, true);
      }
    }
    return localInputStream;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.B;

import twaver.Element;
import twaver.ElementAttribute;

public class E
  extends C
{
  public E(ElementAttribute paramElementAttribute)
    throws Exception
  {
    super(paramElementAttribute, "name", Element.class, null, null);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B.E
 * JD-Core Version:    0.7.0.1
 */
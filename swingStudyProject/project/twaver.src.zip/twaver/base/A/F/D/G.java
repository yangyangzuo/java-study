package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;

public class G
  extends DefaultPersistenceDelegate
{
  public G()
  {
    super(new String[] { "x", "y" });
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.G
 * JD-Core Version:    0.7.0.1
 */
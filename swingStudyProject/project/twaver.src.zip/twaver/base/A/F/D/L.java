package twaver.base.A.F.D;

import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.BTS;
import twaver.Branch;
import twaver.ClientPropertyPersistentFilter;
import twaver.DataBoxOutputSetting;
import twaver.Element;
import twaver.ElementDelegateInterceptor;
import twaver.PersistenceManager;
import twaver.PolyLine;
import twaver.PolySubNetwork;
import twaver.Segment;
import twaver.ShapeNode;
import twaver.TWaverUtil;

public class L
  extends DefaultPersistenceDelegate
{
  private DataBoxOutputSetting A;
  
  public L(DataBoxOutputSetting paramDataBoxOutputSetting)
  {
    this.A = paramDataBoxOutputSetting;
  }
  
  protected void initialize(Class paramClass, Object paramObject1, Object paramObject2, Encoder paramEncoder)
  {
    Element localElement1 = (Element)paramObject1;
    Element localElement2 = (Element)paramObject2;
    if (!this.A.isWithBusinessObject()) {
      localElement2.setBusinessObject(localElement1.getBusinessObject());
    }
    if (this.A.getElementDelegateInterceptor() != null) {
      this.A.getElementDelegateInterceptor().beforeInitialize(paramEncoder, localElement1, localElement2);
    }
    super.initialize(paramClass, localElement1, paramObject2, paramEncoder);
    String str1 = localElement1.getIconURL();
    String str2 = localElement2.getIconURL();
    int i = 0;
    if (str2 != null) {
      i = str2.equals(str1) ? 0 : 1;
    } else if (str1 != null) {
      i = str1.equals(str2) ? 0 : 1;
    }
    if (i != 0) {
      paramEncoder.writeStatement(new Statement(localElement1, "setIcon", new Object[] { str1 }));
    }
    str1 = localElement1.getImageURL();
    str2 = localElement2.getImageURL();
    if (str2 != null) {
      i = str2.equals(str1) ? 0 : 1;
    } else if (str1 != null) {
      i = str1.equals(str2) ? 0 : 1;
    }
    if (i != 0) {
      paramEncoder.writeStatement(new Statement(localElement1, "setImage", new Object[] { str1 }));
    }
    ClientPropertyPersistentFilter localClientPropertyPersistentFilter = this.A.getClientPropertyFilter();
    if (localClientPropertyPersistentFilter == null) {
      localClientPropertyPersistentFilter = PersistenceManager.getClientPropertyFilter();
    }
    Iterator localIterator = localElement1.getClientProperties().keySet().iterator();
    Object localObject2;
    Object localObject4;
    while (localIterator.hasNext())
    {
      localObject1 = localIterator.next();
      localObject2 = localElement1.getClientProperty(localObject1);
      if (localObject2 != null)
      {
        localObject4 = localElement2.getClientProperty(localObject1.toString());
        if (localObject2.equals(localObject4)) {}
      }
      else if ((localClientPropertyPersistentFilter == null) || (!localClientPropertyPersistentFilter.isTransient(localElement1, localObject1)))
      {
        paramEncoder.writeStatement(new Statement(localElement1, "putClientProperty", new Object[] { localObject1, localObject2 }));
      }
    }
    if (this.A.isWithUserProperty())
    {
      localIterator = localElement1.getUserProperties().keySet().iterator();
      while (localIterator.hasNext())
      {
        localObject1 = localIterator.next();
        localObject2 = localElement1.getUserProperty(localObject1);
        if (localObject2 != null)
        {
          localObject4 = localElement2.getUserProperty(localObject1.toString());
          if (localObject2.equals(localObject4)) {}
        }
        else
        {
          paramEncoder.writeStatement(new Statement(localElement1, "putUserProperty", new Object[] { localObject1, localObject2 }));
        }
      }
    }
    Object localObject1 = localElement1.getAlarmState();
    if (this.A.isWithAlarmState())
    {
      localIterator = AlarmSeverity.iterator();
      while (localIterator.hasNext())
      {
        localObject4 = (AlarmSeverity)localIterator.next();
        int j = ((AlarmState)localObject1).getNewAlarmCount((AlarmSeverity)localObject4);
        if (j > 0) {
          paramEncoder.writeStatement(new Statement(localObject1, "setNewAlarmCount", new Object[] { localObject4, TWaverUtil.valueOf(j) }));
        }
        j = ((AlarmState)localObject1).getAcknowledgedAlarmCount((AlarmSeverity)localObject4);
        if (j > 0) {
          paramEncoder.writeStatement(new Statement(localObject1, "setAcknowledgedAlarmCount", new Object[] { localObject4, TWaverUtil.valueOf(j) }));
        }
      }
    }
    Object localObject3;
    Object localObject6;
    Object localObject5;
    if ((localElement1 instanceof PolyLine))
    {
      localObject3 = (PolyLine)localElement1;
      localObject4 = ((PolyLine)localObject3).getBranchs();
      if (((List)localObject4).size() > 0)
      {
        for (int k = 0; k < ((List)localObject4).size(); k++)
        {
          localObject6 = (Branch)((List)localObject4).get(k);
          for (int m = 0; m < ((Branch)localObject6).getSegments().size(); m++)
          {
            Segment localSegment = (Segment)((Branch)localObject6).getSegments().get(m);
            paramEncoder.writeStatement(new Statement(localObject6, "addSegment", new Object[] { localSegment }));
          }
        }
        paramEncoder.writeStatement(new Statement(localObject3, "setBranchs", new Object[] { localObject4 }));
      }
      else
      {
        localObject5 = ((PolyLine)localObject3).getSegments();
        paramEncoder.writeStatement(new Statement(localObject3, "setSegments", new Object[] { localObject5 }));
      }
    }
    if ((localElement1 instanceof ShapeNode))
    {
      localObject3 = (ShapeNode)localElement1;
      localObject4 = ((ShapeNode)localObject3).getPoints();
      paramEncoder.writeStatement(new Statement(localObject3, "setPoints", new Object[] { localObject4 }));
    }
    if ((localElement1 instanceof BTS))
    {
      localObject3 = (BTS)localElement1;
      localObject4 = ((BTS)localObject3).getAntennas();
      paramEncoder.writeStatement(new Statement(localObject3, "setAntennas", new Object[] { localObject4 }));
      paramEncoder.writeStatement(new Statement(localObject3, "setLocation", new Object[] { ((BTS)localObject3).getLocation() }));
    }
    if ((localElement1 instanceof PolySubNetwork))
    {
      localObject3 = (PolySubNetwork)localElement1;
      localObject4 = ((PolySubNetwork)localObject3).getBaseShape();
      paramEncoder.writeStatement(new Statement(localObject4, "setWindingRule", new Object[] { new Integer(((GeneralPath)localObject4).getWindingRule()) }));
      localObject5 = new double[6];
      localObject6 = (Object[])null;
      PathIterator localPathIterator = ((GeneralPath)localObject4).getPathIterator(null);
      while (!localPathIterator.isDone())
      {
        int n = localPathIterator.currentSegment((double[])localObject5);
        switch (n)
        {
        case 0: 
          localObject6 = new Object[] { new Float(localObject5[0]), new Float(localObject5[1]) };
          paramEncoder.writeStatement(new Statement(localObject4, "moveTo", (Object[])localObject6));
          break;
        case 1: 
          localObject6 = new Object[] { new Float(localObject5[0]), new Float(localObject5[1]) };
          paramEncoder.writeStatement(new Statement(localObject4, "lineTo", (Object[])localObject6));
          break;
        case 2: 
          localObject6 = new Object[] { new Float(localObject5[0]), new Float(localObject5[1]), new Float(localObject5[2]), new Float(localObject5[3]) };
          paramEncoder.writeStatement(new Statement(localObject4, "quadTo", (Object[])localObject6));
          break;
        case 3: 
          localObject6 = new Object[] { new Float(localObject5[0]), new Float(localObject5[1]), new Float(localObject5[2]), new Float(localObject5[3]), new Float(localObject5[4]), new Float(localObject5[5]) };
          paramEncoder.writeStatement(new Statement(localObject4, "curveTo", (Object[])localObject6));
          break;
        case 4: 
          localObject6 = new Object[0];
          paramEncoder.writeStatement(new Statement(localObject4, "closePath", (Object[])localObject6));
        }
        localPathIterator.next();
      }
    }
    if (this.A.getElementDelegateInterceptor() != null) {
      this.A.getElementDelegateInterceptor().afterInitialize(paramEncoder, localElement1, localElement2);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.L
 * JD-Core Version:    0.7.0.1
 */
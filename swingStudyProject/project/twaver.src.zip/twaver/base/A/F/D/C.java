package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Statement;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import twaver.Layer;

public class C
  extends DefaultPersistenceDelegate
{
  public C()
  {
    super(new String[] { "ID" });
  }
  
  protected void initialize(Class paramClass, Object paramObject1, Object paramObject2, Encoder paramEncoder)
  {
    super.initialize(paramClass, paramObject1, paramObject2, paramEncoder);
    if ((paramObject1 instanceof Layer))
    {
      Layer localLayer = (Layer)paramObject1;
      Iterator localIterator = localLayer.getClientProperties().keySet().iterator();
      while (localIterator.hasNext())
      {
        Object localObject1 = localIterator.next();
        Object localObject2 = localLayer.getClientProperty(localObject1);
        paramEncoder.writeStatement(new Statement(paramObject1, "putClientProperty", new Object[] { localObject1, localObject2 }));
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.C
 * JD-Core Version:    0.7.0.1
 */
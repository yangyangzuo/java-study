package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;

public class K
  extends DefaultPersistenceDelegate
{
  public K()
  {
    super(new String[] { "time" });
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.K
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Expression;
import java.beans.XMLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import twaver.base.enumerable.Enumerable;
import twaver.base.enumerable.EnumerableManager;

public class I
  extends DefaultPersistenceDelegate
{
  private static I A = new I();
  
  public static I A()
  {
    return A;
  }
  
  protected Expression instantiate(Object paramObject, Encoder paramEncoder)
  {
    Enumerable localEnumerable = (Enumerable)paramObject;
    Object[] arrayOfObject = { localEnumerable.getClass(), localEnumerable.getName() };
    return new Expression(paramObject, EnumerableManager.class, "getEnumerable", arrayOfObject);
  }
  
  public void A(XMLEncoder paramXMLEncoder)
  {
    Iterator localIterator = EnumerableManager.getAllEnumerableMapper().keySet().iterator();
    while (localIterator.hasNext())
    {
      Class localClass = (Class)localIterator.next();
      paramXMLEncoder.setPersistenceDelegate(localClass, this);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.I
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Expression;
import twaver.AlarmSeverity;

public class A
  extends DefaultPersistenceDelegate
{
  public A() {}
  
  public A(String[] paramArrayOfString)
  {
    super(paramArrayOfString);
  }
  
  protected Expression instantiate(Object paramObject, Encoder paramEncoder)
  {
    AlarmSeverity localAlarmSeverity = (AlarmSeverity)paramObject;
    String str = localAlarmSeverity.getName();
    Object[] arrayOfObject = { str };
    return new Expression(paramObject, AlarmSeverity.class, "getByName", arrayOfObject);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.A
 * JD-Core Version:    0.7.0.1
 */
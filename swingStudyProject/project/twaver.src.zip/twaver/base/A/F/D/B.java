package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Expression;

public class B
  extends DefaultPersistenceDelegate
{
  protected void initialize(Class paramClass, Object paramObject1, Object paramObject2, Encoder paramEncoder) {}
  
  protected Expression instantiate(Object paramObject, Encoder paramEncoder)
  {
    return null;
  }
  
  public void writeObject(Object paramObject, Encoder paramEncoder) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.B
 * JD-Core Version:    0.7.0.1
 */
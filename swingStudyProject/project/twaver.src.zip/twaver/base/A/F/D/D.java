package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;

public class D
  extends DefaultPersistenceDelegate
{
  public D()
  {
    super(new String[] { "x", "y", "width", "height" });
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.D
 * JD-Core Version:    0.7.0.1
 */
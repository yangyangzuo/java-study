package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Expression;
import java.beans.XMLEncoder;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import twaver.TWaverUtil;

public class J
  extends DefaultPersistenceDelegate
{
  private static J A = null;
  private List B = new ArrayList();
  
  public static J A()
  {
    if (A == null) {
      A = new J();
    }
    return A;
  }
  
  public void A(Class paramClass)
  {
    if (!this.B.contains(paramClass)) {
      this.B.add(paramClass);
    }
  }
  
  public void A(XMLEncoder paramXMLEncoder)
  {
    for (int i = 0; i < this.B.size(); i++)
    {
      Class localClass = (Class)this.B.get(i);
      paramXMLEncoder.setPersistenceDelegate(localClass, this);
    }
  }
  
  protected Expression instantiate(Object paramObject, Encoder paramEncoder)
  {
    Class localClass = paramObject.getClass();
    Field[] arrayOfField = localClass.getFields();
    int i = 0;
    while (i < arrayOfField.length)
    {
      int j = arrayOfField[i].getModifiers();
      try
      {
        if ((Modifier.isStatic(j)) && (Modifier.isPublic(j)) && (Modifier.isFinal(j)) && (arrayOfField[i].get(null) == paramObject)) {
          return new Expression(paramObject, arrayOfField[i], "get", new Object[1]);
        }
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError(null, localException);
        i++;
      }
    }
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.J
 * JD-Core Version:    0.7.0.1
 */
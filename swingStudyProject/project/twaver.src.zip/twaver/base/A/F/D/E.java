package twaver.base.A.F.D;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.Statement;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import twaver.Alarm;

public class E
  extends DefaultPersistenceDelegate
{
  public E() {}
  
  public E(String[] paramArrayOfString)
  {
    super(paramArrayOfString);
  }
  
  protected void initialize(Class paramClass, Object paramObject1, Object paramObject2, Encoder paramEncoder)
  {
    super.initialize(paramClass, paramObject1, paramObject2, paramEncoder);
    if ((paramObject1 instanceof Alarm))
    {
      Alarm localAlarm = (Alarm)paramObject1;
      Collection localCollection = localAlarm.getComments();
      Object localObject3;
      if ((localCollection != null) && (localCollection.size() > 0))
      {
        localObject1 = localCollection.iterator();
        while (((Iterator)localObject1).hasNext())
        {
          localObject2 = new Object[] { ((Iterator)localObject1).next() };
          localObject3 = new Statement(localAlarm, "addComment", (Object[])localObject2);
          paramEncoder.writeStatement((Statement)localObject3);
        }
      }
      Object localObject1 = localAlarm.getCorrelatedAlarmIDs();
      Object localObject4;
      if ((localObject1 != null) && (((Collection)localObject1).size() > 0))
      {
        localObject2 = ((Collection)localObject1).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = new Object[] { ((Iterator)localObject2).next() };
          localObject4 = new Statement(localAlarm, "addCorrelatedAlarmID", (Object[])localObject3);
          paramEncoder.writeStatement((Statement)localObject4);
        }
      }
      Object localObject2 = localAlarm.getClientProperties().keySet().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = ((Iterator)localObject2).next();
        if ((localObject3 != null) && (!Alarm.isPredefinedProperty(localObject3.toString())))
        {
          localObject4 = localAlarm.getClientProperty(localObject3);
          paramEncoder.writeStatement(new Statement(paramObject1, "putClientProperty", new Object[] { localObject3, localObject4 }));
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.D.E
 * JD-Core Version:    0.7.0.1
 */
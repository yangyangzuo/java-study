package twaver.base.A.F;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.event.EventListenerList;
import twaver.DataBoxSelectionEvent;
import twaver.DataBoxSelectionListener;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.SelectionChangedInterceptor;
import twaver.TDataBox;

public class B
  implements DataBoxSelectionModel
{
  protected EventListenerList G = new EventListenerList();
  protected List F = new LinkedList();
  protected Map D = new HashMap();
  private boolean A = false;
  private TDataBox E = null;
  private int C = -1;
  private SelectionChangedInterceptor B = null;
  
  public B(TDataBox paramTDataBox)
  {
    this.E = paramTDataBox;
  }
  
  public TDataBox getDataBox()
  {
    return this.E;
  }
  
  public void selectAll()
  {
    setSelection(this.E.getAllElements());
  }
  
  public void addDataBoxSelectionListener(DataBoxSelectionListener paramDataBoxSelectionListener)
  {
    this.G.add(DataBoxSelectionListener.class, paramDataBoxSelectionListener);
  }
  
  public void appendSelection(Element paramElement)
  {
    if ((this.A) || (paramElement == null)) {
      return;
    }
    if (this.D.containsKey(paramElement.getID())) {
      return;
    }
    ArrayList localArrayList = new ArrayList(1);
    localArrayList.add(paramElement);
    C(2, localArrayList);
    this.A = true;
    this.F.add(paramElement);
    this.D.put(paramElement.getID(), paramElement);
    if (!paramElement.isSelected()) {
      paramElement.setSelected(true);
    }
    this.A = false;
    A(1, localArrayList);
    B(2, localArrayList);
  }
  
  public void appendSelection(Collection paramCollection)
  {
    if ((this.A) || (paramCollection == null) || (paramCollection.size() == 0)) {
      return;
    }
    C(1, paramCollection);
    this.A = true;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (!this.D.containsKey(localElement.getID()))
      {
        this.F.add(localElement);
        this.D.put(localElement.getID(), localElement);
      }
      localElement.setSelected(true);
    }
    this.A = false;
    A(1, paramCollection);
    B(1, paramCollection);
  }
  
  public boolean contains(Element paramElement)
  {
    if (paramElement == null) {
      return false;
    }
    return this.D.containsKey(paramElement.getID());
  }
  
  public Element lastElement()
  {
    if (this.F.isEmpty()) {
      return null;
    }
    return (Element)this.F.get(size() - 1);
  }
  
  public Element firstElement()
  {
    if (this.F.isEmpty()) {
      return null;
    }
    return (Element)this.F.get(0);
  }
  
  public Iterator selection()
  {
    return getAllSelectedElement().iterator();
  }
  
  public int size()
  {
    return this.F.size();
  }
  
  public void setSelection(Element paramElement)
  {
    if (paramElement == null) {
      return;
    }
    clearSelection();
    appendSelection(paramElement);
  }
  
  public void setSelection(Collection paramCollection)
  {
    if (paramCollection == null) {
      return;
    }
    clearSelection();
    appendSelection(paramCollection);
  }
  
  public void clearSelection()
  {
    if ((this.A) || (this.F.size() <= 0)) {
      return;
    }
    LinkedList localLinkedList = new LinkedList(this.F);
    C(3, localLinkedList);
    this.A = true;
    Iterator localIterator = localLinkedList.iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      localElement.setSelected(false);
    }
    this.F.clear();
    this.D.clear();
    this.A = false;
    A(3, localLinkedList);
    B(3, localLinkedList);
  }
  
  public void removeSelection(Collection paramCollection)
  {
    if ((this.A) || (paramCollection == null)) {
      return;
    }
    C(4, paramCollection);
    Iterator localIterator = paramCollection.iterator();
    this.A = true;
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (this.D.containsKey(localElement.getID()))
      {
        this.F.remove(localElement);
        this.D.remove(localElement.getID());
        localElement.setSelected(false);
      }
    }
    this.A = false;
    A(2, paramCollection);
    B(4, paramCollection);
  }
  
  private void A(int paramInt, Collection paramCollection)
  {
    Object[] arrayOfObject = this.G.getListenerList();
    DataBoxSelectionEvent localDataBoxSelectionEvent = new DataBoxSelectionEvent(this, paramInt, paramCollection);
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == DataBoxSelectionListener.class) {
        ((DataBoxSelectionListener)arrayOfObject[(i + 1)]).selectionChanged(localDataBoxSelectionEvent);
      }
    }
  }
  
  private void C(int paramInt, Collection paramCollection)
  {
    if (this.C != -1) {
      return;
    }
    this.C = paramInt;
    if (this.B != null) {
      this.B.beforeSelectionChanged(this.E, paramInt, paramCollection);
    }
  }
  
  private void B(int paramInt, Collection paramCollection)
  {
    if (this.C != paramInt) {
      return;
    }
    if (this.B != null) {
      this.B.afterSelectionChanged(this.E, paramInt, paramCollection);
    }
    this.C = -1;
  }
  
  public List getDataBoxSelectionListeners()
  {
    ArrayList localArrayList = new ArrayList();
    Object[] arrayOfObject = this.G.getListenerList();
    for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
      if (arrayOfObject[i] == DataBoxSelectionListener.class) {
        localArrayList.add((DataBoxSelectionListener)arrayOfObject[(i + 1)]);
      }
    }
    return localArrayList;
  }
  
  public boolean isEmpty()
  {
    return this.F.isEmpty();
  }
  
  public boolean isAdjusting()
  {
    return this.A;
  }
  
  public void removeDataBoxSelectionListener(DataBoxSelectionListener paramDataBoxSelectionListener)
  {
    this.G.remove(DataBoxSelectionListener.class, paramDataBoxSelectionListener);
  }
  
  public void removeSelection(Element paramElement)
  {
    if ((this.A) || (paramElement == null) || (!this.D.containsKey(paramElement.getID()))) {
      return;
    }
    ArrayList localArrayList = new ArrayList(1);
    localArrayList.add(paramElement);
    C(5, localArrayList);
    this.A = true;
    this.F.remove(paramElement);
    this.D.remove(paramElement.getID());
    paramElement.setSelected(false);
    this.A = false;
    A(2, localArrayList);
    B(5, localArrayList);
  }
  
  public List getAllSelectedElement()
  {
    return new ArrayList(this.F);
  }
  
  public List getToppestSelectedElement()
  {
    LinkedList localLinkedList = new LinkedList();
    HashMap localHashMap = new HashMap();
    for (int i = 0; i < this.F.size(); i++)
    {
      Element localElement;
      for (Object localObject = (Element)this.F.get(i); !localHashMap.containsKey(((Element)localObject).getID()); localObject = localElement)
      {
        localHashMap.put(((Element)localObject).getID(), null);
        localElement = ((Element)localObject).getParent();
        if (localElement == null)
        {
          localLinkedList.add(localObject);
          break;
        }
        if (!this.D.containsKey(localElement.getID()))
        {
          localLinkedList.add(localObject);
          break;
        }
      }
    }
    localHashMap.clear();
    return localLinkedList;
  }
  
  public SelectionChangedInterceptor getSelectionChangedInterceptor()
  {
    return this.B;
  }
  
  public void setSelectionChangedInterceptor(SelectionChangedInterceptor paramSelectionChangedInterceptor)
  {
    this.B = paramSelectionChangedInterceptor;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.B
 * JD-Core Version:    0.7.0.1
 */
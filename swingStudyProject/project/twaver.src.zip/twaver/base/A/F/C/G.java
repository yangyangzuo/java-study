package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import java.util.Map;
import twaver.Element;
import twaver.Equipment;
import twaver.base.A.F.E;

public class G
  implements E
{
  private Map F = null;
  
  public G(Map paramMap)
  {
    this.F = paramMap;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return ((paramPropertyChangeEvent.getSource() instanceof Equipment)) && (paramPropertyChangeEvent.getPropertyName().equals("tag"));
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    Object localObject = paramPropertyChangeEvent.getOldValue();
    this.F.remove(localObject);
    this.F.put(paramPropertyChangeEvent.getNewValue(), localElement);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.G
 * JD-Core Version:    0.7.0.1
 */
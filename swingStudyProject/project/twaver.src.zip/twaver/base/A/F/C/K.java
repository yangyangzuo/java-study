package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.TDataBox;
import twaver.base.A.F.E;

public class K
  implements E
{
  private TDataBox L = null;
  
  public K(TDataBox paramTDataBox)
  {
    this.L = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return paramPropertyChangeEvent.getPropertyName().equals("selected");
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    DataBoxSelectionModel localDataBoxSelectionModel = this.L.getSelectionModel();
    if (localElement.isSelected())
    {
      if (!localDataBoxSelectionModel.contains(localElement)) {
        localDataBoxSelectionModel.appendSelection(localElement);
      }
    }
    else if (localDataBoxSelectionModel.contains(localElement)) {
      localDataBoxSelectionModel.removeSelection(localElement);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.K
 * JD-Core Version:    0.7.0.1
 */
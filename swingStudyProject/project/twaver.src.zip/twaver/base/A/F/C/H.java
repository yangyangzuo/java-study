package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import java.util.List;
import twaver.AlarmPropagator;
import twaver.AlarmState;
import twaver.Element;
import twaver.TDataBox;
import twaver.base.A.F.E;

public class H
  implements E
{
  private TDataBox G = null;
  
  public H(TDataBox paramTDataBox)
  {
    this.G = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return paramPropertyChangeEvent.getPropertyName().equals("enableAlarmPropagationFromChildren");
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement1 = (Element)paramPropertyChangeEvent.getSource();
    if (localElement1.isEnableAlarmPropagationFromChildren())
    {
      AlarmPropagator localAlarmPropagator = this.G.getAlarmPropagator();
      if ((localElement1.childrenSize() > 0) && (localAlarmPropagator != null))
      {
        Element localElement2 = (Element)localElement1.getChildren().get(0);
        localAlarmPropagator.propagate(localElement2);
      }
      else
      {
        localElement1.getAlarmState().setPropagateSeverity(null);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.H
 * JD-Core Version:    0.7.0.1
 */
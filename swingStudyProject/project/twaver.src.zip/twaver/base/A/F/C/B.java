package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.Element;
import twaver.Group;
import twaver.TDataBox;
import twaver.UndoRedoManager;
import twaver.base.A.E.V;
import twaver.base.A.E.a;
import twaver.base.A.F.E;

public class B
  implements E
{
  private TDataBox A;
  
  public B(TDataBox paramTDataBox)
  {
    this.A = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return true;
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    String str = paramPropertyChangeEvent.getPropertyName();
    this.A.getUndoRedoManager().setIgnorePropertyChange(true);
    if (((localElement instanceof Group)) && (("children".equals(str)) || ("expand".equals(str)) || ("image".equals(str)))) {
      ((Group)localElement).invalidateGroupShape();
    }
    if (a.A(str)) {
      V.F(localElement);
    }
    this.A.getUndoRedoManager().setIgnorePropertyChange(false);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.B
 * JD-Core Version:    0.7.0.1
 */
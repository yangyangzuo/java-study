package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.Link;
import twaver.Node;
import twaver.TDataBox;

public class D
  implements twaver.base.A.F.E
{
  public TDataBox C = null;
  
  public D(TDataBox paramTDataBox)
  {
    this.C = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return ((paramPropertyChangeEvent.getSource() instanceof Link)) && (paramPropertyChangeEvent.getPropertyName().equals("toAgent"));
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Link localLink = (Link)paramPropertyChangeEvent.getSource();
    Node localNode1 = (Node)paramPropertyChangeEvent.getNewValue();
    Node localNode2 = (Node)paramPropertyChangeEvent.getOldValue();
    Node localNode3 = localLink.getFromAgent();
    this.C.tagLinkIndex(localNode2, localNode3);
    this.C.tagLinkIndex(localNode1, localNode3);
    twaver.base.A.E.E.A(this.C, localLink);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.D
 * JD-Core Version:    0.7.0.1
 */
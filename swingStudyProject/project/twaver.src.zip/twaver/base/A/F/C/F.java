package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.Element;
import twaver.Follower;
import twaver.TDataBox;

public class F
  implements twaver.base.A.F.E
{
  private TDataBox E = null;
  
  public F(TDataBox paramTDataBox)
  {
    this.E = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return paramPropertyChangeEvent.getPropertyName().equals("host");
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    if ((localElement instanceof Follower)) {
      twaver.base.A.E.E.A(this.E, localElement);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.F
 * JD-Core Version:    0.7.0.1
 */
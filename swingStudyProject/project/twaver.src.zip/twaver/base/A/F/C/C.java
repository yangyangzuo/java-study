package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.Group;
import twaver.TDataBox;
import twaver.base.A.E.j;

public class C
  implements twaver.base.A.F.E
{
  private TDataBox B = null;
  
  public C(TDataBox paramTDataBox)
  {
    this.B = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return ((paramPropertyChangeEvent.getSource() instanceof Group)) && (paramPropertyChangeEvent.getPropertyName().equals("expand"));
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Group localGroup = (Group)paramPropertyChangeEvent.getSource();
    j.A(localGroup);
    twaver.base.A.E.E.A(this.B, localGroup);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.C
 * JD-Core Version:    0.7.0.1
 */
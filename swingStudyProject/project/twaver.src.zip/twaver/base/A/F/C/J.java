package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import java.util.List;
import java.util.Map;
import twaver.AlarmPropagator;
import twaver.AlarmState;
import twaver.Element;
import twaver.Link;
import twaver.Node;
import twaver.TDataBox;
import twaver.base.A.E.j;

public class J
  implements twaver.base.A.F.E
{
  private TDataBox J = null;
  private Map K = null;
  private List I = null;
  
  public J(TDataBox paramTDataBox, Map paramMap, List paramList)
  {
    this.J = paramTDataBox;
    this.K = paramMap;
    this.I = paramList;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return paramPropertyChangeEvent.getPropertyName().equals("parent");
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement1 = (Element)paramPropertyChangeEvent.getSource();
    if (localElement1.getParent() == null)
    {
      if (!this.K.containsKey(localElement1.getID()))
      {
        this.K.put(localElement1.getID(), localElement1);
        this.I.add(localElement1);
      }
    }
    else if (this.K.containsKey(localElement1.getID()))
    {
      this.K.remove(localElement1.getID());
      this.I.remove(localElement1);
    }
    Element localElement2 = (Element)paramPropertyChangeEvent.getOldValue();
    AlarmPropagator localAlarmPropagator = this.J.getAlarmPropagator();
    if (localAlarmPropagator != null)
    {
      if (localElement2 != null) {
        if (localElement2.childrenSize() > 0)
        {
          Element localElement3 = (Element)localElement2.getChildren().get(0);
          localAlarmPropagator.propagate(localElement3);
        }
        else if (localElement2.getAlarmState().isEnablePropagationFromChildren())
        {
          localElement2.getAlarmState().setPropagateSeverity(null);
        }
      }
      localAlarmPropagator.propagate(localElement1);
    }
    if ((localElement1 instanceof Node)) {
      j.A((Node)localElement1);
    }
    if (!(localElement1 instanceof Link)) {
      twaver.base.A.E.E.A(this.J, localElement1);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.J
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.AlarmPropagator;
import twaver.Element;
import twaver.Link;
import twaver.TDataBox;
import twaver.base.A.F.E;

public class I
  implements E
{
  private TDataBox H = null;
  
  public I(TDataBox paramTDataBox)
  {
    this.H = paramTDataBox;
  }
  
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return paramPropertyChangeEvent.getPropertyName().equals("alarmState");
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    AlarmPropagator localAlarmPropagator = this.H.getAlarmPropagator();
    if (localAlarmPropagator != null) {
      localAlarmPropagator.propagate(localElement);
    }
    if ((this.H.isTagLinkWhenAlarmStateChanged()) && ((localElement instanceof Link))) {
      this.H.tagLinkIndex((Link)localElement);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.I
 * JD-Core Version:    0.7.0.1
 */
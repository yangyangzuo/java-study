package twaver.base.A.F.C;

import java.beans.PropertyChangeEvent;
import twaver.BTS;
import twaver.Element;
import twaver.base.A.E.V;
import twaver.base.A.F.E;

public class A
  implements E
{
  public boolean B(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return true;
  }
  
  public void A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    Element localElement = (Element)paramPropertyChangeEvent.getSource();
    if (((localElement instanceof BTS)) && (A(localElement, paramPropertyChangeEvent.getPropertyName()))) {
      V.A((BTS)localElement);
    }
  }
  
  public static boolean A(Element paramElement, String paramString)
  {
    return ("width".equals(paramString)) || ("height".equals(paramString)) || ("image".equals(paramString));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.C.A
 * JD-Core Version:    0.7.0.1
 */
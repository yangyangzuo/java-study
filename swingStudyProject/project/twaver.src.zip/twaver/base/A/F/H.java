package twaver.base.A.F;

import java.rmi.dgc.VMID;
import twaver.IdentifierFactory;

public class H
  implements IdentifierFactory
{
  private static H A = new H();
  
  public static H A()
  {
    return A;
  }
  
  public Object getIdentifier(Object paramObject)
  {
    return new VMID().toString();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.F.H
 * JD-Core Version:    0.7.0.1
 */
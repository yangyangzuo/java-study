package twaver.base.A.G;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;

public class F
  extends A
{
  private static final char[] A = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
  private static final byte[] B = new byte[256];
  byte[] C = new byte[4];
  
  static
  {
    for (int i = 0; i < 255; i++) {
      B[i] = -1;
    }
    for (i = 0; i < A.length; i++) {
      B[A[i]] = ((byte)i);
    }
  }
  
  protected int B()
  {
    return 4;
  }
  
  protected int A()
  {
    return 72;
  }
  
  protected void A(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    int j = -1;
    int k = -1;
    int m = -1;
    int n = -1;
    if (paramInt < 2) {
      throw new G("BASE64Decoder: Not enough bytes for an atom.");
    }
    do
    {
      i = paramPushbackInputStream.read();
      if (i == -1) {
        throw new D();
      }
    } while ((i == 10) || (i == 13));
    this.C[0] = ((byte)i);
    int i = A(paramPushbackInputStream, this.C, 1, paramInt - 1);
    if (i == -1) {
      throw new D();
    }
    if ((paramInt > 3) && (this.C[3] == 61)) {
      paramInt = 3;
    }
    if ((paramInt > 2) && (this.C[2] == 61)) {
      paramInt = 2;
    }
    switch (paramInt)
    {
    case 4: 
      n = B[(this.C[3] & 0xFF)];
    case 3: 
      m = B[(this.C[2] & 0xFF)];
    case 2: 
      k = B[(this.C[1] & 0xFF)];
      j = B[(this.C[0] & 0xFF)];
    }
    switch (paramInt)
    {
    case 2: 
      paramOutputStream.write((byte)(j << 2 & 0xFC | k >>> 4 & 0x3));
      break;
    case 3: 
      paramOutputStream.write((byte)(j << 2 & 0xFC | k >>> 4 & 0x3));
      paramOutputStream.write((byte)(k << 4 & 0xF0 | m >>> 2 & 0xF));
      break;
    case 4: 
      paramOutputStream.write((byte)(j << 2 & 0xFC | k >>> 4 & 0x3));
      paramOutputStream.write((byte)(k << 4 & 0xF0 | m >>> 2 & 0xF));
      paramOutputStream.write((byte)(m << 6 & 0xC0 | n & 0x3F));
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.F
 * JD-Core Version:    0.7.0.1
 */
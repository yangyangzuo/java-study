package twaver.base.A.G;

import java.util.Date;
import twaver.Task;
import twaver.TaskAdapter;

public class H
{
  private static final Task A = new TaskAdapter()
  {
    public int getInterval()
    {
      return 7200000;
    }
    
    public void run(long paramAnonymousLong)
    {
      J localJ = C.G();
      Date localDate1 = localJ.N();
      Date localDate2 = localJ.E();
      Date localDate3 = localJ.L();
      if ((localDate1 != null) && (localDate3.getTime() <= localDate1.getTime())) {
        C.B("TWaver License is expired");
      }
      if ((localDate2 != null) && (localDate3.getTime() >= localDate2.getTime())) {
        C.B("TWaver License is expired");
      }
      if (localJ.O() == 2) {
        C.C();
      }
    }
  };
  
  public static Task A()
  {
    return A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.H
 * JD-Core Version:    0.7.0.1
 */
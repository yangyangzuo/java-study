package twaver.base.A.G;

import java.io.IOException;

public class D
  extends IOException
{}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.D
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.G;

import java.io.IOException;

public class G
  extends IOException
{
  public G(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.G
 * JD-Core Version:    0.7.0.1
 */
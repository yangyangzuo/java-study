package twaver.base.A.G;

import java.io.IOException;
import java.io.OutputStream;

public class I
  extends B
{
  private static final char[] B = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
  
  protected int B()
  {
    return 3;
  }
  
  protected int A()
  {
    return 57;
  }
  
  protected void A(OutputStream paramOutputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    int j;
    int k;
    if (paramInt2 == 1)
    {
      i = paramArrayOfByte[paramInt1];
      j = 0;
      k = 0;
      paramOutputStream.write(B[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(B[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
      paramOutputStream.write(61);
      paramOutputStream.write(61);
    }
    else if (paramInt2 == 2)
    {
      i = paramArrayOfByte[paramInt1];
      j = paramArrayOfByte[(paramInt1 + 1)];
      k = 0;
      paramOutputStream.write(B[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(B[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
      paramOutputStream.write(B[((j << 2 & 0x3C) + (k >>> 6 & 0x3))]);
      paramOutputStream.write(61);
    }
    else
    {
      i = paramArrayOfByte[paramInt1];
      j = paramArrayOfByte[(paramInt1 + 1)];
      k = paramArrayOfByte[(paramInt1 + 2)];
      paramOutputStream.write(B[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(B[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
      paramOutputStream.write(B[((j << 2 & 0x3C) + (k >>> 6 & 0x3))]);
      paramOutputStream.write(B[(k & 0x3F)]);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.I
 * JD-Core Version:    0.7.0.1
 */
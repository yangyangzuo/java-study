package twaver.base.A.G;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;

public abstract class B
{
  protected PrintStream A;
  
  protected abstract int B();
  
  protected abstract int A();
  
  protected void A(OutputStream paramOutputStream)
    throws IOException
  {
    this.A = new PrintStream(paramOutputStream);
  }
  
  protected void C(OutputStream paramOutputStream)
    throws IOException
  {}
  
  protected void A(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {}
  
  protected void B(OutputStream paramOutputStream)
    throws IOException
  {
    this.A.println();
  }
  
  protected abstract void A(OutputStream paramOutputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  protected int A(InputStream paramInputStream, byte[] paramArrayOfByte)
    throws IOException
  {
    for (int i = 0; i < paramArrayOfByte.length; i++)
    {
      int j = paramInputStream.read();
      if (j == -1) {
        return i;
      }
      paramArrayOfByte[i] = ((byte)j);
    }
    return paramArrayOfByte.length;
  }
  
  public void A(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[A()];
    A(paramOutputStream);
    for (;;)
    {
      int j = A(paramInputStream, arrayOfByte);
      if (j == 0) {
        break;
      }
      A(paramOutputStream, j);
      int i = 0;
      while (i < j)
      {
        if (i + B() <= j) {
          A(paramOutputStream, arrayOfByte, i, B());
        } else {
          A(paramOutputStream, arrayOfByte, i, j - i);
        }
        i += B();
      }
      if (j < A()) {
        break;
      }
      B(paramOutputStream);
    }
    C(paramOutputStream);
  }
  
  public void A(byte[] paramArrayOfByte, OutputStream paramOutputStream)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    A(localByteArrayInputStream, paramOutputStream);
  }
  
  public String B(byte[] paramArrayOfByte)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    String str = null;
    try
    {
      A(localByteArrayInputStream, localByteArrayOutputStream);
      str = localByteArrayOutputStream.toString("8859_1");
    }
    catch (Exception localException)
    {
      throw new Error("CharacterEncoder.encode internal error");
    }
    return str;
  }
  
  private byte[] C(ByteBuffer paramByteBuffer)
  {
    Object localObject = (byte[])null;
    if (paramByteBuffer.hasArray())
    {
      byte[] arrayOfByte = paramByteBuffer.array();
      if ((arrayOfByte.length == paramByteBuffer.capacity()) && (arrayOfByte.length == paramByteBuffer.remaining()))
      {
        localObject = arrayOfByte;
        paramByteBuffer.position(paramByteBuffer.limit());
      }
    }
    if (localObject == null)
    {
      localObject = new byte[paramByteBuffer.remaining()];
      paramByteBuffer.get((byte[])localObject);
    }
    return localObject;
  }
  
  public void B(ByteBuffer paramByteBuffer, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = C(paramByteBuffer);
    A(arrayOfByte, paramOutputStream);
  }
  
  public String B(ByteBuffer paramByteBuffer)
  {
    byte[] arrayOfByte = C(paramByteBuffer);
    return B(arrayOfByte);
  }
  
  public void B(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[A()];
    A(paramOutputStream);
    int j;
    do
    {
      j = A(paramInputStream, arrayOfByte);
      if (j == 0) {
        break;
      }
      A(paramOutputStream, j);
      int i = 0;
      while (i < j)
      {
        if (i + B() <= j) {
          A(paramOutputStream, arrayOfByte, i, B());
        } else {
          A(paramOutputStream, arrayOfByte, i, j - i);
        }
        i += B();
      }
      B(paramOutputStream);
    } while (j >= A());
    C(paramOutputStream);
  }
  
  public void B(byte[] paramArrayOfByte, OutputStream paramOutputStream)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    B(localByteArrayInputStream, paramOutputStream);
  }
  
  public String A(byte[] paramArrayOfByte)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    try
    {
      B(localByteArrayInputStream, localByteArrayOutputStream);
    }
    catch (Exception localException)
    {
      throw new Error("CharacterEncoder.encodeBuffer internal error");
    }
    return localByteArrayOutputStream.toString();
  }
  
  public void A(ByteBuffer paramByteBuffer, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = C(paramByteBuffer);
    B(arrayOfByte, paramOutputStream);
  }
  
  public String A(ByteBuffer paramByteBuffer)
  {
    byte[] arrayOfByte = C(paramByteBuffer);
    return A(arrayOfByte);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.B
 * JD-Core Version:    0.7.0.1
 */
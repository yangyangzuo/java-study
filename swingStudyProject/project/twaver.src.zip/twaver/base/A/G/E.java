package twaver.base.A.G;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import twaver.TWaverUtil;
import twaver.base.A.A.G;
import twaver.swing.LabelValueLayout;

public class E
  extends JFrame
{
  public E()
  {
    setResizable(false);
    setTitle("TWaver " + TWaverUtil.getVersionString() + " License Information");
    setSize(450, 300);
    TWaverUtil.centerWindow(this);
    setDefaultCloseOperation(2);
    JPanel localJPanel1 = new JPanel(new BorderLayout(0, 10));
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
    JTextArea localJTextArea = new JTextArea();
    localJTextArea.setFont(new Font("Dialog", 0, 12));
    localJTextArea.setBackground(new JLabel().getBackground());
    localJTextArea.setLineWrap(true);
    localJTextArea.setWrapStyleWord(true);
    localJTextArea.setEditable(false);
    localJPanel1.add(new JScrollPane(localJTextArea), "Center");
    getContentPane().add(localJPanel1, "Center");
    J localJ = C.G();
    localJTextArea.setText(localJ.K());
    JPanel localJPanel2 = new JPanel(new LabelValueLayout());
    localJPanel2.add(new JLabel("License type:"));
    localJPanel2.add(new _A());
    localJPanel1.add(localJPanel2, "North");
    JPanel localJPanel3 = new JPanel(new BorderLayout());
    localJPanel3.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
    getContentPane().add(localJPanel3, "South");
    JPanel localJPanel4 = new JPanel(new FlowLayout(2, 10, 10));
    localJPanel3.add(localJPanel4, "Center");
    JButton localJButton = new JButton("OK");
    localJButton.setMnemonic('O');
    localJButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.this.dispose();
      }
    });
    localJPanel4.add(localJButton);
    getRootPane().setDefaultButton(localJButton);
    JPanel localJPanel5 = new JPanel(new BorderLayout());
    String str = "Copyright (c) 2008 SERVA Software";
    JLabel localJLabel = new JLabel(str);
    localJPanel5.add(localJLabel, "Center");
    localJPanel3.add(localJPanel5, "West");
  }
  
  private class _A
    extends JTextField
  {
    _A()
    {
      setEditable(false);
      setForeground(new Label().getForeground());
      setBorder(G.A);
      setText(C.G().P());
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.E
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.G;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;

public abstract class A
{
  protected abstract int B();
  
  protected abstract int A();
  
  protected void C(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream)
    throws IOException
  {}
  
  protected void A(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream)
    throws IOException
  {}
  
  protected int B(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    return A();
  }
  
  protected void D(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream)
    throws IOException
  {}
  
  protected void A(PushbackInputStream paramPushbackInputStream, OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    throw new D();
  }
  
  protected int A(InputStream paramInputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    for (int i = 0; i < paramInt2; i++)
    {
      int j = paramInputStream.read();
      if (j == -1) {
        return i == 0 ? -1 : i;
      }
      paramArrayOfByte[(i + paramInt1)] = ((byte)j);
    }
    return paramInt2;
  }
  
  public void A(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    int j = 0;
    PushbackInputStream localPushbackInputStream = new PushbackInputStream(paramInputStream);
    C(localPushbackInputStream, paramOutputStream);
    try
    {
      for (;;)
      {
        int k = B(localPushbackInputStream, paramOutputStream);
        int i = 0;
        while (i + B() < k)
        {
          A(localPushbackInputStream, paramOutputStream, B());
          j += B();
          i += B();
        }
        if (i + B() == k)
        {
          A(localPushbackInputStream, paramOutputStream, B());
          j += B();
        }
        else
        {
          A(localPushbackInputStream, paramOutputStream, k - i);
          j += k - i;
        }
        D(localPushbackInputStream, paramOutputStream);
      }
      return;
    }
    catch (D localD)
    {
      A(localPushbackInputStream, paramOutputStream);
    }
  }
  
  public byte[] A(String paramString)
    throws IOException
  {
    byte[] arrayOfByte1 = new byte[paramString.length()];
    byte[] arrayOfByte2 = paramString.getBytes();
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte1);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    A(localByteArrayInputStream, localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public byte[] A(InputStream paramInputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    A(paramInputStream, localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public ByteBuffer B(String paramString)
    throws IOException
  {
    return ByteBuffer.wrap(A(paramString));
  }
  
  public ByteBuffer B(InputStream paramInputStream)
    throws IOException
  {
    return ByteBuffer.wrap(A(paramInputStream));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.A
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.G;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.StringTokenizer;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import twaver.TWaverUtil;
import twaver.chart.AbstractChart;
import twaver.list.TList;
import twaver.network.TNetwork;
import twaver.swing.RotatableLabel;
import twaver.table.TPropertySheet;
import twaver.table.TTable;
import twaver.tree.TTree;
import twaver.web.svg.network.SVGContext;

public class C
{
  private static final String F = "/resource/key.dat";
  private static final String D = "<FingerPrint>";
  private static final String K = "RSA";
  private static final String I = "SHA1WithRSA";
  private static final String H = "UTF8";
  private static final String O = "VFdhdmVyIEV2YWx1YXRpb24gVmVyc2lvbg==";
  private static final String M = "VFdhdmVyIERldmVsb3BtZW50IFZlcnNpb24=";
  private static final String P = "VFdhdmVyIFJ1bnRpbWUgVmVyc2lvbg==";
  private static final Color L = ;
  private static final Font J = new Font("Default", 1, 18);
  private static final Font A = new Font("Tahoma", 0, 11);
  private static String E = null;
  private static J G = new J();
  private static AWTEventListener C = new AWTEventListener()
  {
    public void eventDispatched(AWTEvent paramAnonymousAWTEvent)
    {
      KeyEvent localKeyEvent = (KeyEvent)paramAnonymousAWTEvent;
      if ((localKeyEvent.isShiftDown()) && (localKeyEvent.isControlDown()) && (localKeyEvent.getKeyCode() == 84) && (localKeyEvent.getID() == 402)) {
        C.C();
      }
    }
  };
  private static E B = null;
  private static boolean N = false;
  
  private static PublicKey B()
    throws Exception
  {
    InputStream localInputStream = C.class.getResourceAsStream("/resource/key.dat");
    DataInputStream localDataInputStream = new DataInputStream(localInputStream);
    byte[] arrayOfByte = new byte[localDataInputStream.available()];
    localDataInputStream.readFully(arrayOfByte);
    localDataInputStream.close();
    arrayOfByte = TWaverUtil.decodeBase64Buffer(arrayOfByte);
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte);
    KeyFactory localKeyFactory = KeyFactory.getInstance("RSA");
    PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
    return localPublicKey;
  }
  
  private static boolean A(PublicKey paramPublicKey, String paramString, byte[] paramArrayOfByte)
    throws Exception
  {
    Signature localSignature = Signature.getInstance("SHA1WithRSA");
    localSignature.initVerify(paramPublicKey);
    localSignature.update(paramString.getBytes("UTF8"));
    return localSignature.verify(paramArrayOfByte);
  }
  
  private static String B(byte[] paramArrayOfByte)
    throws Exception
  {
    String str1 = new String(paramArrayOfByte, "UTF8");
    int i = str1.lastIndexOf("<FingerPrint>") - 2;
    String str2 = str1.substring(0, i);
    return str2;
  }
  
  private static String A(byte[] paramArrayOfByte)
    throws Exception
  {
    String str = new String(paramArrayOfByte, "UTF8");
    int i = str.lastIndexOf("<FingerPrint>") - 2;
    i = str.lastIndexOf("<FingerPrint>") + "<FingerPrint>".length();
    return str.substring(i);
  }
  
  private static byte[] A(String paramString)
  {
    paramString = paramString.substring(1, paramString.length() - 1);
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
    int i = localStringTokenizer.countTokens();
    byte[] arrayOfByte = new byte[i];
    for (int j = 0; localStringTokenizer.hasMoreTokens(); j++)
    {
      String str = localStringTokenizer.nextToken().trim();
      int k = Byte.valueOf(str).byteValue();
      arrayOfByte[j] = k;
    }
    return arrayOfByte;
  }
  
  public static void C(String paramString)
  {
    try
    {
      byte[] arrayOfByte1 = TWaverUtil.getByteArrayFromURL(paramString);
      if ((arrayOfByte1 == null) || (arrayOfByte1.length == 0))
      {
        System.err.println("Cannot locate license file from '" + paramString + "'.");
        return;
      }
      PublicKey localPublicKey = B();
      String str1 = B(arrayOfByte1);
      String str2 = A(arrayOfByte1);
      byte[] arrayOfByte2 = A(str2);
      boolean bool = A(localPublicKey, str1, arrayOfByte2);
      if (bool)
      {
        E = str1;
        G = new J(E);
        if (G.O() == 2)
        {
          System.out.println(D());
          System.out.println(G.K());
        }
      }
      else
      {
        System.err.println("Illegal license:" + paramString + ", application exit.");
        System.exit(0);
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public static J G()
  {
    return G;
  }
  
  static String A()
  {
    return new String(TWaverUtil.decodeBase64Buffer("VFdhdmVyIEV2YWx1YXRpb24gVmVyc2lvbg==".getBytes()));
  }
  
  static String D()
  {
    return new String(TWaverUtil.decodeBase64Buffer("VFdhdmVyIERldmVsb3BtZW50IFZlcnNpb24=".getBytes()));
  }
  
  static String F()
  {
    return new String(TWaverUtil.decodeBase64Buffer("VFdhdmVyIFJ1bnRpbWUgVmVyc2lvbg==".getBytes()));
  }
  
  static void B(String paramString)
  {
    if (N) {
      return;
    }
    N = true;
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        JOptionPane.showMessageDialog(null, C.this + ", System will exit.");
        System.exit(0);
      }
    });
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer)
  {
    if (!G.I()) {
      if (SwingUtilities.isEventDispatchThread())
      {
        B("TWaver SVG Access Denied");
      }
      else
      {
        System.err.println("TWaver SVG Access Denied, System will exit.");
        System.exit(0);
      }
    }
    if (G.O() == 1)
    {
      paramStringBuffer.append("<g");
      twaver.base.A.H.E.C(paramStringBuffer);
      paramStringBuffer.append(">");
      paramStringBuffer.append(twaver.base.A.H.E.A(paramSVGContext, "TWaver Evaluation Version", Color.BLACK, J, new Point(16, 31), false, null));
      paramStringBuffer.append(twaver.base.A.H.E.A(paramSVGContext, "TWaver Evaluation Version", Color.WHITE, J, new Point(14, 29), false, null));
      paramStringBuffer.append(twaver.base.A.H.E.A(paramSVGContext, "TWaver Evaluation Version", L, J, new Point(15, 30), false, null));
      paramStringBuffer.append("</g>");
    }
  }
  
  public static void A(JComponent paramJComponent, Graphics2D paramGraphics2D)
  {
    if ((!G.H()) && ((paramJComponent instanceof TNetwork))) {
      B("TWaver Network Access Denied");
    }
    if ((!G.J()) && ((paramJComponent instanceof TTree))) {
      B("TWaver Tree Access Denied");
    }
    if ((!G.B()) && ((paramJComponent instanceof TPropertySheet))) {
      B("TWaver PropertySheet Access Denied");
    }
    if ((!G.G()) && ((paramJComponent instanceof TTable))) {
      B("TWaver Table Access Denied");
    }
    if ((!G.D()) && ((paramJComponent instanceof TList))) {
      B("TWaver List Access Denied");
    }
    if ((!G.C()) && ((paramJComponent.getParent() instanceof AbstractChart))) {
      B("TWaver Chart Access Denied");
    }
    if (G.O() == 1)
    {
      String str = A();
      if ((str == null) || (str.trim().length() != 25)) {
        str = "TWaver Evaluation Version";
      }
      boolean bool = paramJComponent instanceof TNetwork;
      Font localFont = bool ? J : A;
      int i = bool ? 15 : 5;
      int j = bool ? 24 : paramJComponent.getHeight() - localFont.getSize();
      Object localObject = null;
      if (bool)
      {
        localObject = paramGraphics2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        paramGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      }
      paramGraphics2D.setFont(localFont);
      if (bool)
      {
        paramGraphics2D.setColor(Color.black);
        paramGraphics2D.drawString(str, i + 1, j + 1);
        paramGraphics2D.setColor(Color.white);
        paramGraphics2D.drawString(str, i - 1, j - 1);
      }
      paramGraphics2D.setColor(L);
      paramGraphics2D.drawString(str, i, j);
      if (bool) {
        paramGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, localObject);
      }
    }
  }
  
  public static void A(TNetwork paramTNetwork, Graphics2D paramGraphics2D)
  {
    if (G.A() != null)
    {
      String str = G.A();
      paramGraphics2D.setFont(A);
      Rectangle localRectangle = paramTNetwork.getCanvas().getVisibleRect();
      JLabel localJLabel = RotatableLabel.getLabelRenderer(1);
      localJLabel.setFont(A);
      localJLabel.setText(str);
      localJLabel.setForeground(L);
      Dimension localDimension = localJLabel.getPreferredSize();
      int i = localRectangle.x + localRectangle.width - localDimension.width - 6;
      int j = localRectangle.y + localRectangle.height - localDimension.height - 6;
      paramTNetwork.paintComponent(paramGraphics2D, localJLabel, i, j, localDimension.width, localDimension.height);
    }
  }
  
  public static void E()
  {
    try
    {
      Toolkit.getDefaultToolkit().addAWTEventListener(C, 8L);
    }
    catch (SecurityException localSecurityException) {}
  }
  
  static void C()
  {
    if (B != null)
    {
      B.toFront();
      return;
    }
    B = new E();
    B.setVisible(true);
    B.addWindowListener(new WindowAdapter()
    {
      public void windowClosed(WindowEvent paramAnonymousWindowEvent)
      {
        C.B = null;
      }
    });
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.C
 * JD-Core Version:    0.7.0.1
 */
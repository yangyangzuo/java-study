package twaver.base.A.G;

import java.io.IOException;
import java.io.LineNumberReader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import twaver.base.A.E.L;

public class J
{
  public static final int M = 1;
  public static final int N = 2;
  public static final int B = 3;
  private int J = 1;
  private String L = null;
  private String A = null;
  private boolean I = true;
  private boolean P = true;
  private boolean R = true;
  private boolean K = true;
  private boolean C = true;
  private boolean G = true;
  private boolean D = true;
  private boolean O = true;
  private Date F = null;
  private Date E = null;
  private Date Q = new Date();
  private Map H = null;
  
  J() {}
  
  J(String paramString)
  {
    this.L = paramString;
    B(paramString);
    F();
  }
  
  private void B(String paramString)
  {
    this.H = new HashMap();
    LineNumberReader localLineNumberReader = new LineNumberReader(new StringReader(paramString));
    String str1 = null;
    try
    {
      while ((str1 = localLineNumberReader.readLine()) != null)
      {
        int i = str1.indexOf("//");
        if (i != -1) {
          str1 = str1.substring(0, i);
        }
        int j = str1.indexOf("=");
        if (j != -1)
        {
          String str2 = str1.substring(0, j);
          str2 = str2.trim();
          String str3 = str1.substring(str1.indexOf("=") + 1);
          str3 = str3.trim();
          this.H.put(str2, str3);
        }
      }
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  private void F()
  {
    this.J = Integer.valueOf(this.H.get("LicenseType").toString()).intValue();
    boolean bool;
    if (A("PermissionAll"))
    {
      bool = C("PermissionAll");
      this.I = bool;
      this.P = bool;
      this.R = bool;
      this.K = bool;
      this.C = bool;
      this.G = bool;
      this.D = bool;
      this.O = bool;
    }
    if (A("PermissionSwing"))
    {
      bool = C("PermissionSwing");
      this.I = bool;
      this.P = bool;
      this.R = bool;
      this.K = bool;
      this.C = bool;
      this.G = bool;
    }
    if (A("PermissionWeb"))
    {
      bool = C("PermissionWeb");
      this.D = bool;
    }
    if (A("PermissionNetwork")) {
      this.I = C("PermissionNetwork");
    }
    if (A("PermissionTree")) {
      this.P = C("PermissionTree");
    }
    if (A("PermissionSheet")) {
      this.R = C("PermissionSheet");
    }
    if (A("PermissionTable")) {
      this.K = C("PermissionTable");
    }
    if (A("PermissionList")) {
      this.C = C("PermissionList");
    }
    if (A("PermissionChart")) {
      this.G = C("PermissionChart");
    }
    if (A("PermissionSVG")) {
      this.D = C("PermissionSVG");
    }
    if (A("PermissionGIS")) {
      this.O = C("PermissionGIS");
    }
    if (A("PrintInformation")) {
      this.A = this.H.get("PrintInformation").toString();
    }
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    this.F = A("BeginDate", localSimpleDateFormat);
    this.E = A("EndDate", localSimpleDateFormat);
  }
  
  private Date A(String paramString, DateFormat paramDateFormat)
  {
    Object localObject = this.H.get(paramString);
    if ((localObject != null) && (!"".equals(localObject))) {
      try
      {
        return paramDateFormat.parse(localObject.toString());
      }
      catch (ParseException localParseException) {}
    }
    return null;
  }
  
  private boolean A(String paramString)
  {
    Object localObject = this.H.get(paramString);
    return (localObject != null) && (!"".equals(localObject));
  }
  
  private boolean C(String paramString)
  {
    Object localObject = this.H.get(paramString);
    if ((localObject != null) && (!"".equals(localObject))) {
      return L.C(localObject.toString()).booleanValue();
    }
    return true;
  }
  
  public int O()
  {
    return this.J;
  }
  
  String P()
  {
    if (this.J == 1) {
      return C.A();
    }
    if (this.J == 2) {
      return C.D();
    }
    if (this.J == 3) {
      return C.F();
    }
    return "Unknown";
  }
  
  String K()
  {
    return this.L;
  }
  
  boolean H()
  {
    return this.I;
  }
  
  boolean B()
  {
    return this.R;
  }
  
  boolean G()
  {
    return this.K;
  }
  
  boolean C()
  {
    return this.G;
  }
  
  boolean D()
  {
    return this.C;
  }
  
  boolean J()
  {
    return this.P;
  }
  
  boolean I()
  {
    return this.D;
  }
  
  public boolean M()
  {
    return this.O;
  }
  
  public String A()
  {
    return this.A;
  }
  
  public Date E()
  {
    return this.E;
  }
  
  public Date N()
  {
    return this.F;
  }
  
  public Date L()
  {
    return this.Q;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.G.J
 * JD-Core Version:    0.7.0.1
 */
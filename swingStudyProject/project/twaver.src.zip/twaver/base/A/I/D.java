package twaver.base.A.I;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import twaver.Element;
import twaver.ElementAttribute;
import twaver.ElementAttributeVisibleFilter;
import twaver.TPropertyDescriptor;
import twaver.TView;

public abstract interface D
  extends TView
{
  public static final int HOTSPOT_SIZE = 18;
  public static final int DISTINCT_LEVEL_ELEMENT = 0;
  public static final int DISTINCT_LEVEL_CLASS = 1;
  public static final int VIEW_AS_FLAT_LIST = 0;
  public static final int VIEW_AS_CATEGORIES = 1;
  
  public abstract Iterator getSelection();
  
  public abstract Element getLastSelectedElement();
  
  public abstract Comparator getCategorySortingComparator();
  
  public abstract void setCategorySortingComparator(Comparator paramComparator);
  
  public abstract boolean isIndentOpaque();
  
  public abstract void setIndentOpaque(boolean paramBoolean);
  
  public abstract boolean isCategoryFontBold();
  
  public abstract void setCategoryFontBold(boolean paramBoolean);
  
  public abstract boolean isEditable();
  
  public abstract void setEditable(boolean paramBoolean);
  
  public abstract boolean isPropertyExtraIndent();
  
  public abstract void setPropertyExtraIndent(boolean paramBoolean);
  
  public abstract boolean isSingleRootCategoryVisible();
  
  public abstract void setSingleRootCategoryVisible(boolean paramBoolean);
  
  public abstract int getMode();
  
  public abstract void setMode(int paramInt);
  
  public abstract int getPropertyDistinctLevel();
  
  public abstract void setPropertyDistinctLevel(int paramInt);
  
  public abstract Comparator getPropertySortingComparator();
  
  public abstract void setPropertySortingComparator(Comparator paramComparator);
  
  public abstract boolean isSortingCategories();
  
  public abstract void setSortingCategories(boolean paramBoolean);
  
  public abstract boolean isSortingProperties();
  
  public abstract void setSortingProperties(boolean paramBoolean);
  
  public abstract boolean isSortingAscending();
  
  public abstract void setSortingAscending(boolean paramBoolean);
  
  public abstract List getAllBeanInfo(Element paramElement);
  
  public abstract boolean isVisible(ElementAttribute paramElementAttribute);
  
  public abstract ElementAttributeVisibleFilter getElementAttributeVisibleFilter();
  
  public abstract void setElementAttributeVisibleFilter(ElementAttributeVisibleFilter paramElementAttributeVisibleFilter);
  
  public abstract boolean isRestoreCategoryState();
  
  public abstract void setRestoreCategoryState(boolean paramBoolean);
  
  public abstract boolean isShowDescriptionColumn();
  
  public abstract void setShowDescriptionColumn(boolean paramBoolean);
  
  public abstract Object getDescription(Element paramElement, TPropertyDescriptor paramTPropertyDescriptor);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.I.D
 * JD-Core Version:    0.7.0.1
 */
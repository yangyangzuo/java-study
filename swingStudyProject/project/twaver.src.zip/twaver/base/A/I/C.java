package twaver.base.A.I;

import java.util.Comparator;
import java.util.List;
import twaver.ChildrenSortableFilter;
import twaver.Element;
import twaver.Generator;
import twaver.TView;
import twaver.VisibleFilter;

public abstract interface C
  extends TView
{
  public abstract boolean isVisible(Element paramElement);
  
  public abstract List getVisibleFilters();
  
  public abstract void addVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract void removeVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract String getDataBoxIconURL();
  
  public abstract void setDataBoxIconURL(String paramString);
  
  public abstract Comparator getSortComparator();
  
  public abstract void setSortComparator(Comparator paramComparator);
  
  public abstract ChildrenSortableFilter getChildrenSortableFilter();
  
  public abstract void setChildrenSortableFilter(ChildrenSortableFilter paramChildrenSortableFilter);
  
  public abstract boolean isIconVisible();
  
  public abstract void setIconVisible(boolean paramBoolean);
  
  public abstract Generator getElementLabelGenerator();
  
  public abstract void setElementLabelGenerator(Generator paramGenerator);
  
  public abstract Generator getElementStateOutlineColorGenerator();
  
  public abstract void setElementStateOutlineColorGenerator(Generator paramGenerator);
  
  public abstract Generator getElementBodyColorGenerator();
  
  public abstract void setElementBodyColorGenerator(Generator paramGenerator);
  
  public abstract boolean isShowPlainIcon();
  
  public abstract void setShowPlainIcon(boolean paramBoolean);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.I.C
 * JD-Core Version:    0.7.0.1
 */
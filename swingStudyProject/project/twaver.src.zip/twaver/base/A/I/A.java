package twaver.base.A.I;

import java.io.InputStream;
import java.util.List;
import twaver.Element;
import twaver.TView;
import twaver.VisibleFilter;

public abstract interface A
  extends TView
{
  public abstract boolean isVisible(Element paramElement);
  
  public abstract List getVisibleFilters();
  
  public abstract void addVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract void removeVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract Class getElementClass();
  
  public abstract void setElementClass(Class paramClass);
  
  public abstract List getAllBeanInfo(Class paramClass);
  
  public abstract void registerElementClassXML(Class paramClass, String paramString);
  
  public abstract void registerElementClassXML(Class paramClass, InputStream paramInputStream);
  
  public abstract void registerElementClassAttributes(Class paramClass, List paramList);
  
  public abstract List getElementClassAttributes(Class paramClass);
  
  public abstract boolean isConverseIncreaseOrder();
  
  public abstract void setConverseIncreaseOrder(boolean paramBoolean);
  
  public abstract boolean isIteratorByHiberarchy();
  
  public abstract void setIteratorByHiberarchy(boolean paramBoolean);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.I.A
 * JD-Core Version:    0.7.0.1
 */
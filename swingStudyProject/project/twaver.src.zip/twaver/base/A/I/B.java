package twaver.base.A.I;

import java.util.List;
import twaver.Element;
import twaver.Generator;
import twaver.MovableFilter;
import twaver.ResizableFilter;
import twaver.SelectableFilter;
import twaver.TSubNetwork;
import twaver.TView;
import twaver.VisibleFilter;
import twaver.network.background.Background;

public abstract interface B
  extends TView
{
  public abstract void setCurrentSubNetwork(TSubNetwork paramTSubNetwork);
  
  public abstract TSubNetwork getCurrentSubNetwork();
  
  public abstract void addVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract void removeVisibleFilter(VisibleFilter paramVisibleFilter);
  
  public abstract List getVisibleFilters();
  
  public abstract boolean isVisible(Element paramElement);
  
  public abstract void addMovableFilter(MovableFilter paramMovableFilter);
  
  public abstract void removeMovableFilter(MovableFilter paramMovableFilter);
  
  public abstract void clearMovableFilters();
  
  public abstract List getMovableFilters();
  
  public abstract boolean isMovable(Element paramElement);
  
  public abstract void addSelectableFilter(SelectableFilter paramSelectableFilter);
  
  public abstract void removeSelectableFilter(SelectableFilter paramSelectableFilter);
  
  public abstract List getSelectableFilters();
  
  public abstract boolean isSelectable(Element paramElement);
  
  public abstract void setResizableFilter(ResizableFilter paramResizableFilter);
  
  public abstract ResizableFilter getResizableFilter();
  
  public abstract boolean isResizable(Element paramElement);
  
  public abstract boolean isEnableIllegalLinkVisible();
  
  public abstract void setEnableIllegalLinkVisible(boolean paramBoolean);
  
  public abstract Background getNetworkBackground();
  
  public abstract void setNetworkBackground(Background paramBackground);
  
  public abstract Background getCurrentBackground();
  
  public abstract void setCurrentBackground(Background paramBackground);
  
  public abstract boolean isApplyBackgroundThroughSubNetwork();
  
  public abstract void setApplyBackgroundThroughSubNetwork(boolean paramBoolean);
  
  public abstract Generator getElementLabelGenerator();
  
  public abstract void setElementLabelGenerator(Generator paramGenerator);
  
  public abstract Generator getElementToolTipTextGenerator();
  
  public abstract void setElementToolTipTextGenerator(Generator paramGenerator);
  
  public abstract Generator getElementSelectColorGenerator();
  
  public abstract void setElementSelectColorGenerator(Generator paramGenerator);
  
  public abstract boolean isShowLinkBundleHandler();
  
  public abstract void setShowLinkBundleHandler(boolean paramBoolean);
  
  public abstract Generator getElementStateOutlineColorGenerator();
  
  public abstract void setElementStateOutlineColorGenerator(Generator paramGenerator);
  
  public abstract Generator getElementBodyColorGenerator();
  
  public abstract void setElementBodyColorGenerator(Generator paramGenerator);
  
  public abstract boolean isLinkBundleCompact();
  
  public abstract void setLinkBundleCompact(boolean paramBoolean);
  
  public abstract void setStraightLinkGap(int paramInt);
  
  public abstract int getStraightLinkGap();
  
  public abstract void setStraightLinkOffset(int paramInt);
  
  public abstract int getStraightLinkOffset();
  
  public abstract void setParallelLinkGap(int paramInt);
  
  public abstract int getParallelLinkGap();
  
  public abstract void setParallelLinkOffset(int paramInt);
  
  public abstract int getParallelLinkOffset();
  
  public abstract boolean isLinkBundleAlternate();
  
  public abstract void setLinkBundleAlternate(boolean paramBoolean);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.I.B
 * JD-Core Version:    0.7.0.1
 */
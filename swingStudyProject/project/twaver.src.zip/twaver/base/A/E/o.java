package twaver.base.A.E;

import java.util.HashMap;

class o
  extends HashMap
{
  public void B(String paramString)
  {
    put(paramString, null);
  }
  
  public void A(String paramString)
  {
    put("CP:" + paramString, null);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.o
 * JD-Core Version:    0.7.0.1
 */
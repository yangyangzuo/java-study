package twaver.base.A.E;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import twaver.Element;
import twaver.Link;
import twaver.TWaverConst;
import twaver.base.A.D.E;
import twaver.base.A.D.P;
import twaver.network.ui.ElementUI;
import twaver.network.ui.GroupUI;
import twaver.network.ui.LinkUI;
import twaver.web.svg.network.SVGContext;
import twaver.web.svg.network.ui.ElementSVGUI;

public class M
{
  public static Point B(ElementUI paramElementUI, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramElementUI instanceof LinkUI))
    {
      LinkUI localLinkUI = (LinkUI)paramElementUI;
      double d = localLinkUI.getAngle();
      return A(localLinkUI, paramDimension, d, paramInt1, paramInt2, paramInt3, false);
    }
    return A(paramElementUI, paramDimension, paramInt1, paramInt2, paramInt3);
  }
  
  public static Point A(LinkUI paramLinkUI, Dimension paramDimension, double paramDouble, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    if (paramInt1 == 0)
    {
      localPoint = paramLinkUI.getCenterPoint();
      localPoint.x += paramInt2;
      localPoint.y += paramInt3;
      return localPoint;
    }
    if (paramBoolean) {
      return A(paramLinkUI, paramDimension, paramDouble, paramInt1, paramInt2, paramInt3);
    }
    if (paramInt1 == 18)
    {
      localPoint = paramLinkUI.getFromAnchorPoint(paramInt2, paramInt3);
      localPoint.x -= paramDimension.width / 2;
      localPoint.y -= paramDimension.height / 2;
      return localPoint;
    }
    if (paramInt1 == 19)
    {
      localPoint = paramLinkUI.getToAnchorPoint(paramInt2, paramInt3);
      localPoint.x -= paramDimension.width / 2;
      localPoint.y -= paramDimension.height / 2;
      return localPoint;
    }
    Point localPoint = A(paramLinkUI, TWaverConst.EMPTY_DIMENSION, paramDouble, paramInt1, 0, 0);
    localPoint.x += paramInt2;
    localPoint.y += paramInt3;
    if (paramInt1 == 3)
    {
      localPoint.x -= paramDimension.width / 2;
    }
    else if (paramInt1 == 1)
    {
      localPoint.x -= paramDimension.width / 2;
      localPoint.y -= paramDimension.height / 2;
    }
    else if (paramInt1 == 2)
    {
      localPoint.x -= paramDimension.width / 2;
      localPoint.y -= paramDimension.height;
    }
    else if (paramInt1 == 4)
    {
      localPoint.x -= paramDimension.width;
      localPoint.y -= paramDimension.height / 2;
    }
    else if (paramInt1 == 5)
    {
      localPoint.y -= paramDimension.height / 2;
    }
    else if (paramInt1 == 6)
    {
      localPoint.y -= paramDimension.height;
    }
    else if (paramInt1 == 7)
    {
      localPoint.x -= paramDimension.width;
      localPoint.y -= paramDimension.height;
    }
    else if (paramInt1 != 8)
    {
      if (paramInt1 == 9)
      {
        localPoint.x -= paramDimension.width;
      }
      else if (paramInt1 == 10)
      {
        localPoint.x -= paramDimension.width / 2;
      }
      else if (paramInt1 == 11)
      {
        localPoint.x -= paramDimension.width / 2;
        localPoint.y -= paramDimension.height;
      }
      else if (paramInt1 == 12)
      {
        localPoint.y -= paramDimension.height / 2;
      }
      else if (paramInt1 == 13)
      {
        localPoint.x -= paramDimension.width;
        localPoint.y -= paramDimension.height / 2;
      }
      else if (paramInt1 == 14)
      {
        localPoint.y -= paramDimension.height;
      }
      else if (paramInt1 == 15)
      {
        localPoint.x -= paramDimension.width;
        localPoint.y -= paramDimension.height;
      }
      else if ((paramInt1 != 16) && (paramInt1 == 17))
      {
        localPoint.x -= paramDimension.width;
      }
    }
    return localPoint;
  }
  
  public static Rectangle A(E paramE, int paramInt)
  {
    P localP = null;
    Object localObject;
    if ((paramE instanceof P))
    {
      localP = (P)paramE;
    }
    else
    {
      localObject = paramE;
      localP = new P((E)localObject, 0);
    }
    if (C(paramInt))
    {
      localObject = localP.F().getBounds();
    }
    else
    {
      Rectangle localRectangle;
      if (A(paramInt))
      {
        localRectangle = localP.E().getBounds();
        localObject = localP.F().getBounds();
        ((Rectangle)localObject).y = localRectangle.y;
        ((Rectangle)localObject).x = (localRectangle.x + localRectangle.width - ((Rectangle)localObject).width);
      }
      else
      {
        localRectangle = localP.E().getBounds();
        localObject = localP.F().getBounds();
        ((Rectangle)localObject).y = ((localRectangle.y + ((Rectangle)localObject).y) / 2);
        ((Rectangle)localObject).x = ((((Rectangle)localObject).x + localRectangle.x + localRectangle.width - ((Rectangle)localObject).width) / 2);
        localObject.y -= ((Rectangle)localObject).height / 2;
      }
    }
    return localObject;
  }
  
  public static Point A(ElementUI paramElementUI, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == 0)
    {
      localObject = paramElementUI.getHotspot();
      localObject.x += paramInt2;
      localObject.y += paramInt3;
      return localObject;
    }
    Object localObject = null;
    if ((paramElementUI instanceof GroupUI))
    {
      Shape localShape = ((GroupUI)paramElementUI).getShape();
      if ((localShape instanceof E)) {
        localObject = A((E)localShape, paramInt1);
      } else {
        localObject = localShape.getBounds();
      }
    }
    if (localObject == null) {
      localObject = paramElementUI.getElement().getBounds();
    }
    return A((Rectangle)localObject, paramDimension, paramInt1, paramInt2, paramInt3);
  }
  
  public static Point A(ElementSVGUI paramElementSVGUI, SVGContext paramSVGContext, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == 0)
    {
      localObject = paramElementSVGUI.getHotspot(paramSVGContext);
      localObject.x += paramInt2;
      localObject.y += paramInt3;
      return localObject;
    }
    Object localObject = null;
    if ((paramElementSVGUI instanceof GroupUI))
    {
      Shape localShape = ((GroupUI)paramElementSVGUI).getShape();
      if ((localShape instanceof E)) {
        localObject = A((E)localShape, paramInt1);
      } else {
        localObject = localShape.getBounds();
      }
    }
    if (localObject == null) {
      localObject = paramElementSVGUI.getElement().getBounds();
    }
    return A((Rectangle)localObject, paramDimension, paramInt1, paramInt2, paramInt3);
  }
  
  public static Point A(Rectangle paramRectangle, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    boolean bool = B(paramInt1);
    int i;
    if (E(paramInt1))
    {
      i = paramRectangle.x;
      if (paramInt1 == 4) {
        i -= paramDimension.width;
      }
    }
    else if (D(paramInt1))
    {
      i = paramRectangle.x + paramRectangle.width - paramDimension.width;
      if (paramInt1 == 5) {
        i += paramDimension.width;
      }
    }
    else
    {
      i = paramRectangle.x + paramRectangle.width / 2 - paramDimension.width / 2;
    }
    int j;
    if (A(paramInt1))
    {
      if (bool) {
        j = paramRectangle.y;
      } else {
        j = paramRectangle.y - paramDimension.height;
      }
    }
    else if (C(paramInt1))
    {
      if (bool) {
        j = paramRectangle.y + paramRectangle.height - paramDimension.height;
      } else {
        j = paramRectangle.y + paramRectangle.height;
      }
    }
    else {
      j = paramRectangle.y + paramRectangle.height / 2 - paramDimension.height / 2;
    }
    i += paramInt2;
    j += paramInt3;
    return new Point(i, j);
  }
  
  public static boolean B(int paramInt)
  {
    return paramInt >= 10;
  }
  
  public static boolean A(int paramInt)
  {
    return (paramInt == 2) || (paramInt == 6) || (paramInt == 7) || (paramInt == 11) || (paramInt == 14) || (paramInt == 15);
  }
  
  public static boolean C(int paramInt)
  {
    return (paramInt == 3) || (paramInt == 8) || (paramInt == 9) || (paramInt == 10) || (paramInt == 16) || (paramInt == 17);
  }
  
  public static boolean E(int paramInt)
  {
    return (paramInt == 4) || (paramInt == 6) || (paramInt == 8) || (paramInt == 12) || (paramInt == 14) || (paramInt == 16);
  }
  
  public static boolean D(int paramInt)
  {
    return (paramInt == 5) || (paramInt == 7) || (paramInt == 9) || (paramInt == 13) || (paramInt == 15) || (paramInt == 17);
  }
  
  private static Point A(LinkUI paramLinkUI, Dimension paramDimension, double paramDouble, int paramInt1, int paramInt2, int paramInt3)
  {
    Point localPoint1;
    Point localPoint2;
    if (paramLinkUI.getLink().getLinkType() == 2)
    {
      localPoint1 = paramLinkUI.getFromInflexion();
      localPoint2 = paramLinkUI.getToInflexion();
    }
    else
    {
      localPoint1 = paramLinkUI.getFromPoint();
      localPoint2 = paramLinkUI.getToPoint();
    }
    int i = localPoint1.x <= localPoint2.x ? 1 : 0;
    if (i == 0) {
      if (paramInt1 == 14) {
        paramInt1 = 17;
      } else if (paramInt1 == 17) {
        paramInt1 = 14;
      } else if (paramInt1 == 12) {
        paramInt1 = 13;
      } else if (paramInt1 == 13) {
        paramInt1 = 12;
      } else if (paramInt1 == 10) {
        paramInt1 = 11;
      } else if (paramInt1 == 11) {
        paramInt1 = 10;
      }
    }
    Point localPoint3 = paramLinkUI.getCenterPoint();
    double d1 = -Math.sin(paramDouble);
    double d2 = Math.cos(paramDouble);
    int j = (int)D.A(localPoint1, localPoint2);
    int k = paramDimension.width / 2;
    int m = paramDimension.height / 2;
    if (E(paramInt1))
    {
      k = j / 2;
      if (paramInt1 == 4) {
        k += paramDimension.width;
      }
    }
    else if (D(paramInt1))
    {
      k = -j / 2 + paramDimension.width;
      if (paramInt1 == 5) {
        k -= paramDimension.width;
      }
    }
    int n = k - paramInt2;
    int i1 = m - paramInt3;
    int i2 = (int)(localPoint3.x - i1 * d1 - n * d2);
    int i3 = (int)(localPoint3.y + (n * d1 - i1 * d2));
    int i4 = (paramLinkUI.getLinkWidth() + paramLinkUI.getOutlineWidth()) / 2 + m;
    int i5 = (int)(d1 * i4);
    int i6 = (int)(d2 * i4);
    if (A(paramInt1))
    {
      i2 -= i5;
      i3 -= i6;
    }
    else if (C(paramInt1))
    {
      i2 += i5;
      i3 += i6;
    }
    return new Point(i2, i3);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.M
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.Image;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import twaver.ResourceLocateInterceptor;
import twaver.TWaverUtil;
import twaver.base.A.D.B.E;

public final class C
{
  private static ResourceLocateInterceptor B = null;
  private static final Map A = new HashMap() {};
  private static final Map C = new HashMap() {};
  
  public static void A()
  {
    C.clear();
    C.put("-", null);
  }
  
  public static void B()
  {
    A.clear();
    A.put("-", null);
    N.A();
  }
  
  public static void A(String paramString, ImageIcon paramImageIcon)
  {
    if (paramImageIcon == null) {
      A.remove(paramString);
    } else {
      A.put(paramString, paramImageIcon);
    }
    N.B(paramString);
  }
  
  public static boolean A(String paramString)
  {
    return A.containsKey(paramString);
  }
  
  public static void A(ResourceLocateInterceptor paramResourceLocateInterceptor)
  {
    B = paramResourceLocateInterceptor;
  }
  
  public static Icon E(String paramString)
  {
    return B(paramString);
  }
  
  public static byte[] A(InputStream paramInputStream)
  {
    if (paramInputStream != null) {
      try
      {
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramInputStream.available());
        int i = -1;
        while ((i = paramInputStream.read()) != -1) {
          localByteArrayOutputStream.write(i);
        }
        return localByteArrayOutputStream.toByteArray();
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError(null, localException);
        try
        {
          paramInputStream.close();
        }
        catch (IOException localIOException) {}
      }
    }
    return null;
  }
  
  public static byte[] C(String paramString)
  {
    InputStream localInputStream = B(paramString, true);
    return A(localInputStream);
  }
  
  public static byte[] C(String paramString, boolean paramBoolean)
  {
    InputStream localInputStream = B(paramString, paramBoolean);
    return A(localInputStream);
  }
  
  public static final ImageIcon B(String paramString)
  {
    return A(paramString, true);
  }
  
  public static final ImageIcon A(String paramString, boolean paramBoolean)
  {
    if (paramString == null) {
      return null;
    }
    paramString = E.B().A(paramString);
    if (A.containsKey(paramString)) {
      return (ImageIcon)A.get(paramString);
    }
    byte[] arrayOfByte = C(paramString, paramBoolean);
    if ((arrayOfByte != null) && (arrayOfByte.length > 0))
    {
      ImageIcon localImageIcon = new ImageIcon(arrayOfByte);
      A.put(paramString, localImageIcon);
      return localImageIcon;
    }
    A.put(paramString, null);
    if (paramBoolean) {
      TWaverUtil.handleError("can't load image '" + paramString + "'", null);
    }
    return null;
  }
  
  public static final Image D(String paramString)
  {
    ImageIcon localImageIcon = B(paramString);
    if (localImageIcon != null) {
      return localImageIcon.getImage();
    }
    return null;
  }
  
  public static InputStream B(String paramString, boolean paramBoolean)
  {
    InputStream localInputStream = null;
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return null;
    }
    if (B != null)
    {
      Object localObject = B.locate(paramString);
      if ((localObject instanceof InputStream)) {
        return (InputStream)localObject;
      }
      if ((localObject instanceof String))
      {
        paramString = (String)localObject;
      }
      else if (localObject == ResourceLocateInterceptor.INVALID_URL)
      {
        C.put(paramString, null);
        return null;
      }
    }
    if (C.containsKey(paramString)) {
      return null;
    }
    if (paramString.indexOf(":") > 0) {
      localInputStream = A(paramString, null, paramBoolean);
    } else {
      localInputStream = A(paramString, TWaverUtil.class, paramBoolean);
    }
    if (localInputStream == null) {
      C.put(paramString, null);
    }
    return localInputStream;
  }
  
  public static InputStream A(String paramString, Class paramClass, boolean paramBoolean)
  {
    try
    {
      URL localURL = null;
      if (paramClass == null) {
        localURL = new URL(paramString);
      } else {
        localURL = paramClass.getResource(paramString);
      }
      if ((localURL == null) && (TWaverUtil.classLoader != null)) {
        localURL = TWaverUtil.classLoader.getResource(paramString);
      }
      if (localURL == null) {
        return null;
      }
      URLConnection localURLConnection = localURL.openConnection();
      return localURLConnection.getInputStream();
    }
    catch (Exception localException)
    {
      if (paramBoolean) {
        A(paramString, localException);
      }
    }
    return null;
  }
  
  private static void A(String paramString, Exception paramException)
  {
    TWaverUtil.handleError("Can not find resource with url '" + paramString + "'.\n\n" + "    Example URI:\n" + "            file:/D:/abc/def/123.xml\n" + "            http://www.abc.com/def/123.xml\n" + "            ftp://www.abc.com/def/123.xml\n" + "    More information on the types of URLs and their formats can be found at:\n " + "            http://www.ietf.org/rfc/rfc2396.txt.\n", paramException);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.C
 * JD-Core Version:    0.7.0.1
 */
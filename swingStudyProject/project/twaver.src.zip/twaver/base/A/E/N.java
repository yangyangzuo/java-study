package twaver.base.A.E;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import twaver.PixelFilter;
import twaver.TWaverUtil;
import twaver.base.A.A.A.D;
import twaver.base.A.A.A.F;
import twaver.base.A.D.B.E;
import twaver.base.A.D.I;
import twaver.web.WebUtil;
import twaver.web.svg.network.SVGContext;

public class N
{
  private static final Map C = new HashMap();
  private static final Map D = new HashMap();
  private static final Map B = new HashMap();
  private static final Map A = new HashMap();
  
  public static void A(Image paramImage, String paramString1, String paramString2, boolean paramBoolean)
  {
    synchronized (SVGContext.class)
    {
      if ((paramBoolean) && (A.containsKey(paramString1))) {
        return;
      }
      F localF = new F(paramImage);
      if ((localF.A(paramString1, paramString2, null)) && (paramBoolean)) {
        A.put(paramString1, null);
      }
    }
  }
  
  public static void A()
  {
    synchronized (SVGContext.class)
    {
      C.clear();
      D.clear();
      B.clear();
      A.clear();
      WebUtil.clearImageBase64Cache();
    }
  }
  
  public static void B(String paramString)
  {
    synchronized (SVGContext.class)
    {
      C.remove(paramString);
      D.remove(paramString);
      B.remove(paramString);
      List localList = WebUtil.getImageIDs(paramString);
      Iterator localIterator1 = localList.iterator();
      while (localIterator1.hasNext())
      {
        String str1 = (String)localIterator1.next();
        Iterator localIterator2 = new HashSet(A.keySet()).iterator();
        while (localIterator2.hasNext())
        {
          String str2 = (String)localIterator2.next();
          if (str2.indexOf(str1) >= 0) {
            A.remove(str2);
          }
        }
        WebUtil.removeImageBase64Cache(str1);
      }
    }
  }
  
  public static byte[] A(Image paramImage, String paramString)
  {
    paramString = D.ensureFormatName(paramString);
    BufferedImage localBufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), D.getImageType(paramString));
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    localGraphics2D.drawImage(paramImage, 0, 0, null);
    localGraphics2D.dispose();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      ImageIO.write(localBufferedImage, paramString, localByteArrayOutputStream);
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  private static Integer A(Color paramColor)
  {
    Integer localInteger = null;
    if (paramColor != null) {
      localInteger = TWaverUtil.valueOf(paramColor.getRGB());
    }
    return localInteger;
  }
  
  public static ImageIcon A(String paramString, Color paramColor)
  {
    if ((paramString == null) || (paramString.equals("-"))) {
      return null;
    }
    paramString = E.B().A(paramString);
    HashMap localHashMap = (HashMap)C.get(paramString);
    if (localHashMap == null)
    {
      localHashMap = new HashMap();
      C.put(paramString, localHashMap);
    }
    Integer localInteger = A(paramColor);
    ImageIcon localImageIcon = (ImageIcon)localHashMap.get(localInteger);
    if (localImageIcon == null)
    {
      Image localImage = B(paramString, paramColor);
      if (localImage != null)
      {
        localImageIcon = new ImageIcon(localImage);
        localHashMap.put(localInteger, localImageIcon);
      }
    }
    return localImageIcon;
  }
  
  public static Shape C(String paramString)
  {
    if ((paramString == null) || ("-".equals(paramString))) {
      return null;
    }
    paramString = E.B().A(paramString);
    Shape localShape = (Shape)B.get(paramString);
    if (localShape == null)
    {
      localShape = I.A(TWaverUtil.getImage(paramString));
      if (localShape != null) {
        B.put(paramString, localShape);
      }
    }
    return localShape;
  }
  
  public static Shape A(ImageIcon paramImageIcon)
  {
    return I.A(paramImageIcon.getImage());
  }
  
  public static boolean A(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramString = E.B().A(paramString);
    ImageIcon localImageIcon = A(paramString, null);
    int i = localImageIcon.getIconWidth();
    int j = localImageIcon.getIconHeight();
    if (paramInt3 > 0) {
      paramInt1 = (int)(paramInt1 * (i / paramInt3));
    }
    if (paramInt4 > 0) {
      paramInt2 = (int)(paramInt2 * (j / paramInt4));
    }
    if ((paramInt1 >= i) || (paramInt1 < 0)) {
      return false;
    }
    if ((paramInt2 >= j) || (paramInt2 < 0)) {
      return false;
    }
    int[] arrayOfInt = A(paramString);
    int k = arrayOfInt[(paramInt2 * i + paramInt1)];
    int m = k >> 24 & 0xFF;
    return m != 0;
  }
  
  private static int[] A(String paramString)
  {
    paramString = E.B().A(paramString);
    return (int[])D.get(paramString);
  }
  
  private static Image B(String paramString, Color paramColor)
  {
    paramString = E.B().A(paramString);
    Image localImage = TWaverUtil.getImage(paramString);
    if (localImage == null) {
      return null;
    }
    int i = localImage.getWidth(null);
    int j = localImage.getHeight(null);
    int[] arrayOfInt = (int[])D.get(paramString);
    if (arrayOfInt == null)
    {
      arrayOfInt = new int[i * j];
      localObject = new PixelGrabber(localImage, 0, 0, i, j, arrayOfInt, 0, i);
      try
      {
        ((PixelGrabber)localObject).grabPixels();
      }
      catch (InterruptedException localInterruptedException)
      {
        TWaverUtil.handleError(null, localInterruptedException);
        return null;
      }
      D.put(paramString, arrayOfInt);
    }
    Object localObject = new BufferedImage(i > 1 ? i : 1, j > 1 ? j : 1, 2);
    PixelFilter localPixelFilter = TWaverUtil.getPixelFilter();
    for (int k = 0; k < arrayOfInt.length; k++)
    {
      int m = arrayOfInt[k];
      int n = k / i;
      int i1 = k % i;
      if (paramColor != null) {
        m = localPixelFilter.filter(m, paramColor);
      }
      ((BufferedImage)localObject).setRGB(i1, n, m);
    }
    return localObject;
  }
  
  public static Image A(Image paramImage, Color paramColor, boolean paramBoolean1, boolean paramBoolean2)
  {
    BufferedImage localBufferedImage1 = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
    Graphics2D localGraphics2D = localBufferedImage1.createGraphics();
    localGraphics2D.drawImage(paramImage, 0, 0, null);
    localGraphics2D.dispose();
    GeneralPath localGeneralPath = new GeneralPath();
    ArrayList localArrayList1 = new ArrayList();
    int m;
    int i2;
    for (int i = 0; i < localBufferedImage1.getWidth(); i++)
    {
      ArrayList localArrayList3 = new ArrayList();
      int k = 1;
      for (m = 0; m < localBufferedImage1.getHeight(); m++)
      {
        int n = localBufferedImage1.getRGB(i, m) & 0xFF000000;
        i2 = n == 0 ? 1 : 0;
        if (i2 != k)
        {
          localArrayList3.add(new Point(i, m));
          k = i2;
        }
      }
      if (k == 0) {
        localArrayList3.add(new Point(i, localBufferedImage1.getHeight()));
      }
      for (m = 0; m < localArrayList3.size(); m++)
      {
        Point localPoint1 = (Point)localArrayList3.get(m);
        if (m % 2 == 0) {
          localGeneralPath.moveTo(localPoint1.x, localPoint1.y);
        } else {
          localGeneralPath.lineTo(localPoint1.x, localPoint1.y);
        }
      }
      localArrayList1.add(localArrayList3);
    }
    ArrayList localArrayList2 = new ArrayList();
    Object localObject;
    int i1;
    int i3;
    for (int j = 0; j < localBufferedImage1.getHeight(); j++)
    {
      localObject = new ArrayList();
      m = 1;
      for (i1 = 0; i1 < localBufferedImage1.getWidth(); i1++)
      {
        i2 = localBufferedImage1.getRGB(i1, j) & 0xFF000000;
        i3 = i2 == 0 ? 1 : 0;
        if (i3 != m)
        {
          ((List)localObject).add(new Point(i1, j));
          m = i3;
        }
      }
      if (m == 0) {
        ((List)localObject).add(new Point(localBufferedImage1.getWidth(), j));
      }
      localArrayList2.add(localObject);
    }
    BufferedImage localBufferedImage2 = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
    localGraphics2D = localBufferedImage2.createGraphics();
    localGraphics2D.setColor(paramColor);
    localGraphics2D.draw(localGeneralPath);
    if (paramBoolean1)
    {
      localObject = paramColor.brighter();
      Color localColor = paramColor.darker();
      if (paramBoolean2)
      {
        localObject = Color.white;
        localColor = Color.black;
      }
      List localList;
      Point localPoint2;
      for (i1 = 0; i1 < localArrayList1.size(); i1++)
      {
        localList = (List)localArrayList1.get(i1);
        for (i3 = 0; i3 < localList.size(); i3++)
        {
          localPoint2 = (Point)localList.get(i3);
          if (i3 % 2 == 0) {
            localGraphics2D.setColor((Color)localObject);
          } else {
            localGraphics2D.setColor(localColor);
          }
          localGraphics2D.drawLine(localPoint2.x, localPoint2.y, localPoint2.x, localPoint2.y);
        }
      }
      for (i1 = 0; i1 < localArrayList2.size(); i1++)
      {
        localList = (List)localArrayList2.get(i1);
        for (i3 = 0; i3 < localList.size(); i3++)
        {
          localPoint2 = (Point)localList.get(i3);
          if (i3 % 2 == 0) {
            localGraphics2D.setColor((Color)localObject);
          } else {
            localGraphics2D.setColor(localColor);
          }
          localGraphics2D.drawLine(localPoint2.x, localPoint2.y, localPoint2.x, localPoint2.y);
        }
      }
    }
    return localBufferedImage2;
  }
  
  private static int A(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = paramInt5 >> 24 & 0xFF;
    int j = paramInt5 >> 16 & 0xFF;
    int k = paramInt5 >> 8 & 0xFF;
    int m = paramInt5 & 0xFF;
    double d = paramInt2 * 100 / paramInt4 / 100.0D;
    i = (int)(i * d * d);
    int n = (j + k + m) / 3;
    return (i << 24) + (n << 16) + (n << 8) + n;
  }
  
  public static ImageIcon A(Image paramImage)
  {
    int i = paramImage.getWidth(null);
    int j = paramImage.getHeight(null);
    int[] arrayOfInt1 = new int[i * j];
    PixelGrabber localPixelGrabber = new PixelGrabber(paramImage, 0, 0, i, j, arrayOfInt1, 0, i);
    try
    {
      localPixelGrabber.grabPixels();
    }
    catch (Exception localException)
    {
      return null;
    }
    for (int k = 0; k < j; k++) {
      for (m = 0; m < i; m++) {
        arrayOfInt1[(k * i + m)] = A(m, k, i, j, arrayOfInt1[(k * i + m)]);
      }
    }
    int[] arrayOfInt2 = new int[i * j];
    for (int m = 0; m < j; m++) {
      for (int n = 0; n < i; n++) {
        arrayOfInt2[(m * i + n)] = arrayOfInt1[((j - m - 1) * i + n)];
      }
    }
    MemoryImageSource localMemoryImageSource = new MemoryImageSource(i, j, arrayOfInt2, 0, i);
    return new ImageIcon(Toolkit.getDefaultToolkit().createImage(localMemoryImageSource));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.N
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Insets;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import twaver.ElementAttribute;
import twaver.TUIManager;
import twaver.TWaverUtil;
import twaver.base.Direction;

public final class L
{
  private static final Map A = new HashMap();
  
  static
  {
    try
    {
      Field[] arrayOfField = Color.class.getFields();
      for (int i = 0; i < arrayOfField.length; i++)
      {
        Field localField = arrayOfField[i];
        int j = localField.getModifiers();
        if ((Modifier.isStatic(j)) && (Modifier.isPublic(j)) && (Modifier.isFinal(j)))
        {
          String str = localField.getName();
          Object localObject = localField.get(null);
          if ((localObject instanceof Color)) {
            A.put(str.toLowerCase(), localObject);
          }
        }
      }
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
  }
  
  public static String B(String paramString)
  {
    if ((paramString != null) && (paramString.startsWith("i18nKey:")))
    {
      String str = paramString.substring("i18nKey:".length());
      return TWaverUtil.getString(str);
    }
    return paramString;
  }
  
  public static String A(ElementAttribute paramElementAttribute, Class paramClass)
  {
    String str1 = paramElementAttribute.getDisplayName();
    if (str1 != null) {
      return B(str1);
    }
    String str2 = paramClass.getName() + ".";
    if (paramElementAttribute.getUserPropertyKey() != null) {
      str2 = str2 + paramElementAttribute.getUserPropertyKey();
    } else if (paramElementAttribute.isClientProperty()) {
      str2 = str2 + paramElementAttribute.getClientPropertyKey();
    } else {
      str2 = str2 + paramElementAttribute.getName();
    }
    return TWaverUtil.getString(str2);
  }
  
  public static String A(String paramString1, String paramString2, String paramString3)
  {
    if (paramString1 == null) {
      return null;
    }
    if ((paramString2 == null) || (paramString3 == null)) {
      return paramString1;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    int j = paramString1.indexOf(paramString2);
    int k = paramString2.length();
    while (j >= 0)
    {
      localStringBuffer.append(paramString1.substring(i, j));
      localStringBuffer.append(paramString3);
      i = j + k;
      j = paramString1.indexOf(paramString2, i);
    }
    localStringBuffer.append(paramString1.substring(i));
    return localStringBuffer.toString();
  }
  
  public static String A(char paramChar)
  {
    if (paramChar == '&') {
      return "&amp;";
    }
    if (paramChar == '<') {
      return "&lt;";
    }
    if (paramChar == '\r') {
      return "&#13;";
    }
    if (paramChar == '>') {
      return "&gt;";
    }
    if (paramChar == '"') {
      return "&quot;";
    }
    if (paramChar == '\'') {
      return "&apos;";
    }
    return String.valueOf(paramChar);
  }
  
  public static String A(Object paramObject)
  {
    return (paramObject == null) || (paramObject.toString().trim().equals("")) ? null : paramObject.toString();
  }
  
  public static BasicStroke G(String paramString)
  {
    String[] arrayOfString = paramString.split("\\|");
    if (arrayOfString.length == 1) {
      return new BasicStroke(Float.parseFloat(arrayOfString[0]));
    }
    if (arrayOfString.length == 2) {
      return new BasicStroke(Float.parseFloat(arrayOfString[0]), 0, 0, 10.0F, new float[] { Integer.parseInt(arrayOfString[1]) }, 0.0F);
    }
    return new BasicStroke(1.0F);
  }
  
  public static Insets A(String paramString)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return new Insets(0, 0, 0, 0);
    }
    String[] arrayOfString = paramString.split("\\|");
    return new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3]));
  }
  
  public static Direction F(String paramString)
  {
    if ("HORIZONTAL".equalsIgnoreCase(paramString)) {
      return Direction.HORIZONTAL;
    }
    return Direction.VERTICAL;
  }
  
  public static Font E(String paramString)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return TUIManager.getDefaultFont();
    }
    String[] arrayOfString = paramString.split("\\|");
    return TWaverUtil.getFont(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]));
  }
  
  public static String A(Color paramColor, boolean paramBoolean)
  {
    String str1 = Integer.toHexString(paramColor.getRGB() & 0xFFFFFF);
    String str2 = Integer.toHexString(paramColor.getAlpha());
    String str3 = "#000000".substring(0, 7 - str1.length()).concat(str1);
    if (paramBoolean) {
      return (str3 + "00".substring(0, 2 - str2.length()).concat(str2)).toUpperCase();
    }
    return str3.toUpperCase();
  }
  
  public static String A(Font paramFont)
  {
    String str = paramFont.getFontName() + "/";
    if (paramFont.getStyle() == 1) {
      str = str + TWaverUtil.getString("BOLD");
    } else if (paramFont.getStyle() == 2) {
      str = str + TWaverUtil.getString("ITALIC");
    } else if (paramFont.getStyle() == 0) {
      str = str + TWaverUtil.getString("PLAIN");
    } else if (paramFont.getStyle() == 3) {
      str = str + TWaverUtil.getString("BOLDITALIC");
    }
    str = str + "/" + paramFont.getSize();
    return str;
  }
  
  public static Color D(String paramString)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return null;
    }
    Color localColor = (Color)A.get(paramString.toLowerCase());
    if (localColor != null) {
      return localColor;
    }
    if (paramString.startsWith("#"))
    {
      long l = Long.decode(paramString).longValue();
      if (paramString.length() > 7) {
        return new Color((int)(l >> 24 & 0xFF), (int)(l >> 16 & 0xFF), (int)(l >> 8 & 0xFF), (int)(l & 0xFF));
      }
      return new Color((int)(l >> 16 & 0xFF), (int)(l >> 8 & 0xFF), (int)(l & 0xFF));
    }
    String[] arrayOfString = paramString.split("\\|");
    int i = Integer.parseInt(arrayOfString[0]);
    int j = Integer.parseInt(arrayOfString[1]);
    int k = Integer.parseInt(arrayOfString[2]);
    if (arrayOfString.length == 3) {
      return new Color(i, j, k);
    }
    if ("darker".equals(arrayOfString[3])) {
      return new Color(i, j, k).darker();
    }
    if ("brighter".equals(arrayOfString[3])) {
      return new Color(i, j, k).brighter();
    }
    return new Color(i, j, k, Integer.parseInt(arrayOfString[3]));
  }
  
  public static Boolean C(String paramString)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return Boolean.FALSE;
    }
    if ("true".equalsIgnoreCase(paramString)) {
      return Boolean.TRUE;
    }
    if ("false".equalsIgnoreCase(paramString)) {
      return Boolean.FALSE;
    }
    if ("T".equalsIgnoreCase(paramString)) {
      return Boolean.TRUE;
    }
    if ("F".equalsIgnoreCase(paramString)) {
      return Boolean.FALSE;
    }
    if ("yes".equalsIgnoreCase(paramString)) {
      return Boolean.TRUE;
    }
    if ("no".equalsIgnoreCase(paramString)) {
      return Boolean.FALSE;
    }
    if ("Y".equalsIgnoreCase(paramString)) {
      return Boolean.TRUE;
    }
    if ("N".equalsIgnoreCase(paramString)) {
      return Boolean.FALSE;
    }
    return Boolean.FALSE;
  }
  
  public static Object A(String paramString, Class paramClass)
  {
    if ((paramString == null) || (paramString.trim().equals(""))) {
      return null;
    }
    if (Boolean.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToBoolean(paramString);
    }
    if (Color.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToColor(paramString);
    }
    if (Font.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToFont(paramString);
    }
    if (Direction.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToDirection(paramString);
    }
    if (Insets.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToInsets(paramString);
    }
    if (BasicStroke.class.isAssignableFrom(paramClass)) {
      return TWaverUtil.stringToBasicStroke(paramString);
    }
    if (Number.class.isAssignableFrom(paramClass))
    {
      double d = Double.parseDouble(paramString);
      if (paramClass == Integer.class) {
        return TWaverUtil.valueOf((int)d);
      }
      if (paramClass == Long.class) {
        return new Long(d);
      }
      if (paramClass == Byte.class) {
        return new Byte((byte)(int)d);
      }
      if (paramClass == Float.class) {
        return new Float((float)d);
      }
      if (paramClass == Double.class) {
        return new Double(d);
      }
      if (paramClass == Character.class) {
        return new Character((char)(int)d);
      }
      if (paramClass == Short.class) {
        return new Short((short)(int)d);
      }
    }
    return paramString;
  }
  
  public static void A(Component paramComponent, String paramString)
  {
    Object localObject;
    if ((paramComponent instanceof JTextField))
    {
      localObject = (JTextField)paramComponent;
      if ("LEFT".equalsIgnoreCase(paramString)) {
        ((JTextField)localObject).setHorizontalAlignment(2);
      } else if ("CENTER".equalsIgnoreCase(paramString)) {
        ((JTextField)localObject).setHorizontalAlignment(0);
      } else if ("RIGHT".equalsIgnoreCase(paramString)) {
        ((JTextField)localObject).setHorizontalAlignment(4);
      } else if ("LEADING".equalsIgnoreCase(paramString)) {
        ((JTextField)localObject).setHorizontalAlignment(10);
      } else if ("TRAILING".equalsIgnoreCase(paramString)) {
        ((JTextField)localObject).setHorizontalAlignment(11);
      }
    }
    else if ((paramComponent instanceof JLabel))
    {
      localObject = (JLabel)paramComponent;
      if ("LEFT".equalsIgnoreCase(paramString)) {
        ((JLabel)localObject).setHorizontalAlignment(2);
      } else if ("CENTER".equalsIgnoreCase(paramString)) {
        ((JLabel)localObject).setHorizontalAlignment(0);
      } else if ("RIGHT".equalsIgnoreCase(paramString)) {
        ((JLabel)localObject).setHorizontalAlignment(4);
      } else if ("LEADING".equalsIgnoreCase(paramString)) {
        ((JLabel)localObject).setHorizontalAlignment(10);
      } else if ("TRAILING".equalsIgnoreCase(paramString)) {
        ((JLabel)localObject).setHorizontalAlignment(11);
      }
    }
    else if ((paramComponent instanceof AbstractButton))
    {
      localObject = (AbstractButton)paramComponent;
      if ("LEFT".equalsIgnoreCase(paramString)) {
        ((AbstractButton)localObject).setHorizontalAlignment(2);
      } else if ("CENTER".equalsIgnoreCase(paramString)) {
        ((AbstractButton)localObject).setHorizontalAlignment(0);
      } else if ("RIGHT".equalsIgnoreCase(paramString)) {
        ((AbstractButton)localObject).setHorizontalAlignment(4);
      } else if ("LEADING".equalsIgnoreCase(paramString)) {
        ((AbstractButton)localObject).setHorizontalAlignment(10);
      } else if ("TRAILING".equalsIgnoreCase(paramString)) {
        ((AbstractButton)localObject).setHorizontalAlignment(11);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.L
 * JD-Core Version:    0.7.0.1
 */
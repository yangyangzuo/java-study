package twaver.base.A.E;

import java.awt.BasicStroke;
import java.awt.Stroke;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import twaver.LinkStyleFactory;
import twaver.base.A.D.F.D;

public class J
{
  private static Map A = new LinkedHashMap();
  
  static
  {
    A.put("solid", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        return c.B(paramAnonymousInt);
      }
    });
    A.put("dash", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        return c.D(paramAnonymousInt);
      }
    });
    A.put("broken", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        if (paramAnonymousInt <= 0) {
          paramAnonymousInt = 1;
        }
        float f = paramAnonymousInt * 4;
        f = f > 4.0F ? f : 4.0F;
        return new BasicStroke(paramAnonymousInt, 0, 1, 0.0F, new float[] { f, f / 2.0F }, 0.0F);
      }
    });
    A.put("chain", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        return c.C(paramAnonymousInt);
      }
    });
    A.put("dot", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        return new BasicStroke(paramAnonymousInt, 1, 1, 10.0F, new float[] { 0.0F, paramAnonymousInt * 2 - 1 }, 0.0F);
      }
    });
    A.put("zigzag", new LinkStyleFactory()
    {
      public Stroke createStroke(int paramAnonymousInt)
      {
        return new D(c.B(paramAnonymousInt), paramAnonymousInt, (int)(paramAnonymousInt * 1.5D));
      }
    });
  }
  
  public static LinkStyleFactory A(String paramString)
  {
    return (LinkStyleFactory)A.get(paramString);
  }
  
  public static void A(String paramString, LinkStyleFactory paramLinkStyleFactory)
  {
    A.put(paramString, paramLinkStyleFactory);
  }
  
  public static Iterator A()
  {
    return A.keySet().iterator();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.J
 * JD-Core Version:    0.7.0.1
 */
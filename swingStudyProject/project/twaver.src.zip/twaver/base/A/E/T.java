package twaver.base.A.E;

import twaver.base.A.D.E.C.E;
import twaver.base.A.D.E.C.G;
import twaver.base.A.D.E.E.F;
import twaver.base.A.D.E.E.M;
import twaver.base.A.D.E.E.S;

public class T
  extends RuntimeException
{
  public static final E D = new E(0.0D, 0.0D);
  public static final Object C = new Object();
  public static final Object B = new Object();
  public static final G E = new G();
  public static final E G = new E(0.0D, 0.0D);
  public static final Object A = "A";
  public static final Object F = "B";
  
  public static void A()
  {
    if (Thread.interrupted()) {
      throw new RuntimeException();
    }
  }
  
  public static int A(E paramE1, E paramE2, E paramE3)
  {
    return A(paramE1.A, paramE1.B, paramE2.A, paramE2.B, paramE3.A, paramE3.B);
  }
  
  public static int A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    paramDouble3 -= paramDouble1;
    paramDouble4 -= paramDouble2;
    paramDouble5 -= paramDouble1;
    paramDouble6 -= paramDouble2;
    double d = paramDouble5 * paramDouble4 - paramDouble6 * paramDouble3;
    return d >= 0.0D ? -1 : d <= 0.0D ? 0 : 1;
  }
  
  public static boolean C(E paramE1, E paramE2, E paramE3)
  {
    return A(paramE1, paramE2, paramE3) > 0;
  }
  
  public static boolean B(E paramE1, E paramE2, E paramE3)
  {
    return A(paramE1, paramE2, paramE3) < 0;
  }
  
  public static boolean D(E paramE1, E paramE2, E paramE3)
  {
    return A(paramE1, paramE2, paramE3) == 0;
  }
  
  public static S A(S paramS)
  {
    return B(paramS);
  }
  
  public static S B(S paramS)
  {
    S localS1 = new S(paramS.F());
    S localS2 = new S();
    localS1.B();
    if (localS1.isEmpty()) {
      return localS2;
    }
    Object localObject = (E)localS1.A();
    localS2.D(localObject);
    while ((!localS1.isEmpty()) && (((E)localObject).equals(localS1.E()))) {
      localS1.A();
    }
    if (localS1.isEmpty()) {
      return localS2;
    }
    localObject = (E)localS1.A();
    M localM1 = localS2.D(localObject);
    F localF = localS1.F();
    while (localF.C())
    {
      E localE = (E)localF.D();
      if (!localE.equals(localObject))
      {
        localObject = localE;
        if ((localS2.size() == 2) && (D((E)localS2.E(), (E)localS2.H(), localE)))
        {
          localM1.A(localE);
        }
        else
        {
          for (M localM2 = localM1; !B((E)localS2.D(localM2).B(), (E)localM2.B(), localE); localM2 = localS2.D(localM2)) {}
          for (M localM3 = localM1; !C((E)localS2.E(localM3).B(), (E)localM3.B(), localE); localM3 = localS2.E(localM3)) {}
          while (localM3 != localS2.E(localM2)) {
            localS2.F(localS2.E(localM2));
          }
          localM1 = localS2.B(localE, localM2);
        }
      }
      localF.B();
    }
    return localS2;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.T
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.geom.Point2D.Double;

class d
{
  public double B = 0.0D;
  public boolean C = false;
  public Point2D.Double A = null;
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.d
 * JD-Core Version:    0.7.0.1
 */
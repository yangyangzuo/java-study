package twaver.base.A.E;

import java.io.File;
import javax.swing.filechooser.FileFilter;

class k
  extends FileFilter
{
  private String A;
  
  public k(String paramString)
  {
    this.A = paramString;
  }
  
  public boolean accept(File paramFile)
  {
    if (paramFile.isDirectory()) {
      return true;
    }
    String str = A(paramFile);
    if (str != null)
    {
      if (str.equals(this.A)) {
        return c.A(str);
      }
      return false;
    }
    return false;
  }
  
  public String getDescription()
  {
    return this.A;
  }
  
  public String A(File paramFile)
  {
    String str1 = null;
    String str2 = paramFile.getName();
    int i = str2.lastIndexOf('.');
    if ((i > 0) && (i < str2.length() - 1)) {
      str1 = str2.substring(i + 1).toLowerCase();
    }
    return str1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.k
 * JD-Core Version:    0.7.0.1
 */
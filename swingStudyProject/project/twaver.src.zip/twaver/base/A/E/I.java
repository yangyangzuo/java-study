package twaver.base.A.E;

import java.beans.ExceptionListener;
import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import twaver.Alarm;
import twaver.AlarmModel;
import twaver.DataBoxContext;
import twaver.DataBoxParserAgent;
import twaver.Element;
import twaver.Layer;
import twaver.LayerModel;
import twaver.TDataBox;
import twaver.TWaverUtil;
import twaver.XMLInterceptor;

public class I
{
  private static ExceptionListener A = new ExceptionListener()
  {
    public void exceptionThrown(Exception paramAnonymousException)
    {
      TWaverUtil.handleError(null, paramAnonymousException);
    }
  };
  
  public static void A(TDataBox paramTDataBox, InputStream paramInputStream, Element paramElement)
    throws IOException
  {
    if (paramInputStream == null) {
      throw new NullPointerException("inputStream can't be null.");
    }
    if (paramTDataBox == null) {
      throw new NullPointerException("box can't be null.");
    }
    if (TWaverUtil.getXMLInterceptor() != null)
    {
      localObject1 = TWaverUtil.getXMLInterceptor().beforeRead(paramTDataBox, paramInputStream, paramElement);
      if (localObject1 != null) {
        paramInputStream = (InputStream)localObject1;
      }
    }
    DataBoxParserAgent.setDataBox(paramTDataBox);
    Object localObject1 = new BufferedInputStream(paramInputStream)
    {
      public void close()
        throws IOException
      {
        this.in = null;
        this.buf = null;
      }
    };
    XMLDecoder localXMLDecoder = new XMLDecoder((InputStream)localObject1);
    localXMLDecoder.setExceptionListener(A);
    try
    {
      for (Object localObject2 = localXMLDecoder.readObject(); localObject2 != null; localObject2 = localXMLDecoder.readObject()) {
        A(localObject2, paramTDataBox, localXMLDecoder, paramElement);
      }
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {}
    localXMLDecoder.close();
    DataBoxParserAgent.setDataBox(null);
    if (TWaverUtil.getXMLInterceptor() != null) {
      TWaverUtil.getXMLInterceptor().afterRead(paramTDataBox, paramInputStream, paramElement);
    }
  }
  
  public static void A(Object paramObject, TDataBox paramTDataBox, XMLDecoder paramXMLDecoder, Element paramElement)
  {
    Object localObject1;
    if ((paramObject instanceof Element))
    {
      localObject1 = (Element)paramObject;
      paramTDataBox.addElement((Element)localObject1, paramElement);
    }
    else
    {
      Object localObject2;
      if ((paramObject instanceof String))
      {
        localObject1 = (String)paramObject;
        localObject2 = paramXMLDecoder.readObject();
        paramTDataBox.putClientProperty(localObject1, localObject2);
      }
      else if ((paramObject instanceof DataBoxContext))
      {
        localObject1 = (DataBoxContext)paramObject;
        if (((DataBoxContext)localObject1).getID() != null) {
          paramTDataBox.setID(((DataBoxContext)localObject1).getID());
        }
        if (((DataBoxContext)localObject1).getName() != null) {
          paramTDataBox.setName(((DataBoxContext)localObject1).getName());
        }
        if (((DataBoxContext)localObject1).getBackground() != null) {
          paramTDataBox.setBackground(((DataBoxContext)localObject1).getBackground());
        }
        if (((DataBoxContext)localObject1).getVersion() != null)
        {
          localObject2 = ((DataBoxContext)localObject1).getVersion();
          if (((String)localObject2).startsWith("#VERSION{"))
          {
            int i = ((String)localObject2).indexOf("}VERSION#");
            if (i > 0) {
              paramTDataBox.setVersion(((String)localObject2).substring("#VERSION{".length(), i));
            }
          }
        }
      }
      else if ((paramObject instanceof Alarm))
      {
        localObject1 = (Alarm)paramObject;
        A(paramTDataBox, (Alarm)localObject1);
      }
      else if ((paramObject instanceof Layer))
      {
        localObject1 = (Layer)paramObject;
        localObject2 = paramTDataBox.getLayerModel().getLayerByID(((Layer)localObject1).getID());
        if (localObject2 == null) {
          paramTDataBox.getLayerModel().addLayer((Layer)localObject1);
        } else {
          ((Layer)localObject1).exportValues((Layer)localObject2);
        }
      }
    }
  }
  
  private static void A(TDataBox paramTDataBox, Alarm paramAlarm)
  {
    paramTDataBox.getAlarmModel().addAlarm(paramAlarm);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.I
 * JD-Core Version:    0.7.0.1
 */
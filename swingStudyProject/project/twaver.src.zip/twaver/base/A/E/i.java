package twaver.base.A.E;

import java.awt.Insets;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import twaver.Dummy;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.base.A.D.E;
import twaver.base.A.D.M;

public class i
{
  public static Point A(Shape paramShape, Group paramGroup)
  {
    Point localPoint = null;
    if ((paramGroup.isExpand()) && (paramGroup.getGroupType() == 6))
    {
      int i = (int)(paramGroup.getGroupChamferEdge() * Math.sin(0.7853981633974483D) / 2.0D);
      Rectangle localRectangle = paramShape.getBounds();
      return new Point(localRectangle.x + localRectangle.width - i, localRectangle.y + i);
    }
    Object localObject;
    if (((paramShape instanceof M)) || ((paramShape instanceof Ellipse2D)))
    {
      localObject = null;
      if ((paramShape instanceof M)) {
        localObject = ((M)paramShape).A();
      } else if ((paramShape instanceof Ellipse2D)) {
        localObject = (Ellipse2D)paramShape;
      }
      localPoint = K.A(((Ellipse2D)localObject).getX(), ((Ellipse2D)localObject).getY(), ((Ellipse2D)localObject).getWidth(), ((Ellipse2D)localObject).getHeight(), 0.7D);
    }
    else
    {
      localObject = paramShape.getBounds();
      if (((paramShape instanceof E)) && (((E)paramShape).B() > 90))
      {
        localPoint = new Point(((Rectangle)localObject).x + ((E)paramShape).C(), ((Rectangle)localObject).y);
      }
      else
      {
        localPoint = new Point(((Rectangle)localObject).x + ((Rectangle)localObject).width, ((Rectangle)localObject).y);
        if (((Rectangle)localObject).width > 3) {
          localPoint.x -= 3;
        }
        if (((Rectangle)localObject).height > 3) {
          localPoint.y += 3;
        }
      }
    }
    return localPoint;
  }
  
  public static Rectangle A(Group paramGroup, int paramInt, Insets paramInsets, Generator paramGenerator)
  {
    Object localObject = null;
    Iterator localIterator = paramGroup.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if ((!(localElement instanceof Dummy)) && (!(localElement instanceof Link)))
      {
        Rectangle localRectangle = (Rectangle)paramGenerator.generate(localElement);
        if (localRectangle != null)
        {
          if (paramInt >= 0)
          {
            localRectangle.y = (localRectangle.y + localRectangle.height - paramInt);
            localRectangle.height = paramInt;
          }
          if (localObject == null) {
            localObject = localRectangle;
          } else {
            localObject.add(localRectangle);
          }
        }
      }
    }
    if (localObject == null) {
      return null;
    }
    if (paramInsets != null)
    {
      localObject.x -= paramInsets.left;
      localObject.y -= paramInsets.top;
      localObject.width += paramInsets.left + paramInsets.right;
      localObject.height += paramInsets.top + paramInsets.bottom;
    }
    return localObject;
  }
  
  public static G A(Group paramGroup, Generator paramGenerator)
  {
    Object localObject = null;
    ArrayList localArrayList = new ArrayList(paramGroup.getChildren().size() * 4);
    int i = a.J(paramGroup, "group.children.outcrop");
    Iterator localIterator = paramGroup.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if ((!(localElement instanceof Dummy)) && (!(localElement instanceof Link)))
      {
        Rectangle localRectangle = (Rectangle)paramGenerator.generate(localElement);
        if (localRectangle != null)
        {
          if (i >= 0)
          {
            localRectangle.y = (localRectangle.y + localRectangle.height - i);
            localRectangle.height = i;
          }
          if (localObject == null) {
            localObject = localRectangle;
          } else {
            localObject.add(localRectangle);
          }
          localArrayList.add(new Point(localRectangle.x, localRectangle.y));
          localArrayList.add(new Point(localRectangle.x + localRectangle.width, localRectangle.y));
          localArrayList.add(new Point(localRectangle.x, localRectangle.y + localRectangle.height));
          localArrayList.add(new Point(localRectangle.x + localRectangle.width, localRectangle.y + localRectangle.height));
        }
      }
    }
    return new G(localObject, localArrayList);
  }
  
  public static Rectangle A(Group paramGroup)
  {
    Object localObject = null;
    Iterator localIterator = paramGroup.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if ((!(localElement instanceof Dummy)) && (!(localElement instanceof Link)))
      {
        Rectangle localRectangle = localElement.getBounds();
        if (localRectangle != null) {
          if (localObject == null) {
            localObject = localRectangle;
          } else {
            localObject.add(localRectangle);
          }
        }
      }
    }
    return localObject;
  }
  
  public static Ellipse2D A(G paramG, Insets paramInsets)
  {
    Rectangle localRectangle = paramG.B;
    List localList = paramG.A;
    if (localRectangle == null) {
      return null;
    }
    Ellipse2D localEllipse2D = D.A(localRectangle, localList);
    if (paramInsets != null)
    {
      localRectangle.x -= paramInsets.left;
      localRectangle.y -= paramInsets.top;
      localRectangle.width += paramInsets.left + paramInsets.right;
      localRectangle.height += paramInsets.top + paramInsets.bottom;
    }
    localEllipse2D.setFrame(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height);
    return localEllipse2D;
  }
  
  public static E A(G paramG, int paramInt, Insets paramInsets)
  {
    Rectangle localRectangle = paramG.B;
    List localList = paramG.A;
    if (localRectangle == null) {
      return null;
    }
    localRectangle.grow(0, 1);
    double d = Math.toRadians(paramInt);
    int i = Math.abs((int)(localRectangle.height / Math.tan(d)));
    localRectangle.width += i;
    if (paramInt > 90) {
      localRectangle.x -= i;
    }
    E localE = new E(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, paramInt);
    int j = 3;
    int k;
    int m;
    Point localPoint;
    do
    {
      localRectangle.x += 3;
      localRectangle.width -= 3;
      localE = new E(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, paramInt);
      k = 1;
      for (m = 0; m < localList.size(); m++)
      {
        localPoint = (Point)localList.get(m);
        if (!localE.contains(localPoint.x, localPoint.y))
        {
          k = 0;
          break;
        }
      }
    } while (k != 0);
    localRectangle.x -= 3;
    localRectangle.width += 3;
    do
    {
      localRectangle.width -= 3;
      localE = new E(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, paramInt);
      k = 1;
      for (m = 0; m < localList.size(); m++)
      {
        localPoint = (Point)localList.get(m);
        if (!localE.contains(localPoint.x, localPoint.y))
        {
          k = 0;
          break;
        }
      }
    } while (k != 0);
    localRectangle.width += 3;
    if (paramInsets != null)
    {
      i = (int)(paramInsets.top / Math.tan(d));
      localRectangle.x += i - paramInsets.left;
      localRectangle.width += paramInsets.left + paramInsets.right;
      localRectangle.y -= paramInsets.top;
      localRectangle.height += paramInsets.top + paramInsets.bottom;
    }
    return new E(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, paramInt);
  }
  
  public static Polygon A(G paramG, Insets paramInsets, Group paramGroup)
  {
    Rectangle localRectangle = paramG.B;
    List localList = paramG.A;
    if (localRectangle == null) {
      return null;
    }
    int i = paramGroup.getGroupChamferEdge();
    int j = (int)(i * Math.sin(0.7853981633974483D));
    Polygon localPolygon = D.A(localRectangle, i, null);
    int k = 0;
    int m = 0;
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Point localPoint = (Point)localIterator.next();
      if (!localPolygon.contains(localPoint))
      {
        int n = localPoint.x;
        int i1 = localPoint.y;
        int i2 = n - localRectangle.x;
        if (i2 > j) {
          i2 = localRectangle.width - i2;
        }
        int i3 = localRectangle.y + j - i1;
        int i4;
        if (i3 > 0)
        {
          i4 = i3 - i2;
          if (i4 > k) {
            k = i4;
          }
        }
        else
        {
          i3 = j - (localRectangle.height - j + i3);
          i4 = i3 - i2;
          if (i4 > m) {
            m = i4;
          }
        }
      }
    }
    if (k > 0)
    {
      localRectangle.y -= k;
      localRectangle.height += k;
    }
    if (m > 0) {
      localRectangle.height += m;
    }
    localPolygon = D.A(localRectangle, i, paramInsets);
    return localPolygon;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.i
 * JD-Core Version:    0.7.0.1
 */
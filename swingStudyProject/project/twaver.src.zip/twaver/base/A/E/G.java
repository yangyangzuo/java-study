package twaver.base.A.E;

import java.awt.Rectangle;
import java.util.List;

public class G
{
  public Rectangle B = null;
  public List A = null;
  
  public G(Rectangle paramRectangle, List paramList)
  {
    this.B = paramRectangle;
    this.A = paramList;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.G
 * JD-Core Version:    0.7.0.1
 */
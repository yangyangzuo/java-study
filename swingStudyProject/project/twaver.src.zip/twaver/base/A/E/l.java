package twaver.base.A.E;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.ElementReturnCallbackHandler;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.SendToTopFilter;
import twaver.TDataBox;
import twaver.TSubNetwork;
import twaver.TUIManager;
import twaver.TWaverUtil;
import twaver.base.A.I.B;
import twaver.network.CanvasMarker;
import twaver.network.NetworkElementRenderer;
import twaver.network.TNetwork;
import twaver.network.background.Background;
import twaver.network.ui.Attachment;
import twaver.network.ui.ElementUI;
import twaver.network.ui.LinkUI;

public final class l
{
  public static boolean A = true;
  
  public static Shape A(TNetwork paramTNetwork, String paramString)
  {
    Object localObject = paramTNetwork.getClientProperty(paramString);
    if ((localObject instanceof Shape)) {
      return (Shape)localObject;
    }
    return TUIManager.getShape(paramString);
  }
  
  public static String B(TNetwork paramTNetwork, String paramString)
  {
    Object localObject = paramTNetwork.getClientProperty(paramString);
    if ((localObject instanceof String)) {
      return (String)localObject;
    }
    return TUIManager.getString(paramString);
  }
  
  public static Map C(TNetwork paramTNetwork, String paramString)
  {
    Object localObject = paramTNetwork.getClientProperty(paramString);
    if ((localObject instanceof Map)) {
      return (Map)localObject;
    }
    return TUIManager.getMap(paramString);
  }
  
  public static boolean D(TNetwork paramTNetwork, String paramString)
  {
    Object localObject = paramTNetwork.getClientProperty(paramString);
    if ((localObject instanceof Boolean)) {
      return ((Boolean)localObject).booleanValue();
    }
    return TUIManager.getBoolean(paramString);
  }
  
  public static double E(TNetwork paramTNetwork, String paramString)
  {
    Object localObject = paramTNetwork.getClientProperty(paramString);
    if ((localObject instanceof Double)) {
      return ((Double)localObject).doubleValue();
    }
    return TUIManager.getDouble(paramString);
  }
  
  public static String A(B paramB, Element paramElement)
  {
    Generator localGenerator = paramB.getElementLabelGenerator();
    if (localGenerator == null) {
      return null;
    }
    Object localObject = localGenerator.generate(paramElement);
    return L.A(localObject);
  }
  
  public static boolean A(TNetwork paramTNetwork)
  {
    return Boolean.TRUE.equals(paramTNetwork.getClientProperty("isResizingElement"));
  }
  
  public static void A(TNetwork paramTNetwork, boolean paramBoolean)
  {
    if (paramBoolean) {
      paramTNetwork.putClientProperty("isResizingElement", Boolean.TRUE);
    } else {
      paramTNetwork.putClientProperty("isResizingElement", Boolean.FALSE);
    }
  }
  
  public static boolean F(TNetwork paramTNetwork)
  {
    return Boolean.TRUE.equals(paramTNetwork.getClientProperty("isRectangleSelecting"));
  }
  
  public static void B(TNetwork paramTNetwork, boolean paramBoolean, CanvasMarker paramCanvasMarker)
  {
    if (paramBoolean)
    {
      paramTNetwork.putClientProperty("isRectangleSelecting", Boolean.TRUE);
      paramTNetwork.addCanvasMarker(paramCanvasMarker);
    }
    else
    {
      paramTNetwork.putClientProperty("isRectangleSelecting", Boolean.FALSE);
      paramTNetwork.removeCanvasMarker(paramCanvasMarker);
    }
  }
  
  public static boolean B(TNetwork paramTNetwork)
  {
    return Boolean.TRUE.equals(paramTNetwork.getClientProperty("isDraggingElement"));
  }
  
  public static void A(TNetwork paramTNetwork, boolean paramBoolean, CanvasMarker paramCanvasMarker)
  {
    if (paramBoolean)
    {
      paramTNetwork.putClientProperty("isDraggingElement", Boolean.TRUE);
      paramTNetwork.addCanvasMarker(paramCanvasMarker);
    }
    else
    {
      paramTNetwork.putClientProperty("isDraggingElement", Boolean.FALSE);
      paramTNetwork.removeCanvasMarker(paramCanvasMarker);
    }
  }
  
  public static Dimension D(TNetwork paramTNetwork)
  {
    int i = 0;
    int j = 0;
    Background localBackground = paramTNetwork.getCurrentBackground();
    if (localBackground != null)
    {
      localObject = localBackground.getBackgroundSize();
      if (localObject != null)
      {
        i = i > ((Dimension)localObject).width ? i : ((Dimension)localObject).width;
        j = j > ((Dimension)localObject).height ? j : ((Dimension)localObject).height;
      }
    }
    Object localObject = paramTNetwork.getDataBox().iterator();
    while (((Iterator)localObject).hasNext())
    {
      Element localElement = (Element)((Iterator)localObject).next();
      if (paramTNetwork.isVisible(localElement))
      {
        Rectangle localRectangle = paramTNetwork.getElementBounds(localElement);
        if (localRectangle != null)
        {
          if (i < localRectangle.x + localRectangle.width) {
            i = localRectangle.x + localRectangle.width;
          }
          if (j < localRectangle.y + localRectangle.height) {
            j = localRectangle.y + localRectangle.height;
          }
        }
      }
    }
    return new Dimension(i, j);
  }
  
  public static boolean C(TNetwork paramTNetwork)
  {
    if (!paramTNetwork.isShowing()) {
      return false;
    }
    Dimension localDimension1 = paramTNetwork.getLogicalSize();
    int i = localDimension1.width;
    int j = localDimension1.height;
    double d = paramTNetwork.getZoom();
    i = (int)(i * d);
    j = (int)(j * d);
    Rectangle localRectangle = paramTNetwork.getCanvasScrollPane().getViewport().getViewRect();
    if (i < localRectangle.width) {
      i = localRectangle.width;
    }
    if (j < localRectangle.height) {
      j = localRectangle.height;
    }
    Dimension localDimension2 = new Dimension(i, j);
    paramTNetwork.getCanvas().setPreferredSize(localDimension2);
    paramTNetwork.getCanvasScrollPane().getViewport().setViewSize(localDimension2);
    return true;
  }
  
  public static boolean A(TNetwork paramTNetwork, Element paramElement)
  {
    if (paramElement == null) {
      return false;
    }
    if (!paramTNetwork.isVisible(paramElement)) {
      return false;
    }
    Rectangle localRectangle1 = paramTNetwork.getElementBounds(paramElement);
    if (localRectangle1 == null) {
      return false;
    }
    double d = paramTNetwork.getZoom();
    Rectangle localRectangle2 = new Rectangle((int)(localRectangle1.x * d), (int)(localRectangle1.y * d), (int)(localRectangle1.width * d), (int)(localRectangle1.height * d));
    return C(paramTNetwork, localRectangle2.width + localRectangle2.x, localRectangle2.height + localRectangle2.y);
  }
  
  public static void A(TNetwork paramTNetwork, Point paramPoint)
  {
    double d1 = paramTNetwork.getZoom();
    double d2 = paramPoint.x * d1;
    double d3 = paramPoint.y * d1;
    Rectangle localRectangle = paramTNetwork.getCanvasScrollPane().getViewport().getViewRect();
    d2 -= localRectangle.width / 2;
    d3 -= localRectangle.height / 2;
    if (d2 < 0.0D) {
      d2 = 0.0D;
    }
    if (d3 < 0.0D) {
      d3 = 0.0D;
    }
    double d4 = paramTNetwork.getCanvas().getWidth() - localRectangle.width;
    double d5 = paramTNetwork.getCanvas().getHeight() - localRectangle.height;
    if (d2 > d4) {
      d2 = d4;
    }
    if (d3 > d5) {
      d3 = d5;
    }
    paramTNetwork.getCanvasScrollPane().getViewport().setViewPosition(new Point((int)d2, (int)d3));
  }
  
  public static boolean C(TNetwork paramTNetwork, int paramInt1, int paramInt2)
  {
    int i = paramTNetwork.getCanvas().getWidth();
    int j = paramTNetwork.getCanvas().getHeight();
    boolean bool = false;
    if (i < paramInt1)
    {
      bool = true;
      i = paramInt1;
    }
    if (j < paramInt2)
    {
      bool = true;
      j = paramInt2;
    }
    if (bool)
    {
      Dimension localDimension = new Dimension(i, j);
      paramTNetwork.getCanvas().setPreferredSize(localDimension);
      paramTNetwork.getCanvasScrollPane().getViewport().setViewSize(localDimension);
    }
    return bool;
  }
  
  public static void B(TNetwork paramTNetwork, int paramInt1, int paramInt2)
  {
    JScrollPane localJScrollPane = paramTNetwork.getCanvasScrollPane();
    JViewport localJViewport = localJScrollPane.getViewport();
    int i = localJViewport.getViewPosition().x;
    int j = localJViewport.getViewPosition().y;
    i += paramInt1;
    j += paramInt2;
    i = i >= 0 ? i : 0;
    j = j >= 0 ? j : 0;
    int k = paramTNetwork.getCanvas().getSize().width - localJScrollPane.getViewport().getWidth();
    int m = paramTNetwork.getCanvas().getSize().height - localJScrollPane.getViewport().getHeight();
    i = i < k ? i : k;
    j = j < m ? j : m;
    localJViewport.setViewPosition(new Point(i, j));
  }
  
  public static void D(TNetwork paramTNetwork, Element paramElement)
  {
    if (paramElement == null) {
      return;
    }
    TSubNetwork localTSubNetwork = TWaverUtil.getElementSubNetwork(paramElement);
    if (paramTNetwork.getCurrentSubNetwork() != localTSubNetwork) {
      if (paramTNetwork.isAnimateSubnetworkEnter()) {
        paramTNetwork.animateCurrentSubNetwork(localTSubNetwork);
      } else {
        paramTNetwork.setCurrentSubNetwork(localTSubNetwork);
      }
    }
    Element localElement = paramElement;
    while (((localElement = localElement.getParent()) != null) && (localElement != localTSubNetwork)) {
      if ((localElement instanceof Group)) {
        ((Group)localElement).setExpand(true);
      }
    }
    if (paramTNetwork.isVisible(paramElement)) {
      A(paramTNetwork, paramTNetwork.getElementBounds(paramElement));
    }
  }
  
  public static void A(TNetwork paramTNetwork, Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      return;
    }
    JViewport localJViewport = paramTNetwork.getCanvasScrollPane().getViewport();
    double d1 = localJViewport.getViewPosition().getX();
    double d2 = localJViewport.getViewPosition().getY();
    double d3 = localJViewport.getWidth();
    double d4 = localJViewport.getHeight();
    double d5 = paramTNetwork.getZoom();
    d1 /= d5;
    d2 /= d5;
    d3 /= d5;
    d4 /= d5;
    if (paramRectangle.intersects(new Rectangle((int)d1, (int)d2, (int)d3, (int)d4))) {
      return;
    }
    int i = 1;
    if ((paramRectangle.width > d3) && (paramRectangle.x + paramRectangle.width >= d1) && (paramRectangle.x <= d1 + d3)) {
      i = 0;
    }
    int j = 1;
    if ((paramRectangle.height > d4) && (paramRectangle.y + paramRectangle.height >= d2) && (paramRectangle.y <= d2 + d4)) {
      j = 0;
    }
    double d6 = d1;
    double d7 = d2;
    if (i != 0)
    {
      if (paramRectangle.x + paramRectangle.width > d1 + d3) {
        d6 = paramRectangle.x + paramRectangle.width - d3;
      }
      if ((localJViewport.getX() >= 0) && (paramRectangle.x < d1)) {
        d6 = paramRectangle.x;
      }
    }
    if (j != 0)
    {
      if (paramRectangle.y + paramRectangle.height > d2 + d4) {
        d7 = paramRectangle.y + paramRectangle.height - d4;
      }
      if ((localJViewport.getY() >= 0) && (paramRectangle.y < d2)) {
        d7 = paramRectangle.y;
      }
    }
    d6 = d6 < 0.0D ? 0.0D : d6;
    d7 = d7 < 0.0D ? 0.0D : d7;
    d6 *= d5;
    d7 *= d5;
    Point localPoint = new Point();
    localPoint.x = ((int)(d6 - localJViewport.getViewPosition().getX()));
    localPoint.y = ((int)(d7 - localJViewport.getViewPosition().getY()));
    if ((localPoint.x != 0) || (localPoint.y != 0)) {
      localJViewport.setViewPosition(new Point((int)d6, (int)d7));
    }
  }
  
  public static void A(TNetwork paramTNetwork, JComponent paramJComponent)
  {
    Point localPoint = paramJComponent.getLocation();
    int i = localPoint.x;
    int j = localPoint.y;
    JScrollPane localJScrollPane = paramTNetwork.getCanvasScrollPane();
    JViewport localJViewport1 = localJScrollPane.getViewport();
    JViewport localJViewport2 = localJScrollPane.getColumnHeader();
    JViewport localJViewport3 = localJScrollPane.getRowHeader();
    int k = 0;
    int m = 0;
    if (localJViewport2 != null) {
      k = localJViewport2.getPreferredSize().height;
    }
    if (localJViewport3 != null) {
      m = localJViewport3.getPreferredSize().width;
    }
    int n = localJViewport1.getWidth() - paramJComponent.getWidth() + m;
    int i1 = localJViewport1.getHeight() - paramJComponent.getHeight() + k;
    int i2 = 0;
    int i3 = 0;
    i = i > n ? n : i;
    j = j > i1 ? i1 : j;
    i = i < i2 ? i2 : i;
    j = j < i3 ? i3 : j;
    paramJComponent.setLocation(i, j);
    paramTNetwork.getCanvas().repaint();
  }
  
  public static void E(TNetwork paramTNetwork, Element paramElement)
  {
    if (paramElement == null) {
      return;
    }
    if (!C(paramTNetwork, paramElement)) {
      return;
    }
    for (Element localElement = paramElement; paramTNetwork.isVisible(localElement.getParent()); localElement = localElement.getParent()) {}
    if ((localElement != paramElement) && (C(paramTNetwork, localElement))) {
      E.A(paramTNetwork.getDataBox(), localElement);
    }
    E.A(paramTNetwork.getDataBox(), paramElement);
    B(paramTNetwork, paramElement);
  }
  
  public static void B(TNetwork paramTNetwork, Element paramElement)
  {
    if (V.C(paramElement))
    {
      Rectangle localRectangle1 = paramTNetwork.getElementBounds(paramElement);
      Iterator localIterator = paramTNetwork.getDataBox().iterator(Group.class);
      while (localIterator.hasNext())
      {
        Group localGroup = (Group)localIterator.next();
        Rectangle localRectangle2 = paramTNetwork.getElementBounds(localGroup);
        if ((localGroup != paramElement) && (localRectangle2.intersects(localRectangle1)) && (paramTNetwork.isVisible(localGroup)) && (!localGroup.isParentOf(paramElement)) && (!localGroup.isDescendantOf(paramElement)) && (V.C(localGroup)) && (E.A((Group)paramElement)) && (C(paramTNetwork, localGroup))) {
          E.A(paramTNetwork.getDataBox(), localGroup);
        }
      }
    }
  }
  
  private static boolean C(TNetwork paramTNetwork, Element paramElement)
  {
    if (paramElement == null) {
      return false;
    }
    if (paramTNetwork.getSendToTopFilter() == null) {
      return true;
    }
    return paramTNetwork.getSendToTopFilter().isSendToToppable(paramElement);
  }
  
  public static void E(TNetwork paramTNetwork)
  {
    ArrayList localArrayList = new ArrayList(paramTNetwork.getDataBox().size());
    Iterator localIterator = paramTNetwork.getDataBox().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if ((paramTNetwork.isVisible(localElement)) && (paramTNetwork.isSelectable(localElement))) {
        localArrayList.add(localElement);
      }
    }
    paramTNetwork.getSelectionModel().setSelection(localArrayList);
  }
  
  public static void A(TNetwork paramTNetwork, Rectangle paramRectangle, boolean paramBoolean)
  {
    if (paramRectangle == null) {
      return;
    }
    if ((paramRectangle.width <= 0) || (paramRectangle.height <= 0)) {
      return;
    }
    List localList = B(paramTNetwork, paramRectangle, paramBoolean);
    if ((localList != null) && (localList.size() > 0))
    {
      Object localObject = null;
      Element localElement1 = paramTNetwork.getElementLogicalAt(paramRectangle.x, paramRectangle.y);
      if ((localElement1 != null) && (!(localElement1 instanceof Link)) && (localElement1 == paramTNetwork.getElementLogicalAt(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height))) {
        localObject = localElement1;
      }
      LinkedList localLinkedList1 = new LinkedList();
      LinkedList localLinkedList2 = new LinkedList();
      DataBoxSelectionModel localDataBoxSelectionModel = paramTNetwork.getSelectionModel();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Element localElement2 = (Element)localIterator.next();
        if ((localObject == null) || (localElement2.isDescendantOf(localObject))) {
          if (localDataBoxSelectionModel.contains(localElement2)) {
            localLinkedList2.addFirst(localElement2);
          } else if (paramTNetwork.isSelectable(localElement2)) {
            localLinkedList1.addFirst(localElement2);
          }
        }
      }
      if (localLinkedList1.size() > 0) {
        localDataBoxSelectionModel.appendSelection(localLinkedList1);
      }
      if (localLinkedList2.size() > 0) {
        localDataBoxSelectionModel.removeSelection(localLinkedList2);
      }
    }
  }
  
  public static List B(TNetwork paramTNetwork, Rectangle paramRectangle, boolean paramBoolean)
  {
    if ((paramRectangle == null) || (paramRectangle.width <= 0) || (paramRectangle.height <= 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramTNetwork.getDataBox().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (paramTNetwork.isSelectable(localElement)) {
        if (paramBoolean)
        {
          if (A(paramTNetwork, paramRectangle, localElement)) {
            localArrayList.add(localElement);
          }
        }
        else if (B(paramTNetwork, paramRectangle, localElement)) {
          localArrayList.add(localElement);
        }
      }
    }
    return localArrayList;
  }
  
  public static boolean A(TNetwork paramTNetwork, Rectangle paramRectangle, Element paramElement)
  {
    if (!paramTNetwork.isVisible(paramElement)) {
      return false;
    }
    Object localObject;
    if ((paramElement instanceof Link))
    {
      localObject = (LinkUI)paramTNetwork.getElementUI(paramElement);
      Shape localShape = localObject == null ? null : ((LinkUI)localObject).getContainShape();
      if ((localShape != null) && (localShape.intersects(paramRectangle))) {
        return true;
      }
    }
    else
    {
      localObject = paramTNetwork.getElementBounds(paramElement);
      if ((localObject != null) && (((Rectangle)localObject).intersects(paramRectangle))) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean B(TNetwork paramTNetwork, Rectangle paramRectangle, Element paramElement)
  {
    if (!paramTNetwork.isVisible(paramElement)) {
      return false;
    }
    Rectangle localRectangle = paramTNetwork.getElementBounds(paramElement);
    return (localRectangle != null) && (paramRectangle.contains(localRectangle));
  }
  
  public static Rectangle A(TNetwork paramTNetwork, Iterator paramIterator)
  {
    Object localObject = null;
    while (paramIterator.hasNext())
    {
      Element localElement = (Element)paramIterator.next();
      if (paramTNetwork.isVisible(localElement))
      {
        Rectangle localRectangle = paramTNetwork.getElementBounds(localElement);
        if (localRectangle != null) {
          if (localObject == null) {
            localObject = localRectangle;
          } else {
            localObject.add(localRectangle);
          }
        }
      }
    }
    return localObject;
  }
  
  public static void A(TNetwork paramTNetwork, Point paramPoint1, Point paramPoint2, boolean paramBoolean)
  {
    if ((paramPoint1 == null) || (paramPoint2 == null)) {
      return;
    }
    double d1 = paramTNetwork.getZoom();
    double d2 = paramPoint1.getX() / d1;
    double d3 = paramPoint1.y / d1;
    double d4 = paramPoint2.x / d1;
    double d5 = paramPoint2.y / d1;
    A(paramTNetwork, D.A(d2, d3, d4, d5), paramBoolean);
  }
  
  public static List E(TNetwork paramTNetwork, int paramInt1, int paramInt2)
  {
    ElementReturnCallbackHandler local1 = new ElementReturnCallbackHandler()
    {
      private List A;
      private final int val$x;
      private final int val$y;
      
      public boolean processElement(Element paramAnonymousElement)
      {
        if ((l.this.isVisible(paramAnonymousElement)) && (l.this.isSelectable(paramAnonymousElement)) && (l.this.getRenderer().contains(paramAnonymousElement, this.val$x, this.val$y))) {
          this.A.add(paramAnonymousElement);
        }
        return true;
      }
      
      public Object getReturnValue()
      {
        return this.A;
      }
    };
    paramTNetwork.getDataBox().iteratorByLayer(local1);
    return (List)local1.getReturnValue();
  }
  
  public static Element D(TNetwork paramTNetwork, int paramInt1, int paramInt2)
  {
    List localList = E(paramTNetwork, paramInt1, paramInt2);
    if (localList.isEmpty()) {
      return null;
    }
    Iterator localIterator1 = localList.iterator();
    while (localIterator1.hasNext())
    {
      Element localElement = (Element)localIterator1.next();
      ElementUI localElementUI = paramTNetwork.getElementUI(localElement);
      Iterator localIterator2 = localElementUI.attachments();
      while (localIterator2.hasNext())
      {
        Attachment localAttachment = (Attachment)localIterator2.next();
        if ((localAttachment.isShownOnTop()) && (localAttachment.contains(paramInt1, paramInt2))) {
          return localElement;
        }
      }
    }
    return (Element)localList.get(0);
  }
  
  public static Element A(TNetwork paramTNetwork, int paramInt1, int paramInt2)
  {
    ElementReturnCallbackHandler local2 = new ElementReturnCallbackHandler()
    {
      private Element B;
      private final int val$x;
      private final int val$y;
      
      public boolean processElement(Element paramAnonymousElement)
      {
        if ((paramAnonymousElement.isSelected()) && (l.this.isVisible(paramAnonymousElement)) && (l.this.getRenderer().contains(paramAnonymousElement, this.val$x, this.val$y)))
        {
          this.B = paramAnonymousElement;
          return false;
        }
        return true;
      }
      
      public Object getReturnValue()
      {
        return this.B;
      }
    };
    paramTNetwork.getDataBox().iteratorByLayer(local2);
    return (Element)local2.getReturnValue();
  }
  
  public static void G(TNetwork paramTNetwork)
  {
    new DropTarget(paramTNetwork.getCanvas(), 1073741824, new DropTargetAdapter()
    {
      public void drop(DropTargetDropEvent paramAnonymousDropTargetDropEvent)
      {
        if ((paramAnonymousDropTargetDropEvent.getSourceActions() & 0x1) != 0)
        {
          paramAnonymousDropTargetDropEvent.acceptDrop(1);
        }
        else if ((paramAnonymousDropTargetDropEvent.getSourceActions() & 0x2) != 0)
        {
          paramAnonymousDropTargetDropEvent.acceptDrop(2);
        }
        else
        {
          paramAnonymousDropTargetDropEvent.rejectDrop();
          return;
        }
        try
        {
          if (paramAnonymousDropTargetDropEvent.isDataFlavorSupported(DataFlavor.stringFlavor))
          {
            String str = (String)paramAnonymousDropTargetDropEvent.getTransferable().getTransferData(DataFlavor.stringFlavor);
            if ((str != null) && (str.startsWith("className:")))
            {
              str = str.substring("className:".length());
              l.this.handleDrop(paramAnonymousDropTargetDropEvent, str);
            }
          }
        }
        catch (Exception localException)
        {
          TWaverUtil.handleError(null, localException);
        }
      }
    });
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.l
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import twaver.ElementAttribute;
import twaver.table.CellEditorManager;
import twaver.table.CellRendererManager;
import twaver.table.TPropertySheet;
import twaver.table.TTable;
import twaver.table.TTableColumn;

public final class Y
{
  public static TableColumn A(JTableHeader paramJTableHeader, Point paramPoint)
  {
    if (paramJTableHeader == null) {
      return null;
    }
    int i = paramJTableHeader.columnAtPoint(paramPoint);
    if (i == -1) {
      return null;
    }
    Rectangle localRectangle = paramJTableHeader.getHeaderRect(i);
    localRectangle.grow(-3, 0);
    if (localRectangle.contains(paramPoint)) {
      return null;
    }
    int j = localRectangle.x + localRectangle.width / 2;
    int k;
    if (paramJTableHeader.getComponentOrientation().isLeftToRight()) {
      k = paramPoint.x < j ? i - 1 : i;
    } else {
      k = paramPoint.x < j ? i : i - 1;
    }
    if (k == -1) {
      return null;
    }
    return paramJTableHeader.getColumnModel().getColumn(k);
  }
  
  public static TableColumn A(JTable paramJTable, Point paramPoint)
  {
    if (paramJTable.getTableHeader() == null) {
      return null;
    }
    int i = paramJTable.columnAtPoint(paramPoint);
    if (i == -1) {
      return null;
    }
    int j = paramJTable.rowAtPoint(paramPoint);
    if (j == -1) {
      return null;
    }
    Rectangle localRectangle = paramJTable.getCellRect(j, i, true);
    localRectangle.grow(-3, 0);
    if (localRectangle.contains(paramPoint)) {
      return null;
    }
    int k = localRectangle.x + localRectangle.width / 2;
    int m;
    if (paramJTable.getTableHeader().getComponentOrientation().isLeftToRight()) {
      m = paramPoint.x < k ? i - 1 : i;
    } else {
      m = paramPoint.x < k ? i : i - 1;
    }
    if (m == -1) {
      return null;
    }
    return paramJTable.getTableHeader().getColumnModel().getColumn(m);
  }
  
  public static int B(JTable paramJTable, Point paramPoint)
  {
    int i = paramJTable.rowAtPoint(paramPoint);
    if (i == -1) {
      return -1;
    }
    int j = paramJTable.columnAtPoint(paramPoint);
    if (j == -1) {
      return -1;
    }
    Rectangle localRectangle = paramJTable.getCellRect(i, j, true);
    localRectangle.grow(0, -3);
    if (localRectangle.contains(paramPoint)) {
      return -1;
    }
    int k = localRectangle.y + localRectangle.height / 2;
    int m = paramPoint.y < k ? i - 1 : i;
    return m;
  }
  
  public static void A(JTable paramJTable)
  {
    int i = paramJTable.getRowCount();
    for (int j = 0; j < i; j++)
    {
      int k = A(paramJTable, j);
      if (paramJTable.getRowHeight(j) != k) {
        paramJTable.setRowHeight(j, k);
      }
    }
  }
  
  public static int A(JTable paramJTable, int paramInt)
  {
    int i = paramJTable.getRowHeight();
    int j = paramJTable.getColumnCount();
    for (int k = 0; k < j; k++)
    {
      TableColumn localTableColumn = paramJTable.getColumnModel().getColumn(k);
      int m = -1;
      int n = -1;
      boolean bool = true;
      Object localObject1;
      if ((localTableColumn instanceof TTableColumn))
      {
        localObject1 = (TTableColumn)localTableColumn;
        bool = ((TTableColumn)localObject1).isRowPackParticipable();
        m = ((TTableColumn)localObject1).getMinPackHeight();
        n = ((TTableColumn)localObject1).getMaxPackHeight();
      }
      Object localObject2;
      if ((paramJTable instanceof TPropertySheet))
      {
        localObject1 = (TPropertySheet)paramJTable;
        localObject2 = ((TPropertySheet)localObject1).getElementAttribute(paramInt);
        if (localObject2 != null)
        {
          bool = ((ElementAttribute)localObject2).isRowPackParticipable();
          m = ((ElementAttribute)localObject2).getMinPackHeight();
          n = ((ElementAttribute)localObject2).getMaxPackHeight();
        }
      }
      if (bool)
      {
        localObject1 = paramJTable.getCellRenderer(paramInt, k);
        localObject2 = paramJTable.prepareRenderer((TableCellRenderer)localObject1, paramInt, k);
        ((Component)localObject2).setSize(localTableColumn.getWidth(), 10000);
        int i1 = ((Component)localObject2).getPreferredSize().height;
        if ((n > 0) && (n < i1)) {
          i1 = n;
        }
        if ((m > 0) && (m > i1)) {
          i1 = m;
        }
        if (i1 > i) {
          i = i1;
        }
      }
    }
    return i;
  }
  
  public static int A(JTable paramJTable, TableColumn paramTableColumn, boolean paramBoolean, int paramInt)
  {
    if ((paramJTable == null) || (paramTableColumn == null)) {
      return -1;
    }
    int i = paramTableColumn.getModelIndex();
    if (i < 0) {
      return -1;
    }
    int j = paramJTable.convertColumnIndexToView(i);
    if (j < 0) {
      return -1;
    }
    int k = paramJTable.getRowCount();
    int m = 0;
    Object localObject = null;
    TableCellRenderer localTableCellRenderer = null;
    Component localComponent = null;
    if ((paramBoolean) && (paramJTable.getTableHeader() != null))
    {
      localObject = paramTableColumn.getIdentifier();
      localTableCellRenderer = paramJTable.getTableHeader().getDefaultRenderer();
      localComponent = localTableCellRenderer.getTableCellRendererComponent(paramJTable, localObject, false, false, -1, j);
      m = localComponent.getPreferredSize().width;
    }
    for (int n = 0; n < k; n++)
    {
      localObject = paramJTable.getValueAt(n, j);
      localTableCellRenderer = paramJTable.getCellRenderer(n, j);
      localComponent = localTableCellRenderer.getTableCellRendererComponent(paramJTable, localObject, false, false, n, j);
      int i1 = localComponent.getPreferredSize().width;
      m = Math.max(m, i1);
    }
    if (paramInt < 0) {
      paramInt = 8;
    }
    return m + paramJTable.getIntercellSpacing().width + paramInt;
  }
  
  public static void B(JTable paramJTable, TableColumn paramTableColumn, boolean paramBoolean, int paramInt)
  {
    int i = A(paramJTable, paramTableColumn, paramBoolean, paramInt);
    if (i > 0)
    {
      if (paramJTable.getTableHeader() != null) {
        paramJTable.getTableHeader().setResizingColumn(paramTableColumn);
      }
      paramTableColumn.setWidth(i);
    }
  }
  
  public static void A(JTable paramJTable, boolean paramBoolean, int paramInt)
  {
    TableColumnModel localTableColumnModel = paramJTable.getColumnModel();
    int i = localTableColumnModel.getColumnCount();
    int[] arrayOfInt = new int[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      localObject = localTableColumnModel.getColumn(k);
      int m = A(paramJTable, (TableColumn)localObject, paramBoolean, paramInt);
      if ((localObject instanceof TTableColumn))
      {
        TTableColumn localTTableColumn = (TTableColumn)localObject;
        if ((localTTableColumn.getMinPackWidth() > 0) && (m < localTTableColumn.getMinPackWidth())) {
          m = localTTableColumn.getMinPackWidth();
        }
        if ((localTTableColumn.getMaxPackWidth() > 0) && (m > localTTableColumn.getMaxPackWidth())) {
          m = localTTableColumn.getMaxPackWidth();
        }
      }
      arrayOfInt[k] = m;
      j += arrayOfInt[k];
    }
    k = 0;
    Object localObject = paramJTable.getParent();
    if ((localObject instanceof JViewport)) {
      k = ((JViewport)localObject).getWidth() - j;
    } else if (localObject == null) {
      k = paramJTable.getPreferredScrollableViewportSize().width - j;
    } else {
      k = ((Container)localObject).getWidth() - j;
    }
    if (k > 0)
    {
      ArrayList localArrayList = new ArrayList();
      for (int i1 = 0; i1 < i; i1++)
      {
        TableColumn localTableColumn2 = localTableColumnModel.getColumn(i1);
        if ((!(localTableColumn2 instanceof TTableColumn)) || (((TTableColumn)localTableColumn2).isExtraWidthAssignable())) {
          localArrayList.add(new Integer(i1));
        }
      }
      if (localArrayList.size() > 0)
      {
        i1 = Math.max(k / localArrayList.size(), 1);
        for (int i2 = 0; i2 < localArrayList.size(); i2++)
        {
          int i3 = ((Integer)localArrayList.get(i2)).intValue();
          if (i2 == localArrayList.size() - 1)
          {
            arrayOfInt[i3] += k;
          }
          else
          {
            arrayOfInt[i3] += i1;
            k -= i1;
          }
        }
      }
    }
    for (int n = 0; n < i; n++)
    {
      TableColumn localTableColumn1 = localTableColumnModel.getColumn(n);
      if (paramJTable.getTableHeader() != null) {
        paramJTable.getTableHeader().setResizingColumn(localTableColumn1);
      }
      localTableColumn1.setWidth(arrayOfInt[n]);
      if (paramJTable.getTableHeader() != null) {
        paramJTable.getTableHeader().setResizingColumn(null);
      }
    }
  }
  
  public static TableCellRenderer B(TTable paramTTable, int paramInt1, int paramInt2)
  {
    TTableColumn localTTableColumn = (TTableColumn)paramTTable.getColumnModel().getColumn(paramInt2);
    TableCellRenderer localTableCellRenderer = localTTableColumn.getCellRenderer();
    if ((localTableCellRenderer == null) && (localTTableColumn.getJavaClass() != null)) {
      localTableCellRenderer = paramTTable.getCellRendererManager().findRenderer(localTTableColumn.getJavaClass());
    }
    if (localTableCellRenderer == null)
    {
      Object localObject = paramTTable.getValueAt(paramInt1, paramInt2);
      if (localObject != null) {
        localTableCellRenderer = paramTTable.getCellRendererManager().findRenderer(localObject.getClass());
      }
    }
    if (localTableCellRenderer == null) {
      localTableCellRenderer = paramTTable.getDefaultRenderer(paramTTable.getColumnClass(paramInt2));
    }
    return localTableCellRenderer;
  }
  
  public static TableCellEditor A(TTable paramTTable, int paramInt1, int paramInt2)
  {
    TTableColumn localTTableColumn = (TTableColumn)paramTTable.getColumnModel().getColumn(paramInt2);
    TableCellEditor localTableCellEditor = localTTableColumn.getCellEditor();
    if ((localTableCellEditor == null) && (localTTableColumn.getJavaClass() != null)) {
      localTableCellEditor = paramTTable.getCellEditorManager().findEditor(localTTableColumn.getJavaClass());
    }
    if (localTableCellEditor == null)
    {
      Object localObject = paramTTable.getValueAt(paramInt1, paramInt2);
      if (localObject != null) {
        localTableCellEditor = paramTTable.getCellEditorManager().findEditor(localObject.getClass());
      }
    }
    if (localTableCellEditor == null) {
      localTableCellEditor = paramTTable.getDefaultEditor(paramTTable.getColumnClass(paramInt2));
    }
    return localTableCellEditor;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.Y
 * JD-Core Version:    0.7.0.1
 */
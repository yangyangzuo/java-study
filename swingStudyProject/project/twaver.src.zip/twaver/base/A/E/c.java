package twaver.base.A.E;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.RenderingHints.Key;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.LineMetrics;
import java.awt.geom.Ellipse2D.Float;
import java.awt.geom.Line2D.Double;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.base.A.A.A;
import twaver.base.A.D.O;

public final class c
{
  private static final Map B = new HashMap();
  private static Map A = new LinkedHashMap();
  
  static
  {
    A(1);
    A(2);
    A(3);
    A(4);
    A(5);
    A(6);
    A(7);
    A(8);
    A(10);
    A(11);
    A(12);
    A(13);
    A(14);
    A(15);
    A(16);
    A(17);
    A(18);
    A(19);
    A(20);
    A(21);
    A(22);
    A(23);
    A(24);
    A(25);
    A(26);
  }
  
  private static void A(int paramInt)
  {
    A.put(TWaverUtil.valueOf(paramInt), new O()
    {
      private final int val$type;
      
      public Paint A(Rectangle paramAnonymousRectangle, Color paramAnonymousColor1, Color paramAnonymousColor2)
      {
        return c.A(this.val$type, paramAnonymousRectangle, paramAnonymousColor1, paramAnonymousColor2);
      }
    });
  }
  
  public static O E(int paramInt)
  {
    return (O)A.get(TWaverUtil.valueOf(paramInt));
  }
  
  public static Paint A(int paramInt, Rectangle paramRectangle, Color paramColor1, Color paramColor2)
  {
    if (paramInt == 1) {
      return A(paramRectangle, paramColor1, paramColor2, -0.5D, 0.5D, 0.5D, -0.5D);
    }
    if (paramInt == 2) {
      return A(paramRectangle, paramColor1, paramColor2, 0.5D, 0.5D, -0.5D, -0.5D);
    }
    if (paramInt == 3) {
      return A(paramRectangle, paramColor1, paramColor2, -0.5D, -0.5D, 0.5D, 0.5D);
    }
    if (paramInt == 4) {
      return A(paramRectangle, paramColor1, paramColor2, 0.5D, -0.5D, -0.5D, 0.5D);
    }
    if (paramInt == 5) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, -0.5D, 0.0D, 0.5D);
    }
    if (paramInt == 6) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.5D, 0.0D, -0.5D);
    }
    if (paramInt == 7) {
      return A(paramRectangle, paramColor1, paramColor2, -0.5D, 0.0D, 0.5D, 0.0D);
    }
    if (paramInt == 8) {
      return A(paramRectangle, paramColor1, paramColor2, 0.5D, 0.0D, -0.5D, 0.0D);
    }
    if (paramInt == 10) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.0D, 0.5D);
    }
    if (paramInt == 11) {
      return A(paramRectangle, paramColor1, paramColor2, -0.25D, 0.25D);
    }
    if (paramInt == 12) {
      return A(paramRectangle, paramColor1, paramColor2, 0.25D, 0.25D);
    }
    if (paramInt == 13) {
      return A(paramRectangle, paramColor1, paramColor2, -0.25D, -0.25D);
    }
    if (paramInt == 14) {
      return A(paramRectangle, paramColor1, paramColor2, 0.25D, -0.25D);
    }
    if (paramInt == 15) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, -0.25D);
    }
    if (paramInt == 16) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.25D);
    }
    if (paramInt == 17) {
      return A(paramRectangle, paramColor1, paramColor2, -0.25D, 0.0D);
    }
    if (paramInt == 18) {
      return A(paramRectangle, paramColor1, paramColor2, 0.25D, 0.0D);
    }
    if (paramInt == 19) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.0D, 0.5D, 0.0D);
    }
    if (paramInt == 20) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.0D, 0.0D, 0.5D);
    }
    if (paramInt == 21) {
      return A(paramRectangle, paramColor1, paramColor2, false);
    }
    if (paramInt == 22) {
      return A(paramRectangle, paramColor1, paramColor2, true);
    }
    if (paramInt == 23) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, -0.25D, 0.0D, 0.25D);
    }
    if (paramInt == 24) {
      return A(paramRectangle, paramColor1, paramColor2, 0.0D, 0.25D, 0.0D, -0.25D);
    }
    if (paramInt == 25) {
      return A(paramRectangle, paramColor1, paramColor2, -0.25D, 0.0D, 0.25D, 0.0D);
    }
    if (paramInt == 26) {
      return A(paramRectangle, paramColor1, paramColor2, 0.25D, 0.0D, -0.25D, 0.0D);
    }
    return null;
  }
  
  private static Paint A(Rectangle paramRectangle, Color paramColor1, Color paramColor2, boolean paramBoolean)
  {
    double d1 = paramRectangle.getWidth();
    double d2 = paramRectangle.getHeight();
    double d3 = Math.sqrt(d1 * d1 + d2 * d2);
    double d4 = d1 / d3 * d2;
    double d5 = d2 / d3 * d4;
    double d6 = d1 / d3 * d4;
    if (paramBoolean) {
      return new GradientPaint((float)(paramRectangle.getX() + d5), (float)(paramRectangle.getY() + d6), paramColor1, (float)paramRectangle.getX(), (float)paramRectangle.getY(), paramColor2, true);
    }
    return new GradientPaint((float)(paramRectangle.getX() + paramRectangle.getWidth() - d5), (float)(paramRectangle.getY() + d6), paramColor1, (float)(paramRectangle.getX() + paramRectangle.getWidth()), (float)paramRectangle.getY(), paramColor2, true);
  }
  
  private static Paint A(Rectangle paramRectangle, Color paramColor1, Color paramColor2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    return new GradientPaint((float)(paramRectangle.getCenterX() + paramDouble1 * paramRectangle.getWidth()), (float)(paramRectangle.getCenterY() + paramDouble2 * paramRectangle.getHeight()), paramColor1, (float)(paramRectangle.getCenterX() + paramDouble3 * paramRectangle.getWidth()), (float)(paramRectangle.getCenterY() + paramDouble4 * paramRectangle.getHeight()), paramColor2, true);
  }
  
  private static Paint A(Rectangle paramRectangle, Color paramColor1, Color paramColor2, double paramDouble1, double paramDouble2)
  {
    return A(paramRectangle, paramColor1, paramColor2, paramDouble1, paramDouble2, 0.25D);
  }
  
  private static Paint A(Rectangle paramRectangle, Color paramColor1, Color paramColor2, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    Point2D.Double localDouble = new Point2D.Double(paramRectangle.getWidth() * paramDouble3, paramRectangle.getHeight() * paramDouble3);
    return new A(paramRectangle.getCenterX() + paramDouble1 * paramRectangle.getWidth(), paramRectangle.getCenterY() + paramDouble2 * paramRectangle.getHeight(), paramColor1, localDouble, paramColor2);
  }
  
  public static void A(Graphics2D paramGraphics2D, Point paramPoint1, Point paramPoint2, double paramDouble)
  {
    Rectangle localRectangle = D.A(paramPoint1, paramPoint2);
    if (localRectangle != null)
    {
      int i = (int)(localRectangle.x / paramDouble);
      int j = (int)(localRectangle.y / paramDouble);
      int k = (int)(localRectangle.width / paramDouble);
      int m = (int)(localRectangle.height / paramDouble);
      Object localObject = null;
      if ((m == 0) || (k == 0)) {
        localObject = new Line2D.Double(i, j, i + k, j + m);
      } else {
        localObject = new Ellipse2D.Float(i, j, k, m);
      }
      A(paramGraphics2D, (Shape)localObject);
    }
  }
  
  public static void A(Graphics2D paramGraphics2D, Shape paramShape)
  {
    if (paramShape != null)
    {
      Color localColor = paramGraphics2D.getColor();
      Stroke localStroke = paramGraphics2D.getStroke();
      paramGraphics2D.setStroke(TWaverConst.DASHED_STROKE);
      paramGraphics2D.setXORMode(Color.WHITE);
      paramGraphics2D.setColor(Color.BLACK);
      paramGraphics2D.draw(paramShape);
      paramGraphics2D.setPaintMode();
      paramGraphics2D.setStroke(localStroke);
      paramGraphics2D.setColor(localColor);
    }
  }
  
  public static void B(Graphics2D paramGraphics2D, Shape paramShape)
  {
    if (paramShape != null)
    {
      Color localColor = paramGraphics2D.getColor();
      Stroke localStroke = paramGraphics2D.getStroke();
      paramGraphics2D.setStroke(TWaverConst.THINNEST_STROKE);
      paramGraphics2D.setColor(Color.WHITE);
      paramGraphics2D.fill(paramShape);
      paramGraphics2D.setColor(Color.BLACK);
      paramGraphics2D.draw(paramShape);
      paramGraphics2D.setStroke(localStroke);
      paramGraphics2D.setColor(localColor);
    }
  }
  
  public static void C(Graphics2D paramGraphics2D, Point paramPoint1, Point paramPoint2, double paramDouble)
  {
    if ((paramPoint1 != null) && (paramPoint2 != null))
    {
      double d1 = paramPoint1.x / paramDouble;
      double d2 = paramPoint1.y / paramDouble;
      double d3 = paramPoint2.x / paramDouble;
      double d4 = paramPoint2.y / paramDouble;
      Line2D.Double localDouble = new Line2D.Double(d1, d2, d3, d4);
      A(paramGraphics2D, localDouble);
    }
  }
  
  public static void A(Graphics2D paramGraphics2D, Rectangle paramRectangle, double paramDouble)
  {
    if (paramRectangle != null)
    {
      int i = (int)(paramRectangle.x / paramDouble);
      int j = (int)(paramRectangle.y / paramDouble);
      int k = (int)(paramRectangle.width / paramDouble);
      int m = (int)(paramRectangle.height / paramDouble);
      Object localObject = null;
      if ((m == 0) || (k == 0)) {
        localObject = new Line2D.Double(i, j, i + k, j + m);
      } else {
        localObject = new Rectangle(i, j, k, m);
      }
      A(paramGraphics2D, (Shape)localObject);
    }
  }
  
  public static void B(Graphics2D paramGraphics2D, Point paramPoint1, Point paramPoint2, double paramDouble)
  {
    Rectangle localRectangle = D.A(paramPoint1, paramPoint2);
    A(paramGraphics2D, localRectangle, paramDouble);
  }
  
  public static BasicStroke B(int paramInt)
  {
    if (paramInt < 0) {
      paramInt = 0;
    }
    Integer localInteger = TWaverUtil.valueOf(paramInt);
    BasicStroke localBasicStroke = (BasicStroke)B.get(localInteger);
    if (localBasicStroke == null)
    {
      localBasicStroke = new BasicStroke(paramInt, 0, 1);
      B.put(localInteger, localBasicStroke);
    }
    return localBasicStroke;
  }
  
  public static Stroke A(int paramInt, Stroke paramStroke)
  {
    Object localObject;
    if ((paramStroke instanceof BasicStroke))
    {
      localObject = (BasicStroke)paramStroke;
      return new BasicStroke(paramInt, ((BasicStroke)localObject).getEndCap(), ((BasicStroke)localObject).getLineJoin(), ((BasicStroke)localObject).getMiterLimit(), ((BasicStroke)localObject).getDashArray(), ((BasicStroke)localObject).getDashPhase());
    }
    if ((paramStroke instanceof twaver.base.A.D.F.D))
    {
      localObject = (twaver.base.A.D.F.D)paramStroke;
      Stroke localStroke = A(paramInt, ((twaver.base.A.D.F.D)localObject).C());
      return new twaver.base.A.D.F.D(localStroke, ((twaver.base.A.D.F.D)localObject).A(), ((twaver.base.A.D.F.D)localObject).B());
    }
    return paramStroke;
  }
  
  public static BasicStroke D(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 1;
    }
    float f = paramInt * 2;
    f = f > 4.0F ? f : 4.0F;
    return new BasicStroke(paramInt, 0, 1, 0.0F, new float[] { f }, 0.0F);
  }
  
  public static BasicStroke C(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 1;
    }
    return new BasicStroke(paramInt, 1, 1, 0.0F, new float[] { paramInt, paramInt + 2 }, 0.0F);
  }
  
  public static void A(String paramString, Graphics2D paramGraphics2D, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    paramGraphics2D.translate(paramDouble1, paramDouble2);
    paramGraphics2D.rotate(paramDouble3);
    paramGraphics2D.drawString(paramString, 0, 0);
    paramGraphics2D.rotate(-paramDouble3);
    paramGraphics2D.translate(-paramDouble1, -paramDouble2);
  }
  
  public static Dimension A(String paramString, Font paramFont, Graphics2D paramGraphics2D)
  {
    Font localFont = paramGraphics2D.getFont();
    paramGraphics2D.setFont(paramFont);
    FontRenderContext localFontRenderContext = paramGraphics2D.getFontRenderContext();
    int i = (int)paramFont.getStringBounds(paramString, localFontRenderContext).getWidth();
    int j = (int)paramFont.getStringBounds(paramString, localFontRenderContext).getHeight();
    paramGraphics2D.setFont(localFont);
    return new Dimension(i, j);
  }
  
  public static int B(String paramString, Font paramFont, Graphics2D paramGraphics2D)
  {
    Font localFont = paramGraphics2D.getFont();
    paramGraphics2D.setFont(paramFont);
    FontRenderContext localFontRenderContext = paramGraphics2D.getFontRenderContext();
    int i = (int)paramFont.getStringBounds(paramString, localFontRenderContext).getHeight();
    LineMetrics localLineMetrics = paramFont.getLineMetrics(paramString, localFontRenderContext);
    int j = (int)localLineMetrics.getDescent();
    paramGraphics2D.setFont(localFont);
    return i - j;
  }
  
  public static Rectangle A(String paramString, Font paramFont)
  {
    FontRenderContext localFontRenderContext = new FontRenderContext(null, true, true);
    GlyphVector localGlyphVector = paramFont.createGlyphVector(localFontRenderContext, paramString);
    return localGlyphVector.getLogicalBounds().getBounds();
  }
  
  public static ImageIcon A(int paramInt1, int paramInt2, Paint paramPaint, Color paramColor, int paramInt3)
  {
    BufferedImage localBufferedImage = new BufferedImage(paramInt1, paramInt2, 2);
    Rectangle localRectangle = new Rectangle(0, 0, paramInt1 - 1, paramInt2 - 1);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    Shape localShape = K.B(paramInt3, localRectangle);
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    if (paramPaint != null)
    {
      localGraphics2D.setPaint(paramPaint);
      localGraphics2D.fill(localShape);
    }
    if (paramColor != null)
    {
      localGraphics2D.setColor(paramColor);
      localGraphics2D.draw(localShape);
    }
    localGraphics2D.dispose();
    return new ImageIcon(localBufferedImage);
  }
  
  public static ImageIcon A(int paramInt1, int paramInt2, Color paramColor1, Color paramColor2, Color paramColor3, int paramInt3, int paramInt4)
  {
    BufferedImage localBufferedImage = new BufferedImage(paramInt1, paramInt2, 2);
    Rectangle localRectangle = new Rectangle(0, 0, paramInt1 - 1, paramInt2 - 1);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    A(paramColor1, paramColor2, paramColor3, paramInt3, paramInt4, localRectangle, localGraphics2D);
    localGraphics2D.dispose();
    return new ImageIcon(localBufferedImage);
  }
  
  public static void A(Color paramColor1, Color paramColor2, Color paramColor3, int paramInt1, int paramInt2, Rectangle paramRectangle, Graphics2D paramGraphics2D)
  {
    Shape localShape = K.B(paramInt1, paramRectangle);
    paramGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    if (paramColor2 != null)
    {
      if (paramInt2 > 0) {
        paramGraphics2D.setPaint(A(paramInt2, paramRectangle, paramColor1, paramColor2));
      } else {
        paramGraphics2D.setColor(paramColor2);
      }
      paramGraphics2D.fill(localShape);
    }
    paramGraphics2D.setStroke(TWaverConst.BASIC_STROKE);
    if (paramColor3 != null)
    {
      paramGraphics2D.setColor(paramColor3);
      paramGraphics2D.draw(localShape);
    }
  }
  
  public static Icon A()
  {
    return A(Color.BLACK, 12, 5);
  }
  
  public static Icon A(Color paramColor, int paramInt1, int paramInt2)
  {
    new Icon()
    {
      private final int val$width;
      private final int val$height;
      
      public void paintIcon(Component paramAnonymousComponent, Graphics paramAnonymousGraphics, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        int i = getIconWidth() - 2;
        paramAnonymousGraphics.translate(paramAnonymousInt1, paramAnonymousInt2);
        paramAnonymousGraphics.setColor(c.this);
        paramAnonymousGraphics.drawLine(0, 0, i - 1, 0);
        paramAnonymousGraphics.drawLine(1, 1, 1 + (i - 3), 1);
        paramAnonymousGraphics.drawLine(2, 2, 2 + (i - 5), 2);
        paramAnonymousGraphics.drawLine(3, 3, 3 + (i - 7), 3);
        paramAnonymousGraphics.drawLine(4, 4, 4 + (i - 9), 4);
        paramAnonymousGraphics.translate(-paramAnonymousInt1, -paramAnonymousInt2);
      }
      
      public int getIconWidth()
      {
        return this.val$width;
      }
      
      public int getIconHeight()
      {
        return this.val$height;
      }
    };
  }
  
  public static boolean A(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    Iterator localIterator = ImageIO.getImageWritersBySuffix(paramString);
    return (localIterator != null) && (localIterator.hasNext());
  }
  
  public static void B(Graphics paramGraphics, Shape paramShape)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    RenderingHints.Key localKey = RenderingHints.KEY_ANTIALIASING;
    Object localObject = localGraphics2D.getRenderingHint(localKey);
    localGraphics2D.setRenderingHint(localKey, RenderingHints.VALUE_ANTIALIAS_ON);
    localGraphics2D.fill(paramShape);
    localGraphics2D.setRenderingHint(localKey, localObject);
  }
  
  public static void A(Graphics paramGraphics, Shape paramShape)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    RenderingHints.Key localKey = RenderingHints.KEY_ANTIALIASING;
    Object localObject = localGraphics2D.getRenderingHint(localKey);
    localGraphics2D.setRenderingHint(localKey, RenderingHints.VALUE_ANTIALIAS_ON);
    localGraphics2D.draw(paramShape);
    localGraphics2D.setRenderingHint(localKey, localObject);
  }
  
  public static TexturePaint A(Image paramImage)
  {
    if (paramImage == null) {
      return null;
    }
    BufferedImage localBufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    Rectangle localRectangle;
    try
    {
      localGraphics2D.drawImage(paramImage, 0, 0, null);
    }
    finally
    {
      localGraphics2D.dispose();
      ret;
    }
    TexturePaint localTexturePaint = new TexturePaint(localBufferedImage, localRectangle);
    return localTexturePaint;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.c
 * JD-Core Version:    0.7.0.1
 */
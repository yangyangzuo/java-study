package twaver.base.A.E;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import twaver.base.A.D.D.A;
import twaver.base.A.D.D.C;
import twaver.base.A.D.D.D;

public class B
{
  private static Map A = new LinkedHashMap();
  
  static
  {
    A.put("stipple.loose", A.O);
    A.put("stipple.middle", A.M);
    A.put("stipple.dense", A.N);
    A.put("grid.diamond", D.L);
    A.put("grid.square", D.K);
    A.put("grid.triangle", D.J);
    A.put("line.cross", twaver.base.A.D.D.B.H);
    A.put("line.vertical", twaver.base.A.D.D.B.G);
    A.put("line.horizontal", twaver.base.A.D.D.B.E);
    A.put("line.diagonal", twaver.base.A.D.D.B.D);
    A.put("line.antidiagonal", twaver.base.A.D.D.B.F);
  }
  
  public static C A(String paramString)
  {
    return (C)A.get(paramString);
  }
  
  public static Iterator A()
  {
    return A.keySet().iterator();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.B
 * JD-Core Version:    0.7.0.1
 */
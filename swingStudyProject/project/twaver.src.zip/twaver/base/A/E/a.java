package twaver.base.A.E;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Stroke;
import java.beans.PropertyChangeEvent;
import java.text.NumberFormat;
import java.util.List;
import javax.swing.Icon;
import twaver.Element;
import twaver.FloatInsets;
import twaver.TUIManager;
import twaver.TWaverUtil;
import twaver.base.A.D.O;
import twaver.base.Direction;

public final class a
{
  private static o D = new o();
  private static o B = new o();
  private static o A = new o();
  private static o C = new o();
  
  static
  {
    D.B("shapeLinkType");
    D.B("fromAgent");
    D.B("toAgent");
    D.B("linkType");
    D.B("points");
    D.B("segment");
    D.B("blinkingObject");
    D.A("link.outline.width");
    D.A("link.width");
    D.A("link.flowing.width");
    D.A("link.bundle.expand");
    D.A("link.bundle.index");
    D.A("link.bundle.size");
    D.A("link.orthogonal.direction");
    D.A("link.3d");
    D.A("link.to.position");
    D.A("link.to.xoffset");
    D.A("link.to.yoffset");
    D.A("link.from.position");
    D.A("link.from.xoffset");
    D.A("link.from.yoffset");
    D.A("link.style");
    D.A("link.extend");
    D.A("link.proportion");
    B.B("groupModelShape");
    B.B("groupType");
    B.B("expand");
    B.A("custom.draw.shape.factory");
    B.A("group.angle");
    B.A("group.3d");
    B.A("group.deep");
    B.A("group.insets");
    B.A("group.children.outcrop");
    B.A("group.chamfer.edge");
    A.B("groupUIShape");
    A.B("location");
    A.B("width");
    A.B("height");
    A.B("image");
    A.B("points");
    A.A("shapenode.joint.point");
    C.B("size");
    C.B("location");
    C.B("equipCount");
    C.A("equip.direction");
    C.A("slot.border");
    C.A("slot.inner.border");
  }
  
  public static boolean A(String paramString, PropertyChangeEvent paramPropertyChangeEvent)
  {
    if (D.containsKey(paramString)) {
      return true;
    }
    if ("shapeFrozen".equals(paramString)) {
      return Boolean.FALSE.equals(paramPropertyChangeEvent.getNewValue());
    }
    return false;
  }
  
  public static boolean C(String paramString)
  {
    return C.containsKey(paramString);
  }
  
  public static boolean B(String paramString)
  {
    return B.containsKey(paramString);
  }
  
  public static boolean A(String paramString)
  {
    return A.containsKey(paramString);
  }
  
  public static O I(Element paramElement, String paramString)
  {
    int i = J(paramElement, paramString);
    return c.E(i);
  }
  
  public static twaver.base.A.D.K H(Element paramElement, String paramString)
  {
    int i = J(paramElement, paramString);
    return K.B(i);
  }
  
  public static int J(Element paramElement, String paramString)
  {
    Integer localInteger = (Integer)A(paramElement, paramString, Integer.class);
    if (localInteger != null) {
      return localInteger.intValue();
    }
    return TUIManager.getInt(paramString);
  }
  
  public static Icon A(Element paramElement, String paramString)
  {
    Icon localIcon = (Icon)A(paramElement, paramString, Icon.class);
    if (localIcon != null) {
      return localIcon;
    }
    return TUIManager.getIcon(paramString);
  }
  
  public static boolean K(Element paramElement, String paramString)
  {
    Boolean localBoolean = (Boolean)A(paramElement, paramString, Boolean.class);
    if (localBoolean != null) {
      return localBoolean.booleanValue();
    }
    return TUIManager.getBoolean(paramString);
  }
  
  public static NumberFormat G(Element paramElement, String paramString)
  {
    NumberFormat localNumberFormat = (NumberFormat)A(paramElement, paramString, NumberFormat.class);
    if (localNumberFormat != null) {
      return localNumberFormat;
    }
    return TUIManager.getNumberFormat(paramString);
  }
  
  public static List L(Element paramElement, String paramString)
  {
    List localList = (List)A(paramElement, paramString, List.class);
    if (localList != null) {
      return localList;
    }
    return TUIManager.getList(paramString);
  }
  
  public static Color P(Element paramElement, String paramString)
  {
    Color localColor = (Color)A(paramElement, paramString, Color.class);
    if (localColor != null) {
      return localColor;
    }
    return TUIManager.getColor(paramString);
  }
  
  public static Insets B(Element paramElement, String paramString)
  {
    Insets localInsets = (Insets)A(paramElement, paramString, Insets.class);
    if (localInsets != null) {
      return localInsets;
    }
    return TUIManager.getInsets(paramString);
  }
  
  public static FloatInsets N(Element paramElement, String paramString)
  {
    FloatInsets localFloatInsets = (FloatInsets)A(paramElement, paramString, FloatInsets.class);
    if (localFloatInsets != null) {
      return localFloatInsets;
    }
    return TUIManager.getFloatInsets(paramString);
  }
  
  public static double M(Element paramElement, String paramString)
  {
    Double localDouble = (Double)A(paramElement, paramString, Double.class);
    if (localDouble != null) {
      return localDouble.doubleValue();
    }
    return TUIManager.getDouble(paramString);
  }
  
  public static float O(Element paramElement, String paramString)
  {
    Float localFloat = (Float)A(paramElement, paramString, Float.class);
    if (localFloat != null) {
      return localFloat.floatValue();
    }
    return TUIManager.getFloat(paramString);
  }
  
  public static Font D(Element paramElement, String paramString)
  {
    Font localFont = (Font)A(paramElement, paramString, Font.class);
    if (localFont != null) {
      return localFont;
    }
    return TUIManager.getFont(paramString);
  }
  
  public static Stroke F(Element paramElement, String paramString)
  {
    Object localObject = paramElement.getClientProperty(paramString);
    if ((localObject instanceof Stroke)) {
      return (Stroke)localObject;
    }
    if ((localObject instanceof String))
    {
      Stroke localStroke = TUIManager.getStrokeByType((String)localObject);
      if (localStroke != null) {
        return localStroke;
      }
    }
    if ((localObject instanceof Integer)) {
      return TWaverUtil.createStroke(((Integer)localObject).intValue());
    }
    return TUIManager.getStroke(paramString);
  }
  
  public static Direction E(Element paramElement, String paramString)
  {
    Direction localDirection = (Direction)A(paramElement, paramString, Direction.class);
    if (localDirection != null) {
      return localDirection;
    }
    return TUIManager.getDirection(paramString);
  }
  
  public static String Q(Element paramElement, String paramString)
  {
    String str = (String)A(paramElement, paramString, String.class);
    if (str != null) {
      return str;
    }
    return TUIManager.getString(paramString);
  }
  
  private static Object A(Element paramElement, String paramString, Class paramClass)
  {
    Object localObject = paramElement.getClientProperty(paramString);
    if ((localObject != null) && (!paramClass.isAssignableFrom(localObject.getClass())))
    {
      TWaverUtil.handleError("\nValue with client property key '" + paramString + "' should be instance of " + paramClass + "\nactually the value is: " + localObject + ", an instance of " + localObject.getClass(), null);
      return null;
    }
    return localObject;
  }
  
  public static Object C(Element paramElement, String paramString)
  {
    Object localObject = paramElement.getClientProperty(paramString);
    if (localObject != null) {
      return localObject;
    }
    return TUIManager.get(paramString);
  }
  
  public static String A(PropertyChangeEvent paramPropertyChangeEvent)
  {
    String str = paramPropertyChangeEvent.getPropertyName();
    if (str.startsWith("CP:")) {
      str = str.substring("CP:".length());
    }
    return str;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.a
 * JD-Core Version:    0.7.0.1
 */
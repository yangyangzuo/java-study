package twaver.base.A.E;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.List;
import twaver.ShapeNode;

public class X
{
  private static boolean A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    if ((paramDouble3 >= paramDouble1) && (paramDouble3 <= paramDouble2)) {
      return true;
    }
    return (paramDouble3 >= paramDouble2) && (paramDouble3 <= paramDouble1);
  }
  
  private static boolean C(Point paramPoint1, Point paramPoint2, Point2D paramPoint2D)
  {
    if (paramPoint2 == null) {
      return true;
    }
    if (A(paramPoint2.getX(), paramPoint2D.getX(), paramPoint1.getX())) {
      return paramPoint2D.getX() > paramPoint2.getX();
    }
    return Math.abs(paramPoint2.getX() - paramPoint1.getX()) > Math.abs(paramPoint2D.getX() - paramPoint1.getX());
  }
  
  private static boolean A(Point paramPoint1, Point paramPoint2, Point2D paramPoint2D)
  {
    if (paramPoint2 == null) {
      return true;
    }
    if (A(paramPoint2.getX(), paramPoint2D.getX(), paramPoint1.getX())) {
      return paramPoint2D.getX() < paramPoint2.getX();
    }
    return Math.abs(paramPoint2.getX() - paramPoint1.getX()) > Math.abs(paramPoint2D.getX() - paramPoint1.getX());
  }
  
  private static boolean B(Point paramPoint1, Point paramPoint2, Point2D paramPoint2D)
  {
    if (paramPoint2 == null) {
      return true;
    }
    if (A(paramPoint2.getY(), paramPoint2D.getY(), paramPoint1.getY())) {
      return paramPoint2D.getY() < paramPoint2.getY();
    }
    return Math.abs(paramPoint2.getY() - paramPoint1.getY()) > Math.abs(paramPoint2D.getY() - paramPoint1.getY());
  }
  
  private static boolean D(Point paramPoint1, Point paramPoint2, Point2D paramPoint2D)
  {
    if (paramPoint2 == null) {
      return true;
    }
    if (A(paramPoint2.getY(), paramPoint2D.getY(), paramPoint1.getY())) {
      return paramPoint2D.getY() > paramPoint2.getY();
    }
    return Math.abs(paramPoint2.getY() - paramPoint1.getY()) > Math.abs(paramPoint2D.getY() - paramPoint1.getY());
  }
  
  private static Point A(Point paramPoint, Point2D paramPoint2D1, Point2D paramPoint2D2)
  {
    if (A(paramPoint2D1.getX(), paramPoint2D2.getX(), paramPoint.getX())) {
      return new Point(paramPoint.x, (int)paramPoint2D1.getY());
    }
    if (Math.abs(paramPoint.x - paramPoint2D1.getX()) < Math.abs(paramPoint.x - paramPoint2D2.getX())) {
      return new Point((int)paramPoint2D1.getX(), (int)paramPoint2D1.getY());
    }
    return new Point((int)paramPoint2D2.getX(), (int)paramPoint2D2.getY());
  }
  
  private static Point B(Point paramPoint, Point2D paramPoint2D1, Point2D paramPoint2D2)
  {
    if (A(paramPoint2D1.getY(), paramPoint2D2.getY(), paramPoint.getY())) {
      return new Point((int)paramPoint2D1.getX(), paramPoint.y);
    }
    if (Math.abs(paramPoint.y - paramPoint2D1.getY()) < Math.abs(paramPoint.y - paramPoint2D2.getY())) {
      return new Point((int)paramPoint2D1.getX(), (int)paramPoint2D1.getY());
    }
    return new Point((int)paramPoint2D2.getX(), (int)paramPoint2D2.getY());
  }
  
  private static Point A(Point paramPoint1, Point paramPoint2, Point2D paramPoint2D1, Point2D paramPoint2D2, int paramInt)
  {
    int i = Math.abs(paramPoint2D2.getX() - paramPoint2D1.getX()) > Math.abs(paramPoint2D2.getY() - paramPoint2D1.getY()) ? 1 : 0;
    if (3 == paramInt)
    {
      if ((i != 0) && (D(paramPoint2, paramPoint1, paramPoint2D1))) {
        return A(paramPoint2, paramPoint2D1, paramPoint2D2);
      }
      return null;
    }
    if (2 == paramInt)
    {
      if ((i != 0) && (B(paramPoint2, paramPoint1, paramPoint2D1))) {
        return A(paramPoint2, paramPoint2D1, paramPoint2D2);
      }
      return null;
    }
    if (4 == paramInt)
    {
      if ((i == 0) && (A(paramPoint2, paramPoint1, paramPoint2D1))) {
        return B(paramPoint2, paramPoint2D1, paramPoint2D2);
      }
      return null;
    }
    if (5 == paramInt)
    {
      if ((i == 0) && (C(paramPoint2, paramPoint1, paramPoint2D1))) {
        return B(paramPoint2, paramPoint2D1, paramPoint2D2);
      }
      return null;
    }
    if (1 == paramInt)
    {
      Point localPoint;
      if (i != 0) {
        localPoint = A(paramPoint2, paramPoint2D1, paramPoint2D2);
      } else {
        localPoint = B(paramPoint2, paramPoint2D1, paramPoint2D2);
      }
      if ((paramPoint1 == null) || (D.A(paramPoint1, paramPoint2) > D.A(localPoint, paramPoint2))) {
        return localPoint;
      }
      return null;
    }
    return null;
  }
  
  public static Point A(ShapeNode paramShapeNode, Point paramPoint, int paramInt)
  {
    Object localObject1 = null;
    List localList = paramShapeNode.getPoints();
    int i = localList.size();
    if (i > 0)
    {
      Object localObject2 = (Point2D)localList.get(0);
      for (int j = 1; j < i; j++)
      {
        Point2D localPoint2D = (Point2D)localList.get(j);
        Point localPoint = A((Point)localObject1, paramPoint, (Point2D)localObject2, localPoint2D, paramInt);
        if (localPoint != null) {
          localObject1 = localPoint;
        }
        localObject2 = localPoint2D;
      }
      if (localObject1 == null) {
        localObject1 = new Point((int)((Point2D)localObject2).getX(), (int)((Point2D)localObject2).getY());
      }
    }
    return localObject1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.X
 * JD-Core Version:    0.7.0.1
 */
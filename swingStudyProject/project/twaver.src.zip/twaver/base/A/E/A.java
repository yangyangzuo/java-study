package twaver.base.A.E;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.util.Iterator;
import javax.swing.Icon;
import twaver.base.A.D.D;
import twaver.network.ui.AbstractElementUI;
import twaver.network.ui.ElementUI;
import twaver.network.ui.IconAttachment;
import twaver.network.ui.LinkUI;

public class A
{
  public static Rectangle A(ElementUI paramElementUI, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramElementUI instanceof LinkUI))
    {
      localObject1 = (LinkUI)paramElementUI;
      double d = ((LinkUI)localObject1).getAngle();
      if (((LinkUI)localObject1).isLabelRotatable())
      {
        localPoint = M.A((LinkUI)localObject1, paramDimension, d, paramInt1, paramInt2, paramInt3, true);
        Object localObject2 = new Rectangle(localPoint.x, localPoint.y, paramDimension.width, paramDimension.height);
        AffineTransform localAffineTransform = AffineTransform.getRotateInstance(d, localPoint.x, localPoint.y);
        localObject2 = localAffineTransform.createTransformedShape((Shape)localObject2);
        D localD = new D(((Shape)localObject2).getBounds());
        localD.A(d);
        localD.A(localPoint);
        localD.B(paramDimension.width);
        localD.A(paramDimension.height);
        localD.A((Shape)localObject2);
        return localD;
      }
      Point localPoint = M.A((LinkUI)localObject1, paramDimension, d, paramInt1, paramInt2, paramInt3, false);
      return new Rectangle(localPoint.x, localPoint.y, paramDimension.width, paramDimension.height);
    }
    Object localObject1 = M.A(paramElementUI, paramDimension, paramInt1, paramInt2, paramInt3);
    return new Rectangle(((Point)localObject1).x, ((Point)localObject1).y, paramDimension.width, paramDimension.height);
  }
  
  public static Point A(AbstractElementUI paramAbstractElementUI, IconAttachment paramIconAttachment)
  {
    int i = paramAbstractElementUI.getAttachmentPosition();
    int j = paramAbstractElementUI.getAttachmentOrientation();
    int k = paramAbstractElementUI.getAttachmentXOffset();
    int m = paramAbstractElementUI.getAttachmentYOffset();
    int n = paramAbstractElementUI.getAttachmentXGap();
    int i1 = paramAbstractElementUI.getAttachmentYGap();
    Point localPoint = null;
    Iterator localIterator = paramAbstractElementUI.attachments();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof IconAttachment))
      {
        IconAttachment localIconAttachment = (IconAttachment)localObject;
        if (localIconAttachment.getPosition() < 0)
        {
          Icon localIcon = localIconAttachment.getIcon();
          int i2 = localIcon.getIconWidth();
          int i3 = localIcon.getIconHeight();
          int i4 = localIconAttachment == paramIconAttachment ? 1 : 0;
          int i5 = localPoint == null ? 1 : 0;
          if (i5 != 0) {
            localPoint = M.B(paramAbstractElementUI, new Dimension(i2, i3), i, k, m);
          }
          if (j == 1)
          {
            if (i5 == 0) {
              localPoint.y -= i3 + i1;
            }
          }
          else if (j == 2)
          {
            if (i5 == 0) {
              localPoint.y -= i3 + i1;
            }
            if (i4 == 0) {
              localPoint.x += i2 + n;
            }
          }
          else if (j == 3)
          {
            if (i4 == 0) {
              localPoint.x += i2 + n;
            }
          }
          else if (j == 4)
          {
            if (i4 == 0) {
              localPoint.y += i3 + i1;
            }
            if (i4 == 0) {
              localPoint.x += i2 + n;
            }
          }
          else if (j == 5)
          {
            if (i4 == 0) {
              localPoint.y += i3 + i1;
            }
          }
          else if (j == 6)
          {
            if (i4 == 0) {
              localPoint.y += i3 + i1;
            }
            if (i5 == 0) {
              localPoint.x -= i2 + n;
            }
          }
          else if (j == 7)
          {
            if (i5 == 0) {
              localPoint.x -= i2 + n;
            }
          }
          else if (j == 8)
          {
            if (i5 == 0) {
              localPoint.x -= i2 + n;
            }
            if (i5 == 0) {
              localPoint.y -= i3 + i1;
            }
          }
          if (i4 != 0) {
            break;
          }
        }
      }
    }
    return localPoint;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.A
 * JD-Core Version:    0.7.0.1
 */
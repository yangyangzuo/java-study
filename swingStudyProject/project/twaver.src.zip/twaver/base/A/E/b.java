package twaver.base.A.E;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.RoundRectangle2D.Float;
import twaver.Element;
import twaver.Generator;
import twaver.base.A.D.E;
import twaver.base.A.D.M;
import twaver.base.A.D.P;
import twaver.network.TNetwork;
import twaver.network.ui.GroupUI;

public class b
{
  private static G F(GroupUI paramGroupUI)
  {
    Generator local1 = new Generator()
    {
      public Object generate(Object paramAnonymousObject)
      {
        return b.this.getNetwork().getElementBounds((Element)paramAnonymousObject);
      }
    };
    return i.A(paramGroupUI.getGroup(), local1);
  }
  
  public static Rectangle A(GroupUI paramGroupUI)
  {
    Generator local2 = new Generator()
    {
      public Object generate(Object paramAnonymousObject)
      {
        return b.this.getNetwork().getElementBounds((Element)paramAnonymousObject);
      }
    };
    return i.A(paramGroupUI.getGroup(), paramGroupUI.getOutcrop(), paramGroupUI.getGroupInsets(), local2);
  }
  
  public static Ellipse2D D(GroupUI paramGroupUI)
  {
    Rectangle localRectangle = A(paramGroupUI);
    if (localRectangle == null) {
      return null;
    }
    double d = Math.sqrt(localRectangle.width * localRectangle.width + localRectangle.height * localRectangle.height);
    return new Ellipse2D.Double(localRectangle.getCenterX() - d / 2.0D, localRectangle.getCenterY() - d / 2.0D, d, d);
  }
  
  public static RoundRectangle2D E(GroupUI paramGroupUI)
  {
    Rectangle localRectangle = A(paramGroupUI);
    if (localRectangle == null) {
      return null;
    }
    int i = Math.min(localRectangle.width, localRectangle.height) / 4;
    if (i > 40) {
      i = 40;
    }
    return new RoundRectangle2D.Float(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, i, i);
  }
  
  public static M C(GroupUI paramGroupUI)
  {
    Ellipse2D localEllipse2D = G(paramGroupUI);
    if (localEllipse2D == null) {
      return null;
    }
    return new M(localEllipse2D, paramGroupUI.getDeep());
  }
  
  public static Ellipse2D G(GroupUI paramGroupUI)
  {
    G localG = F(paramGroupUI);
    return i.A(localG, paramGroupUI.getGroupInsets());
  }
  
  public static P I(GroupUI paramGroupUI)
  {
    E localE = H(paramGroupUI);
    if (localE == null) {
      return null;
    }
    return new P(localE, paramGroupUI.getDeep());
  }
  
  public static E H(GroupUI paramGroupUI)
  {
    G localG = F(paramGroupUI);
    return i.A(localG, paramGroupUI.getAngle(), paramGroupUI.getGroupInsets());
  }
  
  public static Shape B(GroupUI paramGroupUI)
  {
    G localG = F(paramGroupUI);
    return i.A(localG, paramGroupUI.getGroupInsets(), paramGroupUI.getGroup());
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.b
 * JD-Core Version:    0.7.0.1
 */
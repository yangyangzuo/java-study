package twaver.base.A.E;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;
import twaver.ShapeLink;
import twaver.ShapeNode;
import twaver.TWaverConst;

public class Z
{
  public static GeneralPath A(ShapeLink paramShapeLink, Point2D paramPoint2D1, Point2D paramPoint2D2)
  {
    int i = paramShapeLink.getShapeLinkType();
    ArrayList localArrayList = new ArrayList(paramShapeLink.getPoints());
    localArrayList.add(0, paramPoint2D1);
    if (2 == i)
    {
      localArrayList.add(paramPoint2D2);
      return F(localArrayList, localArrayList.size());
    }
    if (3 == i)
    {
      localArrayList.add(paramPoint2D2);
      return B(localArrayList, localArrayList.size());
    }
    if (4 == i)
    {
      GeneralPath localGeneralPath = D(localArrayList, localArrayList.size());
      localGeneralPath.lineTo((int)paramPoint2D2.getX(), (int)paramPoint2D2.getY());
      return localGeneralPath;
    }
    localArrayList.add(paramPoint2D2);
    return C(localArrayList, localArrayList.size());
  }
  
  public static Shape A(ShapeNode paramShapeNode)
  {
    List localList = paramShapeNode.getPoints();
    int i = localList.size();
    if (i == 1)
    {
      localObject1 = (Point2D)localList.get(0);
      return new Rectangle((int)((Point2D)localObject1).getX(), (int)((Point2D)localObject1).getY(), 1, 1);
    }
    if (i < 1) {
      return TWaverConst.EMPTY_BOUNDS;
    }
    Object localObject1 = paramShapeNode.getSegments();
    if ((localObject1 != null) && (((List)localObject1).size() > 0)) {
      return A(localList, (List)localObject1);
    }
    int j = paramShapeNode.getShapeNodeType();
    if (j == 1) {
      return C(localList, i);
    }
    if (j == 2)
    {
      localObject2 = C(localList, i);
      ((GeneralPath)localObject2).closePath();
      return localObject2;
    }
    if (j == 3) {
      return F(localList, i);
    }
    if (j == 4) {
      return A(localList, i);
    }
    if (j == 5) {
      return B(localList, i);
    }
    if (j == 6) {
      return E(localList, i);
    }
    if (j == 7) {
      return D(localList, i);
    }
    Object localObject2 = null;
    for (int k = 0; k < i; k++)
    {
      Point2D localPoint2D = (Point2D)localList.get(k);
      if (localObject2 == null) {
        localObject2 = new Rectangle((int)localPoint2D.getX(), (int)localPoint2D.getY(), 0, 0);
      } else {
        ((Rectangle)localObject2).add(localPoint2D);
      }
    }
    if (j == 8) {
      return D.A((Rectangle)localObject2, localList);
    }
    if (j == 9)
    {
      double d = Math.sqrt(((Rectangle)localObject2).width * ((Rectangle)localObject2).width + ((Rectangle)localObject2).height * ((Rectangle)localObject2).height);
      return new Ellipse2D.Double(((Rectangle)localObject2).getCenterX() - d / 2.0D, ((Rectangle)localObject2).getCenterY() - d / 2.0D, d, d);
    }
    return localObject2;
  }
  
  public static GeneralPath D(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Object localObject = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)((Point2D)localObject).getX(), (int)((Point2D)localObject).getY());
    for (int i = 1; i < paramInt; i++)
    {
      Point2D localPoint2D = (Point2D)paramList.get(i);
      double d1 = localPoint2D.getX();
      double d2 = localPoint2D.getY();
      double d3 = d1 - ((Point2D)localObject).getX();
      double d4 = d2 - ((Point2D)localObject).getY();
      if (Math.abs(d3) > Math.abs(d4)) {
        localPoint2D.setLocation(d1, ((Point2D)localObject).getY());
      } else {
        localPoint2D.setLocation(((Point2D)localObject).getX(), d2);
      }
      localObject = localPoint2D;
      localGeneralPath.lineTo((int)((Point2D)localObject).getX(), (int)((Point2D)localObject).getY());
    }
    return localGeneralPath;
  }
  
  public static GeneralPath A(List paramList1, List paramList2)
  {
    int i = paramList1.size();
    int j = paramList2.size();
    GeneralPath localGeneralPath = new GeneralPath();
    int k = 0;
    for (int m = 0; m < j; m++)
    {
      int n = ((Integer)paramList2.get(m)).intValue();
      Point2D localPoint2D1;
      Point2D localPoint2D2;
      Point2D localPoint2D3;
      switch (n)
      {
      case 0: 
        if (k >= i) {
          return localGeneralPath;
        }
        localPoint2D1 = (Point2D)paramList1.get(k++);
        localGeneralPath.moveTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
        break;
      case 1: 
        if (k >= i) {
          return localGeneralPath;
        }
        localPoint2D1 = (Point2D)paramList1.get(k++);
        localGeneralPath.lineTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
        break;
      case 2: 
        if (k >= i - 1) {
          return localGeneralPath;
        }
        localPoint2D2 = (Point2D)paramList1.get(k++);
        localPoint2D3 = (Point2D)paramList1.get(k++);
        localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
        break;
      case 3: 
        if (k >= i - 2) {
          return localGeneralPath;
        }
        localPoint2D2 = (Point2D)paramList1.get(k++);
        localPoint2D3 = (Point2D)paramList1.get(k++);
        Point2D localPoint2D4 = (Point2D)paramList1.get(k++);
        localGeneralPath.curveTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY(), (int)localPoint2D4.getX(), (int)localPoint2D4.getY());
        break;
      case 4: 
        localGeneralPath.closePath();
      }
    }
    return localGeneralPath;
  }
  
  public static GeneralPath C(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D localPoint2D = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)localPoint2D.getX(), (int)localPoint2D.getY());
    for (int i = 1; i < paramInt; i++)
    {
      localPoint2D = (Point2D)paramList.get(i);
      localGeneralPath.lineTo((int)localPoint2D.getX(), (int)localPoint2D.getY());
    }
    return localGeneralPath;
  }
  
  public static GeneralPath F(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D localPoint2D1 = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
    int i = 1;
    while (i < paramInt) {
      if (i + 1 < paramInt)
      {
        Point2D localPoint2D2 = (Point2D)paramList.get(i++);
        Point2D localPoint2D3 = (Point2D)paramList.get(i++);
        localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
      }
      else
      {
        localPoint2D1 = (Point2D)paramList.get(i++);
        localGeneralPath.lineTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
      }
    }
    return localGeneralPath;
  }
  
  public static GeneralPath A(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D localPoint2D1 = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
    int i = 1;
    Point2D localPoint2D2;
    Point2D localPoint2D3;
    while (i + 1 < paramInt)
    {
      localPoint2D2 = (Point2D)paramList.get(i++);
      localPoint2D3 = (Point2D)paramList.get(i++);
      localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
    }
    if (i == paramInt - 1)
    {
      localPoint2D2 = (Point2D)paramList.get(paramInt - 1);
      localPoint2D3 = (Point2D)paramList.get(0);
      localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
    }
    else
    {
      localGeneralPath.closePath();
    }
    return localGeneralPath;
  }
  
  public static GeneralPath B(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D localPoint2D1 = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
    int i = 1;
    while (i < paramInt)
    {
      Point2D localPoint2D2;
      Point2D localPoint2D3;
      if (i + 2 < paramInt)
      {
        localPoint2D2 = (Point2D)paramList.get(i++);
        localPoint2D3 = (Point2D)paramList.get(i++);
        Point2D localPoint2D4 = (Point2D)paramList.get(i++);
        localGeneralPath.curveTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY(), (int)localPoint2D4.getX(), (int)localPoint2D4.getY());
      }
      else if (i + 2 == paramInt)
      {
        localPoint2D2 = (Point2D)paramList.get(i++);
        localPoint2D3 = (Point2D)paramList.get(i++);
        localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
      }
      else if (i + 1 == paramInt)
      {
        localPoint2D1 = (Point2D)paramList.get(i++);
        localGeneralPath.lineTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
      }
    }
    return localGeneralPath;
  }
  
  public static GeneralPath E(List paramList, int paramInt)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D localPoint2D1 = (Point2D)paramList.get(0);
    localGeneralPath.moveTo((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
    int i = 1;
    Point2D localPoint2D2;
    Point2D localPoint2D3;
    Point2D localPoint2D4;
    while (i + 2 < paramInt)
    {
      localPoint2D2 = (Point2D)paramList.get(i++);
      localPoint2D3 = (Point2D)paramList.get(i++);
      localPoint2D4 = (Point2D)paramList.get(i++);
      localGeneralPath.curveTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY(), (int)localPoint2D4.getX(), (int)localPoint2D4.getY());
    }
    if (i + 2 == paramInt)
    {
      localPoint2D2 = (Point2D)paramList.get(i++);
      localPoint2D3 = (Point2D)paramList.get(i++);
      localPoint2D4 = (Point2D)paramList.get(0);
      localGeneralPath.curveTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY(), (int)localPoint2D4.getX(), (int)localPoint2D4.getY());
    }
    else if (i + 1 == paramInt)
    {
      localPoint2D2 = (Point2D)paramList.get(i++);
      localPoint2D3 = (Point2D)paramList.get(0);
      localGeneralPath.quadTo((int)localPoint2D2.getX(), (int)localPoint2D2.getY(), (int)localPoint2D3.getX(), (int)localPoint2D3.getY());
    }
    else
    {
      localGeneralPath.closePath();
    }
    return localGeneralPath;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.Z
 * JD-Core Version:    0.7.0.1
 */
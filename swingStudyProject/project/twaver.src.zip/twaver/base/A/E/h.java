package twaver.base.A.E;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import javax.swing.JComponent;
import twaver.Element;
import twaver.Layer;
import twaver.LayerModel;
import twaver.TDataBox;
import twaver.base.A.G.C;
import twaver.network.CanvasCushion;
import twaver.network.CanvasMarker;
import twaver.network.CanvasPaintListener;
import twaver.network.NetworkElementRenderer;
import twaver.network.TNetwork;
import twaver.network.background.Background;
import twaver.network.ui.Attachment;
import twaver.network.ui.ElementUI;

public final class h
{
  public static boolean B = false;
  public static final List A = new LinkedList();
  
  private static void A(Graphics2D paramGraphics2D)
  {
    if (!A.isEmpty())
    {
      Iterator localIterator = A.iterator();
      while (localIterator.hasNext())
      {
        Attachment localAttachment = (Attachment)localIterator.next();
        localAttachment.paint(paramGraphics2D);
      }
      A.clear();
    }
  }
  
  public static final void A(TNetwork paramTNetwork, Graphics paramGraphics, double paramDouble1, double paramDouble2, boolean paramBoolean)
  {
    JComponent localJComponent = paramTNetwork.getCanvas();
    float f = paramTNetwork.getAlpha();
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    Composite localComposite = null;
    if (f != 1.0F)
    {
      localComposite = localGraphics2D.getComposite();
      localObject1 = AlphaComposite.getInstance(3, f);
      localGraphics2D.setComposite((Composite)localObject1);
    }
    Object localObject1 = localGraphics2D.getClip();
    Paint localPaint = localGraphics2D.getPaint();
    Stroke localStroke = localGraphics2D.getStroke();
    Font localFont = localGraphics2D.getFont();
    Color localColor1 = localGraphics2D.getColor();
    Color localColor2 = localGraphics2D.getBackground();
    RenderingHints localRenderingHints = localGraphics2D.getRenderingHints();
    AffineTransform localAffineTransform = localGraphics2D.getTransform();
    localGraphics2D.scale(paramDouble1, paramDouble2);
    List localList = paramTNetwork.getCanvasPaintListeners();
    int i = localList.size();
    CanvasPaintListener localCanvasPaintListener1;
    for (int j = 0; j < i; j++)
    {
      localCanvasPaintListener1 = (CanvasPaintListener)localList.get(j);
      localCanvasPaintListener1.beforePaint(paramGraphics);
    }
    for (j = 0; j < i; j++)
    {
      localCanvasPaintListener1 = (CanvasPaintListener)localList.get(j);
      localCanvasPaintListener1.beforePaintBackground(paramGraphics);
    }
    double d1 = paramTNetwork.getZoom();
    Rectangle localRectangle = localJComponent.getBounds();
    double d2 = localRectangle.getX() / d1;
    double d3 = localRectangle.getY() / d1;
    double d4 = localRectangle.getWidth() / d1;
    double d5 = localRectangle.getHeight() / d1;
    localRectangle = new Rectangle((int)d2, (int)d3, (int)d4, (int)d5);
    if (paramTNetwork.isPaintBackground())
    {
      Background localBackground = paramTNetwork.getCurrentBackground();
      if (localBackground != null) {
        localBackground.paint(paramGraphics, paramDouble1, localRectangle);
      }
    }
    Object localObject2;
    for (int k = 0; k < i; k++)
    {
      localObject2 = (CanvasPaintListener)localList.get(k);
      ((CanvasPaintListener)localObject2).afterPaintBackground(paramGraphics);
    }
    for (k = 0; k < i; k++)
    {
      localObject2 = (CanvasPaintListener)localList.get(k);
      ((CanvasPaintListener)localObject2).beforePaintCushions(paramGraphics);
    }
    Iterator localIterator = paramTNetwork.getCanvasCushions().iterator();
    while (localIterator.hasNext())
    {
      localObject2 = (CanvasCushion)localIterator.next();
      ((CanvasCushion)localObject2).paint(localGraphics2D);
    }
    CanvasPaintListener localCanvasPaintListener2;
    for (int m = 0; m < i; m++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(m);
      localCanvasPaintListener2.afterPaintCushions(paramGraphics);
    }
    for (m = 0; m < i; m++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(m);
      localCanvasPaintListener2.beforePaintElements(paramGraphics);
    }
    A(paramTNetwork, localGraphics2D, paramBoolean);
    for (m = 0; m < i; m++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(m);
      localCanvasPaintListener2.afterPaintElements(paramGraphics);
    }
    for (m = 0; m < i; m++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(m);
      localCanvasPaintListener2.beforePaintMarkers(paramGraphics);
    }
    localIterator = paramTNetwork.getCanvasMarkers().iterator();
    while (localIterator.hasNext())
    {
      CanvasMarker localCanvasMarker = (CanvasMarker)localIterator.next();
      localCanvasMarker.mark(localGraphics2D);
    }
    for (int n = 0; n < i; n++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(n);
      localCanvasPaintListener2.afterPaintMarkers(paramGraphics);
    }
    if (B) {
      C.A(paramTNetwork, localGraphics2D);
    }
    for (n = 0; n < i; n++)
    {
      localCanvasPaintListener2 = (CanvasPaintListener)localList.get(n);
      localCanvasPaintListener2.afterPaint(paramGraphics);
    }
    localGraphics2D.scale(1.0D / paramDouble1, 1.0D / paramDouble2);
    if (localComposite != null) {
      localGraphics2D.setComposite(localComposite);
    }
    if (localAffineTransform != null) {
      localGraphics2D.setTransform(localAffineTransform);
    }
    if (localObject1 != null) {
      localGraphics2D.setClip((Shape)localObject1);
    }
    if (localStroke != null) {
      localGraphics2D.setStroke(localStroke);
    }
    if (localPaint != null) {
      localGraphics2D.setPaint(localPaint);
    }
    if (localFont != null) {
      localGraphics2D.setFont(localFont);
    }
    if (localColor1 != null) {
      localGraphics2D.setColor(localColor1);
    }
    if (localColor2 != null) {
      localGraphics2D.setBackground(localColor2);
    }
    if (localRenderingHints != null) {
      localGraphics2D.setRenderingHints(localRenderingHints);
    }
    C.A(paramTNetwork, localGraphics2D);
  }
  
  private static final void A(TNetwork paramTNetwork, Graphics2D paramGraphics2D, boolean paramBoolean)
  {
    Rectangle localRectangle1 = null;
    if (paramBoolean)
    {
      localRectangle1 = paramGraphics2D.getClipBounds();
      if (localRectangle1 != null)
      {
        int i = (int)Math.max(20.0D * paramTNetwork.getZoom(), 10.0D);
        localRectangle1.grow(i, i);
      }
    }
    Rectangle localRectangle2 = localRectangle1;
    NetworkElementRenderer localNetworkElementRenderer = paramTNetwork.getRenderer();
    TDataBox localTDataBox = paramTNetwork.getDataBox();
    ListIterator localListIterator = paramTNetwork.getPaintElementIterator();
    if (localListIterator != null)
    {
      while (localListIterator.hasPrevious())
      {
        localObject1 = (Element)localListIterator.previous();
        if (paramTNetwork.isVisible((Element)localObject1))
        {
          Object localObject2;
          if (localRectangle2 != null)
          {
            localObject2 = paramTNetwork.getElementBounds((Element)localObject1);
            if ((localObject2 != null) && (!((Rectangle)localObject2).intersects(localRectangle2))) {}
          }
          else
          {
            localObject2 = localNetworkElementRenderer.getElementUI((Element)localObject1);
            ((ElementUI)localObject2).paint(paramGraphics2D);
          }
        }
      }
      A(paramGraphics2D);
      return;
    }
    Object localObject1 = localTDataBox.getLayerModel();
    int j = ((LayerModel)localObject1).size();
    for (int k = 0; k < j; k++)
    {
      Layer localLayer = ((LayerModel)localObject1).getLayerByIndex(k);
      Composite localComposite = null;
      Object localObject3;
      if (localLayer.getAlpha() != 1.0F)
      {
        localComposite = paramGraphics2D.getComposite();
        localObject3 = AlphaComposite.getInstance(3, localLayer.getAlpha());
        paramGraphics2D.setComposite((Composite)localObject3);
      }
      localListIterator = localTDataBox.listIterator(localTDataBox.size());
      while (localListIterator.hasPrevious())
      {
        localObject3 = (Element)localListIterator.previous();
        if ((((LayerModel)localObject1).contains((Element)localObject3, localLayer)) && (paramTNetwork.isVisible((Element)localObject3)))
        {
          Rectangle localRectangle3 = paramTNetwork.getElementBounds((Element)localObject3);
          if ((localRectangle2 == null) || (localRectangle3 == null) || (localRectangle3.intersects(localRectangle2)))
          {
            ElementUI localElementUI = localNetworkElementRenderer.getElementUI((Element)localObject3);
            localElementUI.paint(paramGraphics2D);
          }
        }
      }
      A(paramGraphics2D);
      if (localComposite != null) {
        paramGraphics2D.setComposite(localComposite);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.h
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.beans.PropertyChangeEvent;
import java.util.Collection;
import java.util.Iterator;
import twaver.Alarm;
import twaver.AlarmElementMapping;
import twaver.AlarmModel;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.Element;

public class Q
{
  public static void A(AlarmModel paramAlarmModel, Alarm paramAlarm, boolean paramBoolean)
  {
    Object localObject1 = paramAlarmModel.getAlarmElementMapping().getCorrespondingElements(paramAlarmModel.getDataBox(), paramAlarm);
    Object localObject2;
    if ((localObject1 instanceof Element))
    {
      localObject2 = (Element)localObject1;
      A((Element)localObject2, paramAlarm, paramBoolean);
    }
    else if ((localObject1 instanceof Collection))
    {
      localObject2 = (Collection)localObject1;
      Iterator localIterator = ((Collection)localObject2).iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        A(localElement, paramAlarm, paramBoolean);
      }
    }
  }
  
  public static void A(Element paramElement, Alarm paramAlarm, boolean paramBoolean)
  {
    AlarmSeverity localAlarmSeverity = paramAlarm.getAlarmSeverity();
    if (localAlarmSeverity != null)
    {
      AlarmState localAlarmState = paramElement.getAlarmState();
      if (paramAlarm.isAcked())
      {
        if (paramBoolean) {
          localAlarmState.addAcknowledgedAlarm(localAlarmSeverity);
        } else {
          localAlarmState.removeAcknowledgedAlarm(localAlarmSeverity);
        }
      }
      else if (paramBoolean) {
        localAlarmState.addNewAlarm(localAlarmSeverity);
      } else {
        localAlarmState.removeNewAlarm(localAlarmSeverity);
      }
    }
  }
  
  public static void A(Element paramElement, PropertyChangeEvent paramPropertyChangeEvent)
  {
    Alarm localAlarm = (Alarm)paramPropertyChangeEvent.getSource();
    AlarmSeverity localAlarmSeverity = localAlarm.getAlarmSeverity();
    if (localAlarmSeverity == null) {
      return;
    }
    boolean bool = localAlarm.isAcked();
    int i = bool ? 0 : 1;
    if (i != 0) {
      paramElement.getAlarmState().decreaseAcknowledgedAlarm(localAlarmSeverity, 1);
    } else {
      paramElement.getAlarmState().decreaseNewAlarm(localAlarmSeverity, 1);
    }
    if (bool) {
      paramElement.getAlarmState().addAcknowledgedAlarm(localAlarmSeverity);
    } else {
      paramElement.getAlarmState().addNewAlarm(localAlarmSeverity);
    }
  }
  
  public static void A(Element paramElement, PropertyChangeEvent paramPropertyChangeEvent, AlarmModel paramAlarmModel)
  {
    AlarmState localAlarmState = paramElement.getAlarmState();
    Alarm localAlarm = (Alarm)paramPropertyChangeEvent.getSource();
    AlarmSeverity localAlarmSeverity1 = (AlarmSeverity)paramPropertyChangeEvent.getOldValue();
    AlarmSeverity localAlarmSeverity2 = (AlarmSeverity)paramPropertyChangeEvent.getNewValue();
    if (localAlarmSeverity1 != null) {
      if (localAlarm.isAcked()) {
        localAlarmState.removeAcknowledgedAlarm(localAlarmSeverity1);
      } else {
        localAlarmState.removeNewAlarm(localAlarmSeverity1);
      }
    }
    if (localAlarmSeverity2 != null) {
      if (localAlarm.isAcked()) {
        localAlarmState.addAcknowledgedAlarm(localAlarmSeverity2);
      } else {
        localAlarmState.addNewAlarm(localAlarmSeverity2);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.Q
 * JD-Core Version:    0.7.0.1
 */
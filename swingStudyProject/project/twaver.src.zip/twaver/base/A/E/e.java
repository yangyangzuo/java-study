package twaver.base.A.E;

import java.awt.Rectangle;

class e
  extends Rectangle
{
  double C;
  double D;
  double B;
  double A;
  
  public e(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    setFrame(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    this.C = paramDouble1;
    this.D = paramDouble2;
    this.B = paramDouble3;
    this.A = paramDouble4;
  }
  
  public double getX()
  {
    return this.C;
  }
  
  public double getY()
  {
    return this.D;
  }
  
  public double getWidth()
  {
    return this.B;
  }
  
  public double getHeight()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.e
 * JD-Core Version:    0.7.0.1
 */
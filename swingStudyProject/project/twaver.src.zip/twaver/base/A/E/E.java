package twaver.base.A.E;

import java.awt.Rectangle;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import twaver.Card;
import twaver.Element;
import twaver.Follower;
import twaver.Link;
import twaver.Node;
import twaver.PersistenceManager;
import twaver.ResizableNode;
import twaver.Slot;
import twaver.TDataBox;
import twaver.TWaverUtil;
import twaver.VisibleFilter;

public final class E
{
  public static void B(List paramList1, List paramList2)
  {
    Iterator localIterator = paramList2.iterator();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (localElement.isSelected()) {
        paramList1.add(localElement);
      }
    }
    localIterator = paramList2.iterator();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      B(paramList1, localElement.getChildren());
    }
  }
  
  public static void D(List paramList1, List paramList2)
  {
    ListIterator localListIterator = paramList2.listIterator(paramList2.size());
    while (localListIterator.hasPrevious())
    {
      localObject = (Element)localListIterator.previous();
      if (((Element)localObject).isSelected()) {
        paramList1.add(localObject);
      }
    }
    Object localObject = paramList2.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Element localElement = (Element)((Iterator)localObject).next();
      D(paramList1, localElement.getChildren());
    }
  }
  
  public static void C(List paramList1, List paramList2)
  {
    int i = 0;
    Iterator localIterator = paramList2.iterator();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (localElement.isSelected())
      {
        if (i != 0) {
          paramList1.add(localElement);
        }
      }
      else {
        i = 1;
      }
    }
    localIterator = paramList2.iterator();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      C(paramList1, localElement.getChildren());
    }
  }
  
  public static void A(List paramList1, List paramList2)
  {
    int i = 0;
    ListIterator localListIterator = paramList2.listIterator(paramList2.size());
    while (localListIterator.hasPrevious())
    {
      localObject = (Element)localListIterator.previous();
      if (((Element)localObject).isSelected())
      {
        if (i != 0) {
          paramList1.add(localObject);
        }
      }
      else {
        i = 1;
      }
    }
    Object localObject = paramList2.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Element localElement = (Element)((Iterator)localObject).next();
      A(paramList1, localElement.getChildren());
    }
  }
  
  public static void A(TDataBox paramTDataBox, Element paramElement, VisibleFilter paramVisibleFilter)
  {
    if (paramElement == null) {
      return;
    }
    if ((paramVisibleFilter != null) && (!paramVisibleFilter.isVisible(paramElement))) {
      return;
    }
    if (!paramTDataBox.contains(paramElement)) {
      paramTDataBox.addElement(paramElement);
    }
    List localList = paramElement.getChildren();
    if ((localList != null) && (localList.size() > 0)) {
      for (int i = 0; i < localList.size(); i++)
      {
        Element localElement = (Element)localList.get(i);
        A(paramTDataBox, localElement, paramVisibleFilter);
      }
    }
  }
  
  public static void A(String paramString, Element paramElement, boolean paramBoolean)
    throws IOException
  {
    if (paramString == null) {
      throw new NullPointerException("fileName can't be null.");
    }
    if (paramElement == null) {
      throw new NullPointerException("element can't be null.");
    }
    TDataBox localTDataBox = new TDataBox();
    Element localElement = paramElement.getParent();
    paramElement.setParent(null);
    localTDataBox.addElementWithDescendant(paramElement);
    FileOutputStream localFileOutputStream = new FileOutputStream(paramString);
    PersistenceManager.writeByXML(localTDataBox, paramBoolean, true, true, localFileOutputStream, null, null);
    paramElement.setParent(localElement);
    localTDataBox.clear();
  }
  
  public static String B(Element paramElement, boolean paramBoolean)
    throws IOException
  {
    if (paramElement == null) {
      throw new NullPointerException("element can't be null.");
    }
    TDataBox localTDataBox = new TDataBox();
    Element localElement = paramElement.getParent();
    paramElement.setParent(null);
    localTDataBox.addElementWithDescendant(paramElement);
    String str = PersistenceManager.writeByXML(localTDataBox, paramBoolean);
    paramElement.setParent(localElement);
    localTDataBox.clear();
    return str;
  }
  
  public static Element A(Element paramElement, boolean paramBoolean)
  {
    if (paramElement == null) {
      throw new NullPointerException("source can't be null.");
    }
    try
    {
      String str = B(paramElement, paramBoolean);
      TDataBox localTDataBox = new TDataBox();
      PersistenceManager.readByXML(localTDataBox, str, null);
      Iterator localIterator = localTDataBox.getRootElements().iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        if (localElement.getClass() == paramElement.getClass())
        {
          if ((localElement instanceof Link))
          {
            Node localNode1 = ((Link)localElement).getFrom();
            Node localNode2 = ((Link)localElement).getTo();
            localNode1.setParent(null);
            localNode2.setParent(null);
            if ((localNode1 instanceof Follower)) {
              ((Follower)localNode1).setHost(null);
            }
            if ((localNode2 instanceof Follower)) {
              ((Follower)localNode2).setHost(null);
            }
          }
          localTDataBox.clear();
          return localElement;
        }
      }
      localTDataBox.clear();
      return null;
    }
    catch (IOException localIOException)
    {
      TWaverUtil.handleError(null, localIOException);
    }
    return null;
  }
  
  public static void A(TDataBox paramTDataBox, Slot paramSlot, Card paramCard, boolean paramBoolean)
  {
    B(paramTDataBox, paramSlot);
    if ((paramSlot != null) && (paramCard != null))
    {
      HashMap localHashMap = new HashMap();
      Rectangle localRectangle1 = paramCard.getBounds();
      Iterator localIterator = paramCard.getChildren().iterator();
      Object localObject2;
      while (localIterator.hasNext())
      {
        localObject1 = (Element)localIterator.next();
        if ((localObject1 instanceof ResizableNode))
        {
          localObject2 = (ResizableNode)localObject1;
          localHashMap.put(localObject1, ((ResizableNode)localObject2).getBounds());
        }
      }
      paramSlot.setEquipCount(1);
      paramCard.setParent(paramSlot);
      paramCard.setHost(paramSlot);
      paramTDataBox.addElementWithDescendant(paramCard);
      paramCard.adjustBounds();
      Object localObject1 = paramCard.getBounds();
      localIterator = localHashMap.keySet().iterator();
      while (localIterator.hasNext())
      {
        localObject2 = (Element)localIterator.next();
        if ((localObject2 instanceof ResizableNode))
        {
          ResizableNode localResizableNode = (ResizableNode)localObject2;
          Rectangle localRectangle2 = (Rectangle)localHashMap.get(localResizableNode);
          D.A(localRectangle2, localRectangle1, (Rectangle)localObject1);
          localResizableNode.setLocation(localRectangle2.x, localRectangle2.y);
          localResizableNode.setSize(localRectangle2.width, localRectangle2.height);
        }
      }
    }
  }
  
  public static void B(TDataBox paramTDataBox, Element paramElement)
  {
    if ((paramTDataBox == null) || (paramElement == null)) {
      return;
    }
    while (paramElement.getChildren().size() > 0)
    {
      Element localElement = (Element)paramElement.getChildren().iterator().next();
      paramTDataBox.removeElement(localElement);
      paramElement.removeChild(localElement);
    }
  }
  
  public static void A(TDataBox paramTDataBox, Element paramElement)
  {
    if (paramElement == null) {
      return;
    }
    if (paramElement.isAdjustToBottom())
    {
      paramTDataBox.sendToBottom(paramElement);
      Iterator localIterator = paramElement.children();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        A(paramTDataBox, localElement);
      }
    }
    else
    {
      paramTDataBox.sendToTop(paramElement);
    }
  }
  
  public static boolean A(Node paramNode)
  {
    Iterator localIterator = paramNode.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (((localElement instanceof Node)) && (A((Node)localElement))) {
        return true;
      }
    }
    return paramNode.hasAgentLinks();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.E
 * JD-Core Version:    0.7.0.1
 */
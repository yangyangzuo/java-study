package twaver.base.A.E;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.Node;
import twaver.TDataBox;
import twaver.TSubNetwork;
import twaver.TWaverUtil;

public final class j
{
  public static boolean C(Node paramNode1, Node paramNode2)
  {
    if ((paramNode1 == null) || (paramNode2 == null)) {
      return false;
    }
    List localList1 = paramNode1.getAllLinks();
    List localList2 = paramNode2.getAllLinks();
    if ((localList1 == null) || (localList2 == null)) {
      return false;
    }
    for (int i = 0; i < localList1.size(); i++)
    {
      Link localLink = (Link)localList1.get(i);
      if (localList2.contains(localLink)) {
        return true;
      }
    }
    return false;
  }
  
  public static List A(Node paramNode1, Node paramNode2)
  {
    if ((paramNode1 == null) || (paramNode2 == null)) {
      return null;
    }
    Object localObject = null;
    if (paramNode1 == paramNode2)
    {
      localObject = paramNode1.getLoopLinks();
      if (localObject == null) {
        return null;
      }
      return new ArrayList((Collection)localObject);
    }
    List localList1 = paramNode1.getAllAgentLinks();
    List localList2 = paramNode2.getAllAgentLinks();
    if ((localList1 == null) || (localList2 == null) || (localList1.size() == 0) || (localList2.size() == 0)) {
      return null;
    }
    for (int i = 0; i < localList1.size(); i++)
    {
      Link localLink = (Link)localList1.get(i);
      if (localList2.contains(localLink))
      {
        if (localObject == null) {
          localObject = new ArrayList();
        }
        if (!((List)localObject).contains(localLink)) {
          ((List)localObject).add(localLink);
        }
      }
    }
    return localObject;
  }
  
  public static void A(Node paramNode1, Node paramNode2, boolean paramBoolean)
  {
    List localList = A(paramNode1, paramNode2);
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Link localLink = (Link)localIterator.next();
        localLink.putLinkBundleExpand(paramBoolean);
      }
    }
  }
  
  public static void A(Node paramNode1, Node paramNode2, TDataBox paramTDataBox)
  {
    List localList = paramTDataBox.getBundledLinks(paramNode1, paramNode2);
    int i = localList == null ? 0 : localList.size();
    if (i > 0)
    {
      Object localObject = null;
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        localLink1 = (Link)localIterator.next();
        localObject = localLink1.getClientProperty("link.bundle.expand");
        if (localObject != null) {
          break;
        }
      }
      Link localLink1 = null;
      Generator localGenerator = paramTDataBox.getLinkBundleAgentGenerator();
      if (localGenerator != null) {
        localLink1 = (Link)localGenerator.generate(localList);
      }
      if (localLink1 == null) {
        localLink1 = (Link)localList.get(0);
      }
      localLink1.putLinkBundleIndex(-1);
      localLink1.putLinkBundleIndex(0);
      localLink1.putLinkBundleSize(i);
      localLink1.putClientProperty("link.bundle.expand", localObject);
      localList.remove(localLink1);
      int j = 0;
      localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Link localLink2 = (Link)localIterator.next();
        localLink2.putLinkBundleIndex(j + 1);
        localLink2.putLinkBundleSize(i);
        localLink2.putClientProperty("link.bundle.expand", localObject);
        j++;
      }
    }
  }
  
  public static Node B(Node paramNode)
  {
    if (paramNode == null) {
      return null;
    }
    Element localElement = paramNode.getParent();
    while ((localElement instanceof Group)) {
      if ((localElement.getParent() instanceof Group))
      {
        if (!((Group)localElement).isExpand()) {
          paramNode = (Node)localElement;
        }
        localElement = localElement.getParent();
      }
      else
      {
        if (((Group)localElement).isExpand()) {
          return paramNode;
        }
        return (Node)localElement;
      }
    }
    return paramNode;
  }
  
  public static Node B(Node paramNode1, Node paramNode2)
  {
    if ((paramNode1 == null) || (paramNode2 == null)) {
      return paramNode1;
    }
    TSubNetwork localTSubNetwork1 = TWaverUtil.getElementSubNetwork(paramNode1);
    TSubNetwork localTSubNetwork2 = TWaverUtil.getElementSubNetwork(paramNode2);
    if (localTSubNetwork1 != localTSubNetwork2)
    {
      while ((localTSubNetwork2 != null) && (localTSubNetwork1 != localTSubNetwork2)) {
        localTSubNetwork2 = TWaverUtil.getElementSubNetwork(localTSubNetwork2);
      }
      if (localTSubNetwork1 == localTSubNetwork2) {
        return paramNode1;
      }
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(0, paramNode1);
      for (Element localElement = paramNode1.getParent(); (localElement instanceof Node); localElement = localElement.getParent())
      {
        if (paramNode2.isDescendantOf(localElement)) {
          break;
        }
        localArrayList.add(0, localElement);
      }
      for (int i = 0; i < localArrayList.size(); i++)
      {
        Node localNode = (Node)localArrayList.get(i);
        if (((localNode instanceof Group)) && (!((Group)localNode).isExpand())) {
          return localNode;
        }
        if ((localNode instanceof TSubNetwork)) {
          return localNode;
        }
      }
      return paramNode1;
    }
    return paramNode1;
  }
  
  public static Node B(Link paramLink)
  {
    if (paramLink.isLoop()) {
      return paramLink.getFrom();
    }
    Node localNode1 = B(paramLink.getFrom());
    Node localNode2 = B(paramLink.getTo());
    if (localNode1 == localNode2) {
      return paramLink.getFrom();
    }
    return B(localNode1, localNode2);
  }
  
  public static Node A(Link paramLink)
  {
    if (paramLink.isLoop()) {
      return paramLink.getTo();
    }
    Node localNode1 = B(paramLink.getFrom());
    Node localNode2 = B(paramLink.getTo());
    if (localNode1 == localNode2) {
      return paramLink.getTo();
    }
    return B(localNode2, localNode1);
  }
  
  public static void A(Node paramNode)
  {
    ArrayList localArrayList = new ArrayList();
    A(paramNode, localArrayList);
    for (int i = 0; i < localArrayList.size(); i++)
    {
      Link localLink = (Link)localArrayList.get(i);
      localLink.checkAgentNode();
    }
  }
  
  private static void A(Node paramNode, List paramList)
  {
    List localList = paramNode.getAllLinks();
    if (localList != null) {
      paramList.addAll(localList);
    }
    if (((paramNode instanceof Group)) || ((paramNode instanceof TSubNetwork)))
    {
      Iterator localIterator = paramNode.getChildren().iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        if ((localElement instanceof Node)) {
          A((Node)localElement, paramList);
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.j
 * JD-Core Version:    0.7.0.1
 */
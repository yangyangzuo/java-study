package twaver.base.A.E;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D.Float;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Point2D.Float;
import twaver.TWaverUtil;
import twaver.base.A.D.C;
import twaver.base.A.I.B;

public class S
{
  public static int A(Point paramPoint1, Point paramPoint2, int paramInt)
  {
    int i = (int)D.A(paramPoint1, paramPoint2);
    return i > paramInt * 2 ? paramInt : i / 2;
  }
  
  public static int A(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / 2;
    if (paramInt1 % 2 == 0)
    {
      if (paramInt2 > i) {
        return (paramInt2 - i - 1) * 2;
      }
      return (i - paramInt2) * 2 + 1;
    }
    i++;
    if (paramInt2 <= i) {
      return (i - paramInt2) * 2;
    }
    return (paramInt2 - i) * 2 - 1;
  }
  
  public static int A(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    if (!paramBoolean) {
      paramInt1 = A(paramInt2, paramInt1 + 1);
    }
    int i = paramInt1;
    if (paramInt2 % 2 == 0) {
      i++;
    }
    i = (i + 1) / 2 * (i % 2 == 0 ? -1 : 1);
    int j = paramInt3 * i;
    if (paramInt2 % 2 == 0) {
      if (i > 0) {
        j -= paramInt3 / 4 + 2;
      } else {
        j += paramInt3 / 4 + 2;
      }
    }
    return j;
  }
  
  public static GeneralPath A(int paramInt1, int paramInt2, Rectangle paramRectangle)
  {
    int i = paramInt2 * (paramInt1 + 1);
    Arc2D.Float localFloat = new Arc2D.Float(paramRectangle.x - i, paramRectangle.y - i, i * 2, i * 2, 0.0F, 270.0F, 0);
    return new GeneralPath(localFloat);
  }
  
  public static GeneralPath C(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3, B paramB)
  {
    GeneralPath localGeneralPath1;
    if (paramInt1 == 2)
    {
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        localGeneralPath1 = new GeneralPath();
        localGeneralPath1.moveTo(paramC.F.x, paramC.F.y);
        localGeneralPath1.lineTo(paramC.B.x, paramC.B.y);
        localGeneralPath1.lineTo(paramC.D.x, paramC.D.y);
        localGeneralPath1.lineTo(paramC.E.x, paramC.E.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath1 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath1 = E(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath1;
    }
    Object localObject;
    if (paramInt1 == 4)
    {
      localGeneralPath1 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        Point localPoint1 = paramC.F;
        Point localPoint2 = paramC.B;
        Point localPoint3 = paramC.D;
        Point localPoint4 = paramC.E;
        int k = (int)(localPoint1.x + (localPoint4.x - localPoint1.x) * paramDouble);
        int m = (int)(localPoint1.y + (localPoint4.y - localPoint1.y) * paramDouble);
        localObject = new Point(k, m);
        localGeneralPath1.moveTo(localPoint1.x, localPoint1.y);
        localGeneralPath1.quadTo(localPoint2.x, localPoint2.y, ((Point)localObject).x, ((Point)localObject).y);
        localGeneralPath1.quadTo(localPoint3.x, localPoint3.y, localPoint4.x, localPoint4.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath1 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath1 = E(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath1;
    }
    if (paramInt1 == 3)
    {
      localGeneralPath1 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        localGeneralPath1.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath1.lineTo(paramPoint3.x, paramPoint3.y);
        localGeneralPath1.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath1 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath1 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath1;
    }
    if (paramInt1 == 5)
    {
      int j = paramPoint1.x > paramPoint2.x ? 1 : 0;
      double d1;
      if (paramPoint1.x >= paramPoint2.x) {
        d1 = TWaverUtil.getAngle(paramPoint1, paramPoint2);
      } else {
        d1 = TWaverUtil.getAngle(paramPoint2, paramPoint1);
      }
      if (d1 > 0.0D) {
        d1 += 0.7853981633974483D;
      } else {
        d1 -= 0.7853981633974483D;
      }
      double d2 = paramPoint1.x + (paramPoint2.x - paramPoint1.x) * paramDouble;
      double d3 = paramPoint1.y + (paramPoint2.y - paramPoint1.y) * paramDouble;
      localObject = new AffineTransform();
      ((AffineTransform)localObject).setTransform(1.0D, 0.0D, 0.0D, 1.0D, d2, d3);
      ((AffineTransform)localObject).rotate(d1);
      Point2D.Double localDouble1 = new Point2D.Double(paramInt4, 0.0D);
      Point2D.Double localDouble2 = new Point2D.Double();
      ((AffineTransform)localObject).transform(localDouble1, localDouble2);
      localObject = new AffineTransform();
      ((AffineTransform)localObject).setTransform(1.0D, 0.0D, 0.0D, 1.0D, d2, d3);
      ((AffineTransform)localObject).rotate(d1);
      localDouble1 = new Point2D.Double(-paramInt4, 0.0D);
      Point2D.Double localDouble3 = new Point2D.Double();
      ((AffineTransform)localObject).transform(localDouble1, localDouble3);
      GeneralPath localGeneralPath3 = new GeneralPath();
      localGeneralPath3.moveTo(paramPoint1.x, paramPoint1.y);
      if (j != 0)
      {
        localGeneralPath3.lineTo((int)localDouble3.getX(), (int)localDouble3.getY());
        localGeneralPath3.lineTo((int)localDouble2.getX(), (int)localDouble2.getY());
      }
      else
      {
        localGeneralPath3.lineTo((int)localDouble2.getX(), (int)localDouble2.getY());
        localGeneralPath3.lineTo((int)localDouble3.getX(), (int)localDouble3.getY());
      }
      localGeneralPath3.lineTo(paramPoint2.x, paramPoint2.y);
      return localGeneralPath3;
    }
    GeneralPath localGeneralPath2;
    int i;
    if (paramInt1 == 6)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = (int)(paramPoint1.x + (paramPoint2.x - paramPoint1.x) * paramDouble);
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint2.y);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (paramInt1 == 7)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = paramPoint1.y + (int)((paramPoint2.y - paramPoint1.y) * paramDouble);
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(paramPoint1.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (paramInt1 == 8)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = Math.min(paramPoint1.y - paramRectangle1.height / 2, paramPoint2.y - paramRectangle2.height / 2) - paramInt4;
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(paramPoint1.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (paramInt1 == 9)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = Math.max(paramPoint1.y + paramRectangle1.height / 2, paramPoint2.y + paramRectangle2.height / 2) + paramInt4;
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(paramPoint1.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, i);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (paramInt1 == 10)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = Math.min(paramPoint1.x - paramRectangle1.width / 2, paramPoint2.x - paramRectangle2.width / 2) - paramInt4;
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint2.y);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (paramInt1 == 11)
    {
      localGeneralPath2 = new GeneralPath();
      if ((paramInt3 <= 1) || (paramBoolean))
      {
        i = Math.max(paramPoint1.x + paramRectangle1.width / 2, paramPoint2.x + paramRectangle2.width / 2) + paramInt4;
        localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint1.y);
        localGeneralPath2.lineTo(i, paramPoint2.y);
        localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
      }
      else if (paramB.isLinkBundleCompact())
      {
        localGeneralPath2 = C(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
      }
      else
      {
        localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
      }
      return localGeneralPath2;
    }
    if (((paramInt3 <= 1) || (paramBoolean)) && (paramInt1 != 0))
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramPoint1.x, paramPoint1.y);
      localGeneralPath2.lineTo(paramPoint2.x, paramPoint2.y);
    }
    else
    {
      localGeneralPath2 = A(paramInt1, paramInt2, paramInt3, paramBoolean, paramPoint1, paramPoint2, paramB);
    }
    return localGeneralPath2;
  }
  
  public static GeneralPath A(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, Point paramPoint1, Point paramPoint2, B paramB)
  {
    if (!paramB.isLinkBundleAlternate())
    {
      paramInt2 = paramInt3 - paramInt2 - 1;
      if (((paramPoint1.x < paramPoint2.x) && (paramPoint1.y > paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y < paramPoint2.y)) || ((paramPoint2.x < paramPoint1.x) && (paramPoint2.y > paramPoint1.y)) || ((paramPoint2.x > paramPoint1.x) && (paramPoint2.y < paramPoint1.y))) {
        paramInt2 = paramInt3 - paramInt2 - 1;
      }
    }
    int i;
    int j;
    if (paramInt1 == 0)
    {
      i = A(paramPoint1, paramPoint2, paramB.getParallelLinkOffset());
      if ((paramInt3 <= 1) || (paramBoolean)) {
        j = 0;
      } else {
        j = A(paramInt2, paramInt3, paramB.getParallelLinkGap(), paramB.isLinkBundleAlternate());
      }
    }
    else
    {
      i = A(paramPoint1, paramPoint2, paramB.getStraightLinkOffset());
      j = A(paramInt2, paramInt3, paramB.getStraightLinkGap(), paramB.isLinkBundleAlternate());
    }
    Point localPoint1 = new Point((int)D.A(paramPoint1, paramPoint2), 0);
    Point localPoint2 = new Point(i, j);
    Point localPoint3 = new Point(localPoint1.x - i, j);
    if (paramPoint1.x > paramPoint2.x)
    {
      localPoint1.x = (-localPoint1.x);
      localPoint2.x = (-localPoint2.x);
      localPoint3.x = (-localPoint3.x);
    }
    if ((paramPoint1.x == paramPoint2.x) && (paramPoint1.y > paramPoint2.y))
    {
      localPoint2.y = (-localPoint2.y);
      localPoint3.y = (-localPoint3.y);
    }
    GeneralPath localGeneralPath = new GeneralPath();
    if (paramInt1 == 0)
    {
      localGeneralPath.moveTo(localPoint2.x, localPoint2.y);
      localGeneralPath.lineTo(localPoint1.x - localPoint2.x, localPoint2.y);
    }
    else
    {
      localGeneralPath.moveTo(0.0F, 0.0F);
      localGeneralPath.lineTo(localPoint2.x, localPoint2.y);
      localGeneralPath.lineTo(localPoint3.x, localPoint3.y);
      localGeneralPath.lineTo(localPoint1.x, localPoint1.y);
    }
    AffineTransform localAffineTransform = AffineTransform.getTranslateInstance(paramPoint1.x, paramPoint1.y);
    localAffineTransform.rotate(D.B(paramPoint1.getX(), paramPoint1.getY(), paramPoint2.getX(), paramPoint2.getY()));
    Shape localShape = localAffineTransform.createTransformedShape(localGeneralPath);
    if ((localShape instanceof GeneralPath)) {
      return (GeneralPath)localShape;
    }
    return new GeneralPath(localShape);
  }
  
  public static GeneralPath E(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3, B paramB)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = null;
    Point2D.Float localFloat2 = null;
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    float f1 = paramB.getParallelLinkGap();
    float f2 = f1 / 2.0F * i;
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    float f3 = k * f1 * j;
    int m;
    int n;
    Point localPoint;
    if ((paramC.C == 4) || (paramC.C == 2))
    {
      localFloat1 = new Point2D.Float(paramC.F.x, (float)(paramC.F.getY() - f3 + f2));
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localFloat2 = new Point2D.Float(paramC.E.x, paramC.E.y - f3 + f2);
      if (paramInt1 == 2)
      {
        localGeneralPath.lineTo((float)paramC.B.getX(), localFloat1.y);
        localGeneralPath.lineTo((float)paramC.D.getX(), localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 4)
      {
        m = (int)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble);
        n = (int)(localFloat1.y + (localFloat2.y - localFloat1.y) * paramDouble);
        localPoint = new Point(m, n);
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.quadTo((float)paramC.B.getX(), localFloat1.y, localPoint.x, localPoint.y);
        localGeneralPath.quadTo((float)paramC.D.getX(), localFloat2.y, localFloat2.x, localFloat2.y);
      }
    }
    else if ((paramC.C == 1) || (paramC.C == 3))
    {
      localFloat1 = new Point2D.Float(paramC.F.x - f3 + f2, (float)paramC.F.getY());
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localFloat2 = new Point2D.Float(paramC.E.x - f3 + f2, paramC.E.y);
      if (paramInt1 == 2)
      {
        localGeneralPath.lineTo(localFloat1.x, (float)paramC.B.getY());
        localGeneralPath.lineTo(localFloat2.x, (float)paramC.D.getY());
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 4)
      {
        m = (int)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble);
        n = (int)(localFloat1.y + (localFloat2.y - localFloat1.y) * paramDouble);
        localPoint = new Point(m, n);
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.quadTo(localFloat1.x, (float)paramC.B.getY(), localPoint.x, localPoint.y);
        localGeneralPath.quadTo(localFloat2.x, (float)paramC.D.getY(), localFloat2.x, localFloat2.y);
      }
    }
    return localGeneralPath;
  }
  
  public static GeneralPath A(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3, B paramB)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = B(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
    Point2D.Float localFloat2 = D(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3, paramB);
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    float f1 = paramB.getParallelLinkGap();
    float f2 = f1 / 2.0F * i;
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    float f3 = k * f1 * j;
    if (paramInt1 == 3)
    {
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localGeneralPath.lineTo(localFloat1.x, localFloat2.y);
      localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
    }
    else if (paramInt1 == 6)
    {
      float f4 = 0.0F;
      if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
        f4 = (float)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble - f2 + f3);
      } else {
        f4 = (float)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble + f2 - f3);
      }
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localGeneralPath.lineTo(f4, localFloat1.y);
      localGeneralPath.lineTo(f4, localFloat2.y);
      localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
    }
    else if (paramInt1 == 7)
    {
      int m = 0;
      if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
        m = (int)(paramPoint1.y + (int)((localFloat2.y - paramPoint1.y) * paramDouble) - f2 + f3);
      } else {
        m = (int)(paramPoint1.y + (int)((localFloat2.y - paramPoint1.y) * paramDouble) + f2 - f3);
      }
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localGeneralPath.lineTo(localFloat1.x, m);
      localGeneralPath.lineTo(localFloat2.x, m);
      localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
    }
    else
    {
      float f5;
      if (paramInt1 == 8)
      {
        f5 = 0.0F;
        if (paramPoint1.x < paramPoint2.x) {
          f5 = Math.min(paramPoint1.y - paramRectangle1.height / 2, paramPoint2.y - paramRectangle2.height / 2) - paramInt4 + f2 - f3;
        } else {
          f5 = Math.min(paramPoint1.y - paramRectangle1.height / 2, paramPoint2.y - paramRectangle2.height / 2) - paramInt4 - f2 + f3;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(localFloat1.x, f5);
        localGeneralPath.lineTo(localFloat2.x, f5);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 9)
      {
        f5 = 0.0F;
        if (paramPoint1.x < paramPoint2.x) {
          f5 = Math.max(paramPoint1.y + paramRectangle1.height / 2, paramPoint2.y + paramRectangle2.height / 2) + paramInt4 - f2 + f3;
        } else {
          f5 = Math.max(paramPoint1.y + paramRectangle1.height / 2, paramPoint2.y + paramRectangle2.height / 2) + paramInt4 + f2 - f3;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(localFloat1.x, f5);
        localGeneralPath.lineTo(localFloat2.x, f5);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 10)
      {
        f5 = 0.0F;
        if (paramPoint1.y < paramPoint2.y) {
          f5 = Math.min(paramPoint1.x - paramRectangle1.width / 2, paramPoint2.x - paramRectangle2.width / 2) - paramInt4 + f2 - f3;
        } else {
          f5 = Math.min(paramPoint1.x - paramRectangle1.width / 2, paramPoint2.x - paramRectangle2.width / 2) - paramInt4 - f2 + f3;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(f5, localFloat1.y);
        localGeneralPath.lineTo(f5, localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 11)
      {
        f5 = 0.0F;
        if (paramPoint1.y < paramPoint2.y) {
          f5 = Math.max(paramPoint1.x + paramRectangle1.width / 2, paramPoint2.x + paramRectangle2.width / 2) + paramInt4 - f2 + f3;
        } else {
          f5 = Math.max(paramPoint1.x + paramRectangle1.width / 2, paramPoint2.x + paramRectangle2.width / 2) + paramInt4 + f2 - f3;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(f5, localFloat1.y);
        localGeneralPath.lineTo(f5, localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
    }
    return localGeneralPath;
  }
  
  public static Point2D.Float B(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3, B paramB)
  {
    Point2D.Float localFloat = null;
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    float f1 = paramB.getParallelLinkGap();
    float f2 = f1 / 2.0F * i;
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    float f3 = k * f1 * j;
    if (paramInt1 == 3) {
      localFloat = new Point2D.Float(paramPoint1.x + f2 - f3, paramPoint1.y);
    } else if (paramInt1 == 6) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f2 - f3);
    } else if (paramInt1 == 7) {
      localFloat = new Point2D.Float(paramPoint1.x + f2 - f3, paramPoint1.y);
    } else if (paramInt1 == 8) {
      localFloat = new Point2D.Float(paramPoint1.x + f2 - f3, paramPoint1.y);
    } else if (paramInt1 == 9) {
      localFloat = new Point2D.Float(paramPoint1.x + f2 - f3, paramPoint1.y);
    } else if (paramInt1 == 10) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f2 - f3);
    } else if (paramInt1 == 11) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f2 - f3);
    }
    return localFloat;
  }
  
  public static Point2D.Float D(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3, B paramB)
  {
    Point2D.Float localFloat = null;
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    float f1 = paramB.getParallelLinkGap();
    float f2 = f1 / 2.0F * i;
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    float f3 = k * f1 * j;
    if (paramInt1 == 3)
    {
      if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
        localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f2 + f3);
      } else {
        localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y + f2 - f3);
      }
    }
    else if (paramInt1 == 6) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y + f2 - f3);
    } else if (paramInt1 == 7) {
      localFloat = new Point2D.Float(paramPoint2.x + f2 - f3, paramPoint2.y);
    } else if (paramInt1 == 8) {
      localFloat = new Point2D.Float(paramPoint2.x - f2 + f3, paramPoint2.y);
    } else if (paramInt1 == 9) {
      localFloat = new Point2D.Float(paramPoint2.x - f2 + f3, paramPoint2.y);
    } else if (paramInt1 == 10) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f2 + f3);
    } else if (paramInt1 == 11) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f2 + f3);
    }
    return localFloat;
  }
  
  public static GeneralPath A(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = null;
    Point2D.Float localFloat2 = null;
    float f1 = (float)paramRectangle1.getHeight();
    float f2 = (float)paramRectangle1.getWidth();
    float f3 = (float)paramRectangle2.getHeight();
    float f4 = (float)paramRectangle2.getWidth();
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    float f5;
    float f6;
    Point2D.Float localFloat3;
    Point2D.Float localFloat4;
    Point2D.Float localFloat5;
    Point2D.Float localFloat6;
    float f7;
    float f8;
    Point2D.Float localFloat7;
    if ((paramC.C == 4) || (paramC.C == 2))
    {
      f5 = f1 / paramInt3;
      f6 = f3 / paramInt3;
      localFloat1 = new Point2D.Float(paramC.F.x, paramC.F.y + f5 / 2.0F * i - k * f5 * j);
      localFloat2 = new Point2D.Float(paramC.E.x, paramC.E.y + f6 / 2.0F * i - k * f6 * j);
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      if (paramInt1 == 2)
      {
        localGeneralPath.lineTo((float)paramC.B.getX(), localFloat1.y);
        localGeneralPath.lineTo((float)paramC.D.getX(), localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 4)
      {
        localFloat3 = localFloat1;
        localFloat4 = new Point2D.Float((float)paramC.B.getX(), localFloat1.y);
        localFloat5 = new Point2D.Float((float)paramC.D.getX(), localFloat2.y);
        localFloat6 = localFloat2;
        localFloat4 = new Point2D.Float((float)paramC.B.getX(), localFloat1.y);
        localFloat5 = new Point2D.Float((float)paramC.D.getX(), localFloat2.y);
        f7 = (float)(localFloat3.x + (localFloat6.x - localFloat3.x) * paramDouble);
        f8 = (float)(localFloat3.y + (localFloat6.y - localFloat3.y) * paramDouble);
        localFloat7 = new Point2D.Float(f7, f8);
        localGeneralPath.moveTo(localFloat3.x, localFloat3.y);
        localGeneralPath.quadTo(localFloat4.x, localFloat4.y, localFloat7.x, localFloat7.y);
        localGeneralPath.quadTo(localFloat5.x, localFloat5.y, localFloat6.x, localFloat6.y);
      }
    }
    else if ((paramC.C == 1) || (paramC.C == 3))
    {
      f5 = f2 / paramInt3;
      f6 = f4 / paramInt3;
      localFloat1 = new Point2D.Float(paramC.F.x + f5 / 2.0F * i - k * f5 * j, paramC.F.y);
      localFloat2 = new Point2D.Float(paramC.E.x + f6 / 2.0F * i - k * f6 * j, paramC.E.y);
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      if (paramInt1 == 2)
      {
        localGeneralPath.lineTo(localFloat1.x, (float)paramC.B.getY());
        localGeneralPath.lineTo(localFloat2.x, (float)paramC.D.getY());
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 4)
      {
        localFloat3 = localFloat1;
        localFloat4 = new Point2D.Float((float)paramC.B.getX(), localFloat1.y);
        localFloat5 = new Point2D.Float((float)paramC.D.getX(), localFloat2.y);
        localFloat6 = localFloat2;
        localFloat4 = new Point2D.Float(localFloat1.x, (float)paramC.B.getY());
        localFloat5 = new Point2D.Float(localFloat2.x, (float)paramC.D.getY());
        f7 = (float)(localFloat3.x + (localFloat6.x - localFloat3.x) * paramDouble);
        f8 = (float)(localFloat3.y + (localFloat6.y - localFloat3.y) * paramDouble);
        localFloat7 = new Point2D.Float(f7, f8);
        localGeneralPath.moveTo(localFloat3.x, localFloat3.y);
        localGeneralPath.quadTo(localFloat4.x, localFloat4.y, localFloat7.x, localFloat7.y);
        localGeneralPath.quadTo(localFloat5.x, localFloat5.y, localFloat6.x, localFloat6.y);
      }
    }
    return localGeneralPath;
  }
  
  public static GeneralPath C(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    Point2D.Float localFloat1 = B(paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
    Point2D.Float localFloat2 = A(localFloat1, paramInt1, paramInt2, paramInt3, paramBoolean, paramDouble, paramInt4, paramPoint1, paramPoint2, paramRectangle1, paramRectangle2, paramC, paramPoint3);
    int i = paramRectangle1.height;
    int j = paramRectangle1.width;
    int k = paramRectangle2.height;
    int m = paramRectangle2.width;
    float f1 = 0.02F;
    int n = paramInt3 % 2 == 0 ? 1 : 0;
    int i1 = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      i1 = 0;
    }
    float f2 = Math.abs(localFloat2.x - localFloat1.x);
    float f3 = Math.abs(localFloat2.y - localFloat1.y);
    int i2 = paramInt2 % 2 == 0 ? -1 : 1;
    float f4 = i2 * f2 * f1 * i1;
    float f5 = i2 * f3 * f1 * i1;
    float f6 = f2 * f1 / 2.0F * n;
    float f7 = f3 * f1 / 2.0F * n;
    if (paramInt1 == 3)
    {
      localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
      localGeneralPath.lineTo(localFloat1.x, localFloat2.y);
      localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
    }
    else
    {
      float f8;
      if (paramInt1 == 6)
      {
        f8 = 0.0F;
        if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
          f8 = (float)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble - f6 + f4);
        } else {
          f8 = (float)(localFloat1.x + (localFloat2.x - localFloat1.x) * paramDouble + f6 - f4);
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 7)
      {
        f8 = 0.0F;
        if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
          f8 = (float)(localFloat1.y + (localFloat2.y - localFloat1.y) * paramDouble - f7 + f5);
        } else {
          f8 = (float)(localFloat1.y + (localFloat2.y - localFloat1.y) * paramDouble + f7 - f5);
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(localFloat1.x, f8);
        localGeneralPath.lineTo(localFloat2.x, f8);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 8)
      {
        f8 = 0.0F;
        if (paramPoint1.x <= paramPoint2.x) {
          f8 = Math.min(localFloat1.y - i / 2, localFloat2.y - k / 2) - paramInt4 + f7 - f5;
        } else {
          f8 = Math.min(localFloat1.y - i / 2, localFloat2.y - k / 2) - paramInt4 - f7 + f5;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(localFloat1.x, f8);
        localGeneralPath.lineTo(localFloat2.x, f8);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 9)
      {
        f8 = 0.0F;
        if (paramPoint1.x >= paramPoint2.x) {
          f8 = Math.max(localFloat1.y + i / 2, localFloat2.y + k / 2) + paramInt4 - f7 - f5;
        } else {
          f8 = Math.max(localFloat1.y + i / 2, localFloat2.y + k / 2) + paramInt4 + f7 + f5;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(localFloat1.x, f8);
        localGeneralPath.lineTo(localFloat2.x, f8);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 10)
      {
        f8 = 0.0F;
        if (paramPoint1.y < paramPoint2.y) {
          f8 = Math.min(localFloat1.x - j / 2, localFloat2.x - m / 2) - paramInt4 - f6 - f4;
        } else {
          f8 = Math.min(localFloat1.x - j / 2, localFloat2.x - m / 2) - paramInt4 + f6 + f4;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
      else if (paramInt1 == 11)
      {
        f8 = 0.0F;
        if (paramPoint1.y < paramPoint2.y) {
          f8 = Math.max(localFloat1.x + j / 2, localFloat2.x + m / 2) + paramInt4 - f6 + f4;
        } else {
          f8 = Math.max(localFloat1.x + j / 2, localFloat2.x + m / 2) + paramInt4 + f6 - f4;
        }
        localGeneralPath.moveTo(localFloat1.x, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat1.y);
        localGeneralPath.lineTo(f8, localFloat2.y);
        localGeneralPath.lineTo(localFloat2.x, localFloat2.y);
      }
    }
    return localGeneralPath;
  }
  
  public static Point2D.Float B(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3)
  {
    float f1 = (float)paramRectangle1.getHeight();
    float f2 = (float)paramRectangle1.getWidth();
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    Point2D.Float localFloat = null;
    float f3 = f2 / paramInt3;
    float f4 = f1 / paramInt3;
    if (paramInt1 == 3) {
      localFloat = new Point2D.Float(paramPoint1.x + f3 / 2.0F * i - k * f3 * j, paramPoint1.y);
    } else if (paramInt1 == 6) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f4 / 2.0F * i - k * f4 * j);
    } else if (paramInt1 == 7) {
      localFloat = new Point2D.Float(paramPoint1.x + f3 / 2.0F * i - k * f3 * j, paramPoint1.y);
    } else if (paramInt1 == 8) {
      localFloat = new Point2D.Float(paramPoint1.x + f3 / 2.0F * i - k * f3 * j, paramPoint1.y);
    } else if (paramInt1 == 9) {
      localFloat = new Point2D.Float(paramPoint1.x + f3 / 2.0F * i - k * f3 * j, paramPoint1.y);
    } else if (paramInt1 == 10) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f4 / 2.0F * i - k * f4 * j);
    } else if (paramInt1 == 11) {
      localFloat = new Point2D.Float(paramPoint1.x, paramPoint1.y + f4 / 2.0F * i - k * f4 * j);
    }
    return localFloat;
  }
  
  public static Point2D.Float A(Point2D.Float paramFloat, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, double paramDouble, int paramInt4, Point paramPoint1, Point paramPoint2, Rectangle paramRectangle1, Rectangle paramRectangle2, C paramC, Point paramPoint3)
  {
    float f1 = (float)paramRectangle2.getHeight();
    float f2 = (float)paramRectangle2.getWidth();
    float f3 = f2 / paramInt3;
    float f4 = f1 / paramInt3;
    Point2D.Float localFloat = null;
    int i = paramInt3 % 2 == 0 ? 1 : 0;
    int j = (paramInt2 - 1) / 2 + 1;
    if (paramInt2 == 0) {
      j = 0;
    }
    int k = paramInt2 % 2 == 0 ? -1 : 1;
    if (paramInt1 == 3)
    {
      if (((paramPoint1.x <= paramPoint2.x) && (paramPoint1.y <= paramPoint2.y)) || ((paramPoint1.x > paramPoint2.x) && (paramPoint1.y > paramPoint2.y))) {
        localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f4 / 2.0F * i + k * f4 * j);
      } else {
        localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y + f4 / 2.0F * i - k * f4 * j);
      }
    }
    else if (paramInt1 == 6) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y + f4 / 2.0F * i - k * f4 * j);
    } else if (paramInt1 == 7) {
      localFloat = new Point2D.Float(paramPoint2.x + f3 / 2.0F * i - k * f3 * j, paramPoint2.y);
    } else if (paramInt1 == 8) {
      localFloat = new Point2D.Float(paramPoint2.x - f3 / 2.0F * i + k * f3 * j, paramPoint2.y);
    } else if (paramInt1 == 9) {
      localFloat = new Point2D.Float(paramPoint2.x - f3 / 2.0F * i + k * f3 * j, paramPoint2.y);
    } else if (paramInt1 == 10) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f4 / 2.0F * i + k * f4 * j);
    } else if (paramInt1 == 11) {
      localFloat = new Point2D.Float(paramPoint2.x, paramPoint2.y - f4 / 2.0F * i + k * f4 * j);
    }
    return localFloat;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.S
 * JD-Core Version:    0.7.0.1
 */
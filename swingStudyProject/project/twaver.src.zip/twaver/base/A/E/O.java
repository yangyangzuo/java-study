package twaver.base.A.E;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.List;
import javax.swing.CellEditor;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.SwingUtilities;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import twaver.ComponentCallbackHandler;
import twaver.TUIManager;
import twaver.TWaverConst;
import twaver.base.A.A.A.D;

public final class O
{
  public static final FocusListener B = new FocusAdapter()
  {
    public void focusGained(FocusEvent paramAnonymousFocusEvent)
    {
      Object localObject = paramAnonymousFocusEvent.getSource();
      if ((localObject instanceof JTextField)) {
        ((JTextField)localObject).selectAll();
      }
    }
  };
  public static final ActionListener A = new ActionListener()
  {
    public void actionPerformed(ActionEvent paramAnonymousActionEvent)
    {
      Object localObject1 = paramAnonymousActionEvent.getSource();
      if ((localObject1 instanceof JTextField))
      {
        Object localObject2 = ((JTextField)localObject1).getClientProperty("CellEditor");
        if ((localObject2 instanceof CellEditor)) {
          ((CellEditor)localObject2).stopCellEditing();
        }
      }
    }
  };
  
  public static JFileChooser C()
  {
    JFileChooser localJFileChooser = new JFileChooser();
    List localList = D.getSupportableFormatNames();
    Object localObject = null;
    for (int i = 0; i < localList.size(); i++)
    {
      String str = (String)localList.get(i);
      k localk = new k(str);
      localJFileChooser.setFileFilter(localk);
      if ("png".equalsIgnoreCase(str)) {
        localObject = localk;
      }
    }
    if (localObject != null) {
      localJFileChooser.setFileFilter(localObject);
    }
    return localJFileChooser;
  }
  
  public static void C(JTextField paramJTextField)
  {
    paramJTextField.addFocusListener(B);
  }
  
  public static void B(JTextField paramJTextField)
  {
    paramJTextField.removeFocusListener(B);
  }
  
  public static void A(JTextField paramJTextField, CellEditor paramCellEditor)
  {
    paramJTextField.putClientProperty("CellEditor", paramCellEditor);
    paramJTextField.addActionListener(A);
  }
  
  public static void A(JTextField paramJTextField)
  {
    paramJTextField.putClientProperty("CellEditor", null);
    paramJTextField.removeActionListener(A);
  }
  
  public static void B()
  {
    A(TUIManager.getDefaultFont());
  }
  
  public static JButton D()
  {
    JButton localJButton = new JButton(C.B("/resource/image/table/dotdotdot.png"));
    localJButton.setMargin(TWaverConst.NONE_INSETS);
    return localJButton;
  }
  
  public static JButton A()
  {
    JButton localJButton = new JButton(C.B("/resource/image/table/setnull.png"));
    localJButton.setMargin(TWaverConst.NONE_INSETS);
    return localJButton;
  }
  
  public static void A(Font paramFont)
  {
    Enumeration localEnumeration = UIManager.getLookAndFeelDefaults().keys();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if ((UIManager.get(localObject) instanceof Font)) {
        UIManager.put(localObject, paramFont);
      }
    }
  }
  
  public static final Window B(Component paramComponent)
  {
    if (paramComponent == null) {
      return null;
    }
    if (((paramComponent instanceof Frame)) || ((paramComponent instanceof Dialog))) {
      return (Window)paramComponent;
    }
    return B(paramComponent.getParent());
  }
  
  public static boolean B(JViewport paramJViewport)
  {
    if (paramJViewport == null) {
      return false;
    }
    Dimension localDimension1 = paramJViewport.getSize();
    Dimension localDimension2 = paramJViewport.getViewSize();
    Component localComponent = paramJViewport.getView();
    boolean bool = true;
    if ((localComponent instanceof Scrollable)) {
      bool = !((Scrollable)localComponent).getScrollableTracksViewportWidth();
    }
    if ((bool) && (localDimension2.width <= localDimension1.width)) {
      bool = false;
    }
    return bool;
  }
  
  public static boolean C(JViewport paramJViewport)
  {
    if (paramJViewport == null) {
      return false;
    }
    Dimension localDimension1 = paramJViewport.getSize();
    Dimension localDimension2 = paramJViewport.getViewSize();
    Component localComponent = paramJViewport.getView();
    boolean bool = true;
    if ((localComponent instanceof Scrollable)) {
      bool = !((Scrollable)localComponent).getScrollableTracksViewportHeight();
    }
    if ((bool) && (localDimension2.height <= localDimension1.height)) {
      bool = false;
    }
    return bool;
  }
  
  public static boolean A(JViewport paramJViewport)
  {
    if (paramJViewport == null) {
      return false;
    }
    return (B(paramJViewport)) || (C(paramJViewport));
  }
  
  public static JPopupMenu A(Component paramComponent1, Component paramComponent2, Point paramPoint)
  {
    JPopupMenu localJPopupMenu = new JPopupMenu();
    localJPopupMenu.setLayout(new BorderLayout());
    localJPopupMenu.add(paramComponent1);
    localJPopupMenu.show(paramComponent2, paramPoint.x, paramPoint.y);
    localJPopupMenu.requestFocus();
    return localJPopupMenu;
  }
  
  public static int B(MouseEvent paramMouseEvent)
  {
    if (paramMouseEvent.getClickCount() == 1)
    {
      if (SwingUtilities.isLeftMouseButton(paramMouseEvent)) {
        return 1;
      }
      if (SwingUtilities.isRightMouseButton(paramMouseEvent)) {
        return 3;
      }
    }
    if (paramMouseEvent.getClickCount() == 2)
    {
      if (SwingUtilities.isLeftMouseButton(paramMouseEvent)) {
        return 2;
      }
      if (SwingUtilities.isRightMouseButton(paramMouseEvent)) {
        return 4;
      }
    }
    return -1;
  }
  
  public static void A(Window paramWindow)
  {
    Toolkit localToolkit = Toolkit.getDefaultToolkit();
    Dimension localDimension = localToolkit.getScreenSize();
    GraphicsConfiguration localGraphicsConfiguration = paramWindow.getGraphicsConfiguration();
    Insets localInsets = localToolkit.getScreenInsets(localGraphicsConfiguration);
    localDimension.width -= localInsets.left + localInsets.right;
    localDimension.height -= localInsets.top + localInsets.bottom;
    paramWindow.setSize(localDimension);
    paramWindow.setLocation(localInsets.left, localInsets.top);
  }
  
  public static final void A(Component paramComponent)
  {
    if (paramComponent == null) {
      return;
    }
    Dimension localDimension1 = paramComponent.getToolkit().getScreenSize();
    Dimension localDimension2 = paramComponent.getSize();
    GraphicsConfiguration localGraphicsConfiguration = paramComponent.getGraphicsConfiguration();
    Insets localInsets;
    if (localGraphicsConfiguration == null) {
      localInsets = paramComponent.getToolkit().getScreenInsets(localGraphicsConfiguration);
    } else {
      localInsets = TWaverConst.NONE_INSETS;
    }
    int i = localDimension1.height - localInsets.top - localInsets.bottom;
    int j = localDimension1.width - localInsets.left - localInsets.right;
    int k = (i - localDimension2.height) / 2 + localInsets.top;
    int m = (j - localDimension2.width) / 2 + localInsets.left;
    paramComponent.setLocation(m, k);
  }
  
  public static boolean A(MouseEvent paramMouseEvent)
  {
    return (!paramMouseEvent.isControlDown()) && (!paramMouseEvent.isShiftDown());
  }
  
  public static boolean C(MouseEvent paramMouseEvent)
  {
    return (paramMouseEvent.isControlDown()) && (paramMouseEvent.isShiftDown());
  }
  
  public static void A(Component paramComponent, ComponentCallbackHandler paramComponentCallbackHandler)
  {
    if (paramComponent == null) {
      return;
    }
    paramComponentCallbackHandler.processComponent(paramComponent);
    if ((paramComponent instanceof Container))
    {
      Container localContainer = (Container)paramComponent;
      for (int i = 0; i < localContainer.getComponentCount(); i++)
      {
        Component localComponent = localContainer.getComponent(i);
        A(localComponent, paramComponentCallbackHandler);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.O
 * JD-Core Version:    0.7.0.1
 */
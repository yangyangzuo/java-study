package twaver.base.A.E;

import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.util.List;
import twaver.AbstractElement;
import twaver.Element;
import twaver.TPropertyDescriptor;
import twaver.TWaverUtil;

public class U
{
  public static StringBuffer A(Element paramElement)
  {
    List localList = TWaverUtil.getAllBeanInfo(paramElement.getClass());
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<element>\n");
    for (int i = 0; i < localList.size(); i++)
    {
      BeanInfo localBeanInfo = (BeanInfo)localList.get(i);
      A(paramElement, localBeanInfo, localStringBuffer);
    }
    localStringBuffer.append("</element>");
    return localStringBuffer;
  }
  
  private static void A(Element paramElement, BeanInfo paramBeanInfo, StringBuffer paramStringBuffer)
  {
    PropertyDescriptor[] arrayOfPropertyDescriptor = paramBeanInfo.getPropertyDescriptors();
    if (arrayOfPropertyDescriptor != null) {
      for (int i = 0; i < arrayOfPropertyDescriptor.length; i++)
      {
        TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)arrayOfPropertyDescriptor[i];
        String str = localTPropertyDescriptor.getDisplayName();
        Object localObject = ((AbstractElement)paramElement).getPropertyValue(localTPropertyDescriptor);
        if ((localObject != null) && (str != null))
        {
          paramStringBuffer.append("<item>");
          paramStringBuffer.append("<propertyName><![CDATA[" + str + "]]></propertyName>\n");
          paramStringBuffer.append("<value><![CDATA[" + A(localObject, paramElement) + "]]></value>\n");
          paramStringBuffer.append("</item >\n");
        }
      }
    }
  }
  
  public static String A(Object paramObject, Element paramElement)
  {
    return paramObject.toString();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.U
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.ImageIcon;
import twaver.Element;
import twaver.Generator;
import twaver.TDataBox;
import twaver.TSubNetwork;
import twaver.TWaverUtil;
import twaver.base.A.H.D;
import twaver.web.TWebTree;
import twaver.web.WebUtil;

public class F
{
  private static final String A = "colorborder-";
  private static int B = n.B(1000);
  
  public static String A(TWebTree paramTWebTree, Element paramElement, boolean paramBoolean1, boolean paramBoolean2)
  {
    TDataBox localTDataBox = paramTWebTree.getDataBox();
    if (localTDataBox.isEmpty()) {
      return "[]";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = paramTWebTree.getWebImageUrlPrefix();
    if (str1 == null) {
      str1 = "";
    }
    String str2 = paramTWebTree.getWebImageFilePath();
    if (str2 == null) {
      str2 = "";
    }
    Object localObject;
    if (paramElement == null)
    {
      localObject = localTDataBox.getRootElements();
      localStringBuffer.append(B(paramTWebTree, (Collection)localObject, str1, str2));
    }
    else
    {
      if (((paramElement instanceof TSubNetwork)) && (paramElement.childrenSize() == 0))
      {
        localObject = (TSubNetwork)paramElement;
        localTDataBox.loadSubNetwork((TSubNetwork)localObject);
      }
      localStringBuffer.append("[");
      A(localStringBuffer, paramTWebTree, paramElement, str1, str2);
      localStringBuffer.append("]");
    }
    return localStringBuffer.toString();
  }
  
  private static void A(StringBuffer paramStringBuffer, TWebTree paramTWebTree, Element paramElement)
  {
    Generator localGenerator = paramTWebTree.getElementCustomAttributeGenerator();
    if (localGenerator != null)
    {
      Map localMap = (Map)localGenerator.generate(paramElement);
      if ((localMap != null) && (!localMap.isEmpty()))
      {
        Set localSet = localMap.keySet();
        Iterator localIterator = localSet.iterator();
        while (localIterator.hasNext())
        {
          Object localObject1 = localIterator.next();
          Object localObject2 = localMap.get(localObject1);
          paramStringBuffer.append(",\"" + localObject1 + "\":\"").append(localObject2).append("\"");
        }
      }
    }
  }
  
  private static void A(StringBuffer paramStringBuffer, TWebTree paramTWebTree, Element paramElement, String paramString1, String paramString2)
  {
    if (paramElement == null) {
      return;
    }
    String str1 = paramElement.getID().toString();
    String str2 = paramElement.getIconURL();
    Generator localGenerator = paramTWebTree.getElementBodyColorGenerator();
    Color localColor1 = localGenerator == null ? null : (Color)localGenerator.generate(paramElement);
    ImageIcon localImageIcon = TWaverUtil.getImageIcon(str2, localColor1);
    StringBuffer localStringBuffer = null;
    Object localObject3;
    if (localImageIcon != null)
    {
      localObject1 = new D(str2, localColor1);
      localObject2 = WebUtil.getImageID((D)localObject1);
      localStringBuffer = new StringBuffer(paramString1).append((String)localObject2);
      localObject3 = new StringBuffer(paramString2).append((String)localObject2);
      if (!paramTWebTree.isImageCache())
      {
        localObject3 = ((StringBuffer)localObject3).append(B);
        localStringBuffer.append(B);
      }
      localStringBuffer.append(".").append(WebUtil.IMAGE_FORMAT);
      ((StringBuffer)localObject3).append(".").append(WebUtil.IMAGE_FORMAT);
      N.A(localImageIcon.getImage(), ((StringBuffer)localObject3).toString(), WebUtil.IMAGE_FORMAT, true);
    }
    Object localObject1 = (String)paramTWebTree.getElementLabelGenerator().generate(paramElement);
    Object localObject2 = B(paramTWebTree, paramElement, paramString1, paramString2);
    paramStringBuffer.append("{");
    paramStringBuffer.append("\"text\":\"").append((String)localObject1).append("\",\"id\":\"").append(str1);
    if (localStringBuffer != null)
    {
      paramStringBuffer.append("\",\"icon\":\"").append(localStringBuffer);
      localObject3 = paramTWebTree.getElementStateOutlineColorGenerator();
      Color localColor2 = localObject3 == null ? null : (Color)((Generator)localObject3).generate(paramElement);
      if (localColor2 != null)
      {
        String str3 = L.A(localColor2, true);
        paramStringBuffer.append("\",\"iconCls\":\"").append("colorborder-").append(str3.substring(1, str3.length() - 1));
      }
    }
    paramStringBuffer.append("\"");
    A(paramStringBuffer, paramTWebTree, paramElement);
    if (localObject2 != null)
    {
      paramStringBuffer.append(",\"leaf\":").append("false").append("");
      paramStringBuffer.append(",").append((StringBuffer)localObject2);
    }
    else
    {
      paramStringBuffer.append(",\"leaf\":").append("true").append("");
    }
    paramStringBuffer.append(" }");
  }
  
  private static StringBuffer B(TWebTree paramTWebTree, Element paramElement, String paramString1, String paramString2)
  {
    if (!paramElement.isEmpty())
    {
      StringBuffer localStringBuffer1 = B(paramTWebTree, paramElement.getChildren(), paramString1, paramString2);
      if (localStringBuffer1 != null)
      {
        StringBuffer localStringBuffer2 = new StringBuffer();
        localStringBuffer2.append("\"children\":");
        localStringBuffer2.append(localStringBuffer1);
        return localStringBuffer2;
      }
    }
    return null;
  }
  
  private static StringBuffer B(TWebTree paramTWebTree, Collection paramCollection, String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if ((paramCollection == null) || (paramCollection.isEmpty())) {
      return localStringBuffer;
    }
    localStringBuffer.append("[");
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (paramTWebTree.isVisible(localElement))
      {
        A(localStringBuffer, paramTWebTree, localElement, paramString1, paramString2);
        localStringBuffer.append(",");
      }
    }
    if (localStringBuffer.length() > 1) {
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    localStringBuffer.append("]");
    return localStringBuffer;
  }
  
  public static String B(TWebTree paramTWebTree, Element paramElement, boolean paramBoolean1, boolean paramBoolean2)
  {
    TDataBox localTDataBox = paramTWebTree.getDataBox();
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = paramTWebTree.getWebImageUrlPrefix();
    if (str1 == null) {
      str1 = "";
    }
    String str2 = paramTWebTree.getWebImageFilePath();
    if (str2 == null) {
      str2 = "";
    }
    String str3 = localTDataBox.getName();
    String str4 = paramTWebTree.getDataBoxIconURL();
    str4 = A(str4, null, str1, str2);
    localStringBuffer.append("<object text=\"" + str3 + "\" icon=\"" + str4 + "\">");
    Object localObject;
    if (paramElement == null)
    {
      localObject = localTDataBox.getRootElements();
      localStringBuffer.append(A(paramTWebTree, (Collection)localObject, str1, str2));
    }
    else
    {
      if (((paramElement instanceof TSubNetwork)) && (paramElement.childrenSize() == 0))
      {
        localObject = (TSubNetwork)paramElement;
        localTDataBox.loadSubNetwork((TSubNetwork)localObject);
      }
      B(localStringBuffer, paramTWebTree, paramElement, str1, str2);
    }
    localStringBuffer.append("</object>");
    return localStringBuffer.toString();
  }
  
  private static StringBuffer A(TWebTree paramTWebTree, Element paramElement, String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (!paramElement.isEmpty()) {
      localStringBuffer.append(A(paramTWebTree, paramElement.getChildren(), paramString1, paramString2));
    }
    return localStringBuffer;
  }
  
  private static StringBuffer A(TWebTree paramTWebTree, Collection paramCollection, String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if ((paramCollection == null) || (paramCollection.isEmpty())) {
      return localStringBuffer;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (paramTWebTree.isVisible(localElement)) {
        B(localStringBuffer, paramTWebTree, localElement, paramString1, paramString2);
      }
    }
    return localStringBuffer;
  }
  
  private static String A(String paramString1, Color paramColor, String paramString2, String paramString3)
  {
    D localD = new D(paramString1, paramColor);
    String str1 = WebUtil.getImageID(localD);
    ImageIcon localImageIcon = TWaverUtil.getImageIcon(localD.B, localD.A);
    paramString1 = paramString2 + str1 + "." + WebUtil.IMAGE_FORMAT;
    String str2 = paramString3 + str1 + "." + WebUtil.IMAGE_FORMAT;
    N.A(localImageIcon.getImage(), str2, WebUtil.IMAGE_FORMAT, true);
    return paramString1;
  }
  
  private static void B(StringBuffer paramStringBuffer, TWebTree paramTWebTree, Element paramElement, String paramString1, String paramString2)
  {
    if (paramElement == null) {
      return;
    }
    String str1 = paramElement.getID().toString();
    String str2 = paramElement.getIconURL();
    Generator localGenerator1 = paramTWebTree.getElementBodyColorGenerator();
    Color localColor1 = localGenerator1 == null ? null : (Color)localGenerator1.generate(paramElement);
    str2 = A(str2, localColor1, paramString1, paramString2);
    String str3 = (String)paramTWebTree.getElementLabelGenerator().generate(paramElement);
    StringBuffer localStringBuffer = A(paramTWebTree, paramElement, paramString1, paramString2);
    Generator localGenerator2 = paramTWebTree.getElementStateOutlineColorGenerator();
    Color localColor2 = localGenerator2 == null ? null : (Color)localGenerator2.generate(paramElement);
    paramStringBuffer.append("<object id=\"" + str1 + "\" text=\"" + str3 + "\" icon=\"" + str2 + "\"");
    if (localColor2 != null)
    {
      str4 = L.A(localColor2, true);
      paramStringBuffer.append(" iconCls=\"colorborder-" + str4.substring(1, str4.length() - 1) + "\"");
    }
    paramStringBuffer.append(">");
    String str4 = localStringBuffer.toString();
    if (!"".equals(str4.trim())) {
      paramStringBuffer.append(str4);
    }
    paramStringBuffer.append("</object>");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.ImageIcon;
import twaver.BTS;
import twaver.BTSAntenna;
import twaver.Dummy;
import twaver.Element;
import twaver.Follower;
import twaver.Group;
import twaver.Link;
import twaver.MovableFilter;
import twaver.Node;
import twaver.PolyLine;
import twaver.TSubNetwork;
import twaver.TWaverUtil;
import twaver.network.ui.LinkUI;
import twaver.network.ui.PolyLineUI;

public final class V
{
  public static int H(Element paramElement)
  {
    ImageIcon localImageIcon = paramElement.getImage();
    if (localImageIcon != null) {
      return localImageIcon.getIconWidth();
    }
    return 40;
  }
  
  public static int A(Element paramElement)
  {
    ImageIcon localImageIcon = paramElement.getImage();
    if (localImageIcon != null) {
      return localImageIcon.getIconHeight();
    }
    return 40;
  }
  
  public static Rectangle E(Element paramElement)
  {
    double d1 = paramElement.getX();
    double d2 = paramElement.getY();
    int i = H(paramElement);
    int j = A(paramElement);
    return new e(d1, d2, i, j);
  }
  
  public static boolean D(Element paramElement)
  {
    if ((paramElement instanceof Group))
    {
      Iterator localIterator = paramElement.children();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        if ((!(localObject instanceof Link)) && (!(localObject instanceof Dummy))) {
          return true;
        }
      }
    }
    return false;
  }
  
  public static boolean D(Element paramElement1, Element paramElement2)
  {
    if ((paramElement1 == null) || (paramElement2 == null)) {
      return false;
    }
    return (paramElement1.isDescendantOf(paramElement2)) || (paramElement2.isDescendantOf(paramElement1));
  }
  
  public static boolean B(Element paramElement1, Element paramElement2)
  {
    if (((paramElement1 instanceof Follower)) && ((paramElement2 instanceof Follower)))
    {
      Follower localFollower1 = (Follower)paramElement1;
      Follower localFollower2 = (Follower)paramElement2;
      return (localFollower1.isHostOn(localFollower2)) && (localFollower2.isHostOn(localFollower1));
    }
    return false;
  }
  
  public static boolean C(Element paramElement1, Element paramElement2)
  {
    if (((paramElement1 instanceof Follower)) && ((paramElement2 instanceof Node))) {
      return ((Follower)paramElement1).isHostOn((Node)paramElement2);
    }
    return false;
  }
  
  public static boolean A(Element paramElement1, Element paramElement2)
  {
    if ((paramElement1 == null) || (!(paramElement2 instanceof Group))) {
      return false;
    }
    if (paramElement2.isEmpty()) {
      return false;
    }
    for (paramElement1 = paramElement1.getParent(); (paramElement1 instanceof Group); paramElement1 = paramElement1.getParent()) {
      if (paramElement1 == paramElement2) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean B(Element paramElement)
  {
    if (paramElement == null) {
      return false;
    }
    if ((paramElement instanceof PolyLine)) {
      return false;
    }
    return paramElement instanceof Link;
  }
  
  public static boolean A(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if ((paramObject instanceof PolyLineUI)) {
      return false;
    }
    return paramObject instanceof LinkUI;
  }
  
  public static void B(Element paramElement, List paramList)
  {
    Object localObject = null;
    while ((localObject = paramElement.getParent()) != null)
    {
      paramList.add(localObject);
      paramElement = (Element)localObject;
    }
  }
  
  public static void A(Element paramElement, List paramList)
  {
    Iterator localIterator = paramElement.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      paramList.add(localElement);
      A(localElement, paramList);
    }
  }
  
  public static final TSubNetwork G(Element paramElement)
  {
    if (paramElement == null) {
      return null;
    }
    if (((paramElement instanceof Link)) && (!(paramElement instanceof PolyLine)))
    {
      localObject = (Link)paramElement;
      Node localNode1 = ((Link)localObject).getFromAgent();
      Node localNode2 = ((Link)localObject).getToAgent();
      if ((localNode1 == null) || (localNode2 == null)) {
        return null;
      }
      TSubNetwork localTSubNetwork1 = TWaverUtil.getElementSubNetwork(localNode1);
      TSubNetwork localTSubNetwork2 = TWaverUtil.getElementSubNetwork(localNode2);
      if (localTSubNetwork1 == localTSubNetwork2) {
        return localTSubNetwork1;
      }
      return null;
    }
    if (paramElement.getParent() == null) {
      return null;
    }
    for (Object localObject = paramElement.getParent(); ((localObject instanceof Link)) && (!(localObject instanceof TSubNetwork)); localObject = ((Element)localObject).getParent()) {}
    if ((localObject instanceof TSubNetwork)) {
      return (TSubNetwork)localObject;
    }
    return G((Element)localObject);
  }
  
  public static void F(Element paramElement)
  {
    if ((paramElement == null) || ((paramElement instanceof Link)) || ((paramElement instanceof Dummy))) {
      return;
    }
    Element localElement = paramElement.getParent();
    if ((localElement instanceof Group)) {
      ((Group)localElement).invalidateGroupShape();
    }
  }
  
  public static void A(BTS paramBTS)
  {
    List localList = paramBTS.getAntennas();
    for (int i = 0; i < localList.size(); i++)
    {
      BTSAntenna localBTSAntenna = (BTSAntenna)localList.get(i);
      localBTSAntenna.invalidateAntennaShape();
    }
  }
  
  public static boolean C(Element paramElement)
  {
    if (!(paramElement instanceof Group)) {
      return false;
    }
    return (((Group)paramElement).isExpand()) && (D(paramElement));
  }
  
  public static synchronized List A(Iterator paramIterator, MovableFilter paramMovableFilter)
  {
    ArrayList localArrayList = new ArrayList();
    while (paramIterator.hasNext())
    {
      Element localElement1 = (Element)paramIterator.next();
      if ((!(localElement1 instanceof Link)) && (!(localElement1 instanceof Dummy)) && ((paramMovableFilter == null) || (paramMovableFilter.isMovable(localElement1)))) {
        if ((localElement1 instanceof Node))
        {
          int i = 1;
          Iterator localIterator = localArrayList.iterator();
          while (localIterator.hasNext())
          {
            Element localElement2 = (Element)localIterator.next();
            if ((i != 0) && (B(localElement1, localElement2))) {
              i = 0;
            } else if (C(localElement2, localElement1)) {
              localIterator.remove();
            } else if ((i != 0) && (C(localElement1, localElement2))) {
              i = 0;
            } else if (A(localElement2, localElement1)) {
              localIterator.remove();
            } else if ((i != 0) && (A(localElement1, localElement2))) {
              i = 0;
            }
          }
          if (i == 0) {}
        }
        else
        {
          localArrayList.add(localElement1);
        }
      }
    }
    return localArrayList;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.V
 * JD-Core Version:    0.7.0.1
 */
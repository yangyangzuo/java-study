package twaver.base.A.E;

import java.beans.BeanDescriptor;
import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import twaver.Element;
import twaver.ElementAttribute;
import twaver.TPropertyDescriptor;
import twaver.TUIManager;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.base.A.F.B.A;
import twaver.base.A.F.B.B;
import twaver.base.A.F.B.D;
import twaver.base.A.F.B.E;

public final class H
{
  public static Object A(Object paramObject, Method paramMethod, String paramString)
  {
    if ((paramObject == null) || (paramMethod == null)) {
      return null;
    }
    Object localObject = null;
    try
    {
      if ((paramMethod.getParameterTypes() == null) || (paramMethod.getParameterTypes().length == 0)) {
        localObject = paramMethod.invoke(paramObject, TWaverConst.EMPTY_PARAM_VALUE);
      } else {
        localObject = paramMethod.invoke(paramObject, new Object[] { paramString });
      }
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
    return localObject;
  }
  
  public static void A(Object paramObject1, Method paramMethod, String paramString, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramMethod == null)) {
      return;
    }
    try
    {
      if (paramMethod.getParameterTypes().length == 1) {
        paramMethod.invoke(paramObject1, new Object[] { paramObject2 });
      } else {
        paramMethod.invoke(paramObject1, new Object[] { paramString, paramObject2 });
      }
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
  }
  
  public static Method B(Class paramClass, String paramString)
  {
    Method localMethod = A(paramClass, paramString);
    if (localMethod == null) {
      localMethod = D(paramClass);
    }
    return localMethod;
  }
  
  public static Method B(Class paramClass1, String paramString, Class paramClass2)
  {
    Method localMethod = A(paramClass1, paramString, paramClass2);
    if (localMethod == null) {
      localMethod = A(paramClass1);
    }
    return localMethod;
  }
  
  public static Method A(Class paramClass, String paramString)
  {
    Method localMethod = null;
    if ((paramString == null) || (paramString.equals(""))) {
      throw new RuntimeException("Property Name of " + paramClass.getName() + " is Empty.");
    }
    String str = paramString.substring(0, 1).toUpperCase() + paramString.substring(1);
    try
    {
      localMethod = paramClass.getMethod("get" + str, TWaverConst.EMPTY_PARAM_CLASS);
    }
    catch (Exception localException1) {}
    if (localMethod == null) {
      try
      {
        localMethod = paramClass.getMethod("is" + str, TWaverConst.EMPTY_PARAM_CLASS);
      }
      catch (Exception localException2) {}
    }
    return localMethod;
  }
  
  public static Method A(Class paramClass1, String paramString, Class paramClass2)
  {
    Method localMethod = null;
    if ((paramString == null) || (paramString.equals(""))) {
      throw new RuntimeException("Property Name of " + paramClass1.getName() + " is Empty.");
    }
    String str = paramString.substring(0, 1).toUpperCase() + paramString.substring(1);
    try
    {
      localMethod = paramClass1.getMethod("set" + str, new Class[] { paramClass2 });
    }
    catch (Exception localException) {}
    return localMethod;
  }
  
  public static Method D(Class paramClass)
  {
    try
    {
      return paramClass.getMethod("getClientProperty", TWaverConst.CLIENT_PROPERTY_GETTER_METHOD_PARAM);
    }
    catch (Exception localException) {}
    return null;
  }
  
  public static Method A(Class paramClass)
  {
    try
    {
      return paramClass.getMethod("putClientProperty", TWaverConst.CLIENT_PROPERTY_SETTER_METHOD_PARAM);
    }
    catch (Exception localException) {}
    return null;
  }
  
  public static BeanInfo A(Class paramClass, List paramList)
  {
    if (paramList == null) {
      return null;
    }
    PropertyDescriptor[] arrayOfPropertyDescriptor = new PropertyDescriptor[paramList.size()];
    for (int i = 0; i < paramList.size(); i++)
    {
      ElementAttribute localElementAttribute = (ElementAttribute)paramList.get(i);
      arrayOfPropertyDescriptor[i] = A(paramClass, localElementAttribute);
    }
    BeanDescriptor localBeanDescriptor = new BeanDescriptor(paramClass);
    new SimpleBeanInfo()
    {
      private final PropertyDescriptor[] val$properties;
      
      public BeanDescriptor getBeanDescriptor()
      {
        return H.this;
      }
      
      public PropertyDescriptor[] getPropertyDescriptors()
      {
        return this.val$properties;
      }
    };
  }
  
  public static PropertyDescriptor A(Class paramClass, ElementAttribute paramElementAttribute)
  {
    try
    {
      if (paramElementAttribute.getUserPropertyKey() != null) {
        return new D(paramElementAttribute, paramClass);
      }
      if (paramElementAttribute.isBusinessProperty()) {
        return new E(paramElementAttribute);
      }
      if (paramElementAttribute.isClientProperty()) {
        return new A(paramElementAttribute, paramClass);
      }
      if (paramElementAttribute.getReadMethod() == null)
      {
        localObject = A(paramClass, paramElementAttribute.getName());
        if (localObject != null) {
          paramElementAttribute.setReadMethod(((Method)localObject).getName());
        }
      }
      Object localObject = null;
      if (paramElementAttribute.getReadMethod() != null) {
        try
        {
          Method localMethod1 = paramClass.getMethod(paramElementAttribute.getReadMethod(), TWaverConst.EMPTY_PARAM_CLASS);
          localObject = localMethod1.getReturnType();
          paramElementAttribute.setJavaClass((Class)localObject);
        }
        catch (Exception localException2) {}
      }
      if ((paramElementAttribute.getWriteMethod() == null) && (localObject != null))
      {
        Method localMethod2 = A(paramClass, paramElementAttribute.getName(), (Class)localObject);
        if (localMethod2 != null) {
          paramElementAttribute.setWriteMethod(localMethod2.getName());
        }
      }
      return new B(paramElementAttribute, paramElementAttribute.getName(), paramClass, paramElementAttribute.getReadMethod(), paramElementAttribute.getWriteMethod());
    }
    catch (Exception localException1)
    {
      TWaverUtil.handleError(null, localException1);
    }
    return null;
  }
  
  public static Class A(String paramString)
    throws ClassNotFoundException
  {
    if (TWaverUtil.classLoader == null) {
      return Class.forName(paramString);
    }
    return Class.forName(paramString, true, TWaverUtil.classLoader);
  }
  
  public static Object B(String paramString)
  {
    try
    {
      if ((paramString == null) || (paramString.trim().equals(""))) {
        return null;
      }
      int i = paramString.indexOf("@");
      if (i < 0) {
        return A(paramString).newInstance();
      }
      String str = paramString.substring(i + 1);
      paramString = paramString.substring(0, i);
      String[] arrayOfString = str.split("\\|");
      Class[] arrayOfClass = new Class[arrayOfString.length];
      for (int j = 0; j < arrayOfString.length; j++) {
        arrayOfClass[j] = String.class;
      }
      Class localClass = A(paramString);
      return localClass.getConstructor(arrayOfClass).newInstance(arrayOfString);
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError("Can not create new instance with class name '" + paramString + "'", localException);
    }
    return null;
  }
  
  public static Class A(String paramString1, String paramString2)
  {
    Class localClass = null;
    try
    {
      if (paramString1.startsWith("/")) {
        localClass = A(paramString1.substring(1));
      } else if ((paramString2 != null) && (paramString1.indexOf(".") == -1)) {
        localClass = A(paramString2 + "." + paramString1);
      }
    }
    catch (Exception localException1) {}
    if (localClass == null) {
      try
      {
        localClass = A(paramString1);
      }
      catch (Exception localException2) {}
    }
    if (localClass == null) {
      throw new RuntimeException("can not find class with the class name '" + paramString1 + "'");
    }
    return localClass;
  }
  
  public static String B(Class paramClass)
  {
    if (paramClass == null) {
      return null;
    }
    String str = paramClass.getName();
    return str.substring(str.lastIndexOf(".") + 1);
  }
  
  public static void A(Element paramElement, TPropertyDescriptor paramTPropertyDescriptor, Object paramObject)
    throws Exception
  {
    if ((paramElement == null) || (paramTPropertyDescriptor == null)) {
      return;
    }
    ElementAttribute localElementAttribute = paramTPropertyDescriptor.getElementAttribute();
    Object localObject1;
    Method localMethod;
    if (localElementAttribute.isBusinessProperty())
    {
      localObject1 = paramElement.getBusinessObject();
      if (localObject1 == null) {
        return;
      }
      Class localClass = localObject1.getClass();
      if (localElementAttribute.isClientProperty())
      {
        if (localElementAttribute.getWriteMethod() != null)
        {
          try
          {
            localMethod = localClass.getMethod(localElementAttribute.getWriteMethod(), TWaverConst.CLIENT_PROPERTY_SETTER_METHOD_PARAM);
          }
          catch (Exception localException1)
          {
            TWaverUtil.handleError("can not find '" + localElementAttribute.getWriteMethod() + "' method in " + localClass, localException1);
            return;
          }
        }
        else
        {
          localMethod = TWaverUtil.getBocpWriteMethod();
          if (localMethod == null) {
            localMethod = A(localClass);
          }
        }
      }
      else
      {
        localObject2 = localElementAttribute.getName();
        if (((String)localObject2).indexOf(".") > 0)
        {
          localObject3 = ((String)localObject2).split("\\.");
          localObject2 = localObject3[(localObject3.length - 1)];
          localObject1 = A(localObject1, (String[])localObject3);
          if (localObject1 == null) {
            return;
          }
          localClass = localObject1.getClass();
        }
        if (localElementAttribute.getReadMethod() != null) {
          try
          {
            localObject3 = localClass.getMethod(localElementAttribute.getReadMethod(), TWaverConst.EMPTY_PARAM_CLASS).getReturnType();
          }
          catch (Exception localException2)
          {
            TWaverUtil.handleError(null, localException2);
            return;
          }
        } else {
          localObject3 = A(localClass, (String)localObject2).getReturnType();
        }
        if (localElementAttribute.getWriteMethod() != null) {
          try
          {
            localMethod = localClass.getMethod(localElementAttribute.getWriteMethod(), new Class[] { localObject3 });
          }
          catch (Exception localException3)
          {
            TWaverUtil.handleError(null, localException3);
            return;
          }
        } else {
          localMethod = A(localClass, (String)localObject2, (Class)localObject3);
        }
      }
      Object localObject2 = A(paramElement, paramTPropertyDescriptor);
      A(localObject1, localMethod, localElementAttribute.getClientPropertyKey(), paramObject);
      Object localObject3 = A(paramElement, paramTPropertyDescriptor);
      paramElement.firePropertyChange(localElementAttribute.getKey(), localObject2, localObject3);
    }
    else
    {
      localObject1 = paramElement;
      localMethod = paramTPropertyDescriptor.getWriteMethod();
      if (localMethod == null) {
        return;
      }
      if (localElementAttribute.getUserPropertyKey() != null) {
        paramElement.putUserProperty(localElementAttribute.getUserPropertyKey(), paramObject);
      } else if (localElementAttribute.isClientProperty()) {
        paramElement.putClientProperty(localElementAttribute.getClientPropertyKey(), paramObject);
      } else {
        A(localObject1, localMethod, null, paramObject);
      }
    }
  }
  
  public static Object A(Object paramObject, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length - 1; i++)
    {
      if (paramObject == null) {
        break;
      }
      paramObject = A(paramObject, paramArrayOfString[i]);
    }
    return paramObject;
  }
  
  public static Object A(Object paramObject, String paramString)
  {
    if (paramObject == null) {
      return null;
    }
    Method localMethod = A(paramObject.getClass(), paramString);
    if (localMethod != null) {
      try
      {
        return localMethod.invoke(paramObject, TWaverConst.EMPTY_PARAM_VALUE);
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError(null, localException);
      }
    } else {
      throw new RuntimeException("can not find '" + paramString + "' read method in '" + paramObject + "'");
    }
    return null;
  }
  
  public static Object A(Element paramElement, TPropertyDescriptor paramTPropertyDescriptor)
    throws Exception
  {
    if ((paramElement == null) || (paramTPropertyDescriptor == null)) {
      return null;
    }
    ElementAttribute localElementAttribute = paramTPropertyDescriptor.getElementAttribute();
    Object localObject2;
    Object localObject3;
    if (localElementAttribute.isBusinessProperty())
    {
      localObject1 = paramElement.getBusinessObject();
      if (localObject1 == null) {
        return null;
      }
      localObject2 = localObject1.getClass();
      if (localElementAttribute.isClientProperty())
      {
        if (localElementAttribute.getReadMethod() != null)
        {
          try
          {
            localObject3 = ((Class)localObject2).getMethod(localElementAttribute.getReadMethod(), TWaverConst.CLIENT_PROPERTY_GETTER_METHOD_PARAM);
          }
          catch (Exception localException)
          {
            TWaverUtil.handleError("can not find '" + localElementAttribute.getReadMethod() + "' method in " + localObject2, localException);
            return null;
          }
        }
        else
        {
          localObject3 = TWaverUtil.getBocpReadMethod();
          if (localObject3 == null) {
            localObject3 = D((Class)localObject2);
          }
        }
        return ((Method)localObject3).invoke(localObject1, new Object[] { localElementAttribute.getClientPropertyKey() });
      }
      localObject3 = localElementAttribute.getName();
      if (((String)localObject3).indexOf(".") > 0)
      {
        localObject4 = ((String)localObject3).split("\\.");
        localObject3 = localObject4[(localObject4.length - 1)];
        localObject1 = A(localObject1, (String[])localObject4);
        if (localObject1 == null) {
          return null;
        }
        localObject2 = localObject1.getClass();
      }
      Object localObject4 = null;
      if (localElementAttribute.getReadMethod() != null) {
        localObject4 = ((Class)localObject2).getMethod(localElementAttribute.getReadMethod(), TWaverConst.EMPTY_PARAM_CLASS);
      } else {
        localObject4 = A((Class)localObject2, (String)localObject3);
      }
      return ((Method)localObject4).invoke(localObject1, TWaverConst.EMPTY_PARAM_VALUE);
    }
    Object localObject1 = paramTPropertyDescriptor.getReadMethod();
    if (localObject1 == null) {
      return null;
    }
    if (localElementAttribute.getUserPropertyKey() != null) {
      return paramElement.getUserProperty(localElementAttribute.getUserPropertyKey());
    }
    if (localElementAttribute.isClientProperty())
    {
      localObject2 = localElementAttribute.getClientPropertyKey();
      localObject3 = paramElement.getClientProperty(localObject2);
      if (localObject3 == null) {
        localObject3 = TUIManager.get((String)localObject2);
      }
      return localObject3;
    }
    return ((Method)localObject1).invoke(paramElement, TWaverConst.EMPTY_PARAM_VALUE);
  }
  
  public static Map C(Class paramClass)
  {
    HashMap localHashMap = new HashMap();
    Method[] arrayOfMethod = paramClass.getDeclaredMethods();
    for (int i = 0; i < arrayOfMethod.length; i++) {
      localHashMap.put(arrayOfMethod[i].getName(), arrayOfMethod[i]);
    }
    return localHashMap;
  }
  
  public static List A(List paramList)
  {
    LinkedList localLinkedList = new LinkedList();
    if (paramList != null)
    {
      HashMap localHashMap = new HashMap();
      for (int i = 0; i < paramList.size(); i++)
      {
        BeanInfo localBeanInfo = (BeanInfo)paramList.get(i);
        PropertyDescriptor[] arrayOfPropertyDescriptor = localBeanInfo.getPropertyDescriptors();
        if (arrayOfPropertyDescriptor != null) {
          for (int j = 0; j < arrayOfPropertyDescriptor.length; j++)
          {
            TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)arrayOfPropertyDescriptor[j];
            ElementAttribute localElementAttribute = localTPropertyDescriptor.getElementAttribute();
            Integer localInteger = (Integer)localHashMap.get(localElementAttribute.getKey());
            if (localInteger != null)
            {
              localLinkedList.remove(localInteger.intValue());
              localLinkedList.add(localInteger.intValue(), localTPropertyDescriptor);
            }
            else
            {
              localLinkedList.add(localTPropertyDescriptor);
              localHashMap.put(localElementAttribute.getKey(), TWaverUtil.valueOf(localLinkedList.size() - 1));
            }
          }
        }
      }
    }
    return localLinkedList;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.H
 * JD-Core Version:    0.7.0.1
 */
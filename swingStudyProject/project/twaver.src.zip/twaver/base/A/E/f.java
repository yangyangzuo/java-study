package twaver.base.A.E;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.RoundRectangle2D.Float;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.base.A.D.E;
import twaver.base.A.D.M;
import twaver.base.A.D.P;
import twaver.web.svg.network.SVGContext;
import twaver.web.svg.network.SVGStruct;
import twaver.web.svg.network.TSVGNetwork;
import twaver.web.svg.network.ui.ElementSVGUI;

public class f
{
  private static G E(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    Generator local1 = new Generator()
    {
      private final SVGContext val$context;
      
      public Object generate(Object paramAnonymousObject)
      {
        return f.this.getElementSVGUI((Element)paramAnonymousObject).toSVG(this.val$context).getBounds();
      }
    };
    return i.A(paramGroup, local1);
  }
  
  public static Rectangle D(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    Generator local2 = new Generator()
    {
      private final SVGContext val$context;
      
      public Object generate(Object paramAnonymousObject)
      {
        return f.this.getElementSVGUI((Element)paramAnonymousObject).toSVG(this.val$context).getBounds();
      }
    };
    return i.A(paramGroup, paramGroup.getGroupChildrenOutcrop(), paramGroup.getGroupInsets(), local2);
  }
  
  public static Ellipse2D A(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    Rectangle localRectangle = D(paramGroup, paramTSVGNetwork, paramSVGContext);
    if (localRectangle == null) {
      return null;
    }
    double d = Math.sqrt(localRectangle.width * localRectangle.width + localRectangle.height * localRectangle.height);
    return new Ellipse2D.Double(localRectangle.getCenterX() - d / 2.0D, localRectangle.getCenterY() - d / 2.0D, d, d);
  }
  
  public static RoundRectangle2D G(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    Rectangle localRectangle = D(paramGroup, paramTSVGNetwork, paramSVGContext);
    if (localRectangle == null) {
      return null;
    }
    int i = Math.min(localRectangle.width, localRectangle.height) / 4;
    if (i > 40) {
      i = 40;
    }
    return new RoundRectangle2D.Float(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, i, i);
  }
  
  public static M F(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    Ellipse2D localEllipse2D = B(paramGroup, paramTSVGNetwork, paramSVGContext);
    if (localEllipse2D == null) {
      return null;
    }
    return new M(localEllipse2D, paramGroup.getGroupDeep());
  }
  
  public static Ellipse2D B(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    G localG = E(paramGroup, paramTSVGNetwork, paramSVGContext);
    return i.A(localG, paramGroup.getGroupInsets());
  }
  
  public static P H(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    E localE = C(paramGroup, paramTSVGNetwork, paramSVGContext);
    if (localE == null) {
      return null;
    }
    return new P(localE, paramGroup.getGroupDeep());
  }
  
  public static E C(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    G localG = E(paramGroup, paramTSVGNetwork, paramSVGContext);
    return i.A(localG, paramGroup.getGroupAngle(), paramGroup.getGroupInsets());
  }
  
  public static Shape I(Group paramGroup, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext)
  {
    G localG = E(paramGroup, paramTSVGNetwork, paramSVGContext);
    return i.A(localG, paramGroup.getGroupInsets(), paramGroup);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.f
 * JD-Core Version:    0.7.0.1
 */
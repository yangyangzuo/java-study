package twaver.base.A.E;

import java.awt.Insets;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Float;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Double;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public final class D
{
  public static Ellipse2D A(Rectangle paramRectangle, List paramList)
  {
    int i = 3;
    Ellipse2D.Float localFloat = new Ellipse2D.Float(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    boolean bool;
    do
    {
      paramRectangle.x -= 3;
      paramRectangle.y -= 3;
      paramRectangle.width += 6;
      paramRectangle.height += 6;
      localFloat.setFrame(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
      bool = true;
      int j = paramList.size();
      for (int k = 0; k < j; k++)
      {
        Point2D localPoint2D = (Point2D)paramList.get(k);
        bool = localFloat.contains(localPoint2D.getX(), localPoint2D.getY());
        if (!bool) {
          break;
        }
      }
    } while (!bool);
    return localFloat;
  }
  
  public static Point A(Ellipse2D paramEllipse2D, Point paramPoint)
  {
    double d1 = paramEllipse2D.getCenterX();
    double d2 = paramEllipse2D.getCenterY();
    double d3 = paramPoint.x - d1;
    double d4 = paramPoint.y - d2;
    double d5 = paramEllipse2D.getWidth() / 2.0D;
    double d6 = paramEllipse2D.getHeight() / 2.0D;
    double d7 = Math.sqrt(1.0D / (1.0D / d5 / d5 + d4 * d4 / d3 / d3 / d6 / d6));
    if (d3 < 0.0D) {
      d7 = -d7;
    }
    double d8;
    if (d3 == 0.0D)
    {
      if (d4 > 0.0D) {
        d8 = d6;
      } else {
        d8 = -d6;
      }
    }
    else {
      d8 = d7 * d4 / d3;
    }
    return new Point((int)(d1 + d7), (int)(d2 + d8));
  }
  
  public static int A(Object[] paramArrayOfObject, Object paramObject)
  {
    if (paramArrayOfObject == null) {
      return -1;
    }
    for (int i = 0; i < paramArrayOfObject.length; i++)
    {
      if (paramArrayOfObject[i] == paramObject) {
        return i;
      }
      if ((paramArrayOfObject[i] != null) && (paramObject != null) && (paramArrayOfObject[i].equals(paramObject))) {
        return i;
      }
    }
    return -1;
  }
  
  private static Point2D A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8)
  {
    double d1 = (paramDouble2 - paramDouble4) / (paramDouble1 - paramDouble3);
    double d2 = (paramDouble1 * paramDouble4 - paramDouble3 * paramDouble2) / (paramDouble1 - paramDouble3);
    double d3 = (paramDouble6 - paramDouble8) / (paramDouble5 - paramDouble7);
    double d4 = (paramDouble5 * paramDouble8 - paramDouble7 * paramDouble6) / (paramDouble5 - paramDouble7);
    double d5 = 0.0D;
    double d6 = 0.0D;
    if ((paramDouble1 != paramDouble3) && (paramDouble5 != paramDouble7))
    {
      d5 = (d4 - d2) / (d1 - d3);
      d6 = d1 * d5 + d2;
    }
    else if ((paramDouble1 != paramDouble3) && (paramDouble5 == paramDouble7))
    {
      d5 = paramDouble5;
      d6 = d1 * d5 + d2;
    }
    else if ((paramDouble1 == paramDouble3) && (paramDouble5 != paramDouble7))
    {
      d5 = paramDouble1;
      d6 = d3 * d5 + d4;
    }
    return new Point2D.Double(d5, d6);
  }
  
  private static boolean A(Point2D paramPoint2D, Rectangle2D paramRectangle2D)
  {
    boolean bool = false;
    double d1 = paramRectangle2D.getX() - 0.1D;
    double d2 = paramRectangle2D.getY() - 0.1D;
    double d3 = d1 + paramRectangle2D.getWidth() + 0.5D;
    double d4 = d2 + paramRectangle2D.getHeight() + 0.5D;
    if ((paramPoint2D.getX() >= d1) && (paramPoint2D.getX() <= d3) && (paramPoint2D.getY() >= d2) && (paramPoint2D.getY() <= d4)) {
      bool = true;
    }
    return bool;
  }
  
  public static Point2D A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Rectangle2D paramRectangle2D)
  {
    double d1 = paramRectangle2D.getX();
    double d2 = paramRectangle2D.getY();
    double d3 = paramRectangle2D.getWidth();
    double d4 = paramRectangle2D.getHeight();
    double[] arrayOfDouble1 = { d1, d1 + d3, d1 + d3, d1 };
    double[] arrayOfDouble2 = { d2, d2, d2 + d4, d2 + d4 };
    double[] arrayOfDouble3 = { d1 + d3, d1 + d3, d1, d1 };
    double[] arrayOfDouble4 = { d2, d2 + d4, d2 + d4, d2 };
    Point2D localPoint2D = null;
    for (int i = 0; i < 4; i++)
    {
      localPoint2D = A(paramDouble1, paramDouble2, paramDouble3, paramDouble4, arrayOfDouble1[i], arrayOfDouble2[i], arrayOfDouble3[i], arrayOfDouble4[i]);
      if (localPoint2D != null)
      {
        if ((A(localPoint2D, paramRectangle2D)) && (localPoint2D.getX() <= Math.max(paramDouble1, paramDouble3)) && (localPoint2D.getX() >= Math.min(paramDouble1, paramDouble3)) && (localPoint2D.getY() <= Math.max(paramDouble2, paramDouble4)) && (localPoint2D.getY() >= Math.min(paramDouble2, paramDouble4))) {
          break;
        }
        localPoint2D = null;
      }
    }
    return localPoint2D;
  }
  
  public static double B(Point paramPoint1, Point paramPoint2)
  {
    if ((paramPoint1 == null) || (paramPoint2 == null)) {
      return 0.0D;
    }
    return B(paramPoint1.getX(), paramPoint1.getY(), paramPoint2.getX(), paramPoint2.getY());
  }
  
  public static double B(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    if (paramDouble1 == paramDouble3)
    {
      if (paramDouble4 == paramDouble2) {
        return 0.0D;
      }
      if (paramDouble4 > paramDouble2) {
        return 1.570796326794897D;
      }
      return -1.570796326794897D;
    }
    return Math.atan((paramDouble4 - paramDouble2) / (paramDouble3 - paramDouble1));
  }
  
  public static double A(Point2D paramPoint2D1, Point2D paramPoint2D2)
  {
    if ((paramPoint2D1 == null) || (paramPoint2D2 == null)) {
      return 0.0D;
    }
    return C(paramPoint2D1.getX(), paramPoint2D1.getY(), paramPoint2D2.getX(), paramPoint2D2.getY());
  }
  
  public static double C(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    double d1 = paramDouble3 - paramDouble1;
    double d2 = paramDouble4 - paramDouble2;
    return Math.sqrt(d1 * d1 + d2 * d2);
  }
  
  public static double A(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      return 0.0D;
    }
    return Math.sqrt(paramRectangle.width * paramRectangle.width + paramRectangle.height * paramRectangle.height);
  }
  
  public static Rectangle A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    Rectangle localRectangle = new Rectangle();
    localRectangle.x = ((int)(paramDouble1 < paramDouble3 ? paramDouble1 : paramDouble3));
    localRectangle.y = ((int)(paramDouble2 < paramDouble4 ? paramDouble2 : paramDouble4));
    localRectangle.width = ((int)Math.abs(paramDouble1 - paramDouble3));
    localRectangle.height = ((int)Math.abs(paramDouble2 - paramDouble4));
    return localRectangle;
  }
  
  public static Rectangle A(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    int i = paramList.size();
    Rectangle localRectangle = null;
    for (int j = 0; j < i; j++)
    {
      Point2D localPoint2D = (Point2D)paramList.get(j);
      if (localRectangle == null) {
        localRectangle = new Rectangle((int)localPoint2D.getX(), (int)localPoint2D.getY(), 0, 0);
      } else {
        localRectangle.add(localPoint2D);
      }
    }
    return localRectangle;
  }
  
  public static Rectangle A(Point paramPoint1, Point paramPoint2)
  {
    if ((paramPoint1 == null) || (paramPoint2 == null)) {
      return null;
    }
    return A(paramPoint1.x, paramPoint1.y, paramPoint2.x, paramPoint2.y);
  }
  
  public static int A(Object[] paramArrayOfObject, Object paramObject, Comparator paramComparator)
  {
    int i = Arrays.binarySearch(paramArrayOfObject, paramObject, paramComparator);
    if (i < 0) {
      i = -i - 1;
    }
    return i;
  }
  
  public static void A(Rectangle paramRectangle1, Rectangle paramRectangle2, Rectangle paramRectangle3)
  {
    if ((paramRectangle2 == null) || (paramRectangle3 == null)) {
      return;
    }
    double d1 = paramRectangle1.x - paramRectangle2.x;
    double d2 = paramRectangle1.y - paramRectangle2.y;
    double d3 = paramRectangle3.width / paramRectangle2.width;
    double d4 = paramRectangle3.height / paramRectangle2.height;
    paramRectangle3.x += (int)(d1 * d3);
    paramRectangle3.y += (int)(d2 * d4);
    paramRectangle1.width = ((int)(paramRectangle1.width * d3));
    paramRectangle1.height = ((int)(paramRectangle1.height * d4));
  }
  
  public static boolean A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7)
  {
    if (paramDouble7 < 0.0D) {
      paramDouble7 = 0.0D;
    }
    Line2D.Double localDouble = new Line2D.Double(paramDouble3, paramDouble4, paramDouble5, paramDouble6);
    return (localDouble.ptLineDist(paramDouble1, paramDouble2) <= paramDouble7) && (paramDouble1 >= Math.min(paramDouble3, paramDouble5) - paramDouble7) && (paramDouble1 <= Math.max(paramDouble3, paramDouble5) + paramDouble7) && (paramDouble2 >= Math.min(paramDouble4, paramDouble6) - paramDouble7) && (paramDouble2 <= Math.max(paramDouble4, paramDouble6) + paramDouble7);
  }
  
  public static int A(int paramInt, Rectangle paramRectangle1, Rectangle paramRectangle2)
  {
    int i = (int)(paramRectangle2.getCenterX() - paramRectangle1.getCenterX());
    int j = (int)(paramRectangle2.getCenterY() - paramRectangle1.getCenterY());
    int k;
    if ((i >= 0) && (Math.abs(j) <= Math.abs(i)))
    {
      k = 2 * paramInt + paramRectangle1.width / 2 + paramRectangle2.width / 2;
      if (i < k)
      {
        if (j > 0) {
          return 1;
        }
        return 3;
      }
      return 4;
    }
    if ((i <= 0) && (Math.abs(j) <= Math.abs(i)))
    {
      k = 2 * paramInt + paramRectangle1.width / 2 + paramRectangle2.width / 2;
      if (Math.abs(i) < k)
      {
        if (j > 0) {
          return 1;
        }
        return 3;
      }
      return 2;
    }
    if ((j >= 0) && (Math.abs(i) <= Math.abs(j)))
    {
      k = 2 * paramInt + paramRectangle1.height / 2 + paramRectangle2.height / 2;
      if (j < k)
      {
        if (i < 0) {
          return 4;
        }
        return 2;
      }
      return 3;
    }
    if ((j <= 0) && (Math.abs(i) <= Math.abs(j)))
    {
      k = 2 * paramInt + paramRectangle1.height / 2 + paramRectangle2.height / 2;
      if (Math.abs(j) < k)
      {
        if (i < 0) {
          return 4;
        }
        return 2;
      }
      return 1;
    }
    return 1;
  }
  
  public static int B(int paramInt, Rectangle paramRectangle1, Rectangle paramRectangle2)
  {
    int i = (int)(paramRectangle1.getCenterX() - paramRectangle2.getCenterX());
    int j = (int)(paramRectangle1.getCenterY() - paramRectangle2.getCenterY());
    int k;
    if ((i >= 0) && (Math.abs(j) <= Math.abs(i)))
    {
      k = 2 * paramInt + paramRectangle1.width / 2 + paramRectangle2.width / 2;
      if (i < k)
      {
        if (j < 0) {
          return 1;
        }
        return 3;
      }
      return 4;
    }
    if ((i <= 0) && (Math.abs(j) <= Math.abs(i)))
    {
      k = 2 * paramInt + paramRectangle1.width / 2 + paramRectangle2.width / 2;
      if (Math.abs(i) < k)
      {
        if (j < 0) {
          return 1;
        }
        return 3;
      }
      return 2;
    }
    if ((j >= 0) && (Math.abs(i) <= Math.abs(j)))
    {
      k = 2 * paramInt + paramRectangle1.height / 2 + paramRectangle2.height / 2;
      if (j < k)
      {
        if (i > 0) {
          return 4;
        }
        return 2;
      }
      return 3;
    }
    if ((j <= 0) && (Math.abs(i) <= Math.abs(j)))
    {
      k = 2 * paramInt + paramRectangle1.height / 2 + paramRectangle2.height / 2;
      if (Math.abs(j) < k)
      {
        if (i > 0) {
          return 4;
        }
        return 2;
      }
      return 1;
    }
    return 1;
  }
  
  public static Polygon A(Rectangle paramRectangle, int paramInt, Insets paramInsets)
  {
    int i = (int)(paramInt * Math.sin(0.7853981633974483D));
    int j;
    if (paramRectangle.width < 2 * i)
    {
      j = i - paramRectangle.width / 2;
      paramRectangle.width = (2 * i);
      paramRectangle.x -= j;
    }
    if (paramRectangle.height < 2 * i)
    {
      j = i - paramRectangle.height / 2;
      paramRectangle.height = (2 * i);
      paramRectangle.y -= j;
    }
    Polygon localPolygon = new Polygon();
    int k = paramRectangle.x;
    int m = paramRectangle.y;
    int n = paramRectangle.x + paramRectangle.width;
    int i1 = paramRectangle.y + paramRectangle.height;
    if (paramInsets != null)
    {
      k -= paramInsets.left;
      m -= paramInsets.top;
      n += paramInsets.right;
      i1 += paramInsets.bottom;
    }
    if (n - k < paramInt * 1.42D / 2.0D) {
      n = (int)(n + paramInt * 1.42D / 2.0D);
    }
    if (i1 - m < paramInt * 1.42D / 2.0D) {
      i1 = (int)(i1 + paramInt * 1.42D / 2.0D);
    }
    Point[] arrayOfPoint = new Point[8];
    arrayOfPoint[0] = new Point(k, m + i);
    arrayOfPoint[1] = new Point(k + i, m);
    arrayOfPoint[2] = new Point(n - i, m);
    arrayOfPoint[3] = new Point(n, m + i);
    arrayOfPoint[4] = new Point(n, i1 - i);
    arrayOfPoint[5] = new Point(n - i, i1);
    arrayOfPoint[6] = new Point(k + i, i1);
    arrayOfPoint[7] = new Point(k, i1 - i);
    for (int i2 = 0; i2 < arrayOfPoint.length; i2++) {
      localPolygon.addPoint(arrayOfPoint[i2].x, arrayOfPoint[i2].y);
    }
    return localPolygon;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.D
 * JD-Core Version:    0.7.0.1
 */
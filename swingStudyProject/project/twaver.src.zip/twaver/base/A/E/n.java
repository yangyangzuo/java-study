package twaver.base.A.E;

import java.awt.Color;
import java.awt.Point;
import java.util.Random;

public final class n
{
  public static Random A = new Random();
  
  public static double A()
  {
    return A.nextDouble();
  }
  
  public static float D()
  {
    return A.nextFloat();
  }
  
  public static long F()
  {
    return A.nextLong();
  }
  
  public static double C()
  {
    return A.nextGaussian();
  }
  
  public static int B(int paramInt)
  {
    return A.nextInt(paramInt);
  }
  
  public static Point A(int paramInt)
  {
    return new Point(A.nextInt(paramInt), A.nextInt(paramInt));
  }
  
  public static Color E()
  {
    return new Color(A.nextInt(255), A.nextInt(255), A.nextInt(255));
  }
  
  public static Color H()
  {
    return new Color(A.nextInt(255), A.nextInt(255), A.nextInt(255), A.nextInt(255));
  }
  
  public static boolean B()
  {
    return A.nextBoolean();
  }
  
  public static Boolean G()
  {
    return Boolean.valueOf(A.nextBoolean());
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.n
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.beans.DefaultPersistenceDelegate;
import java.beans.Encoder;
import java.beans.ExceptionListener;
import java.beans.PersistenceDelegate;
import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import twaver.AbstractElement;
import twaver.Alarm;
import twaver.AlarmModel;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.DataBoxContext;
import twaver.DataBoxOutputSetting;
import twaver.Element;
import twaver.ElementPersistentFilter;
import twaver.Layer;
import twaver.LayerModel;
import twaver.PersistenceManager;
import twaver.TDataBox;
import twaver.TWaverUtil;
import twaver.XMLInterceptor;
import twaver.base.A.F.D.A;
import twaver.base.A.F.D.E;
import twaver.base.A.F.D.I;
import twaver.base.A.F.D.J;
import twaver.base.A.F.D.L;
import twaver.base.A.F.G;

public class P
{
  private static ThreadLocal C = new ThreadLocal();
  private static final E A = new E();
  private static final E E = new E(new String[] { "alarmID" });
  private static final A B = new A();
  private static ExceptionListener D = new ExceptionListener()
  {
    public void exceptionThrown(Exception paramAnonymousException)
    {
      TWaverUtil.handleError(null, paramAnonymousException);
    }
  };
  
  public static boolean A()
  {
    return C.get() != null;
  }
  
  private static boolean A(XMLEncoder paramXMLEncoder, Element paramElement, ElementPersistentFilter paramElementPersistentFilter)
  {
    if (paramXMLEncoder.getPersistenceDelegate(paramElement.getClass()) == PersistenceManager.TRANSIENT_DELEGATE) {
      return false;
    }
    return (paramElementPersistentFilter == null) || (!paramElementPersistentFilter.isTransient(paramElement));
  }
  
  private static void A(XMLEncoder paramXMLEncoder, Element paramElement, TDataBox paramTDataBox, ElementPersistentFilter paramElementPersistentFilter)
  {
    if (paramTDataBox.contains(paramElement))
    {
      if (A(paramXMLEncoder, paramElement, paramElementPersistentFilter)) {
        paramXMLEncoder.writeObject(paramElement);
      }
      Iterator localIterator = paramElement.getChildren().iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        A(paramXMLEncoder, localElement, paramTDataBox, paramElementPersistentFilter);
      }
    }
  }
  
  public static void A(TDataBox paramTDataBox, DataBoxOutputSetting paramDataBoxOutputSetting)
    throws IOException
  {
    OutputStream localOutputStream = paramDataBoxOutputSetting.getOutputStream();
    ElementPersistentFilter localElementPersistentFilter = paramDataBoxOutputSetting.getElementFilter();
    if (localOutputStream == null) {
      throw new NullPointerException("outputStream can't be null.");
    }
    if (paramTDataBox == null) {
      throw new NullPointerException("box can't be null.");
    }
    C.set(paramTDataBox);
    if (TWaverUtil.getXMLInterceptor() != null) {
      TWaverUtil.getXMLInterceptor().beforeWrite(paramTDataBox, paramDataBoxOutputSetting);
    }
    BufferedOutputStream local2 = new BufferedOutputStream(localOutputStream)
    {
      public void close()
        throws IOException
      {
        flush();
      }
    };
    XMLEncoder localXMLEncoder = new XMLEncoder(local2);
    localXMLEncoder.setExceptionListener(D);
    Object localObject1 = null;
    if (paramDataBoxOutputSetting.isWithElementId()) {
      localObject1 = new DefaultPersistenceDelegate(new String[] { "ID" })
      {
        private final XMLEncoder val$encoder;
        private final ElementPersistentFilter val$elementFilter;
        
        public void writeObject(Object paramAnonymousObject, Encoder paramAnonymousEncoder)
        {
          Element localElement = (Element)paramAnonymousObject;
          if (P.A(this.val$encoder, localElement, this.val$elementFilter)) {
            super.writeObject(localElement, paramAnonymousEncoder);
          }
        }
      };
    } else {
      localObject1 = new DefaultPersistenceDelegate()
      {
        private final ElementPersistentFilter val$elementFilter;
        
        public void writeObject(Object paramAnonymousObject, Encoder paramAnonymousEncoder)
        {
          Element localElement = (Element)paramAnonymousObject;
          if (P.A(P.this, localElement, this.val$elementFilter)) {
            super.writeObject(localElement, paramAnonymousEncoder);
          }
        }
      };
    }
    localXMLEncoder.setPersistenceDelegate(AbstractElement.class, new L(paramDataBoxOutputSetting));
    localXMLEncoder.setPersistenceDelegate(AlarmSeverity.class, B);
    if (paramDataBoxOutputSetting.isWithAlarmId()) {
      localXMLEncoder.setPersistenceDelegate(Alarm.class, E);
    } else {
      localXMLEncoder.setPersistenceDelegate(Alarm.class, A);
    }
    if (paramDataBoxOutputSetting.isWithAlarmState()) {
      localXMLEncoder.setPersistenceDelegate(AlarmState.class, PersistenceManager.DEFAULT_DElEGATE);
    } else {
      localXMLEncoder.setPersistenceDelegate(AlarmState.class, PersistenceManager.TRANSIENT_DELEGATE);
    }
    J.A().A(localXMLEncoder);
    I.A().A(localXMLEncoder);
    Iterator localIterator = paramTDataBox.iterator();
    while (localIterator.hasNext())
    {
      localObject2 = localIterator.next();
      if (localXMLEncoder.getPersistenceDelegate(localObject2.getClass()) != localObject1) {
        localXMLEncoder.setPersistenceDelegate(localObject2.getClass(), (PersistenceDelegate)localObject1);
      }
    }
    G.A().A(localXMLEncoder);
    Object localObject2 = new DataBoxContext();
    Object localObject3;
    if (paramDataBoxOutputSetting.isWithDataBoxName())
    {
      localObject3 = paramTDataBox.getName();
      if ((localObject3 != null) && (!((String)localObject3).equals("DataBox"))) {
        ((DataBoxContext)localObject2).setName((String)localObject3);
      }
    }
    ((DataBoxContext)localObject2).setImages(paramDataBoxOutputSetting.getImages());
    if (paramDataBoxOutputSetting.isWithDataBoxID()) {
      ((DataBoxContext)localObject2).setID(paramTDataBox.getID());
    }
    if (paramDataBoxOutputSetting.isWithDataBoxBackground()) {
      ((DataBoxContext)localObject2).setBackground(paramTDataBox.getBackground());
    }
    if ((paramDataBoxOutputSetting.isWithDataBoxVersion()) && (paramTDataBox.getVersion() != null)) {
      ((DataBoxContext)localObject2).setVersion("#VERSION{" + paramTDataBox.getVersion() + "}VERSION#");
    }
    if ((((DataBoxContext)localObject2).getName() != null) || (((DataBoxContext)localObject2).getBackground() != null) || (((DataBoxContext)localObject2).getVersion() != null) || (((DataBoxContext)localObject2).getID() != null) || (((DataBoxContext)localObject2).getImages() != null)) {
      localXMLEncoder.writeObject(localObject2);
    }
    if (paramDataBoxOutputSetting.isWithDataBoxClientProperty())
    {
      localIterator = paramTDataBox.getClientProperties().keySet().iterator();
      while (localIterator.hasNext())
      {
        localObject3 = localIterator.next();
        Object localObject4 = paramTDataBox.getClientProperty(localObject3);
        if (((localObject3 instanceof String)) && (localObject4 != null))
        {
          localXMLEncoder.writeObject(localObject3);
          localXMLEncoder.writeObject(localObject4);
        }
      }
    }
    localIterator = paramTDataBox.getRootElements().iterator();
    while (localIterator.hasNext())
    {
      localObject3 = localIterator.next();
      A(localXMLEncoder, (Element)localObject3, paramTDataBox, localElementPersistentFilter);
    }
    if (paramDataBoxOutputSetting.isWithAlarm())
    {
      localIterator = paramTDataBox.getAlarmModel().iterator();
      while (localIterator.hasNext())
      {
        localObject3 = (Alarm)localIterator.next();
        localXMLEncoder.writeObject(localObject3);
      }
    }
    if (paramDataBoxOutputSetting.isWithLayers())
    {
      localIterator = paramTDataBox.getLayerModel().iterator();
      while (localIterator.hasNext())
      {
        localObject3 = (Layer)localIterator.next();
        localXMLEncoder.writeObject(localObject3);
      }
    }
    localXMLEncoder.close();
    if (TWaverUtil.getXMLInterceptor() != null) {
      TWaverUtil.getXMLInterceptor().afterWrite(paramTDataBox, paramDataBoxOutputSetting);
    }
    C.set(null);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.P
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.E;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D.Float;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D.Float;
import java.util.ArrayList;
import java.util.List;
import twaver.Link;
import twaver.Node;
import twaver.ShapeLink;
import twaver.TWaverConst;
import twaver.network.ui.LinkUI;

public class R
{
  public static AffineTransform L = new AffineTransform();
  public static final GeneralPath M;
  public static final GeneralPath K;
  public static final GeneralPath S;
  public static final GeneralPath R;
  public static final Shape F = new Ellipse2D.Float(-12.0F, -6.0F, 12.0F, 12.0F);
  public static final Shape D;
  public static final Shape O = new Rectangle2D.Float(-12.0F, -6.0F, 12.0F, 12.0F);
  public static final Shape U;
  public static final Shape I;
  public static final Shape P;
  public static final Shape B;
  public static final Shape T;
  public static final Shape N;
  public static final Shape E = A(0.6D, O);
  public static final Shape J;
  public static final Shape A;
  public static final Shape G;
  public static final Shape Q;
  public static final Shape H;
  public static final Shape C;
  public static final Shape V = A(1.5D, O);
  
  static
  {
    M = A();
    M.lineTo(-12.0F, -5.0F);
    M.lineTo(-9.0F, 0.0F);
    M.lineTo(-12.0F, 5.0F);
    M.closePath();
    K = A();
    K.lineTo(-12.0F, -5.0F);
    K.lineTo(-12.0F, 5.0F);
    K.closePath();
    S = A();
    S.lineTo(-7.0F, 5.0F);
    S.lineTo(-14.0F, 0.0F);
    S.lineTo(-7.0F, -5.0F);
    S.closePath();
    R = A();
    R.lineTo(-8.0F, -6.0F);
    R.lineTo(-5.0F, 0.0F);
    R.lineTo(-8.0F, 6.0F);
    R.closePath();
    GeneralPath localGeneralPath = new GeneralPath();
    for (int i = 0; i < 8; i++)
    {
      int j = (int)(8.0D * Math.cos(Math.toRadians(45 * i))) - 4;
      int k = (int)(8.0D * Math.sin(Math.toRadians(45 * i)));
      if (i == 0) {
        localGeneralPath.moveTo(j, k);
      } else {
        localGeneralPath.lineTo(j, k);
      }
      localGeneralPath.lineTo(-4.0F, 0.0F);
    }
    D = TWaverConst.DOUBLE_WIDTH_STROKE.createStrokedShape(localGeneralPath);
    U = A(0.6D, M);
    J = A(1.5D, M);
    I = A(0.6D, K);
    A = A(1.5D, K);
    P = A(0.6D, S);
    G = A(1.5D, S);
    B = A(0.7D, R);
    Q = A(1.5D, R);
    T = A(0.6D, F);
    H = A(1.5D, F);
    N = A(0.6D, D);
    C = A(1.5D, D);
  }
  
  private static final Shape A(double paramDouble, Shape paramShape)
  {
    L = new AffineTransform();
    L.scale(paramDouble, paramDouble);
    return L.createTransformedShape(paramShape);
  }
  
  private static GeneralPath A()
  {
    GeneralPath localGeneralPath = new GeneralPath(1, 6);
    localGeneralPath.moveTo(0.0F, 0.0F);
    return localGeneralPath;
  }
  
  public static Shape A(double paramDouble, Point2D paramPoint2D, int paramInt1, int paramInt2, int paramInt3)
  {
    Shape localShape = A(paramInt1);
    if ((paramInt2 != 0) || (paramInt3 != 0))
    {
      L.setTransform(1.0D, 0.0D, 0.0D, 1.0D, -paramInt2, -paramInt3);
      localShape = L.createTransformedShape(localShape);
    }
    L.setTransform(1.0D, 0.0D, 0.0D, 1.0D, paramPoint2D.getX(), paramPoint2D.getY());
    L.rotate(paramDouble);
    return L.createTransformedShape(localShape);
  }
  
  protected static Shape A(int paramInt)
  {
    switch (paramInt)
    {
    case 5: 
      return K;
    case 4: 
      return I;
    case 6: 
      return A;
    case 2: 
      return M;
    case 1: 
      return U;
    case 3: 
      return J;
    case 8: 
      return S;
    case 7: 
      return P;
    case 9: 
      return G;
    case 11: 
      return R;
    case 10: 
      return B;
    case 12: 
      return Q;
    case 14: 
      return F;
    case 13: 
      return T;
    case 15: 
      return H;
    case 17: 
      return D;
    case 16: 
      return N;
    case 18: 
      return C;
    case 20: 
      return O;
    case 19: 
      return E;
    case 21: 
      return V;
    }
    return M;
  }
  
  public static Shape A(boolean paramBoolean, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Rectangle paramRectangle, Node paramNode, int paramInt1, int paramInt2, int paramInt3)
  {
    paramRectangle.grow(1, 1);
    Object localObject = null;
    if (paramNode == null) {
      localObject = new Point2D.Double(paramRectangle.getCenterX(), paramRectangle.getCenterY());
    } else if (!paramNode.isAdjustToBottom()) {
      localObject = D.A(paramDouble3, paramDouble4, paramDouble1, paramDouble2, paramRectangle);
    }
    if (localObject == null) {
      localObject = new Point((int)paramDouble1, (int)paramDouble2);
    }
    double d1 = paramDouble3 - paramDouble1;
    double d2 = paramDouble4 - paramDouble2;
    if (d1 == 0.0D) {
      d1 = 1.0E-006D;
    }
    double d3 = Math.atan(d2 / d1);
    if (paramDouble3 >= paramDouble1) {
      d3 += 3.141592653589793D;
    }
    if (paramBoolean) {
      localObject = new Point((int)(paramDouble1 + paramDouble3) / 2, (int)(paramDouble2 + paramDouble4) / 2);
    }
    return A(d3, (Point2D)localObject, paramInt1, paramInt2, paramInt3);
  }
  
  public static Shape B(Link paramLink, GeneralPath paramGeneralPath, Rectangle paramRectangle)
  {
    return A(paramLink.isLinkFromArrowCenter(), paramGeneralPath, paramRectangle, paramLink.getFromAgent(), paramLink.getLinkFromArrowStyle(), paramLink.getLinkFromArrowXOffset(), paramLink.getLinkFromArrowYOffset());
  }
  
  public static Shape A(GeneralPath paramGeneralPath, Rectangle paramRectangle, int paramInt1, int paramInt2, int paramInt3)
  {
    ArrayList localArrayList = new ArrayList();
    K.A(paramGeneralPath, localArrayList, null);
    if (localArrayList.size() == 0) {
      return null;
    }
    Point2D localPoint2D = (Point2D)localArrayList.get(0);
    double d1 = localPoint2D.getX();
    double d2 = localPoint2D.getY();
    double d3 = localPoint2D.getX();
    double d4 = localPoint2D.getY();
    for (int i = 1; i < localArrayList.size(); i++)
    {
      localPoint2D = (Point2D)localArrayList.get(i);
      d3 = localPoint2D.getX();
      d4 = localPoint2D.getY();
      if ((d1 != d3) || (d2 != d4)) {
        break;
      }
    }
    if (paramRectangle == null) {
      paramRectangle = new Rectangle((int)d1 - 1, (int)d2 - 1, 1, 1);
    }
    return A(d1, d2, d3, d4, paramRectangle, paramInt1, paramInt2, paramInt3);
  }
  
  public static Shape B(GeneralPath paramGeneralPath, Rectangle paramRectangle, int paramInt1, int paramInt2, int paramInt3)
  {
    ArrayList localArrayList = new ArrayList();
    K.A(paramGeneralPath, localArrayList, null);
    if (localArrayList.size() == 0) {
      return null;
    }
    Point2D localPoint2D = (Point2D)localArrayList.get(localArrayList.size() - 1);
    double d1 = localPoint2D.getX();
    double d2 = localPoint2D.getY();
    double d3 = localPoint2D.getX();
    double d4 = localPoint2D.getY();
    for (int i = localArrayList.size() - 2; i >= 0; i--)
    {
      localPoint2D = (Point2D)localArrayList.get(i);
      d3 = localPoint2D.getX();
      d4 = localPoint2D.getY();
      if ((d1 != d3) || (d2 != d4)) {
        break;
      }
    }
    if (paramRectangle == null) {
      paramRectangle = new Rectangle((int)d1 - 1, (int)d2 - 1, 1, 1);
    }
    return A(d1, d2, d3, d4, paramRectangle, paramInt1, paramInt2, paramInt3);
  }
  
  public static Shape A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Rectangle paramRectangle, int paramInt1, int paramInt2, int paramInt3)
  {
    paramRectangle.grow(1, 1);
    Point localPoint = new Point((int)paramDouble1, (int)paramDouble2);
    double d1 = paramDouble3 - paramDouble1;
    double d2 = paramDouble4 - paramDouble2;
    if (d1 == 0.0D) {
      d1 = 1.0E-006D;
    }
    double d3 = Math.atan(d2 / d1);
    if (paramDouble3 >= paramDouble1) {
      d3 += 3.141592653589793D;
    }
    return A(d3, localPoint, paramInt1, paramInt2, paramInt3);
  }
  
  public static Shape A(boolean paramBoolean, GeneralPath paramGeneralPath, Rectangle paramRectangle, Node paramNode, int paramInt1, int paramInt2, int paramInt3)
  {
    ArrayList localArrayList = new ArrayList();
    K.A(paramGeneralPath, localArrayList, null);
    if (localArrayList.size() < 1) {
      return null;
    }
    Point2D localPoint2D;
    double d1;
    double d2;
    double d3;
    double d4;
    if (paramBoolean)
    {
      localPoint2D = (Point2D)localArrayList.get(localArrayList.size() / 2 - 1);
      d1 = localPoint2D.getX();
      d2 = localPoint2D.getY();
      localPoint2D = (Point2D)localArrayList.get(localArrayList.size() / 2);
      d3 = localPoint2D.getX();
      d4 = localPoint2D.getY();
    }
    else
    {
      localPoint2D = (Point2D)localArrayList.get(0);
      d1 = localPoint2D.getX();
      d2 = localPoint2D.getY();
      d3 = localPoint2D.getX();
      d4 = localPoint2D.getY();
      for (int i = 1; i < localArrayList.size(); i++)
      {
        localPoint2D = (Point2D)localArrayList.get(i);
        d3 = localPoint2D.getX();
        d4 = localPoint2D.getY();
        if ((d1 != d3) || (d2 != d4)) {
          break;
        }
      }
    }
    if (paramRectangle == null) {
      paramRectangle = new Rectangle((int)d1 - 1, (int)d2 - 1, 1, 1);
    }
    return A(paramBoolean, d1, d2, d3, d4, paramRectangle, paramNode, paramInt1, paramInt2, paramInt3);
  }
  
  public static Shape A(Link paramLink, GeneralPath paramGeneralPath, Rectangle paramRectangle)
  {
    return B(paramLink.isLinkToArrowCenter(), paramGeneralPath, paramRectangle, paramLink.getToAgent(), paramLink.getLinkToArrowStyle(), paramLink.getLinkToArrowXOffset(), paramLink.getLinkToArrowYOffset());
  }
  
  public static Shape B(boolean paramBoolean, GeneralPath paramGeneralPath, Rectangle paramRectangle, Node paramNode, int paramInt1, int paramInt2, int paramInt3)
  {
    ArrayList localArrayList = new ArrayList();
    K.A(paramGeneralPath, localArrayList, null);
    if (localArrayList.size() < 1) {
      return null;
    }
    double d1;
    double d2;
    double d3;
    double d4;
    if (paramBoolean)
    {
      int i = 0;
      if (localArrayList.size() % 2 == 1) {
        i = 1;
      }
      Point2D localPoint2D2 = (Point2D)localArrayList.get(localArrayList.size() / 2 + i);
      d1 = localPoint2D2.getX();
      d2 = localPoint2D2.getY();
      localPoint2D2 = (Point2D)localArrayList.get(localArrayList.size() / 2 - 1 + i);
      d3 = localPoint2D2.getX();
      d4 = localPoint2D2.getY();
    }
    else
    {
      Point2D localPoint2D1 = (Point2D)localArrayList.get(localArrayList.size() - 1);
      d1 = localPoint2D1.getX();
      d2 = localPoint2D1.getY();
      d3 = localPoint2D1.getX();
      d4 = localPoint2D1.getY();
      for (int j = localArrayList.size() - 2; j >= 0; j--)
      {
        localPoint2D1 = (Point2D)localArrayList.get(j);
        d3 = localPoint2D1.getX();
        d4 = localPoint2D1.getY();
        if ((d1 != d3) || (d2 != d4)) {
          break;
        }
      }
    }
    if (paramRectangle == null) {
      paramRectangle = new Rectangle((int)d1 - 1, (int)d2 - 1, 1, 1);
    }
    return A(paramBoolean, d1, d2, d3, d4, paramRectangle, paramNode, paramInt1, paramInt2, paramInt3);
  }
  
  public static Area A(LinkUI paramLinkUI, int paramInt)
  {
    Link localLink = paramLinkUI.getLink();
    ArrayList localArrayList = new ArrayList();
    K.A(paramLinkUI.getPath(), localArrayList, null);
    if (localArrayList.size() == 0) {
      return null;
    }
    Point2D localPoint2D1 = (Point2D)localArrayList.get(0);
    double d1 = localPoint2D1.getX();
    double d2 = localPoint2D1.getY();
    double d3 = localPoint2D1.getX();
    double d4 = localPoint2D1.getY();
    for (int i = 1; i < localArrayList.size(); i++)
    {
      localPoint2D1 = (Point2D)localArrayList.get(i);
      d3 = localPoint2D1.getX();
      d4 = localPoint2D1.getY();
      if ((d1 != d3) || (d2 != d4)) {
        break;
      }
    }
    localPoint2D1 = (Point2D)localArrayList.get(localArrayList.size() - 1);
    double d5 = localPoint2D1.getX();
    double d6 = localPoint2D1.getY();
    double d7 = localPoint2D1.getX();
    double d8 = localPoint2D1.getY();
    for (int j = localArrayList.size() - 2; j >= 0; j--)
    {
      localPoint2D1 = (Point2D)localArrayList.get(j);
      d7 = localPoint2D1.getX();
      d8 = localPoint2D1.getY();
      if ((d5 != d7) || (d6 != d8)) {
        break;
      }
    }
    Node localNode = localLink.getFromAgent();
    Rectangle localRectangle = paramLinkUI.getFromAgentBounds();
    localRectangle.grow(paramInt, paramInt);
    Object localObject1 = null;
    if (localNode.isAdjustToBottom()) {
      localObject1 = new Point2D.Double(localRectangle.getCenterX(), localRectangle.getCenterY());
    } else {
      localObject1 = D.A(d1, d2, d3, d4, localRectangle);
    }
    if (localObject1 == null) {
      localObject1 = new Point((int)d1, (int)d2);
    }
    localNode = localLink.getToAgent();
    localRectangle = paramLinkUI.getToAgentBounds();
    localRectangle.grow(paramInt, paramInt);
    Object localObject2 = null;
    if (localNode.isAdjustToBottom()) {
      localObject2 = new Point2D.Double(localRectangle.getCenterX(), localRectangle.getCenterY());
    } else {
      localObject2 = D.A(d5, d6, d7, d8, localRectangle);
    }
    if (localObject2 == null) {
      localObject2 = new Point((int)d5, (int)d6);
    }
    Area localArea = new Area();
    localArea.add(A((Point2D)localObject1));
    if ((localLink instanceof ShapeLink))
    {
      List localList = ((ShapeLink)localLink).getPoints();
      for (int k = 0; k < localList.size(); k++)
      {
        Point2D localPoint2D2 = (Point2D)localList.get(k);
        localArea.add(A(localPoint2D2));
      }
    }
    localArea.add(A((Point2D)localObject2));
    return localArea;
  }
  
  private static Area A(Point2D paramPoint2D)
  {
    return new Area(new Rectangle((int)paramPoint2D.getX() - 3, (int)paramPoint2D.getY() - 3, 6, 6));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.R
 * JD-Core Version:    0.7.0.1
 */
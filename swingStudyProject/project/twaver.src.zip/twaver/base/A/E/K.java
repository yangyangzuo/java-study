package twaver.base.A.E;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Ellipse2D.Float;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D.Double;
import java.awt.geom.RoundRectangle2D.Float;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import twaver.TWaverUtil;
import twaver.base.SerializablePoint2D;
import twaver.network.ui.ElementUI;

public final class K
{
  private static Map A = new LinkedHashMap();
  
  static
  {
    A(1);
    A(2);
    A(3);
    A(4);
    A(5);
    A(6);
    A(7);
    A(8);
    A(9);
    A(10);
    A(11);
    A(12);
    A(13);
    A(14);
    A(15);
    A(16);
    A(17);
    A(18);
    A(19);
    A(20);
    A(21);
    A(22);
    A(23);
    A(24);
  }
  
  public static Point2D A(Point2D paramPoint2D)
  {
    if (((paramPoint2D instanceof Point2D.Double)) && ((paramPoint2D instanceof Serializable))) {
      return paramPoint2D;
    }
    if (Serializable.class.isAssignableFrom(Point2D.Double.class)) {
      return new Point2D.Double(paramPoint2D.getX(), paramPoint2D.getY());
    }
    return new SerializablePoint2D(paramPoint2D.getX(), paramPoint2D.getY());
  }
  
  public static List A(List paramList)
  {
    if (paramList == null) {
      return new ArrayList();
    }
    int i = paramList.size();
    for (int j = 0; j < i; j++)
    {
      Point2D localPoint2D = (Point2D)paramList.get(j);
      paramList.set(j, A(localPoint2D));
    }
    return paramList;
  }
  
  private static void A(int paramInt)
  {
    A.put(TWaverUtil.valueOf(paramInt), new twaver.base.A.D.K()
    {
      private final int val$type;
      
      public Shape D(ElementUI paramAnonymousElementUI, Rectangle paramAnonymousRectangle)
      {
        return K.B(this.val$type, paramAnonymousRectangle);
      }
      
      public Shape A(ElementUI paramAnonymousElementUI, Rectangle paramAnonymousRectangle)
      {
        paramAnonymousRectangle.grow(1, 1);
        return K.B(this.val$type, paramAnonymousRectangle);
      }
      
      public Shape C(ElementUI paramAnonymousElementUI, Rectangle paramAnonymousRectangle)
      {
        if (paramAnonymousElementUI.getStateOutlineColor() != null) {
          paramAnonymousRectangle.grow(3, 3);
        } else {
          paramAnonymousRectangle.grow(1, 1);
        }
        return K.B(this.val$type, paramAnonymousRectangle);
      }
      
      public Point B(ElementUI paramAnonymousElementUI, Rectangle paramAnonymousRectangle)
      {
        return K.A(this.val$type, paramAnonymousRectangle);
      }
    });
  }
  
  public static twaver.base.A.D.K B(int paramInt)
  {
    return (twaver.base.A.D.K)A.get(TWaverUtil.valueOf(paramInt));
  }
  
  public static Shape B(int paramInt, Rectangle paramRectangle)
  {
    float f1 = (float)Math.min(paramRectangle.getWidth(), paramRectangle.getHeight());
    if (paramInt == 1) {
      return new Ellipse2D.Float(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
    if (paramInt == 2) {
      return paramRectangle;
    }
    if (paramInt == 3) {
      return new RoundRectangle2D.Float(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height, f1, f1);
    }
    if (paramInt == 4) {
      return new RoundRectangle2D.Float(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height, f1 / 2.0F, f1 / 2.0F);
    }
    if (paramInt == 5) {
      return new RoundRectangle2D.Float(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height, f1 / 4.0F, f1 / 4.0F);
    }
    float f2;
    Area localArea1;
    if (paramInt == 6)
    {
      f2 = f1;
      localArea1 = new Area(new RoundRectangle2D.Float((float)paramRectangle.getX(), (float)paramRectangle.getY(), (float)paramRectangle.getWidth(), f2, f2, f2));
      localArea1.add(new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY() + f2 / 2.0F, paramRectangle.getWidth(), paramRectangle.getHeight() - f2 / 2.0F)));
      return localArea1;
    }
    if (paramInt == 7)
    {
      f2 = f1 / 2.0F;
      localArea1 = new Area(new RoundRectangle2D.Float((float)paramRectangle.getX(), (float)paramRectangle.getY(), (float)paramRectangle.getWidth(), f2, f2, f2));
      localArea1.add(new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY() + f2 / 2.0F, paramRectangle.getWidth(), paramRectangle.getHeight() - f2 / 2.0F)));
      return localArea1;
    }
    if (paramInt == 8)
    {
      f2 = f1 / 4.0F;
      localArea1 = new Area(new RoundRectangle2D.Float((float)paramRectangle.getX(), (float)paramRectangle.getY(), (float)paramRectangle.getWidth(), f2, f2, f2));
      localArea1.add(new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY() + f2 / 2.0F, paramRectangle.getWidth(), paramRectangle.getHeight() - f2 / 2.0F)));
      return localArea1;
    }
    GeneralPath localGeneralPath1;
    if (paramInt == 9)
    {
      localGeneralPath1 = new GeneralPath();
      localGeneralPath1.moveTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y);
      localGeneralPath1.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath1.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
      localGeneralPath1.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath1.closePath();
      return localGeneralPath1;
    }
    if (paramInt == 10)
    {
      localGeneralPath1 = new GeneralPath();
      localGeneralPath1.moveTo((float)(paramRectangle.getX() + paramRectangle.getWidth() / 2.0D), paramRectangle.y);
      localGeneralPath1.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath1.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath1.closePath();
      return localGeneralPath1;
    }
    if (paramInt == 11)
    {
      float f3 = paramRectangle.width * 2;
      float f4 = paramRectangle.height * 2;
      GeneralPath localGeneralPath3 = new GeneralPath();
      float f5 = paramRectangle.x + f3 / 4.0F;
      float f6 = paramRectangle.y + f4 / 4.0F;
      localGeneralPath3.moveTo(f5 - f3 / 4.0F, f6 - f4 / 12.0F);
      localGeneralPath3.lineTo(f5 + f3 / 4.0F, f6 - f4 / 12.0F);
      localGeneralPath3.lineTo(f5 - f3 / 6.0F, f6 + f4 / 4.0F);
      localGeneralPath3.lineTo(f5 + 0.0F, f6 - f4 / 4.0F);
      localGeneralPath3.lineTo(f5 + f3 / 6.0F, f6 + f4 / 4.0F);
      localGeneralPath3.closePath();
      Area localArea2 = new Area(localGeneralPath3);
      return localArea2;
    }
    if (paramInt == 12)
    {
      double d1 = paramRectangle.getCenterX();
      double d2 = paramRectangle.getCenterY();
      double d3 = Math.min(paramRectangle.width, paramRectangle.height) / 2;
      return new Ellipse2D.Double(d1 - d3, d2 - d3, d3 * 2.0D, d3 * 2.0D);
    }
    GeneralPath localGeneralPath2;
    if (paramInt == 14)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 13)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 15)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 16)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 17)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.25D), paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.25D), paramRectangle.y + paramRectangle.height);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 18)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 4, paramRectangle.y + paramRectangle.height / 2);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y + paramRectangle.height);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 19)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 4);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + (int)(paramRectangle.height * 0.75D));
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + (int)(paramRectangle.height * 0.25D));
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 20)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + (int)(paramRectangle.height * 0.75D));
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height / 4);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + (int)(paramRectangle.height * 0.75D));
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 21)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x + paramRectangle.width / 4, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height / 4);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 22)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 4);
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + paramRectangle.height);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 23)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.quadTo(paramRectangle.x + paramRectangle.width / 4, paramRectangle.y + paramRectangle.height + paramRectangle.height / 8, paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.quadTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y + (int)(paramRectangle.height * 0.625D), paramRectangle.x + paramRectangle.width, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    if (paramInt == 24)
    {
      localGeneralPath2 = new GeneralPath();
      localGeneralPath2.moveTo(paramRectangle.x, paramRectangle.y);
      localGeneralPath2.lineTo(paramRectangle.x, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.quadTo(paramRectangle.x + paramRectangle.width / 4, paramRectangle.y + (int)(paramRectangle.height * 0.625D), paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.quadTo(paramRectangle.x + (int)(paramRectangle.width * 0.75D), paramRectangle.y + paramRectangle.height + paramRectangle.height / 8, paramRectangle.x + paramRectangle.width, paramRectangle.y + (int)(paramRectangle.height * 0.875D));
      localGeneralPath2.lineTo(paramRectangle.x + paramRectangle.width, paramRectangle.y);
      localGeneralPath2.closePath();
      return localGeneralPath2;
    }
    return null;
  }
  
  public static Point A(int paramInt, Rectangle paramRectangle)
  {
    int i;
    int j;
    int k;
    int m;
    double d1;
    if (paramInt == 1)
    {
      i = paramRectangle.x;
      j = paramRectangle.y;
      k = paramRectangle.width;
      m = paramRectangle.height;
      d1 = k / 2;
      double d2 = m / 2;
      double d4 = d1 * d2 / Math.sqrt(d1 * d1 + d2 * d2);
      int i4 = i + k / 2 + (int)d4;
      int i5 = j + m / 2 - (int)d4;
      return new Point(i4, i5);
    }
    if (paramInt == 2)
    {
      i = (int)(paramRectangle.getX() + paramRectangle.getWidth());
      j = (int)paramRectangle.getY();
      return new Point(i, j);
    }
    int i2;
    int i3;
    if ((paramInt == 3) || (paramInt == 4) || (paramInt == 5))
    {
      i = paramRectangle.x;
      j = paramRectangle.y;
      k = paramRectangle.width;
      m = paramRectangle.height;
      d1 = 0.12D;
      i2 = i + k - (int)(k * d1);
      i3 = j + (int)(m * d1);
      return new Point(i2, i3);
    }
    if ((paramInt == 6) || (paramInt == 7) || (paramInt == 8))
    {
      i = paramRectangle.x;
      j = paramRectangle.y;
      k = paramRectangle.width;
      m = paramRectangle.height / 2;
      d1 = 0.15D;
      i2 = i + k - (int)(k * d1);
      i3 = j + (int)(m * d1);
      return new Point(i2, i3);
    }
    int n;
    int i1;
    if (paramInt == 9)
    {
      i = paramRectangle.x;
      j = paramRectangle.y;
      k = paramRectangle.width;
      m = paramRectangle.height;
      n = (int)(i + k * 0.75D);
      i1 = (int)(j + m * 0.25D);
      return new Point(n, i1);
    }
    if (paramInt == 10) {
      return new Point((int)(paramRectangle.x + paramRectangle.width * 0.625D + 1.0D), (int)(paramRectangle.y + paramRectangle.height * 0.25D));
    }
    if (paramInt == 11) {
      return new Point((int)(paramRectangle.x + paramRectangle.width * 0.62D), (int)(paramRectangle.y + paramRectangle.height * 0.3D));
    }
    if (paramInt == 12)
    {
      i = (int)paramRectangle.getCenterX();
      j = (int)paramRectangle.getCenterY();
      k = Math.min(paramRectangle.width, paramRectangle.height) / 2;
      m = i - k;
      n = j - k;
      i1 = k * 2;
      i2 = k * 2;
      double d3 = i1 / 2;
      double d5 = i2 / 2;
      double d6 = d3 * d5 / Math.sqrt(d3 * d3 + d5 * d5);
      int i6 = m + i1 / 2 + (int)d6;
      int i7 = n + i2 / 2 - (int)d6;
      return new Point(i6, i7);
    }
    return new Point((int)paramRectangle.getCenterX(), (int)paramRectangle.getCenterY());
  }
  
  public static GeneralPath A(int paramInt, Dimension paramDimension)
  {
    GeneralPath localGeneralPath = new GeneralPath();
    for (int i = 0; i < paramInt; i++)
    {
      int j = (int)(paramDimension.width * Math.cos(Math.toRadians(360 / paramInt * i)));
      int k = (int)(paramDimension.height * Math.sin(Math.toRadians(360 / paramInt * i)));
      if (i == 0) {
        localGeneralPath.moveTo(j, k);
      } else {
        localGeneralPath.lineTo(j, k);
      }
    }
    return localGeneralPath;
  }
  
  public static Shape A(float paramFloat1, float paramFloat2)
  {
    return new Ellipse2D.Float(0.0F, 0.0F, paramFloat1, paramFloat2);
  }
  
  public static Shape A(Shape paramShape)
  {
    if (paramShape != null)
    {
      Rectangle localRectangle = paramShape.getBounds();
      AffineTransform localAffineTransform = AffineTransform.getTranslateInstance(-localRectangle.getX(), -localRectangle.getY());
      return localAffineTransform.createTransformedShape(paramShape);
    }
    return null;
  }
  
  public static Point A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5)
  {
    paramDouble5 /= 2.0D;
    Point localPoint = new Point();
    localPoint.x = ((int)(paramDouble1 + paramDouble3 * 0.5D + paramDouble3 * paramDouble5));
    localPoint.y = ((int)(paramDouble2 + paramDouble4 / 2.0D - Math.sqrt(0.25D - paramDouble5 * paramDouble5) * paramDouble4));
    return localPoint;
  }
  
  public static Shape A(Arc2D paramArc2D)
  {
    int i = (int)paramArc2D.getWidth() / 2 - 2;
    float f1 = Math.min(i, 16);
    float f2 = Math.min(i / 2, 7);
    GeneralPath localGeneralPath = new GeneralPath();
    localGeneralPath.moveTo(0.0F, 0.0F);
    localGeneralPath.lineTo(i - f1, 0.0F);
    localGeneralPath.lineTo(i - f1, f2 / 2.0F);
    localGeneralPath.lineTo(i, 0.0F);
    localGeneralPath.lineTo(i - f1, -f2 / 2.0F);
    localGeneralPath.lineTo(i - f1, 0.0F);
    double d = paramArc2D.getAngleStart() + paramArc2D.getAngleExtent() / 2.0D;
    d = -d;
    d = Math.toRadians(d);
    AffineTransform localAffineTransform = AffineTransform.getRotateInstance(d);
    Shape localShape = localAffineTransform.createTransformedShape(localGeneralPath);
    localAffineTransform = AffineTransform.getTranslateInstance(paramArc2D.getCenterX(), paramArc2D.getCenterY());
    return localAffineTransform.createTransformedShape(localShape);
  }
  
  public static Shape A(Arc2D paramArc2D, int paramInt)
  {
    if (paramInt == 1) {
      return paramArc2D;
    }
    Object localObject = null;
    float f1 = (float)paramArc2D.getWidth() / 2.0F;
    float f2 = (float)paramArc2D.getAngleExtent();
    if (paramInt == 2)
    {
      localObject = new Ellipse2D.Float(0.0F, -f2 / 2.0F, f1, f2);
    }
    else if (paramInt == 3)
    {
      GeneralPath localGeneralPath = new GeneralPath();
      localGeneralPath.moveTo(0.0F, 0.0F);
      localGeneralPath.lineTo(f1, -f2 / 2.0F);
      localGeneralPath.lineTo(f1, f2 / 2.0F);
      localGeneralPath.closePath();
      localObject = localGeneralPath;
    }
    else if (paramInt == 4)
    {
      localObject = new Rectangle(0, (int)-f2 / 2, (int)f1, (int)f2);
    }
    else if (paramInt == 5)
    {
      float f3 = Math.min(f1, f2);
      localObject = new RoundRectangle2D.Float(0.0F, -f2 / 2.0F, f1, f2, f3, f3);
    }
    double d = paramArc2D.getAngleStart() + paramArc2D.getAngleExtent() / 2.0D;
    d = -d;
    d = Math.toRadians(d);
    AffineTransform localAffineTransform = AffineTransform.getRotateInstance(d);
    localObject = localAffineTransform.createTransformedShape((Shape)localObject);
    localAffineTransform = AffineTransform.getTranslateInstance(paramArc2D.getCenterX(), paramArc2D.getCenterY());
    return localAffineTransform.createTransformedShape((Shape)localObject);
  }
  
  public static int B(Rectangle paramRectangle, int paramInt)
  {
    int i = Math.min(paramRectangle.width, paramRectangle.height) - 1;
    if (paramInt > 0) {
      i -= paramInt * 2;
    }
    int j = 6;
    if (j * 3 > i)
    {
      j = i / 3;
      if (j % 2 == 1) {
        j--;
      }
      if (j < 2) {
        j = 2;
      }
    }
    return j;
  }
  
  public static Area A(Rectangle paramRectangle, int paramInt)
  {
    int i = B(paramRectangle, paramInt);
    Area localArea = new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY(), i, i));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX() + paramRectangle.getWidth() - i, paramRectangle.getY(), i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY() + paramRectangle.getHeight() - i, i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX() + paramRectangle.getWidth() - i, paramRectangle.getY() + paramRectangle.getHeight() - i, i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX() + paramRectangle.getWidth() / 2.0D - i / 2, paramRectangle.getY(), i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX(), paramRectangle.getY() + paramRectangle.getHeight() / 2.0D - i / 2, i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX() + paramRectangle.getWidth() / 2.0D - i / 2, paramRectangle.getY() + paramRectangle.getHeight() - i, i, i)));
    localArea.add(new Area(new Rectangle2D.Double(paramRectangle.getX() + paramRectangle.getWidth() - i, paramRectangle.getY() + paramRectangle.getHeight() / 2.0D - i / 2, i, i)));
    return localArea;
  }
  
  public static Cursor A(Rectangle paramRectangle, Point paramPoint)
  {
    int i = B(paramRectangle, 0);
    if (new Rectangle(paramRectangle.x, paramRectangle.y, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(6);
    }
    if (new Rectangle(paramRectangle.x + paramRectangle.width - i, paramRectangle.y, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(7);
    }
    if (new Rectangle(paramRectangle.x, paramRectangle.y + paramRectangle.height - i, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(4);
    }
    if (new Rectangle(paramRectangle.x + paramRectangle.width - i, paramRectangle.y + paramRectangle.height - i, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(5);
    }
    if (new Rectangle(paramRectangle.x + paramRectangle.width / 2 - i / 2, paramRectangle.y, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(8);
    }
    if (new Rectangle(paramRectangle.x, paramRectangle.y + paramRectangle.height / 2 - i / 2, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(10);
    }
    if (new Rectangle(paramRectangle.x + paramRectangle.width / 2 - i / 2, paramRectangle.y + paramRectangle.height - i, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(9);
    }
    if (new Rectangle(paramRectangle.x + paramRectangle.width - i, paramRectangle.y + paramRectangle.height / 2 - i / 2, i, i).contains(paramPoint)) {
      return Cursor.getPredefinedCursor(11);
    }
    return null;
  }
  
  public static Point A(GeneralPath paramGeneralPath)
  {
    ArrayList localArrayList = new ArrayList();
    A(paramGeneralPath, localArrayList, null);
    if (localArrayList.size() == 0) {
      return null;
    }
    int i = localArrayList.size();
    int j = localArrayList.size() / 2;
    if (i % 2 == 0)
    {
      localPoint2D1 = (Point2D)localArrayList.get(j - 1);
      Point2D localPoint2D2 = (Point2D)localArrayList.get(j);
      return new Point((int)(localPoint2D2.getX() + localPoint2D1.getX()) / 2, (int)(localPoint2D2.getY() + localPoint2D1.getY()) / 2);
    }
    Point2D localPoint2D1 = (Point2D)localArrayList.get(j);
    return new Point((int)localPoint2D1.getX(), (int)localPoint2D1.getY());
  }
  
  public static final void A(GeneralPath paramGeneralPath, List paramList1, List paramList2)
  {
    float[] arrayOfFloat = new float[6];
    PathIterator localPathIterator = paramGeneralPath.getPathIterator(null);
    while ((localPathIterator != null) && (!localPathIterator.isDone()))
    {
      int i = localPathIterator.currentSegment(arrayOfFloat);
      if (paramList2 != null) {
        paramList2.add(TWaverUtil.valueOf(i));
      }
      switch (i)
      {
      case 0: 
        paramList1.add(new Point2D.Double((int)arrayOfFloat[0], (int)arrayOfFloat[1]));
        break;
      case 1: 
        paramList1.add(new Point2D.Double((int)arrayOfFloat[0], (int)arrayOfFloat[1]));
        break;
      case 2: 
        paramList1.add(new Point2D.Double((int)arrayOfFloat[0], (int)arrayOfFloat[1]));
        paramList1.add(new Point2D.Double((int)arrayOfFloat[2], (int)arrayOfFloat[3]));
        break;
      case 3: 
        paramList1.add(new Point2D.Double((int)arrayOfFloat[0], (int)arrayOfFloat[1]));
        paramList1.add(new Point2D.Double((int)arrayOfFloat[2], (int)arrayOfFloat[3]));
        paramList1.add(new Point2D.Double((int)arrayOfFloat[4], (int)arrayOfFloat[5]));
        break;
      }
      localPathIterator.next();
    }
  }
  
  public static List A(Shape paramShape, int paramInt)
  {
    if (paramInt == 0) {
      return new ArrayList();
    }
    ArrayList localArrayList = new ArrayList();
    d locald = B(paramShape);
    double d1 = 0.0D;
    if (locald.C) {
      d1 = (locald.B - 0.5D) / paramInt;
    } else {
      d1 = (locald.B - 0.5D) / (paramInt - 1);
    }
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    double d2 = 0.0D;
    int j = 0;
    while (!localFlatteningPathIterator.isDone())
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        d2 = d1;
        if (localArrayList.size() < paramInt) {
          localArrayList.add(new Point2D.Double(arrayOfFloat[0], arrayOfFloat[1]));
        }
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f7 = f5 - f3;
        float f8 = f6 - f4;
        float f9 = (float)Math.sqrt(f7 * f7 + f8 * f8);
        if (f9 >= d2)
        {
          float f10 = 1.0F / f9;
          while (f9 >= d2)
          {
            double d3 = f3 + d2 * f7 * f10;
            double d4 = f4 + d2 * f8 * f10;
            if (localArrayList.size() < paramInt) {
              localArrayList.add(new Point2D.Double(d3, d4));
            }
            d2 += d1;
            j++;
          }
        }
        d2 -= f9;
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    return localArrayList;
  }
  
  public static final double C(Shape paramShape)
  {
    d locald = B(paramShape);
    if (locald == null) {
      return 0.0D;
    }
    return locald.B;
  }
  
  public static final d B(Shape paramShape)
  {
    if (paramShape == null) {
      return null;
    }
    FlatteningPathIterator localFlatteningPathIterator = new FlatteningPathIterator(paramShape.getPathIterator(null), 1.0D);
    float[] arrayOfFloat = new float[6];
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f5 = 0.0F;
    float f6 = 0.0F;
    int i = 0;
    d locald = new d();
    while (!localFlatteningPathIterator.isDone())
    {
      i = localFlatteningPathIterator.currentSegment(arrayOfFloat);
      switch (i)
      {
      case 0: 
        f1 = f3 = arrayOfFloat[0];
        f2 = f4 = arrayOfFloat[1];
        if (locald.A == null) {
          locald.A = new Point2D.Double(arrayOfFloat[0], arrayOfFloat[1]);
        }
        break;
      case 4: 
        arrayOfFloat[0] = f1;
        arrayOfFloat[1] = f2;
      case 1: 
        f5 = arrayOfFloat[0];
        f6 = arrayOfFloat[1];
        float f7 = f5 - f3;
        float f8 = f6 - f4;
        locald.B += Math.sqrt(f7 * f7 + f8 * f8);
        f3 = f5;
        f4 = f6;
      }
      localFlatteningPathIterator.next();
    }
    locald.C = ((locald.A != null) && (locald.A.x == arrayOfFloat[0]) && (locald.A.y == arrayOfFloat[1]));
    return locald;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.K
 * JD-Core Version:    0.7.0.1
 */
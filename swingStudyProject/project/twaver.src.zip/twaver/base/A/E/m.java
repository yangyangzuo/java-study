package twaver.base.A.E;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import twaver.network.ui.LinkUI;

public class m
{
  public static void A(Shape paramShape, Graphics2D paramGraphics2D, LinkUI paramLinkUI)
  {
    int i = paramLinkUI.getLinkWidth();
    i = i > 0 ? i : 1;
    if (i > 1)
    {
      if (paramLinkUI.is3D()) {
        A(paramShape, paramGraphics2D, paramLinkUI, i);
      } else {
        D(paramShape, paramGraphics2D, paramLinkUI, i);
      }
    }
    else {
      B(paramShape, paramGraphics2D, paramLinkUI, i);
    }
  }
  
  private static void C(Shape paramShape, Graphics2D paramGraphics2D, LinkUI paramLinkUI, int paramInt)
  {
    if (paramLinkUI.isFlowing())
    {
      paramGraphics2D.setColor(paramLinkUI.getFlowingColor());
      float[] arrayOfFloat = { paramInt * 2 };
      BasicStroke localBasicStroke = new BasicStroke(paramLinkUI.getFlowingWidth(), 0, 1, paramInt, arrayOfFloat, paramLinkUI.getDashPhase());
      paramGraphics2D.setStroke(localBasicStroke);
      paramGraphics2D.draw(paramLinkUI.getPath());
    }
  }
  
  public static void A(Shape paramShape, Graphics2D paramGraphics2D, LinkUI paramLinkUI, int paramInt)
  {
    int i = paramLinkUI.getOutlineWidth();
    Color localColor1 = paramLinkUI.getStateOutlineColor();
    if (localColor1 != null)
    {
      paramGraphics2D.setColor(localColor1);
      paramGraphics2D.setStroke(c.B(i + 3));
      paramGraphics2D.draw(paramShape);
    }
    AffineTransform localAffineTransform1 = AffineTransform.getTranslateInstance(-1.0D, -1.0D);
    AffineTransform localAffineTransform2 = AffineTransform.getTranslateInstance(1.0D, 1.0D);
    Shape localShape1 = localAffineTransform1.createTransformedShape(paramShape);
    Shape localShape2 = localAffineTransform2.createTransformedShape(paramShape);
    Color localColor2 = paramLinkUI.getPaintBodyColor(paramLinkUI.getLinkColor());
    paramGraphics2D.setColor(localColor2.brighter().brighter());
    paramGraphics2D.fill(localShape1);
    paramGraphics2D.setColor(localColor2.darker().darker());
    paramGraphics2D.fill(localShape2);
    paramLinkUI.setBodyPaint(paramGraphics2D, localColor2);
    paramGraphics2D.fill(paramShape);
    C(paramShape, paramGraphics2D, paramLinkUI, paramInt);
  }
  
  public static void D(Shape paramShape, Graphics2D paramGraphics2D, LinkUI paramLinkUI, int paramInt)
  {
    int i = paramLinkUI.getOutlineWidth();
    Color localColor = paramLinkUI.getStateOutlineColor();
    if (localColor != null)
    {
      paramGraphics2D.setColor(localColor);
      paramGraphics2D.setStroke(c.B(i + 2));
      paramGraphics2D.draw(paramShape);
    }
    if (!paramLinkUI.isHollow())
    {
      paramLinkUI.setBodyPaint(paramGraphics2D, paramLinkUI.getPaintBodyColor(paramLinkUI.getLinkColor()));
      paramGraphics2D.fill(paramShape);
    }
    C(paramShape, paramGraphics2D, paramLinkUI, paramInt);
    if (i > 0)
    {
      paramGraphics2D.setColor(paramLinkUI.getOutlineColor());
      paramGraphics2D.setStroke(c.B(i));
      paramGraphics2D.draw(paramShape);
    }
  }
  
  public static void B(Shape paramShape, Graphics2D paramGraphics2D, LinkUI paramLinkUI, int paramInt)
  {
    int i = paramLinkUI.getOutlineWidth();
    Stroke localStroke = paramLinkUI.getStroke();
    Color localColor = paramLinkUI.getStateOutlineColor();
    if (localColor != null)
    {
      paramGraphics2D.setColor(localColor);
      paramGraphics2D.setStroke(c.A((i + 2) * 2 + paramInt, localStroke));
      paramGraphics2D.draw(paramShape);
    }
    if (i > 0)
    {
      paramGraphics2D.setColor(paramLinkUI.getOutlineColor());
      paramGraphics2D.setStroke(c.A(i * 2 + paramInt, localStroke));
      paramGraphics2D.draw(paramShape);
    }
    if (!paramLinkUI.isHollow())
    {
      paramLinkUI.setBodyPaint(paramGraphics2D, paramLinkUI.getPaintBodyColor(paramLinkUI.getLinkColor()));
      paramGraphics2D.setStroke(localStroke);
      paramGraphics2D.draw(paramShape);
    }
    C(paramShape, paramGraphics2D, paramLinkUI, paramInt);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.m
 * JD-Core Version:    0.7.0.1
 */
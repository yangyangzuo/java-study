package twaver.base.A.E;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import twaver.Element;
import twaver.Generator;
import twaver.PaintSelectionStateFilter;
import twaver.TDataBox;
import twaver.base.A.A.I;
import twaver.tree.AbstractTTreeNode;
import twaver.tree.DataBoxNode;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public final class g
{
  public static boolean F(TTree paramTTree, Element paramElement)
  {
    if ((paramElement != null) && (paramTTree.getPaintSelectionStateFilter() != null)) {
      return paramTTree.getPaintSelectionStateFilter().isPaintable(paramElement);
    }
    return true;
  }
  
  public static void A(TTree paramTTree, JLabel paramJLabel)
  {
    String str = paramTTree.getDataBox().getName();
    paramJLabel.setText(str);
    paramJLabel.setToolTipText(str);
    I localI = null;
    if ((paramTTree.isIconVisible()) && (paramTTree.getDataBoxIconURL() != null)) {
      localI = new I(paramTTree.getDataBoxIconURL(), paramTTree.getIconWidth(), paramTTree.getIconHeight());
    }
    if (paramTTree.isEnabled()) {
      paramJLabel.setIcon(localI);
    } else {
      paramJLabel.setDisabledIcon(localI);
    }
    if ((localI == null) && ((str == null) || (str.length() == 0))) {
      paramJLabel.setText(" ");
    }
  }
  
  public static void A(TTree paramTTree, Element paramElement, JLabel paramJLabel)
  {
    String str1 = null;
    if (paramTTree.getElementLabelGenerator() != null) {
      str1 = (String)paramTTree.getElementLabelGenerator().generate(paramElement);
    }
    paramJLabel.setText(str1);
    String str2 = null;
    if ((paramTTree.isElementToolTipDisplayable()) && (paramTTree.getElementToolTipTextGenerator() != null)) {
      str2 = (String)paramTTree.getElementToolTipTextGenerator().generate(paramElement);
    }
    paramJLabel.setToolTipText(str2);
    Icon localIcon = null;
    if ((paramTTree.isIconVisible()) && (paramTTree.getElementIconGenerator() != null)) {
      localIcon = (Icon)paramTTree.getElementIconGenerator().generate(paramElement);
    }
    if (paramTTree.isEnabled()) {
      paramJLabel.setIcon(localIcon);
    } else {
      paramJLabel.setDisabledIcon(localIcon);
    }
    if ((localIcon == null) && ((str1 == null) || (str1.length() == 0))) {
      paramJLabel.setText(" ");
    }
  }
  
  public static boolean C(TTree paramTTree, Element paramElement)
  {
    if (!paramTTree.isVisible(paramElement)) {
      return true;
    }
    if (!paramElement.isSelected()) {
      return false;
    }
    boolean bool = true;
    Iterator localIterator = paramElement.getChildren().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      if (!C(paramTTree, localElement))
      {
        bool = false;
        break;
      }
    }
    return bool;
  }
  
  public static void B(TTree paramTTree)
  {
    AbstractTTreeNode localAbstractTTreeNode = paramTTree.getRootNode();
    Object localObject1;
    if ((localAbstractTTreeNode instanceof DataBoxNode))
    {
      localObject1 = new LinkedList(paramTTree.getDataBox().getRootElements());
      Object localObject2 = ((List)localObject1).iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Element)((Iterator)localObject2).next();
        E(paramTTree, (Element)localObject3);
      }
      localObject2 = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localAbstractTTreeNode);
      Object localObject3 = new TreePath((Object[])localObject2);
      paramTTree.expandPath((TreePath)localObject3);
    }
    else if ((localAbstractTTreeNode instanceof ElementNode))
    {
      localObject1 = ((ElementNode)localAbstractTTreeNode).getElement();
      E(paramTTree, (Element)localObject1);
    }
  }
  
  public static void E(TTree paramTTree, Element paramElement)
  {
    if (paramTTree.makeNodeLoaded(paramElement))
    {
      LinkedList localLinkedList = new LinkedList(paramElement.getChildren());
      Object localObject1 = localLinkedList.iterator();
      Object localObject2;
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Element)((Iterator)localObject1).next();
        E(paramTTree, (Element)localObject2);
      }
      localObject1 = paramTTree.getLoadedTreeNodeByElement(paramElement);
      if (localObject1 != null)
      {
        localObject2 = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot((TreeNode)localObject1);
        TreePath localTreePath = new TreePath((Object[])localObject2);
        paramTTree.expandPath(localTreePath);
      }
    }
  }
  
  public static void A(TTree paramTTree, int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    A(paramTTree);
    if (paramTTree.isRootVisible()) {
      paramInt--;
    }
    AbstractTTreeNode localAbstractTTreeNode = paramTTree.getRootNode();
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if ((localAbstractTTreeNode instanceof DataBoxNode))
    {
      localObject1 = new LinkedList(paramTTree.getDataBox().getRootElements());
      localObject2 = ((List)localObject1).iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Element)((Iterator)localObject2).next();
        A(paramTTree, (Element)localObject3, paramInt);
      }
    }
    else
    {
      localObject1 = (ElementNode)localAbstractTTreeNode;
      localObject2 = ((ElementNode)localObject1).getElement();
      localObject3 = new LinkedList(((Element)localObject2).getChildren());
      Iterator localIterator = ((List)localObject3).iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        A(paramTTree, localElement, paramInt);
      }
    }
  }
  
  public static void A(TTree paramTTree, Element paramElement, int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    if (paramTTree.makeNodeLoaded(paramElement))
    {
      LinkedList localLinkedList = new LinkedList(paramElement.getChildren());
      Object localObject1 = localLinkedList.iterator();
      Object localObject2;
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Element)((Iterator)localObject1).next();
        A(paramTTree, (Element)localObject2, paramInt - 1);
      }
      localObject1 = paramTTree.getLoadedTreeNodeByElement(paramElement);
      if (localObject1 != null)
      {
        localObject2 = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot((TreeNode)localObject1);
        TreePath localTreePath = new TreePath((Object[])localObject2);
        paramTTree.expandPath(localTreePath);
      }
    }
  }
  
  public static void D(TTree paramTTree, Element paramElement)
  {
    if (paramTTree.makeNodeLoaded(paramElement))
    {
      ElementNode localElementNode = paramTTree.getLoadedTreeNodeByElement(paramElement);
      if (localElementNode != null)
      {
        TreeNode[] arrayOfTreeNode = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localElementNode);
        TreePath localTreePath = new TreePath(arrayOfTreeNode);
        paramTTree.expandPath(localTreePath);
      }
    }
  }
  
  public static void A(TTree paramTTree)
  {
    AbstractTTreeNode localAbstractTTreeNode = paramTTree.getRootNode();
    TreeNode[] arrayOfTreeNode = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localAbstractTTreeNode);
    TreePath localTreePath = new TreePath(arrayOfTreeNode);
    paramTTree.expandPath(localTreePath);
  }
  
  public static void C(TTree paramTTree)
  {
    AbstractTTreeNode localAbstractTTreeNode = paramTTree.getRootNode();
    Object localObject1;
    Object localObject2;
    if (paramTTree.isRootVisible())
    {
      localObject1 = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localAbstractTTreeNode);
      localObject2 = new TreePath((Object[])localObject1);
      A(paramTTree, (TreePath)localObject2);
    }
    else if ((localAbstractTTreeNode instanceof DataBoxNode))
    {
      localObject1 = paramTTree.getDataBox().getRootElements().iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Element)((Iterator)localObject1).next();
        A(paramTTree, (Element)localObject2);
      }
    }
    else
    {
      localObject1 = (ElementNode)localAbstractTTreeNode;
      localObject2 = ((ElementNode)localObject1).getElement();
      Iterator localIterator = ((Element)localObject2).getChildren().iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        A(paramTTree, localElement);
      }
    }
  }
  
  public static void A(TTree paramTTree, Element paramElement)
  {
    if (paramTTree.isLoaded(paramElement))
    {
      ElementNode localElementNode = paramTTree.getLoadedTreeNodeByElement(paramElement);
      if (localElementNode != null)
      {
        TreeNode[] arrayOfTreeNode = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localElementNode);
        TreePath localTreePath = new TreePath(arrayOfTreeNode);
        A(paramTTree, localTreePath);
      }
    }
  }
  
  public static void B(TTree paramTTree, Element paramElement)
  {
    if (paramTTree.isLoaded(paramElement))
    {
      ElementNode localElementNode = paramTTree.getLoadedTreeNodeByElement(paramElement);
      if (localElementNode != null)
      {
        TreeNode[] arrayOfTreeNode = ((DefaultTreeModel)paramTTree.getModel()).getPathToRoot(localElementNode);
        TreePath localTreePath = new TreePath(arrayOfTreeNode);
        paramTTree.collapsePath(localTreePath);
      }
    }
  }
  
  public static void A(TTree paramTTree, TreePath paramTreePath)
  {
    if (paramTreePath == null) {
      return;
    }
    TreeNode localTreeNode1 = (TreeNode)paramTreePath.getLastPathComponent();
    if (localTreeNode1.getChildCount() >= 0)
    {
      Enumeration localEnumeration = localTreeNode1.children();
      while (localEnumeration.hasMoreElements())
      {
        TreeNode localTreeNode2 = (TreeNode)localEnumeration.nextElement();
        TreePath localTreePath = paramTreePath.pathByAddingChild(localTreeNode2);
        A(paramTTree, localTreePath);
      }
    }
    paramTTree.collapsePath(paramTreePath);
  }
  
  public static int A(TTree paramTTree, AbstractTTreeNode paramAbstractTTreeNode, ElementNode paramElementNode)
  {
    int j = paramAbstractTTreeNode.getChildCount();
    Object localObject;
    int i;
    if ((paramTTree.getSortComparator() == null) || (j == 0) || (!paramTTree.isChildrenSortable(paramElementNode.getElement().getParent())))
    {
      localObject = null;
      if ((paramAbstractTTreeNode instanceof ElementNode))
      {
        Element localElement1 = ((ElementNode)paramAbstractTTreeNode).getElement();
        localObject = localElement1.getChildren();
      }
      else
      {
        localObject = paramTTree.getDataBox().getRootElements();
      }
      int k = ((List)localObject).indexOf(paramElementNode.getElement());
      if (k == ((List)localObject).size() - 1)
      {
        i = j;
      }
      else
      {
        Enumeration localEnumeration2 = paramAbstractTTreeNode.children();
        for (int n = 0; localEnumeration2.hasMoreElements(); n++)
        {
          Element localElement2 = ((ElementNode)localEnumeration2.nextElement()).getElement();
          if (k < ((List)localObject).indexOf(localElement2)) {
            break;
          }
        }
        i = n;
      }
    }
    else
    {
      localObject = new Element[j];
      Enumeration localEnumeration1 = paramAbstractTTreeNode.children();
      for (int m = 0; localEnumeration1.hasMoreElements(); m++) {
        localObject[m] = ((ElementNode)localEnumeration1.nextElement()).getElement();
      }
      i = D.A((Object[])localObject, paramElementNode.getElement(), paramTTree.getSortComparator());
    }
    return i;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.g
 * JD-Core Version:    0.7.0.1
 */
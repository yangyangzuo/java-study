package twaver.base.A.E;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public final class _
{
  public static InputStream A(InputStream paramInputStream, String paramString1, String paramString2)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = paramInputStream.read()) != -1) {
      localByteArrayOutputStream.write(i);
    }
    String str = new String(localByteArrayOutputStream.toByteArray(), paramString1);
    str = new String(str.getBytes(paramString1), paramString2);
    paramInputStream = new ByteArrayInputStream(str.getBytes(paramString2));
    return paramInputStream;
  }
  
  public static void B(String paramString1, String paramString2)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(new FileReader(new File(paramString1)));
    FileWriter localFileWriter = new FileWriter(paramString2);
    for (String str = localBufferedReader.readLine(); str != null; str = localBufferedReader.readLine())
    {
      char[] arrayOfChar = str.toCharArray();
      CharArrayReader localCharArrayReader = new CharArrayReader(arrayOfChar);
      for (int i = 0; i < arrayOfChar.length; i++)
      {
        int j = localCharArrayReader.read();
        if (j < 255) {
          localFileWriter.write((char)j);
        } else {
          localFileWriter.write("\\u" + Integer.toHexString(j));
        }
      }
      localFileWriter.write("\n");
    }
    localBufferedReader.close();
    localFileWriter.flush();
    localFileWriter.close();
  }
  
  public static byte[] A(Object paramObject)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
    localObjectOutputStream.writeObject(paramObject);
    localObjectOutputStream.flush();
    localObjectOutputStream.close();
    return localByteArrayOutputStream.toByteArray();
  }
  
  public static Object A(byte[] paramArrayOfByte)
    throws IOException, ClassNotFoundException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
    Object localObject = localObjectInputStream.readObject();
    localObjectInputStream.close();
    return localObject;
  }
  
  public static byte[] B(Object paramObject)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
    ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localGZIPOutputStream);
    localObjectOutputStream.writeObject(paramObject);
    localObjectOutputStream.flush();
    localObjectOutputStream.close();
    localGZIPOutputStream.close();
    return localByteArrayOutputStream.toByteArray();
  }
  
  public static Object B(byte[] paramArrayOfByte)
    throws IOException, ClassNotFoundException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    GZIPInputStream localGZIPInputStream = new GZIPInputStream(localByteArrayInputStream);
    ObjectInputStream localObjectInputStream = new ObjectInputStream(localGZIPInputStream);
    Object localObject = localObjectInputStream.readObject();
    localObjectInputStream.close();
    localGZIPInputStream.close();
    return localObject;
  }
  
  /* Error */
  public static void A(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: ldc 187
    //   5: invokevirtual 189	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   8: ifeq +31 -> 39
    //   11: aload_0
    //   12: ldc 187
    //   14: invokevirtual 193	java/lang/String:length	()I
    //   17: invokevirtual 196	java/lang/String:substring	(I)Ljava/lang/String;
    //   20: astore_0
    //   21: goto +9 -> 30
    //   24: aload_0
    //   25: iconst_1
    //   26: invokevirtual 196	java/lang/String:substring	(I)Ljava/lang/String;
    //   29: astore_0
    //   30: aload_0
    //   31: ldc 199
    //   33: invokevirtual 189	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   36: ifne -12 -> 24
    //   39: new 201	java/io/FileOutputStream
    //   42: dup
    //   43: aload_0
    //   44: invokespecial 203	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
    //   47: astore_2
    //   48: aload_2
    //   49: aload_1
    //   50: ldc 204
    //   52: invokevirtual 41	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   55: invokevirtual 206	java/io/OutputStream:write	([B)V
    //   58: aload_2
    //   59: invokevirtual 210	java/io/OutputStream:flush	()V
    //   62: goto +43 -> 105
    //   65: astore_3
    //   66: aconst_null
    //   67: aload_3
    //   68: invokestatic 211	twaver/TWaverUtil:handleError	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   71: goto +34 -> 105
    //   74: astore 5
    //   76: jsr +6 -> 82
    //   79: aload 5
    //   81: athrow
    //   82: astore 4
    //   84: aload_2
    //   85: ifnull +18 -> 103
    //   88: aload_2
    //   89: invokevirtual 217	java/io/OutputStream:close	()V
    //   92: goto +11 -> 103
    //   95: astore 6
    //   97: aconst_null
    //   98: aload 6
    //   100: invokestatic 211	twaver/TWaverUtil:handleError	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   103: ret 4
    //   105: jsr -23 -> 82
    //   108: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	109	0	paramString1	String
    //   0	109	1	paramString2	String
    //   1	88	2	localFileOutputStream	java.io.FileOutputStream
    //   65	3	3	localException	java.lang.Exception
    //   82	1	4	localObject1	Object
    //   74	6	5	localObject2	Object
    //   95	4	6	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   2	62	65	java/lang/Exception
    //   2	71	74	finally
    //   105	108	74	finally
    //   88	92	95	java/io/IOException
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E._
 * JD-Core Version:    0.7.0.1
 */
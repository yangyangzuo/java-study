package twaver.base.A.E;

import java.awt.Point;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.Link;
import twaver.TDataBox;

public class W
{
  public static void A(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().size() <= 2) {
      return;
    }
    double d1 = -1.797693134862316E+308D;
    double d2 = -1.797693134862316E+308D;
    double d3 = 0.0D;
    Iterator localIterator = paramTDataBox.selection();
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = (int)(localElement1.getY() - localElement2.getY());
        if (i == 0) {
          i = -1;
        }
        return i;
      }
    });
    int i = 0;
    while (localIterator.hasNext())
    {
      Element localElement1 = (Element)localIterator.next();
      if (!(localElement1 instanceof Link))
      {
        localTreeSet.add(localElement1);
        if (d1 == -1.797693134862316E+308D) {
          d1 = localElement1.getLocation().y;
        } else {
          d1 = Math.min(localElement1.getLocation().y, d1);
        }
        if (d2 == -1.797693134862316E+308D) {
          d2 = localElement1.getLocation().y + localElement1.getHeight();
        } else {
          d2 = Math.max(localElement1.getLocation().y + localElement1.getHeight(), d2);
        }
        i = localElement1.getHeight();
      }
    }
    int j = paramTDataBox.getSelectionModel().size();
    d3 = (d2 - i - d1) / (j - 1);
    double d4 = d1;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      localElement2.setLocation(localElement2.getX(), d4);
      d4 += d3;
    }
  }
  
  public static void K(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().size() <= 2) {
      return;
    }
    double d1 = -1.797693134862316E+308D;
    double d2 = -1.797693134862316E+308D;
    double d3 = 0.0D;
    Iterator localIterator = paramTDataBox.selection();
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = (int)(localElement1.getX() - localElement2.getX());
        if (i == 0) {
          i = -1;
        }
        return i;
      }
    });
    while (localIterator.hasNext())
    {
      Element localElement1 = (Element)localIterator.next();
      if (!(localElement1 instanceof Link))
      {
        localTreeSet.add(localElement1);
        if (d1 == -1.797693134862316E+308D) {
          d1 = localElement1.getLocation().x;
        } else {
          d1 = Math.min(localElement1.getLocation().x, d1);
        }
        if (d2 == -1.797693134862316E+308D) {
          d2 = localElement1.getLocation().x + localElement1.getWidth();
        } else {
          d2 = Math.max(localElement1.getLocation().x + localElement1.getWidth(), d2);
        }
        d3 = localElement1.getWidth();
      }
    }
    d3 = (d2 - d1 - d3) / (paramTDataBox.getSelectionModel().size() - 1);
    double d4 = d1;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      localElement2.setLocation(d4, localElement2.getY());
      d4 += d3;
    }
  }
  
  public static void G(TDataBox paramTDataBox)
  {
    int i = -1;
    Iterator localIterator = paramTDataBox.selection();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link)) {
        if (i == -1) {
          i = localElement.getLocation().y;
        } else {
          i = Math.min(localElement.getLocation().y, i);
        }
      }
    }
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link))
      {
        Point localPoint = new Point(localElement.getLocation().x, i);
        localElement.setLocation(localPoint);
      }
    }
  }
  
  public static void J(TDataBox paramTDataBox)
  {
    int i = -1;
    Iterator localIterator = paramTDataBox.selection();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link)) {
        if (i == -1) {
          i = localElement.getLocation().x + localElement.getWidth();
        } else {
          i = Math.max(localElement.getLocation().x + localElement.getWidth(), i);
        }
      }
    }
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link))
      {
        Point localPoint = new Point(i - localElement.getWidth(), localElement.getLocation().y);
        localElement.setLocation(localPoint);
      }
    }
  }
  
  public static void F(TDataBox paramTDataBox)
  {
    int i = -1;
    int j = -1;
    Iterator localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      Element localElement1 = (Element)localIterator.next();
      if (!(localElement1 instanceof Link))
      {
        if (i == -1) {
          i = localElement1.getLocation().x;
        } else {
          i = Math.min(localElement1.getLocation().x, i);
        }
        if (j == -1) {
          j = localElement1.getLocation().x + localElement1.getWidth();
        } else {
          j = Math.max(localElement1.getLocation().x + localElement1.getWidth(), j);
        }
      }
    }
    int k = (j + i) / 2;
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (!(localElement2 instanceof Link))
      {
        Point localPoint = new Point(k - localElement2.getWidth() / 2, localElement2.getLocation().y);
        localElement2.setLocation(localPoint);
      }
    }
  }
  
  public static void C(TDataBox paramTDataBox)
  {
    int i = -1;
    Iterator localIterator = paramTDataBox.selection();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link)) {
        if (i == -1) {
          i = localElement.getLocation().x;
        } else {
          i = Math.min(localElement.getLocation().x, i);
        }
      }
    }
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link))
      {
        Point localPoint = new Point(i, localElement.getLocation().y);
        localElement.setLocation(localPoint);
      }
    }
  }
  
  public static void H(TDataBox paramTDataBox)
  {
    int i = -1;
    Iterator localIterator = paramTDataBox.selection();
    Element localElement;
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link)) {
        if (i == -1) {
          i = localElement.getLocation().y + localElement.getHeight();
        } else {
          i = Math.max(localElement.getLocation().y + localElement.getHeight(), i);
        }
      }
    }
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      localElement = (Element)localIterator.next();
      if (!(localElement instanceof Link))
      {
        Point localPoint = new Point(localElement.getLocation().x, i - localElement.getHeight());
        localElement.setLocation(localPoint);
      }
    }
  }
  
  public static void E(TDataBox paramTDataBox)
  {
    int i = -1;
    int j = -1;
    Iterator localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      Element localElement1 = (Element)localIterator.next();
      if (!(localElement1 instanceof Link))
      {
        if (i == -1) {
          i = localElement1.getLocation().y;
        } else {
          i = Math.min(localElement1.getLocation().y, i);
        }
        if (j == -1) {
          j = localElement1.getLocation().x + localElement1.getWidth();
        } else {
          j = Math.max(localElement1.getLocation().x + localElement1.getWidth(), j);
        }
      }
    }
    int k = (j + i) / 2;
    localIterator = paramTDataBox.selection();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (!(localElement2 instanceof Link))
      {
        Point localPoint = new Point(localElement2.getLocation().x, k - localElement2.getHeight() / 2);
        localElement2.setLocation(localPoint);
      }
    }
  }
  
  public static void D(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().isEmpty()) {
      return;
    }
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = localElement1.getLocation().x;
        int j = localElement2.getLocation().x;
        if (i == j) {
          return 1;
        }
        return i - j;
      }
    });
    Iterator localIterator = null;
    DataBoxSelectionModel localDataBoxSelectionModel = paramTDataBox.getSelectionModel();
    Element localElement1;
    if (localDataBoxSelectionModel.size() == 1)
    {
      localElement1 = localDataBoxSelectionModel.lastElement();
      localIterator = localElement1.children();
    }
    else
    {
      localIterator = paramTDataBox.selection();
    }
    while (localIterator.hasNext())
    {
      localElement1 = (Element)localIterator.next();
      if (localElement1.getLocation() != null) {
        localTreeSet.add(localElement1);
      }
    }
    if (localTreeSet.isEmpty()) {
      return;
    }
    int i = -2147483648;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (i == -2147483648)
      {
        i = localElement2.getLocation().x + localElement2.getWidth();
      }
      else
      {
        localElement2.setLocation(i, localElement2.getLocation().y);
        i += localElement2.getWidth();
      }
    }
  }
  
  public static void B(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().isEmpty()) {
      return;
    }
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = localElement1.getLocation().x + localElement1.getWidth();
        int j = localElement2.getLocation().x + localElement2.getWidth();
        if (i == j) {
          return 1;
        }
        return j - i;
      }
    });
    Iterator localIterator = null;
    DataBoxSelectionModel localDataBoxSelectionModel = paramTDataBox.getSelectionModel();
    Element localElement1;
    if (localDataBoxSelectionModel.size() == 1)
    {
      localElement1 = localDataBoxSelectionModel.lastElement();
      localIterator = localElement1.children();
    }
    else
    {
      localIterator = paramTDataBox.selection();
    }
    while (localIterator.hasNext())
    {
      localElement1 = (Element)localIterator.next();
      if (localElement1.getLocation() != null) {
        localTreeSet.add(localElement1);
      }
    }
    if (localTreeSet.isEmpty()) {
      return;
    }
    int i = -2147483648;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (i == -2147483648)
      {
        i = localElement2.getLocation().x;
      }
      else
      {
        i -= localElement2.getWidth();
        localElement2.setLocation(i, localElement2.getLocation().y);
      }
    }
  }
  
  public static void L(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().isEmpty()) {
      return;
    }
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = localElement1.getLocation().y + localElement1.getHeight();
        int j = localElement2.getLocation().y + localElement2.getHeight();
        if (i == j) {
          return 1;
        }
        return j - i;
      }
    });
    Iterator localIterator = null;
    DataBoxSelectionModel localDataBoxSelectionModel = paramTDataBox.getSelectionModel();
    Element localElement1;
    if (localDataBoxSelectionModel.size() == 1)
    {
      localElement1 = localDataBoxSelectionModel.lastElement();
      localIterator = localElement1.children();
    }
    else
    {
      localIterator = paramTDataBox.selection();
    }
    while (localIterator.hasNext())
    {
      localElement1 = (Element)localIterator.next();
      if (localElement1.getLocation() != null) {
        localTreeSet.add(localElement1);
      }
    }
    if (localTreeSet.isEmpty()) {
      return;
    }
    int i = -2147483648;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (i == -2147483648)
      {
        i = localElement2.getLocation().y;
      }
      else
      {
        localElement2.setLocation(localElement2.getLocation().x, i - localElement2.getHeight());
        i -= localElement2.getHeight();
      }
    }
  }
  
  public static void I(TDataBox paramTDataBox)
  {
    if (paramTDataBox.getSelectionModel().isEmpty()) {
      return;
    }
    TreeSet localTreeSet = new TreeSet(new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Element localElement1 = (Element)paramAnonymousObject1;
        Element localElement2 = (Element)paramAnonymousObject2;
        int i = localElement1.getLocation().y;
        int j = localElement2.getLocation().y;
        if (i == j) {
          return 1;
        }
        return i - j;
      }
    });
    Iterator localIterator = null;
    DataBoxSelectionModel localDataBoxSelectionModel = paramTDataBox.getSelectionModel();
    Element localElement1;
    if (localDataBoxSelectionModel.size() == 1)
    {
      localElement1 = localDataBoxSelectionModel.lastElement();
      localIterator = localElement1.children();
    }
    else
    {
      localIterator = paramTDataBox.selection();
    }
    while (localIterator.hasNext())
    {
      localElement1 = (Element)localIterator.next();
      if (localElement1.getLocation() != null) {
        localTreeSet.add(localElement1);
      }
    }
    if (localTreeSet.isEmpty()) {
      return;
    }
    int i = -2147483648;
    localIterator = localTreeSet.iterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if (i == -2147483648)
      {
        i = localElement2.getLocation().y + localElement2.getHeight();
      }
      else
      {
        localElement2.setLocation(localElement2.getLocation().x, i);
        i += localElement2.getHeight();
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.E.W
 * JD-Core Version:    0.7.0.1
 */
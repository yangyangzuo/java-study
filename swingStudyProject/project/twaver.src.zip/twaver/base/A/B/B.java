package twaver.base.A.B;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;

public abstract class B
  extends C
{
  public static final int G = 0;
  public static final int D = 1;
  public static final int B = 2;
  public static final int H = 0;
  public static final int C = 1;
  protected int F = 0;
  protected int E = 1;
  protected Rectangle I;
  protected Rectangle A;
  
  public void A(int paramInt)
  {
    this.F = paramInt;
  }
  
  public int B()
  {
    return this.F;
  }
  
  public void B(int paramInt)
  {
    this.E = paramInt;
  }
  
  public int A()
  {
    return this.E;
  }
  
  protected abstract void A(int paramInt1, int paramInt2, float[] paramArrayOfFloat);
  
  protected void A(Rectangle paramRectangle) {}
  
  public BufferedImage filter(BufferedImage paramBufferedImage1, BufferedImage paramBufferedImage2)
  {
    int i = paramBufferedImage1.getWidth();
    int j = paramBufferedImage1.getHeight();
    paramBufferedImage1.getType();
    paramBufferedImage1.getRaster();
    this.A = new Rectangle(0, 0, i, j);
    this.I = new Rectangle(0, 0, i, j);
    A(this.I);
    if (paramBufferedImage2 == null)
    {
      localObject = paramBufferedImage1.getColorModel();
      paramBufferedImage2 = new BufferedImage((ColorModel)localObject, ((ColorModel)localObject).createCompatibleWritableRaster(this.I.width, this.I.height), ((ColorModel)localObject).isAlphaPremultiplied(), null);
    }
    paramBufferedImage2.getRaster();
    Object localObject = B(paramBufferedImage1, 0, 0, i, j, null);
    if (this.E == 0) {
      return A(paramBufferedImage2, i, j, (int[])localObject, this.I);
    }
    int k = i;
    int m = j;
    int n = i - 1;
    int i1 = j - 1;
    int i2 = this.I.width;
    int i3 = this.I.height;
    int[] arrayOfInt = new int[i2];
    int i4 = this.I.x;
    int i5 = this.I.y;
    float[] arrayOfFloat = new float[2];
    for (int i6 = 0; i6 < i3; i6++)
    {
      for (int i7 = 0; i7 < i2; i7++)
      {
        A(i4 + i7, i5 + i6, arrayOfFloat);
        int i8 = (int)Math.floor(arrayOfFloat[0]);
        int i9 = (int)Math.floor(arrayOfFloat[1]);
        float f1 = arrayOfFloat[0] - i8;
        float f2 = arrayOfFloat[1] - i9;
        int i10;
        int i11;
        int i12;
        int i13;
        if ((i8 >= 0) && (i8 < n) && (i9 >= 0) && (i9 < i1))
        {
          int i14 = k * i9 + i8;
          i10 = localObject[i14];
          i11 = localObject[(i14 + 1)];
          i12 = localObject[(i14 + k)];
          i13 = localObject[(i14 + k + 1)];
        }
        else
        {
          i10 = A((int[])localObject, i8, i9, k, m);
          i11 = A((int[])localObject, i8 + 1, i9, k, m);
          i12 = A((int[])localObject, i8, i9 + 1, k, m);
          i13 = A((int[])localObject, i8 + 1, i9 + 1, k, m);
        }
        arrayOfInt[i7] = D.A(f1, f2, i10, i11, i12, i13);
      }
      A(paramBufferedImage2, 0, i6, this.I.width, 1, arrayOfInt);
    }
    return paramBufferedImage2;
  }
  
  private final int A(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((paramInt1 < 0) || (paramInt1 >= paramInt3) || (paramInt2 < 0) || (paramInt2 >= paramInt4))
    {
      switch (this.F)
      {
      case 0: 
      default: 
        return 0;
      case 2: 
        return paramArrayOfInt[(D.A(paramInt2, paramInt4) * paramInt3 + D.A(paramInt1, paramInt3))];
      }
      return paramArrayOfInt[(D.A(paramInt2, 0, paramInt4 - 1) * paramInt3 + D.A(paramInt1, 0, paramInt3 - 1))];
    }
    return paramArrayOfInt[(paramInt2 * paramInt3 + paramInt1)];
  }
  
  protected BufferedImage A(BufferedImage paramBufferedImage, int paramInt1, int paramInt2, int[] paramArrayOfInt, Rectangle paramRectangle)
  {
    int i = paramInt1;
    int j = paramInt2;
    int k = paramRectangle.width;
    int m = paramRectangle.height;
    int[] arrayOfInt1 = new int[k];
    int n = paramRectangle.x;
    int i1 = paramRectangle.y;
    int[] arrayOfInt2 = new int[4];
    float[] arrayOfFloat = new float[2];
    for (int i4 = 0; i4 < m; i4++)
    {
      for (int i5 = 0; i5 < k; i5++)
      {
        A(n + i5, i1 + i4, arrayOfFloat);
        int i2 = (int)arrayOfFloat[0];
        int i3 = (int)arrayOfFloat[1];
        int i6;
        if ((arrayOfFloat[0] < 0.0F) || (i2 >= i) || (arrayOfFloat[1] < 0.0F) || (i3 >= j))
        {
          switch (this.F)
          {
          case 0: 
          default: 
            i6 = 0;
            break;
          case 2: 
            i6 = paramArrayOfInt[(D.A(i3, j) * i + D.A(i2, i))];
            break;
          case 1: 
            i6 = paramArrayOfInt[(D.A(i3, 0, j - 1) * i + D.A(i2, 0, i - 1))];
          }
          arrayOfInt1[i5] = i6;
        }
        else
        {
          i6 = i * i3 + i2;
          arrayOfInt2[0] = paramArrayOfInt[i6];
          arrayOfInt1[i5] = paramArrayOfInt[i6];
        }
      }
      A(paramBufferedImage, 0, i4, paramRectangle.width, 1, arrayOfInt1);
    }
    return paramBufferedImage;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.B.B
 * JD-Core Version:    0.7.0.1
 */
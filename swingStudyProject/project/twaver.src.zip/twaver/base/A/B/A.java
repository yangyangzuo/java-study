package twaver.base.A.B;

import java.awt.Rectangle;

public class A
  extends B
{
  private float e;
  private float P;
  private float d;
  private float O;
  private float c;
  private float N;
  private float b;
  private float L;
  private float M;
  private float U;
  private float K;
  private float S;
  private float J;
  private float Q;
  private float a;
  private float _;
  private float Z;
  private float Y;
  private float X;
  private float W;
  private float V;
  private float T;
  private float R;
  
  public A()
  {
    this(0.0F, 0.0F, 100.0F, 0.0F, 100.0F, 100.0F, 0.0F, 100.0F);
  }
  
  public A(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
  {
    A(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
  }
  
  public void A(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
  {
    this.e = paramFloat1;
    this.P = paramFloat2;
    this.d = paramFloat3;
    this.O = paramFloat4;
    this.c = paramFloat5;
    this.N = paramFloat6;
    this.b = paramFloat7;
    this.L = paramFloat8;
    this.M = (paramFloat3 - paramFloat5);
    this.U = (paramFloat4 - paramFloat6);
    this.K = (paramFloat7 - paramFloat5);
    this.S = (paramFloat8 - paramFloat6);
    this.J = (paramFloat1 - paramFloat3 + paramFloat5 - paramFloat7);
    this.Q = (paramFloat2 - paramFloat4 + paramFloat6 - paramFloat8);
    float f1;
    float f4;
    float f7;
    float f2;
    float f5;
    float f8;
    float f6;
    float f3;
    if ((this.J == 0.0F) && (this.Q == 0.0F))
    {
      f1 = paramFloat3 - paramFloat1;
      f4 = paramFloat5 - paramFloat3;
      f7 = paramFloat1;
      f2 = paramFloat4 - paramFloat2;
      f5 = paramFloat6 - paramFloat4;
      f8 = paramFloat2;
      f3 = f6 = 0.0F;
    }
    else
    {
      f3 = (this.J * this.S - this.K * this.Q) / (this.M * this.S - this.U * this.K);
      f6 = (this.M * this.Q - this.U * this.J) / (this.M * this.S - this.U * this.K);
      f1 = paramFloat3 - paramFloat1 + f3 * paramFloat3;
      f4 = paramFloat7 - paramFloat1 + f6 * paramFloat7;
      f7 = paramFloat1;
      f2 = paramFloat4 - paramFloat2 + f3 * paramFloat4;
      f5 = paramFloat8 - paramFloat2 + f6 * paramFloat8;
      f8 = paramFloat2;
    }
    this.a = (f5 - f8 * f6);
    this._ = (f7 * f6 - f4);
    this.Z = (f4 * f8 - f7 * f5);
    this.Y = (f8 * f3 - f2);
    this.X = (f1 - f7 * f3);
    this.W = (f7 * f2 - f1 * f8);
    this.V = (f2 * f6 - f5 * f3);
    this.T = (f4 * f3 - f1 * f6);
    this.R = (f1 * f5 - f4 * f2);
  }
  
  protected void A(Rectangle paramRectangle)
  {
    paramRectangle.x = ((int)Math.min(Math.min(this.e, this.d), Math.min(this.c, this.b)));
    paramRectangle.y = ((int)Math.min(Math.min(this.P, this.O), Math.min(this.N, this.L)));
    paramRectangle.width = ((int)Math.max(Math.max(this.e, this.d), Math.max(this.c, this.b)) - paramRectangle.x);
    paramRectangle.height = ((int)Math.max(Math.max(this.P, this.O), Math.max(this.N, this.L)) - paramRectangle.y);
  }
  
  public float D()
  {
    return this.e - (int)Math.min(Math.min(this.e, this.d), Math.min(this.c, this.b));
  }
  
  public float C()
  {
    return this.P - (int)Math.min(Math.min(this.P, this.O), Math.min(this.N, this.L));
  }
  
  protected void A(int paramInt1, int paramInt2, float[] paramArrayOfFloat)
  {
    paramArrayOfFloat[0] = (this.A.width * (this.a * paramInt1 + this._ * paramInt2 + this.Z) / (this.V * paramInt1 + this.T * paramInt2 + this.R));
    paramArrayOfFloat[1] = (this.A.height * (this.Y * paramInt1 + this.X * paramInt2 + this.W) / (this.V * paramInt1 + this.T * paramInt2 + this.R));
  }
  
  public String toString()
  {
    return "Distort/Perspective...";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.B.A
 * JD-Core Version:    0.7.0.1
 */
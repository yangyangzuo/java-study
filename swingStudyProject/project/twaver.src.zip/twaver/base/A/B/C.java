package twaver.base.A.B;

import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;

public abstract class C
  implements BufferedImageOp, Cloneable
{
  public BufferedImage createCompatibleDestImage(BufferedImage paramBufferedImage, ColorModel paramColorModel)
  {
    if (paramColorModel == null) {
      paramColorModel = paramBufferedImage.getColorModel();
    }
    return new BufferedImage(paramColorModel, paramColorModel.createCompatibleWritableRaster(paramBufferedImage.getWidth(), paramBufferedImage.getHeight()), paramColorModel.isAlphaPremultiplied(), null);
  }
  
  public Rectangle2D getBounds2D(BufferedImage paramBufferedImage)
  {
    return new Rectangle(0, 0, paramBufferedImage.getWidth(), paramBufferedImage.getHeight());
  }
  
  public Point2D getPoint2D(Point2D paramPoint2D1, Point2D paramPoint2D2)
  {
    if (paramPoint2D2 == null) {
      paramPoint2D2 = new Point2D.Double();
    }
    paramPoint2D2.setLocation(paramPoint2D1.getX(), paramPoint2D1.getY());
    return paramPoint2D2;
  }
  
  public RenderingHints getRenderingHints()
  {
    return null;
  }
  
  public int[] B(BufferedImage paramBufferedImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    int i = paramBufferedImage.getType();
    if ((i == 2) || (i == 1)) {
      return (int[])paramBufferedImage.getRaster().getDataElements(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
    }
    return paramBufferedImage.getRGB(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, 0, paramInt3);
  }
  
  public void A(BufferedImage paramBufferedImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    int i = paramBufferedImage.getType();
    if ((i == 2) || (i == 1)) {
      paramBufferedImage.getRaster().setDataElements(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
    } else {
      paramBufferedImage.setRGB(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, 0, paramInt3);
    }
  }
  
  public Object clone()
  {
    try
    {
      return super.clone();
    }
    catch (CloneNotSupportedException localCloneNotSupportedException) {}
    return null;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.B.C
 * JD-Core Version:    0.7.0.1
 */
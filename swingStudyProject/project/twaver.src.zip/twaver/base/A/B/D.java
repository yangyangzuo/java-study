package twaver.base.A.B;

public class D
{
  public static final float N = 3.141593F;
  public static final float A = 1.570796F;
  public static final float Q = 0.7853982F;
  public static final float O = 6.283186F;
  private static final float L = -0.5F;
  private static final float J = 1.5F;
  private static final float H = -1.5F;
  private static final float F = 0.5F;
  private static final float T = 1.0F;
  private static final float S = -2.5F;
  private static final float R = 2.0F;
  private static final float P = -0.5F;
  private static final float E = -0.5F;
  private static final float D = 0.0F;
  private static final float C = 0.5F;
  private static final float B = 0.0F;
  private static final float M = 0.0F;
  private static final float K = 1.0F;
  private static final float I = 0.0F;
  private static final float G = 0.0F;
  
  public static float C(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 / ((1.0F / paramFloat2 - 2.0F) * (1.0F - paramFloat1) + 1.0F);
  }
  
  public static float B(float paramFloat1, float paramFloat2)
  {
    float f = (1.0F / paramFloat2 - 2.0F) * (1.0F - 2.0F * paramFloat1);
    if (paramFloat1 < 0.5D) {
      return paramFloat1 / (f + 1.0F);
    }
    return (f - paramFloat1) / (f - 1.0F);
  }
  
  public static float D(float paramFloat1, float paramFloat2)
  {
    return paramFloat2 < paramFloat1 ? 0.0F : 1.0F;
  }
  
  public static float C(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return (paramFloat3 < paramFloat1) || (paramFloat3 >= paramFloat2) ? 0.0F : 1.0F;
  }
  
  public static float A(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
  {
    if ((paramFloat5 < paramFloat1) || (paramFloat5 >= paramFloat4)) {
      return 0.0F;
    }
    if (paramFloat5 >= paramFloat2)
    {
      if (paramFloat5 < paramFloat3) {
        return 1.0F;
      }
      paramFloat5 = (paramFloat5 - paramFloat3) / (paramFloat4 - paramFloat3);
      return 1.0F - paramFloat5 * paramFloat5 * (3.0F - 2.0F * paramFloat5);
    }
    paramFloat5 = (paramFloat5 - paramFloat1) / (paramFloat2 - paramFloat1);
    return paramFloat5 * paramFloat5 * (3.0F - 2.0F * paramFloat5);
  }
  
  public static float A(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat3 < paramFloat1) {
      return 0.0F;
    }
    if (paramFloat3 >= paramFloat2) {
      return 1.0F;
    }
    paramFloat3 = (paramFloat3 - paramFloat1) / (paramFloat2 - paramFloat1);
    return paramFloat3 * paramFloat3 * (3.0F - 2.0F * paramFloat3);
  }
  
  public static float C(float paramFloat)
  {
    paramFloat = 1.0F - paramFloat;
    return (float)Math.sqrt(1.0F - paramFloat * paramFloat);
  }
  
  public static float A(float paramFloat)
  {
    return 1.0F - (float)Math.sqrt(1.0F - paramFloat * paramFloat);
  }
  
  public static float B(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return paramFloat1 > paramFloat3 ? paramFloat3 : paramFloat1 < paramFloat2 ? paramFloat2 : paramFloat1;
  }
  
  public static int A(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 > paramInt3 ? paramInt3 : paramInt1 < paramInt2 ? paramInt2 : paramInt1;
  }
  
  public static double A(double paramDouble1, double paramDouble2)
  {
    int i = (int)(paramDouble1 / paramDouble2);
    paramDouble1 -= i * paramDouble2;
    if (paramDouble1 < 0.0D) {
      return paramDouble1 + paramDouble2;
    }
    return paramDouble1;
  }
  
  public static float A(float paramFloat1, float paramFloat2)
  {
    int i = (int)(paramFloat1 / paramFloat2);
    paramFloat1 -= i * paramFloat2;
    if (paramFloat1 < 0.0F) {
      return paramFloat1 + paramFloat2;
    }
    return paramFloat1;
  }
  
  public static int A(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / paramInt2;
    paramInt1 -= i * paramInt2;
    if (paramInt1 < 0) {
      return paramInt1 + paramInt2;
    }
    return paramInt1;
  }
  
  public static float B(float paramFloat)
  {
    float f = A(paramFloat, 1.0F);
    return 2.0F * (f < 0.5D ? f : 1.0F - f);
  }
  
  public static float D(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return paramFloat2 + paramFloat1 * (paramFloat3 - paramFloat2);
  }
  
  public static int B(float paramFloat, int paramInt1, int paramInt2)
  {
    return (int)(paramInt1 + paramFloat * (paramInt2 - paramInt1));
  }
  
  public static int A(float paramFloat, int paramInt1, int paramInt2)
  {
    int i = paramInt1 >> 24 & 0xFF;
    int j = paramInt1 >> 16 & 0xFF;
    int k = paramInt1 >> 8 & 0xFF;
    int m = paramInt1 & 0xFF;
    int n = paramInt2 >> 24 & 0xFF;
    int i1 = paramInt2 >> 16 & 0xFF;
    int i2 = paramInt2 >> 8 & 0xFF;
    int i3 = paramInt2 & 0xFF;
    i = B(paramFloat, i, n);
    j = B(paramFloat, j, i1);
    k = B(paramFloat, k, i2);
    m = B(paramFloat, m, i3);
    return i << 24 | j << 16 | k << 8 | m;
  }
  
  public static int A(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt1 >> 24 & 0xFF;
    int j = paramInt1 >> 16 & 0xFF;
    int k = paramInt1 >> 8 & 0xFF;
    int m = paramInt1 & 0xFF;
    int n = paramInt2 >> 24 & 0xFF;
    int i1 = paramInt2 >> 16 & 0xFF;
    int i2 = paramInt2 >> 8 & 0xFF;
    int i3 = paramInt2 & 0xFF;
    int i4 = paramInt3 >> 24 & 0xFF;
    int i5 = paramInt3 >> 16 & 0xFF;
    int i6 = paramInt3 >> 8 & 0xFF;
    int i7 = paramInt3 & 0xFF;
    int i8 = paramInt4 >> 24 & 0xFF;
    int i9 = paramInt4 >> 16 & 0xFF;
    int i10 = paramInt4 >> 8 & 0xFF;
    int i11 = paramInt4 & 0xFF;
    float f3 = 1.0F - paramFloat1;
    float f4 = 1.0F - paramFloat2;
    float f1 = f3 * i + paramFloat1 * n;
    float f2 = f3 * i4 + paramFloat1 * i8;
    int i12 = (int)(f4 * f1 + paramFloat2 * f2);
    f1 = f3 * j + paramFloat1 * i1;
    f2 = f3 * i5 + paramFloat1 * i9;
    int i13 = (int)(f4 * f1 + paramFloat2 * f2);
    f1 = f3 * k + paramFloat1 * i2;
    f2 = f3 * i6 + paramFloat1 * i10;
    int i14 = (int)(f4 * f1 + paramFloat2 * f2);
    f1 = f3 * m + paramFloat1 * i3;
    f2 = f3 * i7 + paramFloat1 * i11;
    int i15 = (int)(f4 * f1 + paramFloat2 * f2);
    return i12 << 24 | i13 << 16 | i14 << 8 | i15;
  }
  
  public static int A(int paramInt)
  {
    int i = paramInt >> 16 & 0xFF;
    int j = paramInt >> 8 & 0xFF;
    int k = paramInt & 0xFF;
    return (int)(i * 0.299F + j * 0.587F + k * 0.114F);
  }
  
  public static float A(float paramFloat, int paramInt, float[] paramArrayOfFloat)
  {
    int j = paramInt - 3;
    if (j < 1) {
      throw new IllegalArgumentException("Too few knots in spline");
    }
    paramFloat = B(paramFloat, 0.0F, 1.0F) * j;
    int i = (int)paramFloat;
    if (i > paramInt - 4) {
      i = paramInt - 4;
    }
    paramFloat -= i;
    float f1 = paramArrayOfFloat[i];
    float f2 = paramArrayOfFloat[(i + 1)];
    float f3 = paramArrayOfFloat[(i + 2)];
    float f4 = paramArrayOfFloat[(i + 3)];
    float f8 = -0.5F * f1 + 1.5F * f2 + -1.5F * f3 + 0.5F * f4;
    float f7 = 1.0F * f1 + -2.5F * f2 + 2.0F * f3 + -0.5F * f4;
    float f6 = -0.5F * f1 + 0.0F * f2 + 0.5F * f3 + 0.0F * f4;
    float f5 = 0.0F * f1 + 1.0F * f2 + 0.0F * f3 + 0.0F * f4;
    return ((f8 * paramFloat + f7) * paramFloat + f6) * paramFloat + f5;
  }
  
  public static float A(float paramFloat, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int j = paramInt - 3;
    if (j < 1) {
      throw new IllegalArgumentException("Too few knots in spline");
    }
    for (int i = 0; i < j; i++) {
      if (paramArrayOfInt1[(i + 1)] > paramFloat) {
        break;
      }
    }
    if (i > paramInt - 3) {
      i = paramInt - 3;
    }
    float f9 = (paramFloat - paramArrayOfInt1[i]) / (paramArrayOfInt1[(i + 1)] - paramArrayOfInt1[i]);
    i--;
    if (i < 0)
    {
      i = 0;
      f9 = 0.0F;
    }
    float f1 = paramArrayOfInt2[i];
    float f2 = paramArrayOfInt2[(i + 1)];
    float f3 = paramArrayOfInt2[(i + 2)];
    float f4 = paramArrayOfInt2[(i + 3)];
    float f8 = -0.5F * f1 + 1.5F * f2 + -1.5F * f3 + 0.5F * f4;
    float f7 = 1.0F * f1 + -2.5F * f2 + 2.0F * f3 + -0.5F * f4;
    float f6 = -0.5F * f1 + 0.0F * f2 + 0.5F * f3 + 0.0F * f4;
    float f5 = 0.0F * f1 + 1.0F * f2 + 0.0F * f3 + 0.0F * f4;
    return ((f8 * f9 + f7) * f9 + f6) * f9 + f5;
  }
  
  public static int A(float paramFloat, int paramInt, int[] paramArrayOfInt)
  {
    int j = paramInt - 3;
    if (j < 1) {
      throw new IllegalArgumentException("Too few knots in spline");
    }
    paramFloat = B(paramFloat, 0.0F, 1.0F) * j;
    int i = (int)paramFloat;
    if (i > paramInt - 4) {
      i = paramInt - 4;
    }
    paramFloat -= i;
    int k = 0;
    for (int m = 0; m < 4; m++)
    {
      int n = m * 8;
      float f1 = paramArrayOfInt[i] >> n & 0xFF;
      float f2 = paramArrayOfInt[(i + 1)] >> n & 0xFF;
      float f3 = paramArrayOfInt[(i + 2)] >> n & 0xFF;
      float f4 = paramArrayOfInt[(i + 3)] >> n & 0xFF;
      float f8 = -0.5F * f1 + 1.5F * f2 + -1.5F * f3 + 0.5F * f4;
      float f7 = 1.0F * f1 + -2.5F * f2 + 2.0F * f3 + -0.5F * f4;
      float f6 = -0.5F * f1 + 0.0F * f2 + 0.5F * f3 + 0.0F * f4;
      float f5 = 0.0F * f1 + 1.0F * f2 + 0.0F * f3 + 0.0F * f4;
      int i1 = (int)(((f8 * paramFloat + f7) * paramFloat + f6) * paramFloat + f5);
      if (i1 < 0) {
        i1 = 0;
      } else if (i1 > 255) {
        i1 = 255;
      }
      k |= i1 << n;
    }
    return k;
  }
  
  public static int A(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int j = paramInt2 - 3;
    if (j < 1) {
      throw new IllegalArgumentException("Too few knots in spline");
    }
    for (int i = 0; i < j; i++) {
      if (paramArrayOfInt1[(i + 1)] > paramInt1) {
        break;
      }
    }
    if (i > paramInt2 - 3) {
      i = paramInt2 - 3;
    }
    float f9 = (paramInt1 - paramArrayOfInt1[i]) / (paramArrayOfInt1[(i + 1)] - paramArrayOfInt1[i]);
    i--;
    if (i < 0)
    {
      i = 0;
      f9 = 0.0F;
    }
    int k = 0;
    for (int m = 0; m < 4; m++)
    {
      int n = m * 8;
      float f1 = paramArrayOfInt2[i] >> n & 0xFF;
      float f2 = paramArrayOfInt2[(i + 1)] >> n & 0xFF;
      float f3 = paramArrayOfInt2[(i + 2)] >> n & 0xFF;
      float f4 = paramArrayOfInt2[(i + 3)] >> n & 0xFF;
      float f8 = -0.5F * f1 + 1.5F * f2 + -1.5F * f3 + 0.5F * f4;
      float f7 = 1.0F * f1 + -2.5F * f2 + 2.0F * f3 + -0.5F * f4;
      float f6 = -0.5F * f1 + 0.0F * f2 + 0.5F * f3 + 0.0F * f4;
      float f5 = 0.0F * f1 + 1.0F * f2 + 0.0F * f3 + 0.0F * f4;
      int i1 = (int)(((f8 * f9 + f7) * f9 + f6) * f9 + f5);
      if (i1 < 0) {
        i1 = 0;
      } else if (i1 > 255) {
        i1 = 255;
      }
      k |= i1 << n;
    }
    return k;
  }
  
  public static void A(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt1, int paramInt2, int paramInt3, float[] paramArrayOfFloat)
  {
    int i6 = paramInt2;
    int i7 = paramInt2;
    int i8 = paramArrayOfInt1.length;
    float[] arrayOfFloat = new float[paramInt1 + 2];
    int i = 0;
    for (int j = 0; j < paramInt1; j++)
    {
      while (paramArrayOfFloat[(i + 1)] < j) {
        i++;
      }
      arrayOfFloat[j] = (i + (j - paramArrayOfFloat[i]) / (paramArrayOfFloat[(i + 1)] - paramArrayOfFloat[i]));
    }
    arrayOfFloat[paramInt1] = paramInt1;
    arrayOfFloat[(paramInt1 + 1)] = paramInt1;
    float f2 = 1.0F;
    float f3 = arrayOfFloat[1];
    float f1 = f3;
    float f7;
    float f6;
    float f5;
    float f4 = f5 = f6 = f7 = 0.0F;
    int i9 = paramArrayOfInt1[i6];
    int k = i9 >> 24 & 0xFF;
    int m = i9 >> 16 & 0xFF;
    int n = i9 >> 8 & 0xFF;
    int i1 = i9 & 0xFF;
    i6 += paramInt3;
    i9 = paramArrayOfInt1[i6];
    int i2 = i9 >> 24 & 0xFF;
    int i3 = i9 >> 16 & 0xFF;
    int i4 = i9 >> 8 & 0xFF;
    int i5 = i9 & 0xFF;
    i6 += paramInt3;
    i = 1;
    while (i <= paramInt1)
    {
      float f8 = f2 * k + (1.0F - f2) * i2;
      float f9 = f2 * m + (1.0F - f2) * i3;
      float f10 = f2 * n + (1.0F - f2) * i4;
      float f11 = f2 * i1 + (1.0F - f2) * i5;
      if (f2 < f3)
      {
        f4 += f8 * f2;
        f5 += f9 * f2;
        f6 += f10 * f2;
        f7 += f11 * f2;
        f3 -= f2;
        f2 = 1.0F;
        k = i2;
        m = i3;
        n = i4;
        i1 = i5;
        if (i6 < i8) {
          i9 = paramArrayOfInt1[i6];
        }
        i2 = i9 >> 24 & 0xFF;
        i3 = i9 >> 16 & 0xFF;
        i4 = i9 >> 8 & 0xFF;
        i5 = i9 & 0xFF;
        i6 += paramInt3;
      }
      else
      {
        f4 += f8 * f3;
        f5 += f9 * f3;
        f6 += f10 * f3;
        f7 += f11 * f3;
        paramArrayOfInt2[i7] = ((int)Math.min(f4 / f1, 255.0F) << 24 | (int)Math.min(f5 / f1, 255.0F) << 16 | (int)Math.min(f6 / f1, 255.0F) << 8 | (int)Math.min(f7 / f1, 255.0F));
        i7 += paramInt3;
        f4 = f5 = f6 = f7 = 0.0F;
        f2 -= f3;
        f3 = arrayOfFloat[(i + 1)] - arrayOfFloat[i];
        f1 = f3;
        i++;
      }
    }
  }
  
  public static void B(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    paramInt2 += paramInt1;
    for (int i = paramInt1; i < paramInt2; i++)
    {
      int j = paramArrayOfInt[i];
      int k = j >> 24 & 0xFF;
      int m = j >> 16 & 0xFF;
      int n = j >> 8 & 0xFF;
      int i1 = j & 0xFF;
      float f = k * 0.003921569F;
      m = (int)(m * f);
      n = (int)(n * f);
      i1 = (int)(i1 * f);
      paramArrayOfInt[i] = (k << 24 | m << 16 | n << 8 | i1);
    }
  }
  
  public static void A(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    paramInt2 += paramInt1;
    for (int i = paramInt1; i < paramInt2; i++)
    {
      int j = paramArrayOfInt[i];
      int k = j >> 24 & 0xFF;
      int m = j >> 16 & 0xFF;
      int n = j >> 8 & 0xFF;
      int i1 = j & 0xFF;
      if ((k != 0) && (k != 255))
      {
        float f = 255.0F / k;
        m = (int)(m * f);
        n = (int)(n * f);
        i1 = (int)(i1 * f);
        if (m > 255) {
          m = 255;
        }
        if (n > 255) {
          n = 255;
        }
        if (i1 > 255) {
          i1 = 255;
        }
        paramArrayOfInt[i] = (k << 24 | m << 16 | n << 8 | i1);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.B.D
 * JD-Core Version:    0.7.0.1
 */
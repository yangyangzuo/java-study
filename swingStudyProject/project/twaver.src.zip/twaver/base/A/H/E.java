package twaver.base.A.H;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.LineMetrics;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Constructor;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.ImageIcon;
import twaver.AbstractElement;
import twaver.AlarmSeverity;
import twaver.AlarmState;
import twaver.Element;
import twaver.Generator;
import twaver.Group;
import twaver.Link;
import twaver.TUIManager;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.base.A.D.H;
import twaver.base.A.E.K;
import twaver.base.A.E.M;
import twaver.base.A.E.a;
import twaver.base.A.E.l;
import twaver.base.PositionStruct;
import twaver.network.ui.IconAttachmentHolder;
import twaver.web.WebUtil;
import twaver.web.svg.network.SVGBlinkingRule;
import twaver.web.svg.network.SVGContext;
import twaver.web.svg.network.SVGStruct;
import twaver.web.svg.network.TSVGNetwork;
import twaver.web.svg.network.ui.ElementSVGUI;
import twaver.web.svg.network.ui.LinkSVGUI;
import twaver.web.svg.network.ui.SVGAttachment;

public class E
{
  private static final NumberFormat G = TUIManager.getNumberFormat("web.path.numberformat");
  private static final float C = TUIManager.getFloat("web.path.distance");
  private static final Class[] H = { String.class, ElementSVGUI.class };
  private static final String D = TUIManager.getString("message.close.url");
  private static final String B = TUIManager.getString("message.minimize.url");
  private static final String A = TUIManager.getString("message.info.url");
  private static final int F = 9;
  private static final int E = 9;
  
  public static boolean A(String paramString)
  {
    return (paramString == null) || ("".equals(paramString));
  }
  
  public static SVGAttachment A(Class paramClass, String paramString, ElementSVGUI paramElementSVGUI)
  {
    boolean bool = SVGAttachment.class.isAssignableFrom(paramClass);
    if (bool) {
      try
      {
        Constructor localConstructor = paramClass.getConstructor(H);
        Object[] arrayOfObject = { paramString, paramElementSVGUI };
        SVGAttachment localSVGAttachment = (SVGAttachment)localConstructor.newInstance(arrayOfObject);
        return localSVGAttachment;
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError(null, localException);
      }
    }
    return null;
  }
  
  public static void B(SVGContext paramSVGContext, StringBuffer paramStringBuffer)
  {
    if (paramSVGContext.isSvgHeader()) {
      paramStringBuffer.append("<?xml version='1.0' encoding='UTF-8'?>");
    }
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer)
  {
    double d1 = paramSVGContext.getStartX();
    if (d1 != 0.0D) {
      paramStringBuffer.append(" x='" + d1 + "'");
    }
    double d2 = paramSVGContext.getStartY();
    if (d2 != 0.0D) {
      paramStringBuffer.append(" y='" + d2 + "'");
    }
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Color paramColor, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, float paramFloat)
  {
    Color localColor1 = paramColor.brighter();
    Color localColor2 = paramColor.darker();
    Color localColor3 = paramBoolean ? localColor1 : localColor2;
    A(paramSVGContext, paramStringBuffer, new Rectangle(paramInt1, paramInt2, 1, paramInt4 + 1), localColor3, null, null, paramFloat);
    A(paramSVGContext, paramStringBuffer, new Rectangle(paramInt1 + 1, paramInt2, paramInt3 - 1, 1), localColor3, null, null, paramFloat);
    localColor3 = paramBoolean ? localColor2 : localColor1;
    A(paramSVGContext, paramStringBuffer, new Rectangle(paramInt1 + 1, paramInt2 + paramInt4, paramInt3, 1), localColor3, null, null, paramFloat);
    A(paramSVGContext, paramStringBuffer, new Rectangle(paramInt1 + paramInt3 - 1, paramInt2, 1, paramInt4), localColor3, null, null, paramFloat);
    return paramStringBuffer;
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, String paramString1, String paramString2)
  {
    if ((paramString1 != null) && (paramString2 != null)) {
      return paramStringBuffer.append(" ").append(paramString1).append("='").append(paramString2).append("'");
    }
    return paramStringBuffer;
  }
  
  public static void A(StringBuffer paramStringBuffer, Object paramObject)
  {
    A(paramStringBuffer, "elementid", (String)paramObject);
  }
  
  public static void A(StringBuffer paramStringBuffer, String paramString1, String paramString2, String paramString3, int paramInt, String paramString4, String paramString5, String paramString6)
  {
    if (paramInt > 0)
    {
      paramStringBuffer.append("<animate");
      A(paramStringBuffer, "attributeName", paramString1);
      A(paramStringBuffer, "repeatCount", paramString3);
      A(paramStringBuffer, "dur", paramInt + "ms");
      A(paramStringBuffer, "by", paramString6);
      A(paramStringBuffer, "from", paramString4);
      A(paramStringBuffer, "to", paramString5);
      paramStringBuffer.append("/>\n");
    }
  }
  
  public static void A(StringBuffer paramStringBuffer, String paramString1, String paramString2, String paramString3, int paramInt, String paramString4)
  {
    if (paramInt > 0)
    {
      paramStringBuffer.append("<animate");
      A(paramStringBuffer, "attributeName", paramString1);
      A(paramStringBuffer, "repeatCount", paramString2);
      A(paramStringBuffer, "to", paramString3);
      A(paramStringBuffer, "dur", paramInt + "ms");
      A(paramStringBuffer, "fill", paramString4);
      paramStringBuffer.append("/>\n");
    }
  }
  
  public static String A(SVGContext paramSVGContext, Shape paramShape)
  {
    String str = WebUtil.getNextCustomDefinitionID();
    StringBuffer localStringBuffer = new StringBuffer("<path id='").append(str).append("' d='");
    A(localStringBuffer, paramShape);
    localStringBuffer.append("'/>\n");
    paramSVGContext.registerCustomDefinition(localStringBuffer.toString());
    return str;
  }
  
  public static StringBuffer B(StringBuffer paramStringBuffer, Object paramObject)
  {
    if (paramObject == null) {
      return paramStringBuffer.append("none");
    }
    if ((paramObject instanceof String))
    {
      localObject = (String)paramObject;
      if ("none".equalsIgnoreCase((String)localObject)) {
        return paramStringBuffer.append("none");
      }
      return paramStringBuffer.append("url(#").append((String)paramObject).append(")");
    }
    Object localObject = (Color)paramObject;
    return paramStringBuffer.append("rgb(").append(((Color)localObject).getRed()).append(",").append(((Color)localObject).getGreen()).append(",").append(((Color)localObject).getBlue()).append(")");
  }
  
  public static String A(SVGContext paramSVGContext, String paramString1, boolean paramBoolean1, Color paramColor, Object paramObject, Point paramPoint1, boolean paramBoolean2, String paramString2, Point paramPoint2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<text");
    if (!paramBoolean1) {
      C(localStringBuffer);
    }
    B(paramSVGContext, localStringBuffer, paramColor);
    if (paramBoolean2) {
      localStringBuffer.append(" text-decoration='underline'");
    }
    localStringBuffer.append(" x='").append(paramPoint1.x).append("' y='").append(paramPoint1.y).append("'");
    if (paramString2 != null)
    {
      if (paramPoint2 == null) {
        paramPoint2 = paramPoint1;
      }
      localStringBuffer.append(" transform='rotate(").append(paramString2).append(",").append(paramPoint2.x).append(",").append(paramPoint2.y).append(")'");
    }
    A(paramSVGContext, localStringBuffer, paramObject);
    localStringBuffer.append(">");
    localStringBuffer.append(paramString1);
    localStringBuffer.append("</text>");
    return localStringBuffer.toString();
  }
  
  public static String A(SVGContext paramSVGContext, String paramString1, boolean paramBoolean1, Color paramColor, Object paramObject, Point paramPoint, boolean paramBoolean2, String paramString2)
  {
    return A(paramSVGContext, paramString1, paramBoolean1, paramColor, paramObject, paramPoint, paramBoolean2, paramString2, null);
  }
  
  public static String A(SVGContext paramSVGContext, String paramString1, Color paramColor, Font paramFont, Point paramPoint, boolean paramBoolean, String paramString2)
  {
    return A(paramSVGContext, paramString1, true, paramColor, paramFont, paramPoint, paramBoolean, paramString2);
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString, Color paramColor, Font paramFont, int paramInt1, int paramInt2, int paramInt3)
  {
    A(paramSVGContext, paramStringBuffer, paramString, paramColor, paramFont, paramInt1, paramInt2, 1, paramInt3);
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString, Color paramColor, Font paramFont, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (paramString == null) {
      return;
    }
    FontRenderContext localFontRenderContext = new FontRenderContext(null, true, true);
    GlyphVector localGlyphVector = paramFont.createGlyphVector(localFontRenderContext, paramString);
    Rectangle localRectangle = localGlyphVector.getLogicalBounds().getBounds();
    if (paramInt3 == 2) {
      paramInt3 = 3;
    }
    Dimension localDimension;
    if ((paramInt3 == 3) || (paramInt3 == 4)) {
      localDimension = new Dimension((int)localRectangle.getHeight(), (int)localRectangle.getWidth());
    } else {
      localDimension = localRectangle.getSize();
    }
    String str = null;
    if (paramInt3 == 3)
    {
      str = "270";
      if (paramInt4 == 3)
      {
        paramInt1 += localDimension.width / 3;
        paramInt2 += localDimension.height;
      }
    }
    else if (paramInt3 == 4)
    {
      str = "90";
      if (paramInt4 == 3) {
        paramInt2 += 5;
      }
    }
    else if (paramInt4 == 1)
    {
      paramInt1 -= localDimension.width / 2;
      paramInt2 += localDimension.height / 2;
    }
    else if (paramInt4 == 3)
    {
      paramInt1 -= localDimension.width / 2;
      paramInt2 += localDimension.height * 2 / 3;
    }
    else if (paramInt4 == 5)
    {
      paramInt2 += localDimension.height / 3;
    }
    else if (paramInt4 != 7)
    {
      if (paramInt4 == 4)
      {
        paramInt1 -= localDimension.width;
        paramInt2 += localDimension.height / 3;
      }
      else if (paramInt4 == 2)
      {
        paramInt1 -= localDimension.width / 2;
      }
      else if (paramInt4 == 9)
      {
        paramInt2 += localDimension.height * 2 / 3;
      }
      else if (paramInt4 == 8)
      {
        paramInt1 -= localDimension.width;
        paramInt2 += localDimension.height * 2 / 3;
      }
      else if (paramInt4 == 6)
      {
        paramInt1 -= localDimension.width;
      }
    }
    Point localPoint = new Point(paramInt1, paramInt2);
    if (paramSVGContext.isUseCDATA()) {
      paramString = TWaverUtil.wrapCDATA(paramString);
    }
    paramStringBuffer.append(A(paramSVGContext, paramString, paramColor, paramFont, localPoint, false, str));
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject)
  {
    if ((paramObject instanceof String))
    {
      paramSVGContext.appendValue(paramStringBuffer, "font-family", (String)paramObject);
    }
    else
    {
      Font localFont = (Font)paramObject;
      int i = paramSVGContext.getDefaultFontSize();
      String str1 = paramSVGContext.getDefaultFontWeight();
      String str2 = localFont.getFamily(TWaverConst.EN_US);
      if ((!"dialog".equalsIgnoreCase(str2)) && (!"default".equalsIgnoreCase(str2)) && (!"dialoginput".equalsIgnoreCase(str2))) {
        paramSVGContext.appendValue(paramStringBuffer, "font-family", str2);
      }
      if (i != localFont.getSize()) {
        paramSVGContext.appendValue(paramStringBuffer, "font-size", localFont.getSize());
      }
      if (localFont.isBold()) {
        paramSVGContext.appendValue(paramStringBuffer, "stroke-width", 2);
      } else if ((localFont.isPlain()) && (!"normal".equals(str1))) {
        paramSVGContext.appendValue(paramStringBuffer, "font-weight", "normal");
      }
      if (localFont.isItalic()) {
        paramSVGContext.appendValue(paramStringBuffer, "font-style", "italic");
      }
    }
    return paramStringBuffer;
  }
  
  public static StringBuffer B(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject)
  {
    if ((paramObject == null) && ("none".equals(paramSVGContext.getDefaultValue("fill")))) {
      return paramStringBuffer;
    }
    paramStringBuffer.append(" fill='");
    B(paramStringBuffer, paramObject);
    paramStringBuffer.append("'");
    return paramStringBuffer;
  }
  
  public static StringBuffer C(StringBuffer paramStringBuffer, Object paramObject)
  {
    if (paramObject == null) {
      return paramStringBuffer;
    }
    paramStringBuffer.append(" stroke='");
    B(paramStringBuffer, paramObject);
    paramStringBuffer.append("'");
    return paramStringBuffer;
  }
  
  public static StringBuffer C(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject)
  {
    if ((paramObject instanceof Stroke)) {
      return G.A(paramSVGContext, paramStringBuffer, (Stroke)paramObject);
    }
    if ((paramObject instanceof String))
    {
      if ("0".equals(paramObject)) {
        paramObject = "1";
      }
      paramSVGContext.appendValue(paramStringBuffer, "stroke-width", (String)paramObject);
    }
    return paramStringBuffer;
  }
  
  public static StringBuffer B(StringBuffer paramStringBuffer, float paramFloat)
  {
    if ((paramFloat >= 0.0F) && (paramFloat < 1.0F)) {
      return paramStringBuffer.append(" fill-opacity='").append(paramFloat).append("'");
    }
    return paramStringBuffer;
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, float paramFloat)
  {
    if ((paramFloat >= 0.0F) && (paramFloat < 1.0F)) {
      return paramStringBuffer.append(" opacity='").append(paramFloat).append("'");
    }
    return paramStringBuffer;
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    return paramStringBuffer.append(" transform='translate(").append(paramInt1).append(",").append(paramInt2).append(")'");
  }
  
  public static StringBuffer B(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    B(paramSVGContext, paramStringBuffer, paramObject1);
    if (paramObject2 != null) {
      C(paramStringBuffer, paramObject2);
    }
    C(paramSVGContext, paramStringBuffer, paramObject3);
    B(paramStringBuffer, paramFloat);
    return paramStringBuffer;
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    B(paramSVGContext, paramStringBuffer, paramObject1);
    if (paramObject2 != null) {
      C(paramStringBuffer, paramObject2);
    }
    C(paramSVGContext, paramStringBuffer, paramObject3);
    B(paramStringBuffer, paramFloat);
    return paramStringBuffer;
  }
  
  public static StringBuffer C(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    if (paramObject1 == null)
    {
      paramObject1 = Color.white;
      paramFloat = 0.0F;
    }
    A(paramSVGContext, paramStringBuffer, paramObject1, paramObject2, paramObject3, paramFloat);
    return paramStringBuffer;
  }
  
  public static StringBuffer B(StringBuffer paramStringBuffer)
  {
    return paramStringBuffer.append(" visibility='hidden'");
  }
  
  public static StringBuffer C(StringBuffer paramStringBuffer)
  {
    return paramStringBuffer.append(" pointer-events='none'");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Rectangle paramRectangle, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    return paramStringBuffer.append(A(paramSVGContext, null, paramRectangle, paramObject1, paramObject2, paramObject3, paramFloat)).append("/>\n");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, String paramString, Rectangle paramRectangle, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramRectangle == null)
    {
      if (paramString != null) {
        localStringBuffer.append("<rect id='" + paramString + "' x='0' y='0' width='100%' height='100%'");
      } else {
        localStringBuffer.append("<rect x='0' y='0' width='100%' height='100%'");
      }
    }
    else
    {
      localStringBuffer.append("<rect");
      if (paramString != null) {
        localStringBuffer.append(" id='" + paramString + "'");
      }
      localStringBuffer.append(" x='").append(paramRectangle.x).append("' y='").append(paramRectangle.y).append("' width='").append(paramRectangle.width).append("' height='").append(paramRectangle.height).append("'");
    }
    A(paramSVGContext, localStringBuffer, paramObject1, paramObject2, paramObject3, paramFloat);
    return localStringBuffer;
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, double paramDouble1, double paramDouble2)
  {
    String str1 = paramSVGContext.format(paramDouble1);
    String str2 = paramSVGContext.format(paramDouble2);
    return paramStringBuffer.append(" transform='scale(").append(str1).append(",").append(str2).append(")'");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString, Color paramColor, Rectangle paramRectangle, float paramFloat)
  {
    String str = paramSVGContext.getImageID(paramString, paramColor);
    ImageIcon localImageIcon = TWaverUtil.getImageIcon(paramString);
    int i = localImageIcon.getIconWidth();
    int j = localImageIcon.getIconHeight();
    if ((paramRectangle.width == 0) || (paramRectangle.height == 0))
    {
      A(paramStringBuffer, str.toString(), paramRectangle.x, paramRectangle.y);
    }
    else if ((i != paramRectangle.width) || (j != paramRectangle.height))
    {
      double d1 = paramRectangle.getWidth() / i;
      double d2 = paramRectangle.getHeight() / j;
      A(paramStringBuffer, str.toString(), (int)(paramRectangle.x / d1), (int)(paramRectangle.y / d2));
      A(paramSVGContext, paramStringBuffer, d1, d2);
    }
    else
    {
      A(paramStringBuffer, str.toString(), paramRectangle.x, paramRectangle.y);
    }
    A(paramStringBuffer, paramFloat);
    return paramStringBuffer.append("/>\n");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString1, String paramString2, Color paramColor, int paramInt1, int paramInt2, float paramFloat)
  {
    String str = paramSVGContext.getImageID(paramString2, paramColor);
    A(paramStringBuffer, str.toString(), paramInt1, paramInt2);
    A(paramStringBuffer, paramFloat);
    if (paramString1 != null) {
      paramStringBuffer.append(paramString1);
    }
    return paramStringBuffer.append("/>\n");
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, boolean paramBoolean, Element paramElement, String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    String str = paramSVGContext.getImageID(paramString1, null);
    A(paramStringBuffer, str.toString(), paramInt1, paramInt2);
    paramStringBuffer.append(" attachment_name = '" + paramString2 + "' ");
    if (paramBoolean) {
      A(paramStringBuffer);
    }
    paramStringBuffer.append(">");
    if (paramBoolean)
    {
      int i = a.J(paramElement, "blink.iconattachment.speed");
      A(paramStringBuffer, "visibility", "indefinite", "hidden", i, "remove");
    }
    paramStringBuffer.append("</use>");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString, Color paramColor, int paramInt1, int paramInt2, float paramFloat)
  {
    return A(paramSVGContext, paramStringBuffer, null, paramString, paramColor, paramInt1, paramInt2, paramFloat);
  }
  
  public static void A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, String paramString1, String paramString2, Color paramColor, int paramInt1, int paramInt2)
  {
    String str = paramSVGContext.getImageID(paramString2, paramColor);
    A(paramStringBuffer, str.toString(), paramInt1, paramInt2);
    if (paramString1 != null) {
      paramStringBuffer.append(paramString1);
    }
    paramStringBuffer.append("/>\n");
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, String paramString, int paramInt1, int paramInt2)
  {
    paramStringBuffer.append("<use xlink:href='#").append(paramString).append("'").append(" x='").append(paramInt1).append("'").append(" y='").append(paramInt2).append("'");
    return paramStringBuffer;
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, String paramString)
  {
    return paramStringBuffer.append("<use xlink:href='#").append(paramString).append("'");
  }
  
  public static StringBuffer B(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Shape paramShape, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    String str = A(paramSVGContext, paramShape);
    A(paramStringBuffer, str);
    return A(paramSVGContext, paramStringBuffer, paramObject1, paramObject2, paramObject3, paramFloat).append("/>\n");
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Shape paramShape, Object paramObject)
  {
    float f = 1.0F;
    if ((paramObject != null) && ((paramObject instanceof Color)))
    {
      Color localColor = (Color)paramObject;
      if (localColor.getAlpha() != 255) {
        f = localColor.getAlpha() * 1.0F / 255.0F;
      }
    }
    return A(paramSVGContext, paramStringBuffer, paramShape, paramObject, null, null, f);
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Shape paramShape, Object paramObject1, Object paramObject2)
  {
    return A(paramSVGContext, paramStringBuffer, paramShape, null, paramObject1, paramObject2, 0.0F);
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Shape paramShape, Object paramObject1, Object paramObject2, Object paramObject3, float paramFloat)
  {
    paramStringBuffer.append("<path ").append(" d='");
    A(paramStringBuffer, paramShape);
    paramStringBuffer.append("' ");
    B(paramSVGContext, paramStringBuffer, paramObject1, paramObject2, paramObject3, paramFloat);
    paramStringBuffer.append("/>\n");
    return paramStringBuffer;
  }
  
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Object paramObject, Color paramColor)
  {
    paramStringBuffer.append("<line ").append(" x1='").append(paramInt1).append("' y1='").append(paramInt2).append("' x2='").append(paramInt3).append("' y2='").append(paramInt4).append("' ");
    C(paramSVGContext, paramStringBuffer, paramObject);
    paramStringBuffer.append(" style='stroke:");
    B(paramStringBuffer, paramColor).append("' ");
    paramStringBuffer.append("/>\n");
    return paramStringBuffer;
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, String paramString, Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      paramStringBuffer.append("<pattern id='").append(paramString).append("' x='0' y='0' width='100%' height='100%'");
    } else {
      paramStringBuffer.append("<pattern id='").append(paramString).append("' x='").append(paramRectangle.x).append("' y='").append(paramRectangle.y).append("' width='").append(paramRectangle.width).append("' height='").append(paramRectangle.height).append("' patternUnits='userSpaceOnUse'");
    }
    return paramStringBuffer;
  }
  
  private static void A(StringBuffer paramStringBuffer, float paramFloat1, float paramFloat2)
  {
    paramStringBuffer.append(G.format(paramFloat1));
    paramStringBuffer.append(" ");
    paramStringBuffer.append(G.format(paramFloat2));
    paramStringBuffer.append(" ");
  }
  
  public static StringBuffer A(StringBuffer paramStringBuffer, Shape paramShape)
  {
    PathIterator localPathIterator = paramShape.getPathIterator(null);
    float[] arrayOfFloat1 = new float[6];
    int i = 0;
    float[] arrayOfFloat2 = (float[])null;
    while (!localPathIterator.isDone())
    {
      i = localPathIterator.currentSegment(arrayOfFloat1);
      switch (i)
      {
      case 0: 
        paramStringBuffer.append("M");
        A(paramStringBuffer, arrayOfFloat1[0], arrayOfFloat1[1]);
        break;
      case 1: 
        if ((arrayOfFloat2 == null) || (Math.abs(arrayOfFloat2[0] - arrayOfFloat1[0]) >= C) || (Math.abs(arrayOfFloat2[1] - arrayOfFloat1[1]) >= C))
        {
          paramStringBuffer.append("L");
          A(paramStringBuffer, arrayOfFloat1[0], arrayOfFloat1[1]);
        }
        arrayOfFloat2 = new float[] { arrayOfFloat1[0], arrayOfFloat1[1] };
        break;
      case 4: 
        paramStringBuffer.append("Z");
        break;
      case 2: 
        paramStringBuffer.append("Q");
        A(paramStringBuffer, arrayOfFloat1[0], arrayOfFloat1[1]);
        A(paramStringBuffer, arrayOfFloat1[2], arrayOfFloat1[3]);
        break;
      case 3: 
        paramStringBuffer.append("C");
        A(paramStringBuffer, arrayOfFloat1[0], arrayOfFloat1[1]);
        A(paramStringBuffer, arrayOfFloat1[2], arrayOfFloat1[3]);
        A(paramStringBuffer, arrayOfFloat1[4], arrayOfFloat1[5]);
      }
      localPathIterator.next();
    }
    return paramStringBuffer;
  }
  
  public static SVGStruct B(TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, AbstractElement paramAbstractElement)
  {
    if (!paramAbstractElement.isLabelVisible()) {
      return SVGStruct.EMPTY;
    }
    String str1 = l.A(paramTSVGNetwork, paramAbstractElement);
    if (A(str1)) {
      return SVGStruct.EMPTY;
    }
    Color localColor = paramAbstractElement.getLabelColor();
    int i = paramAbstractElement.getLabelPosition();
    int j = paramAbstractElement.getLabelYOffset();
    int k = paramAbstractElement.getLabelXOffset();
    boolean bool = paramAbstractElement.isLabelUnderline();
    Font localFont = paramAbstractElement.getLabelFont();
    int m = paramAbstractElement.getLabelOrientation();
    String[][] arrayOfString = A(str1.split("\\|\\|"));
    String str2 = A(arrayOfString);
    FontRenderContext localFontRenderContext = new FontRenderContext(null, true, true);
    GlyphVector localGlyphVector = localFont.createGlyphVector(localFontRenderContext, str2);
    Rectangle localRectangle1 = localGlyphVector.getLogicalBounds().getBounds();
    LineMetrics localLineMetrics = localFont.getLineMetrics(str2, localFontRenderContext);
    int n = (int)localLineMetrics.getDescent();
    if (m == 2) {
      m = 3;
    }
    Dimension localDimension;
    if ((m == 3) || (m == 4)) {
      localDimension = new Dimension((int)localRectangle1.getHeight(), (int)localRectangle1.getWidth());
    } else {
      localDimension = localRectangle1.getSize();
    }
    Point localPoint1 = A(paramTSVGNetwork, paramSVGContext, paramAbstractElement, localDimension, i, k, j);
    Point localPoint2 = null;
    Rectangle localRectangle2 = new Rectangle(localPoint1.x, localPoint1.y, localDimension.width, localDimension.height);
    String str3;
    if (m == 3)
    {
      str3 = "270";
      localPoint1.x = (localPoint1.x + localRectangle1.height - n - 2);
      localPoint1.y = (localPoint1.y + localRectangle1.width - 2);
    }
    else if (m == 4)
    {
      str3 = "90";
      localPoint1.x = (localPoint1.x + n + 2);
      localPoint1.y += 2;
    }
    else
    {
      str3 = null;
      localPoint1.x += 2;
      localPoint1.y = (localPoint1.y + localRectangle1.height - n - 2);
      if ((paramAbstractElement instanceof Link))
      {
        localObject = (Link)paramAbstractElement;
        if (((Link)localObject).isLinkLabelRotatable())
        {
          localPoint2 = new Point(localPoint1.x + localRectangle1.width / 2, localPoint1.y);
          LinkSVGUI localLinkSVGUI = (LinkSVGUI)paramTSVGNetwork.getElementSVGUI(paramAbstractElement);
          double d = localLinkSVGUI.getAngle(paramSVGContext);
          str3 = Math.toDegrees(d);
        }
      }
    }
    Object localObject = new StringBuffer();
    for (int i1 = 0; i1 < arrayOfString.length; i1++)
    {
      String str4 = arrayOfString[i1][0];
      if (arrayOfString[i1][1] != null)
      {
        ((StringBuffer)localObject).append(arrayOfString[i1][1]);
        if (paramSVGContext.isUseCDATA()) {
          str4 = TWaverUtil.wrapCDATA(str4);
        }
        ((StringBuffer)localObject).append(A(paramSVGContext, str4, paramSVGContext.isEnableElementLabelInteract(), localColor, localFont, localPoint1, bool, str3, localPoint2));
        ((StringBuffer)localObject).append("</a>");
      }
      else
      {
        if (paramSVGContext.isUseCDATA()) {
          str4 = TWaverUtil.wrapCDATA(str4);
        }
        ((StringBuffer)localObject).append(A(paramSVGContext, str4, paramSVGContext.isEnableElementLabelInteract(), localColor, localFont, localPoint1, bool, str3, localPoint2));
      }
      if (m == 1) {
        localPoint1.setLocation(localPoint1.x, localPoint1.y + localDimension.height);
      } else {
        localPoint1.setLocation(localPoint1.x + localDimension.width, localPoint1.y);
      }
    }
    if (paramAbstractElement.isLabelBorder())
    {
      localColor = paramAbstractElement.getLabelBorderColor();
      Stroke localStroke = a.F(paramAbstractElement, "label.border.stroke");
      A(paramSVGContext, (StringBuffer)localObject, localRectangle2, null, localColor, localStroke, 1.0F);
    }
    return new SVGStruct(((StringBuffer)localObject).toString(), localRectangle2);
  }
  
  public static String B(String paramString)
  {
    String[][] arrayOfString = A(paramString.split("\\|\\|"));
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfString.length; i++)
    {
      localStringBuffer.append(arrayOfString[i][0]);
      localStringBuffer.append("||");
    }
    String str = localStringBuffer.toString();
    if (str.endsWith("||")) {
      str = str.substring(0, str.length() - 2);
    }
    return str;
  }
  
  private static String[][] A(String[] paramArrayOfString)
  {
    String[][] arrayOfString = new String[paramArrayOfString.length][2];
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      String str1 = paramArrayOfString[i];
      if (str1.startsWith("<a"))
      {
        int j = str1.indexOf(">");
        String str2 = str1.substring(0, j + 1);
        int k = str1.indexOf("</a>");
        arrayOfString[i][0] = str1.substring(j + 1, k);
        arrayOfString[i][1] = str2;
      }
      else
      {
        arrayOfString[i][0] = str1;
      }
    }
    return arrayOfString;
  }
  
  private static String A(String[][] paramArrayOfString)
  {
    String str = "";
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i][0].length() > str.length()) {
        str = paramArrayOfString[i][0];
      }
    }
    return str;
  }
  
  public static SVGStruct A(TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, ElementSVGUI paramElementSVGUI)
  {
    Element localElement = paramElementSVGUI.getElement();
    StringBuffer localStringBuffer = new StringBuffer();
    Rectangle localRectangle = null;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localElement.getClientProperties().keySet().iterator();
    Point localPoint;
    int i3;
    while (localIterator.hasNext())
    {
      String str1 = localIterator.next().toString();
      Object localObject1 = localElement.getClientProperty(str1);
      if ((Boolean.TRUE.equals(localObject1)) && (str1.startsWith("StateIcon:")))
      {
        String str2 = str1.substring("StateIcon:".length());
        localObject1 = IconAttachmentHolder.getAttachmentInfo(str2);
        Object localObject2;
        Object localObject3;
        if ((localObject1 instanceof String))
        {
          localObject2 = (String)localObject1;
          localObject3 = IconAttachmentHolder.getAttachmentPosition(str2);
          if ((localObject3 != null) && (((PositionStruct)localObject3).position > 0))
          {
            ImageIcon localImageIcon1 = TWaverUtil.getImageIcon((String)localObject2);
            Dimension localDimension1 = new Dimension(localImageIcon1.getIconWidth(), localImageIcon1.getIconHeight());
            localPoint = A(paramTSVGNetwork, paramSVGContext, localElement, localDimension1, ((PositionStruct)localObject3).position, ((PositionStruct)localObject3).xOffset, ((PositionStruct)localObject3).yOffset);
            i3 = paramTSVGNetwork.getBlinkingRule().isIconAttachmentBlinkable(localElement, str2);
            A(paramSVGContext, localStringBuffer, i3, localElement, (String)localObject2, str2, localPoint.x, localPoint.y);
            if (localRectangle == null) {
              localRectangle = new Rectangle(localPoint, localDimension1);
            } else {
              localRectangle.add(new Rectangle(localPoint, localDimension1));
            }
          }
          else
          {
            localArrayList.add(new String[] { localObject2, str2 });
          }
        }
        else if ((localObject1 instanceof Class))
        {
          localObject2 = A((Class)localObject1, str2, paramElementSVGUI);
          if (localObject2 != null)
          {
            localObject3 = ((SVGAttachment)localObject2).toSVG(paramSVGContext);
            localRectangle = ((SVGStruct)localObject3).getBounds();
            localStringBuffer.append(((SVGStruct)localObject3).getSvg());
          }
        }
      }
    }
    int i = localArrayList.size();
    if (i > 0)
    {
      int j = localElement.getAttachmentPosition();
      int k = localElement.getAttachmentOrientation();
      int m = localElement.getAttachmentXOffset();
      int n = localElement.getAttachmentYOffset();
      int i1 = localElement.getAttachmentXGap();
      int i2 = localElement.getAttachmentYGap();
      localPoint = null;
      for (i3 = 0; i3 < i; i3++)
      {
        String[] arrayOfString = (String[])localArrayList.get(i3);
        String str3 = arrayOfString[0];
        ImageIcon localImageIcon2 = TWaverUtil.getImageIcon(str3);
        int i4 = localImageIcon2.getIconWidth();
        int i5 = localImageIcon2.getIconHeight();
        int i6 = i3 == 0 ? 1 : 0;
        Dimension localDimension2 = new Dimension(localImageIcon2.getIconWidth(), localImageIcon2.getIconHeight());
        if (i6 != 0) {
          localPoint = A(paramTSVGNetwork, paramSVGContext, localElement, localDimension2, j, m, n);
        }
        if (k == 1)
        {
          if (i6 == 0) {
            localPoint.y -= i5 + i2;
          }
        }
        else if (k == 2)
        {
          if (i6 == 0) {
            localPoint.y -= i5 + i2;
          }
        }
        else if (k == 6)
        {
          if (i6 == 0) {
            localPoint.x -= i4 + i1;
          }
        }
        else if (k == 7)
        {
          if (i6 == 0) {
            localPoint.x -= i4 + i1;
          }
        }
        else if (k == 8)
        {
          if (i6 == 0) {
            localPoint.x -= i4 + i1;
          }
          if (i6 == 0) {
            localPoint.y -= i5 + i2;
          }
        }
        String str4 = arrayOfString[1];
        boolean bool = paramTSVGNetwork.getBlinkingRule().isIconAttachmentBlinkable(localElement, str4);
        A(paramSVGContext, localStringBuffer, bool, localElement, str3, str4, localPoint.x, localPoint.y);
        if (localRectangle == null) {
          localRectangle = new Rectangle(localPoint, localDimension2);
        } else {
          localRectangle.add(new Rectangle(localPoint, localDimension2));
        }
        if (k == 2)
        {
          localPoint.x += i4 + i1;
        }
        else if (k == 3)
        {
          localPoint.x += i4 + i1;
        }
        else if (k == 4)
        {
          localPoint.y += i5 + i2;
          localPoint.x += i4 + i1;
        }
        else if (k == 5)
        {
          localPoint.y += i5 + i2;
        }
        else if (k == 6)
        {
          localPoint.y += i5 + i2;
        }
      }
    }
    if (localRectangle == null) {
      return SVGStruct.EMPTY;
    }
    return new SVGStruct(localStringBuffer.toString(), localRectangle);
  }
  
  public static SVGStruct A(TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, AbstractElement paramAbstractElement, boolean paramBoolean)
  {
    if (!paramAbstractElement.isAlarmBalloonVisible()) {
      return SVGStruct.EMPTY;
    }
    AlarmSeverity localAlarmSeverity = paramAbstractElement.getAlarmState().getHighestNewAlarmSeverity();
    if (localAlarmSeverity == null) {
      return SVGStruct.EMPTY;
    }
    String str1 = (String)paramTSVGNetwork.getAlarmLabelGenerator().generate(paramAbstractElement);
    if (A(str1)) {
      return SVGStruct.EMPTY;
    }
    int i = paramAbstractElement.getAlarmBalloonPosition();
    int j = paramAbstractElement.getAlarmBalloonXOffset();
    int k = paramAbstractElement.getAlarmBalloonYOffset();
    int m = paramAbstractElement.getAlarmBalloonDirection();
    int n = paramAbstractElement.getAlarmBalloonShadowOffset();
    float f = paramAbstractElement.getAlarmBalloonAlpha();
    Font localFont = paramAbstractElement.getAlarmBalloonTextFont();
    Color localColor1 = paramAbstractElement.getAlarmBalloonTextColor();
    Color localColor2 = paramAbstractElement.getAlarmBalloonOutlineColor();
    Color localColor3 = paramAbstractElement.getAlarmBalloonShadowColor();
    FontRenderContext localFontRenderContext = new FontRenderContext(null, true, true);
    GlyphVector localGlyphVector = localFont.createGlyphVector(localFontRenderContext, str1);
    Rectangle localRectangle = localGlyphVector.getLogicalBounds().getBounds();
    LineMetrics localLineMetrics = localFont.getLineMetrics(str1, localFontRenderContext);
    int i1 = (int)localLineMetrics.getDescent();
    Point localPoint1 = A(paramTSVGNetwork, paramSVGContext, paramAbstractElement, TWaverConst.EMPTY_DIMENSION, i, j, k);
    H localH = new H(localPoint1, localRectangle.width, localRectangle.height, m, 7, 8, true);
    Point localPoint2 = localH.A.getLocation();
    localPoint2.y = (localPoint2.y + localRectangle.height - i1 - 2);
    localPoint2.x += 2;
    String str2 = A(paramSVGContext, localH.B);
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<g").append(" ");
    A(localStringBuffer, paramAbstractElement.getID());
    if (paramBoolean) {
      A(localStringBuffer);
    }
    localStringBuffer.append(">");
    if (paramBoolean)
    {
      int i2 = a.J(paramAbstractElement, "blink.alarmattachment.speed");
      A(localStringBuffer, "visibility", "indefinite", "hidden", i2, "remove");
    }
    if (f == 1.0F)
    {
      A(localStringBuffer, str2);
      A(paramSVGContext, localStringBuffer, localColor3, null, "1", -1.0F);
      A(localStringBuffer, n, n).append("/>\n");
    }
    Color localColor4 = (Color)paramTSVGNetwork.getAlarmColorGenerator().generate(paramAbstractElement);
    if (localColor4 != null)
    {
      A(localStringBuffer, str2);
      A(paramSVGContext, localStringBuffer, localColor4, localColor2, "1", f).append("/>\n");
    }
    localStringBuffer.append(A(paramSVGContext, str1, localColor1, localFont, localPoint2, false, null));
    localStringBuffer.append("</g>");
    return new SVGStruct(localStringBuffer.toString(), localH.B.getBounds());
  }
  
  public static void A(StringBuffer paramStringBuffer, TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, AbstractElement paramAbstractElement)
  {
    int i = paramAbstractElement.getMessagePosition();
    int j = paramAbstractElement.getMessageXOffset();
    int k = paramAbstractElement.getMessageYOffset();
    Point localPoint = A(paramTSVGNetwork, paramSVGContext, paramAbstractElement, new Dimension(9, 9), i, j, k);
    A(paramSVGContext, paramStringBuffer, " attIcon='maxMessage'", A, null, localPoint.x, localPoint.y);
  }
  
  public static SVGStruct A(TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, AbstractElement paramAbstractElement)
  {
    boolean bool1 = a.K(paramAbstractElement, "StateIcon:attachment.message");
    if (!bool1) {
      return SVGStruct.EMPTY;
    }
    String str1 = paramTSVGNetwork.getMessageContent(paramAbstractElement);
    if (A(str1)) {
      return SVGStruct.EMPTY;
    }
    int i = paramAbstractElement.getMessagePosition();
    int j = paramAbstractElement.getMessageXOffset();
    int k = paramAbstractElement.getMessageYOffset();
    int m = paramAbstractElement.getMessageDirection();
    Font localFont = paramAbstractElement.getMessageFont();
    Color localColor1 = paramAbstractElement.getMessageForeground();
    Object localObject1 = paramAbstractElement.getMessageBackground();
    Color localColor2 = paramAbstractElement.getMessageBorderColor();
    boolean bool2 = paramAbstractElement.isMessageGradient();
    if (bool2)
    {
      localObject2 = paramAbstractElement.getMessageGradientColor();
      if (localObject2 != null)
      {
        int n = paramAbstractElement.getMessageGradientFactory();
        localObject1 = WebUtil.getGradientID(paramSVGContext, n, (Color)localObject2, paramAbstractElement.getMessageBackground());
      }
    }
    Object localObject2 = new FontRenderContext(null, true, true);
    String[] arrayOfString = str1.split("\\|\\|");
    int i1 = 0;
    int i2 = 0;
    for (int i3 = 0; i3 < arrayOfString.length; i3++)
    {
      localObject3 = arrayOfString[i3];
      if (i1 < ((String)localObject3).length())
      {
        i1 = ((String)localObject3).length();
        i2 = i3;
      }
    }
    GlyphVector localGlyphVector = localFont.createGlyphVector((FontRenderContext)localObject2, arrayOfString[i2]);
    Object localObject3 = localGlyphVector.getLogicalBounds();
    double d1 = ((Rectangle2D)localObject3).getHeight();
    double d2 = ((Rectangle2D)localObject3).getWidth();
    boolean bool3 = a.K(paramAbstractElement, "message.closable");
    boolean bool4 = a.K(paramAbstractElement, "message.minimizable");
    if ((bool3) || (bool4)) {
      d2 += 9.0D;
    }
    double d3 = arrayOfString.length * d1 + 2.0D;
    if ((bool3) && (bool4)) {
      d3 += 4.0D;
    }
    Point localPoint = A(paramTSVGNetwork, paramSVGContext, paramAbstractElement, TWaverConst.EMPTY_DIMENSION, i, j, k);
    Object localObject4 = null;
    int i4 = paramAbstractElement.getMessageStyle();
    if (i4 == 1)
    {
      localPoint.x -= (int)d2 / 2;
      localPoint.y -= (int)d3;
      localObject4 = new Rectangle(localPoint, new Dimension((int)d2 + 4, (int)d3));
    }
    else
    {
      localObject5 = new H(localPoint, (int)d2, (int)d3, m, 7, 8, true);
      localObject4 = ((H)localObject5).B;
    }
    Object localObject5 = ((Shape)localObject4).getBounds().getLocation();
    if (i4 == 1)
    {
      ((Point)localObject5).y = (((Point)localObject5).y + (int)d1 - 2);
      ((Point)localObject5).x += 2;
    }
    else
    {
      ((Point)localObject5).y = (((Point)localObject5).y + (int)d1 - 2);
      ((Point)localObject5).x += 8;
    }
    String str2 = A(paramSVGContext, (Shape)localObject4);
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<g message-elementid='");
    localStringBuffer.append(paramAbstractElement.getID());
    localStringBuffer.append("'>");
    if (paramAbstractElement.isMessageShadowVisible())
    {
      Color localColor3 = paramAbstractElement.getMessageShadowColor();
      A(localStringBuffer, str2);
      A(paramSVGContext, localStringBuffer, localColor3, null, "1", -1.0F);
      A(localStringBuffer, 3, 3).append("/>\n");
    }
    A(localStringBuffer, str2);
    A(paramSVGContext, localStringBuffer, localObject1, localColor2, "1", 1.0F).append("/>\n");
    for (int i5 = 0; i5 < arrayOfString.length; i5++)
    {
      String str3 = arrayOfString[i5];
      localStringBuffer.append(A(paramSVGContext, str3, localColor1, localFont, (Point)localObject5, false, null));
      ((Point)localObject5).y += (int)d1;
    }
    Rectangle localRectangle = A(paramSVGContext, localStringBuffer, ((Shape)localObject4).getBounds(), bool3, bool4);
    localStringBuffer.append("</g>");
    return new SVGStruct(localStringBuffer.toString(), localRectangle);
  }
  
  public static Rectangle A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Rectangle paramRectangle, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = paramRectangle.x + paramRectangle.width - 9 - 2;
    int j = paramRectangle.y + 2;
    if (paramBoolean1)
    {
      A(paramSVGContext, paramStringBuffer, " attIcon='close'", D, null, i, j);
      j += 10;
    }
    if (paramBoolean2)
    {
      A(paramSVGContext, paramStringBuffer, " attIcon='min'", B, null, i, j);
      j += 10;
    }
    return new Rectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width + 9, paramRectangle.height);
  }
  
  public static Point A(TSVGNetwork paramTSVGNetwork, SVGContext paramSVGContext, Element paramElement, Dimension paramDimension, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == 0)
    {
      localObject1 = paramTSVGNetwork.getElementSVGUI(paramElement).getHotspot(paramSVGContext);
      localObject1.x += paramInt2;
      localObject1.y += paramInt3;
      return localObject1;
    }
    Object localObject2;
    if ((paramElement instanceof Link))
    {
      localObject1 = (Link)paramElement;
      localObject2 = null;
      if (M.E(paramInt1)) {
        localObject2 = paramSVGContext.getFromPoint((Link)localObject1);
      } else if (M.D(paramInt1)) {
        localObject2 = paramSVGContext.getToPoint((Link)localObject1);
      } else {
        localObject2 = K.A(paramSVGContext.getLinkPath((Link)localObject1));
      }
      Rectangle localRectangle = new Rectangle(((Point)localObject2).x - 3, ((Point)localObject2).y - 3, 6, 6);
      return M.A(localRectangle, paramDimension, paramInt1, paramInt2, paramInt3);
    }
    Object localObject1 = null;
    if ((paramElement instanceof Group))
    {
      localObject2 = paramSVGContext.getGroupShape((Group)paramElement);
      if ((localObject2 instanceof twaver.base.A.D.E)) {
        localObject1 = M.A((twaver.base.A.D.E)localObject2, paramInt1);
      } else {
        localObject1 = ((Shape)localObject2).getBounds();
      }
    }
    if (localObject1 == null) {
      localObject1 = paramElement.getBounds();
    }
    return M.A((Rectangle)localObject1, paramDimension, paramInt1, paramInt2, paramInt3);
  }
  
  public static void C(SVGContext paramSVGContext, StringBuffer paramStringBuffer)
  {
    paramStringBuffer.append(" CSNID='" + paramSVGContext.getCurrentSubNetworkID() + "' ");
  }
  
  public static void B(StringBuffer paramStringBuffer, String paramString)
  {
    paramStringBuffer.append(" elementClass");
    paramStringBuffer.append("='");
    paramStringBuffer.append(paramString);
    paramStringBuffer.append("'");
  }
  
  public static void A(StringBuffer paramStringBuffer)
  {
    paramStringBuffer.append(" blinkflag='true' ");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.E
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.H;

import java.awt.Color;

public class F
{
  private int B;
  private Color A;
  private Color C;
  
  public F(int paramInt, Color paramColor1, Color paramColor2)
  {
    this.B = paramInt;
    this.A = paramColor1;
    this.C = paramColor2;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof F))
    {
      F localF = (F)paramObject;
      return (localF.B == this.B) && (localF.A.getRGB() == this.A.getRGB()) && (localF.C.getRGB() == this.C.getRGB());
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.B + this.A.getRGB() + this.C.getRGB();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.F
 * JD-Core Version:    0.7.0.1
 */
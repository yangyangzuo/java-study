package twaver.base.A.H;

import java.awt.Color;

public class B
{
  public static String A(String paramString, int paramInt, Color paramColor1, Color paramColor2)
  {
    if (paramInt == 1) {
      return A(paramString, paramColor1, paramColor2, 0, 100, 100, 0);
    }
    if (paramInt == 2) {
      return A(paramString, paramColor1, paramColor2, 100, 100, 0, 0);
    }
    if (paramInt == 3) {
      return A(paramString, paramColor1, paramColor2, 0, 0, 100, 100);
    }
    if (paramInt == 4) {
      return A(paramString, paramColor1, paramColor2, 100, 0, 0, 100);
    }
    if (paramInt == 5) {
      return A(paramString, paramColor1, paramColor2, 0, 0, 0, 100);
    }
    if (paramInt == 6) {
      return A(paramString, paramColor1, paramColor2, 0, 100, 0, 0);
    }
    if (paramInt == 7) {
      return A(paramString, paramColor1, paramColor2, 0, 0, 100, 0);
    }
    if (paramInt == 8) {
      return A(paramString, paramColor1, paramColor2, 100, 0, 0, 0);
    }
    if (paramInt == 10) {
      return A(paramString, paramColor1, paramColor2, 50, 50, 50);
    }
    if (paramInt == 11) {
      return A(paramString, paramColor1, paramColor2, 25, 75, 50);
    }
    if (paramInt == 12) {
      return A(paramString, paramColor1, paramColor2, 75, 75, 50);
    }
    if (paramInt == 13) {
      return A(paramString, paramColor1, paramColor2, 25, 25, 50);
    }
    if (paramInt == 14) {
      return A(paramString, paramColor1, paramColor2, 75, 25, 50);
    }
    if (paramInt == 15) {
      return A(paramString, paramColor1, paramColor2, 55, 25, 50);
    }
    if (paramInt == 16) {
      return A(paramString, paramColor1, paramColor2, 50, 75, 50);
    }
    if (paramInt == 17) {
      return A(paramString, paramColor1, paramColor2, 25, 50, 50);
    }
    if (paramInt == 18) {
      return A(paramString, paramColor1, paramColor2, 75, 50, 50);
    }
    if (paramInt == 19) {
      return B(paramString, paramColor1, paramColor2, 0, 0, 100, 0);
    }
    if (paramInt == 20) {
      return B(paramString, paramColor1, paramColor2, 0, 0, 0, 100);
    }
    if (paramInt == 21) {
      return B(paramString, paramColor1, paramColor2, 100, 0, 0, 100);
    }
    if (paramInt == 22) {
      return B(paramString, paramColor1, paramColor2, 0, 0, 100, 100);
    }
    if (paramInt == 23) {
      return C(paramString, paramColor1, paramColor2, 0, 25, 0, 75);
    }
    if (paramInt == 24) {
      return C(paramString, paramColor2, paramColor1, 0, 25, 0, 75);
    }
    if (paramInt == 25) {
      return C(paramString, paramColor1, paramColor2, 25, 0, 75, 0);
    }
    if (paramInt == 26) {
      return C(paramString, paramColor2, paramColor1, 25, 0, 75, 0);
    }
    return "";
  }
  
  private static String A(String paramString, Color paramColor1, Color paramColor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    StringBuffer localStringBuffer = new StringBuffer("<linearGradient id='").append(paramString).append("' x1='").append(paramInt1).append("%' y1='").append(paramInt2).append("%' x2='").append(paramInt3).append("%' y2='").append(paramInt4).append("%'>");
    localStringBuffer.append("<stop offset='0%' stop-color='");
    E.B(localStringBuffer, paramColor1).append("'/>\n");
    localStringBuffer.append("<stop offset='100%' stop-color='");
    E.B(localStringBuffer, paramColor2).append("'/>\n");
    localStringBuffer.append("</linearGradient>");
    return localStringBuffer.toString();
  }
  
  private static String A(String paramString, Color paramColor1, Color paramColor2, int paramInt1, int paramInt2, int paramInt3)
  {
    StringBuffer localStringBuffer = new StringBuffer("<radialGradient id='").append(paramString).append("' cx='").append(paramInt1).append("%' cy='").append(paramInt2).append("%' r='").append(paramInt3).append("%'>\n");
    localStringBuffer.append("<stop offset='0%' stop-color='");
    E.B(localStringBuffer, paramColor1).append("'/>\n");
    localStringBuffer.append("<stop offset='100%' stop-color='");
    E.B(localStringBuffer, paramColor2).append("'/>\n");
    localStringBuffer.append("</radialGradient>");
    return localStringBuffer.toString();
  }
  
  private static String B(String paramString, Color paramColor1, Color paramColor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    StringBuffer localStringBuffer = new StringBuffer("<linearGradient id='").append(paramString).append("' x1='").append(paramInt1).append("%' y1='").append(paramInt2).append("%' x2='").append(paramInt3).append("%' y2='").append(paramInt4).append("%'>\n");
    localStringBuffer.append("<stop offset='0%' stop-color='");
    E.B(localStringBuffer, paramColor2).append("'/>\n");
    localStringBuffer.append("<stop offset='50%' stop-color='");
    E.B(localStringBuffer, paramColor1).append("'/>\n");
    localStringBuffer.append("<stop offset='100%' stop-color='");
    E.B(localStringBuffer, paramColor2).append("'/>\n");
    localStringBuffer.append("</linearGradient>");
    return localStringBuffer.toString();
  }
  
  private static String C(String paramString, Color paramColor1, Color paramColor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    StringBuffer localStringBuffer = new StringBuffer("<linearGradient id='").append(paramString).append("' x1='").append(paramInt1).append("%' y1='").append(paramInt2).append("%' x2='").append(paramInt3).append("%' y2='").append(paramInt4).append("%' spreadMethod='reflect'>\n");
    localStringBuffer.append("<stop offset='0%' stop-color='");
    E.B(localStringBuffer, paramColor1).append("'/>\n");
    localStringBuffer.append("<stop offset='100%' stop-color='");
    E.B(localStringBuffer, paramColor2).append("'/>\n");
    localStringBuffer.append("</linearGradient>");
    return localStringBuffer.toString();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.B
 * JD-Core Version:    0.7.0.1
 */
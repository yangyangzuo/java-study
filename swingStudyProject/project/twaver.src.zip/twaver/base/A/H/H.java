package twaver.base.A.H;

import java.awt.Color;

public class H
{
  private String B;
  private Color A;
  
  public H(String paramString, Color paramColor)
  {
    this.B = paramString;
    this.A = paramColor;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof H))
    {
      H localH = (H)paramObject;
      return (localH.B.equals(this.B)) && (localH.A.getRGB() == this.A.getRGB());
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.B.hashCode() + this.A.getRGB();
  }
  
  public Color B()
  {
    return this.A;
  }
  
  public String A()
  {
    return this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.H
 * JD-Core Version:    0.7.0.1
 */
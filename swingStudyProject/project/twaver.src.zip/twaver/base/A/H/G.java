package twaver.base.A.H;

import java.awt.BasicStroke;
import java.awt.Stroke;
import twaver.web.svg.network.SVGContext;

public class G
{
  public static StringBuffer A(SVGContext paramSVGContext, StringBuffer paramStringBuffer, Stroke paramStroke)
  {
    if (!(paramStroke instanceof BasicStroke)) {
      return paramStringBuffer;
    }
    BasicStroke localBasicStroke = (BasicStroke)paramStroke;
    float f = localBasicStroke.getLineWidth();
    if (f == 0.0F) {
      f = 1.0F;
    }
    paramSVGContext.appendValue(paramStringBuffer, "stroke-width", f);
    paramSVGContext.appendValue(paramStringBuffer, "stroke-miterlimit", localBasicStroke.getMiterLimit());
    paramSVGContext.appendValue(paramStringBuffer, "stroke-linejoin", B(localBasicStroke.getLineJoin()));
    paramSVGContext.appendValue(paramStringBuffer, "stroke-linecap", A(localBasicStroke.getEndCap()));
    paramSVGContext.appendValue(paramStringBuffer, "stroke-dasharray", A(paramSVGContext, localBasicStroke.getDashArray()), false);
    paramSVGContext.appendValue(paramStringBuffer, "stroke-dashoffset", paramSVGContext.format(localBasicStroke.getDashPhase()));
    return paramStringBuffer;
  }
  
  private static String A(SVGContext paramSVGContext, float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null) {
      return null;
    }
    StringBuffer localStringBuffer = new StringBuffer(paramArrayOfFloat.length * 8);
    if (paramArrayOfFloat.length > 0) {
      localStringBuffer.append(paramSVGContext.format(paramArrayOfFloat[0]));
    } else {
      return null;
    }
    for (int i = 1; i < paramArrayOfFloat.length; i++)
    {
      localStringBuffer.append(' ');
      localStringBuffer.append(paramSVGContext.format(paramArrayOfFloat[i]));
    }
    return localStringBuffer.toString();
  }
  
  private static String B(int paramInt)
  {
    switch (paramInt)
    {
    case 2: 
      return "bevel";
    case 1: 
      return "round";
    }
    return "miter";
  }
  
  private static String A(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "butt";
    case 1: 
      return "round";
    }
    return "square";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.G
 * JD-Core Version:    0.7.0.1
 */
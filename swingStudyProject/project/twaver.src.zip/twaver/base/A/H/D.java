package twaver.base.A.H;

import java.awt.Color;

public class D
{
  public String B;
  public Color A;
  
  public D(String paramString, Color paramColor)
  {
    this.B = paramString;
    this.A = paramColor;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof D))
    {
      D localD = (D)paramObject;
      if (!this.B.equals(localD.B)) {
        return false;
      }
      if (this.A == localD.A) {
        return true;
      }
      if ((this.A == null) && (localD.A != null)) {
        return false;
      }
      if ((this.A != null) && (localD.A == null)) {
        return false;
      }
      return this.A.getRGB() == localD.A.getRGB();
    }
    return false;
  }
  
  public int hashCode()
  {
    int i = this.B.hashCode();
    if (this.A != null) {
      i += this.A.getRGB();
    }
    return i;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.D
 * JD-Core Version:    0.7.0.1
 */
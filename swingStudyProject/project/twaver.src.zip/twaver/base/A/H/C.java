package twaver.base.A.H;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class C
{
  public static final Map A = new HashMap();
  
  static
  {
    A.put("stipple.loose", "<g id='" + "stipple.loose" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "</g>");
    A.put("stipple.middle", "<g id='" + "stipple.middle" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='3' y='0' width='1' height='1'/>" + "<rect x='0' y='3' width='1' height='1'/>" + "<rect x='3' y='3' width='1' height='1'/>" + "</g>");
    A.put("stipple.dense", "<g id='" + "stipple.dense" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='2' y='0' width='1' height='1'/>" + "<rect x='4' y='0' width='1' height='1'/>" + "<rect x='0' y='2' width='1' height='1'/>" + "<rect x='2' y='2' width='1' height='1'/>" + "<rect x='4' y='2' width='1' height='1'/>" + "<rect x='0' y='4' width='1' height='1'/>" + "<rect x='2' y='4' width='1' height='1'/>" + "<rect x='4' y='4' width='1' height='1'/>" + "</g>");
    A.put("grid.diamond", "<g id='TEX_DEF_IN_1'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='1' width='1' height='1'/>" + "<rect x='2' y='2' width='1' height='1'/>" + "<rect x='3' y='3' width='1' height='1'/>" + "<rect x='4' y='4' width='1' height='1'/>" + "</g>" + "<g id='" + "grid.diamond" + "' transform='translate(0,5)'>" + "<use xlink:href='#TEX_DEF_IN_1'/>" + "<use xlink:href='#TEX_DEF_IN_1' transform='translate(1,-1)'/>" + "<use xlink:href='#TEX_DEF_IN_1' transform='translate(2,-2)'/>" + "<use xlink:href='#TEX_DEF_IN_1' transform='translate(3,-3)'/>" + "<use xlink:href='#TEX_DEF_IN_1' transform='translate(4,-4)'/>" + "</g>");
    A.put("line.diagonal", "<g id='" + "line.diagonal" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='1' width='1' height='1'/>" + "<rect x='2' y='2' width='1' height='1'/>" + "<rect x='3' y='3' width='1' height='1'/>" + "<rect x='4' y='4' width='1' height='1'/>" + "</g>");
    A.put("grid.square", "<g id='TEX_DEF_IN_2'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='2' y='0' width='1' height='1'/>" + "<rect x='4' y='0' width='1' height='1'/>" + "<rect x='6' y='0' width='1' height='1'/>" + "</g>" + "<g id='" + "grid.square" + "'>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(1,0)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(0,1)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(1,2)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(0,3)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(1,4)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(0,5)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(1,6)'/>" + "<use xlink:href='#TEX_DEF_IN_2' transform='translate(0,7)'/>" + "</g>");
    A.put("grid.triangle", "<g id='TEX_DEF_IN_3'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='1' width='1' height='1'/>" + "<rect x='2' y='2' width='1' height='1'/>" + "<rect x='3' y='3' width='1' height='1'/>" + "<rect x='4' y='4' width='1' height='1'/>" + "</g>" + "<g id='TEX_DEF_IN_4'>" + "<use xlink:href='#TEX_DEF_IN_3'/>" + "<use xlink:href='#TEX_DEF_IN_3' transform='translate(1,-1)'/>" + "<use xlink:href='#TEX_DEF_IN_3' transform='translate(2,-2)'/>" + "<use xlink:href='#TEX_DEF_IN_3' transform='translate(3,-3)'/>" + "<use xlink:href='#TEX_DEF_IN_3' transform='translate(4,-4)'/>" + "</g>" + "<g id='" + "grid.triangle" + "'>" + "<use xlink:href='#TEX_DEF_IN_4' transform='translate(0,5)'/>" + "</g>");
    A.put("line.cross", "<g id='" + "line.cross" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='0' width='1' height='1'/>" + "<rect x='2' y='0' width='1' height='1'/>" + "<rect x='3' y='0' width='1' height='1'/>" + "<rect x='4' y='0' width='1' height='1'/>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='0' y='1' width='1' height='1'/>" + "<rect x='0' y='2' width='1' height='1'/>" + "<rect x='0' y='3' width='1' height='1'/>" + "<rect x='0' y='4' width='1' height='1'/>" + "</g>");
    A.put("line.vertical", "<g id='" + "line.vertical" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='0' y='1' width='1' height='1'/>" + "<rect x='0' y='2' width='1' height='1'/>" + "<rect x='0' y='3' width='1' height='1'/>" + "<rect x='0' y='4' width='1' height='1'/>" + "</g>");
    A.put("line.horizontal", "<g id='" + "line.horizontal" + "'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='0' width='1' height='1'/>" + "<rect x='2' y='0' width='1' height='1'/>" + "<rect x='3' y='0' width='1' height='1'/>" + "<rect x='4' y='0' width='1' height='1'/>" + "</g>");
    A.put("line.antidiagonal", "<g id='TEX_DEF_IN_5'>" + "<rect x='0' y='0' width='1' height='1'/>" + "<rect x='1' y='1' width='1' height='1'/>" + "<rect x='2' y='2' width='1' height='1'/>" + "<rect x='3' y='3' width='1' height='1'/>" + "<rect x='4' y='4' width='1' height='1'/>" + "</g>" + "<g id='" + "line.antidiagonal" + "'>" + "<use xlink:href='#TEX_DEF_IN_5' transform='rotate(90,2.5,2.5)'/>" + "</g>");
  }
  
  public static String A(String paramString)
  {
    return (String)A.get(paramString);
  }
  
  public static String A(String paramString1, String paramString2, Color paramColor)
  {
    if (paramString2.equals("stipple.loose")) {
      return A(paramString1, paramString2, paramColor, 6, 6);
    }
    if (paramString2.equals("stipple.middle")) {
      return A(paramString1, paramString2, paramColor, 6, 6);
    }
    if (paramString2.equals("stipple.dense")) {
      return A(paramString1, paramString2, paramColor, 6, 6);
    }
    if (paramString2.equals("grid.diamond")) {
      return A(paramString1, paramString2, paramColor, 10, 10);
    }
    if (paramString2.equals("grid.square")) {
      return A(paramString1, paramString2, paramColor, 10, 10);
    }
    if (paramString2.equals("grid.triangle")) {
      return A(paramString1, paramString2, paramColor, 10, 10);
    }
    if (paramString2.equals("line.cross")) {
      return A(paramString1, paramString2, paramColor, 5, 5);
    }
    if (paramString2.equals("line.vertical")) {
      return A(paramString1, paramString2, paramColor, 5, 5);
    }
    if (paramString2.equals("line.horizontal")) {
      return A(paramString1, paramString2, paramColor, 5, 5);
    }
    if (paramString2.equals("line.diagonal")) {
      return A(paramString1, paramString2, paramColor, 5, 5);
    }
    if (paramString2.equals("line.antidiagonal")) {
      return A(paramString1, paramString2, paramColor, 5, 5);
    }
    return null;
  }
  
  private static String A(String paramString1, String paramString2, Color paramColor, int paramInt1, int paramInt2)
  {
    StringBuffer localStringBuffer = new StringBuffer("<pattern id='").append(paramString1).append("' x='0' y='0' width='").append(paramInt1).append("' height='").append(paramInt2).append("'");
    localStringBuffer.append(" fill='");
    E.B(localStringBuffer, paramColor);
    localStringBuffer.append("'");
    return " patternUnits='userSpaceOnUse'>" + "<use xlink:href='#" + paramString2 + "'/>\n" + "</pattern>";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.C
 * JD-Core Version:    0.7.0.1
 */
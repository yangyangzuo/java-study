package twaver.base.A.H;

import java.awt.Point;
import java.awt.Rectangle;
import twaver.Link;
import twaver.Node;
import twaver.TWaverConst;
import twaver.base.A.E.D;
import twaver.base.A.E.M;
import twaver.web.svg.network.SVGContext;
import twaver.web.svg.network.TSVGNetwork;
import twaver.web.svg.network.ui.LinkSVGUI;

public class A
{
  public int C;
  public int A;
  public Point F = new Point();
  public Point E = new Point();
  public Point B = new Point();
  public Point D = new Point();
  
  public A(SVGContext paramSVGContext, LinkSVGUI paramLinkSVGUI)
  {
    Link localLink = (Link)paramLinkSVGUI.getElement();
    Node localNode1 = localLink.getFromAgent();
    Node localNode2 = localLink.getToAgent();
    Rectangle localRectangle1 = paramLinkSVGUI.getFromBounds(paramSVGContext, localNode1);
    Rectangle localRectangle2 = paramLinkSVGUI.getToBounds(paramSVGContext, localNode2);
    int i = localLink.getLinkExtend();
    int j = localLink.getLinkFromPosition();
    int k = localLink.getLinkFromXOffset();
    int m = localLink.getLinkFromYOffset();
    int n = localLink.getLinkToPosition();
    int i1 = localLink.getLinkToXOffset();
    int i2 = localLink.getLinkToYOffset();
    this.F = M.A(paramLinkSVGUI.getNetwork().getElementSVGUI(localNode1), paramSVGContext, TWaverConst.EMPTY_DIMENSION, j, k, m);
    this.E = M.A(paramLinkSVGUI.getNetwork().getElementSVGUI(localNode2), paramSVGContext, TWaverConst.EMPTY_DIMENSION, n, i1, i2);
    A(localRectangle1, localRectangle2, i, j, n);
  }
  
  private void A(Rectangle paramRectangle1, Rectangle paramRectangle2, int paramInt1, int paramInt2, int paramInt3)
  {
    this.C = D.A(paramInt1, paramRectangle1, paramRectangle2);
    this.A = D.B(paramInt1, paramRectangle1, paramRectangle2);
    int i = paramInt2 == 1 ? 1 : 0;
    int j = paramInt3 == 1 ? 1 : 0;
    this.B.setLocation(this.F.x, this.F.y);
    if (this.C == 4)
    {
      if (i != 0)
      {
        Point tmp84_81 = this.F;
        tmp84_81.x = ((int)(tmp84_81.x + paramRectangle1.getWidth() / 2.0D));
      }
      this.B.x = (this.F.x + paramInt1);
    }
    else if (this.C == 2)
    {
      if (i != 0)
      {
        Point tmp138_135 = this.F;
        tmp138_135.x = ((int)(tmp138_135.x - paramRectangle1.getWidth() / 2.0D));
      }
      this.B.x = (this.F.x - paramInt1);
    }
    else if (this.C == 1)
    {
      if (i != 0)
      {
        Point tmp192_189 = this.F;
        tmp192_189.y = ((int)(tmp192_189.y - paramRectangle1.getHeight() / 2.0D));
      }
      this.B.y = (this.F.y - paramInt1);
    }
    else if (this.C == 3)
    {
      if (i != 0)
      {
        Point tmp246_243 = this.F;
        tmp246_243.y = ((int)(tmp246_243.y + paramRectangle1.getHeight() / 2.0D));
      }
      this.B.y = (this.F.y + paramInt1);
    }
    this.D.setLocation(paramRectangle2.getCenterX(), paramRectangle2.getCenterY());
    if (this.A == 4)
    {
      if (j != 0)
      {
        Point tmp312_309 = this.E;
        tmp312_309.x = ((int)(tmp312_309.x + paramRectangle2.getWidth() / 2.0D));
      }
      this.D.x = (this.E.x + paramInt1);
    }
    else if (this.A == 2)
    {
      if (j != 0)
      {
        Point tmp366_363 = this.E;
        tmp366_363.x = ((int)(tmp366_363.x - paramRectangle2.getWidth() / 2.0D));
      }
      this.D.x = (this.E.x - paramInt1);
    }
    else if (this.A == 1)
    {
      if (j != 0)
      {
        Point tmp420_417 = this.E;
        tmp420_417.y = ((int)(tmp420_417.y - paramRectangle2.getHeight() / 2.0D));
      }
      this.D.y = (this.E.y - paramInt1);
    }
    else if (this.A == 3)
    {
      if (j != 0)
      {
        Point tmp474_471 = this.E;
        tmp474_471.y = ((int)(tmp474_471.y + paramRectangle2.getHeight() / 2.0D));
      }
      this.D.y = (this.E.y + paramInt1);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.H.A
 * JD-Core Version:    0.7.0.1
 */
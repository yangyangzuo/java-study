package twaver.base.A.J;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.lang.reflect.Method;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import twaver.TWaverUtil;
import twaver.table.TTable;
import twaver.table.TTableModel;
import twaver.table.TTablePopupMenuFactory;

public class F
  implements TTablePopupMenuFactory
{
  public static final TTablePopupMenuFactory A = new F();
  static Class class$0;
  
  public JPopupMenu getPopupMenu(TTable paramTTable, MouseEvent paramMouseEvent)
  {
    JPopupMenu localJPopupMenu = new JPopupMenu();
    localJPopupMenu.add(A(paramTTable, "removeCheckedRows"));
    localJPopupMenu.add(A(paramTTable, "removeSelectedRows"));
    localJPopupMenu.addSeparator();
    localJPopupMenu.add(A(paramTTable, "clearRawData"));
    localJPopupMenu.add(A(paramTTable, "clearPublishedData"));
    localJPopupMenu.addSeparator();
    localJPopupMenu.add(A(paramTTable, "uncheckPublishedRows"));
    localJPopupMenu.add(A(paramTTable, "uncheckCurrentPageRows"));
    localJPopupMenu.addSeparator();
    localJPopupMenu.add(A(paramTTable, "checkSelectedRows"));
    localJPopupMenu.add(A(paramTTable, "checkCurrentPageRows"));
    localJPopupMenu.add(A(paramTTable, "checkPublishedRows"));
    return localJPopupMenu;
  }
  
  private JMenuItem A(TTable paramTTable, String paramString)
  {
    JMenuItem localJMenuItem = new JMenuItem(TWaverUtil.getString("table." + paramString));
    localJMenuItem.addActionListener(new ActionListener()
    {
      private final TTable val$table;
      private final String val$methodName;
      
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        try
        {
          this.val$table.getTableModel().unlock();
          Class tmp13_10 = F.class$0;
          if (tmp13_10 == null)
          {
            tmp13_10;
            try
            {
              tmpTernaryOp = (F.class$0 = Class.forName("twaver.table.TTableModel");
            }
            catch (ClassNotFoundException localClassNotFoundException)
            {
              throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
            }
          }
          Method localMethod = tmp13_10.getMethod(this.val$methodName, null);
          localMethod.invoke(this.val$table.getTableModel(), null);
        }
        catch (Exception localException)
        {
          TWaverUtil.handleError(null, localException);
        }
      }
    });
    return localJMenuItem;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.J.A;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import twaver.base.A.E.O;
import twaver.base.A.E.Y;
import twaver.table.TTable;
import twaver.table.TTableModel;

public class A
  extends MouseAdapter
{
  private TTable A;
  
  public A(TTable paramTTable)
  {
    this.A = paramTTable;
    this.A.addMouseListener(this);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    this.A.setCurrentMouseEvent(paramMouseEvent);
    if (!this.A.isEnabled()) {
      return;
    }
    int i = this.A.rowAtPoint(paramMouseEvent.getPoint());
    int j = this.A.columnAtPoint(paramMouseEvent.getPoint());
    if (j < 0) {
      return;
    }
    int k = this.A.getColumnModel().getColumn(j).getModelIndex();
    if (SwingUtilities.isLeftMouseButton(paramMouseEvent))
    {
      if ((paramMouseEvent.getClickCount() == 2) && (Y.A(this.A, paramMouseEvent.getPoint()) != null)) {
        return;
      }
      if ((j >= 0) && (i >= 0)) {
        this.A.getTableModel().fireRowClicked(paramMouseEvent.getClickCount(), i, k);
      } else if (this.A.isClearSelectionOnMarginClicked()) {
        this.A.getSelectionModel().clearSelection();
      }
    }
    else if ((SwingUtilities.isRightMouseButton(paramMouseEvent)) && (O.A(paramMouseEvent)) && (this.A.isSelectableOnRightClick()))
    {
      if ((j >= 0) && (i >= 0))
      {
        if (!this.A.getSelectionModel().isSelectedIndex(i))
        {
          this.A.getSelectionModel().setSelectionInterval(i, i);
          if (this.A.isEnableRightClickEvent()) {
            this.A.getTableModel().fireRowClicked(paramMouseEvent.getClickCount(), i, k);
          }
        }
      }
      else if (this.A.isClearSelectionOnMarginClicked()) {
        this.A.getSelectionModel().clearSelection();
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.A
 * JD-Core Version:    0.7.0.1
 */
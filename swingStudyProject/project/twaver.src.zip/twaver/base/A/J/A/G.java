package twaver.base.A.J.A;

import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import twaver.base.A.E.Y;
import twaver.table.ResizableTable;

public class G
  extends MouseInputAdapter
{
  public static Cursor D = Cursor.getPredefinedCursor(11);
  private int C;
  private Cursor A = D;
  private ResizableTable B;
  
  public G(ResizableTable paramResizableTable)
  {
    this.B = paramResizableTable;
    paramResizableTable.addMouseListener(this);
    paramResizableTable.addMouseMotionListener(this);
  }
  
  private boolean A(TableColumn paramTableColumn)
  {
    if (this.B.getTableHeader() == null) {
      return false;
    }
    if (!this.B.isColumnResizable()) {
      return false;
    }
    return (paramTableColumn != null) && (this.B.getTableHeader().getResizingAllowed()) && (paramTableColumn.getResizable());
  }
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    if (this.B.getTableHeader() == null) {
      return;
    }
    if (!this.B.isColumnResizable()) {
      return;
    }
    this.B.getTableHeader().setDraggedColumn(null);
    this.B.getTableHeader().setResizingColumn(null);
    this.B.getTableHeader().setDraggedDistance(0);
    Point localPoint = paramMouseEvent.getPoint();
    int i = this.B.columnAtPoint(localPoint);
    if (i == -1) {
      return;
    }
    TableColumn localTableColumn = Y.A(this.B, localPoint);
    if (!A(localTableColumn)) {
      return;
    }
    this.B.getTableHeader().setResizingColumn(localTableColumn);
    if (this.B.getTableHeader().getComponentOrientation().isLeftToRight()) {
      this.C = (localPoint.x - localTableColumn.getWidth());
    } else {
      this.C = (localPoint.x + localTableColumn.getWidth());
    }
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    if (!this.B.isColumnResizable()) {
      return;
    }
    TableColumn localTableColumn = Y.A(this.B, paramMouseEvent.getPoint());
    if (A(localTableColumn) != (this.B.getCursor() == D))
    {
      Cursor localCursor = this.B.getCursor();
      this.B.setCursor(this.A);
      this.A = localCursor;
    }
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    if (this.B.getTableHeader() == null) {
      return;
    }
    if (!this.B.isColumnResizable()) {
      return;
    }
    int i = paramMouseEvent.getX();
    TableColumn localTableColumn = this.B.getTableHeader().getResizingColumn();
    boolean bool = this.B.getTableHeader().getComponentOrientation().isLeftToRight();
    if (localTableColumn != null)
    {
      int j = localTableColumn.getWidth();
      int k;
      if (bool) {
        k = i - this.C;
      } else {
        k = this.C - i;
      }
      localTableColumn.setWidth(k);
      Container localContainer;
      if ((this.B.getTableHeader().getParent() == null) || ((localContainer = this.B.getTableHeader().getParent().getParent()) == null) || (!(localContainer instanceof JScrollPane))) {
        return;
      }
      if ((!localContainer.getComponentOrientation().isLeftToRight()) && (!bool) && (this.B != null))
      {
        JViewport localJViewport = ((JScrollPane)localContainer).getViewport();
        int m = localJViewport.getWidth();
        int n = k - j;
        int i1 = this.B.getWidth() + n;
        Dimension localDimension = this.B.getSize();
        localDimension.width += n;
        this.B.setSize(localDimension);
        if ((i1 >= m) && (this.B.getAutoResizeMode() == 0))
        {
          Point localPoint = localJViewport.getViewPosition();
          localPoint.x = Math.max(0, Math.min(i1 - m, localPoint.x + n));
          localJViewport.setViewPosition(localPoint);
          this.C += n;
        }
      }
    }
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    if (this.B.getTableHeader() == null) {
      return;
    }
    if (!this.B.isColumnResizable()) {
      return;
    }
    this.B.getTableHeader().setResizingColumn(null);
    this.B.getTableHeader().setDraggedColumn(null);
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent)
  {
    if (!this.B.isColumnResizable()) {
      return;
    }
    this.A = D;
    this.B.setCursor(Cursor.getPredefinedCursor(0));
  }
  
  public void mouseExited(MouseEvent paramMouseEvent)
  {
    if (!this.B.isColumnResizable()) {
      return;
    }
    this.A = D;
    this.B.setCursor(Cursor.getPredefinedCursor(0));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.G
 * JD-Core Version:    0.7.0.1
 */
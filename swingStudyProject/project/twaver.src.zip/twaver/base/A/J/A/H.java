package twaver.base.A.J.A;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import twaver.base.A.J.A;
import twaver.table.Category;
import twaver.table.TPropertySheet;

public class H
  extends MouseAdapter
{
  public TPropertySheet A = null;
  
  public H(TPropertySheet paramTPropertySheet)
  {
    this.A = paramTPropertySheet;
    this.A.addMouseListener(this);
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    if (!this.A.isEnableCategoryInteraction()) {
      return;
    }
    Point localPoint = paramMouseEvent.getPoint();
    int i = this.A.rowAtPoint(localPoint);
    A localA = this.A.getPropertySheetModel();
    Object localObject = localA.getValueAt(i, 0);
    if ((localObject instanceof Category))
    {
      Category localCategory = (Category)localObject;
      int j = localA.A(localCategory);
      int k = 18 * j;
      int m = 18 * (j + 1);
      int n = localPoint.x;
      if ((paramMouseEvent.getClickCount() == 2) || ((n >= k) && (n <= m))) {
        localA.A(localCategory.getName(), !localCategory.isExpand());
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.H
 * JD-Core Version:    0.7.0.1
 */
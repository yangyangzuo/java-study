package twaver.base.A.J.A;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import twaver.base.A.E.Y;
import twaver.table.ResizableTable;

public class F
  extends MouseAdapter
{
  private ResizableTable A;
  
  public F(ResizableTable paramResizableTable)
  {
    this.A = paramResizableTable;
    if (this.A.getTableHeader() != null) {
      this.A.getTableHeader().addMouseListener(this);
    }
    this.A.addMouseListener(this);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    if (paramMouseEvent.getClickCount() != 2) {
      return;
    }
    TableColumn localTableColumn = null;
    if ((paramMouseEvent.getSource() instanceof JTable))
    {
      if (this.A.isColumnAutoResizable()) {
        localTableColumn = Y.A(this.A, paramMouseEvent.getPoint());
      }
    }
    else if (((paramMouseEvent.getSource() instanceof JTableHeader)) && (this.A.isHeadAutoResizable()) && (this.A.getTableHeader() != null)) {
      localTableColumn = Y.A(this.A.getTableHeader(), paramMouseEvent.getPoint());
    }
    if (localTableColumn != null) {
      Y.B(this.A, localTableColumn, !paramMouseEvent.isControlDown(), -1);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.F
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.J.A;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import twaver.base.A.E.Y;
import twaver.table.TTable;
import twaver.table.TTableColumn;
import twaver.table.TTableModel;

public class E
  extends MouseAdapter
{
  private TTable A;
  
  public E(TTable paramTTable)
  {
    this.A = paramTTable;
    if (paramTTable.getTableHeader() != null) {
      this.A.getTableHeader().addMouseListener(this);
    }
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    if ((!SwingUtilities.isLeftMouseButton(paramMouseEvent)) || (this.A.getTableModel().isLocked())) {
      return;
    }
    if ((this.A.isSortable()) && (this.A.getTableHeader() != null))
    {
      if (Y.A(this.A.getTableHeader(), paramMouseEvent.getPoint()) != null) {
        return;
      }
      TableColumnModel localTableColumnModel = this.A.getColumnModel();
      int i = localTableColumnModel.getColumnIndexAtX(paramMouseEvent.getX());
      if (i < 0) {
        return;
      }
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      if (((localTableColumn instanceof TTableColumn)) && (!((TTableColumn)localTableColumn).isSortable())) {
        return;
      }
      int j = localTableColumn.getModelIndex();
      if (j < 0) {
        return;
      }
      boolean bool = this.A.isMultiColumnSortable() ? paramMouseEvent.isControlDown() : false;
      this.A.getTableModel().sortColumn(j, bool);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.E
 * JD-Core Version:    0.7.0.1
 */
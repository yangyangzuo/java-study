package twaver.base.A.J.A;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import twaver.PopupMenuGenerator;
import twaver.TView;
import twaver.table.TElementTable;
import twaver.table.TTable;
import twaver.table.TTableModel;
import twaver.table.TTablePopupMenuFactory;

public class C
  extends MouseAdapter
{
  private TTable A;
  
  public C(TTable paramTTable)
  {
    this.A = paramTTable;
    this.A.addMouseListener(this);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    if (SwingUtilities.isRightMouseButton(paramMouseEvent))
    {
      Object localObject;
      if (this.A.getTableModel().getPublishedColumn().size() == 0)
      {
        if (this.A.getTableHeaderPopupMenuFactory() != null)
        {
          localObject = this.A.getTableHeaderPopupMenuFactory().getPopupMenu(this.A, paramMouseEvent);
          if (localObject != null)
          {
            ((JPopupMenu)localObject).show(this.A, paramMouseEvent.getX(), paramMouseEvent.getY());
            ((JPopupMenu)localObject).requestFocus();
          }
        }
      }
      else
      {
        if ((this.A instanceof TElementTable))
        {
          localObject = (TElementTable)this.A;
          PopupMenuGenerator localPopupMenuGenerator = ((TElementTable)localObject).getPopupMenuGenerator();
          if (localPopupMenuGenerator != null)
          {
            JPopupMenu localJPopupMenu = localPopupMenuGenerator.generate((TView)localObject, paramMouseEvent);
            if (localJPopupMenu != null)
            {
              localJPopupMenu.show(this.A, paramMouseEvent.getX(), paramMouseEvent.getY());
              localJPopupMenu.requestFocus();
              return;
            }
          }
        }
        if (this.A.getTableBodyPopupMenuFactory() != null)
        {
          localObject = this.A.getTableBodyPopupMenuFactory().getPopupMenu(this.A, paramMouseEvent);
          if (localObject != null)
          {
            ((JPopupMenu)localObject).show(this.A, paramMouseEvent.getX(), paramMouseEvent.getY());
            ((JPopupMenu)localObject).requestFocus();
          }
        }
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.C
 * JD-Core Version:    0.7.0.1
 */
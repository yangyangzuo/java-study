package twaver.base.A.J.A;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.event.MouseInputAdapter;
import twaver.base.A.E.Y;
import twaver.table.ResizableTable;

public class B
  extends MouseInputAdapter
{
  public static Cursor E = Cursor.getPredefinedCursor(8);
  private Cursor B = E;
  private int A;
  private int D;
  private ResizableTable C;
  
  public B(ResizableTable paramResizableTable)
  {
    this.C = paramResizableTable;
    paramResizableTable.addMouseListener(this);
    paramResizableTable.addMouseMotionListener(this);
  }
  
  private int A(MouseEvent paramMouseEvent)
  {
    if (this.C.isRowResizable()) {
      return Y.B(this.C, paramMouseEvent.getPoint());
    }
    return -1;
  }
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    if (this.C.isRowResizable())
    {
      Point localPoint = paramMouseEvent.getPoint();
      this.D = A(paramMouseEvent);
      this.A = (localPoint.y - this.C.getRowHeight(this.D));
    }
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    if (this.C.isRowResizable()) {
      if ((A(paramMouseEvent) >= 0 ? 1 : 0) != (this.C.getCursor() == E ? 1 : 0))
      {
        Cursor localCursor = this.C.getCursor();
        this.C.setCursor(this.B);
        this.B = localCursor;
      }
    }
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    if ((this.C.isRowResizable()) && (this.D >= 0))
    {
      int i = paramMouseEvent.getY();
      int j = i - this.A;
      if (j > 0) {
        this.C.setRowHeight(this.D, j);
      }
    }
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent)
  {
    if (this.C.isRowResizable())
    {
      this.B = E;
      this.C.setCursor(Cursor.getPredefinedCursor(0));
    }
  }
  
  public void mouseExited(MouseEvent paramMouseEvent)
  {
    if (this.C.isRowResizable())
    {
      this.B = E;
      this.C.setCursor(Cursor.getPredefinedCursor(0));
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.J.A;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.table.JTableHeader;
import twaver.table.TTable;
import twaver.table.TTableModel;
import twaver.table.TTablePopupMenuFactory;

public class D
  extends MouseAdapter
{
  private TTable A;
  
  public D(TTable paramTTable)
  {
    this.A = paramTTable;
    if (this.A.getTableHeader() != null) {
      this.A.getTableHeader().addMouseListener(this);
    }
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    if ((this.A.getTableModel().isLocked()) || (this.A.getTableHeader() == null)) {
      return;
    }
    if ((SwingUtilities.isRightMouseButton(paramMouseEvent)) && (this.A.getTableHeaderPopupMenuFactory() != null))
    {
      JPopupMenu localJPopupMenu = this.A.getTableHeaderPopupMenuFactory().getPopupMenu(this.A, paramMouseEvent);
      if (localJPopupMenu != null)
      {
        localJPopupMenu.show(this.A.getTableHeader(), paramMouseEvent.getX(), paramMouseEvent.getY());
        localJPopupMenu.requestFocus();
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A.D
 * JD-Core Version:    0.7.0.1
 */
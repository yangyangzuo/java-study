package twaver.base.A.J;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;
import twaver.Element;
import twaver.table.TTreeTable;
import twaver.tree.TTree;

public class D
  implements TableCellEditor
{
  private TTreeTable A;
  
  public D(TTreeTable paramTTreeTable)
  {
    this.A = paramTTreeTable;
  }
  
  public Component getTableCellEditorComponent(JTable paramJTable, Object paramObject, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    return null;
  }
  
  public void cancelCellEditing() {}
  
  public boolean stopCellEditing()
  {
    return true;
  }
  
  public Object getCellEditorValue()
  {
    return null;
  }
  
  public boolean shouldSelectCell(EventObject paramEventObject)
  {
    return false;
  }
  
  public void addCellEditorListener(CellEditorListener paramCellEditorListener) {}
  
  public void removeCellEditorListener(CellEditorListener paramCellEditorListener) {}
  
  public boolean isCellEditable(EventObject paramEventObject)
  {
    if ((paramEventObject instanceof MouseEvent))
    {
      MouseEvent localMouseEvent1 = (MouseEvent)paramEventObject;
      if ((!localMouseEvent1.isControlDown()) && (!localMouseEvent1.isShiftDown()))
      {
        TTree localTTree = this.A.getTree();
        int i = this.A.columnAtPoint(new Point(localMouseEvent1.getX(), localMouseEvent1.getY()));
        int j = this.A.rowAtPoint(new Point(localMouseEvent1.getX(), localMouseEvent1.getY()));
        Element localElement = this.A.getElementByRowIndex(j);
        j = localTTree.getRowForPath(localTTree.getTreePathByElement(localElement));
        MouseEvent localMouseEvent2 = new MouseEvent(localTTree, localMouseEvent1.getID(), localMouseEvent1.getWhen(), localMouseEvent1.getModifiers(), localMouseEvent1.getX() - this.A.getCellRect(0, i, true).x, localTTree.getRowHeight() * j, localMouseEvent1.getClickCount(), localMouseEvent1.isPopupTrigger());
        localTTree.dispatchEvent(localMouseEvent2);
      }
    }
    return false;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.D
 * JD-Core Version:    0.7.0.1
 */
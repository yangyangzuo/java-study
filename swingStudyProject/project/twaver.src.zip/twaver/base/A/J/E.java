package twaver.base.A.J;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import twaver.TWaverUtil;
import twaver.table.TTable;
import twaver.table.TTableColumn;
import twaver.table.TTableModel;
import twaver.table.TTablePopupMenuFactory;

public class E
  implements TTablePopupMenuFactory
{
  public static final TTablePopupMenuFactory B = new E();
  
  public JPopupMenu getPopupMenu(TTable paramTTable, MouseEvent paramMouseEvent)
  {
    JPopupMenu localJPopupMenu = new JPopupMenu();
    JPanel localJPanel1 = TWaverUtil.createVerticalPanel(0);
    JScrollPane localJScrollPane = new JScrollPane(localJPanel1);
    localJScrollPane.setHorizontalScrollBarPolicy(31);
    JPanel localJPanel2 = TWaverUtil.createVerticalPanel(0);
    localJPopupMenu.setLayout(new BorderLayout());
    localJPopupMenu.add(localJScrollPane, "Center");
    localJPopupMenu.add(localJPanel2, "South");
    ArrayList localArrayList = new ArrayList();
    List localList = paramTTable.getTableModel().getRawColumn();
    for (int i = 0; i < localList.size(); i++)
    {
      localObject = (TTableColumn)localList.get(i);
      String str = ((TTableColumn)localObject).getDisplayName();
      if ((str != null) && (!str.trim().equals("")) && ((paramTTable.isShowPredefinedColumnsInPopupMenu()) || (!paramTTable.isPredefinedColumn((TTableColumn)localObject))))
      {
        JCheckBox localJCheckBox = new JCheckBox(((TTableColumn)localObject).getDisplayName(), ((TTableColumn)localObject).isVisible());
        localJPanel1.add(localJCheckBox);
        localJCheckBox.putClientProperty("twaver.column", localObject);
        localArrayList.add(localJCheckBox);
        localJCheckBox.addActionListener(new ActionListener()
        {
          private final TTableColumn val$column;
          private final JCheckBox val$checkBox;
          
          public void actionPerformed(ActionEvent paramAnonymousActionEvent)
          {
            this.val$column.setVisible(this.val$checkBox.isSelected());
          }
        });
      }
    }
    JButton localJButton = new JButton(TWaverUtil.getString("table.column.visibleAll"));
    localJPanel2.add(localJButton);
    localJButton.addActionListener(new ActionListener()
    {
      private final List val$checkBoxs;
      
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        for (int i = 0; i < this.val$checkBoxs.size(); i++)
        {
          JCheckBox localJCheckBox = (JCheckBox)this.val$checkBoxs.get(i);
          TTableColumn localTTableColumn = (TTableColumn)localJCheckBox.getClientProperty("twaver.column");
          localTTableColumn.setVisible(true);
          localJCheckBox.setSelected(true);
        }
      }
    });
    localJButton = new JButton(TWaverUtil.getString("table.column.hideAll"));
    localJPanel2.add(localJButton);
    localJButton.addActionListener(new ActionListener()
    {
      private final List val$checkBoxs;
      
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        for (int i = 0; i < this.val$checkBoxs.size(); i++)
        {
          JCheckBox localJCheckBox = (JCheckBox)this.val$checkBoxs.get(i);
          TTableColumn localTTableColumn = (TTableColumn)localJCheckBox.getClientProperty("twaver.column");
          localTTableColumn.setVisible(false);
          localJCheckBox.setSelected(false);
        }
      }
    });
    Object localObject = localJPopupMenu.getPreferredSize();
    if (((Dimension)localObject).height > 400)
    {
      ((Dimension)localObject).height = 400;
      localObject.width += localJScrollPane.getVerticalScrollBar().getPreferredSize().width;
      localJPopupMenu.setPopupSize(((Dimension)localObject).width, ((Dimension)localObject).height);
    }
    return localJPopupMenu;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.E
 * JD-Core Version:    0.7.0.1
 */
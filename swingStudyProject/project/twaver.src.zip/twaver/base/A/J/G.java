package twaver.base.A.J;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.TDataBox;
import twaver.TWaverUtil;
import twaver.VisibleFilter;
import twaver.base.A.F.A.B;
import twaver.table.TTable;
import twaver.table.TTableColumn;
import twaver.table.TTableModel;
import twaver.table.TTableRowFilter;
import twaver.table.TTreeTable;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public class G
  extends TTableModel
{
  private TTree D;
  private TTableColumn H;
  private Comparator G = new B(this);
  private Comparator J = new _B();
  private PropertyChangeListener F = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
    {
      if (G.this.D.getDataBox() != G.this.G().getDataBox()) {
        G.this.G().setDataBox(G.this.D.getDataBox());
      }
    }
  };
  private PropertyChangeListener E = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
    {
      G.this.publishData();
    }
  };
  private TreeExpansionListener K = new TreeExpansionListener()
  {
    public void treeCollapsed(TreeExpansionEvent paramAnonymousTreeExpansionEvent)
    {
      G.this.publishData();
    }
    
    public void treeExpanded(TreeExpansionEvent paramAnonymousTreeExpansionEvent)
    {
      G.this.publishData();
    }
  };
  private TreeModelListener I = new TreeModelListener()
  {
    public void treeNodesChanged(TreeModelEvent paramAnonymousTreeModelEvent)
    {
      G.access$1(G.this).repaint();
    }
    
    public void treeNodesInserted(TreeModelEvent paramAnonymousTreeModelEvent)
    {
      G.this.publishData();
    }
    
    public void treeNodesRemoved(TreeModelEvent paramAnonymousTreeModelEvent)
    {
      G.this.publishData();
    }
    
    public void treeStructureChanged(TreeModelEvent paramAnonymousTreeModelEvent)
    {
      G.this.publishData();
    }
  };
  
  public G(TTreeTable paramTTreeTable)
  {
    super(paramTTreeTable);
    paramTTreeTable.addPropertyChangeListener("databox", new PropertyChangeListener()
    {
      public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
      {
        G.this.F();
      }
    });
  }
  
  public TTree E()
  {
    return this.D;
  }
  
  public TTreeTable G()
  {
    return (TTreeTable)this.table;
  }
  
  private void F()
  {
    TDataBox localTDataBox = G().getDataBox();
    if (this.D == null) {
      A(localTDataBox);
    } else if (this.D.getDataBox() != localTDataBox) {
      this.D.setDataBox(localTDataBox);
    }
  }
  
  private void A(TDataBox paramTDataBox)
  {
    TableCellRenderer localTableCellRenderer = G().createTreeColumnCellRenderer();
    if (!(localTableCellRenderer instanceof TTree)) {
      throw new IllegalStateException("tree column cell renderer must be an instance of TTree");
    }
    this.D = ((TTree)localTableCellRenderer);
    this.H.setRenderer(localTableCellRenderer);
    this.D.addPropertyChangeListener("databox", this.F);
    this.D.addPropertyChangeListener("rootVisible", this.E);
    this.D.addTreeExpansionListener(this.K);
    this.D.getModel().addTreeModelListener(this.I);
    this.D.addVisibleFilter(new _A());
    if (this.D.getRowHeight() != this.table.getRowHeight()) {
      this.D.setRowHeight(this.table.getRowHeight());
    }
  }
  
  protected void createPredefindedColumn()
  {
    super.createPredefindedColumn();
    String str = "table.column.tree";
    this.H = new TTableColumn(str, TWaverUtil.getString(str), 150, null, G().createTreeColumnCellEditor());
    this.H.addPropertyChangeListener(this);
    this.rawColumn.add(this.H);
    this.rawColumnMap.put(this.H.getName(), this.H);
    fireColumnAdded(this.H);
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if ((paramInt2 < 0) || (paramInt2 >= this.publishedColumn.size())) {
      return false;
    }
    TTableColumn localTTableColumn = (TTableColumn)this.publishedColumn.get(paramInt2);
    if (localTTableColumn == this.H) {
      return true;
    }
    Element localElement = G().getElementByRowIndex(paramInt1);
    if (!G().interested(localElement))
    {
      if (localElement == null) {
        return false;
      }
      if ((localTTableColumn != this.oidColumn) && (localTTableColumn != this.checkColumn)) {
        return false;
      }
    }
    return super.isCellEditable(paramInt1, paramInt2);
  }
  
  public void addRowFilter(TTableRowFilter paramTTableRowFilter)
  {
    if (!this.rowFilters.contains(paramTTableRowFilter))
    {
      this.rowFilters.add(paramTTableRowFilter);
      if (E() != null) {
        E().updateTViewUI();
      }
    }
  }
  
  public void removeRowFilter(TTableRowFilter paramTTableRowFilter)
  {
    if ((this.rowFilters.remove(paramTTableRowFilter)) && (E() != null)) {
      E().updateTViewUI();
    }
  }
  
  public void sortColumn(TTableColumn paramTTableColumn, int paramInt, boolean paramBoolean)
  {
    TDataBox localTDataBox = G().getDataBox();
    List localList1 = D();
    List localList2 = localTDataBox.getSelectionModel().getAllSelectedElement();
    super.sortColumn(paramTTableColumn, paramInt, paramBoolean);
    if (this.sortColumnList.size() == 0) {
      this.D.setSortComparator(null);
    } else {
      this.D.setSortComparator(this.J);
    }
    E().ensureVisible(localList1);
    localTDataBox.getSelectionModel().setSelection(localList2);
  }
  
  public void reset()
  {
    this.D.setSortComparator(null);
    super.reset();
  }
  
  private List D()
  {
    ArrayList localArrayList = new ArrayList();
    int i = this.D.getRowCount();
    for (int j = 0; j < i; j++)
    {
      TreePath localTreePath = this.D.getPathForRow(j);
      Object localObject = localTreePath.getLastPathComponent();
      if ((localObject instanceof ElementNode))
      {
        ElementNode localElementNode = (ElementNode)localObject;
        Element localElement = localElementNode.getElement();
        localArrayList.add(localElement);
      }
    }
    return localArrayList;
  }
  
  public void publishData()
  {
    if (this.D == null) {
      return;
    }
    if (!this.table.isPublishable()) {
      return;
    }
    TTreeTable localTTreeTable = G();
    boolean bool = localTTreeTable.isInCheckState();
    this.publishedData.clear();
    this.selectedRows.clear();
    int i = this.D.getRowCount();
    for (int j = 0; j < i; j++)
    {
      localObject1 = this.D.getPathForRow(j);
      Object localObject2 = ((TreePath)localObject1).getLastPathComponent();
      Object localObject3;
      if ((localObject2 instanceof ElementNode))
      {
        ElementNode localElementNode = (ElementNode)localObject2;
        localObject3 = localElementNode.getElement();
        Vector localVector = localTTreeTable.getRowDataByElementID(((Element)localObject3).getID());
        if (localVector != null)
        {
          this.publishedData.add(localVector);
          if ((!bool) && (((Element)localObject3).isSelected())) {
            this.selectedRows.add(localVector);
          }
        }
        else
        {
          this.publishedData.clear();
          this.selectedRows.clear();
          update();
        }
      }
      else
      {
        int k = getRawColumn().size();
        localObject3 = new Vector(k);
        for (int m = 0; m < k; m++) {
          ((Vector)localObject3).add(null);
        }
        this.publishedData.add(localObject3);
        if (this.D.getSelectionModel().isPathSelected((TreePath)localObject1)) {
          this.selectedRows.add(localObject3);
        }
      }
    }
    List localList = this.table.filterTopRows(this.publishedData);
    Object localObject1 = this.table.filterBottomRows(this.publishedData);
    if ((localList != null) && (localList.size() > 0)) {
      this.publishedData.addAll(0, localList);
    }
    if ((localObject1 != null) && (((List)localObject1).size() > 0)) {
      this.publishedData.addAll((Collection)localObject1);
    }
    resetPublishedDataMap();
    update();
  }
  
  public TTableColumn B()
  {
    return this.H;
  }
  
  public Comparator C()
  {
    return this.G;
  }
  
  public void A(Comparator paramComparator)
  {
    if (paramComparator == null) {
      throw new IllegalArgumentException("treeColumnComparator can not be null.");
    }
    this.G = paramComparator;
  }
  
  class _B
    implements Comparator
  {
    _B() {}
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      Element localElement1 = (Element)paramObject1;
      Element localElement2 = (Element)paramObject2;
      TTreeTable localTTreeTable = G.this.G();
      Vector localVector1 = localTTreeTable.getRowDataByElementID(localElement1.getID());
      Vector localVector2 = localTTreeTable.getRowDataByElementID(localElement2.getID());
      for (int i = 0; i < G.access$2(G.this).size(); i++)
      {
        TTableColumn localTTableColumn = (TTableColumn)G.access$2(G.this).get(i);
        if (localTTableColumn.getSortComparator() != null)
        {
          G.access$5(G.access$4(G.this).indexOf(localTTableColumn));
          G.access$7(localTTableColumn);
          int j = 0;
          if (localTTableColumn == G.this.H) {
            j = G.this.G.compare(localElement1, localElement2) * localTTableColumn.getSortMode();
          } else {
            j = G.access$10().compare(localVector1, localVector2);
          }
          if (j != 0) {
            return j;
          }
        }
      }
      G.access$5(-1);
      G.access$7(null);
      return 0;
    }
  }
  
  class _A
    implements VisibleFilter
  {
    _A() {}
    
    public boolean isVisible(Element paramElement)
    {
      TTreeTable localTTreeTable = G.this.G();
      Vector localVector = localTTreeTable.getRowDataByElementID(paramElement.getID());
      return G.this.isVisible(localVector);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.G
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.J;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.ListSelectionModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import twaver.Element;
import twaver.ElementAttribute;
import twaver.TPropertyDescriptor;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.base.A.E.H;
import twaver.base.A.F.A.C;
import twaver.base.A.I.D;
import twaver.table.Category;
import twaver.table.PropertySheetEvent;
import twaver.table.PropertyValueSettingListener;
import twaver.table.TPropertySheet;

public class A
  extends AbstractTableModel
{
  private PropertyChangeListener C = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
    {
      String str = paramAnonymousPropertyChangeEvent.getPropertyName();
      if ((str.equals("element.update.ui")) || (str.equals("businessObject")))
      {
        A.this.B();
      }
      else
      {
        Integer localInteger = (Integer)A.this.G.get(str);
        if (localInteger != null)
        {
          int i = localInteger.intValue();
          A.this.fireTableCellUpdated(i, 1);
          if ((A.this.K instanceof TPropertySheet)) {
            ((TPropertySheet)A.this.K).firePropertySheetChanged(paramAnonymousPropertyChangeEvent, i);
          }
        }
      }
    }
  };
  private PropertyChangeListener A = new PropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
    {
      String str = paramAnonymousPropertyChangeEvent.getPropertyName();
      if (("sheet.mode".equals(str)) || ("sheet.single.root.category.visible".equals(str)))
      {
        A.this.B();
      }
      else if ("sheet.property.extra.indent".equals(str))
      {
        ((TPropertySheet)A.this.K).repaint();
      }
      else if (("sheet.sorting.categories".equals(str)) || ("sheet.sorting.properties".equals(str)) || ("sheet.property.sorting.comparator".equals(str)) || ("sheet.category.sorting.comparator".equals(str)) || ("sheet.sorting.ascending".equals(str)))
      {
        JTableHeader localJTableHeader = ((TPropertySheet)A.this.K).getTableHeader();
        if (localJTableHeader != null) {
          ((TPropertySheet)A.this.K).getTableHeader().repaint();
        }
        A.this.D();
      }
    }
  };
  private D K = null;
  private Element E = null;
  private List I = new ArrayList();
  private Map H = new HashMap();
  private _A F = null;
  private List B = new ArrayList();
  private Set D = new LinkedHashSet();
  private Map G = new HashMap();
  private Map J = new HashMap();
  private Map L = new HashMap();
  
  public A(D paramD)
  {
    this.K = paramD;
    if ((this.K instanceof TPropertySheet)) {
      ((TPropertySheet)this.K).addPropertyChangeListener(this.A);
    }
  }
  
  private boolean C(Category paramCategory)
  {
    if ((paramCategory != null) && (this.F != null) && (!this.K.isSingleRootCategoryVisible()))
    {
      _A local_A = (_A)this.L.get(paramCategory);
      if (local_A.A == this.F)
      {
        if (this.F.B != null) {
          return (this.F.B.size() == 1) && ((this.F.B.iterator().next() instanceof Category));
        }
        return (this.F.E.size() == 0) && (this.F.D.size() == 1);
      }
    }
    return false;
  }
  
  private boolean G()
  {
    if ((this.F != null) && (!this.K.isSingleRootCategoryVisible()))
    {
      if (this.F.B != null) {
        return (this.F.B.size() == 1) && ((this.F.B.iterator().next() instanceof Category));
      }
      return (this.F.E.size() == 0) && (this.F.D.size() == 1);
    }
    return false;
  }
  
  public int B(TPropertyDescriptor paramTPropertyDescriptor)
  {
    if (this.K.getMode() == 0)
    {
      if (this.K.isPropertyExtraIndent()) {
        return 1;
      }
      return 0;
    }
    Category localCategory = D(paramTPropertyDescriptor.getElementAttribute().getCategoryName());
    int i = A(localCategory);
    if (this.K.isPropertyExtraIndent()) {
      i++;
    }
    return i;
  }
  
  public int A(Category paramCategory)
  {
    if (this.K.getMode() == 0)
    {
      if (this.K.isPropertyExtraIndent()) {
        return 1;
      }
      return 0;
    }
    paramCategory = D(paramCategory.getName());
    _A local_A = (_A)this.L.get(paramCategory);
    for (int i = -1; (local_A != null) && (local_A != this.F); i++) {
      local_A = local_A.A;
    }
    if ((G()) && (this.K.isPropertyExtraIndent())) {
      i--;
    }
    return i;
  }
  
  private _A A(Category paramCategory, _A param_A)
  {
    _A local_A = (_A)this.L.get(paramCategory);
    if (local_A == null)
    {
      paramCategory = (Category)paramCategory.clone();
      if (this.K.isRestoreCategoryState())
      {
        Boolean localBoolean = (Boolean)this.H.get(paramCategory.getName());
        if ((localBoolean != null) && (paramCategory.isExpand() != localBoolean.booleanValue()))
        {
          paramCategory.setExpand(localBoolean.booleanValue());
          B(paramCategory);
        }
      }
      local_A = new _A(paramCategory, param_A);
      param_A.A(paramCategory);
      this.L.put(paramCategory, local_A);
    }
    return local_A;
  }
  
  private void B(Category paramCategory)
  {
    if ((this.K instanceof TPropertySheet))
    {
      TPropertySheet localTPropertySheet = (TPropertySheet)this.K;
      localTPropertySheet.firePropertySheetChanged(paramCategory);
    }
  }
  
  private List C()
  {
    Object localObject = null;
    HashMap localHashMap1 = new HashMap();
    HashMap localHashMap2 = new HashMap();
    Iterator localIterator1 = K();
    if (localIterator1 != null) {
      while (localIterator1.hasNext())
      {
        Element localElement = (Element)localIterator1.next();
        if (this.K.getPropertyDistinctLevel() == 1)
        {
          if (!localHashMap2.containsKey(localElement.getClass())) {
            localHashMap2.put(localElement.getClass(), null);
          }
        }
        else
        {
          List localList1 = this.K.getAllBeanInfo(localElement);
          List localList2 = H.A(localList1);
          TPropertyDescriptor localTPropertyDescriptor;
          if (localObject != null)
          {
            Iterator localIterator2 = localList2.iterator();
            while (localIterator2.hasNext())
            {
              localTPropertyDescriptor = (TPropertyDescriptor)localIterator2.next();
              if (!localHashMap1.containsKey(localTPropertyDescriptor.getElementAttribute().getKey())) {
                localIterator2.remove();
              }
            }
          }
          localObject = localList2;
          localHashMap1.clear();
          for (int i = 0; i < localObject.size(); i++)
          {
            localTPropertyDescriptor = (TPropertyDescriptor)localObject.get(i);
            localHashMap1.put(localTPropertyDescriptor.getElementAttribute().getKey(), null);
          }
        }
      }
    }
    if (localObject == null) {
      return TWaverConst.EMPTY_LIST;
    }
    return localObject;
  }
  
  public void D()
  {
    Object localObject;
    if ((this.K instanceof TPropertySheet))
    {
      if (((TPropertySheet)this.K).isEditing())
      {
        localObject = ((TPropertySheet)this.K).getCellEditor();
        if (localObject != null) {
          ((TableCellEditor)localObject).stopCellEditing();
        }
      }
      if (this.E != null) {
        this.E.removePropertyChangeListener(this.C);
      }
    }
    this.E = E();
    this.F = new _A(null, null);
    this.L.clear();
    this.J.clear();
    if (this.K.isSortingProperties())
    {
      if (this.K.getPropertySortingComparator() != null) {
        this.D = new TreeSet(new _B(this.K.getPropertySortingComparator()));
      } else {
        this.D = new TreeSet(new _B(C.A));
      }
    }
    else {
      this.D = new LinkedHashSet();
    }
    if (this.E != null)
    {
      if ((this.K instanceof TPropertySheet)) {
        this.E.addPropertyChangeListener(this.C);
      }
      localObject = C();
      for (int i = 0; i < ((List)localObject).size(); i++)
      {
        TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)((List)localObject).get(i);
        ElementAttribute localElementAttribute = localTPropertyDescriptor.getElementAttribute();
        String str1 = localElementAttribute.getCategoryName();
        Category localCategory1 = Category.getCategory(str1);
        if (localCategory1 == null)
        {
          TWaverUtil.handleError("Category with name '" + str1 + "' isn't registered.", null);
        }
        else
        {
          this.D.add(localTPropertyDescriptor);
          this.J.put(localElementAttribute.getKey(), localTPropertyDescriptor);
          if (!this.K.isVisible(localElementAttribute))
          {
            this.D.remove(localTPropertyDescriptor);
            this.J.remove(localElementAttribute.getKey());
          }
          else
          {
            _A local_A;
            if (localElementAttribute.getCategoryNames() == null)
            {
              local_A = A(Category.getCategory(localElementAttribute.getCategoryName()), this.F);
              local_A.A(localTPropertyDescriptor);
            }
            else
            {
              local_A = this.F;
              List localList = localElementAttribute.getCategoryNames();
              for (int j = 0; j < localList.size(); j++)
              {
                String str2 = (String)localList.get(j);
                Category localCategory2 = Category.getCategory(str2);
                local_A = A(localCategory2, local_A);
              }
              local_A.A(localTPropertyDescriptor);
            }
          }
        }
      }
    }
    B();
  }
  
  public void B()
  {
    int i = 0;
    if ((this.K instanceof TPropertySheet)) {
      i = ((TPropertySheet)this.K).getSelectionModel().getLeadSelectionIndex();
    }
    TPropertyDescriptor localTPropertyDescriptor1 = A(i);
    this.B.clear();
    this.G.clear();
    Object localObject;
    if (this.K.getMode() == 1)
    {
      this.F.A();
    }
    else
    {
      localObject = this.D.iterator();
      while (((Iterator)localObject).hasNext())
      {
        TPropertyDescriptor localTPropertyDescriptor2 = (TPropertyDescriptor)((Iterator)localObject).next();
        ElementAttribute localElementAttribute = localTPropertyDescriptor2.getElementAttribute();
        this.B.add(localTPropertyDescriptor2);
        this.G.put(localElementAttribute.getKey(), TWaverUtil.valueOf(this.B.size() - 1));
      }
    }
    fireTableDataChanged();
    if ((this.K instanceof TPropertySheet))
    {
      localObject = (TPropertySheet)this.K;
      if (localTPropertyDescriptor1 != null)
      {
        i = A(localTPropertyDescriptor1.getElementAttribute());
        if (i >= 0)
        {
          ((TPropertySheet)localObject).getSelectionModel().setSelectionInterval(i, i);
          ((TPropertySheet)localObject).ensureSelectedRowVisible();
        }
      }
      else
      {
        ((TPropertySheet)localObject).getSelectionModel().clearSelection();
      }
      ((TPropertySheet)localObject).firePropertySheetChanged(new PropertySheetEvent((TPropertySheet)localObject, 2));
    }
  }
  
  public Element H()
  {
    return this.E;
  }
  
  public Class getColumnClass(int paramInt)
  {
    if (paramInt == 0) {}
    return Object.class;
  }
  
  public String getColumnName(int paramInt)
  {
    if (paramInt == 0) {
      return TWaverUtil.getString("PROPERTY");
    }
    if (paramInt == 1) {
      return TWaverUtil.getString("VALUE");
    }
    if (paramInt == 2) {
      return TWaverUtil.getString("DESCRIPTION");
    }
    return null;
  }
  
  public int getColumnCount()
  {
    return this.K.isShowDescriptionColumn() ? 3 : 2;
  }
  
  public int getRowCount()
  {
    return this.B.size();
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if (this.K.isEditable())
    {
      if (paramInt2 != 1) {
        return false;
      }
      Object localObject = this.B.get(paramInt1);
      if ((localObject instanceof Category)) {
        return false;
      }
      TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)localObject;
      return localTPropertyDescriptor.getElementAttribute().isEditable();
    }
    return false;
  }
  
  public TPropertyDescriptor B(String paramString)
  {
    return (TPropertyDescriptor)this.J.get(paramString);
  }
  
  public TPropertyDescriptor A(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.B.size())) {
      return null;
    }
    Object localObject = this.B.get(paramInt);
    if ((localObject instanceof Category)) {
      return null;
    }
    return (TPropertyDescriptor)localObject;
  }
  
  public Category C(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.B.size())) {
      return null;
    }
    Object localObject = this.B.get(paramInt);
    if ((localObject instanceof Category)) {
      return (Category)localObject;
    }
    return null;
  }
  
  public List J()
  {
    return new ArrayList(this.D);
  }
  
  public List C(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramString == null) {
      return localArrayList;
    }
    Iterator localIterator1 = this.D.iterator();
    while (localIterator1.hasNext())
    {
      TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)localIterator1.next();
      ElementAttribute localElementAttribute = localTPropertyDescriptor.getElementAttribute();
      if (paramString.equals(localElementAttribute.getCategoryName()))
      {
        localArrayList.add(localTPropertyDescriptor);
      }
      else if (localElementAttribute.getCategoryNames() != null)
      {
        Iterator localIterator2 = localElementAttribute.getCategoryNames().iterator();
        while (localIterator2.hasNext())
        {
          String str = (String)localIterator2.next();
          if (paramString.equals(str))
          {
            localArrayList.add(localTPropertyDescriptor);
            break;
          }
        }
      }
    }
    return localArrayList;
  }
  
  public Category D(String paramString)
  {
    Iterator localIterator = this.L.keySet().iterator();
    while (localIterator.hasNext())
    {
      Category localCategory = (Category)localIterator.next();
      if (localCategory.getName().equals(paramString)) {
        return localCategory;
      }
    }
    return null;
  }
  
  public ElementAttribute B(int paramInt)
  {
    Object localObject = this.B.get(paramInt);
    if ((localObject instanceof Category)) {
      return null;
    }
    TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)localObject;
    return localTPropertyDescriptor.getElementAttribute();
  }
  
  public Object getValueAt(int paramInt1, int paramInt2)
  {
    if ((this.E == null) || (paramInt1 < 0) || (paramInt2 < 0)) {
      return null;
    }
    Object localObject = this.B.get(paramInt1);
    if ((localObject instanceof Category)) {
      return (Category)localObject;
    }
    if (paramInt2 == 0) {
      return localObject;
    }
    if (paramInt2 == 2) {
      return this.K.getDescription(this.E, (TPropertyDescriptor)localObject);
    }
    return this.E.getPropertyValue((TPropertyDescriptor)localObject);
  }
  
  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
    if (this.E == null) {
      return;
    }
    if (paramInt2 != 1) {
      return;
    }
    Object localObject = this.B.get(paramInt1);
    if ((localObject instanceof Category)) {
      return;
    }
    TPropertyDescriptor localTPropertyDescriptor = (TPropertyDescriptor)localObject;
    ElementAttribute localElementAttribute = localTPropertyDescriptor.getElementAttribute();
    if (localElementAttribute.isEditable()) {
      A(localTPropertyDescriptor, paramObject);
    }
  }
  
  private void A(TPropertyDescriptor paramTPropertyDescriptor, Object paramObject)
  {
    Iterator localIterator = K();
    if (localIterator != null) {
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        PropertyValueSettingListener localPropertyValueSettingListener;
        for (int i = 0; i < this.I.size(); i++)
        {
          localPropertyValueSettingListener = (PropertyValueSettingListener)this.I.get(i);
          if (!localPropertyValueSettingListener.beforePropertyValueSetting(localElement, paramTPropertyDescriptor, paramObject)) {
            return;
          }
        }
        localElement.setPropertyValue(paramTPropertyDescriptor, paramObject);
        for (i = 0; i < this.I.size(); i++)
        {
          localPropertyValueSettingListener = (PropertyValueSettingListener)this.I.get(i);
          localPropertyValueSettingListener.afterPropertyValueSetting(localElement, paramTPropertyDescriptor, paramObject);
        }
      }
    }
  }
  
  public Object A(TPropertyDescriptor paramTPropertyDescriptor)
  {
    if (this.E == null) {
      return null;
    }
    return this.E.getPropertyValue(paramTPropertyDescriptor);
  }
  
  public int A(ElementAttribute paramElementAttribute)
  {
    if (paramElementAttribute != null)
    {
      Integer localInteger = (Integer)this.G.get(paramElementAttribute.getKey());
      if (localInteger != null) {
        return localInteger.intValue();
      }
    }
    return -1;
  }
  
  public int A(String paramString)
  {
    Integer localInteger = (Integer)this.G.get(paramString);
    if (localInteger != null) {
      return localInteger.intValue();
    }
    return -1;
  }
  
  public void B(PropertyValueSettingListener paramPropertyValueSettingListener)
  {
    if (!this.I.contains(paramPropertyValueSettingListener)) {
      this.I.add(paramPropertyValueSettingListener);
    }
  }
  
  public void A(PropertyValueSettingListener paramPropertyValueSettingListener)
  {
    this.I.remove(paramPropertyValueSettingListener);
  }
  
  public void A(String paramString, boolean paramBoolean)
  {
    Category localCategory = D(paramString);
    if ((localCategory != null) && (localCategory.isExpand() != paramBoolean))
    {
      localCategory.setExpand(paramBoolean);
      B(localCategory);
      this.H.put(localCategory.getName(), Boolean.valueOf(paramBoolean));
      B();
    }
  }
  
  public void F()
  {
    Iterator localIterator = this.L.keySet().iterator();
    while (localIterator.hasNext())
    {
      Category localCategory = (Category)localIterator.next();
      if (localCategory.isExpand())
      {
        localCategory.setExpand(false);
        B(localCategory);
      }
      this.H.put(localCategory.getName(), Boolean.FALSE);
    }
    B();
  }
  
  public void I()
  {
    Iterator localIterator = this.L.keySet().iterator();
    while (localIterator.hasNext())
    {
      Category localCategory = (Category)localIterator.next();
      if (!localCategory.isExpand())
      {
        localCategory.setExpand(true);
        B(localCategory);
      }
      this.H.put(localCategory.getName(), Boolean.TRUE);
    }
    B();
  }
  
  public List A()
  {
    return this.B;
  }
  
  public Iterator K()
  {
    return this.K.getSelection();
  }
  
  public Element E()
  {
    return this.K.getLastSelectedElement();
  }
  
  class _A
  {
    Category C = null;
    _A A = null;
    Set B = null;
    Set D = null;
    Set E = null;
    
    public _A(Category paramCategory, _A param_A)
    {
      this.C = paramCategory;
      this.A = param_A;
      if (A.this.K.isSortingCategories())
      {
        if (A.this.K.getCategorySortingComparator() != null) {
          this.D = new TreeSet(new A._B(A.this, A.this.K.getCategorySortingComparator()));
        } else {
          this.D = new TreeSet(new A._B(A.this, Category.DISPLAYNAME_COMPARATOR));
        }
      }
      else {
        this.D = new LinkedHashSet();
      }
      if (A.this.K.isSortingProperties())
      {
        if (A.this.K.getPropertySortingComparator() != null) {
          this.E = new TreeSet(new A._B(A.this, A.this.K.getPropertySortingComparator()));
        } else {
          this.E = new TreeSet(new A._B(A.this, C.A));
        }
      }
      else {
        this.E = new LinkedHashSet();
      }
      if ((!A.this.K.isSortingCategories()) && (!A.this.K.isSortingProperties())) {
        this.B = new LinkedHashSet();
      }
    }
    
    public void A(Category paramCategory)
    {
      if (this.B != null) {
        this.B.add(paramCategory);
      } else {
        this.D.add(paramCategory);
      }
    }
    
    public void A(TPropertyDescriptor paramTPropertyDescriptor)
    {
      if (this.B != null) {
        this.B.add(paramTPropertyDescriptor);
      } else {
        this.E.add(paramTPropertyDescriptor);
      }
    }
    
    public void A()
    {
      if ((this.C != null) && (!A.this.C(this.C)))
      {
        A.this.B.add(this.C);
        if (!this.C.isExpand()) {
          return;
        }
      }
      if (this.B != null)
      {
        A(this.B);
      }
      else
      {
        A(this.D);
        A(this.E);
      }
    }
    
    private void A(Set paramSet)
    {
      Iterator localIterator = paramSet.iterator();
      while (localIterator.hasNext())
      {
        Object localObject1 = localIterator.next();
        Object localObject2;
        Object localObject3;
        if ((localObject1 instanceof Category))
        {
          localObject2 = (Category)localObject1;
          localObject3 = (_A)A.this.L.get(localObject2);
          ((_A)localObject3).A();
        }
        else
        {
          localObject2 = (TPropertyDescriptor)localObject1;
          localObject3 = ((TPropertyDescriptor)localObject2).getElementAttribute();
          A.this.B.add(localObject2);
          A.this.G.put(((ElementAttribute)localObject3).getKey(), TWaverUtil.valueOf(A.this.B.size() - 1));
        }
      }
    }
  }
  
  class _B
    implements Comparator
  {
    private Comparator A;
    
    public _B(Comparator paramComparator)
    {
      this.A = paramComparator;
    }
    
    public int compare(Object paramObject1, Object paramObject2)
    {
      if (A.this.K.isSortingAscending()) {
        return this.A.compare(paramObject1, paramObject2);
      }
      return -this.A.compare(paramObject1, paramObject2);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.A
 * JD-Core Version:    0.7.0.1
 */
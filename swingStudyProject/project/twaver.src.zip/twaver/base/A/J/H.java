package twaver.base.A.J;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import twaver.Element;
import twaver.Generator;
import twaver.TDataBox;
import twaver.table.TTableModel;
import twaver.table.TTreeTable;
import twaver.tree.TTree;

public class H
  extends TTree
  implements TableCellRenderer
{
  private TTreeTable ŕ;
  private int ŗ;
  private boolean Ŗ;
  private String Ř = null;
  
  public H(TTreeTable paramTTreeTable)
  {
    super(paramTTreeTable.getDataBox());
    this.ŕ = paramTTreeTable;
  }
  
  public void updateUI()
  {
    super.updateUI();
    if (this.ŕ != null) {
      this.ŕ.getTableModel().publishData();
    }
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    if (this.ŕ != null) {
      this.ŕ.repaint();
    }
  }
  
  public void setRowHeight(int paramInt)
  {
    if (paramInt > 0)
    {
      super.setRowHeight(paramInt);
      if ((this.ŕ != null) && (this.ŕ.getRowHeight() != paramInt)) {
        this.ŕ.setRowHeight(paramInt);
      }
    }
  }
  
  public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.ŕ == null)
    {
      super.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    else
    {
      paramInt4 = this.ŕ.getTree().getRowCount() * getRowHeight();
      super.setBounds(paramInt1, 0, paramInt3, paramInt4);
    }
  }
  
  public void paint(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    int i = this.ŗ * getRowHeight();
    localGraphics2D.translate(0, -i);
    super.paint(localGraphics2D);
    localGraphics2D.translate(0, i);
  }
  
  public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    this.Ŗ = paramBoolean1;
    this.Ř = null;
    Element localElement = this.ŕ.getElementByRowIndex(paramInt1);
    if (localElement != null)
    {
      this.ŗ = getRowForPath(getTreePathByElement(localElement));
      if ((this.ŕ.getTree().isElementToolTipDisplayable()) && (this.ŕ.getTree().getElementToolTipTextGenerator() != null)) {
        this.Ř = ((String)this.ŕ.getTree().getElementToolTipTextGenerator().generate(localElement));
      }
    }
    else
    {
      this.Ř = this.ŕ.getDataBox().getName();
      this.ŗ = (paramInt1 + this.ŕ.getTableModel().getFirstRowIndex());
    }
    if (paramBoolean1)
    {
      setBackground(paramJTable.getSelectionBackground());
      setForeground(paramJTable.getSelectionForeground());
    }
    else
    {
      setBackground(paramJTable.getBackground());
      setForeground(paramJTable.getForeground());
    }
    return this;
  }
  
  public String getToolTipText(MouseEvent paramMouseEvent)
  {
    return this.Ř;
  }
  
  protected Component getCursorComponent()
  {
    if (this.ŕ == null) {
      return this;
    }
    return this.ŕ;
  }
  
  public boolean Q()
  {
    return this.Ŗ;
  }
  
  public TTreeTable P()
  {
    return this.ŕ;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.H
 * JD-Core Version:    0.7.0.1
 */
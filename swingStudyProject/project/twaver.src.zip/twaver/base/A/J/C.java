package twaver.base.A.J;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.util.List;
import javax.swing.CellRendererPane;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import twaver.ElementAttribute;
import twaver.TWaverConst;
import twaver.TWaverUtil;
import twaver.table.TTable;
import twaver.table.TTableColumn;
import twaver.table.TTableModel;

public class C
  extends DefaultTableCellRenderer
{
  public static Icon B = twaver.base.A.E.C.E("/resource/image/table/ascend.png");
  public static Icon D = twaver.base.A.E.C.E("/resource/image/table/descend.png");
  private static final double A = 0.85D;
  private TTable E = null;
  private JLabel F = new JLabel();
  private CellRendererPane G;
  private _A C = new _A();
  
  public C(TTable paramTTable)
  {
    this.E = paramTTable;
    this.G = new CellRendererPane();
    add(this.G);
    setHorizontalAlignment(0);
    this.F.setIconTextGap(0);
    this.F.setBorder(null);
    Font localFont = paramTTable.getFont();
    if (localFont == null) {
      localFont = TWaverUtil.getFont(0, 9.0F);
    } else {
      localFont = localFont.deriveFont(localFont.getSize() - 3.0F);
    }
    this.F.setFont(localFont);
    this.F.setVerticalAlignment(0);
    this.F.setHorizontalAlignment(0);
    this.F.setHorizontalTextPosition(0);
  }
  
  public Color A(Color paramColor)
  {
    return new Color(Math.max((int)(paramColor.getRed() * 0.85D), 0), Math.max((int)(paramColor.getGreen() * 0.85D), 0), Math.max((int)(paramColor.getBlue() * 0.85D), 0));
  }
  
  public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    JLabel localJLabel = (JLabel)super.getTableCellRendererComponent(paramJTable, null, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
    localJLabel.setToolTipText(null);
    setBorder(new _A());
    localJLabel.setBorder(this.C);
    this.F.setText(null);
    localJLabel.setIcon(null);
    TTableColumn localTTableColumn = null;
    if (paramJTable != null)
    {
      JTableHeader localJTableHeader = paramJTable.getTableHeader();
      if (localJTableHeader != null)
      {
        localJLabel.setForeground(localJTableHeader.getForeground());
        localJLabel.setBackground(localJTableHeader.getBackground());
        localJLabel.setFont(localJTableHeader.getFont());
        int i = paramJTable.getColumnModel().getColumn(paramInt2).getModelIndex();
        localTTableColumn = this.E.getTableModel().getPublishedColumn(i);
        if ((!localTTableColumn.isSortable()) && (this.E.isDistinctSortableHeader())) {
          localJLabel.setBackground(A(localJLabel.getBackground()));
        }
        if (localTTableColumn.getSortMode() == 1) {
          this.F.setIcon(B);
        } else if (localTTableColumn.getSortMode() == -1) {
          this.F.setIcon(D);
        } else {
          this.F.setIcon(null);
        }
        String str = localTTableColumn.getDisplayName();
        if ((str == null) || ("".equals(str))) {
          localJLabel.setText(" ");
        } else {
          localJLabel.setText(str);
        }
        localJLabel.setToolTipText(str);
        List localList = this.E.getTableModel().getSortColumnList();
        if ((localList.size() > 1) && (localList.contains(localTTableColumn)))
        {
          int j = localList.indexOf(localTTableColumn) + 1;
          this.F.setText(j);
        }
        if (this.E.isShowTableHeaderIcon()) {
          localJLabel.setIcon(localTTableColumn.getIcon());
        }
        if (localTTableColumn.getHeaderRenderer() == null) {
          localTTableColumn.setHeaderRenderer(this);
        }
        if (localTTableColumn.getElementAttribute() != null) {
          setToolTipText(localTTableColumn.getElementAttribute().getDescription());
        }
      }
    }
    if (this.F.getText() == null) {
      this.F.setVerticalTextPosition(0);
    } else {
      this.F.setVerticalTextPosition(3);
    }
    if (localTTableColumn != null) {
      this.E.prepareTableHeaderRenderer(this, localTTableColumn);
    }
    return this;
  }
  
  class _A
    implements Border
  {
    _A() {}
    
    public Insets getBorderInsets(Component paramComponent)
    {
      if (C.this.F.getIcon() == null) {
        return TWaverConst.THIN_INSETS;
      }
      return new Insets(1, 1, 1, C.this.F.getPreferredSize().width);
    }
    
    public void paintBorder(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      Border localBorder = UIManager.getBorder("TableHeader.cellBorder");
      if (localBorder != null) {
        localBorder.paintBorder(paramComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
      }
      if (C.this.F.getIcon() != null)
      {
        Dimension localDimension = C.this.F.getPreferredSize();
        int i = C.this.F.getText() == null ? 0 : 1;
        C.this.G.paintComponent(paramGraphics, C.this.F, C.this, C.this.getWidth() - localDimension.width - 2, paramInt2 + (paramInt4 - localDimension.height) / 2 + i, localDimension.width, localDimension.height);
      }
    }
    
    public boolean isBorderOpaque()
    {
      return true;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.C
 * JD-Core Version:    0.7.0.1
 */
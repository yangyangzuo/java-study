package twaver.base.A.J;

import java.awt.Component;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import twaver.base.A.I.D;

public class I
  extends DefaultTableCellRenderer
{
  private D A;
  
  public I(D paramD)
  {
    this.A = paramD;
    setHorizontalAlignment(0);
  }
  
  public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    if (paramJTable != null)
    {
      JTableHeader localJTableHeader = paramJTable.getTableHeader();
      if (localJTableHeader != null)
      {
        setForeground(localJTableHeader.getForeground());
        setBackground(localJTableHeader.getBackground());
        setFont(localJTableHeader.getFont());
      }
    }
    setText(paramObject == null ? "" : paramObject.toString());
    setBorder(UIManager.getBorder("TableHeader.cellBorder"));
    if ((paramInt2 == 0) && (this.A.isSortingProperties()))
    {
      if (this.A.isSortingAscending()) {
        setIcon(C.B);
      } else {
        setIcon(C.D);
      }
    }
    else {
      setIcon(null);
    }
    return this;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.I
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.J;

import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import twaver.table.TTable;
import twaver.table.TTableColumn;
import twaver.table.TTableModel;
import twaver.table.TTreeTable;

public class B
  extends DefaultTableColumnModel
{
  private TTable A = null;
  
  public B(TTable paramTTable)
  {
    this.A = paramTTable;
  }
  
  public void addColumn(TableColumn paramTableColumn)
  {
    if (this.A.getTableModel().isInitingColumn()) {
      super.addColumn(paramTableColumn);
    } else {
      this.A.getTableModel().addColumn(paramTableColumn);
    }
  }
  
  public void removeColumn(TableColumn paramTableColumn)
  {
    if (this.A.getTableModel().isInitingColumn()) {
      super.removeColumn(paramTableColumn);
    } else {
      this.A.getTableModel().removeColumn(paramTableColumn);
    }
  }
  
  public void moveColumn(int paramInt1, int paramInt2)
  {
    JTableHeader localJTableHeader = this.A.getTableHeader();
    if (((this.A instanceof TTreeTable)) && (localJTableHeader != null) && (!((TTreeTable)this.A).isTreeColumnMovable()))
    {
      TTableColumn localTTableColumn = (TTableColumn)getColumn(paramInt1);
      if ("table.column.tree".equals(localTTableColumn.getName()))
      {
        localJTableHeader.setDraggedColumn(null);
        localJTableHeader.repaint();
        this.A.repaint();
        return;
      }
      localTTableColumn = (TTableColumn)getColumn(paramInt2);
      if ("table.column.tree".equals(localTTableColumn.getName()))
      {
        localJTableHeader.setDraggedColumn(null);
        localJTableHeader.repaint();
        this.A.repaint();
        return;
      }
    }
    super.moveColumn(paramInt1, paramInt2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.J.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class I
  implements F
{
  public void A(Attributes paramAttributes)
    throws SAXException
  {}
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {}
  
  public void A(String paramString)
    throws SAXException
  {}
  
  public void A()
    throws SAXException
  {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.I
 * JD-Core Version:    0.7.0.1
 */
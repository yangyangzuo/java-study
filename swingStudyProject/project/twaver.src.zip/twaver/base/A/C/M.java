package twaver.base.A.C;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TWaverUtil;
import twaver.base.A.E.H;
import twaver.base.A.F.A.A;
import twaver.table.TTableColumn;

public class M
  extends I
{
  private String M;
  private List N;
  private Map L = new HashMap();
  private static final M K = new M();
  
  public static M J()
  {
    return K;
  }
  
  public List B(String paramString)
  {
    return (List)this.L.get(paramString);
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    if (paramString.equals("table"))
    {
      this.M = paramAttributes.getValue("name");
      this.N = new ArrayList();
      this.L.put(this.M, this.N);
    }
    else
    {
      String str1 = paramAttributes.getValue("name");
      String str2 = paramAttributes.getValue("displayName");
      String str3 = paramAttributes.getValue("sortComparator");
      Comparator localComparator = null;
      if ((str3 != null) && (!str3.trim().equals(""))) {
        try
        {
          localComparator = (Comparator)H.A(str3).newInstance();
        }
        catch (Exception localException1)
        {
          TWaverUtil.handleError(null, localException1);
        }
      } else {
        localComparator = A.A();
      }
      String str4 = paramAttributes.getValue("renderer");
      Class localClass1 = null;
      if ((str4 != null) && (!str4.trim().equals(""))) {
        localClass1 = H.A(str4, "twaver.table.renderer");
      }
      TableCellRenderer localTableCellRenderer = null;
      if (localClass1 != null) {
        try
        {
          localTableCellRenderer = (TableCellRenderer)localClass1.newInstance();
        }
        catch (Exception localException2)
        {
          TWaverUtil.handleError(null, localException2);
        }
      }
      boolean bool1 = TWaverUtil.stringToBoolean(paramAttributes.getValue("editable")).booleanValue();
      TableCellEditor localTableCellEditor = null;
      Class localClass2 = null;
      String str5 = paramAttributes.getValue("editor");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        localClass2 = H.A(str5, "twaver.table.editor");
      }
      if (localClass2 != null) {
        try
        {
          localTableCellEditor = (TableCellEditor)localClass2.newInstance();
        }
        catch (Exception localException3)
        {
          TWaverUtil.handleError(null, localException3);
        }
      }
      boolean bool2 = true;
      str5 = paramAttributes.getValue("visible");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        bool2 = TWaverUtil.stringToBoolean(str5).booleanValue();
      }
      int i = 75;
      str5 = paramAttributes.getValue("width");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        i = Integer.parseInt(str5);
      }
      Class localClass3 = null;
      str5 = paramAttributes.getValue("javaClass");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        try
        {
          localClass3 = H.A(str5);
        }
        catch (Exception localException4)
        {
          TWaverUtil.handleError(null, localException4);
        }
      }
      TTableColumn localTTableColumn = new TTableColumn(str1, str2, localComparator, localTableCellRenderer, bool1, localTableCellEditor, bool2, i, localClass3);
      str5 = paramAttributes.getValue("rowPackParticipable");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        localTTableColumn.setRowPackParticipable(TWaverUtil.stringToBoolean(str5).booleanValue());
      }
      str5 = paramAttributes.getValue("extraWidthAssignable");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        localTTableColumn.setExtraWidthAssignable(TWaverUtil.stringToBoolean(str5).booleanValue());
      }
      str5 = paramAttributes.getValue("minPackWidth");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        localTTableColumn.setMinPackWidth(Integer.parseInt(str5));
      }
      str5 = paramAttributes.getValue("maxPackWidth");
      if ((str5 != null) && (!str5.trim().equals(""))) {
        localTTableColumn.setMaxPackWidth(Integer.parseInt(str5));
      }
      this.N.add(localTTableColumn);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.M
 * JD-Core Version:    0.7.0.1
 */
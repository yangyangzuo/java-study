package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.AlarmSeverity;
import twaver.TWaverUtil;

public class H
  extends I
{
  private static final H E = new H();
  
  public static H F()
  {
    return E;
  }
  
  public void A(Attributes paramAttributes)
    throws SAXException
  {}
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    AlarmSeverity.registerAlarmSeverity(paramAttributes.getValue("name"), paramAttributes.getValue("nickName"), Integer.parseInt(paramAttributes.getValue("value")), TWaverUtil.stringToColor(paramAttributes.getValue("color")), paramAttributes.getValue("displayName"));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.H
 * JD-Core Version:    0.7.0.1
 */
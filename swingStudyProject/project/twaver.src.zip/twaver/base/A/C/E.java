package twaver.base.A.C;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import twaver.TWaverUtil;

public class E
  extends DefaultHandler
{
  private String D;
  private Map B = new HashMap();
  private int C = 0;
  private static final E A = new E();
  
  public static E B()
  {
    return A;
  }
  
  private E()
  {
    A("alarm", H.F());
    A("propertysheet", C.C());
    A("uidefault", G.E());
    A("toolbars", K.H());
    A("iconattachments", L.I());
    A("tables", M.J());
    A("tablecelleditor", J.G());
    A("tablecellrenderer", D.D());
    A("elementicon", B.B());
    A("elementimage", A.K());
  }
  
  private void A(String paramString, F paramF)
  {
    this.B.put(paramString, paramF);
  }
  
  public synchronized void A()
  {
    try
    {
      if (TWaverUtil.getResourceAgentURL() == null) {
        return;
      }
      InputStream localInputStream = twaver.base.A.E.C.A(TWaverUtil.getResourceAgentURL() + "TWaver.xml", TWaverUtil.class, false);
      if (localInputStream == null) {
        return;
      }
      SAXParserFactory localSAXParserFactory = SAXParserFactory.newInstance();
      SAXParser localSAXParser = localSAXParserFactory.newSAXParser();
      XMLReader localXMLReader = localSAXParser.getXMLReader();
      localXMLReader.setContentHandler(A);
      localXMLReader.parse(new InputSource(localInputStream));
    }
    catch (Exception localException)
    {
      TWaverUtil.handleError(null, localException);
    }
  }
  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes)
    throws SAXException
  {
    if (paramString3.equals("twaver")) {
      return;
    }
    F localF;
    if (this.D == null)
    {
      localF = (F)this.B.get(paramString3);
      if (localF != null)
      {
        localF.A(paramAttributes);
        this.D = paramString3;
      }
      else
      {
        throw new SAXException("can't find config for name '" + paramString3 + "' ");
      }
    }
    else
    {
      if (this.D.equals(paramString3)) {
        this.C += 1;
      }
      localF = (F)this.B.get(this.D);
      try
      {
        localF.A(paramString3, paramAttributes);
      }
      catch (Exception localException)
      {
        TWaverUtil.handleError("config '" + paramString3 + "' in '" + this.D + "' error", localException);
      }
    }
  }
  
  public void endElement(String paramString1, String paramString2, String paramString3)
    throws SAXException
  {
    F localF = (F)this.B.get(this.D);
    if (paramString3.equals(this.D))
    {
      if (this.C == 0)
      {
        localF.A();
        this.D = null;
        return;
      }
      this.C -= 1;
    }
    if (localF != null) {
      localF.A(paramString3);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.E
 * JD-Core Version:    0.7.0.1
 */
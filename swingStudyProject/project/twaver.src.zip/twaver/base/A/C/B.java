package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TUIManager;
import twaver.base.A.E.H;

public class B
  extends I
{
  private static final B A = new B();
  
  public static B B()
  {
    return A;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("elementClass");
    String str2 = paramAttributes.getValue("iconURL");
    Class localClass = H.A(str1, "twaver.");
    if (localClass != null) {
      TUIManager.registerIcon(localClass, str2);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TUIManager;
import twaver.base.A.E.H;

public class D
  extends I
{
  private static final D C = new D();
  
  public static D D()
  {
    return C;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("valueClass");
    String str2 = paramAttributes.getValue("rendererClass");
    Class localClass1 = H.A(str1, null);
    Class localClass2 = H.A(str2, "twaver.table.renderer");
    if (localClass1 != null) {
      TUIManager.registerTableCellRenderer(localClass1, localClass2);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.D
 * JD-Core Version:    0.7.0.1
 */
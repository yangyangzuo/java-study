package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.network.ui.IconAttachmentHolder;

public class L
  extends I
{
  private static final L J = new L();
  
  public static L I()
  {
    return J;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("name");
    String str2 = paramAttributes.getValue("iconurl");
    IconAttachmentHolder.addAttachment(str1, str2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.L
 * JD-Core Version:    0.7.0.1
 */
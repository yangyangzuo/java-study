package twaver.base.A.C;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.base.A.E.H;
import twaver.network.NetworkToolBarFactory;

public class K
  extends I
{
  private String H = null;
  private List I = null;
  private static final K G = new K();
  
  public static K H()
  {
    return G;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    if (paramString.equals("toolbar"))
    {
      this.H = paramAttributes.getValue("name");
      this.I = new ArrayList();
    }
    else if (paramString.equals("button"))
    {
      if (this.H == null) {
        B(paramAttributes);
      } else {
        this.I.add(paramAttributes.getValue("id"));
      }
    }
    else if (paramString.equals("toolbar-button"))
    {
      this.I.add(paramAttributes.getValue("id"));
    }
  }
  
  public void A(String paramString)
    throws SAXException
  {
    if (paramString.equals("toolbar"))
    {
      NetworkToolBarFactory.registerToolbar(this.H, this.I);
      this.H = null;
      this.I = null;
    }
  }
  
  public void B(Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("id");
    String str2 = paramAttributes.getValue("class");
    Class localClass = H.A(str2, "twaver.network.toolbar");
    NetworkToolBarFactory.registerButton(str1, localClass);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.K
 * JD-Core Version:    0.7.0.1
 */
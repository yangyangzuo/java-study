package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TUIManager;
import twaver.TWaverUtil;

class G
  extends I
{
  private static final G D = new G();
  
  public static G E()
  {
    return D;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("key");
    String str2 = paramAttributes.getValue("value");
    Object localObject = TUIManager.get(str1);
    if (localObject == null) {
      TUIManager.registerDefault(str1, str2);
    } else {
      TUIManager.registerDefault(str1, TWaverUtil.stringToObject(str2, localObject.getClass()));
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.G
 * JD-Core Version:    0.7.0.1
 */
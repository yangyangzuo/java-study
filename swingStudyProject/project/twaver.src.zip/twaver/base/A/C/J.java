package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TUIManager;
import twaver.base.A.E.H;

public class J
  extends I
{
  private static final J F = new J();
  
  public static J G()
  {
    return F;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    String str1 = paramAttributes.getValue("valueClass");
    String str2 = paramAttributes.getValue("editorClass");
    Class localClass = H.A(str1, null);
    TUIManager.registerTableCellEditor(localClass, str2);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.J
 * JD-Core Version:    0.7.0.1
 */
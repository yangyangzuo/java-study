package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import twaver.TWaverUtil;
import twaver.table.Category;

class C
  extends I
{
  private static final C B = new C();
  
  public static C C()
  {
    return B;
  }
  
  public void A(String paramString, Attributes paramAttributes)
    throws SAXException
  {
    Category.registerCategory(paramAttributes.getValue("name"), paramAttributes.getValue("displayName"), paramAttributes.getValue("description"), TWaverUtil.stringToBoolean(paramAttributes.getValue("isExpend")).booleanValue());
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.C
 * JD-Core Version:    0.7.0.1
 */
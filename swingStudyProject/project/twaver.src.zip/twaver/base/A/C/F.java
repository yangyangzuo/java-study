package twaver.base.A.C;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public abstract interface F
{
  public abstract void A(Attributes paramAttributes)
    throws SAXException;
  
  public abstract void A(String paramString, Attributes paramAttributes)
    throws SAXException;
  
  public abstract void A(String paramString)
    throws SAXException;
  
  public abstract void A()
    throws SAXException;
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.C.F
 * JD-Core Version:    0.7.0.1
 */
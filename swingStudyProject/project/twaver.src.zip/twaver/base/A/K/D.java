package twaver.base.A.K;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.tree.TreeCellRenderer;
import twaver.Element;
import twaver.TWaverConst;
import twaver.base.A.E.g;
import twaver.base.A.J.H;
import twaver.swing.TTristateCheckBox;
import twaver.table.TTreeTable;
import twaver.tree.DataBoxNode;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public class D
  extends JComponent
  implements TreeCellRenderer
{
  C E;
  private TTristateCheckBox C;
  private _A D;
  private TTree A;
  private _A B;
  
  public void updateUI()
  {
    super.updateUI();
    this.C.updateUI();
    this.D.updateUI();
    this.B.updateUI();
  }
  
  public D(TTree paramTTree)
  {
    setLayout(null);
    this.A = paramTTree;
    this.E = new C(paramTTree);
    this.B = new _A();
    this.C = new TTristateCheckBox();
    this.D = new _A();
    add(this.C);
    add(this.D);
    this.C.setMargin(new Insets(0, 0, 0, 0));
  }
  
  public Component getTreeCellRendererComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt, boolean paramBoolean4)
  {
    paramBoolean4 = false;
    this.C.setCheckedWhenNotSpecified(this.A.isCheckedWhenNotSpecified());
    this.C.setBackground(UIManager.getColor("Tree.textBackground"));
    _A local_A = null;
    Object localObject = null;
    Element localElement = null;
    if ((paramObject instanceof ElementNode))
    {
      localElement = ((ElementNode)paramObject).getElement();
      paramBoolean1 = localElement.isSelected();
      boolean bool = this.A.isCheckable(localElement);
      int i = this.A.getUncheckableStyle(localElement);
      if ((!bool) && (i == 1)) {
        return this.E.getTreeCellRendererComponent(paramJTree, paramObject, paramBoolean1, paramBoolean2, paramBoolean3, paramInt, paramBoolean4);
      }
      g.A(this.A, localElement, this.D);
      local_A = this.D;
      setToolTipText(this.D.getToolTipText());
      localObject = this;
      if ((!bool) && (i == 2)) {
        this.C.setBlank(true);
      } else {
        this.C.setBlank(false);
      }
      if (!paramJTree.isEnabled()) {
        this.C.setEnabled(false);
      } else if ((!bool) && (i == 3)) {
        this.C.setEnabled(false);
      } else {
        this.C.setEnabled(true);
      }
      this.C.setState(this.A.getTristate(localElement));
    }
    else if ((paramObject instanceof DataBoxNode))
    {
      g.A(this.A, this.B);
      local_A = this.B;
      localObject = this.B;
    }
    setEnabled(paramJTree.isEnabled());
    local_A.setEnabled(paramJTree.isEnabled());
    local_A.setFont(paramJTree.getFont());
    local_A.C(paramBoolean4);
    if (!this.A.isPaintSelectedStateWhenChecked()) {
      paramBoolean1 = false;
    }
    local_A.B(paramBoolean1);
    if (paramBoolean1) {
      local_A.setForeground(UIManager.getColor("Tree.selectionForeground"));
    } else {
      local_A.setForeground(UIManager.getColor("Tree.textForeground"));
    }
    local_A.A(this.A.isDnDTarget(paramObject));
    if ((paramJTree instanceof H))
    {
      local_A.setOpaque(true);
      local_A.setBackground(paramJTree.getBackground());
      local_A.setForeground(paramJTree.getForeground());
      this.C.setOpaque(true);
      this.C.setBackground(paramJTree.getBackground());
      this.C.setForeground(paramJTree.getForeground());
      if (((H)paramJTree).P() != null) {
        ((H)paramJTree).P().prepareTreeColumnRenderer(local_A, localElement);
      }
    }
    this.A.prepareRenderer(local_A, localElement);
    return localObject;
  }
  
  public Dimension getPreferredSize()
  {
    Dimension localDimension1 = this.C.getPreferredSize();
    Dimension localDimension2 = this.D.getPreferredSize();
    return new Dimension(localDimension1.width + localDimension2.width, localDimension1.height < localDimension2.height ? localDimension2.height : localDimension1.height);
  }
  
  public void doLayout()
  {
    Dimension localDimension1 = this.C.getPreferredSize();
    Dimension localDimension2 = this.D.getPreferredSize();
    int i = 0;
    int j = 0;
    if (localDimension1.height < localDimension2.height) {
      i = (localDimension2.height - localDimension1.height) / 2;
    } else {
      j = (localDimension1.height - localDimension2.height) / 2;
    }
    this.C.setLocation(0, i);
    this.C.setBounds(0, i, localDimension1.width, localDimension1.height);
    this.D.setLocation(localDimension1.width, j);
    this.D.setBounds(localDimension1.width, j, localDimension2.width, localDimension2.height);
  }
  
  public void setBackground(Color paramColor)
  {
    if ((paramColor instanceof ColorUIResource)) {
      paramColor = null;
    }
    super.setBackground(paramColor);
  }
  
  class _A
    extends JLabel
  {
    boolean A = false;
    boolean C = false;
    boolean B = false;
    
    _A() {}
    
    public void setBackground(Color paramColor)
    {
      if ((paramColor instanceof ColorUIResource)) {
        paramColor = null;
      }
      super.setBackground(paramColor);
    }
    
    public void A(boolean paramBoolean)
    {
      this.B = paramBoolean;
    }
    
    public void paint(Graphics paramGraphics)
    {
      String str;
      if (((str = getText()) != null) && (str.length() > 0))
      {
        if (this.A) {
          paramGraphics.setColor(UIManager.getColor("Tree.selectionBackground"));
        } else {
          paramGraphics.setColor(UIManager.getColor("Tree.textBackground"));
        }
        Dimension localDimension = getPreferredSize();
        int i = 0;
        Icon localIcon = getIcon();
        if (localIcon != null) {
          i = localIcon.getIconWidth() + Math.max(0, getIconTextGap() - 1);
        }
        paramGraphics.fillRect(i, 0, localDimension.width - 1 - i, localDimension.height);
        if (this.C)
        {
          paramGraphics.setColor(UIManager.getColor("Tree.selectionBorderColor"));
          paramGraphics.drawRect(i, 0, localDimension.width - 1 - i, localDimension.height - 1);
        }
        if (this.B)
        {
          paramGraphics.setColor(TWaverConst.DND_TARGET_COLOR);
          paramGraphics.drawRect(i, 0, getWidth() - 1 - i, getHeight() - 1);
        }
      }
      super.paint(paramGraphics);
    }
    
    public Dimension getPreferredSize()
    {
      Dimension localDimension = super.getPreferredSize();
      if (localDimension != null) {
        localDimension = new Dimension(localDimension.width + 3, localDimension.height);
      }
      return localDimension;
    }
    
    void B(boolean paramBoolean)
    {
      this.A = paramBoolean;
    }
    
    void C(boolean paramBoolean)
    {
      this.C = paramBoolean;
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.K.D
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.K;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.tree.DefaultTreeSelectionModel;
import javax.swing.tree.TreePath;
import twaver.DataBoxSelectionModel;
import twaver.Element;
import twaver.TDataBox;
import twaver.base.A.E.V;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public class B
  extends DefaultTreeSelectionModel
{
  private TTree A = null;
  
  public B(TTree paramTTree)
  {
    this.A = paramTTree;
  }
  
  public void A(TreePath[] paramArrayOfTreePath)
  {
    super.setSelectionPaths(paramArrayOfTreePath);
  }
  
  public void setSelectionPaths(TreePath[] paramArrayOfTreePath)
  {
    if ((paramArrayOfTreePath == null) || (paramArrayOfTreePath.length == 0)) {
      return;
    }
    int i = this.A.getTTreeSelectionMode();
    if (i != 0)
    {
      if (paramArrayOfTreePath.length != 1) {
        return;
      }
      TreePath localTreePath = paramArrayOfTreePath[0];
      Object localObject = localTreePath.getLastPathComponent();
      if ((localObject != null) && ((localObject instanceof ElementNode)))
      {
        Element localElement = ((ElementNode)localObject).getElement();
        if (this.A.isCheckable(localElement))
        {
          boolean bool = isPathSelected(localTreePath);
          A(i, localElement, !bool);
        }
      }
    }
    else
    {
      super.setSelectionPaths(paramArrayOfTreePath);
    }
  }
  
  private void A(int paramInt, Element paramElement, boolean paramBoolean)
  {
    LinkedList localLinkedList = new LinkedList();
    if (paramInt == 1)
    {
      localLinkedList.add(paramElement);
    }
    else if (paramInt == 2)
    {
      localLinkedList.add(paramElement);
      localLinkedList.addAll(paramElement.getChildren());
    }
    else if (paramInt == 3)
    {
      localLinkedList.add(paramElement);
      V.A(paramElement, localLinkedList);
    }
    else if (paramInt == 4)
    {
      localLinkedList.add(paramElement);
      V.A(paramElement, localLinkedList);
      if (paramBoolean) {
        V.B(paramElement, localLinkedList);
      }
    }
    Iterator localIterator = localLinkedList.iterator();
    while (localIterator.hasNext())
    {
      paramElement = (Element)localIterator.next();
      if ((!this.A.isVisible(paramElement)) || (!this.A.isCheckable(paramElement))) {
        localIterator.remove();
      }
    }
    if (paramBoolean) {
      this.A.getDataBox().getSelectionModel().appendSelection(localLinkedList);
    } else {
      this.A.getDataBox().getSelectionModel().removeSelection(localLinkedList);
    }
    if (this.A.isEnableTristateCheckBox()) {
      this.A.repaint();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.K.B
 * JD-Core Version:    0.7.0.1
 */
package twaver.base.A.K;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultCellEditor.EditorDelegate;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.TreePath;
import twaver.EditableFilter;
import twaver.Element;
import twaver.Generator;
import twaver.TDataBox;
import twaver.tree.DataBoxNode;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public class A
  extends DefaultCellEditor
{
  private TTree A = null;
  
  public A(TTree paramTTree)
  {
    super(new JTextField());
    this.A = paramTTree;
    JTextField localJTextField = (JTextField)getComponent();
    localJTextField.addFocusListener(new FocusAdapter()
    {
      private final TTree val$tree;
      
      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        if (this.val$tree.isEditing()) {
          this.val$tree.stopEditing();
        }
      }
    });
    localJTextField.addKeyListener(new KeyAdapter()
    {
      private final JTextField val$textField;
      
      public void keyTyped(KeyEvent paramAnonymousKeyEvent)
      {
        A();
      }
      
      public void keyReleased(KeyEvent paramAnonymousKeyEvent)
      {
        A();
      }
      
      private void A()
      {
        Dimension localDimension = this.val$textField.getPreferredSize();
        int i = Math.max(20, localDimension.width);
        this.val$textField.setBounds(this.val$textField.getX(), this.val$textField.getY(), i, this.val$textField.getHeight());
      }
    });
  }
  
  public boolean isCellEditable(EventObject paramEventObject)
  {
    if ((paramEventObject instanceof MouseEvent))
    {
      MouseEvent localMouseEvent = (MouseEvent)paramEventObject;
      if (localMouseEvent.getClickCount() >= 2)
      {
        EditableFilter localEditableFilter = this.A.getElementLabelEditableFilter();
        if (localEditableFilter == null) {
          return false;
        }
        TreePath localTreePath = this.A.getPathForLocation(localMouseEvent.getX(), localMouseEvent.getY());
        if (localTreePath != null)
        {
          Object localObject = localTreePath.getLastPathComponent();
          if ((localObject instanceof ElementNode)) {
            return localEditableFilter.isEditable(((ElementNode)localObject).getElement());
          }
          if ((localObject instanceof DataBoxNode)) {
            return this.A.isDataBoxLabelEditable();
          }
        }
      }
      return false;
    }
    return true;
  }
  
  public Component getTreeCellEditorComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt)
  {
    if ((paramObject instanceof ElementNode))
    {
      Element localElement = ((ElementNode)paramObject).getElement();
      Object localObject = ((TTree)paramJTree).getElementLabelGenerator().generate(localElement);
      this.delegate.setValue(localObject);
    }
    else if ((paramObject instanceof DataBoxNode))
    {
      this.delegate.setValue(this.A.getDataBox().getName());
    }
    return this.editorComponent;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.K.A
 * JD-Core Version:    0.7.0.1
 */
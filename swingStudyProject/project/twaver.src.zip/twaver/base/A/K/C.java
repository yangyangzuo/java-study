package twaver.base.A.K;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.DefaultTreeCellRenderer;
import twaver.Element;
import twaver.TWaverConst;
import twaver.base.A.E.g;
import twaver.base.A.J.H;
import twaver.table.TTreeTable;
import twaver.tree.DataBoxNode;
import twaver.tree.ElementNode;
import twaver.tree.TTree;

public class C
  extends DefaultTreeCellRenderer
{
  private TTree A = null;
  private boolean B = false;
  
  public C(TTree paramTTree)
  {
    this.A = paramTTree;
  }
  
  public Component getTreeCellRendererComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt, boolean paramBoolean4)
  {
    setTextSelectionColor(UIManager.getColor("Tree.selectionForeground"));
    setTextNonSelectionColor(UIManager.getColor("Tree.textForeground"));
    setBackgroundSelectionColor(UIManager.getColor("Tree.selectionBackground"));
    setBackgroundNonSelectionColor(UIManager.getColor("Tree.textBackground"));
    setBorderSelectionColor(UIManager.getColor("Tree.selectionBorderColor"));
    Element localElement = null;
    if ((paramObject instanceof ElementNode))
    {
      localElement = ((ElementNode)paramObject).getElement();
      if (g.F(this.A, localElement))
      {
        if ((this.A.isAutoSyncSelectionFromDataBoxToView()) && (this.A.isAutoSyncSelectionFromViewToDataBox())) {
          paramBoolean1 = localElement.isSelected();
        }
      }
      else
      {
        paramBoolean1 = false;
        paramBoolean4 = false;
      }
    }
    if ((paramBoolean4) && (!paramBoolean1)) {
      paramBoolean4 = false;
    }
    super.getTreeCellRendererComponent(paramJTree, paramObject, paramBoolean1, paramBoolean2, paramBoolean3, paramInt, paramBoolean4);
    if ((paramObject instanceof ElementNode)) {
      g.A(this.A, localElement, this);
    } else if ((paramObject instanceof DataBoxNode)) {
      g.A(this.A, this);
    }
    this.B = this.A.isDnDTarget(paramObject);
    if ((paramJTree instanceof H))
    {
      setOpaque(true);
      setBackground(paramJTree.getBackground());
      setForeground(paramJTree.getForeground());
      if (((H)paramJTree).P() != null) {
        ((H)paramJTree).P().prepareTreeColumnRenderer(this, localElement);
      }
    }
    this.A.prepareRenderer(this, localElement);
    return this;
  }
  
  public void paintComponent(Graphics paramGraphics)
  {
    super.paintComponent(paramGraphics);
    if (this.B)
    {
      paramGraphics.setColor(TWaverConst.DND_TARGET_COLOR);
      int i = A();
      paramGraphics.drawRect(i, 0, getWidth() - 1 - i, getHeight() - 1);
    }
  }
  
  private int A()
  {
    Icon localIcon = getIcon();
    if ((localIcon != null) && (getText() != null)) {
      return localIcon.getIconWidth() + Math.max(0, getIconTextGap() - 1);
    }
    return 0;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.A.K.C
 * JD-Core Version:    0.7.0.1
 */
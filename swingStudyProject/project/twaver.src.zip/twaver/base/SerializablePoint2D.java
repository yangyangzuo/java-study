package twaver.base;

import java.awt.geom.Point2D.Double;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializablePoint2D
  extends Point2D.Double
  implements Serializable
{
  public SerializablePoint2D() {}
  
  public SerializablePoint2D(double x, double y)
  {
    super(x, y);
  }
  
  public String toString()
  {
    return "SerializablePoint2D[" + this.x + ", " + this.y + "]";
  }
  
  private void writeObject(ObjectOutputStream s)
    throws IOException
  {
    s.writeDouble(this.x);
    s.writeDouble(this.y);
  }
  
  private void readObject(ObjectInputStream s)
    throws ClassNotFoundException, IOException
  {
    this.x = s.readDouble();
    this.y = s.readDouble();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.SerializablePoint2D
 * JD-Core Version:    0.7.0.1
 */
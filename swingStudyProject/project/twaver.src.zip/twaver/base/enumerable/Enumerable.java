package twaver.base.enumerable;

import java.io.Serializable;

public abstract interface Enumerable
  extends Serializable
{
  public abstract String getName();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.enumerable.Enumerable
 * JD-Core Version:    0.7.0.1
 */
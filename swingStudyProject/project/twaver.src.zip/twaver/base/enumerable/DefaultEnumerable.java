package twaver.base.enumerable;

import java.io.Serializable;
import twaver.TWaverUtil;

public class DefaultEnumerable
  implements Enumerable, Comparable, Serializable
{
  private final String C;
  
  public DefaultEnumerable(String name)
  {
    this.C = name;
    EnumerableManager.registerEnumerable(this);
  }
  
  public String getName()
  {
    return this.C;
  }
  
  public String toString()
  {
    return this.C;
  }
  
  public boolean equals(Object object)
  {
    if ((object instanceof Enumerable))
    {
      Enumerable enumerable = (Enumerable)object;
      return this.C.equals(enumerable.getName());
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.C.hashCode();
  }
  
  public int compareTo(Object object)
  {
    if ((object instanceof Enumerable))
    {
      Enumerable enumerable = (Enumerable)object;
      return TWaverUtil.compare(this.C, enumerable.getName());
    }
    return -1;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.enumerable.DefaultEnumerable
 * JD-Core Version:    0.7.0.1
 */
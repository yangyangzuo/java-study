package twaver.base.enumerable;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class EnumerableManager
{
  private static final Map A = new HashMap();
  
  protected static void registerEnumerable(Enumerable enumerable)
  {
    if (enumerable == null) {
      throw new IllegalArgumentException("enumerable should not be null.");
    }
    Class enumerableClass = enumerable.getClass();
    A enumerableInfo = (A)A.get(enumerableClass);
    if (enumerableInfo == null)
    {
      enumerableInfo = new A(enumerableClass);
      A.put(enumerableClass, enumerableInfo);
    }
    enumerableInfo.A(enumerable);
  }
  
  public static Enumerable getEnumerable(Class enumerableClass, String name)
  {
    A enumerableInfo = (A)A.get(enumerableClass);
    if (enumerableInfo != null) {
      return enumerableInfo.A(name);
    }
    return null;
  }
  
  public static Vector getEnumerables(Class enumerableClass)
  {
    A enumerableInfo = (A)A.get(enumerableClass);
    if (enumerableInfo != null) {
      return enumerableInfo.A();
    }
    return null;
  }
  
  public static Map getAllEnumerableMapper()
  {
    return A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.enumerable.EnumerableManager
 * JD-Core Version:    0.7.0.1
 */
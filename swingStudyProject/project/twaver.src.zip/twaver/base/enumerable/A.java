package twaver.base.enumerable;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

class A
{
  private final Class B;
  private final Vector A;
  private final Map C;
  
  protected A(Class enumerableClass)
  {
    if (enumerableClass == null) {
      throw new IllegalArgumentException("enumerableClass should not be null.");
    }
    this.B = enumerableClass;
    this.C = new HashMap();
    this.A = new Vector();
  }
  
  protected void A(Enumerable enumerable)
  {
    if ((enumerable == null) || (enumerable.getClass() != this.B)) {
      throw new IllegalArgumentException("enumerable must be an instance of '" + this.B + "'.");
    }
    String name = enumerable.getName();
    if (name == null) {
      throw new IllegalArgumentException("enumerable's name should not be null.");
    }
    if (this.C.containsKey(name)) {
      throw new IllegalArgumentException("enumerable with name '" + name + "' already exist.");
    }
    this.C.put(name, enumerable);
    this.A.add(enumerable);
  }
  
  protected Enumerable A(String name)
  {
    return (Enumerable)this.C.get(name);
  }
  
  protected Vector A()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.enumerable.A
 * JD-Core Version:    0.7.0.1
 */
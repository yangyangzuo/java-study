package twaver.base.enumerable;

public abstract class AbstractEnumerable
  implements Enumerable
{
  private final String A;
  
  public AbstractEnumerable(String name)
  {
    this.A = name;
    EnumerableManager.registerEnumerable(this);
  }
  
  public String getName()
  {
    return this.A;
  }
  
  public String toString()
  {
    return this.A;
  }
  
  public boolean equals(Object object)
  {
    if ((object instanceof Enumerable))
    {
      Enumerable enumerable = (Enumerable)object;
      return this.A.equals(enumerable.getName());
    }
    return this.A.equals(object);
  }
  
  public int hashCode()
  {
    return this.A.hashCode();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.base.enumerable.AbstractEnumerable
 * JD-Core Version:    0.7.0.1
 */
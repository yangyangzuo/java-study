package twaver;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import javax.swing.ImageIcon;
import javax.swing.event.EventListenerList;
import twaver.base.A.E.P;
import twaver.base.A.E.V;
import twaver.base.A.E.W;
import twaver.base.A.E.j;
import twaver.base.A.F.C.A;
import twaver.base.A.F.C.D;
import twaver.base.A.F.C.G;
import twaver.base.A.F.C.I;
import twaver.base.A.F.C.J;
import twaver.base.A.F.C.K;
import twaver.network.background.Background;

public class TDataBox
  implements PropertyChangeListener, Serializable, Batchable
{
  private boolean K = true;
  private List O = new LinkedList();
  private Map Z = new HashMap(30);
  private Map a = new HashMap(30);
  private List C = new LinkedList();
  private Object S = null;
  private Map P = new HashMap();
  private String c = "DataBox";
  private String H = TWaverUtil.getDataBoxVersion();
  private boolean N = true;
  private EventListenerList b = new EventListenerList();
  private EventListenerList M = new EventListenerList();
  private PropertyChangeSupport E = new PropertyChangeSupport(this);
  private DataBoxSelectionModel R = new twaver.base.A.F.B(this);
  private AlarmModel B = new AlarmModel(this);
  private LayerModel I = new LayerModel();
  protected Map clientProperties;
  private Background Y;
  private transient List J = null;
  private transient AlarmPropagator V = null;
  private transient List X = null;
  private transient List L = null;
  private transient twaver.base.A.D.B.C G = null;
  private transient twaver.base.A.D.B.C D = null;
  private transient List T = null;
  private transient UndoRedoManager W = null;
  private transient Generator _ = TUIManager.getLinkBundleAgentGenerator();
  private transient VisibleFilter F = TUIManager.getLinkBundleFilter();
  private int Q = 0;
  private transient List U = new ArrayList();
  
  public boolean isBatching()
  {
    return this.Q > 0;
  }
  
  public void startBatch()
  {
    this.Q += 1;
    int count = this.U.size();
    if ((this.Q == 1) && (count > 0))
    {
      BatchEvent event = new BatchEvent(this);
      for (int i = 0; i < count; i++)
      {
        BatchListener l = (BatchListener)this.U.get(i);
        l.batchStarted(event);
      }
    }
  }
  
  public void endBatch()
  {
    if (this.Q == 0) {
      throw new IllegalStateException("batch hasn't started yet.");
    }
    this.Q -= 1;
    int count = this.U.size();
    if ((this.Q == 0) && (count > 0))
    {
      BatchEvent event = new BatchEvent(this);
      for (int i = 0; i < count; i++)
      {
        BatchListener l = (BatchListener)this.U.get(i);
        l.batchEnded(event);
      }
    }
  }
  
  public void addBatchListener(BatchListener l)
  {
    if (!this.U.contains(l)) {
      this.U.add(l);
    }
  }
  
  public void removeBatchListener(BatchListener l)
  {
    this.U.remove(l);
  }
  
  public void setBackground(Background background)
  {
    Object oldValue = this.Y;
    this.Y = background;
    firePropertyChange("background", oldValue, this.Y);
  }
  
  public Background getBackground()
  {
    return this.Y;
  }
  
  public String getName()
  {
    return this.c;
  }
  
  public void setName(String name)
  {
    Object oldValue = this.c;
    this.c = name;
    firePropertyChange("name", oldValue, name);
  }
  
  public Object getClientProperty(Object key)
  {
    if (this.clientProperties == null) {
      return null;
    }
    return getClientProperties().get(key);
  }
  
  public Map getClientProperties()
  {
    if (this.clientProperties == null) {
      this.clientProperties = new LinkedHashMap();
    }
    return this.clientProperties;
  }
  
  public void putClientProperty(Object key, Object value)
  {
    Object oldValue = getClientProperties().get(key);
    if (value != null) {
      getClientProperties().put(key, value);
    } else if (oldValue != null) {
      getClientProperties().remove(key);
    }
    String propertyName = "CP:" + key.toString();
    firePropertyChange(propertyName, oldValue, value);
  }
  
  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    this.E.addPropertyChangeListener(listener);
  }
  
  public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
  {
    this.E.addPropertyChangeListener(propertyName, listener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    this.E.removePropertyChangeListener(listener);
  }
  
  public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
  {
    this.E.removePropertyChangeListener(propertyName, listener);
  }
  
  public TDataBox()
  {
    this("DataBox");
  }
  
  public TDataBox(String name)
  {
    this(name, null);
  }
  
  public TDataBox(List elements)
  {
    this("DataBox", elements);
  }
  
  public TDataBox(String name, List elements)
  {
    this.c = name;
    if (elements != null) {
      this.O = elements;
    }
    if (this.O.size() > 0) {
      throw new IllegalArgumentException("elements should be empty.");
    }
    A();
  }
  
  public AlarmModel getAlarmModel()
  {
    return this.B;
  }
  
  public LayerModel getLayerModel()
  {
    return this.I;
  }
  
  private void readObject(ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    A();
  }
  
  private void A()
  {
    this.V = new SummingAlarmPropagator();
    this.L = new ArrayList();
    this._ = TUIManager.getLinkBundleAgentGenerator();
    this.F = TUIManager.getLinkBundleFilter();
    this.U = new ArrayList();
    this.W = new UndoRedoManager(this);
    this.T = new ArrayList();
    this.T.add(new I(this));
    this.T.add(new twaver.base.A.F.C.H(this));
    this.T.add(new J(this, this.a, this.C));
    this.T.add(new twaver.base.A.F.C.F(this));
    this.T.add(new K(this));
    this.T.add(new G(this.P));
    this.T.add(new twaver.base.A.F.C.B(this));
    this.T.add(new A());
    this.T.add(new twaver.base.A.F.C.C(this));
    this.T.add(new twaver.base.A.F.C.E(this));
    this.T.add(new D(this));
  }
  
  public PropertyChangeSupport getPropertyChangeSupport()
  {
    return this.E;
  }
  
  protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
  {
    this.E.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  protected void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
  {
    this.E.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  public void addDataBoxSequenceListener(DataBoxSequenceListener l)
  {
    this.M.add(DataBoxSequenceListener.class, l);
  }
  
  public void removeDataBoxSequenceListener(DataBoxSequenceListener l)
  {
    this.M.remove(DataBoxSequenceListener.class, l);
  }
  
  public void fireIndexChanged(Element element)
  {
    Object[] listeners = this.M.getListenerList();
    for (int i = 0; i <= listeners.length - 2; i += 2) {
      if (listeners[i] == DataBoxSequenceListener.class) {
        ((DataBoxSequenceListener)listeners[(i + 1)]).indexChanged(element);
      }
    }
  }
  
  void B(DataBoxListener l)
  {
    if (l == null) {
      return;
    }
    if (this.J == null) {
      this.J = new ArrayList();
    }
    if (!this.J.contains(l)) {
      this.J.add(l);
    }
  }
  
  void A(DataBoxListener l)
  {
    if (this.J != null) {
      this.J.remove(l);
    }
  }
  
  void B(PropertyChangeListener l)
  {
    if (this.X == null) {
      this.X = new ArrayList();
    }
    if (!this.X.contains(l)) {
      this.X.add(l);
    }
  }
  
  void A(PropertyChangeListener l)
  {
    if (this.X != null) {
      this.X.remove(l);
    }
  }
  
  public void addDataBoxListener(DataBoxListener l)
  {
    this.b.add(DataBoxListener.class, l);
  }
  
  private void B(Element element)
  {
    Node host = null;
    if ((element instanceof Follower)) {
      host = ((Follower)element).getHost();
    }
    Node from = null;
    Node to = null;
    if ((element instanceof Link))
    {
      Link link = (Link)element;
      from = link.getFrom();
      to = link.getTo();
    }
    BTS bts = null;
    if ((element instanceof BTSAntenna)) {
      bts = ((BTSAntenna)element).getBTS();
    }
    DataBoxEvent e = new DataBoxEvent(this, element, element.getParent(), from, to, host, bts, 1);
    if (this.J != null)
    {
      Iterator it = this.J.iterator();
      while (it.hasNext()) {
        ((DataBoxListener)it.next()).elementAdded(e);
      }
    }
    Object[] listeners = this.b.getListenerList();
    for (int i = 0; i <= listeners.length - 2; i += 2) {
      ((DataBoxListener)listeners[(i + 1)]).elementAdded(e);
    }
  }
  
  private void A(Element element, Element parent, Node from, Node to, Node host, BTS bts)
  {
    DataBoxEvent e = new DataBoxEvent(this, element, parent, from, to, host, bts, 2);
    if (this.J != null)
    {
      Iterator it = this.J.iterator();
      while (it.hasNext()) {
        ((DataBoxListener)it.next()).elementRemoved(e);
      }
    }
    Object[] listeners = this.b.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      ((DataBoxListener)listeners[(i + 1)]).elementRemoved(e);
    }
  }
  
  private void A(List elements)
  {
    DataBoxEvent e = new DataBoxEvent(this, null, 3);
    e.setUserObject(elements);
    if (this.J != null)
    {
      Iterator it = this.J.iterator();
      while (it.hasNext()) {
        ((DataBoxListener)it.next()).elementsCleared(e);
      }
    }
    Object[] listeners = this.b.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      ((DataBoxListener)listeners[(i + 1)]).elementsCleared(e);
    }
  }
  
  public void removeDataBoxListener(DataBoxListener l)
  {
    this.b.remove(DataBoxListener.class, l);
  }
  
  public DataBoxSelectionModel getSelectionModel()
  {
    return this.R;
  }
  
  public Element getLastSelectedElement()
  {
    return this.R.lastElement();
  }
  
  public Iterator selection()
  {
    return this.R.selection();
  }
  
  public void setSelectionModel(DataBoxSelectionModel selectionModel)
  {
    if (selectionModel == null) {
      throw new IllegalArgumentException("Cannot set a null TDataBox DataBoxSelectionModel");
    }
    this.R = selectionModel;
  }
  
  public Element getElementByID(Object id)
  {
    return (Element)this.Z.get(id);
  }
  
  public Element getRandomElement()
  {
    int size = this.O.size();
    if (size == 0) {
      return null;
    }
    return (Element)this.O.get(TWaverUtil.getRandomInt(size));
  }
  
  public Element getElementByName(String name)
  {
    if (name == null) {
      return null;
    }
    Iterator it = this.Z.values().iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      if ((element.getName() != null) && (element.getName().equals(name))) {
        return element;
      }
    }
    return null;
  }
  
  public Element getElementByTag(String tag)
  {
    return (Element)this.P.get(tag);
  }
  
  public boolean containsByID(Object id)
  {
    return this.Z.containsKey(id);
  }
  
  public boolean contains(Element element)
  {
    if (element == null) {
      return false;
    }
    return element == this.Z.get(element.getID());
  }
  
  public void addElement(Element element)
    throws IllegalArgumentException
  {
    addElement(-1, element);
  }
  
  public void addElement(int index, Element element)
  {
    if (element == null) {
      return;
    }
    if (this.Z.containsKey(element.getID())) {
      throw new IllegalArgumentException("Element with ID '" + element.getID() + "' already exist");
    }
    if (V.B(element))
    {
      Link link = (Link)element;
      if ((link.getFrom() == null) || (link.getTo() == null)) {
        throw new IllegalArgumentException("Link element with ID '" + element.getID() + "' must set from node and to node.");
      }
    }
    this.Z.put(element.getID(), element);
    if ((element instanceof PolyLine)) {
      this.O.add(element);
    } else {
      this.O.add(0, element);
    }
    if (element.getParent() == null)
    {
      this.a.put(element.getID(), element);
      if (index >= 0) {
        this.C.add(index, element);
      } else {
        this.C.add(element);
      }
    }
    element.addPropertyChangeListener(this);
    B(element);
    if (element.isSelected()) {
      this.R.appendSelection(element);
    }
    if ((element instanceof Link))
    {
      Link link = (Link)element;
      link.checkAgentNode();
      tagLinkIndex(link);
    }
    if ((element instanceof Node))
    {
      Node node = (Node)element;
      j.A(node);
    }
    twaver.base.A.E.E.A(this, element);
    if ((element instanceof Group)) {
      ((Group)element).invalidateGroupShape();
    }
    if ((element instanceof BTS))
    {
      ((BTS)element).P();
      V.A((BTS)element);
    }
    if ((element instanceof BTSAntenna)) {
      ((BTSAntenna)element).invalidateAntennaShape();
    }
    V.F(element);
    if ((getAlarmPropagator() != null) && (!element.getAlarmState().isEmpty()))
    {
      AlarmPropagator propagator = getAlarmPropagator();
      propagator.propagate(element);
    }
    if ((element instanceof Equipment))
    {
      Equipment equipment = (Equipment)element;
      if (equipment.getTag() != null) {
        this.P.put(equipment.getTag(), equipment);
      }
    }
  }
  
  public int size()
  {
    return this.O.size();
  }
  
  public int getChildIndex(Element element)
  {
    if (element == null) {
      return -1;
    }
    if (element.getParent() != null) {
      return element.getParent().getChildren().indexOf(element);
    }
    return this.C.indexOf(element);
  }
  
  public boolean removeElement(Element element)
  {
    if (element != null) {
      return removeElementByID(element.getID()) == element;
    }
    return false;
  }
  
  public Element removeElementByID(Object id)
  {
    if (id == null) {
      return null;
    }
    if (!containsByID(id)) {
      return null;
    }
    Element element = (Element)this.Z.get(id);
    Node from = null;
    Node to = null;
    if ((element instanceof Link))
    {
      Link link = (Link)element;
      from = link.getFrom();
      to = link.getTo();
      link.setFrom(null);
      link.setTo(null);
      if ((from == to) && (from != null)) {
        tagLinkIndex(from, to);
      }
    }
    if (((element instanceof Node)) && (((Node)element).getAllLinks() != null))
    {
      Object[] links = ((Node)element).getAllLinks().toArray();
      for (int i = 0; i < links.length; i++) {
        removeElement((Link)links[i]);
      }
    }
    if (((element instanceof Node)) && (((Node)element).getAllFollowers() != null))
    {
      Object[] followers = ((Node)element).getAllFollowers().toArray();
      for (int i = 0; i < followers.length; i++)
      {
        Follower follower = (Follower)followers[i];
        follower.setHost(null);
      }
    }
    Node host = null;
    if (((element instanceof Follower)) && (((Follower)element).getHost() != null))
    {
      host = ((Follower)element).getHost();
      ((Follower)element).setHost(null);
    }
    if ((element instanceof BTS)) {
      ((BTS)element).clearAntennas();
    }
    BTS bts = null;
    if ((element instanceof BTSAntenna))
    {
      bts = ((BTSAntenna)element).getBTS();
      ((BTSAntenna)element).setBTS(null);
    }
    Object[] children = element.getChildren().toArray();
    for (int i = 0; i < children.length; i++)
    {
      Element child = (Element)children[i];
      removeElementByID(child.getID());
    }
    Element oldParent = element.getParent();
    if (element.getParent() != null) {
      element.getParent().removeChild(element);
    }
    if (getSelectionModel().contains(element)) {
      getSelectionModel().removeSelection(element);
    }
    this.Z.remove(id);
    this.O.remove(element);
    if (this.a.containsKey(element.getID()))
    {
      this.a.remove(element.getID());
      this.C.remove(element);
    }
    if ((element instanceof Equipment)) {
      this.P.remove(((Equipment)element).getTag());
    }
    A(element, oldParent, from, to, host, bts);
    element.removePropertyChangeListener(this);
    return element;
  }
  
  public void removeSelectedElements()
  {
    if (getSelectionModel().isEmpty()) {
      return;
    }
    Collection eldestElements = getSelectionModel().getToppestSelectedElement();
    getSelectionModel().clearSelection();
    Iterator it = eldestElements.iterator();
    while (it.hasNext()) {
      removeElement((Element)it.next());
    }
  }
  
  public Iterator iterator()
  {
    return this.O.iterator();
  }
  
  public Iterator iteratorReverse()
  {
    return getAllElementsReverse().iterator();
  }
  
  public void iterator(ElementCallbackHandler handler)
  {
    Iterator it = this.O.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      if (!handler.processElement(element)) {
        return;
      }
    }
  }
  
  public void iteratorSelection(ElementCallbackHandler handler)
  {
    Iterator it = selection();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      if (!handler.processElement(element)) {
        return;
      }
    }
  }
  
  public void iteratorReverse(ElementCallbackHandler handler)
  {
    ListIterator it = this.O.listIterator(this.O.size());
    while (it.hasPrevious())
    {
      Element element = (Element)it.previous();
      if (!handler.processElement(element)) {
        return;
      }
    }
  }
  
  public void iteratorReverseByLayer(ElementCallbackHandler handler)
  {
    int layerSize = this.I.size();
    for (int index = 0; index < layerSize; index++)
    {
      Layer layer = this.I.getLayerByIndex(index);
      ListIterator it = this.O.listIterator(this.O.size());
      while (it.hasPrevious())
      {
        Element element = (Element)it.previous();
        if ((this.I.contains(element, layer)) && (!handler.processElement(element))) {
          return;
        }
      }
    }
  }
  
  public void iteratorByLayer(ElementCallbackHandler handler)
  {
    int layerSize = this.I.size();
    for (int index = layerSize - 1; index >= 0; index--)
    {
      Layer layer = this.I.getLayerByIndex(index);
      Iterator it = this.O.iterator();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if ((this.I.contains(element, layer)) && (!handler.processElement(element))) {
          return;
        }
      }
    }
  }
  
  public Iterator iterator(Class clazz)
  {
    return getElementsByType(clazz).iterator();
  }
  
  public List getElementsByType(Class clazz)
  {
    List list = new ArrayList();
    if (clazz != null)
    {
      Iterator it = this.O.iterator();
      while (it.hasNext())
      {
        Object e = it.next();
        if (clazz.isAssignableFrom(e.getClass())) {
          list.add(e);
        }
      }
    }
    return list;
  }
  
  public boolean isEmpty()
  {
    return this.O.isEmpty();
  }
  
  public ListIterator listIterator(int index)
  {
    return this.O.listIterator(index);
  }
  
  public List getAllElements()
  {
    return new ArrayList(this.O);
  }
  
  public List getAllElementsReverse()
  {
    List list = new ArrayList();
    ListIterator listIt = listIterator(size());
    while (listIt.hasPrevious())
    {
      Element element = (Element)listIt.previous();
      list.add(element);
    }
    return list;
  }
  
  public List getRootElements()
  {
    return this.C;
  }
  
  public List getRootElementsReverse()
  {
    List result = new ArrayList(this.C);
    Collections.reverse(result);
    return result;
  }
  
  public void clear()
  {
    getSelectionModel().clearSelection();
    Iterator it = this.O.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      element.removePropertyChangeListener(this);
    }
    List oldValue = new ArrayList(this.O);
    this.Z.clear();
    this.O.clear();
    this.a.clear();
    this.C.clear();
    this.P.clear();
    A(oldValue);
  }
  
  public int indexOf(Element element)
  {
    return this.O.indexOf(element);
  }
  
  public void sendToTop(Element element)
  {
    if (!this.K) {
      return;
    }
    if (!contains(element)) {
      return;
    }
    this.O.remove(element);
    this.O.add(0, element);
    fireIndexChanged(element);
    if (V.B(element))
    {
      Link link = (Link)element;
      Node fromAgent = link.getFromAgent();
      if ((fromAgent != null) && (!fromAgent.isAdjustToBottom())) {
        sendToTop(link.getFromAgent());
      }
      Node toAgent = link.getToAgent();
      if ((toAgent != null) && (!toAgent.isAdjustToBottom())) {
        sendToTop(link.getToAgent());
      }
    }
    if (((element instanceof Node)) && (!(element instanceof BTS)) && (!(element instanceof BTSAntenna)))
    {
      Node node = (Node)element;
      List followers = node.getAllFollowers();
      if (followers != null) {
        for (int i = 0; i < followers.size(); i++)
        {
          Follower f = (Follower)followers.get(i);
          if ((!V.D(f, node)) && (!V.B(node, f))) {
            sendToTop(f);
          }
        }
      }
    }
    if ((element instanceof PolyLine))
    {
      List routerNodes = ((PolyLine)element).getAllNodes();
      for (int i = 0; i < routerNodes.size(); i++)
      {
        Node routerNode = (Node)routerNodes.get(i);
        if (!V.D(element, routerNode)) {
          sendToTop(routerNode);
        }
      }
    }
    if ((element instanceof BTSAntenna))
    {
      BTS bts = ((BTSAntenna)element).getBTS();
      if (bts != null) {
        sendToTop(bts);
      }
    }
    if (((element instanceof TSubNetwork)) || ((element instanceof BTS))) {
      return;
    }
    if (((element instanceof Group)) && (!((Group)element).isExpand())) {
      return;
    }
    Iterator it = element.children();
    while (it.hasNext())
    {
      Element child = (Element)it.next();
      if (!(child instanceof Link)) {
        sendToTop(child);
      }
    }
  }
  
  public void sendToBottom(Element element)
  {
    sendToBottom(element, null);
  }
  
  public void sendToBottom(Element element, Element referenceElement)
  {
    if (!this.K) {
      return;
    }
    if (!contains(element)) {
      return;
    }
    if ((referenceElement != null) && (!contains(referenceElement))) {
      return;
    }
    this.O.remove(element);
    int newIndex;
    int newIndex;
    if (referenceElement == null) {
      newIndex = this.O.size();
    } else {
      newIndex = this.O.indexOf(referenceElement) + 1;
    }
    this.O.add(newIndex, element);
    fireIndexChanged(element);
    Element parent = element.getParent();
    if ((!(parent instanceof TSubNetwork)) && (!(parent instanceof Link))) {
      sendToBottom(parent, element);
    }
  }
  
  public AlarmPropagator getAlarmPropagator()
  {
    return this.V;
  }
  
  public void setAlarmPropagator(AlarmPropagator alarmPropagator)
  {
    if (this.V == alarmPropagator) {
      return;
    }
    AlarmPropagator oldValue = this.V;
    this.V = alarmPropagator;
    Iterator it = this.O.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      element.getAlarmState().setPropagateSeverity(null);
    }
    it = this.O.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      if ((getAlarmPropagator() != null) && (!element.getAlarmState().isEmpty()))
      {
        AlarmPropagator propagator = getAlarmPropagator();
        propagator.propagate(element);
      }
    }
    firePropertyChange("alarmPropagator", oldValue, this.V);
  }
  
  public void propertyChange(PropertyChangeEvent e)
  {
    if (this.X != null)
    {
      Iterator it = this.X.iterator();
      while (it.hasNext())
      {
        PropertyChangeListener l = (PropertyChangeListener)it.next();
        l.propertyChange(e);
      }
    }
    for (int i = 0; i < this.T.size(); i++)
    {
      twaver.base.A.F.E handler = (twaver.base.A.F.E)this.T.get(i);
      if (handler.B(e)) {
        handler.A(e);
      }
    }
    Iterator it = this.L.iterator();
    while (it.hasNext())
    {
      PropertyChangeListener l = (PropertyChangeListener)it.next();
      l.propertyChange(e);
    }
  }
  
  public void addElementPropertyChangeListener(PropertyChangeListener l)
  {
    if (!this.L.contains(l)) {
      this.L.add(l);
    }
  }
  
  public void removeElementPropertyChangeListener(PropertyChangeListener l)
  {
    this.L.remove(l);
  }
  
  public List getElementPropertyChangeListeners()
  {
    return new ArrayList(this.L);
  }
  
  public void parseJar(InputStream in)
    throws IOException
  {
    parseJar(in, null);
  }
  
  public void parseJar(InputStream in, Element parentOfRootElement)
    throws IOException
  {
    JarInputStream jarIn = new JarInputStream(in);
    for (JarEntry entry = jarIn.getNextJarEntry(); entry != null; entry = jarIn.getNextJarEntry())
    {
      String name = entry.getName();
      if (!name.equals("data.xml"))
      {
        byte[] bytes = TWaverUtil.getByteArrayFromInputStream(jarIn);
        if (bytes != null)
        {
          ImageIcon img = new ImageIcon(bytes);
          TWaverUtil.registerImageIcon(name, img);
        }
      }
      else
      {
        byte[] xmlChars = TWaverUtil.getByteArrayFromInputStream(jarIn);
        String xmlString = new String(xmlChars, "UTF-8");
        PersistenceManager.readByXML(this, xmlString, parentOfRootElement);
      }
    }
    jarIn.close();
  }
  
  public void outputJar(String fileName)
    throws IOException
  {
    if (fileName == null) {
      return;
    }
    if (fileName.startsWith("file:")) {
      for (fileName = fileName.substring("file:".length()); fileName.startsWith("/"); fileName = fileName.substring(1)) {}
    }
    OutputStream out = new FileOutputStream(fileName);
    outputJar(out);
    out.close();
  }
  
  public byte[] toJarBytes()
    throws IOException
  {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    DataBoxJarWriter writer = new DataBoxJarWriter(out);
    writer.write(this);
    return out.toByteArray();
  }
  
  public void outputJar(OutputStream out)
    throws IOException
  {
    DataBoxJarWriter writer = new DataBoxJarWriter(out);
    writer.write(this);
  }
  
  public void parseJar(String filename)
    throws IOException
  {
    parseJar(filename, null);
  }
  
  public void parseJar(String filename, Element parentOfRootElement)
    throws IOException
  {
    filename = "jar:file:/" + filename + "!/";
    URL url = new URL(filename);
    JarURLConnection conn = (JarURLConnection)url.openConnection();
    DataBoxJarReader reader = new DataBoxJarReader(conn);
    reader.read(this, parentOfRootElement);
  }
  
  public void parse(InputStream in)
    throws IOException
  {
    parse(in, null);
  }
  
  public void parse(String url)
    throws IOException
  {
    parse(url, null);
  }
  
  public void parse(InputStream in, Element parentOfRootElement)
    throws IOException
  {
    PersistenceManager.readByXML(this, in, parentOfRootElement);
  }
  
  /* Error */
  public void parse(String url, Element parentOfRootElement)
    throws IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: iconst_1
    //   2: invokestatic 1024	twaver/base/A/E/C:B	(Ljava/lang/String;Z)Ljava/io/InputStream;
    //   5: astore_3
    //   6: aload_3
    //   7: ifnonnull +34 -> 41
    //   10: new 1030	java/lang/NullPointerException
    //   13: dup
    //   14: new 171	java/lang/StringBuffer
    //   17: dup
    //   18: ldc_w 1032
    //   21: invokespecial 175	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   24: aload_1
    //   25: invokevirtual 179	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   28: ldc_w 1034
    //   31: invokevirtual 179	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   34: invokevirtual 183	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   37: invokespecial 1036	java/lang/NullPointerException:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: aload_0
    //   42: aload_3
    //   43: aload_2
    //   44: invokestatic 1021	twaver/PersistenceManager:readByXML	(Ltwaver/TDataBox;Ljava/io/InputStream;Ltwaver/Element;)V
    //   47: goto +19 -> 66
    //   50: astore 5
    //   52: jsr +6 -> 58
    //   55: aload 5
    //   57: athrow
    //   58: astore 4
    //   60: aload_3
    //   61: invokevirtual 1037	java/io/InputStream:close	()V
    //   64: ret 4
    //   66: jsr -8 -> 58
    //   69: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	70	0	this	TDataBox
    //   0	70	1	url	String
    //   0	70	2	parentOfRootElement	Element
    //   5	56	3	in	InputStream
    //   58	1	4	localObject1	Object
    //   50	6	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   41	50	50	finally
    //   66	69	50	finally
  }
  
  public void output(String fileName, boolean withElementId)
    throws IOException
  {
    DataBoxOutputSetting setting = new DataBoxOutputSetting();
    setting.setWithElementId(withElementId);
    output(fileName, setting);
  }
  
  public void output(String fileName, boolean withElementId, boolean withAlarmState, ElementPersistentFilter elementFilter, ClientPropertyPersistentFilter clientPropertyFilter)
    throws IOException
  {
    DataBoxOutputSetting setting = new DataBoxOutputSetting();
    setting.setWithElementId(withElementId);
    setting.setWithAlarmState(withAlarmState);
    setting.setElementFilter(elementFilter);
    setting.setClientPropertyFilter(clientPropertyFilter);
    output(fileName, setting);
  }
  
  public void output(String fileName, DataBoxOutputSetting outputSetting)
    throws IOException
  {
    if (fileName == null) {
      return;
    }
    if (fileName.startsWith("file:")) {
      for (fileName = fileName.substring("file:".length()); fileName.startsWith("/"); fileName = fileName.substring(1)) {}
    }
    OutputStream out = new FileOutputStream(fileName);
    outputSetting.setOutputStream(out);
    P.A(this, outputSetting);
    out.close();
  }
  
  public void output(DataBoxOutputSetting outputSetting)
    throws IOException
  {
    P.A(this, outputSetting);
  }
  
  public void output(OutputStream out, boolean withElementId)
    throws IOException
  {
    DataBoxOutputSetting setting = new DataBoxOutputSetting();
    setting.setWithElementId(withElementId);
    setting.setOutputStream(out);
    P.A(this, setting);
  }
  
  public twaver.base.A.D.B.C getGifImageFinder()
  {
    if (this.G == null) {
      this.G = new twaver.base.A.D.B.C(this, false);
    }
    return this.G;
  }
  
  public twaver.base.A.D.B.C getGifIconFinder()
  {
    if (this.D == null) {
      this.D = new twaver.base.A.D.B.C(this, true);
    }
    return this.D;
  }
  
  public void selectAll()
  {
    getSelectionModel().selectAll();
  }
  
  public List getLayers()
  {
    return this.O;
  }
  
  public Enumeration depthFirstEnumeration()
  {
    return new twaver.base.A.F.F(this.C);
  }
  
  public Enumeration depthFirstEnumeration(Element root)
  {
    return new twaver.base.A.F.F(root);
  }
  
  public Enumeration breadthFirstEnumeration()
  {
    return new twaver.base.A.F.C(this.C);
  }
  
  public Enumeration breadthFirstEnumeration(Element root)
  {
    return new twaver.base.A.F.C(root);
  }
  
  public void addElementWithDescendant(Element element)
  {
    addElementWithDescendant(element, null);
  }
  
  public void addElementWithDescendant(Element element, VisibleFilter filter)
  {
    twaver.base.A.E.E.A(this, element, filter);
  }
  
  public void removeDescendant(Element element)
  {
    twaver.base.A.E.E.B(this, element);
  }
  
  public DataBoxQuickFinder createJavaBeanFinder(String propertyName)
  {
    return createJavaBeanFinder(propertyName, null);
  }
  
  public DataBoxQuickFinder createJavaBeanFinder(String propertyName, Class elementClass)
  {
    if (elementClass == null) {
      elementClass = Element.class;
    }
    Method readMethod = twaver.base.A.E.H.A(elementClass, propertyName);
    if (readMethod == null) {
      throw new RuntimeException("can not find '" + propertyName + "' read method in '" + elementClass + "'");
    }
    Generator keyGenerator = new Generator()
    {
      private final Method val$readMethod;
      private final String val$propertyName;
      
      public Object generate(Object element)
      {
        return twaver.base.A.E.H.A(element, this.val$readMethod, this.val$propertyName);
      }
    };
    DataBoxQuickFinder finder = new DataBoxQuickFinder(this, propertyName, elementClass, keyGenerator);
    return finder;
  }
  
  public DataBoxQuickFinder createClientPropertyFinder(String clientPropertyKey)
  {
    return createClientPropertyFinder(clientPropertyKey, Element.class);
  }
  
  public DataBoxQuickFinder createClientPropertyFinder(String clientPropertyKey, Class elementClass)
  {
    Generator keyGenerator = new Generator()
    {
      private final String val$clientPropertyKey;
      
      public Object generate(Object element)
      {
        return ((Element)element).getClientProperty(this.val$clientPropertyKey);
      }
    };
    DataBoxQuickFinder finder = new DataBoxQuickFinder(this, "CP:" + clientPropertyKey, elementClass, keyGenerator);
    return finder;
  }
  
  public DataBoxQuickFinder createUserPropertyFinder(String userPropertyKey)
  {
    return createUserPropertyFinder(userPropertyKey, Element.class);
  }
  
  public DataBoxQuickFinder createUserPropertyFinder(String userPropertyKey, Class elementClass)
  {
    Generator keyGenerator = new Generator()
    {
      private final String val$userPropertyKey;
      
      public Object generate(Object element)
      {
        return ((Element)element).getUserProperty(this.val$userPropertyKey);
      }
    };
    DataBoxQuickFinder finder = new DataBoxQuickFinder(this, "UP:" + userPropertyKey, elementClass, keyGenerator);
    return finder;
  }
  
  public Generator getLinkBundleAgentGenerator()
  {
    return this._;
  }
  
  public void setLinkBundleAgentGenerator(Generator linkBundleAgentGenerator)
  {
    this._ = linkBundleAgentGenerator;
  }
  
  public void reverseBundleExpand(Link link)
  {
    this.W.setEnable(false);
    link.setBundleExpand(!link.isLinkBundleExpand());
    this.W.setEnable(true);
    this.W.addEvent(new UndoRedoEvent(link));
    tagLinkIndex(link);
  }
  
  public void tagLinkIndex(Link link)
  {
    if (link != null) {
      tagLinkIndex(link.getFromAgent(), link.getToAgent());
    }
  }
  
  public void tagLinkIndex(Node node1, Node node2)
  {
    this.W.setEnable(false);
    j.A(node1, node2, this);
    this.W.setEnable(true);
    this.W.addEvent(new UndoRedoEvent(this, node1, node2));
  }
  
  public List getBundledLinks(Link link)
  {
    return getBundledLinks(link.getFromAgent(), link.getToAgent());
  }
  
  public List getBundledLinks(Node node1, Node node2)
  {
    List links = j.A(node1, node2);
    if ((this.F != null) && (links != null) && (links.size() > 0))
    {
      Iterator it = links.iterator();
      while (it.hasNext())
      {
        Link link = (Link)it.next();
        if (!this.F.isVisible(link)) {
          it.remove();
        }
      }
    }
    return links;
  }
  
  private void A(Element element)
  {
    Object[] listeners = this.M.getListenerList();
    for (int i = 0; i <= listeners.length - 2; i += 2) {
      if (listeners[i] == DataBoxSequenceListener.class) {
        ((DataBoxSequenceListener)listeners[(i + 1)]).hiberarchyChanged(element);
      }
    }
  }
  
  public void moveTo(int index, Element element)
  {
    Element pElement = element.getParent();
    List list;
    List list;
    if (pElement == null) {
      list = this.C;
    } else {
      list = pElement.getChildren();
    }
    int nowIndex = list.indexOf(element);
    if ((nowIndex == index) || (nowIndex < 0)) {
      return;
    }
    if ((index >= 0) && (index <= list.size()))
    {
      list.remove(element);
      if (index > list.size()) {
        index--;
      }
      list.add(index, element);
      A(element);
    }
  }
  
  public void moveToUp(Element element)
  {
    Element pElement = element.getParent();
    List list;
    List list;
    if (pElement == null) {
      list = this.C;
    } else {
      list = pElement.getChildren();
    }
    moveTo(list.indexOf(element) - 1, element);
  }
  
  public void moveToDown(Element element)
  {
    Element pElement = element.getParent();
    List list;
    List list;
    if (pElement == null) {
      list = this.C;
    } else {
      list = pElement.getChildren();
    }
    moveTo(list.indexOf(element) + 1, element);
  }
  
  public void moveToTop(Element element)
  {
    moveTo(0, element);
  }
  
  public void moveToBottom(Element element)
  {
    Element pElement = element.getParent();
    List list;
    List list;
    if (pElement == null) {
      list = this.C;
    } else {
      list = pElement.getChildren();
    }
    moveTo(list.size(), element);
  }
  
  public void moveSelectionToUp()
  {
    List elements = new ArrayList();
    twaver.base.A.E.E.C(elements, this.C);
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      moveToUp(element);
    }
  }
  
  public void moveSelectionToDown()
  {
    List elements = new ArrayList();
    twaver.base.A.E.E.A(elements, this.C);
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      moveToDown(element);
    }
  }
  
  public void moveSelectionToTop()
  {
    List elements = new ArrayList();
    twaver.base.A.E.E.D(elements, this.C);
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      moveToTop(element);
    }
  }
  
  public void moveSelectionToBottom()
  {
    List elements = new ArrayList();
    twaver.base.A.E.E.B(elements, this.C);
    for (int i = 0; i < elements.size(); i++)
    {
      Element element = (Element)elements.get(i);
      moveToBottom(element);
    }
  }
  
  public void copySelection()
  {
    if (!this.R.isEmpty())
    {
      List list = new ArrayList();
      Iterator it = selection();
      while (it.hasNext()) {
        list.add(it.next());
      }
      TWaverUtil.setPasteOffset(0);
      TWaverUtil.setCopyElements(list);
    }
  }
  
  public List pasteElements(Element parentElement)
  {
    List pastes = new ArrayList();
    List list = TWaverUtil.getCopyElements();
    if ((list != null) && (list.size() > 0))
    {
      int offset = TWaverUtil.getPasteOffset() + 5;
      TWaverUtil.setPasteOffset(offset);
      for (int i = 0; i < list.size(); i++)
      {
        Element element = (Element)list.get(i);
        Element newElement = element.copy(this);
        if (element.getLocation() != null)
        {
          int x = element.getLocation().x + offset;
          int y = element.getLocation().y + offset;
          newElement.setLocation(x, y);
        }
        if ((parentElement != null) && (newElement.getParent() == null)) {
          newElement.setParent(parentElement);
        }
        if (!contains(newElement)) {
          addElement(newElement);
        }
        pastes.add(newElement);
      }
      this.R.setSelection(pastes);
    }
    return pastes;
  }
  
  public void sameHeightSelection()
  {
    if (this.R.size() > 1)
    {
      int size = this.R.firstElement().getHeight();
      Iterator it = this.R.selection();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if ((element instanceof Resizable))
        {
          Resizable resizable = (Resizable)element;
          resizable.setSize(element.getWidth(), size);
        }
      }
    }
  }
  
  public void sameWidthSelection()
  {
    if (this.R.size() > 1)
    {
      int size = this.R.firstElement().getWidth();
      Iterator it = this.R.selection();
      while (it.hasNext())
      {
        Element element = (Element)it.next();
        if ((element instanceof Resizable))
        {
          Resizable resizable = (Resizable)element;
          resizable.setSize(size, element.getHeight());
        }
      }
    }
  }
  
  public void alignBottomSelection()
  {
    W.H(this);
  }
  
  public void alignCenterSelection()
  {
    W.F(this);
  }
  
  public void alignLeftSelection()
  {
    W.C(this);
  }
  
  public void alignMiddleSelection()
  {
    W.E(this);
  }
  
  public void alignRightSelection()
  {
    W.J(this);
  }
  
  public void alignTopSelection()
  {
    W.G(this);
  }
  
  public void evenHSpaceSelection()
  {
    W.K(this);
  }
  
  public void evenVSpaceSelection()
  {
    W.A(this);
  }
  
  public void bottomPileSelection()
  {
    W.L(this);
  }
  
  public void leftPileSelection()
  {
    W.D(this);
  }
  
  public void topPileSelection()
  {
    W.I(this);
  }
  
  public void rightPileSelection()
  {
    W.B(this);
  }
  
  public static void moveElements(Iterator elements, MovableFilter movableFilter, double xOffset, double yOffset)
  {
    TWaverUtil.moveElements(elements, movableFilter, xOffset, yOffset);
  }
  
  public UndoRedoManager getUndoRedoManager()
  {
    return this.W;
  }
  
  public boolean isTagLinkWhenAlarmStateChanged()
  {
    return this.N;
  }
  
  public void setTagLinkWhenAlarmStateChanged(boolean tagLinkWhenAlarmStateChanged)
  {
    if (this.N != tagLinkWhenAlarmStateChanged)
    {
      boolean oldValue = this.N;
      this.N = tagLinkWhenAlarmStateChanged;
      firePropertyChange("tagLinkWhenAlarmStateChanged", oldValue, tagLinkWhenAlarmStateChanged);
    }
  }
  
  public void loadSubNetwork(TSubNetwork subNetwork)
  {
    if (contains(subNetwork)) {
      TWaverUtil.getDataLoader().load(subNetwork, this);
    }
  }
  
  public void loadSubNetwork(TSubNetwork subNetwork, Component component)
  {
    Cursor cursor = null;
    if (component != null)
    {
      cursor = component.getCursor();
      component.setCursor(Cursor.getPredefinedCursor(3));
    }
    loadSubNetwork(subNetwork);
    if (component != null) {
      component.setCursor(cursor);
    }
  }
  
  public void addElements(Collection collection)
  {
    addElements(collection, null);
  }
  
  public void addElements(Collection collection, Element parentOfRootElement)
  {
    if (collection == null) {
      return;
    }
    Iterator it = collection.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      addElement(element, parentOfRootElement);
    }
  }
  
  public void addElement(Element element, Element parentOfRootElement)
  {
    if (element == null) {
      return;
    }
    Element parent = element.getParent();
    if ((parentOfRootElement != null) && (parent == null)) {
      element.setParent(parentOfRootElement);
    }
    if (V.B(element))
    {
      Link link = (Link)element;
      if ((link.getFrom() == null) || (link.getTo() == null))
      {
        TWaverUtil.handleError("link with id '" + link.getID() + "'and name '" + link.getName() + "' has no from or to Node.", null);
        return;
      }
      if (!containsByID(link.getFrom().getID())) {
        addElement(link.getFrom(), parentOfRootElement);
      }
      if (!containsByID(link.getTo().getID())) {
        addElement(link.getTo(), parentOfRootElement);
      }
    }
    if ((parent != null) && (!V.B(parent)) && (!containsByID(parent.getID()))) {
      addElement(parent, parentOfRootElement);
    }
    if (!containsByID(element.getID())) {
      addElement(element);
    }
  }
  
  public void parseXML(String xml)
  {
    parseXML(xml, null);
  }
  
  public void parseXML(String xml, Element parent)
  {
    try
    {
      PersistenceManager.readByXML(this, xml, parent);
    }
    catch (IOException e)
    {
      TWaverUtil.handleError(null, e);
    }
  }
  
  public String toXML()
  {
    return toXML(new DataBoxOutputSetting());
  }
  
  public String toXML(DataBoxOutputSetting setting)
  {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    setting.setOutputStream(out);
    try
    {
      P.A(this, setting);
      out.close();
      return new String(out.toByteArray(), "UTF-8");
    }
    catch (IOException ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public void clearAllElementAlarmState()
  {
    Iterator it = this.O.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      element.getAlarmState().clear();
    }
  }
  
  public boolean isEnableAdjustIndex()
  {
    return this.K;
  }
  
  public void setEnableAdjustIndex(boolean enableAdjustIndex)
  {
    this.K = enableAdjustIndex;
  }
  
  public String getVersion()
  {
    return this.H;
  }
  
  public void setVersion(String version)
  {
    Object oldValue = this.H;
    this.H = version;
    firePropertyChange("version", oldValue, this.H);
  }
  
  public Object getID()
  {
    return this.S;
  }
  
  public void setID(Object id)
  {
    Object oldValue = this.S;
    this.S = id;
    firePropertyChange("id", oldValue, this.S);
  }
  
  public VisibleFilter getLinkBundleFilter()
  {
    return this.F;
  }
  
  public void setLinkBundleFilter(VisibleFilter linkBundleFilter)
  {
    this.F = linkBundleFilter;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TDataBox
 * JD-Core Version:    0.7.0.1
 */
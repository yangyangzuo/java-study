package twaver;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D.Double;

public class Dummy
  extends Node
{
  public Dummy() {}
  
  public Dummy(Object id)
  {
    super(id);
  }
  
  public String getUIClassID()
  {
    return "DummyUI";
  }
  
  public String getSVGUIClassID()
  {
    return "DummySVGUI";
  }
  
  public Point getLocation()
  {
    return TWaverConst.ORIGIN_POINT;
  }
  
  public int getWidth()
  {
    return 0;
  }
  
  public int getHeight()
  {
    return 0;
  }
  
  public double getX()
  {
    return 0.0D;
  }
  
  public double getY()
  {
    return 0.0D;
  }
  
  public Rectangle getBounds()
  {
    return TWaverConst.EMPTY_BOUNDS.getBounds();
  }
  
  public void setLocation(double x, double y) {}
  
  public void setLocation(Point location) {}
  
  public void setLocation(Point2D.Double location) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Dummy
 * JD-Core Version:    0.7.0.1
 */
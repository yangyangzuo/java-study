package twaver;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D.Double;
import twaver.base.A.E.V;

public class RotatableNode
  extends Node
{
  private double Z = 0.0D;
  private int W = 0;
  private int V = 0;
  private double Y = 1.0D;
  private Shape X = null;
  
  public RotatableNode()
  {
    M();
  }
  
  public RotatableNode(Object id)
  {
    super(id);
    M();
  }
  
  private void M()
  {
    this.W = V.H(this);
    this.V = V.A(this);
    L();
  }
  
  public String getUIClassID()
  {
    return "RotatableNodeUI";
  }
  
  public double getAngle()
  {
    return this.Z;
  }
  
  public void setAngle(double angle)
  {
    if (this.Z == angle) {
      return;
    }
    Object oldValue = new Double(this.Z);
    this.Z = angle;
    firePropertyChange("angle", oldValue, new Double(this.Z));
    L();
  }
  
  public double getZoom()
  {
    return this.Y;
  }
  
  public void setZoom(double zoom)
  {
    if (this.Y == zoom) {
      return;
    }
    Object oldValue = new Double(this.Y);
    this.Y = zoom;
    firePropertyChange("zoom", oldValue, new Double(this.Y));
    L();
  }
  
  public int getWidth()
  {
    return this.W;
  }
  
  public int getHeight()
  {
    return this.V;
  }
  
  public void setImage(String url)
  {
    if ((url == null) || (url.trim().equals(""))) {
      url = null;
    }
    String oldUrl = this.imageUrl;
    this.imageUrl = url;
    firePropertyChange("image", oldUrl, this.imageUrl);
    L();
  }
  
  private void L()
  {
    int oldWidth = this.W;
    int oldHeight = this.V;
    Point centerLocation = getCenterLocation();
    int w = V.H(this);
    int h = V.A(this);
    AffineTransform at = new AffineTransform();
    at.setTransform(1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
    at.rotate(Math.toRadians(this.Z));
    this.X = at.createTransformedShape(new Rectangle2D.Double(-w / 2 * this.Y, -h / 2 * this.Y, w * this.Y, h * this.Y));
    Rectangle rect = this.X.getBounds();
    this.V = rect.height;
    this.W = rect.width;
    firePropertyChange("width", oldWidth, this.W);
    firePropertyChange("height", oldHeight, this.V);
    setCenterLocation(centerLocation);
  }
  
  public Shape getRotatableShape()
  {
    Point centerLocation = getCenterLocation();
    AffineTransform at = new AffineTransform();
    at.translate(centerLocation.getX(), centerLocation.getY());
    return at.createTransformedShape(this.X);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.RotatableNode
 * JD-Core Version:    0.7.0.1
 */
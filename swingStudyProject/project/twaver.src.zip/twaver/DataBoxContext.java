package twaver;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.ImageIcon;
import twaver.network.background.Background;

public class DataBoxContext
{
  private Object E = null;
  private String B = null;
  private String C = null;
  private Background D = null;
  private Map A = null;
  
  public Map getImages()
  {
    return this.A;
  }
  
  public void setImages(Map images)
  {
    this.A = images;
    if (TWaverUtil.isXMLParsing())
    {
      Iterator it = images.keySet().iterator();
      while (it.hasNext())
      {
        String key = (String)it.next();
        if (TWaverUtil.getImageIcon(key, false) == null)
        {
          String value = (String)images.get(key);
          byte[] bytes = TWaverUtil.decodeBase64Buffer(value.getBytes());
          TWaverUtil.registerImageIcon(key, new ImageIcon(bytes));
        }
      }
    }
  }
  
  public Background getBackground()
  {
    return this.D;
  }
  
  public void setBackground(Background background)
  {
    this.D = background;
  }
  
  public String getName()
  {
    return this.C;
  }
  
  public void setName(String name)
  {
    this.C = name;
  }
  
  public String getVersion()
  {
    return this.B;
  }
  
  public void setVersion(String version)
  {
    this.B = version;
  }
  
  public Object getID()
  {
    return this.E;
  }
  
  public void setID(Object id)
  {
    this.E = id;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxContext
 * JD-Core Version:    0.7.0.1
 */
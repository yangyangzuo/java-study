package twaver;

import java.awt.Stroke;

public abstract interface LinkStyleFactory
{
  public abstract Stroke createStroke(int paramInt);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.LinkStyleFactory
 * JD-Core Version:    0.7.0.1
 */
package twaver;

class SpringLayouter$4
  implements Runnable
{
  final SpringLayouter.3 this$1;
  
  SpringLayouter$4(SpringLayouter.3 param3)
  {
    this.this$1 = param3;
  }
  
  public void run()
  {
    SpringLayouter.access$4(SpringLayouter.3.access$0(this.this$1));
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SpringLayouter.4
 * JD-Core Version:    0.7.0.1
 */
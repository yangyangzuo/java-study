package twaver.animate;

import twaver.TSubNetwork;
import twaver.network.TNetwork;

public class AnimateSubNetwork
  extends Animate
{
  private TNetwork G;
  private TSubNetwork F;
  
  public AnimateSubNetwork(TNetwork network, TSubNetwork subNetwork, Runnable runnable, int stepSize, int sleep)
  {
    super(runnable, stepSize, sleep);
    this.G = network;
    this.F = subNetwork;
  }
  
  public void step(int stepIndex)
  {
    double t = stepIndex / this.stepSize;
    if (t > 0.5D)
    {
      this.G.setAlpha((float)(t * 2.0D - 1.0D));
      if (this.G.getCurrentSubNetwork() != this.F) {
        this.G.setCurrentSubNetwork(this.F);
      }
    }
    else
    {
      this.G.setAlpha(1.0F - (float)t * 2.0F);
    }
  }
  
  public TNetwork getNetwork()
  {
    return this.G;
  }
  
  public TSubNetwork getSubNetwork()
  {
    return this.F;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateSubNetwork
 * JD-Core Version:    0.7.0.1
 */
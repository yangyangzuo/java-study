package twaver.animate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import twaver.Element;

public abstract class AnimateProperty
  extends Animate
{
  protected Map newProperties;
  protected Map oldProperties;
  
  public AnimateProperty(Map newProperties, Runnable runnable, int stepSize, int sleep)
  {
    super(runnable, stepSize, sleep);
    this.newProperties = newProperties;
    this.oldProperties = new HashMap();
    Iterator it = newProperties.keySet().iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      this.oldProperties.put(element, getPropertyValue(element));
    }
  }
  
  public void step(int stepIndex)
  {
    Iterator it = this.newProperties.keySet().iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      Object oldPropertyValue = this.oldProperties.get(element);
      Object newPropertyValue = this.newProperties.get(element);
      step(stepIndex, element, oldPropertyValue, newPropertyValue);
    }
  }
  
  public abstract Object getPropertyValue(Element paramElement);
  
  public abstract void step(int paramInt, Element paramElement, Object paramObject1, Object paramObject2);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateProperty
 * JD-Core Version:    0.7.0.1
 */
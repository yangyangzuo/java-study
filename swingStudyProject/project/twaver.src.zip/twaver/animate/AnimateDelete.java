package twaver.animate;

import java.util.Iterator;
import java.util.List;
import twaver.Element;
import twaver.TDataBox;
import twaver.UndoRedoManager;

public class AnimateDelete
  extends Animate
{
  private TDataBox A;
  private List B;
  
  public AnimateDelete(TDataBox box, List elements, Runnable runnable, int stepSize, int sleep)
  {
    super(runnable, stepSize, sleep);
    this.A = box;
    this.B = elements;
  }
  
  public void step(int stepIndex)
  {
    float t = 1.0F - stepIndex / this.stepSize;
    Iterator it = this.B.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      this.A.getUndoRedoManager().setIgnorePropertyChange(true);
      element.putRenderAlpha(t);
      this.A.getUndoRedoManager().setIgnorePropertyChange(false);
      if (stepIndex == this.stepSize)
      {
        this.A.getUndoRedoManager().setIgnorePropertyChange(true);
        element.putRenderAlpha(1.0F);
        this.A.getUndoRedoManager().setIgnorePropertyChange(false);
        this.A.removeElement(element);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateDelete
 * JD-Core Version:    0.7.0.1
 */
package twaver.animate;

import java.awt.event.MouseEvent;
import twaver.TWaverUtil;
import twaver.network.TNetwork;
import twaver.network.ui.ComponentAttachment;
import twaver.network.ui.ElementUI;

public class AnimateComponentAttachment
  extends Animate
{
  private ComponentAttachment E;
  private int C;
  private MouseEvent D;
  
  public AnimateComponentAttachment(ComponentAttachment attachment, int type, MouseEvent mouseEvent)
  {
    super(null, TWaverUtil.getAnimateStep() * 2, -1);
    this.E = attachment;
    this.C = type;
    this.D = mouseEvent;
    if (type == 1) {
      attachment.setAlpha(0.0F);
    }
  }
  
  public void step(int stepIndex)
  {
    float t = stepIndex / this.stepSize;
    if (this.C == 1) {
      this.E.setAlpha(t);
    } else {
      this.E.setAlpha(1.0F - t);
    }
    if (stepIndex == this.stepSize)
    {
      this.E.setAlpha(1.0F);
      if (this.C == 2)
      {
        this.E.getElementUI().removeAttachment(this.E);
        this.E.getElementUI().getNetwork().invalidateElementBounds(this.E.getElementUI().getElement());
      }
      else if (this.C == 3)
      {
        this.E.setShrinked(true, this.D);
      }
      else if (this.C == 4)
      {
        this.E.setMinimized(true, this.D);
      }
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateComponentAttachment
 * JD-Core Version:    0.7.0.1
 */
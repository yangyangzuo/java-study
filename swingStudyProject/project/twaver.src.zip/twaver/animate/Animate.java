package twaver.animate;

import twaver.TWaverUtil;

public abstract class Animate
{
  protected int currentStepIndex;
  protected int stepSize;
  protected int sleep;
  protected Runnable runnable;
  
  public Animate(Runnable runnable, int stepSize, int sleep)
  {
    this.runnable = runnable;
    this.stepSize = stepSize;
    this.sleep = sleep;
    if (this.stepSize < 0) {
      this.stepSize = TWaverUtil.getAnimateStep();
    }
    if (this.sleep < 0) {
      this.sleep = TWaverUtil.getAnimateSleep();
    }
  }
  
  public void start()
  {
    AnimateManager.getInstance().addAnimate(this);
  }
  
  public int getSleep()
  {
    return this.sleep;
  }
  
  public abstract void step(int paramInt);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.Animate
 * JD-Core Version:    0.7.0.1
 */
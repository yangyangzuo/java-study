package twaver.animate;

import java.awt.Rectangle;
import java.util.Map;
import twaver.Element;
import twaver.ResizableNode;

public class AnimateResize
  extends AnimateProperty
{
  public AnimateResize(Map newLocations)
  {
    this(newLocations, null);
  }
  
  public AnimateResize(Map newBounds, Runnable runnable)
  {
    this(newBounds, runnable, -1, -1);
  }
  
  public AnimateResize(Map newBounds, Runnable runnable, int stepSize, int sleep)
  {
    super(newBounds, runnable, stepSize, sleep);
  }
  
  public Object getPropertyValue(Element element)
  {
    return element.getBounds();
  }
  
  public void step(int stepIndex, Element element, Object oldPropertyValue, Object newPropertyValue)
  {
    Rectangle oldBound = (Rectangle)oldPropertyValue;
    Rectangle newBound = (Rectangle)newPropertyValue;
    double x = oldBound.x + stepIndex * (newBound.getX() - oldBound.getX()) / this.stepSize;
    double y = oldBound.y + stepIndex * (newBound.getY() - oldBound.getY()) / this.stepSize;
    double w = oldBound.width + stepIndex * (newBound.getWidth() - oldBound.getWidth()) / this.stepSize;
    double h = oldBound.height + stepIndex * (newBound.getHeight() - oldBound.getHeight()) / this.stepSize;
    element.setLocation(x, y);
    ((ResizableNode)element).setSize((int)w, (int)h);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateResize
 * JD-Core Version:    0.7.0.1
 */
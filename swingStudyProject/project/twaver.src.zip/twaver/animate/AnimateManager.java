package twaver.animate;

import twaver.TWaverUtil;
import twaver.Task;
import twaver.TaskAdapter;
import twaver.TaskScheduler;

public class AnimateManager
{
  private Animate C = null;
  private TaskScheduler D = null;
  private static AnimateManager A = null;
  private boolean B = false;
  
  public TaskScheduler getTaskScheduler()
  {
    return this.D;
  }
  
  public Animate getCurrentAnimate()
  {
    return this.C;
  }
  
  public static synchronized AnimateManager getInstance()
  {
    if ((A == null) || (!A.D.isRunning()))
    {
      A = new AnimateManager();
      A.D = TaskScheduler.createTaskScheduler(TWaverUtil.getAnimateSleep());
      A.D.start("Animate Scheduler Thread");
    }
    return A;
  }
  
  public void addAnimate(Animate animate)
  {
    if (this.B)
    {
      animate.currentStepIndex = animate.stepSize;
      animate.step(animate.currentStepIndex);
      if (animate.runnable != null)
      {
        animate.runnable.run();
        animate.runnable = null;
      }
      return;
    }
    if (this.C != null)
    {
      this.B = true;
      Animate t = this.C;
      this.C = null;
      t.currentStepIndex = t.stepSize;
      t.step(t.currentStepIndex);
      if (t.runnable != null)
      {
        t.runnable.run();
        t.runnable = null;
      }
      this.B = false;
    }
    this.C = animate;
    animate.currentStepIndex = 0;
    Task task = new TaskAdapter()
    {
      private final Animate val$animate;
      
      public int getInterval()
      {
        double t = this.val$animate.currentStepIndex / this.val$animate.stepSize;
        if ((t < 0.2D) || (t > 0.8D)) {
          return this.val$animate.getSleep() * 2;
        }
        return this.val$animate.getSleep();
      }
      
      public void run(long clock)
      {
        if (this.val$animate.currentStepIndex < this.val$animate.stepSize)
        {
          this.val$animate.currentStepIndex += 1;
          this.val$animate.step(this.val$animate.currentStepIndex);
        }
        else
        {
          if (this.val$animate.runnable != null)
          {
            this.val$animate.runnable.run();
            this.val$animate.runnable = null;
          }
          AnimateManager.this.D.unregister(this);
          if (AnimateManager.this.C == this.val$animate) {
            AnimateManager.this.C = null;
          }
        }
      }
    };
    this.D.register(task);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateManager
 * JD-Core Version:    0.7.0.1
 */
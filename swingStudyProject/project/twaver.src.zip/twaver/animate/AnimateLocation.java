package twaver.animate;

import java.awt.geom.Point2D;
import java.util.Map;
import twaver.Element;

public class AnimateLocation
  extends AnimateProperty
{
  public AnimateLocation(Map newLocations)
  {
    this(newLocations, null);
  }
  
  public AnimateLocation(Map newLocations, Runnable runnable)
  {
    this(newLocations, runnable, -1, -1);
  }
  
  public AnimateLocation(Map newLocations, Runnable runnable, int stepSize, int sleep)
  {
    super(newLocations, runnable, stepSize, sleep);
  }
  
  public Object getPropertyValue(Element element)
  {
    return element.getLocation();
  }
  
  public void step(int stepIndex, Element element, Object oldPropertyValue, Object newPropertyValue)
  {
    Point2D oldLocation = (Point2D)oldPropertyValue;
    Point2D newLocation = (Point2D)newPropertyValue;
    double x = oldLocation.getX() + stepIndex * (newLocation.getX() - oldLocation.getX()) / this.stepSize;
    double y = oldLocation.getY() + stepIndex * (newLocation.getY() - oldLocation.getY()) / this.stepSize;
    element.setLocation(x, y);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.animate.AnimateLocation
 * JD-Core Version:    0.7.0.1
 */
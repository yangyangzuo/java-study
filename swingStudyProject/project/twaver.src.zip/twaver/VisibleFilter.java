package twaver;

public abstract interface VisibleFilter
  extends Filter
{
  public abstract boolean isVisible(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.VisibleFilter
 * JD-Core Version:    0.7.0.1
 */
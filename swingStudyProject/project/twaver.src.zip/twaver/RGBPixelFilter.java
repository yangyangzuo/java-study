package twaver;

import java.awt.Color;

public class RGBPixelFilter
  implements PixelFilter
{
  public int filter(int pixel, Color filterColor)
  {
    int alpha = pixel >> 24 & 0xFF;
    if (alpha > 0)
    {
      if (TWaverUtil.isGrayImageBeforeDyed()) {
        pixel = gray(pixel);
      }
      return pixel & filterColor.getRGB();
    }
    return 0;
  }
  
  public int gray(int rgb)
  {
    int a = rgb & 0xFF000000;
    int r = rgb >> 16 & 0xFF;
    int g = rgb >> 8 & 0xFF;
    int b = rgb & 0xFF;
    rgb = r * 77 + g * 151 + b * 28 >> 8;
    return a | rgb << 16 | rgb << 8 | rgb;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.RGBPixelFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.beans.PropertyChangeEvent;

public class AlarmStateChangeEvent
  extends PropertyChangeEvent
{
  public static final int PROPAGATE_CHANGED = 1;
  public static final int NATIVE_CHANGED = 2;
  private int A = 2;
  
  public AlarmStateChangeEvent(Element element, int type)
  {
    super(element, "alarmState", null, element.getAlarmState());
    if ((type != 1) && (type != 2)) {
      throw new IllegalArgumentException("bad event type:" + type);
    }
    this.A = type;
  }
  
  public int getType()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmStateChangeEvent
 * JD-Core Version:    0.7.0.1
 */
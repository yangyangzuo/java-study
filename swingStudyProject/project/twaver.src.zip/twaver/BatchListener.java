package twaver;

public abstract interface BatchListener
{
  public abstract void batchStarted(BatchEvent paramBatchEvent);
  
  public abstract void batchEnded(BatchEvent paramBatchEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BatchListener
 * JD-Core Version:    0.7.0.1
 */
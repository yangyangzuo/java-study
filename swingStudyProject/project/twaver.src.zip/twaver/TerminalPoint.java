package twaver;

public class TerminalPoint
  extends Follower
{
  public TerminalPoint() {}
  
  public TerminalPoint(Object id)
  {
    super(id);
  }
  
  public String getUIClassID()
  {
    return "NodeUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TerminalPoint
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

public class MouseActionEvent
  extends ActionEvent
{
  private MouseEvent C;
  private int B;
  private TView A;
  
  public MouseActionEvent(Object source, int id, String command, MouseEvent mouseEvent, TView view, int index)
  {
    super(source, id, command);
    this.C = mouseEvent;
    this.A = view;
    this.B = index;
  }
  
  public MouseActionEvent(Object source, MouseEvent mouseEvent, TView view, int index)
  {
    super(source, 0, null);
    this.C = mouseEvent;
    this.A = view;
    this.B = index;
  }
  
  public MouseActionEvent(Object source, MouseEvent mouseEvent, TView view)
  {
    this(source, mouseEvent, view, -1);
  }
  
  public MouseEvent getMouseEvent()
  {
    return this.C;
  }
  
  public Point getMousePoint()
  {
    return this.C.getPoint();
  }
  
  public int getClickCount()
  {
    return this.C.getClickCount();
  }
  
  public int getIndex()
  {
    return this.B;
  }
  
  public TView getView()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.MouseActionEvent
 * JD-Core Version:    0.7.0.1
 */
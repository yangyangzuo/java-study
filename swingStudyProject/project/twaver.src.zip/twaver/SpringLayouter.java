package twaver;

import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.swing.SwingUtilities;

public class SpringLayouter
{
  private double E = 1.0D;
  private double N = 1.0D;
  private double S = 0.008999999999999999D;
  private boolean K = false;
  private Random A = new Random();
  private Thread D = null;
  private Map H = new HashMap();
  private List M = new ArrayList();
  private List B = new ArrayList();
  private int F = 30;
  private int G = 100;
  private int C = 10;
  private double R = 0.6D;
  private double Q = 0.6D;
  private TDataBox J = null;
  private MovableFilter L = null;
  private VisibleFilter I = null;
  private boolean O = true;
  private Rectangle P = null;
  
  public SpringLayouter(TDataBox box, boolean layoutInSwingThread)
  {
    this.J = box;
    this.O = layoutInSwingThread;
    F();
  }
  
  private void F()
  {
    this.J.addDataBoxListener(new DataBoxListener()
    {
      public void elementsCleared(DataBoxEvent e)
      {
        SpringLayouter.this.D();
      }
      
      public void elementRemoved(DataBoxEvent e)
      {
        SpringLayouter.this.D();
      }
      
      public void elementAdded(DataBoxEvent e)
      {
        SpringLayouter.this.D();
      }
    });
    this.J.addElementPropertyChangeListener(new PropertyChangeListener()
    {
      public void propertyChange(PropertyChangeEvent evt)
      {
        SpringLayouter.this.G();
      }
    });
  }
  
  private void D()
  {
    if (getDataBox().size() == 0)
    {
      this.E = 0.0D;
      this.N = 0.0D;
    }
    else
    {
      this.E = 1.0D;
      this.N = 1.0D;
    }
  }
  
  private void G()
  {
    if (!this.K)
    {
      this.E = 1.0D;
      this.N = 1.0D;
    }
  }
  
  protected TDataBox getDataBox()
  {
    return this.J;
  }
  
  private boolean B(Element element)
  {
    if (this.L != null) {
      return this.L.isMovable(element);
    }
    return !element.isSelected();
  }
  
  private boolean A(Element element)
  {
    if (this.I != null) {
      return this.I.isVisible(element);
    }
    return true;
  }
  
  public void random(int offset, int randomSize)
  {
    Iterator elements = getDataBox().iterator();
    while (elements.hasNext())
    {
      Element element = (Element)elements.next();
      if ((A(element)) && (B(element)) && (!(element instanceof Link)))
      {
        int x = TWaverUtil.getRandomInt(randomSize);
        int y = TWaverUtil.getRandomInt(randomSize);
        element.setLocation(offset + x, offset + y);
      }
    }
  }
  
  public void start()
  {
    this.N = 1.0D;
    Runnable r = new Runnable()
    {
      public void run()
      {
        while ((!Thread.currentThread().isInterrupted()) && (SpringLayouter.this.D == Thread.currentThread()))
        {
          try
          {
            if (SpringLayouter.this.O) {
              SwingUtilities.invokeAndWait(new SpringLayouter.4(this));
            } else {
              SpringLayouter.this.E();
            }
          }
          catch (Exception localException) {}
          if (SpringLayouter.this.C > 0) {
            try
            {
              Thread.sleep(SpringLayouter.this.C);
            }
            catch (InterruptedException e)
            {
              return;
            }
          }
        }
      }
    };
    this.D = new Thread(r);
    this.D.start();
  }
  
  public void stop()
  {
    this.D = null;
  }
  
  private void E()
  {
    this.E = 1.0D;
    if (this.N < this.S) {
      return;
    }
    B();
    for (int i = 0; i < this.F; i++)
    {
      Iterator it = this.B.iterator();
      while (it.hasNext()) {
        A((_A)it.next());
      }
      Iterator itFirst = this.M.iterator();
      while (itFirst.hasNext())
      {
        _B n1 = (_B)itFirst.next();
        Iterator itSecend = this.M.iterator();
        while (itSecend.hasNext())
        {
          _B n2 = (_B)itSecend.next();
          if (n1 != n2) {
            A(n1, n2);
          }
        }
      }
      A();
    }
    this.K = true;
    Iterator it = this.M.iterator();
    while (it.hasNext())
    {
      _B node = (_B)it.next();
      if ((!node.A) && (!node.F.isSelected())) {
        node.F.setLocation(node.B, node.G);
      }
    }
    this.K = false;
  }
  
  private void A(_A link)
  {
    double vx = link.B.B - link.D.B;
    double vy = link.B.G - link.D.G;
    double len = Math.sqrt(vx * vx + vy * vy);
    double dx = vx * 0.25D;
    double dy = vy * 0.25D;
    dx /= link.C * 100.0D;
    double length = link.C;
    double div = length * 100.0D;
    double ddy = dy;
    dy /= div;
    ddy /= link.C * 100.0D;
    link.B.E -= dx * len;
    link.B.C -= dy * len;
    link.D.E += dx * len;
    link.D.C += dy * len;
  }
  
  private void A(_B n1, _B n2)
  {
    double dx = 0.0D;
    double dy = 0.0D;
    double vx = n1.B - n2.B;
    double vy = n1.G - n2.G;
    double len = vx * vx + vy * vy;
    if (len == 0.0D)
    {
      dx = this.A.nextDouble();
      dy = this.A.nextDouble();
    }
    else if (len < 360000.0D)
    {
      dx = vx / len;
      dy = vy / len;
    }
    double repSum = n1.D * n2.D / 100.0D;
    double factor = repSum * 0.25D;
    n1.E += dx * factor;
    n1.C += dy * factor;
    n2.E -= dx * factor;
    n2.C -= dy * factor;
  }
  
  private void A()
  {
    double maxMotionA = 0.0D;
    Iterator it = this.M.iterator();
    while (it.hasNext())
    {
      _B n = (_B)it.next();
      double dx = n.E;
      double dy = n.C;
      dx *= this.E;
      dy *= this.E;
      n.E = (dx / 2.0D);
      n.C = (dy / 2.0D);
      double distMoved = Math.sqrt(dx * dx + dy * dy);
      if (!n.A)
      {
        n.B += Math.max(-30.0D, Math.min(30.0D, dx));
        n.G += Math.max(-30.0D, Math.min(30.0D, dy));
        if (this.P == null)
        {
          if (n.B < 1.0D) {
            A(1.0D, 0.0D);
          }
          if (n.G < 1.0D) {
            A(0.0D, 1.0D);
          }
        }
        else
        {
          if (n.B < this.P.x)
          {
            n.B = this.P.x;
            A(1.0D, 0.0D);
          }
          if (n.G < this.P.y)
          {
            n.G = this.P.y;
            A(0.0D, 1.0D);
          }
          if (n.B + n.F.getWidth() > this.P.x + this.P.width)
          {
            n.B = (this.P.x + this.P.width - n.F.getWidth());
            A(-1.0D, 0.0D);
          }
          if (n.G + n.F.getHeight() > this.P.y + this.P.height)
          {
            n.G = (this.P.y + this.P.height - n.F.getHeight());
            A(0.0D, -1.0D);
          }
        }
      }
      maxMotionA = Math.max(distMoved, maxMotionA);
    }
    this.N = maxMotionA;
    C();
  }
  
  private void C()
  {
    if (((this.N < 0.2D) || ((this.N > 1.0D) && (this.E < 0.9D))) && (this.E > 0.01D)) {
      this.E -= 0.01D;
    } else if ((this.N < 0.4D) && (this.E > 0.003D)) {
      this.E -= 0.003D;
    } else if (this.E > 0.0001D) {
      this.E -= 0.0001D;
    }
  }
  
  private void B()
  {
    this.H.clear();
    this.M.clear();
    this.B.clear();
    Iterator it = getDataBox().iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      if (A(element)) {
        if ((element instanceof Link)) {
          A((Link)element);
        } else {
          C(element);
        }
      }
    }
  }
  
  private _B C(Element element)
  {
    _B node = (_B)this.H.get(element);
    if (node != null) {
      return node;
    }
    node = new _B();
    node.F = element;
    node.D = D(element);
    node.B = element.getX();
    node.G = element.getY();
    node.A = (!B(element));
    this.H.put(element, node);
    this.M.add(node);
    return node;
  }
  
  private void A(Link element)
  {
    _A link = new _A();
    link.D = C(element.getFrom());
    link.B = C(element.getTo());
    link.A = element;
    double w = element.getFrom().getWidth() + element.getTo().getWidth();
    double h = element.getFrom().getHeight() + element.getTo().getHeight();
    link.C = (Math.sqrt(w * w + h * h) * this.Q);
    if (link.C < this.G) {
      link.C = this.G;
    }
    this.B.add(link);
  }
  
  private double D(Element node)
  {
    double result = Math.sqrt(node.getWidth() * node.getWidth() + node.getHeight() * node.getHeight()) * this.R;
    if (result <= 0.0D) {
      result = 100.0D;
    }
    return result;
  }
  
  private void A(double xoffset, double yoffset)
  {
    Iterator it = this.M.iterator();
    while (it.hasNext())
    {
      _B n = (_B)it.next();
      if (xoffset > 0.0D)
      {
        if ((this.P == null) || (n.B + n.F.getWidth() + xoffset < this.P.x + this.P.width)) {
          n.B += xoffset;
        }
      }
      else if ((this.P == null) || (n.B > this.P.x)) {
        n.B += xoffset;
      }
      if (yoffset > 0.0D)
      {
        if ((this.P == null) || (n.G + n.F.getHeight() < this.P.y + this.P.height)) {
          n.G += yoffset;
        }
      }
      else if ((this.P == null) || (n.G > this.P.y)) {
        n.G += yoffset;
      }
    }
  }
  
  public int getForceSize()
  {
    return this.G;
  }
  
  public void setForceSize(int forceSize)
  {
    this.G = forceSize;
    this.E = 1.0D;
    this.N = 1.0D;
  }
  
  public int getStepSize()
  {
    return this.F;
  }
  
  public void setStepSize(int stepSize)
  {
    this.F = stepSize;
  }
  
  public int getUpdateDuration()
  {
    return this.C;
  }
  
  public void setUpdateDuration(int updateDuration)
  {
    this.C = updateDuration;
  }
  
  public VisibleFilter getVisibleFilter()
  {
    return this.I;
  }
  
  public void setVisibleFilter(VisibleFilter visibleFilter)
  {
    this.I = visibleFilter;
  }
  
  public MovableFilter getMovableFilter()
  {
    return this.L;
  }
  
  public void setMovableFilter(MovableFilter movableFilter)
  {
    this.L = movableFilter;
  }
  
  public Rectangle getLimitBounds()
  {
    return this.P;
  }
  
  public void setLimitBounds(Rectangle limitBounds)
  {
    this.P = limitBounds;
    this.E = 1.0D;
    this.N = 1.0D;
  }
  
  public double getNodeRepulsionFactor()
  {
    return this.R;
  }
  
  public void setNodeRepulsionFactor(double nodeRepulsionFactor)
  {
    if (nodeRepulsionFactor < 0.02D) {
      nodeRepulsionFactor = 0.02D;
    }
    this.R = nodeRepulsionFactor;
    this.E = 1.0D;
    this.N = 1.0D;
  }
  
  public double getLinkRepulsionFactor()
  {
    return this.Q;
  }
  
  public void setLinkRepulsionFactor(double linkRepulsionFactor)
  {
    if (linkRepulsionFactor < 0.02D) {
      linkRepulsionFactor = 0.02D;
    }
    this.Q = linkRepulsionFactor;
    this.E = 1.0D;
    this.N = 1.0D;
  }
  
  class _A
  {
    SpringLayouter._B D;
    SpringLayouter._B B;
    Link A;
    double C;
    
    _A() {}
  }
  
  class _B
  {
    double B = 0.0D;
    double G = 0.0D;
    double E = 0.0D;
    double C = 0.0D;
    double D = 0.0D;
    boolean A = false;
    Element F;
    
    _B() {}
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SpringLayouter
 * JD-Core Version:    0.7.0.1
 */
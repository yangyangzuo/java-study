package twaver;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import twaver.base.A.E.L;
import twaver.base.A.E.N;
import twaver.network.background.Background;
import twaver.network.background.ImageBackground;
import twaver.network.background.TextureBackground;

public class DataBoxJarWriter
{
  private OutputStream A = null;
  
  public DataBoxJarWriter(OutputStream output)
  {
    this.A = output;
  }
  
  public void write(TDataBox box)
    throws IOException
  {
    JarOutputStream jarOutputStream = new JarOutputStream(this.A);
    Map map = A(box, jarOutputStream);
    ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
    box.getSelectionModel().clearSelection();
    box.output(byteOutputStream, false);
    String xmlString = byteOutputStream.toString("UTF-8");
    byteOutputStream.close();
    Iterator it = map.keySet().iterator();
    while (it.hasNext())
    {
      Object key = it.next();
      Object value = map.get(key);
      String imageURL = (String)key;
      String entryName = (String)value;
      String imageTag = "<string>" + imageURL + "</string>";
      String newImageTag = "<string>" + entryName + "</string>";
      xmlString = L.A(xmlString, imageTag, newImageTag);
    }
    ByteArrayInputStream bytesInputStream = new ByteArrayInputStream(xmlString.getBytes("UTF-8"));
    A(jarOutputStream, bytesInputStream, "data.xml");
    bytesInputStream.close();
    jarOutputStream.close();
  }
  
  private String A(Background background)
  {
    String imageURL = null;
    if (background != null) {
      if ((background instanceof ImageBackground)) {
        imageURL = ((ImageBackground)background).getImageURL();
      } else if ((background instanceof TextureBackground)) {
        imageURL = ((TextureBackground)background).getImageURL();
      }
    }
    if ("-".equals(imageURL)) {
      return null;
    }
    return imageURL;
  }
  
  private Map A(TDataBox box, JarOutputStream jar)
    throws IOException
  {
    Set set = new TreeSet();
    Iterator it = box.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      String iconURL = element.getIconURL();
      if ((iconURL != null) && (!iconURL.equals("-"))) {
        set.add(iconURL);
      }
      String imageURL = element.getImageURL();
      if ((imageURL != null) && (!imageURL.equals("-"))) {
        set.add(imageURL);
      }
      if ((element instanceof TSubNetwork))
      {
        Background background = ((TSubNetwork)element).getBackground();
        imageURL = A(background);
        if (imageURL != null) {
          set.add(imageURL);
        }
      }
    }
    Background background = box.getBackground();
    String backGroundImageURL = A(background);
    if (backGroundImageURL != null) {
      set.add(backGroundImageURL);
    }
    Map map = new HashMap();
    it = set.iterator();
    int index = 1;
    while (it.hasNext())
    {
      Object o = it.next();
      String imageURL = (String)o;
      InputStream inputStream = TWaverUtil.getInputStream(imageURL, false);
      if (inputStream == null)
      {
        Image img = TWaverUtil.getImage(imageURL);
        if (img != null) {
          inputStream = new ByteArrayInputStream(N.A(img, "png"));
        }
      }
      if (inputStream != null)
      {
        int endIndex = imageURL.lastIndexOf(".");
        String extName = imageURL;
        if (endIndex >= 0) {
          extName = imageURL.substring(imageURL.lastIndexOf("."));
        }
        String jarEntryName = "JarImage_" + index + extName;
        A(jar, inputStream, jarEntryName);
        inputStream.close();
        index++;
        map.put(imageURL, jarEntryName);
      }
    }
    return map;
  }
  
  private void A(JarOutputStream jarOutput, InputStream inputStream, String name)
    throws IOException
  {
    byte[] buffer = new byte[1024];
    JarEntry jarEntry = new JarEntry(name);
    jarOutput.putNextEntry(jarEntry);
    int bytesRead;
    while ((bytesRead = inputStream.read(buffer)) != -1)
    {
      int bytesRead;
      jarOutput.write(buffer, 0, bytesRead);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxJarWriter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import twaver.base.A.E.K;
import twaver.base.A.E.Z;
import twaver.base.A.E.a;

public class ShapeNode
  extends Node
{
  protected int shapeNodeType = 0;
  protected List points = new ArrayList();
  protected List segments = null;
  protected transient Shape shape = TWaverConst.EMPTY_BOUNDS;
  protected boolean isAdjusting = false;
  
  public ShapeNode()
  {
    I();
  }
  
  public ShapeNode(Object id)
  {
    super(id);
    I();
  }
  
  private void I()
  {
    getClientProperties().put("custom.draw.fill", Boolean.FALSE);
    getClientProperties().put("custom.draw.fill.color", Color.GRAY);
    getClientProperties().put("custom.draw.outline", Boolean.TRUE);
    getClientProperties().put("custom.draw.outline.3d", Boolean.TRUE);
    getClientProperties().put("custom.draw.outline.color", Color.LIGHT_GRAY);
    getClientProperties().put("custom.draw.outline.stroke", "solid.thickest");
  }
  
  public int getShapeNodeType()
  {
    return this.shapeNodeType;
  }
  
  public void setShapeNodeType(int shapeNodeType)
  {
    if (this.shapeNodeType != shapeNodeType)
    {
      int oldValue = this.shapeNodeType;
      if ((shapeNodeType == 1) || (shapeNodeType == 2) || (shapeNodeType == 3) || (shapeNodeType == 4) || (shapeNodeType == 5) || (shapeNodeType == 6) || (shapeNodeType == 7) || (shapeNodeType == 8) || (shapeNodeType == 9))
      {
        putCustomDraw(true);
      }
      else
      {
        shapeNodeType = 0;
        putCustomDraw(false);
      }
      this.shapeNodeType = shapeNodeType;
      firePropertyChange("shapeNodeType", oldValue, shapeNodeType);
      firePointsChange();
    }
  }
  
  private void readObject(ObjectInputStream s)
    throws ClassNotFoundException, IOException
  {
    s.defaultReadObject();
    this.shape = createShape();
  }
  
  public String getUIClassID()
  {
    return "ShapeNodeUI";
  }
  
  public String getSVGUIClassID()
  {
    return "ShapeNodeSVGUI";
  }
  
  public List getPoints()
  {
    return this.points;
  }
  
  public Point2D getPoint(int index)
  {
    if ((index >= 0) && (index < this.points.size())) {
      return (Point2D)this.points.get(index);
    }
    return null;
  }
  
  public Point2D[] toPoints()
  {
    Point2D[] ps = (Point2D[])Array.newInstance(Point2D.class, this.points.size());
    this.points.toArray(ps);
    return ps;
  }
  
  public List getSegments()
  {
    return this.segments;
  }
  
  public void setSegments(List segments)
  {
    this.segments = segments;
    firePointsChange();
  }
  
  public void setBaseShape(Shape baseShape)
  {
    GeneralPath path = null;
    if ((baseShape instanceof GeneralPath)) {
      path = (GeneralPath)baseShape;
    } else {
      path = new GeneralPath(baseShape);
    }
    List ps = new ArrayList();
    this.segments = new ArrayList();
    K.A(path, ps, this.segments);
    setPoints(ps);
  }
  
  public void setPoints(List points)
  {
    this.points = K.A(points);
    firePointsChange();
  }
  
  public void setPoint(int index, Point2D point)
  {
    if ((index >= 0) && (index < this.points.size()))
    {
      this.points.set(index, K.A(point));
      firePointsChange();
    }
  }
  
  public void insertPoint(int index, Point2D point)
  {
    if ((index >= 0) && (index <= this.points.size()))
    {
      this.points.add(index, K.A(point));
      firePointsChange();
    }
  }
  
  public void removePoint(int index)
  {
    if ((index >= 0) && (index < this.points.size()))
    {
      this.points.remove(index);
      firePointsChange();
    }
  }
  
  public void addPoint(Point2D point)
  {
    if (point != null)
    {
      this.points.add(K.A(point));
      firePointsChange();
    }
  }
  
  public void clear()
  {
    if (this.points.size() > 0)
    {
      this.points.clear();
      firePointsChange();
    }
    this.segments = null;
  }
  
  public int getWidth()
  {
    return getBounds().width;
  }
  
  public int getHeight()
  {
    return getBounds().height;
  }
  
  public Rectangle getBounds()
  {
    return this.shape.getBounds();
  }
  
  public void setLocation(Point2D.Double location)
  {
    if ((this.isAdjusting) || (TWaverUtil.isXMLParsing()))
    {
      super.setLocation(location);
    }
    else
    {
      double xOffSet = location.getX() - this.xLocation;
      double yOffSet = location.getY() - this.yLocation;
      if ((xOffSet != 0.0D) || (yOffSet != 0.0D))
      {
        for (int i = 0; i < this.points.size(); i++)
        {
          Point2D point = (Point2D)this.points.get(i);
          point.setLocation(point.getX() + xOffSet, point.getY() + yOffSet);
        }
        super.setLocation(location);
        firePointsChange();
      }
    }
  }
  
  protected Shape createShape()
  {
    return Z.A(this);
  }
  
  public void firePointsChange()
  {
    if (this.isAdjusting) {
      return;
    }
    this.shape = createShape();
    this.isAdjusting = true;
    setLocation(this.shape.getBounds().getLocation());
    this.isAdjusting = false;
    firePropertyChange("points", null, this.points);
  }
  
  public Shape getShape()
  {
    return this.shape;
  }
  
  public GeneralPath getPath()
  {
    if ((this.shape instanceof GeneralPath)) {
      return (GeneralPath)this.shape;
    }
    return new GeneralPath(this.shape);
  }
  
  public void putShapeNodeShowDashLine(boolean shapeNodeShowDashLine)
  {
    putClientProperty("shapenode.show.dash.line", shapeNodeShowDashLine);
  }
  
  public boolean isShapeNodeShowDashLine()
  {
    return a.K(this, "shapenode.show.dash.line");
  }
  
  public void putShapeNodeJointPoint(int shapeNodeJointPoint)
  {
    putClientProperty("shapenode.joint.point", shapeNodeJointPoint);
  }
  
  public int getShapeNodeJointPoint()
  {
    return a.J(this, "shapenode.joint.point");
  }
  
  public void putShapeNodeFromArrow(boolean shapeNodeFromArrow)
  {
    putClientProperty("shapenode.from.arrow", shapeNodeFromArrow);
  }
  
  public void putShapeNodeToArrow(boolean shapeNodeToArrow)
  {
    putClientProperty("shapenode.to.arrow", shapeNodeToArrow);
  }
  
  public void putShapeNodeFromArrowXOffset(int shapeNodeFromArrowXOffset)
  {
    putClientProperty("shapenode.from.arrow.xoffset", shapeNodeFromArrowXOffset);
  }
  
  public void putShapeNodeFromArrowYOffset(int shapeNodeFromArrowYOffset)
  {
    putClientProperty("shapenode.from.arrow.yoffset", shapeNodeFromArrowYOffset);
  }
  
  public void putShapeNodeToArrowXOffset(int shapeNodeToArrowXOffset)
  {
    putClientProperty("shapenode.to.arrow.xoffset", shapeNodeToArrowXOffset);
  }
  
  public void putShapeNodeToArrowYOffset(int shapeNodeToArrowYOffset)
  {
    putClientProperty("shapenode.to.arrow.yoffset", shapeNodeToArrowYOffset);
  }
  
  public void putShapeNodeFromArrowCenter(boolean shapeNodeFromArrowCenter)
  {
    putClientProperty("shapenode.from.arrow.center", shapeNodeFromArrowCenter);
  }
  
  public void putShapeNodeToArrowCenter(boolean shapeNodeToArrowCenter)
  {
    putClientProperty("shapenode.to.arrow.center", shapeNodeToArrowCenter);
  }
  
  public void putShapeNodeFromArrowStyle(int shapeNodeFromArrowStyle)
  {
    putClientProperty("shapenode.from.arrow.style", shapeNodeFromArrowStyle);
  }
  
  public void putShapeNodeToArrowStyle(int shapeNodeToArrowStyle)
  {
    putClientProperty("shapenode.to.arrow.style", shapeNodeToArrowStyle);
  }
  
  public void putShapeNodeFromArrowColor(Color shapeNodeFromArrowColor)
  {
    putClientProperty("shapenode.from.arrow.color", shapeNodeFromArrowColor);
  }
  
  public void putShapeNodeToArrowColor(Color shapeNodeToArrowColor)
  {
    putClientProperty("shapenode.to.arrow.color", shapeNodeToArrowColor);
  }
  
  public void putShapeNodeFromArrowOutline(boolean shapeNodeFromArrowOutline)
  {
    putClientProperty("shapenode.from.arrow.outline", shapeNodeFromArrowOutline);
  }
  
  public void putShapeNodeToArrowOutline(boolean shapeNodeToArrowOutline)
  {
    putClientProperty("shapenode.to.arrow.outline", shapeNodeToArrowOutline);
  }
  
  public void putShapeNodeFromArrowOutlineColor(Color shapeNodeFromArrowOutlineColor)
  {
    putClientProperty("shapenode.from.arrow.outline.color", shapeNodeFromArrowOutlineColor);
  }
  
  public void putShapeNodeToArrowOutlineColor(Color shapeNodeToArrowOutlineColor)
  {
    putClientProperty("shapenode.to.arrow.outline.color", shapeNodeToArrowOutlineColor);
  }
  
  public boolean isShapeNodeFromArrowCenter()
  {
    return a.K(this, "shapenode.from.arrow.center");
  }
  
  public boolean isShapeNodeToArrowCenter()
  {
    return a.K(this, "shapenode.to.arrow.center");
  }
  
  public int getShapeNodeFromArrowStyle()
  {
    return a.J(this, "shapenode.from.arrow.style");
  }
  
  public int getShapeNodeToArrowStyle()
  {
    return a.J(this, "shapenode.to.arrow.style");
  }
  
  public Color getShapeNodeFromArrowColor()
  {
    return a.P(this, "shapenode.from.arrow.color");
  }
  
  public Color getShapeNodeToArrowColor()
  {
    return a.P(this, "shapenode.to.arrow.color");
  }
  
  public Color getShapeNodeFromArrowOutlineColor()
  {
    return a.P(this, "shapenode.from.arrow.outline.color");
  }
  
  public Color getShapeNodeToArrowOutlineColor()
  {
    return a.P(this, "shapenode.to.arrow.outline.color");
  }
  
  public boolean isShapeNodeFromArrowOutline()
  {
    return a.K(this, "shapenode.from.arrow.outline");
  }
  
  public boolean isShapeNodeToArrowOutline()
  {
    return a.K(this, "shapenode.to.arrow.outline");
  }
  
  public int getShapeNodeFromArrowXOffset()
  {
    return a.J(this, "shapenode.from.arrow.xoffset");
  }
  
  public int getShapeNodeFromArrowYOffset()
  {
    return a.J(this, "shapenode.from.arrow.yoffset");
  }
  
  public int getShapeNodeToArrowXOffset()
  {
    return a.J(this, "shapenode.to.arrow.xoffset");
  }
  
  public int getShapeNodeToArrowYOffset()
  {
    return a.J(this, "shapenode.to.arrow.yoffset");
  }
  
  public boolean isShapeNodeFromArrow()
  {
    return a.K(this, "shapenode.from.arrow");
  }
  
  public boolean isShapeNodeToArrow()
  {
    return a.K(this, "shapenode.to.arrow");
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ShapeNode
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import twaver.base.A.D.A.B;

public abstract class BlinkingRule
{
  private boolean A = true;
  private boolean B = true;
  
  public abstract boolean isBodyBlinking(Element paramElement);
  
  public abstract boolean isOutlineBlinking(Element paramElement);
  
  public boolean isEnableBodyBlinking()
  {
    return this.A;
  }
  
  public void setEnableBodyBlinking(boolean enableBlinking)
  {
    this.A = enableBlinking;
    B.C().A();
  }
  
  public boolean isEnableOutlineBlinking()
  {
    return this.B;
  }
  
  public void setEnableOutlineBlinking(boolean enableBlinking)
  {
    this.B = enableBlinking;
    B.C().A();
  }
  
  public void setEnableBlinking(boolean enableBlinking)
  {
    this.A = enableBlinking;
    this.B = enableBlinking;
    B.C().A();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BlinkingRule
 * JD-Core Version:    0.7.0.1
 */
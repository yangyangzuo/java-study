package twaver;

public class Chassis
  extends SubNetwork
{
  public Chassis() {}
  
  public Chassis(Object id)
  {
    super(id);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Chassis
 * JD-Core Version:    0.7.0.1
 */
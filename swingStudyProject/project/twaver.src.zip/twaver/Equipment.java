package twaver;

public abstract interface Equipment
  extends Element
{
  public abstract String getTag();
  
  public abstract void setTag(String paramString);
  
  public abstract void setExist(boolean paramBoolean);
  
  public abstract boolean isExist();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Equipment
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.beans.PropertyChangeEvent;

public abstract interface ElementPropertyChangeRepaintFilter
  extends Filter
{
  public abstract boolean isInterested(Element paramElement, PropertyChangeEvent paramPropertyChangeEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementPropertyChangeRepaintFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import java.awt.Point;
import twaver.network.background.Background;

public abstract interface TSubNetwork
  extends Element
{
  public abstract Point getViewPoint();
  
  public abstract void setViewPoint(Point paramPoint);
  
  public abstract Background getBackground();
  
  public abstract void setBackground(Background paramBackground);
  
  public abstract void setTextureBackground(String paramString);
  
  public abstract void setImageBackground(String paramString);
  
  public abstract void setColorBackground(Color paramColor);
  
  public abstract String getDataSource();
  
  public abstract void setDataSource(String paramString);
  
  public abstract void setDataLoaded(boolean paramBoolean);
  
  public abstract boolean isDataLoaded();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TSubNetwork
 * JD-Core Version:    0.7.0.1
 */
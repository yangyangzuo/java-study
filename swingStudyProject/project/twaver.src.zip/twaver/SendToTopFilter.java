package twaver;

public abstract interface SendToTopFilter
  extends Filter
{
  public abstract boolean isSendToToppable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SendToTopFilter
 * JD-Core Version:    0.7.0.1
 */
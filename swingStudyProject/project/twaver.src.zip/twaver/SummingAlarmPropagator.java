package twaver;

import java.util.Comparator;
import java.util.Iterator;

public class SummingAlarmPropagator
  implements AlarmPropagator
{
  protected ThreadLocal threadLocal = new ThreadLocal();
  
  public void propagate(Element element)
  {
    if ((element == null) || (this.threadLocal.get() != null)) {
      return;
    }
    this.threadLocal.set(element);
    propagateToTop(element);
    this.threadLocal.set(null);
  }
  
  protected void propagateToTop(Element element)
  {
    while ((element != null) && (element.getParent() != null))
    {
      Element parent = element.getParent();
      if (!parent.getAlarmState().isEnablePropagationFromChildren()) {
        return;
      }
      propagateToParent(element, parent);
      element = parent;
    }
  }
  
  protected void propagateToParent(Element element, Element parent)
  {
    AlarmSeverity result = null;
    Iterator it = parent.children();
    Comparator comparator = AlarmSeverity.getSeverityComparator();
    while (it.hasNext())
    {
      Element child = (Element)it.next();
      AlarmSeverity childHighest = child.getAlarmState().getHighestOverallAlarmSeverity();
      if ((childHighest != null) && (comparator.compare(childHighest, result) > 0)) {
        result = childHighest;
      }
    }
    parent.getAlarmState().setPropagateSeverity(result);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SummingAlarmPropagator
 * JD-Core Version:    0.7.0.1
 */
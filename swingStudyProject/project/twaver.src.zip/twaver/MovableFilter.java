package twaver;

public abstract interface MovableFilter
  extends Filter
{
  public abstract boolean isMovable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.MovableFilter
 * JD-Core Version:    0.7.0.1
 */
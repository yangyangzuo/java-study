package twaver;

import java.awt.Dimension;
import java.awt.Rectangle;
import twaver.base.A.E.V;

public class ResizableNode
  extends Node
  implements Resizable
{
  protected Dimension size = null;
  
  public ResizableNode() {}
  
  public ResizableNode(Object id)
  {
    super(id);
  }
  
  public void setSize(int width, int height)
  {
    setSize(new Dimension(width, height));
  }
  
  public void setSize(Dimension size)
  {
    Dimension oldSize = this.size;
    int oldWidth = getWidth();
    int oldHeight = getHeight();
    this.size = size;
    int width = getWidth();
    int height = getHeight();
    firePropertyChange("size", oldSize, size);
    firePropertyChange("width", oldWidth, width);
    firePropertyChange("height", oldHeight, height);
  }
  
  public Dimension getSize()
  {
    if (this.size == null) {
      return new Dimension(getWidth(), getHeight());
    }
    return this.size;
  }
  
  public void setWidthSize(int width)
  {
    setSize(width, getHeight());
  }
  
  public void setHeightSize(int height)
  {
    setSize(getWidth(), height);
  }
  
  public int getWidth()
  {
    if (this.size == null) {
      return V.H(this);
    }
    return this.size.width;
  }
  
  public int getHeight()
  {
    if (this.size == null) {
      return V.A(this);
    }
    return this.size.height;
  }
  
  public Rectangle getBounds()
  {
    if (this.size == null) {
      return new Rectangle((int)this.xLocation, (int)this.yLocation, getWidth(), getHeight());
    }
    return new Rectangle((int)this.xLocation, (int)this.yLocation, this.size.width, this.size.height);
  }
  
  public void setImage(String url)
  {
    super.setImage(url);
    resetDefaultSize();
  }
  
  public void resetDefaultSize()
  {
    setSize(V.H(this), V.A(this));
  }
  
  public String getUIClassID()
  {
    return "ResizableNodeUI";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ResizableNode
 * JD-Core Version:    0.7.0.1
 */
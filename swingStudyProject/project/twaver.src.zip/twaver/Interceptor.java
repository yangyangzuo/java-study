package twaver;

public abstract interface Interceptor {}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Interceptor
 * JD-Core Version:    0.7.0.1
 */
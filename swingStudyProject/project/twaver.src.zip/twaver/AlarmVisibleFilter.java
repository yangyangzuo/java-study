package twaver;

public abstract interface AlarmVisibleFilter
  extends Filter
{
  public abstract boolean isVisible(Alarm paramAlarm);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmVisibleFilter
 * JD-Core Version:    0.7.0.1
 */
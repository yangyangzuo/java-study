package twaver;

public abstract interface ErrorHandler
{
  public abstract void handle(String paramString, Throwable paramThrowable);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ErrorHandler
 * JD-Core Version:    0.7.0.1
 */
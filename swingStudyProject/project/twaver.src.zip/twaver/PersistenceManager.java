package twaver;

import java.beans.DefaultPersistenceDelegate;
import java.beans.PersistenceDelegate;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import twaver.base.A.E.I;
import twaver.base.A.E.P;
import twaver.base.A.E._;
import twaver.base.A.F.D.B;
import twaver.base.A.F.G;

public class PersistenceManager
{
  public static final PersistenceDelegate TRANSIENT_DELEGATE = new B();
  public static final PersistenceDelegate DEFAULT_DElEGATE = new DefaultPersistenceDelegate();
  private static ClientPropertyPersistentFilter A = null;
  
  public static ClientPropertyPersistentFilter getClientPropertyFilter()
  {
    return A;
  }
  
  public static void setClientPropertyFilter(ClientPropertyPersistentFilter clientPropertyFilter)
  {
    A = clientPropertyFilter;
  }
  
  public static void registerClassDelegate(Class clazz, PersistenceDelegate delegate)
  {
    G.A().A(clazz, delegate);
  }
  
  public static void unregisterClassDelegate(Class clazz)
  {
    G.A().A(clazz);
  }
  
  public static String writeByXML(TDataBox box, boolean withElementId)
    throws IOException
  {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    DataBoxOutputSetting setting = new DataBoxOutputSetting();
    setting.setWithElementId(withElementId);
    setting.setOutputStream(out);
    P.A(box, setting);
    out.close();
    return new String(out.toByteArray(), "UTF-8");
  }
  
  public static void writeByXML(TDataBox box, boolean withElementId, boolean withAlarmId, boolean withAlarmState, OutputStream out, ElementPersistentFilter elementFilter, ClientPropertyPersistentFilter clientPropertyFilter)
    throws IOException
  {
    DataBoxOutputSetting setting = new DataBoxOutputSetting();
    setting.setWithElementId(withElementId);
    setting.setWithAlarmId(withAlarmId);
    setting.setWithAlarmState(withAlarmState);
    setting.setOutputStream(out);
    setting.setElementFilter(elementFilter);
    setting.setClientPropertyFilter(clientPropertyFilter);
    P.A(box, setting);
  }
  
  public static void writeByXML(TDataBox box, DataBoxOutputSetting outputSetting)
    throws IOException
  {
    P.A(box, outputSetting);
  }
  
  public static void readByXML(TDataBox box, String data, Element parentOfRootElement)
    throws IOException
  {
    ByteArrayInputStream in = new ByteArrayInputStream(data.getBytes("UTF-8"));
    readByXML(box, in, parentOfRootElement);
    in.close();
  }
  
  public static void readByXML(TDataBox box, InputStream in, Element parentOfRootElement)
    throws IOException
  {
    I.A(box, in, parentOfRootElement);
  }
  
  public static byte[] writeByBinary(TDataBox box, boolean compressed)
    throws IOException
  {
    if (compressed) {
      return _.B(box);
    }
    return _.A(box);
  }
  
  public static TDataBox readByBinary(boolean compressed, byte[] data)
    throws IOException, ClassNotFoundException
  {
    if (compressed) {
      return (TDataBox)_.B(data);
    }
    return (TDataBox)_.A(data);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PersistenceManager
 * JD-Core Version:    0.7.0.1
 */
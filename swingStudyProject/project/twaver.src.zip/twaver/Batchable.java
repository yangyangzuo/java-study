package twaver;

public abstract interface Batchable
{
  public abstract boolean isBatching();
  
  public abstract void startBatch();
  
  public abstract void endBatch();
  
  public abstract void addBatchListener(BatchListener paramBatchListener);
  
  public abstract void removeBatchListener(BatchListener paramBatchListener);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Batchable
 * JD-Core Version:    0.7.0.1
 */
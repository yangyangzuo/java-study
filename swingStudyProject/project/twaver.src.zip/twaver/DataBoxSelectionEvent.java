package twaver;

import java.io.Serializable;
import java.util.Collection;
import java.util.EventObject;

public class DataBoxSelectionEvent
  extends EventObject
  implements Serializable
{
  public static final int ELEMENT_ADDED = 1;
  public static final int ELEMENT_REMOVED = 2;
  public static final int ELEMENT_CLEARED = 3;
  private int A;
  private Collection B;
  
  public DataBoxSelectionEvent(DataBoxSelectionModel source, int type, Collection elements)
  {
    super(source);
    this.A = type;
    this.B = elements;
  }
  
  public DataBoxSelectionModel getBoxSelectionModel()
  {
    return (DataBoxSelectionModel)this.source;
  }
  
  public String toString()
  {
    String properties = "BoxSelectionModel=" + getSource();
    return getClass().getName() + "[" + properties + "]";
  }
  
  public int getType()
  {
    return this.A;
  }
  
  public Collection getElements()
  {
    return this.B;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSelectionEvent
 * JD-Core Version:    0.7.0.1
 */
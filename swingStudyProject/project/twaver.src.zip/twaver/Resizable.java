package twaver;

import java.awt.Dimension;

public abstract interface Resizable
  extends Element
{
  public abstract void setSize(int paramInt1, int paramInt2);
  
  public abstract void setWidthSize(int paramInt);
  
  public abstract void setHeightSize(int paramInt);
  
  public abstract void setSize(Dimension paramDimension);
  
  public abstract Dimension getSize();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Resizable
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import twaver.base.A.E.a;

public class Node
  extends BaseElement
{
  protected List allFollowers;
  protected List fromLinks;
  protected List toLinks;
  protected List allLinks;
  protected List linksSet;
  protected List loopLinks;
  protected List fromAgentLinks;
  protected List toAgentLinks;
  protected List allAgentLinks;
  protected List agentLinksSet;
  
  public Node() {}
  
  public Node(Object id)
  {
    super(id);
  }
  
  public String getUIClassID()
  {
    return "NodeUI";
  }
  
  public String getSVGUIClassID()
  {
    return "NodeSVGUI";
  }
  
  public List getAllLinks()
  {
    return this.linksSet;
  }
  
  public List getFromLinks()
  {
    return this.fromLinks;
  }
  
  public List getToLinks()
  {
    return this.toLinks;
  }
  
  void E(Link link)
  {
    if (this.allLinks == null) {
      this.allLinks = new ArrayList();
    }
    if (this.fromLinks == null) {
      this.fromLinks = new ArrayList();
    }
    this.allLinks.add(link);
    this.fromLinks.add(link);
    D();
  }
  
  void D(Link link)
  {
    if (this.allLinks == null) {
      this.allLinks = new ArrayList();
    }
    if (this.toLinks == null) {
      this.toLinks = new ArrayList();
    }
    this.allLinks.add(link);
    this.toLinks.add(link);
    D();
  }
  
  void F(Link link)
  {
    this.allLinks.remove(link);
    this.fromLinks.remove(link);
    D();
  }
  
  void G(Link link)
  {
    this.allLinks.remove(link);
    this.toLinks.remove(link);
    D();
  }
  
  void A(Follower follower)
  {
    if (this.allFollowers == null) {
      this.allFollowers = new ArrayList();
    }
    this.allFollowers.add(follower);
  }
  
  void B(Follower follower)
  {
    this.allFollowers.remove(follower);
  }
  
  public List getAllFollowers()
  {
    return this.allFollowers;
  }
  
  public boolean hasAgentLinks()
  {
    return (this.agentLinksSet != null) && (this.agentLinksSet.size() > 0);
  }
  
  public List getAllAgentLinks()
  {
    return this.agentLinksSet;
  }
  
  public List getFromAgentLinks()
  {
    return this.fromAgentLinks;
  }
  
  public List getToAgentLinks()
  {
    return this.toAgentLinks;
  }
  
  void B(Link link)
  {
    if (this.fromAgentLinks == null) {
      this.fromAgentLinks = new ArrayList();
    }
    if (this.allAgentLinks == null) {
      this.allAgentLinks = new ArrayList();
    }
    this.fromAgentLinks.add(link);
    this.allAgentLinks.add(link);
    E();
  }
  
  void C(Link link)
  {
    if (this.allAgentLinks == null) {
      this.allAgentLinks = new ArrayList();
    }
    if (this.toAgentLinks == null) {
      this.toAgentLinks = new ArrayList();
    }
    this.allAgentLinks.add(link);
    this.toAgentLinks.add(link);
    E();
  }
  
  void H(Link link)
  {
    this.allAgentLinks.remove(link);
    this.fromAgentLinks.remove(link);
    E();
  }
  
  void A(Link link)
  {
    this.allAgentLinks.remove(link);
    this.toAgentLinks.remove(link);
    E();
  }
  
  private void E()
  {
    if ((this.allAgentLinks == null) || (this.allAgentLinks.size() == 0))
    {
      this.agentLinksSet = null;
      return;
    }
    if (this.agentLinksSet == null) {
      this.agentLinksSet = new ArrayList();
    }
    Set set = new LinkedHashSet(this.allAgentLinks);
    this.agentLinksSet.clear();
    this.agentLinksSet.addAll(set);
  }
  
  private void D()
  {
    this.loopLinks = null;
    if ((this.allLinks == null) || (this.allLinks.size() == 0))
    {
      this.linksSet = null;
      return;
    }
    if (this.linksSet == null) {
      this.linksSet = new ArrayList();
    }
    Set set = new LinkedHashSet(this.allLinks);
    this.linksSet.clear();
    this.linksSet.addAll(set);
    Iterator it = this.linksSet.iterator();
    while (it.hasNext())
    {
      Link link = (Link)it.next();
      if (link.isLoop())
      {
        if (this.loopLinks == null) {
          this.loopLinks = new ArrayList();
        }
        this.loopLinks.add(link);
      }
    }
  }
  
  public void putDrawImageShape(boolean drawImageShape)
  {
    putClientProperty("draw.image.shape", drawImageShape);
  }
  
  public boolean isDrawImageShape()
  {
    return a.K(this, "draw.image.shape");
  }
  
  public List getLoopLinks()
  {
    return this.loopLinks;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Node
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Color;
import javax.swing.Icon;

public class EnumType
  implements Comparable
{
  private Comparable E = null;
  private String A = null;
  private Icon C = null;
  private Color B = null;
  private Color D = null;
  
  public EnumType(Comparable value)
  {
    this(value, value.toString());
  }
  
  public EnumType(int value, String displayName)
  {
    this(value, displayName, null);
  }
  
  public EnumType(int value, String displayName, String url)
  {
    this(value, displayName, TWaverUtil.getImageIcon(url));
  }
  
  public EnumType(int value, String displayName, Icon icon)
  {
    this(TWaverUtil.valueOf(value), displayName, icon);
  }
  
  public EnumType(Comparable value, String displayName)
  {
    this(value, displayName, null);
  }
  
  public EnumType(Comparable value, String dispalyName, String url)
  {
    this(value, dispalyName, TWaverUtil.getImageIcon(url));
  }
  
  public EnumType(Comparable value, String displayName, Icon icon)
  {
    this.E = value;
    this.A = displayName;
    this.C = icon;
  }
  
  public String toString()
  {
    return this.A;
  }
  
  public Icon getIcon()
  {
    return this.C;
  }
  
  public Object getValue()
  {
    return this.E;
  }
  
  public boolean equals(Object object)
  {
    if ((object instanceof EnumType)) {
      return ((EnumType)object).getValue().equals(this.E);
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.E.hashCode();
  }
  
  public int compareTo(Object o)
  {
    if ((o instanceof EnumType)) {
      return ((EnumType)o).E.compareTo(this.E);
    }
    return -1;
  }
  
  public Color getBackground()
  {
    return this.B;
  }
  
  public void setBackground(Color background)
  {
    this.B = background;
  }
  
  public Color getForeground()
  {
    return this.D;
  }
  
  public void setForeground(Color foreground)
  {
    this.D = foreground;
  }
  
  public String getDisplayName()
  {
    return this.A;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.EnumType
 * JD-Core Version:    0.7.0.1
 */
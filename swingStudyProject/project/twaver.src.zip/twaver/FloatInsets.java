package twaver;

import java.io.Serializable;

public class FloatInsets
  implements Cloneable, Serializable
{
  public float top;
  public float left;
  public float bottom;
  public float right;
  
  public FloatInsets() {}
  
  public FloatInsets(float top, float left, float bottom, float right)
  {
    this.top = top;
    this.left = left;
    this.bottom = bottom;
    this.right = right;
  }
  
  public boolean equals(Object obj)
  {
    if ((obj instanceof FloatInsets))
    {
      FloatInsets insets = (FloatInsets)obj;
      return (this.top == insets.top) && (this.left == insets.left) && (this.bottom == insets.bottom) && (this.right == insets.right);
    }
    return false;
  }
  
  public int hashCode()
  {
    float sum1 = this.left + this.bottom;
    float sum2 = this.right + this.top;
    float val1 = sum1 * (sum1 + 1.0F) / 2.0F + this.left;
    float val2 = sum2 * (sum2 + 1.0F) / 2.0F + this.top;
    float sum3 = val1 + val2;
    return (int)(sum3 * (sum3 + 1.0F) / 2.0F + val2);
  }
  
  public String toString()
  {
    return getClass().getName() + "[top=" + this.top + ",left=" + this.left + ",bottom=" + this.bottom + ",right=" + this.right + "]";
  }
  
  public Object clone()
  {
    try
    {
      return super.clone();
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError();
    }
  }
  
  public float getBottom()
  {
    return this.bottom;
  }
  
  public void setBottom(float bottom)
  {
    this.bottom = bottom;
  }
  
  public float getLeft()
  {
    return this.left;
  }
  
  public void setLeft(float left)
  {
    this.left = left;
  }
  
  public float getRight()
  {
    return this.right;
  }
  
  public void setRight(float right)
  {
    this.right = right;
  }
  
  public float getTop()
  {
    return this.top;
  }
  
  public void setTop(float top)
  {
    this.top = top;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.FloatInsets
 * JD-Core Version:    0.7.0.1
 */
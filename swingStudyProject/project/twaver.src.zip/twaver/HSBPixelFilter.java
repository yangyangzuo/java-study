package twaver;

import java.awt.Color;

public class HSBPixelFilter
  implements PixelFilter
{
  public static float[] RGBtoHSB(int r, int g, int b, float[] hslvals)
  {
    if (hslvals == null) {
      hslvals = new float[3];
    }
    float R = r / 255.0F;
    float G = g / 255.0F;
    float B = b / 255.0F;
    float mincolor = Math.min(R, Math.min(G, B));
    float maxcolor = Math.max(R, Math.max(G, B));
    float L;
    float L;
    float S;
    float H;
    if (mincolor == maxcolor)
    {
      float S;
      float H = S = 0.0F;
      L = mincolor;
    }
    else
    {
      float colordiff = maxcolor - mincolor;
      L = (maxcolor + mincolor) / 2.0F;
      float S;
      if (L < 0.5F) {
        S = colordiff / (maxcolor + mincolor);
      } else {
        S = colordiff / (2.0F - maxcolor - mincolor);
      }
      float H;
      if (R == maxcolor)
      {
        H = (G - B) / colordiff;
      }
      else
      {
        float H;
        if (G == maxcolor) {
          H = 2.0F + (B - R) / colordiff;
        } else {
          H = 4.0F + (R - G) / colordiff;
        }
      }
      H /= 6.0F;
      if (H < 0.0F) {
        H += 1.0F;
      }
    }
    hslvals[0] = H;
    hslvals[1] = S;
    hslvals[2] = L;
    return hslvals;
  }
  
  public static int HSBtoRGB(float h, float sl, float l)
  {
    float r = l;
    float g = l;
    float b = l;
    float v = l <= 0.5F ? l * (1.0F + sl) : l + sl - l * sl;
    if (v > 0.0F)
    {
      float m = l + l - v;
      float sv = (v - m) / v;
      h = (float)(h * 6.0D);
      int sextant = (int)h;
      float fract = h - sextant;
      float vsf = v * sv * fract;
      float mid1 = m + vsf;
      float mid2 = v - vsf;
      switch (sextant)
      {
      case 0: 
        r = v;
        g = mid1;
        b = m;
        break;
      case 1: 
        r = mid2;
        g = v;
        b = m;
        break;
      case 2: 
        r = m;
        g = v;
        b = mid1;
        break;
      case 3: 
        r = m;
        g = mid2;
        b = v;
        break;
      case 4: 
        r = mid1;
        g = m;
        b = v;
        break;
      case 5: 
        r = v;
        g = m;
        b = mid2;
      }
    }
    return new Color(r, g, b).getRGB();
  }
  
  public int filter(int pixel, Color filterColor)
  {
    int alpha = pixel >> 24 & 0xFF;
    if (alpha > 0)
    {
      int pixelR = pixel >> 16 & 0xFF;
      int pixelG = pixel >> 8 & 0xFF;
      int pixelB = pixel & 0xFF;
      float[] pixelHSB = RGBtoHSB(pixelR, pixelG, pixelB, null);
      float hue = pixelHSB[0];
      float saturation = pixelHSB[1];
      float brightness = pixelHSB[2];
      int filterColorR = filterColor.getRed();
      int filterColorG = filterColor.getGreen();
      int filterColorB = filterColor.getBlue();
      float[] filterColorHSB = RGBtoHSB(filterColorR, filterColorG, filterColorB, null);
      hue = filterColorHSB[0];
      saturation = filterColorHSB[1];
      return HSBtoRGB(hue, saturation, brightness);
    }
    return 0;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.HSBPixelFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface ResourceLocateInterceptor
  extends Interceptor
{
  public static final Object INVALID_URL = new Object();
  
  public abstract Object locate(String paramString);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ResourceLocateInterceptor
 * JD-Core Version:    0.7.0.1
 */
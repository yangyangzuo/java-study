package twaver;

import java.util.EventObject;

public class BatchEvent
  extends EventObject
{
  public BatchEvent(Object source)
  {
    super(source);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BatchEvent
 * JD-Core Version:    0.7.0.1
 */
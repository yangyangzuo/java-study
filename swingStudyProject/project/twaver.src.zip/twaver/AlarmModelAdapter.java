package twaver;

public class AlarmModelAdapter
  implements AlarmModelListener
{
  public void alarmAdded(AlarmModelEvent e) {}
  
  public void alarmRemoved(AlarmModelEvent e) {}
  
  public void alarmCleared(AlarmModelEvent e) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmModelAdapter
 * JD-Core Version:    0.7.0.1
 */
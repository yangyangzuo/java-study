package twaver;

import java.io.Serializable;

public abstract interface AlarmSeverityChangeListener
  extends Serializable
{
  public abstract boolean alarmSeverityChange();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.AlarmSeverityChangeListener
 * JD-Core Version:    0.7.0.1
 */
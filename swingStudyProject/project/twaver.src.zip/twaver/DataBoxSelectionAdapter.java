package twaver;

public class DataBoxSelectionAdapter
  implements DataBoxSelectionListener
{
  public void selectionChanged(DataBoxSelectionEvent e) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxSelectionAdapter
 * JD-Core Version:    0.7.0.1
 */
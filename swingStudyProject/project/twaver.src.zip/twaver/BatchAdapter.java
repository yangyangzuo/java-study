package twaver;

public class BatchAdapter
  implements BatchListener
{
  public void batchStarted(BatchEvent e) {}
  
  public void batchEnded(BatchEvent e) {}
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.BatchAdapter
 * JD-Core Version:    0.7.0.1
 */
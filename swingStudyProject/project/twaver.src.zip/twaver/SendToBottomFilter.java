package twaver;

public abstract interface SendToBottomFilter
  extends Filter
{
  public abstract boolean isSendToBottomable(Element paramElement);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SendToBottomFilter
 * JD-Core Version:    0.7.0.1
 */
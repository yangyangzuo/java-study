package twaver;

public abstract interface ElementAttributeVisibleFilter
  extends Filter
{
  public abstract boolean isVisible(ElementAttribute paramElementAttribute);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementAttributeVisibleFilter
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public class Port
  extends BaseEquipment
{
  public Port() {}
  
  public Port(Object id)
  {
    super(id);
  }
  
  public Port(Object id, int width, int height)
  {
    this(id);
    setSize(width, height);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Port
 * JD-Core Version:    0.7.0.1
 */
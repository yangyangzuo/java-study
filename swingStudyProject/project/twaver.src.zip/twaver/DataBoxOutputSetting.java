package twaver;

import java.io.OutputStream;
import java.util.Map;

public class DataBoxOutputSetting
{
  private boolean G = TUIManager.getBoolean("xml.output.with.businessobject");
  private boolean Q = TUIManager.getBoolean("xml.output.with.userproperty");
  private boolean L = TUIManager.getBoolean("xml.output.with.elementid");
  private boolean E = TUIManager.getBoolean("xml.output.with.layers");
  private boolean D = TUIManager.getBoolean("xml.output.with.alarm");
  private boolean F = TUIManager.getBoolean("xml.output.with.alarmid");
  private boolean B = TUIManager.getBoolean("xml.output.with.alarmstate");
  private boolean K = TUIManager.getBoolean("xml.output.with.databoxclientproperty");
  private boolean C = TUIManager.getBoolean("xml.output.with.databoxname");
  private boolean O = TUIManager.getBoolean("xml.output.with.databoxid");
  private boolean N = TUIManager.getBoolean("xml.output.with.databoxversion");
  private boolean I = TUIManager.getBoolean("xml.output.with.databoxbackground");
  private OutputStream H = null;
  private ElementPersistentFilter P = (ElementPersistentFilter)TUIManager.get("xml.output.elementfilter");
  private ClientPropertyPersistentFilter M = (ClientPropertyPersistentFilter)TUIManager.get("xml.output.clientpropertyfilter");
  private ElementDelegateInterceptor A = (ElementDelegateInterceptor)TUIManager.get("xml.output.elementdelegateinterceptor");
  private Map J = null;
  
  public Map getImages()
  {
    return this.J;
  }
  
  public void setImages(Map images)
  {
    this.J = images;
  }
  
  public ClientPropertyPersistentFilter getClientPropertyFilter()
  {
    return this.M;
  }
  
  public void setClientPropertyFilter(ClientPropertyPersistentFilter clientPropertyFilter)
  {
    this.M = clientPropertyFilter;
  }
  
  public ElementPersistentFilter getElementFilter()
  {
    return this.P;
  }
  
  public void setElementFilter(ElementPersistentFilter elementFilter)
  {
    this.P = elementFilter;
  }
  
  public OutputStream getOutputStream()
  {
    return this.H;
  }
  
  public void setOutputStream(OutputStream outputStream)
  {
    this.H = outputStream;
  }
  
  public boolean isWithAlarmId()
  {
    return this.F;
  }
  
  public void setWithAlarmId(boolean withAlarmId)
  {
    this.F = withAlarmId;
  }
  
  public boolean isWithAlarmState()
  {
    return this.B;
  }
  
  public void setWithAlarmState(boolean withAlarmState)
  {
    this.B = withAlarmState;
  }
  
  public boolean isWithDataBoxClientProperty()
  {
    return this.K;
  }
  
  public void setWithDataBoxClientProperty(boolean withDataBoxClientProperty)
  {
    this.K = withDataBoxClientProperty;
  }
  
  public boolean isWithElementId()
  {
    return this.L;
  }
  
  public void setWithElementId(boolean withElementId)
  {
    this.L = withElementId;
  }
  
  public boolean isWithLayers()
  {
    return this.E;
  }
  
  public void setWithLayers(boolean withLayers)
  {
    this.E = withLayers;
  }
  
  public boolean isWithDataBoxBackground()
  {
    return this.I;
  }
  
  public void setWithDataBoxBackground(boolean withDataBoxBackground)
  {
    this.I = withDataBoxBackground;
  }
  
  public boolean isWithDataBoxName()
  {
    return this.C;
  }
  
  public void setWithDataBoxName(boolean withDataBoxName)
  {
    this.C = withDataBoxName;
  }
  
  public boolean isWithUserProperty()
  {
    return this.Q;
  }
  
  public void setWithUserProperty(boolean withUserProperty)
  {
    this.Q = withUserProperty;
  }
  
  public boolean isWithBusinessObject()
  {
    return this.G;
  }
  
  public void setWithBusinessObject(boolean withBusinessObject)
  {
    this.G = withBusinessObject;
  }
  
  public boolean isWithAlarm()
  {
    return this.D;
  }
  
  public void setWithAlarm(boolean withAlarm)
  {
    this.D = withAlarm;
  }
  
  public ElementDelegateInterceptor getElementDelegateInterceptor()
  {
    return this.A;
  }
  
  public void setElementDelegateInterceptor(ElementDelegateInterceptor interceptor)
  {
    this.A = interceptor;
  }
  
  public boolean isWithDataBoxVersion()
  {
    return this.N;
  }
  
  public void setWithDataBoxVersion(boolean withDataBoxVersion)
  {
    this.N = withDataBoxVersion;
  }
  
  public boolean isWithDataBoxID()
  {
    return this.O;
  }
  
  public void setWithDataBoxID(boolean withDataBoxID)
  {
    this.O = withDataBoxID;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxOutputSetting
 * JD-Core Version:    0.7.0.1
 */
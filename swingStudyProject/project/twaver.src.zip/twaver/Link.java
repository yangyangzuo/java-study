package twaver;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import twaver.base.A.E.a;
import twaver.base.A.E.j;
import twaver.base.OrthogonalLinkDirectionType;

public class Link
  extends AbstractElement
{
  private boolean E = false;
  private Node I = null;
  private Node H = null;
  private Node F = null;
  private Node G = null;
  private int D = 1;
  
  public Link()
  {
    A();
  }
  
  public Link(Object id)
  {
    super(id);
    A();
  }
  
  public Link(Node from, Node to)
  {
    setFrom(from);
    setTo(to);
    A();
  }
  
  public Link(Object id, Node from, Node to)
  {
    this(id);
    setFrom(from);
    setTo(to);
    A();
  }
  
  private void A()
  {
    getClientProperties().put("attachment.position", TWaverUtil.valueOf(0));
    getClientProperties().put("border.underneath", Boolean.TRUE);
  }
  
  public int getLinkType()
  {
    return this.D;
  }
  
  public void setLinkType(int linkType)
  {
    if (this.D != linkType)
    {
      int oldValue = this.D;
      this.D = linkType;
      firePropertyChange("linkType", oldValue, this.D);
    }
  }
  
  public String getUIClassID()
  {
    return "LinkUI";
  }
  
  public String getSVGUIClassID()
  {
    return "LinkSVGUI";
  }
  
  public Node getFrom()
  {
    return this.I;
  }
  
  public void setFrom(Node from)
  {
    Object oldValue = this.I;
    if (this.I != null) {
      this.I.F(this);
    }
    this.I = from;
    if (this.I != null) {
      this.I.E(this);
    }
    checkAgentNode();
    firePropertyChange("from", oldValue, this.I);
  }
  
  public Node getTo()
  {
    return this.H;
  }
  
  public void setTo(Node to)
  {
    Object oldValue = this.H;
    if (this.H != null) {
      this.H.G(this);
    }
    this.H = to;
    if (to != null) {
      this.H.D(this);
    }
    checkAgentNode();
    firePropertyChange("to", oldValue, this.H);
  }
  
  public Node getFromAgent()
  {
    return this.F;
  }
  
  public Node getToAgent()
  {
    return this.G;
  }
  
  public boolean isLoop()
  {
    return (this.I == this.H) && (this.I != null) && (this.H != null);
  }
  
  public Point getLocation()
  {
    return null;
  }
  
  public int getWidth()
  {
    return 0;
  }
  
  public int getHeight()
  {
    return 0;
  }
  
  public Rectangle getBounds()
  {
    return null;
  }
  
  public void setLocation(double x, double y) {}
  
  public void setLocation(Point location) {}
  
  public void setLocation(Point2D.Double location) {}
  
  public Point getCenterLocation()
  {
    return null;
  }
  
  public void setCenterLocation(double x, double y) {}
  
  public void setCenterLocation(Point2D location) {}
  
  public double getX()
  {
    return -1.0D;
  }
  
  public double getY()
  {
    return -1.0D;
  }
  
  public Element copy()
  {
    return copy(null);
  }
  
  public Element copy(Object id)
  {
    return copy(id, null);
  }
  
  public Link copy(Node from, Node to)
  {
    return copy(from, to, null);
  }
  
  public Link copy(Object id, Node from, Node to)
  {
    return copy(id, from, to, null);
  }
  
  public Element copy(TDataBox box)
  {
    try
    {
      Constructor constructor = getClass().getConstructor(new Class[] { Node.class, Node.class });
      Element newElement = (Element)constructor.newInstance(new Object[] { getFrom(), getTo() });
      exportValues(newElement, box);
      return newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public Element copy(Object id, TDataBox box)
  {
    try
    {
      Constructor constructor = getClass().getConstructor(new Class[] { Object.class, Node.class, Node.class });
      Element newElement = (Element)constructor.newInstance(new Object[] { id, getFrom(), getTo() });
      exportValues(newElement, box);
      return newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public Link copy(Node from, Node to, TDataBox box)
  {
    try
    {
      Constructor constructor = getClass().getConstructor(new Class[] { Node.class, Node.class });
      Element newElement = (Element)constructor.newInstance(new Object[] { from, to });
      exportValues(newElement, box);
      return (Link)newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public Link copy(Object id, Node from, Node to, TDataBox box)
  {
    try
    {
      Constructor constructor = getClass().getConstructor(new Class[] { Object.class, Node.class, Node.class });
      Element newElement = (Element)constructor.newInstance(new Object[] { id, from, to });
      exportValues(newElement, box);
      return (Link)newElement;
    }
    catch (Exception ex)
    {
      TWaverUtil.handleError(null, ex);
    }
    return null;
  }
  
  public void checkAgentNode()
  {
    Node newFromAgent = j.B(this);
    if (this.F != newFromAgent)
    {
      Object oldValue = this.F;
      if (this.F != null) {
        this.F.H(this);
      }
      this.F = newFromAgent;
      if (this.F != null) {
        this.F.B(this);
      }
      firePropertyChange("fromAgent", oldValue, this.F);
    }
    Node newToAgent = j.A(this);
    if (this.G != newToAgent)
    {
      Object oldValue = this.G;
      if (this.G != null) {
        this.G.A(this);
      }
      this.G = newToAgent;
      if (this.G != null) {
        this.G.C(this);
      }
      firePropertyChange("toAgent", oldValue, this.G);
    }
  }
  
  public void setBundleExpand(boolean bundleExpand)
  {
    List links = j.A(this.F, this.G);
    if (links != null)
    {
      Iterator it = links.iterator();
      while (it.hasNext())
      {
        Link link = (Link)it.next();
        link.putClientProperty("link.bundle.expand", bundleExpand);
      }
    }
  }
  
  public void putClientProperty(Object key, Object value)
  {
    super.putClientProperty(key, value);
    if ((key.equals("link.dash")) && (Boolean.TRUE.equals(value))) {
      putLinkStyle("dash");
    } else if ((key.equals("link.chain")) && (Boolean.TRUE.equals(value))) {
      putLinkStyle("chain");
    }
  }
  
  public boolean isBundleAgent()
  {
    return (!isLinkBundleExpand()) && (getLinkBundleSize() > 1) && (getLinkBundleIndex() == 0);
  }
  
  public void putLinkStyle(String linkStyle)
  {
    putClientProperty("link.style", linkStyle);
  }
  
  public void putLinkColor(Color linkColor)
  {
    putClientProperty("link.color", linkColor);
  }
  
  public void putLinkOutlineColor(Color linkOutlineColor)
  {
    putClientProperty("link.outline.color", linkOutlineColor);
  }
  
  public void putLinkOutlineWidth(int linkOutlineWidth)
  {
    putClientProperty("link.outline.width", linkOutlineWidth);
  }
  
  public void putLinkWidth(int linkWidth)
  {
    putClientProperty("link.width", linkWidth);
  }
  
  public void putLinkExtend(int linkExtend)
  {
    putClientProperty("link.extend", linkExtend);
  }
  
  public void putLinkProportion(double linkProportion)
  {
    putClientProperty("link.proportion", new Double(linkProportion));
  }
  
  public void putLinkFlowingWidth(int linkFlowingWidth)
  {
    putClientProperty("link.flowing.width", linkFlowingWidth);
  }
  
  public void putLinkFromArrow(boolean linkFromArrow)
  {
    putClientProperty("link.fromArrow", linkFromArrow);
  }
  
  public void putLinkToArrow(boolean linkToArrow)
  {
    putClientProperty("link.toArrow", linkToArrow);
  }
  
  public void putLinkFlowing(boolean linkFlowing)
  {
    putClientProperty("link.flowing", linkFlowing);
  }
  
  public void putLinkFlowingConverse(boolean linkFlowingConverse)
  {
    putClientProperty("link.flowing.converse", linkFlowingConverse);
  }
  
  public void putLinkBlinking(boolean linkBlinking)
  {
    putClientProperty("link.blinking", linkBlinking);
  }
  
  public void putLinkBlinkingColor(Color linkBlinkingColor)
  {
    putClientProperty("link.blinking.color", linkBlinkingColor);
  }
  
  public void putLinkFlowingColor(Color linkFlowingColor)
  {
    putClientProperty("link.flowing.color", linkFlowingColor);
  }
  
  public void putLinkBundleExpand(boolean linkBundleExpand)
  {
    putClientProperty("link.bundle.expand", linkBundleExpand);
  }
  
  public void putLinkBundleIndex(int linkBundleIndex)
  {
    putClientProperty("link.bundle.index", linkBundleIndex);
  }
  
  public void putLinkBundleSize(int linkBundleSize)
  {
    putClientProperty("link.bundle.size", linkBundleSize);
  }
  
  public void putLink3D(boolean link3D)
  {
    putClientProperty("link.3d", link3D);
  }
  
  public void putLinkLabelRotatable(boolean linkLabelRotatable)
  {
    putClientProperty("link.label.rotatable", linkLabelRotatable);
  }
  
  public void putLinkAntialias(boolean linkAntialias)
  {
    putClientProperty("link.antialias", linkAntialias);
  }
  
  public void putLinkFromArrowCenter(boolean linkFromArrowCenter)
  {
    putClientProperty("link.from.arrow.center", linkFromArrowCenter);
  }
  
  public void putLinkToArrowCenter(boolean linkToArrowCenter)
  {
    putClientProperty("link.to.arrow.center", linkToArrowCenter);
  }
  
  public void putLinkFromArrowStyle(int linkFromArrowStyle)
  {
    putClientProperty("link.from.arrow.style", linkFromArrowStyle);
  }
  
  public void putLinkToArrowStyle(int linkToArrowStyle)
  {
    putClientProperty("link.to.arrow.style", linkToArrowStyle);
  }
  
  public void putLinkFromArrowColor(Color linkFromArrowColor)
  {
    putClientProperty("link.from.arrow.color", linkFromArrowColor);
  }
  
  public void putLinkToArrowColor(Color linkToArrowColor)
  {
    putClientProperty("link.to.arrow.color", linkToArrowColor);
  }
  
  public void putLinkFromArrowOutline(boolean linkFromArrowOutline)
  {
    putClientProperty("link.from.arrow.outline", linkFromArrowOutline);
  }
  
  public void putLinkToArrowOutline(boolean linkToArrowOutline)
  {
    putClientProperty("link.to.arrow.outline", linkToArrowOutline);
  }
  
  public void putLinkFromArrowOutlineColor(Color linkFromArrowOutlineColor)
  {
    putClientProperty("link.from.arrow.outline.color", linkFromArrowOutlineColor);
  }
  
  public void putLinkToArrowOutlineColor(Color linkToArrowOutlineColor)
  {
    putClientProperty("link.to.arrow.outline.color", linkToArrowOutlineColor);
  }
  
  public void putLinkHollow(boolean linkHollow)
  {
    putClientProperty("link.style", linkHollow);
  }
  
  public void putLinkHandlerPosition(int linkHandlerPosition)
  {
    putClientProperty("link.handler.position", linkHandlerPosition);
  }
  
  public void putLinkHandlerXOffset(int linkHandlerXOffset)
  {
    putClientProperty("link.handler.xoffset", linkHandlerXOffset);
  }
  
  public void putLinkHandlerYOffset(int linkHandlerYOffset)
  {
    putClientProperty("link.handler.yoffset", linkHandlerYOffset);
  }
  
  public void putLinkHandlerVisible(boolean linkHandlerVisible)
  {
    putClientProperty("link.handler.visible", linkHandlerVisible);
  }
  
  public void putLinkFromArrowXOffset(int linkFromArrowXOffset)
  {
    putClientProperty("link.from.arrow.xoffset", linkFromArrowXOffset);
  }
  
  public void putLinkFromArrowYOffset(int linkFromArrowYOffset)
  {
    putClientProperty("link.from.arrow.yoffset", linkFromArrowYOffset);
  }
  
  public void putLinkToArrowXOffset(int linkToArrowXOffset)
  {
    putClientProperty("link.to.arrow.xoffset", linkToArrowXOffset);
  }
  
  public void putLinkToArrowYOffset(int linkToArrowYOffset)
  {
    putClientProperty("link.to.arrow.yoffset", linkToArrowYOffset);
  }
  
  public void putLinkToPosition(int linkToPosition)
  {
    putClientProperty("link.to.position", linkToPosition);
  }
  
  public void putLinkFromPosition(int linkFromPosition)
  {
    putClientProperty("link.from.position", linkFromPosition);
  }
  
  public void putLinkToXOffset(int linkToXOffset)
  {
    putClientProperty("link.to.xoffset", linkToXOffset);
  }
  
  public void putLinkToYOffset(int linkToYOffset)
  {
    putClientProperty("link.to.yoffset", linkToYOffset);
  }
  
  public void putLinkFromXOffset(int linkFromXOffset)
  {
    putClientProperty("link.from.xoffset", linkFromXOffset);
  }
  
  public void putLinkFromYOffset(int linkFromYOffset)
  {
    putClientProperty("link.from.yoffset", linkFromYOffset);
  }
  
  public void putLinkOrthogonalDirection(OrthogonalLinkDirectionType direction)
  {
    putClientProperty("link.orthogonal.direction", direction);
  }
  
  public String getLinkStyle()
  {
    return a.Q(this, "link.style");
  }
  
  public boolean isLinkHollow()
  {
    return a.K(this, "link.hollow");
  }
  
  public Color getLinkColor()
  {
    return a.P(this, "link.color");
  }
  
  public Color getLinkOutlineColor()
  {
    return a.P(this, "link.outline.color");
  }
  
  public int getLinkOutlineWidth()
  {
    return a.J(this, "link.outline.width");
  }
  
  public int getLinkWidth()
  {
    return a.J(this, "link.width");
  }
  
  public int getLinkExtend()
  {
    return a.J(this, "link.extend");
  }
  
  public double getLinkProportion()
  {
    double proportion = a.M(this, "link.proportion");
    if ((proportion < 0.0D) || (proportion > 1.0D)) {
      return 0.5D;
    }
    return proportion;
  }
  
  public int getLinkFlowingWidth()
  {
    return a.J(this, "link.flowing.width");
  }
  
  public boolean isLinkFromArrow()
  {
    return a.K(this, "link.fromArrow");
  }
  
  public boolean isLinkToArrow()
  {
    return a.K(this, "link.toArrow");
  }
  
  public boolean isLinkFlowing()
  {
    return a.K(this, "link.flowing");
  }
  
  public boolean isLinkFlowingConverse()
  {
    return a.K(this, "link.flowing.converse");
  }
  
  public boolean isLinkBlinking()
  {
    return a.K(this, "link.blinking");
  }
  
  public Color getLinkBlinkingColor()
  {
    return a.P(this, "link.blinking.color");
  }
  
  public boolean isLink3D()
  {
    return a.K(this, "link.3d");
  }
  
  public Color getLinkFlowingColor()
  {
    return a.P(this, "link.flowing.color");
  }
  
  public boolean isLinkBundleExpand()
  {
    return a.K(this, "link.bundle.expand");
  }
  
  public int getLinkBundleIndex()
  {
    return a.J(this, "link.bundle.index");
  }
  
  public int getLinkBundleSize()
  {
    return a.J(this, "link.bundle.size");
  }
  
  public boolean isLinkLabelRotatable()
  {
    return a.K(this, "link.label.rotatable");
  }
  
  public boolean isLinkAntialias()
  {
    return a.K(this, "link.antialias");
  }
  
  public boolean isLinkFromArrowCenter()
  {
    return a.K(this, "link.from.arrow.center");
  }
  
  public boolean isLinkToArrowCenter()
  {
    return a.K(this, "link.to.arrow.center");
  }
  
  public int getLinkFromArrowStyle()
  {
    return a.J(this, "link.from.arrow.style");
  }
  
  public int getLinkToArrowStyle()
  {
    return a.J(this, "link.to.arrow.style");
  }
  
  public Color getLinkFromArrowColor()
  {
    return a.P(this, "link.from.arrow.color");
  }
  
  public Color getLinkToArrowColor()
  {
    return a.P(this, "link.to.arrow.color");
  }
  
  public Color getLinkFromArrowOutlineColor()
  {
    return a.P(this, "link.from.arrow.outline.color");
  }
  
  public Color getLinkToArrowOutlineColor()
  {
    return a.P(this, "link.to.arrow.outline.color");
  }
  
  public boolean isLinkFromArrowOutline()
  {
    return a.K(this, "link.from.arrow.outline");
  }
  
  public boolean isLinkToArrowOutline()
  {
    return a.K(this, "link.to.arrow.outline");
  }
  
  public int getLinkHandlerPosition()
  {
    return a.J(this, "link.handler.position");
  }
  
  public int getLinkToPosition()
  {
    return a.J(this, "link.to.position");
  }
  
  public int getLinkFromPosition()
  {
    return a.J(this, "link.from.position");
  }
  
  public int getLinkHandlerXOffset()
  {
    return a.J(this, "link.handler.xoffset");
  }
  
  public int getLinkHandlerYOffset()
  {
    return a.J(this, "link.handler.yoffset");
  }
  
  public boolean isLinkHandlerVisible()
  {
    return a.K(this, "link.handler.visible");
  }
  
  public int getLinkFromArrowXOffset()
  {
    return a.J(this, "link.from.arrow.xoffset");
  }
  
  public int getLinkFromArrowYOffset()
  {
    return a.J(this, "link.from.arrow.yoffset");
  }
  
  public int getLinkToArrowXOffset()
  {
    return a.J(this, "link.to.arrow.xoffset");
  }
  
  public int getLinkToArrowYOffset()
  {
    return a.J(this, "link.to.arrow.yoffset");
  }
  
  public int getLinkToXOffset()
  {
    return a.J(this, "link.to.xoffset");
  }
  
  public int getLinkToYOffset()
  {
    return a.J(this, "link.to.yoffset");
  }
  
  public int getLinkFromXOffset()
  {
    return a.J(this, "link.from.xoffset");
  }
  
  public int getLinkFromYOffset()
  {
    return a.J(this, "link.from.yoffset");
  }
  
  public OrthogonalLinkDirectionType getLinkOrthogonalDirection()
  {
    Object value = getClientProperty("link.orthogonal.direction");
    if ((value instanceof OrthogonalLinkDirectionType)) {
      return (OrthogonalLinkDirectionType)value;
    }
    return (OrthogonalLinkDirectionType)TUIManager.get("link.orthogonal.direction");
  }
  
  public boolean isShapeFrozen()
  {
    return this.E;
  }
  
  public void setShapeFrozen(boolean shapeFrozen)
  {
    if (this.E != shapeFrozen)
    {
      boolean oldValue = this.E;
      this.E = shapeFrozen;
      firePropertyChange("shapeFrozen", oldValue, this.E);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Link
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.awt.Insets;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.util.Map;
import twaver.base.A.E.E;
import twaver.base.A.E.a;
import twaver.base.Direction;

public class Card
  extends BaseEquipment
{
  private int s = 0;
  private int r = 0;
  
  public Card()
  {
    S();
  }
  
  public Card(Object id)
  {
    super(id);
    S();
  }
  
  public String getUIClassID()
  {
    return "CardUI";
  }
  
  public String getSVGUIClassID()
  {
    return "CardSVGUI";
  }
  
  public boolean isAdjustToBottom()
  {
    return E.A(this);
  }
  
  protected void hostPropertyChange(PropertyChangeEvent evt)
  {
    if (a.C(evt.getPropertyName())) {
      adjustBounds();
    }
  }
  
  private void S()
  {
    setSize(30, 100);
    getClientProperties().put("border.insets", TWaverUtil.valueOf(-2));
    getClientProperties().put("label.highlightable", Boolean.FALSE);
    getClientProperties().put("label.position", TWaverUtil.valueOf(1));
    getClientProperties().put("label.orientation", TWaverUtil.valueOf(3));
  }
  
  public void adjustBounds()
  {
    Node host = getHost();
    if ((host instanceof Slot))
    {
      Slot slot = (Slot)host;
      Rectangle b1 = slot.getEquipBoundsByIndex(this.s);
      Rectangle b2 = slot.getEquipBoundsByIndex(this.s + this.r);
      Rectangle bounds;
      Rectangle bounds;
      if ((b1 != null) && (b2 != null))
      {
        b1.add(b2);
        bounds = b1;
      }
      else
      {
        bounds = slot.getEquipBoundsByIndex(0);
      }
      if (bounds != null)
      {
        FloatInsets floatInsets = getCardExtendPercent();
        if (floatInsets != null)
        {
          Rectangle b0 = slot.getEquipBoundsByIndex(0);
          if (floatInsets.top != 0.0F)
          {
            float extend = b0.height * floatInsets.top;
            Rectangle tmp118_117 = bounds;
            tmp118_117.y = ((int)(tmp118_117.y - extend));
            Rectangle tmp131_130 = bounds;
            tmp131_130.height = ((int)(tmp131_130.height + extend));
          }
          if (floatInsets.bottom != 0.0F)
          {
            float extend = b0.height * floatInsets.bottom;
            Rectangle tmp168_167 = bounds;
            tmp168_167.height = ((int)(tmp168_167.height + extend));
          }
          if (floatInsets.left != 0.0F)
          {
            float extend = b0.width * floatInsets.left;
            Rectangle tmp205_204 = bounds;
            tmp205_204.x = ((int)(tmp205_204.x - extend));
            Rectangle tmp218_217 = bounds;
            tmp218_217.width = ((int)(tmp218_217.width + extend));
          }
          if (floatInsets.right != 0.0F)
          {
            float extend = b0.width * floatInsets.right;
            Rectangle tmp255_254 = bounds;
            tmp255_254.width = ((int)(tmp255_254.width + extend));
          }
        }
        Insets insets = getCardExtendPixel();
        if (insets != null)
        {
          if (insets.top != 0)
          {
            bounds.y -= insets.top;
            bounds.height += insets.top;
          }
          if (insets.bottom != 0) {
            bounds.height += insets.bottom;
          }
          if (insets.left != 0)
          {
            bounds.x -= insets.left;
            bounds.width += insets.left;
          }
          if (insets.right != 0) {
            bounds.width += insets.right;
          }
        }
        setLocation(bounds.x, bounds.y);
        setSize(bounds.width, bounds.height);
      }
    }
  }
  
  public void putClientProperty(Object key, Object value)
  {
    if ("label.direction".equals(key))
    {
      putLabelPosition(1);
      if (Direction.VERTICAL.equals(value)) {
        putLabelOrientation(3);
      } else {
        putLabelOrientation(1);
      }
    }
    super.putClientProperty(key, value);
    if (key.toString().startsWith("card.extend.")) {
      adjustBounds();
    }
  }
  
  public void putLabelDirection(Direction direction)
  {
    putClientProperty("label.direction", direction);
  }
  
  public void putCardBoltTop(boolean cardBoltTop)
  {
    putClientProperty("card.bolt.top", cardBoltTop);
  }
  
  public void putCardBoltBottom(boolean cardBoltBottom)
  {
    putClientProperty("card.bolt.bottom", cardBoltBottom);
  }
  
  public void putCardBoltLeft(boolean cardBoltLeft)
  {
    putClientProperty("card.bolt.left", cardBoltLeft);
  }
  
  public void putCardBoltRight(boolean cardBoltRight)
  {
    putClientProperty("card.bolt.right", cardBoltRight);
  }
  
  public void putCardExtendPixel(Insets cardExtendPixel)
  {
    putClientProperty("card.extend.pixel", cardExtendPixel);
  }
  
  public void putCardExtendPercent(FloatInsets cardExtendPercent)
  {
    putClientProperty("card.extend.percent", cardExtendPercent);
  }
  
  public boolean isCardBoltTop()
  {
    return a.K(this, "card.bolt.top");
  }
  
  public boolean isCardBoltBottom()
  {
    return a.K(this, "card.bolt.bottom");
  }
  
  public boolean isCardBoltLeft()
  {
    return a.K(this, "card.bolt.left");
  }
  
  public boolean isCardBoltRight()
  {
    return a.K(this, "card.bolt.right");
  }
  
  public Insets getCardExtendPixel()
  {
    return a.B(this, "card.extend.pixel");
  }
  
  public FloatInsets getCardExtendPercent()
  {
    return a.N(this, "card.extend.percent");
  }
  
  public int getSpanCount()
  {
    return this.r;
  }
  
  public void setSpanCount(int spanCount)
  {
    if (this.r != spanCount)
    {
      int oldValue = this.r;
      this.r = spanCount;
      firePropertyChange("spanCount", oldValue, this.r);
      adjustBounds();
    }
  }
  
  public int getStartIndex()
  {
    return this.s;
  }
  
  public void setStartIndex(int startIndex)
  {
    if (this.s != startIndex)
    {
      int oldValue = this.s;
      this.s = startIndex;
      firePropertyChange("startIndex", oldValue, this.s);
      adjustBounds();
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Card
 * JD-Core Version:    0.7.0.1
 */
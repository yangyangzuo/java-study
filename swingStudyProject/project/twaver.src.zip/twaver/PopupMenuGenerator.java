package twaver;

import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;

public abstract interface PopupMenuGenerator
{
  public abstract JPopupMenu generate(TView paramTView, MouseEvent paramMouseEvent);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.PopupMenuGenerator
 * JD-Core Version:    0.7.0.1
 */
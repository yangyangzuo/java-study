package twaver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DataBoxQuickFinder
{
  protected TDataBox box = null;
  protected String propertyName = null;
  protected Class elementClass = null;
  protected Generator keyGenerator = null;
  private Map B = new HashMap();
  private DataBoxListener C = new DataBoxListener()
  {
    public void elementAdded(DataBoxEvent e)
    {
      DataBoxQuickFinder.this.addElement(e.getElement());
    }
    
    public void elementRemoved(DataBoxEvent e)
    {
      DataBoxQuickFinder.this.removeElement(e.getElement());
    }
    
    public void elementsCleared(DataBoxEvent e)
    {
      DataBoxQuickFinder.this.clear();
    }
  };
  private PropertyChangeListener A = new SerializablePropertyChangeListener()
  {
    public void propertyChange(PropertyChangeEvent e)
    {
      DataBoxQuickFinder.this.elementPropertyChange(e);
    }
  };
  
  public DataBoxQuickFinder(TDataBox box, String propertyName)
  {
    this(box, propertyName, null);
  }
  
  public DataBoxQuickFinder(TDataBox box, String propertyName, Class elementClass)
  {
    this(box, propertyName, elementClass, null);
  }
  
  public DataBoxQuickFinder(TDataBox box, String propertyName, Class elementClass, Generator keyGenerator)
  {
    this.box = box;
    this.propertyName = propertyName;
    this.keyGenerator = keyGenerator;
    if (elementClass == null) {
      this.elementClass = Element.class;
    } else {
      this.elementClass = elementClass;
    }
    Iterator it = box.iterator();
    while (it.hasNext())
    {
      Element element = (Element)it.next();
      addElement(element);
    }
    this.box.B(this.C);
    this.box.B(this.A);
  }
  
  public List find(Object value)
  {
    return (List)this.B.get(value);
  }
  
  public Element findFirst(Object value)
  {
    List list = (List)this.B.get(value);
    if ((list != null) && (list.size() > 0)) {
      return (Element)list.get(0);
    }
    return null;
  }
  
  protected void addElement(Element element)
  {
    if (!interested(element)) {
      return;
    }
    Object key = getKey(element);
    List list = find(key);
    if (list == null)
    {
      list = new ArrayList(1);
      this.B.put(key, list);
    }
    list.add(element);
  }
  
  protected void removeElement(Element element)
  {
    if (!interested(element)) {
      return;
    }
    Object key = getKey(element);
    List list = find(key);
    if (list != null)
    {
      list.remove(element);
      if (list.isEmpty()) {
        this.B.remove(key);
      }
    }
  }
  
  protected void clear()
  {
    this.B.clear();
  }
  
  protected void elementPropertyChange(PropertyChangeEvent e)
  {
    if (this.propertyName == null) {
      return;
    }
    String name = e.getPropertyName();
    if (name.equals(this.propertyName))
    {
      Element element = (Element)e.getSource();
      Object oldKey = e.getOldValue();
      List list = find(oldKey);
      if (list != null) {
        list.remove(element);
      }
      addElement(element);
      return;
    }
  }
  
  public void dispose()
  {
    this.box.A(this.C);
    this.box.A(this.A);
    this.propertyName = null;
    this.keyGenerator = null;
    this.B = null;
    this.box = null;
    this.elementClass = null;
    this.C = null;
    this.A = null;
  }
  
  public boolean interested(Element element)
  {
    return this.elementClass.isInstance(element);
  }
  
  protected Object getKey(Element element)
  {
    if (this.keyGenerator == null) {
      return null;
    }
    return this.keyGenerator.generate(element);
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.DataBoxQuickFinder
 * JD-Core Version:    0.7.0.1
 */
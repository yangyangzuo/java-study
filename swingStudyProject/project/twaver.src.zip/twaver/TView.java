package twaver;

import java.io.Serializable;

public abstract interface TView
  extends Serializable
{
  public abstract void setDataBox(TDataBox paramTDataBox);
  
  public abstract TDataBox getDataBox();
  
  public abstract void updateTViewUI();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TView
 * JD-Core Version:    0.7.0.1
 */
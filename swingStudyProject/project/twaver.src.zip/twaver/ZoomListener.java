package twaver;

public abstract interface ZoomListener
{
  public abstract void zoomChanged(double paramDouble1, double paramDouble2);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ZoomListener
 * JD-Core Version:    0.7.0.1
 */
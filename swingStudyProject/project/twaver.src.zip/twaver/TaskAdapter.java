package twaver;

public abstract class TaskAdapter
  implements Task
{
  protected int interval = 1000;
  
  public int getInterval()
  {
    return this.interval;
  }
  
  public void setInterval(int interval)
  {
    this.interval = interval;
  }
  
  public boolean interested()
  {
    return true;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.TaskAdapter
 * JD-Core Version:    0.7.0.1
 */
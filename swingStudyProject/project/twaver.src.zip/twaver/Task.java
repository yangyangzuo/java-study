package twaver;

public abstract interface Task
{
  public abstract void run(long paramLong);
  
  public abstract int getInterval();
  
  public abstract void setInterval(int paramInt);
  
  public abstract boolean interested();
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Task
 * JD-Core Version:    0.7.0.1
 */
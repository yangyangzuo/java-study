package twaver;

import java.awt.geom.Point2D.Double;
import java.io.Serializable;

public class GeoCoordinate
  extends Point2D.Double
  implements Serializable
{
  public GeoCoordinate()
  {
    this(0.0D, 0.0D);
  }
  
  public GeoCoordinate(double longitude, double latitude)
  {
    super(longitude, latitude);
  }
  
  public double getLatitude()
  {
    return getY();
  }
  
  public void setLatitude(double lat)
  {
    setLocation(this.x, lat);
  }
  
  public void setLongitude(double lon)
  {
    setLocation(lon, this.y);
  }
  
  public double getLongitude()
  {
    return getX();
  }
  
  public boolean equals(Object target)
  {
    boolean result = false;
    if ((target instanceof GeoCoordinate))
    {
      GeoCoordinate tc = (GeoCoordinate)target;
      result = (tc.getLongitude() == getLongitude()) && (tc.getLatitude() == getLatitude());
    }
    return result;
  }
  
  public String toString()
  {
    return "(" + getX() + "," + getY() + ")";
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.GeoCoordinate
 * JD-Core Version:    0.7.0.1
 */
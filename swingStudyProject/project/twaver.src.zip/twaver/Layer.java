package twaver;

import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class Layer
  implements Serializable
{
  public static final String PROPERTY_ID = "id";
  public static final String PROPERTY_NAME = "name";
  public static final String PROPERTY_DESCRIPTION = "description";
  public static final String PROPERTY_VISIBLE = "visible";
  public static final String PROPERTY_SELECTABLE = "selectable";
  public static final String PROPERTY_MOVABLE = "movable";
  public static final String PROPERTY_RESIZABLE = "resizable";
  public static final String PROPERTY_ALPHA = "alpha";
  private final Object H;
  private String J = null;
  private boolean B = true;
  private boolean F = true;
  private boolean C = true;
  private boolean E = true;
  private float D = 1.0F;
  private String I = null;
  private PropertyChangeSupport A = new PropertyChangeSupport(this);
  private Map G = new LinkedHashMap();
  
  public Layer()
  {
    this.H = TWaverUtil.getIdentifier(this);
  }
  
  public Layer(Object id)
  {
    this.H = id;
  }
  
  public Layer(Object id, String name)
  {
    this.H = id;
    this.J = name;
  }
  
  public Layer(Object id, String name, String description, boolean visible)
  {
    this.H = id;
    this.J = name;
    this.I = description;
    this.B = visible;
  }
  
  public void exportValues(Layer otherLayer)
  {
    otherLayer.setName(getName());
    otherLayer.setDescription(getDescription());
    otherLayer.setVisible(isVisible());
    otherLayer.setMovable(isMovable());
    otherLayer.setSelectable(isSelectable());
    otherLayer.setResizable(isResizable());
    otherLayer.setAlpha(getAlpha());
    Iterator it = getClientProperties().keySet().iterator();
    while (it.hasNext())
    {
      Object propertyKey = it.next();
      Object value = getClientProperty(propertyKey);
      otherLayer.putClientProperty(propertyKey, value);
    }
  }
  
  public PropertyChangeSupport getPropertyChangeSupport()
  {
    return this.A;
  }
  
  public Object getClientProperty(Object key)
  {
    return this.G.get(key);
  }
  
  public void putClientProperty(Object key, Object value)
  {
    Object oldValue = getClientProperty(key);
    Object newValue = value;
    if (oldValue != newValue)
    {
      this.G.put(key, value);
      String propertyName = "CP:" + key.toString();
      this.A.firePropertyChange(propertyName, oldValue, newValue);
    }
  }
  
  public Map getClientProperties()
  {
    return this.G;
  }
  
  public String getName()
  {
    return this.J;
  }
  
  public void setName(String name)
  {
    String oldValue = this.J;
    this.J = name;
    getPropertyChangeSupport().firePropertyChange("name", oldValue, name);
  }
  
  public boolean isVisible()
  {
    return this.B;
  }
  
  public void setVisible(boolean visible)
  {
    boolean oldValue = this.B;
    this.B = visible;
    getPropertyChangeSupport().firePropertyChange("visible", oldValue, visible);
  }
  
  public Object getID()
  {
    return this.H;
  }
  
  public String getDescription()
  {
    return this.I;
  }
  
  public void setDescription(String description)
  {
    String oldValue = this.I;
    this.I = description;
    getPropertyChangeSupport().firePropertyChange("description", oldValue, description);
  }
  
  public float getAlpha()
  {
    return this.D;
  }
  
  public void setAlpha(float alpha)
  {
    if ((alpha != this.D) && (alpha >= 0.0F) && (alpha <= 1.0F))
    {
      float oldValue = this.D;
      this.D = alpha;
      getPropertyChangeSupport().firePropertyChange("alpha", new Float(oldValue), new Float(alpha));
    }
  }
  
  public boolean isMovable()
  {
    return this.C;
  }
  
  public void setMovable(boolean movable)
  {
    boolean oldValue = this.C;
    this.C = movable;
    getPropertyChangeSupport().firePropertyChange("movable", oldValue, movable);
  }
  
  public boolean isSelectable()
  {
    return this.F;
  }
  
  public void setSelectable(boolean selectable)
  {
    boolean oldValue = this.F;
    this.F = selectable;
    getPropertyChangeSupport().firePropertyChange("selectable", oldValue, selectable);
  }
  
  public boolean isResizable()
  {
    return this.E;
  }
  
  public void setResizable(boolean resizable)
  {
    boolean oldValue = this.E;
    this.E = resizable;
    getPropertyChangeSupport().firePropertyChange("resizable", oldValue, resizable);
  }
  
  public String toString()
  {
    return getName();
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.Layer
 * JD-Core Version:    0.7.0.1
 */
package twaver;

import java.beans.PropertyChangeListener;
import java.io.Serializable;

public abstract interface SerializablePropertyChangeListener
  extends PropertyChangeListener, Serializable
{}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SerializablePropertyChangeListener
 * JD-Core Version:    0.7.0.1
 */
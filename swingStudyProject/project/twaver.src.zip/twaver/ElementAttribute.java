package twaver;

import java.awt.Color;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import twaver.base.A.E.H;
import twaver.base.A.F.A.A;

public class ElementAttribute
{
  private String N = "system";
  private List B = null;
  private String f = null;
  private Boolean S = null;
  private boolean U = false;
  private String F = null;
  private String Q = null;
  private Class e = null;
  private String I = null;
  private String _ = null;
  private String L = null;
  private String K = null;
  private String b = null;
  private boolean W = true;
  private int V = 75;
  private int T = -1;
  private int Y = -1;
  private Comparator J = A.A();
  private Icon Z = null;
  private Color P = null;
  private Color G = null;
  private String X = null;
  private int E = 2;
  private boolean H = true;
  private boolean C = true;
  private boolean D = true;
  private boolean R = false;
  private boolean d = false;
  private int M = -1;
  private int A = -1;
  private int O = -1;
  private int c = -1;
  private Map a = null;
  
  public String getName()
  {
    return this.f;
  }
  
  public void setName(String name)
  {
    this.f = name;
  }
  
  public Class getJavaClass()
  {
    return this.e;
  }
  
  public void setJavaClass(Class javaClass)
  {
    this.e = javaClass;
  }
  
  public boolean isClientProperty()
  {
    if (this.S != null) {
      return this.S.booleanValue();
    }
    return this.F != null;
  }
  
  /**
   * @deprecated
   */
  public void setClientProperty(boolean clientProperty)
  {
    this.S = Boolean.valueOf(clientProperty);
  }
  
  public TableCellRenderer getRenderer()
  {
    if (this._ != null) {
      return (TableCellRenderer)H.B(this._);
    }
    return null;
  }
  
  public TableCellEditor getEditor()
  {
    if (this.L != null) {
      return (TableCellEditor)H.B(this.L);
    }
    return null;
  }
  
  public String getReadMethod()
  {
    return this.K;
  }
  
  public void setReadMethod(String readMethod)
  {
    this.K = readMethod;
  }
  
  public String getWriteMethod()
  {
    return this.b;
  }
  
  public void setWriteMethod(String writeMethod)
  {
    this.b = writeMethod;
  }
  
  public boolean isEditable()
  {
    return this.W;
  }
  
  public void setEditable(boolean editable)
  {
    this.W = editable;
  }
  
  public boolean isEnableBatch()
  {
    return this.H;
  }
  
  public void setEnableBatch(boolean enableBatch)
  {
    this.H = enableBatch;
  }
  
  public String getClientPropertyKey()
  {
    return this.F;
  }
  
  public void setClientPropertyKey(String clientPropertyKey)
  {
    this.F = clientPropertyKey;
  }
  
  public String getDisplayName()
  {
    return this.I;
  }
  
  public void setDisplayName(String displayName)
  {
    this.I = displayName;
  }
  
  public String getCategoryName()
  {
    return this.N;
  }
  
  public void setCategoryName(String categoryName)
  {
    this.N = categoryName;
  }
  
  public Comparator getSortComparator()
  {
    return this.J;
  }
  
  public void setSortComparator(Comparator sortComparator)
  {
    this.J = sortComparator;
  }
  
  public int getWidth()
  {
    return this.V;
  }
  
  public void setWidth(int width)
  {
    this.V = width;
  }
  
  public int getMinWidth()
  {
    return this.T;
  }
  
  public void setMinWidth(int minWidth)
  {
    this.T = minWidth;
  }
  
  public int getMaxWidth()
  {
    return this.Y;
  }
  
  public void setMaxWidth(int maxWidth)
  {
    this.Y = maxWidth;
  }
  
  public Icon getIcon()
  {
    return this.Z;
  }
  
  public void setIcon(Icon icon)
  {
    this.Z = icon;
  }
  
  public Color getFillColor()
  {
    return this.G;
  }
  
  public void setFillColor(Color fillColor)
  {
    this.G = fillColor;
  }
  
  public Color getForeColor()
  {
    return this.P;
  }
  
  public void setForeColor(Color foreColor)
  {
    this.P = foreColor;
  }
  
  public String getDescription()
  {
    return this.X;
  }
  
  public void setDescription(String description)
  {
    this.X = description;
  }
  
  public Map getParams()
  {
    return this.a;
  }
  
  public void setParams(Map params)
  {
    this.a = params;
  }
  
  public Object getParam(Object key)
  {
    return this.a == null ? null : this.a.get(key);
  }
  
  public void addParam(Object key, Object value)
  {
    if (this.a == null) {
      this.a = new HashMap();
    }
    this.a.put(key, value);
  }
  
  public String getEditorClass()
  {
    return this.L;
  }
  
  public void setEditorClass(String editorClass)
  {
    this.L = editorClass;
  }
  
  public String getRendererClass()
  {
    return this._;
  }
  
  public void setRendererClass(String rendererClass)
  {
    this._ = rendererClass;
  }
  
  public String getKey()
  {
    if (this.Q != null) {
      return "UP:" + this.Q;
    }
    if (isClientProperty())
    {
      if (isBusinessProperty()) {
        return "BOCP:" + getClientPropertyKey();
      }
      return "CP:" + getClientPropertyKey();
    }
    if (isBusinessProperty()) {
      return "BOJP:" + getName();
    }
    return getName();
  }
  
  public List getCategoryNames()
  {
    return this.B;
  }
  
  public void setCategoryNames(List categoryNames)
  {
    this.B = categoryNames;
    setCategoryName((String)categoryNames.get(categoryNames.size() - 1));
  }
  
  public int getFontStyle()
  {
    return this.E;
  }
  
  public void setFontStyle(int fontStyle)
  {
    this.E = fontStyle;
  }
  
  public boolean isSortable()
  {
    return this.C;
  }
  
  public void setSortable(boolean sortable)
  {
    this.C = sortable;
  }
  
  public boolean isVisible()
  {
    return this.D;
  }
  
  public void setVisible(boolean visible)
  {
    this.D = visible;
  }
  
  public boolean isExtraWidthAssignable()
  {
    return this.d;
  }
  
  public void setExtraWidthAssignable(boolean extraWidthAssignable)
  {
    this.d = extraWidthAssignable;
  }
  
  public int getMaxPackWidth()
  {
    return this.A;
  }
  
  public void setMaxPackWidth(int maxPackWidth)
  {
    this.A = maxPackWidth;
  }
  
  public int getMinPackWidth()
  {
    return this.M;
  }
  
  public void setMinPackWidth(int minPackWidth)
  {
    this.M = minPackWidth;
  }
  
  public boolean isRowPackParticipable()
  {
    return this.R;
  }
  
  public void setRowPackParticipable(boolean rowPackParticipable)
  {
    this.R = rowPackParticipable;
  }
  
  public boolean isBusinessProperty()
  {
    return this.U;
  }
  
  public void setBusinessProperty(boolean businessProperty)
  {
    this.U = businessProperty;
  }
  
  public String getUserPropertyKey()
  {
    return this.Q;
  }
  
  public void setUserPropertyKey(String userPropertyKey)
  {
    this.Q = userPropertyKey;
  }
  
  public int getMaxPackHeight()
  {
    return this.c;
  }
  
  public void setMaxPackHeight(int maxPackHeight)
  {
    this.c = maxPackHeight;
  }
  
  public int getMinPackHeight()
  {
    return this.O;
  }
  
  public void setMinPackHeight(int minPackHeight)
  {
    this.O = minPackHeight;
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementAttribute
 * JD-Core Version:    0.7.0.1
 */
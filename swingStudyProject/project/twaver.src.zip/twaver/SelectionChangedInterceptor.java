package twaver;

import java.util.Collection;

public abstract interface SelectionChangedInterceptor
  extends Interceptor
{
  public static final int APPEND_SELECTION_COLLECTION = 1;
  public static final int APPEND_SELECTION_ELEMENT = 2;
  public static final int CLEAR_SELECTION = 3;
  public static final int REMOVE_SELECTION_COLLECTION = 4;
  public static final int REMOVE_SELECTION_ELEMENT = 5;
  
  public abstract void beforeSelectionChanged(TDataBox paramTDataBox, int paramInt, Collection paramCollection);
  
  public abstract void afterSelectionChanged(TDataBox paramTDataBox, int paramInt, Collection paramCollection);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.SelectionChangedInterceptor
 * JD-Core Version:    0.7.0.1
 */
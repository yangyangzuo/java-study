package twaver;

import java.util.Map;
import twaver.base.OrthogonalLinkDirectionType;

public class OrthogonalLink
  extends Link
{
  public OrthogonalLink()
  {
    C();
  }
  
  public OrthogonalLink(Object id)
  {
    super(id);
    C();
  }
  
  public OrthogonalLink(Object id, Node from, Node to)
  {
    super(id, from, to);
    C();
  }
  
  public OrthogonalLink(Node from, Node to)
  {
    super(from, to);
    C();
  }
  
  private void C()
  {
    setLinkType(3);
    getClientProperties().put("link.orthogonal.direction", OrthogonalLinkDirectionType.X_TO_Y);
  }
  
  public void putClientProperty(Object key, Object value)
  {
    super.putClientProperty(key, value);
    if (("direction".equals(key)) && ((value instanceof OrthogonalLinkDirectionType))) {
      putLinkOrthogonalDirection((OrthogonalLinkDirectionType)value);
    }
  }
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.OrthogonalLink
 * JD-Core Version:    0.7.0.1
 */
package twaver;

public abstract interface ElementLabelEditor
{
  public static final ElementLabelEditor TREEEDITOR = new ElementLabelEditor()
  {
    public void setLabel(Element element, String newLabel)
    {
      if (element != null) {
        element.setName(newLabel);
      }
    }
  };
  public static final ElementLabelEditor NETWORKEDITOR = new ElementLabelEditor()
  {
    public void setLabel(Element element, String newLabel)
    {
      if (element != null) {
        if (element.getDisplayName() != null) {
          element.setDisplayName(newLabel);
        } else {
          element.setName(newLabel);
        }
      }
    }
  };
  
  public abstract void setLabel(Element paramElement, String paramString);
}


/* Location:           C:\Users\Administrator\Desktop\download\twaver.jar
 * Qualified Name:     twaver.ElementLabelEditor
 * JD-Core Version:    0.7.0.1
 */
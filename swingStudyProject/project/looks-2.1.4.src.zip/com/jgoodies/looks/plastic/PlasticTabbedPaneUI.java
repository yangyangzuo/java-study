/*    1:     */ package com.jgoodies.looks.plastic;
/*    2:     */ 
/*    3:     */ import com.jgoodies.looks.LookUtils;
/*    4:     */ import com.jgoodies.looks.Options;
/*    5:     */ import java.awt.Color;
/*    6:     */ import java.awt.Component;
/*    7:     */ import java.awt.Container;
/*    8:     */ import java.awt.Dimension;
/*    9:     */ import java.awt.Font;
/*   10:     */ import java.awt.FontMetrics;
/*   11:     */ import java.awt.Graphics;
/*   12:     */ import java.awt.Graphics2D;
/*   13:     */ import java.awt.Insets;
/*   14:     */ import java.awt.LayoutManager;
/*   15:     */ import java.awt.Point;
/*   16:     */ import java.awt.Polygon;
/*   17:     */ import java.awt.Rectangle;
/*   18:     */ import java.awt.Shape;
/*   19:     */ import java.awt.event.ActionEvent;
/*   20:     */ import java.awt.event.ActionListener;
/*   21:     */ import java.awt.event.MouseEvent;
/*   22:     */ import java.beans.PropertyChangeEvent;
/*   23:     */ import java.beans.PropertyChangeListener;
/*   24:     */ import javax.swing.AbstractAction;
/*   25:     */ import javax.swing.Action;
/*   26:     */ import javax.swing.ActionMap;
/*   27:     */ import javax.swing.Icon;
/*   28:     */ import javax.swing.JButton;
/*   29:     */ import javax.swing.JComponent;
/*   30:     */ import javax.swing.JPanel;
/*   31:     */ import javax.swing.JTabbedPane;
/*   32:     */ import javax.swing.JViewport;
/*   33:     */ import javax.swing.SwingUtilities;
/*   34:     */ import javax.swing.UIManager;
/*   35:     */ import javax.swing.event.ChangeEvent;
/*   36:     */ import javax.swing.event.ChangeListener;
/*   37:     */ import javax.swing.plaf.ComponentUI;
/*   38:     */ import javax.swing.plaf.UIResource;
/*   39:     */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*   40:     */ import javax.swing.plaf.basic.BasicTabbedPaneUI.PropertyChangeHandler;
/*   41:     */ import javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout;
/*   42:     */ import javax.swing.plaf.metal.MetalTabbedPaneUI;
/*   43:     */ import javax.swing.text.View;
/*   44:     */ 
/*   45:     */ public final class PlasticTabbedPaneUI
/*   46:     */   extends MetalTabbedPaneUI
/*   47:     */ {
/*   48: 120 */   private static boolean isTabIconsEnabled = ;
/*   49:     */   private Boolean noContentBorder;
/*   50:     */   private Boolean embeddedTabs;
/*   51:     */   private AbstractRenderer renderer;
/*   52:     */   private ScrollableTabSupport tabScroller;
/*   53:     */   private int[] xCropLen;
/*   54:     */   private int[] yCropLen;
/*   55:     */   private static final int CROP_SEGMENT = 12;
/*   56:     */   
/*   57:     */   public static ComponentUI createUI(JComponent tabPane)
/*   58:     */   {
/*   59: 152 */     return new PlasticTabbedPaneUI();
/*   60:     */   }
/*   61:     */   
/*   62:     */   public void installUI(JComponent c)
/*   63:     */   {
/*   64: 161 */     super.installUI(c);
/*   65: 162 */     this.embeddedTabs = ((Boolean)c.getClientProperty("jgoodies.embeddedTabs"));
/*   66: 163 */     this.noContentBorder = ((Boolean)c.getClientProperty("jgoodies.noContentBorder"));
/*   67: 164 */     this.renderer = createRenderer(this.tabPane);
/*   68:     */   }
/*   69:     */   
/*   70:     */   public void uninstallUI(JComponent c)
/*   71:     */   {
/*   72: 172 */     this.renderer = null;
/*   73: 173 */     super.uninstallUI(c);
/*   74:     */   }
/*   75:     */   
/*   76:     */   protected void installComponents()
/*   77:     */   {
/*   78: 182 */     if ((scrollableTabLayoutEnabled()) && 
/*   79: 183 */       (this.tabScroller == null))
/*   80:     */     {
/*   81: 184 */       this.tabScroller = new ScrollableTabSupport(this.tabPane.getTabPlacement());
/*   82: 185 */       this.tabPane.add(this.tabScroller.viewport);
/*   83:     */     }
/*   84:     */   }
/*   85:     */   
/*   86:     */   protected void uninstallComponents()
/*   87:     */   {
/*   88: 196 */     if (scrollableTabLayoutEnabled())
/*   89:     */     {
/*   90: 197 */       this.tabPane.remove(this.tabScroller.viewport);
/*   91: 198 */       this.tabPane.remove(this.tabScroller.scrollForwardButton);
/*   92: 199 */       this.tabPane.remove(this.tabScroller.scrollBackwardButton);
/*   93: 200 */       this.tabScroller = null;
/*   94:     */     }
/*   95:     */   }
/*   96:     */   
/*   97:     */   protected void installListeners()
/*   98:     */   {
/*   99: 205 */     super.installListeners();
/*  100: 212 */     if ((this.mouseListener != null) && (LookUtils.IS_JAVA_1_4) && 
/*  101: 213 */       (scrollableTabLayoutEnabled()))
/*  102:     */     {
/*  103: 214 */       this.tabPane.removeMouseListener(this.mouseListener);
/*  104: 215 */       this.tabScroller.tabPanel.addMouseListener(this.mouseListener);
/*  105:     */     }
/*  106:     */   }
/*  107:     */   
/*  108:     */   protected void uninstallListeners()
/*  109:     */   {
/*  110: 221 */     if ((this.mouseListener != null) && (LookUtils.IS_JAVA_1_4))
/*  111:     */     {
/*  112: 222 */       if (scrollableTabLayoutEnabled()) {
/*  113: 223 */         this.tabScroller.tabPanel.removeMouseListener(this.mouseListener);
/*  114:     */       } else {
/*  115: 225 */         this.tabPane.removeMouseListener(this.mouseListener);
/*  116:     */       }
/*  117: 227 */       this.mouseListener = null;
/*  118:     */     }
/*  119: 229 */     super.uninstallListeners();
/*  120:     */   }
/*  121:     */   
/*  122:     */   protected void installKeyboardActions()
/*  123:     */   {
/*  124: 233 */     super.installKeyboardActions();
/*  125: 237 */     if (scrollableTabLayoutEnabled())
/*  126:     */     {
/*  127: 238 */       Action forwardAction = new ScrollTabsForwardAction(null);
/*  128: 239 */       Action backwardAction = new ScrollTabsBackwardAction(null);
/*  129: 240 */       ActionMap am = SwingUtilities.getUIActionMap(this.tabPane);
/*  130: 241 */       am.put("scrollTabsForwardAction", forwardAction);
/*  131: 242 */       am.put("scrollTabsBackwardAction", backwardAction);
/*  132: 243 */       this.tabScroller.scrollForwardButton.setAction(forwardAction);
/*  133: 244 */       this.tabScroller.scrollBackwardButton.setAction(backwardAction);
/*  134:     */     }
/*  135:     */   }
/*  136:     */   
/*  137:     */   private boolean hasNoContentBorder()
/*  138:     */   {
/*  139: 254 */     return Boolean.TRUE.equals(this.noContentBorder);
/*  140:     */   }
/*  141:     */   
/*  142:     */   private boolean hasEmbeddedTabs()
/*  143:     */   {
/*  144: 261 */     return Boolean.TRUE.equals(this.embeddedTabs);
/*  145:     */   }
/*  146:     */   
/*  147:     */   private AbstractRenderer createRenderer(JTabbedPane tabbedPane)
/*  148:     */   {
/*  149: 270 */     return hasEmbeddedTabs() ? AbstractRenderer.createEmbeddedRenderer(tabbedPane) : AbstractRenderer.createRenderer(this.tabPane);
/*  150:     */   }
/*  151:     */   
/*  152:     */   protected PropertyChangeListener createPropertyChangeListener()
/*  153:     */   {
/*  154: 281 */     return new MyPropertyChangeHandler(null);
/*  155:     */   }
/*  156:     */   
/*  157:     */   protected ChangeListener createChangeListener()
/*  158:     */   {
/*  159: 285 */     return new TabSelectionHandler(null);
/*  160:     */   }
/*  161:     */   
/*  162:     */   private void doLayout()
/*  163:     */   {
/*  164: 292 */     this.tabPane.revalidate();
/*  165: 293 */     this.tabPane.repaint();
/*  166:     */   }
/*  167:     */   
/*  168:     */   private void tabPlacementChanged()
/*  169:     */   {
/*  170: 301 */     this.renderer = createRenderer(this.tabPane);
/*  171: 302 */     if (scrollableTabLayoutEnabled()) {
/*  172: 303 */       this.tabScroller.createButtons();
/*  173:     */     }
/*  174: 305 */     doLayout();
/*  175:     */   }
/*  176:     */   
/*  177:     */   private void embeddedTabsPropertyChanged(Boolean newValue)
/*  178:     */   {
/*  179: 313 */     this.embeddedTabs = newValue;
/*  180: 314 */     this.renderer = createRenderer(this.tabPane);
/*  181: 315 */     doLayout();
/*  182:     */   }
/*  183:     */   
/*  184:     */   private void noContentBorderPropertyChanged(Boolean newValue)
/*  185:     */   {
/*  186: 324 */     this.noContentBorder = newValue;
/*  187: 325 */     this.tabPane.repaint();
/*  188:     */   }
/*  189:     */   
/*  190:     */   public void paint(Graphics g, JComponent c)
/*  191:     */   {
/*  192: 329 */     int selectedIndex = this.tabPane.getSelectedIndex();
/*  193: 330 */     int tabPlacement = this.tabPane.getTabPlacement();
/*  194:     */     
/*  195: 332 */     ensureCurrentLayout();
/*  196: 338 */     if (!scrollableTabLayoutEnabled()) {
/*  197: 339 */       paintTabArea(g, tabPlacement, selectedIndex);
/*  198:     */     }
/*  199: 343 */     paintContentBorder(g, tabPlacement, selectedIndex);
/*  200:     */   }
/*  201:     */   
/*  202:     */   protected void paintTab(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect)
/*  203:     */   {
/*  204: 348 */     Rectangle tabRect = rects[tabIndex];
/*  205: 349 */     int selectedIndex = this.tabPane.getSelectedIndex();
/*  206: 350 */     boolean isSelected = selectedIndex == tabIndex;
/*  207: 351 */     Graphics2D g2 = null;
/*  208: 352 */     Polygon cropShape = null;
/*  209: 353 */     Shape save = null;
/*  210: 354 */     int cropx = 0;
/*  211: 355 */     int cropy = 0;
/*  212: 357 */     if ((scrollableTabLayoutEnabled()) && 
/*  213: 358 */       ((g instanceof Graphics2D)))
/*  214:     */     {
/*  215: 359 */       g2 = (Graphics2D)g;
/*  216:     */       
/*  217:     */ 
/*  218: 362 */       Rectangle viewRect = this.tabScroller.viewport.getViewRect();
/*  219:     */       int cropline;
/*  220: 364 */       switch (tabPlacement)
/*  221:     */       {
/*  222:     */       case 2: 
/*  223:     */       case 4: 
/*  224: 367 */         cropline = viewRect.y + viewRect.height;
/*  225: 368 */         if ((tabRect.y < cropline) && (tabRect.y + tabRect.height > cropline))
/*  226:     */         {
/*  227: 370 */           cropShape = createCroppedTabClip(tabPlacement, tabRect, cropline);
/*  228:     */           
/*  229: 372 */           cropx = tabRect.x;
/*  230: 373 */           cropy = cropline - 1;
/*  231:     */         }
/*  232:     */         break;
/*  233:     */       case 1: 
/*  234:     */       case 3: 
/*  235:     */       default: 
/*  236: 379 */         cropline = viewRect.x + viewRect.width;
/*  237: 380 */         if ((tabRect.x < cropline) && (tabRect.x + tabRect.width > cropline))
/*  238:     */         {
/*  239: 382 */           cropShape = createCroppedTabClip(tabPlacement, tabRect, cropline);
/*  240:     */           
/*  241: 384 */           cropx = cropline - 1;
/*  242: 385 */           cropy = tabRect.y;
/*  243:     */         }
/*  244:     */         break;
/*  245:     */       }
/*  246: 388 */       if (cropShape != null)
/*  247:     */       {
/*  248: 389 */         save = g.getClip();
/*  249: 390 */         g2.clip(cropShape);
/*  250:     */       }
/*  251:     */     }
/*  252: 395 */     paintTabBackground(g, tabPlacement, tabIndex, tabRect.x, tabRect.y, tabRect.width, tabRect.height, isSelected);
/*  253:     */     
/*  254:     */ 
/*  255: 398 */     paintTabBorder(g, tabPlacement, tabIndex, tabRect.x, tabRect.y, tabRect.width, tabRect.height, isSelected);
/*  256:     */     
/*  257:     */ 
/*  258: 401 */     String title = this.tabPane.getTitleAt(tabIndex);
/*  259: 402 */     Font font = this.tabPane.getFont();
/*  260: 403 */     FontMetrics metrics = g.getFontMetrics(font);
/*  261: 404 */     Icon icon = getIconForTab(tabIndex);
/*  262:     */     
/*  263: 406 */     layoutLabel(tabPlacement, metrics, tabIndex, title, icon, tabRect, iconRect, textRect, isSelected);
/*  264:     */     
/*  265:     */ 
/*  266: 409 */     paintText(g, tabPlacement, font, metrics, tabIndex, title, textRect, isSelected);
/*  267:     */     
/*  268:     */ 
/*  269: 412 */     paintIcon(g, tabPlacement, tabIndex, icon, iconRect, isSelected);
/*  270:     */     
/*  271: 414 */     paintFocusIndicator(g, tabPlacement, rects, tabIndex, iconRect, textRect, isSelected);
/*  272: 417 */     if (cropShape != null)
/*  273:     */     {
/*  274: 418 */       paintCroppedTabEdge(g, tabPlacement, tabIndex, isSelected, cropx, cropy);
/*  275:     */       
/*  276: 420 */       g.setClip(save);
/*  277:     */     }
/*  278:     */   }
/*  279:     */   
/*  280:     */   public PlasticTabbedPaneUI()
/*  281:     */   {
/*  282: 446 */     this.xCropLen = new int[] { 1, 1, 0, 0, 1, 1, 2, 2 };
/*  283:     */     
/*  284: 448 */     this.yCropLen = new int[] { 0, 3, 3, 6, 6, 9, 9, 12 };
/*  285:     */   }
/*  286:     */   
/*  287:     */   private Polygon createCroppedTabClip(int tabPlacement, Rectangle tabRect, int cropline)
/*  288:     */   {
/*  289: 454 */     int rlen = 0;
/*  290: 455 */     int start = 0;
/*  291: 456 */     int end = 0;
/*  292: 457 */     int ostart = 0;
/*  293: 459 */     switch (tabPlacement)
/*  294:     */     {
/*  295:     */     case 2: 
/*  296:     */     case 4: 
/*  297: 462 */       rlen = tabRect.width;
/*  298: 463 */       start = tabRect.x;
/*  299: 464 */       end = tabRect.x + tabRect.width;
/*  300: 465 */       ostart = tabRect.y;
/*  301: 466 */       break;
/*  302:     */     case 1: 
/*  303:     */     case 3: 
/*  304:     */     default: 
/*  305: 470 */       rlen = tabRect.height;
/*  306: 471 */       start = tabRect.y;
/*  307: 472 */       end = tabRect.y + tabRect.height;
/*  308: 473 */       ostart = tabRect.x;
/*  309:     */     }
/*  310: 475 */     int rcnt = rlen / 12;
/*  311: 476 */     if (rlen % 12 > 0) {
/*  312: 477 */       rcnt++;
/*  313:     */     }
/*  314: 479 */     int npts = 2 + rcnt * 8;
/*  315: 480 */     int[] xp = new int[npts];
/*  316: 481 */     int[] yp = new int[npts];
/*  317: 482 */     int pcnt = 0;
/*  318:     */     
/*  319: 484 */     xp[pcnt] = ostart;
/*  320: 485 */     yp[(pcnt++)] = end;
/*  321: 486 */     xp[pcnt] = ostart;
/*  322: 487 */     yp[(pcnt++)] = start;
/*  323: 488 */     for (int i = 0; i < rcnt; i++) {
/*  324: 489 */       for (int j = 0; j < this.xCropLen.length; j++)
/*  325:     */       {
/*  326: 490 */         xp[pcnt] = (cropline - this.xCropLen[j]);
/*  327: 491 */         yp[pcnt] = (start + i * 12 + this.yCropLen[j]);
/*  328: 492 */         if (yp[pcnt] >= end)
/*  329:     */         {
/*  330: 493 */           yp[pcnt] = end;
/*  331: 494 */           pcnt++;
/*  332: 495 */           break;
/*  333:     */         }
/*  334: 497 */         pcnt++;
/*  335:     */       }
/*  336:     */     }
/*  337: 500 */     if ((tabPlacement == 1) || (tabPlacement == 3)) {
/*  338: 502 */       return new Polygon(xp, yp, pcnt);
/*  339:     */     }
/*  340: 506 */     return new Polygon(yp, xp, pcnt);
/*  341:     */   }
/*  342:     */   
/*  343:     */   private void paintCroppedTabEdge(Graphics g, int tabPlacement, int tabIndex, boolean isSelected, int x, int y)
/*  344:     */   {
/*  345:     */     int xx;
/*  346: 514 */     switch (tabPlacement)
/*  347:     */     {
/*  348:     */     case 2: 
/*  349:     */     case 4: 
/*  350: 517 */       xx = x;
/*  351: 518 */       g.setColor(this.shadow);
/*  352:     */     }
/*  353: 519 */     while (xx <= x + this.rects[tabIndex].width)
/*  354:     */     {
/*  355: 520 */       for (int i = 0; i < this.xCropLen.length; i += 2) {
/*  356: 521 */         g.drawLine(xx + this.yCropLen[i], y - this.xCropLen[i], xx + this.yCropLen[(i + 1)] - 1, y - this.xCropLen[(i + 1)]);
/*  357:     */       }
/*  358: 524 */       xx += 12; continue;
/*  359:     */       
/*  360:     */ 
/*  361:     */ 
/*  362:     */ 
/*  363:     */ 
/*  364: 530 */       int yy = y;
/*  365: 531 */       g.setColor(this.shadow);
/*  366: 532 */       while (yy <= y + this.rects[tabIndex].height)
/*  367:     */       {
/*  368: 533 */         for (int i = 0; i < this.xCropLen.length; i += 2) {
/*  369: 534 */           g.drawLine(x - this.xCropLen[i], yy + this.yCropLen[i], x - this.xCropLen[(i + 1)], yy + this.yCropLen[(i + 1)] - 1);
/*  370:     */         }
/*  371: 537 */         yy += 12;
/*  372:     */       }
/*  373:     */     }
/*  374:     */   }
/*  375:     */   
/*  376:     */   private void ensureCurrentLayout()
/*  377:     */   {
/*  378: 543 */     if (!this.tabPane.isValid()) {
/*  379: 544 */       this.tabPane.validate();
/*  380:     */     }
/*  381: 550 */     if (!this.tabPane.isValid())
/*  382:     */     {
/*  383: 551 */       TabbedPaneLayout layout = (TabbedPaneLayout)this.tabPane.getLayout();
/*  384: 552 */       layout.calculateLayoutInfo();
/*  385:     */     }
/*  386:     */   }
/*  387:     */   
/*  388:     */   public int tabForCoordinate(JTabbedPane pane, int x, int y)
/*  389:     */   {
/*  390: 561 */     ensureCurrentLayout();
/*  391: 562 */     Point p = new Point(x, y);
/*  392: 564 */     if (scrollableTabLayoutEnabled())
/*  393:     */     {
/*  394: 565 */       translatePointToTabPanel(x, y, p);
/*  395: 566 */       Rectangle viewRect = this.tabScroller.viewport.getViewRect();
/*  396: 567 */       if (!viewRect.contains(p)) {
/*  397: 568 */         return -1;
/*  398:     */       }
/*  399:     */     }
/*  400: 571 */     int tabCount = this.tabPane.getTabCount();
/*  401: 572 */     for (int i = 0; i < tabCount; i++) {
/*  402: 573 */       if (this.rects[i].contains(p.x, p.y)) {
/*  403: 574 */         return i;
/*  404:     */       }
/*  405:     */     }
/*  406: 577 */     return -1;
/*  407:     */   }
/*  408:     */   
/*  409:     */   protected Rectangle getTabBounds(int tabIndex, Rectangle dest)
/*  410:     */   {
/*  411: 581 */     dest.width = this.rects[tabIndex].width;
/*  412: 582 */     dest.height = this.rects[tabIndex].height;
/*  413: 583 */     if (scrollableTabLayoutEnabled())
/*  414:     */     {
/*  415: 586 */       Point vpp = this.tabScroller.viewport.getLocation();
/*  416: 587 */       Point viewp = this.tabScroller.viewport.getViewPosition();
/*  417: 588 */       dest.x = (this.rects[tabIndex].x + vpp.x - viewp.x);
/*  418: 589 */       dest.y = (this.rects[tabIndex].y + vpp.y - viewp.y);
/*  419:     */     }
/*  420:     */     else
/*  421:     */     {
/*  422: 591 */       dest.x = this.rects[tabIndex].x;
/*  423: 592 */       dest.y = this.rects[tabIndex].y;
/*  424:     */     }
/*  425: 594 */     return dest;
/*  426:     */   }
/*  427:     */   
/*  428:     */   private int getClosestTab(int x, int y)
/*  429:     */   {
/*  430: 602 */     int min = 0;
/*  431: 603 */     int tabCount = Math.min(this.rects.length, this.tabPane.getTabCount());
/*  432: 604 */     int max = tabCount;
/*  433: 605 */     int tabPlacement = this.tabPane.getTabPlacement();
/*  434: 606 */     boolean useX = (tabPlacement == 1) || (tabPlacement == 3);
/*  435: 607 */     int want = useX ? x : y;
/*  436: 609 */     while (min != max)
/*  437:     */     {
/*  438: 610 */       int current = (max + min) / 2;
/*  439:     */       int maxLoc;
/*  440:     */       int minLoc;
/*  441:     */       int maxLoc;
/*  442: 614 */       if (useX)
/*  443:     */       {
/*  444: 615 */         int minLoc = this.rects[current].x;
/*  445: 616 */         maxLoc = minLoc + this.rects[current].width;
/*  446:     */       }
/*  447:     */       else
/*  448:     */       {
/*  449: 618 */         minLoc = this.rects[current].y;
/*  450: 619 */         maxLoc = minLoc + this.rects[current].height;
/*  451:     */       }
/*  452: 621 */       if (want < minLoc)
/*  453:     */       {
/*  454: 622 */         max = current;
/*  455: 623 */         if (min == max) {
/*  456: 624 */           return Math.max(0, current - 1);
/*  457:     */         }
/*  458:     */       }
/*  459: 626 */       else if (want >= maxLoc)
/*  460:     */       {
/*  461: 627 */         min = current;
/*  462: 628 */         if (max - min <= 1) {
/*  463: 629 */           return Math.max(current + 1, tabCount - 1);
/*  464:     */         }
/*  465:     */       }
/*  466:     */       else
/*  467:     */       {
/*  468: 632 */         return current;
/*  469:     */       }
/*  470:     */     }
/*  471: 635 */     return min;
/*  472:     */   }
/*  473:     */   
/*  474:     */   private Point translatePointToTabPanel(int srcx, int srcy, Point dest)
/*  475:     */   {
/*  476: 644 */     Point vpp = this.tabScroller.viewport.getLocation();
/*  477: 645 */     Point viewp = this.tabScroller.viewport.getViewPosition();
/*  478: 646 */     dest.x = (srcx - vpp.x + viewp.x);
/*  479: 647 */     dest.y = (srcy - vpp.y + viewp.y);
/*  480: 648 */     return dest;
/*  481:     */   }
/*  482:     */   
/*  483:     */   protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex)
/*  484:     */   {
/*  485: 652 */     int tabCount = this.tabPane.getTabCount();
/*  486:     */     
/*  487: 654 */     Rectangle iconRect = new Rectangle();
/*  488: 655 */     Rectangle textRect = new Rectangle();
/*  489: 656 */     Rectangle clipRect = g.getClipBounds();
/*  490: 659 */     for (int i = this.runCount - 1; i >= 0; i--)
/*  491:     */     {
/*  492: 660 */       int start = this.tabRuns[i];
/*  493: 661 */       int next = this.tabRuns[(i + 1)];
/*  494: 662 */       int end = next != 0 ? next - 1 : tabCount - 1;
/*  495: 663 */       for (int j = end; j >= start; j--) {
/*  496: 664 */         if ((j != selectedIndex) && (this.rects[j].intersects(clipRect))) {
/*  497: 665 */           paintTab(g, tabPlacement, this.rects, j, iconRect, textRect);
/*  498:     */         }
/*  499:     */       }
/*  500:     */     }
/*  501: 672 */     if ((selectedIndex >= 0) && (this.rects[selectedIndex].intersects(clipRect))) {
/*  502: 673 */       paintTab(g, tabPlacement, this.rects, selectedIndex, iconRect, textRect);
/*  503:     */     }
/*  504:     */   }
/*  505:     */   
/*  506:     */   protected void layoutLabel(int tabPlacement, FontMetrics metrics, int tabIndex, String title, Icon icon, Rectangle tabRect, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*  507:     */   {
/*  508: 691 */     textRect.x = (textRect.y = iconRect.x = iconRect.y = 0);
/*  509:     */     
/*  510: 693 */     View v = getTextViewForTab(tabIndex);
/*  511: 694 */     if (v != null) {
/*  512: 695 */       this.tabPane.putClientProperty("html", v);
/*  513:     */     }
/*  514: 698 */     Rectangle calcRectangle = new Rectangle(tabRect);
/*  515: 699 */     if (isSelected)
/*  516:     */     {
/*  517: 700 */       Insets calcInsets = getSelectedTabPadInsets(tabPlacement);
/*  518: 701 */       calcRectangle.x += calcInsets.left;
/*  519: 702 */       calcRectangle.y += calcInsets.top;
/*  520: 703 */       calcRectangle.width -= calcInsets.left + calcInsets.right;
/*  521: 704 */       calcRectangle.height -= calcInsets.bottom + calcInsets.top;
/*  522:     */     }
/*  523: 706 */     int xNudge = getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
/*  524: 707 */     int yNudge = getTabLabelShiftY(tabPlacement, tabIndex, isSelected);
/*  525: 708 */     if (((tabPlacement == 4) || (tabPlacement == 2)) && (icon != null) && (title != null) && (!title.equals("")))
/*  526:     */     {
/*  527: 709 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 0, 2, 0, 11, calcRectangle, iconRect, textRect, this.textIconGap);
/*  528:     */       
/*  529:     */ 
/*  530:     */ 
/*  531:     */ 
/*  532:     */ 
/*  533:     */ 
/*  534:     */ 
/*  535:     */ 
/*  536:     */ 
/*  537:     */ 
/*  538:     */ 
/*  539:     */ 
/*  540: 722 */       xNudge += 4;
/*  541:     */     }
/*  542:     */     else
/*  543:     */     {
/*  544: 724 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 0, 0, 0, 11, calcRectangle, iconRect, textRect, this.textIconGap);
/*  545:     */       
/*  546:     */ 
/*  547:     */ 
/*  548:     */ 
/*  549:     */ 
/*  550:     */ 
/*  551:     */ 
/*  552:     */ 
/*  553:     */ 
/*  554:     */ 
/*  555:     */ 
/*  556:     */ 
/*  557: 737 */       iconRect.y += calcRectangle.height % 2;
/*  558:     */     }
/*  559: 741 */     this.tabPane.putClientProperty("html", null);
/*  560:     */     
/*  561: 743 */     iconRect.x += xNudge;
/*  562: 744 */     iconRect.y += yNudge;
/*  563: 745 */     textRect.x += xNudge;
/*  564: 746 */     textRect.y += yNudge;
/*  565:     */   }
/*  566:     */   
/*  567:     */   protected Icon getIconForTab(int tabIndex)
/*  568:     */   {
/*  569: 755 */     String title = this.tabPane.getTitleAt(tabIndex);
/*  570: 756 */     boolean hasTitle = (title != null) && (title.length() > 0);
/*  571: 757 */     return (!isTabIconsEnabled) && (hasTitle) ? null : super.getIconForTab(tabIndex);
/*  572:     */   }
/*  573:     */   
/*  574:     */   protected LayoutManager createLayoutManager()
/*  575:     */   {
/*  576: 766 */     if (this.tabPane.getTabLayoutPolicy() == 1) {
/*  577: 767 */       return new TabbedPaneScrollLayout(null);
/*  578:     */     }
/*  579: 770 */     return new TabbedPaneLayout(null);
/*  580:     */   }
/*  581:     */   
/*  582:     */   private boolean scrollableTabLayoutEnabled()
/*  583:     */   {
/*  584: 779 */     return this.tabPane.getLayout() instanceof TabbedPaneScrollLayout;
/*  585:     */   }
/*  586:     */   
/*  587:     */   protected boolean isTabInFirstRun(int tabIndex)
/*  588:     */   {
/*  589: 783 */     return getRunForTab(this.tabPane.getTabCount(), tabIndex) == 0;
/*  590:     */   }
/*  591:     */   
/*  592:     */   protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex)
/*  593:     */   {
/*  594: 787 */     int width = this.tabPane.getWidth();
/*  595: 788 */     int height = this.tabPane.getHeight();
/*  596: 789 */     Insets insets = this.tabPane.getInsets();
/*  597:     */     
/*  598: 791 */     int x = insets.left;
/*  599: 792 */     int y = insets.top;
/*  600: 793 */     int w = width - insets.right - insets.left;
/*  601: 794 */     int h = height - insets.top - insets.bottom;
/*  602: 796 */     switch (tabPlacement)
/*  603:     */     {
/*  604:     */     case 2: 
/*  605: 798 */       x += calculateTabAreaWidth(tabPlacement, this.runCount, this.maxTabWidth);
/*  606: 799 */       w -= x - insets.left;
/*  607: 800 */       break;
/*  608:     */     case 4: 
/*  609: 802 */       w -= calculateTabAreaWidth(tabPlacement, this.runCount, this.maxTabWidth);
/*  610: 803 */       break;
/*  611:     */     case 3: 
/*  612: 805 */       h -= calculateTabAreaHeight(tabPlacement, this.runCount, this.maxTabHeight);
/*  613: 806 */       break;
/*  614:     */     case 1: 
/*  615:     */     default: 
/*  616: 809 */       y += calculateTabAreaHeight(tabPlacement, this.runCount, this.maxTabHeight);
/*  617: 810 */       h -= y - insets.top;
/*  618:     */     }
/*  619: 813 */     g.setColor(this.selectColor == null ? this.tabPane.getBackground() : this.selectColor);
/*  620:     */     
/*  621:     */ 
/*  622: 816 */     g.fillRect(x, y, w, h);
/*  623:     */     
/*  624:     */ 
/*  625: 819 */     Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, this.calcRect);
/*  626: 820 */     boolean drawBroken = (selectedIndex >= 0) && (isTabInFirstRun(selectedIndex));
/*  627: 821 */     boolean isContentBorderPainted = !hasNoContentBorder();
/*  628:     */     
/*  629:     */ 
/*  630:     */ 
/*  631:     */ 
/*  632: 826 */     this.renderer.paintContentBorderTopEdge(g, x, y, w, h, drawBroken, selRect, isContentBorderPainted);
/*  633: 827 */     this.renderer.paintContentBorderLeftEdge(g, x, y, w, h, drawBroken, selRect, isContentBorderPainted);
/*  634: 828 */     this.renderer.paintContentBorderBottomEdge(g, x, y, w, h, drawBroken, selRect, isContentBorderPainted);
/*  635: 829 */     this.renderer.paintContentBorderRightEdge(g, x, y, w, h, drawBroken, selRect, isContentBorderPainted);
/*  636:     */   }
/*  637:     */   
/*  638:     */   protected Insets getContentBorderInsets(int tabPlacement)
/*  639:     */   {
/*  640: 840 */     return this.renderer.getContentBorderInsets(super.getContentBorderInsets(tabPlacement));
/*  641:     */   }
/*  642:     */   
/*  643:     */   protected Insets getTabAreaInsets(int tabPlacement)
/*  644:     */   {
/*  645: 847 */     return this.renderer.getTabAreaInsets(super.getTabAreaInsets(tabPlacement));
/*  646:     */   }
/*  647:     */   
/*  648:     */   protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected)
/*  649:     */   {
/*  650: 854 */     return this.renderer.getTabLabelShiftX(tabIndex, isSelected);
/*  651:     */   }
/*  652:     */   
/*  653:     */   protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected)
/*  654:     */   {
/*  655: 861 */     return this.renderer.getTabLabelShiftY(tabIndex, isSelected);
/*  656:     */   }
/*  657:     */   
/*  658:     */   protected int getTabRunOverlay(int tabPlacement)
/*  659:     */   {
/*  660: 868 */     return this.renderer.getTabRunOverlay(this.tabRunOverlay);
/*  661:     */   }
/*  662:     */   
/*  663:     */   protected boolean shouldPadTabRun(int tabPlacement, int run)
/*  664:     */   {
/*  665: 876 */     return this.renderer.shouldPadTabRun(run, super.shouldPadTabRun(tabPlacement, run));
/*  666:     */   }
/*  667:     */   
/*  668:     */   protected int getTabRunIndent(int tabPlacement, int run)
/*  669:     */   {
/*  670: 885 */     return this.renderer.getTabRunIndent(run);
/*  671:     */   }
/*  672:     */   
/*  673:     */   protected Insets getTabInsets(int tabPlacement, int tabIndex)
/*  674:     */   {
/*  675: 892 */     return this.renderer.getTabInsets(tabIndex, this.tabInsets);
/*  676:     */   }
/*  677:     */   
/*  678:     */   protected Insets getSelectedTabPadInsets(int tabPlacement)
/*  679:     */   {
/*  680: 899 */     return this.renderer.getSelectedTabPadInsets();
/*  681:     */   }
/*  682:     */   
/*  683:     */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rectangles, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*  684:     */   {
/*  685: 913 */     this.renderer.paintFocusIndicator(g, rectangles, tabIndex, iconRect, textRect, isSelected);
/*  686:     */   }
/*  687:     */   
/*  688:     */   protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*  689:     */   {
/*  690: 922 */     this.renderer.paintTabBackground(g, tabIndex, x, y, w, h, isSelected);
/*  691:     */   }
/*  692:     */   
/*  693:     */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*  694:     */   {
/*  695: 931 */     this.renderer.paintTabBorder(g, tabIndex, x, y, w, h, isSelected);
/*  696:     */   }
/*  697:     */   
/*  698:     */   protected boolean shouldRotateTabRuns(int tabPlacement)
/*  699:     */   {
/*  700: 940 */     return false;
/*  701:     */   }
/*  702:     */   
/*  703:     */   private class TabSelectionHandler
/*  704:     */     implements ChangeListener
/*  705:     */   {
/*  706:     */     TabSelectionHandler(PlasticTabbedPaneUI.1 x1)
/*  707:     */     {
/*  708: 943 */       this();
/*  709:     */     }
/*  710:     */     
/*  711: 945 */     private Rectangle rect = new Rectangle();
/*  712:     */     
/*  713:     */     public void stateChanged(ChangeEvent e)
/*  714:     */     {
/*  715: 948 */       JTabbedPane tabPane = (JTabbedPane)e.getSource();
/*  716: 949 */       tabPane.revalidate();
/*  717: 950 */       tabPane.repaint();
/*  718: 952 */       if (tabPane.getTabLayoutPolicy() == 1)
/*  719:     */       {
/*  720: 953 */         int index = tabPane.getSelectedIndex();
/*  721: 954 */         if ((index < PlasticTabbedPaneUI.this.rects.length) && (index != -1))
/*  722:     */         {
/*  723: 955 */           this.rect.setBounds(PlasticTabbedPaneUI.this.rects[index]);
/*  724: 956 */           Point viewPosition = PlasticTabbedPaneUI.this.tabScroller.viewport.getViewPosition();
/*  725: 957 */           if (this.rect.x < viewPosition.x) {
/*  726: 958 */             this.rect.x -= PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/*  727:     */           } else {
/*  728: 960 */             this.rect.x += PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/*  729:     */           }
/*  730: 962 */           PlasticTabbedPaneUI.this.tabScroller.tabPanel.scrollRectToVisible(this.rect);
/*  731:     */         }
/*  732:     */       }
/*  733:     */     }
/*  734:     */     
/*  735:     */     private TabSelectionHandler() {}
/*  736:     */   }
/*  737:     */   
/*  738:     */   private class MyPropertyChangeHandler
/*  739:     */     extends BasicTabbedPaneUI.PropertyChangeHandler
/*  740:     */   {
/*  741:     */     MyPropertyChangeHandler(PlasticTabbedPaneUI.1 x1)
/*  742:     */     {
/*  743: 973 */       this();
/*  744:     */     }
/*  745:     */     
/*  746:     */     private MyPropertyChangeHandler()
/*  747:     */     {
/*  748: 973 */       super();
/*  749:     */     }
/*  750:     */     
/*  751:     */     public void propertyChange(PropertyChangeEvent e)
/*  752:     */     {
/*  753: 976 */       String pName = e.getPropertyName();
/*  754: 978 */       if (null == pName) {
/*  755: 979 */         return;
/*  756:     */       }
/*  757: 982 */       super.propertyChange(e);
/*  758: 984 */       if (pName.equals("tabPlacement"))
/*  759:     */       {
/*  760: 985 */         PlasticTabbedPaneUI.this.tabPlacementChanged();
/*  761: 986 */         return;
/*  762:     */       }
/*  763: 988 */       if (pName.equals("jgoodies.embeddedTabs"))
/*  764:     */       {
/*  765: 989 */         PlasticTabbedPaneUI.this.embeddedTabsPropertyChanged((Boolean)e.getNewValue());
/*  766: 990 */         return;
/*  767:     */       }
/*  768: 992 */       if (pName.equals("jgoodies.noContentBorder"))
/*  769:     */       {
/*  770: 993 */         PlasticTabbedPaneUI.this.noContentBorderPropertyChanged((Boolean)e.getNewValue());
/*  771: 994 */         return;
/*  772:     */       }
/*  773:     */     }
/*  774:     */   }
/*  775:     */   
/*  776:     */   private class TabbedPaneLayout
/*  777:     */     extends BasicTabbedPaneUI.TabbedPaneLayout
/*  778:     */     implements LayoutManager
/*  779:     */   {
/*  780:     */     TabbedPaneLayout(PlasticTabbedPaneUI.1 x1)
/*  781:     */     {
/*  782:1003 */       this();
/*  783:     */     }
/*  784:     */     
/*  785:     */     private TabbedPaneLayout()
/*  786:     */     {
/*  787:1003 */       super();
/*  788:     */     }
/*  789:     */     
/*  790:     */     protected void calculateTabRects(int tabPlacement, int tabCount)
/*  791:     */     {
/*  792:1006 */       FontMetrics metrics = PlasticTabbedPaneUI.this.getFontMetrics();
/*  793:1007 */       Dimension size = PlasticTabbedPaneUI.this.tabPane.getSize();
/*  794:1008 */       Insets insets = PlasticTabbedPaneUI.this.tabPane.getInsets();
/*  795:1009 */       Insets theTabAreaInsets = PlasticTabbedPaneUI.this.getTabAreaInsets(tabPlacement);
/*  796:1010 */       int fontHeight = metrics.getHeight();
/*  797:1011 */       int selectedIndex = PlasticTabbedPaneUI.this.tabPane.getSelectedIndex();
/*  798:     */       
/*  799:     */ 
/*  800:     */ 
/*  801:     */ 
/*  802:1016 */       boolean verticalTabRuns = (tabPlacement == 2) || (tabPlacement == 4);
/*  803:1017 */       boolean leftToRight = PlasticUtils.isLeftToRight(PlasticTabbedPaneUI.this.tabPane);
/*  804:     */       int x;
/*  805:     */       int y;
/*  806:     */       int returnAt;
/*  807:1022 */       switch (tabPlacement)
/*  808:     */       {
/*  809:     */       case 2: 
/*  810:1024 */         PlasticTabbedPaneUI.this.maxTabWidth = PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement);
/*  811:1025 */         x = insets.left + theTabAreaInsets.left;
/*  812:1026 */         y = insets.top + theTabAreaInsets.top;
/*  813:1027 */         returnAt = size.height - (insets.bottom + theTabAreaInsets.bottom);
/*  814:1028 */         break;
/*  815:     */       case 4: 
/*  816:1030 */         PlasticTabbedPaneUI.this.maxTabWidth = PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement);
/*  817:1031 */         x = size.width - insets.right - theTabAreaInsets.right - PlasticTabbedPaneUI.this.maxTabWidth;
/*  818:1032 */         y = insets.top + theTabAreaInsets.top;
/*  819:1033 */         returnAt = size.height - (insets.bottom + theTabAreaInsets.bottom);
/*  820:1034 */         break;
/*  821:     */       case 3: 
/*  822:1036 */         PlasticTabbedPaneUI.this.maxTabHeight = PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement);
/*  823:1037 */         x = insets.left + theTabAreaInsets.left;
/*  824:1038 */         y = size.height - insets.bottom - theTabAreaInsets.bottom - PlasticTabbedPaneUI.this.maxTabHeight;
/*  825:1039 */         returnAt = size.width - (insets.right + theTabAreaInsets.right);
/*  826:1040 */         break;
/*  827:     */       case 1: 
/*  828:     */       default: 
/*  829:1043 */         PlasticTabbedPaneUI.this.maxTabHeight = PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement);
/*  830:1044 */         x = insets.left + theTabAreaInsets.left;
/*  831:1045 */         y = insets.top + theTabAreaInsets.top;
/*  832:1046 */         returnAt = size.width - (insets.right + theTabAreaInsets.right);
/*  833:     */       }
/*  834:1050 */       int theTabRunOverlay = PlasticTabbedPaneUI.this.getTabRunOverlay(tabPlacement);
/*  835:     */       
/*  836:1052 */       PlasticTabbedPaneUI.this.runCount = 0;
/*  837:1053 */       PlasticTabbedPaneUI.this.selectedRun = -1;
/*  838:     */       
/*  839:     */ 
/*  840:     */ 
/*  841:     */ 
/*  842:1058 */       int tabInRun = -1;
/*  843:     */       
/*  844:     */ 
/*  845:1061 */       int runReturnAt = returnAt;
/*  846:1063 */       if (tabCount == 0) {
/*  847:1064 */         return;
/*  848:     */       }
/*  849:1069 */       for (int i = 0; i < tabCount; i++)
/*  850:     */       {
/*  851:1070 */         Rectangle rect = PlasticTabbedPaneUI.this.rects[i];
/*  852:1071 */         tabInRun++;
/*  853:1073 */         if (!verticalTabRuns)
/*  854:     */         {
/*  855:1075 */           if (i > 0)
/*  856:     */           {
/*  857:1076 */             rect.x = (PlasticTabbedPaneUI.this.rects[(i - 1)].x + PlasticTabbedPaneUI.this.rects[(i - 1)].width);
/*  858:     */           }
/*  859:     */           else
/*  860:     */           {
/*  861:1078 */             PlasticTabbedPaneUI.this.tabRuns[0] = 0;
/*  862:1079 */             PlasticTabbedPaneUI.this.runCount = 1;
/*  863:1080 */             PlasticTabbedPaneUI.this.maxTabWidth = 0;
/*  864:1081 */             rect.x = x;
/*  865:     */           }
/*  866:1084 */           rect.width = PlasticTabbedPaneUI.this.calculateTabWidth(tabPlacement, i, metrics);
/*  867:1085 */           PlasticTabbedPaneUI.this.maxTabWidth = Math.max(PlasticTabbedPaneUI.this.maxTabWidth, rect.width);
/*  868:1093 */           if ((tabInRun != 0) && (rect.x + rect.width > runReturnAt))
/*  869:     */           {
/*  870:1094 */             if (PlasticTabbedPaneUI.this.runCount > PlasticTabbedPaneUI.this.tabRuns.length - 1) {
/*  871:1095 */               PlasticTabbedPaneUI.this.expandTabRunsArray();
/*  872:     */             }
/*  873:1098 */             tabInRun = 0;
/*  874:1099 */             PlasticTabbedPaneUI.this.tabRuns[PlasticTabbedPaneUI.this.runCount] = i;
/*  875:1100 */             PlasticTabbedPaneUI.access$4608(PlasticTabbedPaneUI.this);
/*  876:1101 */             rect.x = x;
/*  877:1102 */             runReturnAt -= 2 * PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, PlasticTabbedPaneUI.this.runCount);
/*  878:     */           }
/*  879:1105 */           rect.y = y;
/*  880:1106 */           rect.height = PlasticTabbedPaneUI.this.maxTabHeight;
/*  881:     */         }
/*  882:     */         else
/*  883:     */         {
/*  884:1110 */           if (i > 0)
/*  885:     */           {
/*  886:1111 */             rect.y = (PlasticTabbedPaneUI.this.rects[(i - 1)].y + PlasticTabbedPaneUI.this.rects[(i - 1)].height);
/*  887:     */           }
/*  888:     */           else
/*  889:     */           {
/*  890:1113 */             PlasticTabbedPaneUI.this.tabRuns[0] = 0;
/*  891:1114 */             PlasticTabbedPaneUI.this.runCount = 1;
/*  892:1115 */             PlasticTabbedPaneUI.this.maxTabHeight = 0;
/*  893:1116 */             rect.y = y;
/*  894:     */           }
/*  895:1119 */           rect.height = PlasticTabbedPaneUI.this.calculateTabHeight(tabPlacement, i, fontHeight);
/*  896:1120 */           PlasticTabbedPaneUI.this.maxTabHeight = Math.max(PlasticTabbedPaneUI.this.maxTabHeight, rect.height);
/*  897:1126 */           if ((tabInRun != 0) && (rect.y + rect.height > runReturnAt))
/*  898:     */           {
/*  899:1127 */             if (PlasticTabbedPaneUI.this.runCount > PlasticTabbedPaneUI.this.tabRuns.length - 1) {
/*  900:1128 */               PlasticTabbedPaneUI.this.expandTabRunsArray();
/*  901:     */             }
/*  902:1130 */             PlasticTabbedPaneUI.this.tabRuns[PlasticTabbedPaneUI.this.runCount] = i;
/*  903:1131 */             PlasticTabbedPaneUI.access$6208(PlasticTabbedPaneUI.this);
/*  904:1132 */             rect.y = y;
/*  905:1133 */             tabInRun = 0;
/*  906:1134 */             runReturnAt -= 2 * PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, PlasticTabbedPaneUI.this.runCount);
/*  907:     */           }
/*  908:1137 */           rect.x = x;
/*  909:1138 */           rect.width = PlasticTabbedPaneUI.this.maxTabWidth;
/*  910:     */         }
/*  911:1141 */         if (i == selectedIndex) {
/*  912:1142 */           PlasticTabbedPaneUI.this.selectedRun = (PlasticTabbedPaneUI.this.runCount - 1);
/*  913:     */         }
/*  914:     */       }
/*  915:1146 */       if (PlasticTabbedPaneUI.this.runCount > 1) {
/*  916:1154 */         if (PlasticTabbedPaneUI.this.shouldRotateTabRuns(tabPlacement)) {
/*  917:1155 */           rotateTabRuns(tabPlacement, PlasticTabbedPaneUI.this.selectedRun);
/*  918:     */         }
/*  919:     */       }
/*  920:1161 */       for (i = PlasticTabbedPaneUI.this.runCount - 1; i >= 0; i--)
/*  921:     */       {
/*  922:1162 */         int start = PlasticTabbedPaneUI.this.tabRuns[i];
/*  923:1163 */         int next = PlasticTabbedPaneUI.this.tabRuns[(i + 1)];
/*  924:1164 */         int end = next != 0 ? next - 1 : tabCount - 1;
/*  925:1165 */         int indent = PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, i);
/*  926:1166 */         if (!verticalTabRuns)
/*  927:     */         {
/*  928:1167 */           for (int j = start; j <= end; j++)
/*  929:     */           {
/*  930:1168 */             Rectangle rect = PlasticTabbedPaneUI.this.rects[j];
/*  931:1169 */             rect.y = y;
/*  932:1170 */             rect.x += indent;
/*  933:     */           }
/*  934:1174 */           if (PlasticTabbedPaneUI.this.shouldPadTabRun(tabPlacement, i)) {
/*  935:1175 */             padTabRun(tabPlacement, start, end, returnAt - 2 * indent);
/*  936:     */           }
/*  937:1177 */           if (tabPlacement == 3) {
/*  938:1178 */             y -= PlasticTabbedPaneUI.this.maxTabHeight - theTabRunOverlay;
/*  939:     */           } else {
/*  940:1180 */             y += PlasticTabbedPaneUI.this.maxTabHeight - theTabRunOverlay;
/*  941:     */           }
/*  942:     */         }
/*  943:     */         else
/*  944:     */         {
/*  945:1183 */           for (int j = start; j <= end; j++)
/*  946:     */           {
/*  947:1184 */             Rectangle rect = PlasticTabbedPaneUI.this.rects[j];
/*  948:1185 */             rect.x = x;
/*  949:1186 */             rect.y += indent;
/*  950:     */           }
/*  951:1188 */           if (PlasticTabbedPaneUI.this.shouldPadTabRun(tabPlacement, i)) {
/*  952:1189 */             padTabRun(tabPlacement, start, end, returnAt - 2 * indent);
/*  953:     */           }
/*  954:1191 */           if (tabPlacement == 4) {
/*  955:1192 */             x -= PlasticTabbedPaneUI.this.maxTabWidth - theTabRunOverlay;
/*  956:     */           } else {
/*  957:1194 */             x += PlasticTabbedPaneUI.this.maxTabWidth - theTabRunOverlay;
/*  958:     */           }
/*  959:     */         }
/*  960:     */       }
/*  961:1200 */       padSelectedTab(tabPlacement, selectedIndex);
/*  962:1204 */       if ((!leftToRight) && (!verticalTabRuns))
/*  963:     */       {
/*  964:1205 */         int rightMargin = size.width - (insets.right + theTabAreaInsets.right);
/*  965:1206 */         for (i = 0; i < tabCount; i++) {
/*  966:1207 */           PlasticTabbedPaneUI.this.rects[i].x = (rightMargin - PlasticTabbedPaneUI.this.rects[i].x - PlasticTabbedPaneUI.this.rects[i].width + PlasticTabbedPaneUI.this.renderer.getTabsOverlay());
/*  967:     */         }
/*  968:     */       }
/*  969:     */     }
/*  970:     */     
/*  971:     */     protected void padSelectedTab(int tabPlacement, int selectedIndex)
/*  972:     */     {
/*  973:1217 */       if (selectedIndex >= 0)
/*  974:     */       {
/*  975:1218 */         Rectangle selRect = PlasticTabbedPaneUI.this.rects[selectedIndex];
/*  976:1219 */         Insets padInsets = PlasticTabbedPaneUI.this.getSelectedTabPadInsets(tabPlacement);
/*  977:1220 */         selRect.x -= padInsets.left;
/*  978:1221 */         selRect.width += padInsets.left + padInsets.right;
/*  979:1222 */         selRect.y -= padInsets.top;
/*  980:1223 */         selRect.height += padInsets.top + padInsets.bottom;
/*  981:     */       }
/*  982:     */     }
/*  983:     */   }
/*  984:     */   
/*  985:     */   private boolean requestFocusForVisibleComponent()
/*  986:     */   {
/*  987:1231 */     Component visibleComponent = getVisibleComponent();
/*  988:1232 */     if (visibleComponent.isFocusable())
/*  989:     */     {
/*  990:1233 */       visibleComponent.requestFocus();
/*  991:1234 */       return true;
/*  992:     */     }
/*  993:1236 */     if (((visibleComponent instanceof JComponent)) && 
/*  994:1237 */       (((JComponent)visibleComponent).requestDefaultFocus())) {
/*  995:1238 */       return true;
/*  996:     */     }
/*  997:1241 */     return false;
/*  998:     */   }
/*  999:     */   
/* 1000:     */   private static class ScrollTabsForwardAction
/* 1001:     */     extends AbstractAction
/* 1002:     */   {
/* 1003:     */     ScrollTabsForwardAction(PlasticTabbedPaneUI.1 x0)
/* 1004:     */     {
/* 1005:1244 */       this();
/* 1006:     */     }
/* 1007:     */     
/* 1008:     */     public void actionPerformed(ActionEvent e)
/* 1009:     */     {
/* 1010:1247 */       JTabbedPane pane = null;
/* 1011:1248 */       Object src = e.getSource();
/* 1012:1249 */       if ((src instanceof JTabbedPane)) {
/* 1013:1250 */         pane = (JTabbedPane)src;
/* 1014:1251 */       } else if ((src instanceof PlasticArrowButton)) {
/* 1015:1252 */         pane = (JTabbedPane)((PlasticArrowButton)src).getParent();
/* 1016:     */       } else {
/* 1017:1254 */         return;
/* 1018:     */       }
/* 1019:1256 */       PlasticTabbedPaneUI ui = (PlasticTabbedPaneUI)pane.getUI();
/* 1020:1258 */       if (ui.scrollableTabLayoutEnabled()) {
/* 1021:1259 */         ui.tabScroller.scrollForward(pane.getTabPlacement());
/* 1022:     */       }
/* 1023:     */     }
/* 1024:     */     
/* 1025:     */     private ScrollTabsForwardAction() {}
/* 1026:     */   }
/* 1027:     */   
/* 1028:     */   private static class ScrollTabsBackwardAction
/* 1029:     */     extends AbstractAction
/* 1030:     */   {
/* 1031:     */     ScrollTabsBackwardAction(PlasticTabbedPaneUI.1 x0)
/* 1032:     */     {
/* 1033:1264 */       this();
/* 1034:     */     }
/* 1035:     */     
/* 1036:     */     public void actionPerformed(ActionEvent e)
/* 1037:     */     {
/* 1038:1267 */       JTabbedPane pane = null;
/* 1039:1268 */       Object src = e.getSource();
/* 1040:1269 */       if ((src instanceof JTabbedPane)) {
/* 1041:1270 */         pane = (JTabbedPane)src;
/* 1042:1271 */       } else if ((src instanceof PlasticArrowButton)) {
/* 1043:1272 */         pane = (JTabbedPane)((PlasticArrowButton)src).getParent();
/* 1044:     */       } else {
/* 1045:1274 */         return;
/* 1046:     */       }
/* 1047:1276 */       PlasticTabbedPaneUI ui = (PlasticTabbedPaneUI)pane.getUI();
/* 1048:1278 */       if (ui.scrollableTabLayoutEnabled()) {
/* 1049:1279 */         ui.tabScroller.scrollBackward(pane.getTabPlacement());
/* 1050:     */       }
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     private ScrollTabsBackwardAction() {}
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   private class TabbedPaneScrollLayout
/* 1057:     */     extends PlasticTabbedPaneUI.TabbedPaneLayout
/* 1058:     */   {
/* 1059:     */     TabbedPaneScrollLayout(PlasticTabbedPaneUI.1 x1)
/* 1060:     */     {
/* 1061:1284 */       this();
/* 1062:     */     }
/* 1063:     */     
/* 1064:     */     private TabbedPaneScrollLayout()
/* 1065:     */     {
/* 1066:1284 */       super(null);
/* 1067:     */     }
/* 1068:     */     
/* 1069:     */     protected int preferredTabAreaHeight(int tabPlacement, int width)
/* 1070:     */     {
/* 1071:1287 */       return PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement);
/* 1072:     */     }
/* 1073:     */     
/* 1074:     */     protected int preferredTabAreaWidth(int tabPlacement, int height)
/* 1075:     */     {
/* 1076:1291 */       return PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement);
/* 1077:     */     }
/* 1078:     */     
/* 1079:     */     public void layoutContainer(Container parent)
/* 1080:     */     {
/* 1081:1295 */       int tabPlacement = PlasticTabbedPaneUI.this.tabPane.getTabPlacement();
/* 1082:1296 */       int tabCount = PlasticTabbedPaneUI.this.tabPane.getTabCount();
/* 1083:1297 */       Insets insets = PlasticTabbedPaneUI.this.tabPane.getInsets();
/* 1084:1298 */       int selectedIndex = PlasticTabbedPaneUI.this.tabPane.getSelectedIndex();
/* 1085:1299 */       Component visibleComponent = PlasticTabbedPaneUI.this.getVisibleComponent();
/* 1086:     */       
/* 1087:1301 */       calculateLayoutInfo();
/* 1088:1303 */       if (selectedIndex < 0)
/* 1089:     */       {
/* 1090:1304 */         if (visibleComponent != null) {
/* 1091:1306 */           PlasticTabbedPaneUI.this.setVisibleComponent(null);
/* 1092:     */         }
/* 1093:     */       }
/* 1094:     */       else
/* 1095:     */       {
/* 1096:1309 */         Component selectedComponent = PlasticTabbedPaneUI.this.tabPane.getComponentAt(selectedIndex);
/* 1097:1310 */         boolean shouldChangeFocus = false;
/* 1098:1319 */         if (selectedComponent != null)
/* 1099:     */         {
/* 1100:1320 */           if ((selectedComponent != visibleComponent) && (visibleComponent != null)) {
/* 1101:1322 */             if (SwingUtilities.findFocusOwner(visibleComponent) != null) {
/* 1102:1323 */               shouldChangeFocus = true;
/* 1103:     */             }
/* 1104:     */           }
/* 1105:1326 */           PlasticTabbedPaneUI.this.setVisibleComponent(selectedComponent);
/* 1106:     */         }
/* 1107:1330 */         Insets contentInsets = PlasticTabbedPaneUI.this.getContentBorderInsets(tabPlacement);
/* 1108:1331 */         Rectangle bounds = PlasticTabbedPaneUI.this.tabPane.getBounds();
/* 1109:1332 */         int numChildren = PlasticTabbedPaneUI.this.tabPane.getComponentCount();
/* 1110:1334 */         if (numChildren > 0)
/* 1111:     */         {
/* 1112:     */           int tw;
/* 1113:     */           int th;
/* 1114:     */           int tx;
/* 1115:     */           int ty;
/* 1116:     */           int cx;
/* 1117:     */           int cy;
/* 1118:     */           int cw;
/* 1119:     */           int ch;
/* 1120:1335 */           switch (tabPlacement)
/* 1121:     */           {
/* 1122:     */           case 2: 
/* 1123:1338 */             tw = PlasticTabbedPaneUI.this.calculateTabAreaWidth(tabPlacement, PlasticTabbedPaneUI.this.runCount, PlasticTabbedPaneUI.this.maxTabWidth);
/* 1124:     */             
/* 1125:1340 */             th = bounds.height - insets.top - insets.bottom;
/* 1126:1341 */             tx = insets.left;
/* 1127:1342 */             ty = insets.top;
/* 1128:     */             
/* 1129:     */ 
/* 1130:1345 */             cx = tx + tw + contentInsets.left;
/* 1131:1346 */             cy = ty + contentInsets.top;
/* 1132:1347 */             cw = bounds.width - insets.left - insets.right - tw - contentInsets.left - contentInsets.right;
/* 1133:     */             
/* 1134:1349 */             ch = bounds.height - insets.top - insets.bottom - contentInsets.top - contentInsets.bottom;
/* 1135:     */             
/* 1136:1351 */             break;
/* 1137:     */           case 4: 
/* 1138:1354 */             tw = PlasticTabbedPaneUI.this.calculateTabAreaWidth(tabPlacement, PlasticTabbedPaneUI.this.runCount, PlasticTabbedPaneUI.this.maxTabWidth);
/* 1139:     */             
/* 1140:1356 */             th = bounds.height - insets.top - insets.bottom;
/* 1141:1357 */             tx = bounds.width - insets.right - tw;
/* 1142:1358 */             ty = insets.top;
/* 1143:     */             
/* 1144:     */ 
/* 1145:1361 */             cx = insets.left + contentInsets.left;
/* 1146:1362 */             cy = insets.top + contentInsets.top;
/* 1147:1363 */             cw = bounds.width - insets.left - insets.right - tw - contentInsets.left - contentInsets.right;
/* 1148:     */             
/* 1149:1365 */             ch = bounds.height - insets.top - insets.bottom - contentInsets.top - contentInsets.bottom;
/* 1150:     */             
/* 1151:1367 */             break;
/* 1152:     */           case 3: 
/* 1153:1370 */             tw = bounds.width - insets.left - insets.right;
/* 1154:1371 */             th = PlasticTabbedPaneUI.this.calculateTabAreaHeight(tabPlacement, PlasticTabbedPaneUI.this.runCount, PlasticTabbedPaneUI.this.maxTabHeight);
/* 1155:     */             
/* 1156:1373 */             tx = insets.left;
/* 1157:1374 */             ty = bounds.height - insets.bottom - th;
/* 1158:     */             
/* 1159:     */ 
/* 1160:1377 */             cx = insets.left + contentInsets.left;
/* 1161:1378 */             cy = insets.top + contentInsets.top;
/* 1162:1379 */             cw = bounds.width - insets.left - insets.right - contentInsets.left - contentInsets.right;
/* 1163:     */             
/* 1164:1381 */             ch = bounds.height - insets.top - insets.bottom - th - contentInsets.top - contentInsets.bottom;
/* 1165:     */             
/* 1166:1383 */             break;
/* 1167:     */           case 1: 
/* 1168:     */           default: 
/* 1169:1387 */             tw = bounds.width - insets.left - insets.right;
/* 1170:1388 */             th = PlasticTabbedPaneUI.this.calculateTabAreaHeight(tabPlacement, PlasticTabbedPaneUI.this.runCount, PlasticTabbedPaneUI.this.maxTabHeight);
/* 1171:     */             
/* 1172:1390 */             tx = insets.left;
/* 1173:1391 */             ty = insets.top;
/* 1174:     */             
/* 1175:     */ 
/* 1176:1394 */             cx = tx + contentInsets.left;
/* 1177:1395 */             cy = ty + th + contentInsets.top;
/* 1178:1396 */             cw = bounds.width - insets.left - insets.right - contentInsets.left - contentInsets.right;
/* 1179:     */             
/* 1180:1398 */             ch = bounds.height - insets.top - insets.bottom - th - contentInsets.top - contentInsets.bottom;
/* 1181:     */           }
/* 1182:1402 */           for (int i = 0; i < numChildren; i++)
/* 1183:     */           {
/* 1184:1403 */             Component child = PlasticTabbedPaneUI.this.tabPane.getComponent(i);
/* 1185:1405 */             if ((PlasticTabbedPaneUI.this.tabScroller != null) && (child == PlasticTabbedPaneUI.this.tabScroller.viewport))
/* 1186:     */             {
/* 1187:1406 */               JViewport viewport = (JViewport)child;
/* 1188:1407 */               Rectangle viewRect = viewport.getViewRect();
/* 1189:1408 */               int vw = tw;
/* 1190:1409 */               int vh = th;
/* 1191:1410 */               Dimension butSize = PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton.getPreferredSize();
/* 1192:1411 */               switch (tabPlacement)
/* 1193:     */               {
/* 1194:     */               case 2: 
/* 1195:     */               case 4: 
/* 1196:1414 */                 int totalTabHeight = PlasticTabbedPaneUI.this.rects[(tabCount - 1)].y + PlasticTabbedPaneUI.this.rects[(tabCount - 1)].height;
/* 1197:1416 */                 if (totalTabHeight > th)
/* 1198:     */                 {
/* 1199:1418 */                   vh = th > 2 * butSize.height ? th - 2 * butSize.height : 0;
/* 1200:1420 */                   if (totalTabHeight - viewRect.y <= vh) {
/* 1201:1425 */                     vh = totalTabHeight - viewRect.y;
/* 1202:     */                   }
/* 1203:     */                 }
/* 1204:     */                 break;
/* 1205:     */               case 1: 
/* 1206:     */               case 3: 
/* 1207:     */               default: 
/* 1208:1432 */                 int totalTabWidth = PlasticTabbedPaneUI.this.rects[(tabCount - 1)].x + PlasticTabbedPaneUI.this.rects[(tabCount - 1)].width + PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1209:1434 */                 if (totalTabWidth > tw)
/* 1210:     */                 {
/* 1211:1436 */                   vw = tw > 2 * butSize.width ? tw - 2 * butSize.width : 0;
/* 1212:1438 */                   if (totalTabWidth - viewRect.x <= vw) {
/* 1213:1443 */                     vw = totalTabWidth - viewRect.x;
/* 1214:     */                   }
/* 1215:     */                 }
/* 1216:     */                 break;
/* 1217:     */               }
/* 1218:1447 */               child.setBounds(tx, ty, vw, vh);
/* 1219:     */             }
/* 1220:1449 */             else if ((PlasticTabbedPaneUI.this.tabScroller != null) && ((child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton) || (child == PlasticTabbedPaneUI.this.tabScroller.scrollBackwardButton)))
/* 1221:     */             {
/* 1222:1452 */               Component scrollbutton = child;
/* 1223:1453 */               Dimension bsize = scrollbutton.getPreferredSize();
/* 1224:1454 */               int bx = 0;
/* 1225:1455 */               int by = 0;
/* 1226:1456 */               int bw = bsize.width;
/* 1227:1457 */               int bh = bsize.height;
/* 1228:1458 */               boolean visible = false;
/* 1229:1460 */               switch (tabPlacement)
/* 1230:     */               {
/* 1231:     */               case 2: 
/* 1232:     */               case 4: 
/* 1233:1463 */                 int totalTabHeight = PlasticTabbedPaneUI.this.rects[(tabCount - 1)].y + PlasticTabbedPaneUI.this.rects[(tabCount - 1)].height + PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1234:1466 */                 if (totalTabHeight > th)
/* 1235:     */                 {
/* 1236:1467 */                   visible = true;
/* 1237:1468 */                   bx = tabPlacement == 2 ? tx + tw - bsize.width : tx;
/* 1238:     */                   
/* 1239:1470 */                   by = child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton ? bounds.height - insets.bottom - bsize.height : bounds.height - insets.bottom - 2 * bsize.height;
/* 1240:     */                 }
/* 1241:     */                 break;
/* 1242:     */               case 1: 
/* 1243:     */               case 3: 
/* 1244:     */               default: 
/* 1245:1480 */                 int totalTabWidth = PlasticTabbedPaneUI.this.rects[(tabCount - 1)].x + PlasticTabbedPaneUI.this.rects[(tabCount - 1)].width + PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1246:1484 */                 if (totalTabWidth > tw)
/* 1247:     */                 {
/* 1248:1485 */                   visible = true;
/* 1249:1486 */                   bx = child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton ? bounds.width - insets.left - bsize.width : bounds.width - insets.left - 2 * bsize.width;
/* 1250:     */                   
/* 1251:     */ 
/* 1252:     */ 
/* 1253:1490 */                   by = tabPlacement == 1 ? ty + th - bsize.height : ty;
/* 1254:     */                 }
/* 1255:     */                 break;
/* 1256:     */               }
/* 1257:1494 */               child.setVisible(visible);
/* 1258:1495 */               if (visible) {
/* 1259:1496 */                 child.setBounds(bx, by, bw, bh);
/* 1260:     */               }
/* 1261:     */             }
/* 1262:     */             else
/* 1263:     */             {
/* 1264:1501 */               child.setBounds(cx, cy, cw, ch);
/* 1265:     */             }
/* 1266:     */           }
/* 1267:1504 */           if ((shouldChangeFocus) && 
/* 1268:1505 */             (!PlasticTabbedPaneUI.this.requestFocusForVisibleComponent())) {
/* 1269:1506 */             PlasticTabbedPaneUI.this.tabPane.requestFocus();
/* 1270:     */           }
/* 1271:     */         }
/* 1272:     */       }
/* 1273:     */     }
/* 1274:     */     
/* 1275:     */     protected void calculateTabRects(int tabPlacement, int tabCount)
/* 1276:     */     {
/* 1277:1514 */       FontMetrics metrics = PlasticTabbedPaneUI.this.getFontMetrics();
/* 1278:1515 */       Dimension size = PlasticTabbedPaneUI.this.tabPane.getSize();
/* 1279:1516 */       Insets insets = PlasticTabbedPaneUI.this.tabPane.getInsets();
/* 1280:1517 */       Insets tabAreaInsets = PlasticTabbedPaneUI.this.getTabAreaInsets(tabPlacement);
/* 1281:1518 */       int fontHeight = metrics.getHeight();
/* 1282:1519 */       int selectedIndex = PlasticTabbedPaneUI.this.tabPane.getSelectedIndex();
/* 1283:1520 */       boolean verticalTabRuns = (tabPlacement == 2) || (tabPlacement == 4);
/* 1284:1521 */       boolean leftToRight = PlasticUtils.isLeftToRight(PlasticTabbedPaneUI.this.tabPane);
/* 1285:1522 */       int x = tabAreaInsets.left;
/* 1286:1523 */       int y = tabAreaInsets.top;
/* 1287:1524 */       int totalWidth = 0;
/* 1288:1525 */       int totalHeight = 0;
/* 1289:1530 */       switch (tabPlacement)
/* 1290:     */       {
/* 1291:     */       case 2: 
/* 1292:     */       case 4: 
/* 1293:1533 */         PlasticTabbedPaneUI.this.maxTabWidth = PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement);
/* 1294:1534 */         break;
/* 1295:     */       case 1: 
/* 1296:     */       case 3: 
/* 1297:     */       default: 
/* 1298:1538 */         PlasticTabbedPaneUI.this.maxTabHeight = PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement);
/* 1299:     */       }
/* 1300:1541 */       PlasticTabbedPaneUI.this.runCount = 0;
/* 1301:1542 */       PlasticTabbedPaneUI.this.selectedRun = -1;
/* 1302:1544 */       if (tabCount == 0) {
/* 1303:1545 */         return;
/* 1304:     */       }
/* 1305:1548 */       PlasticTabbedPaneUI.this.selectedRun = 0;
/* 1306:1549 */       PlasticTabbedPaneUI.this.runCount = 1;
/* 1307:1553 */       for (int i = 0; i < tabCount; i++)
/* 1308:     */       {
/* 1309:1554 */         Rectangle rect = PlasticTabbedPaneUI.this.rects[i];
/* 1310:1556 */         if (!verticalTabRuns)
/* 1311:     */         {
/* 1312:1558 */           if (i > 0)
/* 1313:     */           {
/* 1314:1559 */             rect.x = (PlasticTabbedPaneUI.this.rects[(i - 1)].x + PlasticTabbedPaneUI.this.rects[(i - 1)].width);
/* 1315:     */           }
/* 1316:     */           else
/* 1317:     */           {
/* 1318:1561 */             PlasticTabbedPaneUI.this.tabRuns[0] = 0;
/* 1319:1562 */             PlasticTabbedPaneUI.this.maxTabWidth = 0;
/* 1320:1563 */             totalHeight += PlasticTabbedPaneUI.this.maxTabHeight;
/* 1321:1564 */             rect.x = x;
/* 1322:     */           }
/* 1323:1566 */           rect.width = PlasticTabbedPaneUI.this.calculateTabWidth(tabPlacement, i, metrics);
/* 1324:1567 */           totalWidth = rect.x + rect.width + PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1325:1568 */           PlasticTabbedPaneUI.this.maxTabWidth = Math.max(PlasticTabbedPaneUI.this.maxTabWidth, rect.width);
/* 1326:     */           
/* 1327:1570 */           rect.y = y;
/* 1328:1571 */           rect.height = PlasticTabbedPaneUI.this.maxTabHeight;
/* 1329:     */         }
/* 1330:     */         else
/* 1331:     */         {
/* 1332:1575 */           if (i > 0)
/* 1333:     */           {
/* 1334:1576 */             rect.y = (PlasticTabbedPaneUI.this.rects[(i - 1)].y + PlasticTabbedPaneUI.this.rects[(i - 1)].height);
/* 1335:     */           }
/* 1336:     */           else
/* 1337:     */           {
/* 1338:1578 */             PlasticTabbedPaneUI.this.tabRuns[0] = 0;
/* 1339:1579 */             PlasticTabbedPaneUI.this.maxTabHeight = 0;
/* 1340:1580 */             totalWidth = PlasticTabbedPaneUI.this.maxTabWidth;
/* 1341:1581 */             rect.y = y;
/* 1342:     */           }
/* 1343:1583 */           rect.height = PlasticTabbedPaneUI.this.calculateTabHeight(tabPlacement, i, fontHeight);
/* 1344:1584 */           totalHeight = rect.y + rect.height;
/* 1345:1585 */           PlasticTabbedPaneUI.this.maxTabHeight = Math.max(PlasticTabbedPaneUI.this.maxTabHeight, rect.height);
/* 1346:     */           
/* 1347:1587 */           rect.x = x;
/* 1348:1588 */           rect.width = PlasticTabbedPaneUI.this.maxTabWidth;
/* 1349:     */         }
/* 1350:     */       }
/* 1351:1594 */       padSelectedTab(tabPlacement, selectedIndex);
/* 1352:1598 */       if ((!leftToRight) && (!verticalTabRuns))
/* 1353:     */       {
/* 1354:1599 */         int rightMargin = size.width - (insets.right + tabAreaInsets.right);
/* 1355:1601 */         for (int i = 0; i < tabCount; i++) {
/* 1356:1602 */           PlasticTabbedPaneUI.this.rects[i].x = (rightMargin - PlasticTabbedPaneUI.this.rects[i].x - PlasticTabbedPaneUI.this.rects[i].width);
/* 1357:     */         }
/* 1358:     */       }
/* 1359:1605 */       PlasticTabbedPaneUI.this.tabScroller.tabPanel.setPreferredSize(new Dimension(totalWidth, totalHeight));
/* 1360:     */     }
/* 1361:     */   }
/* 1362:     */   
/* 1363:     */   private class ScrollableTabSupport
/* 1364:     */     implements ActionListener, ChangeListener
/* 1365:     */   {
/* 1366:     */     public PlasticTabbedPaneUI.ScrollableTabViewport viewport;
/* 1367:     */     public PlasticTabbedPaneUI.ScrollableTabPanel tabPanel;
/* 1368:     */     public JButton scrollForwardButton;
/* 1369:     */     public JButton scrollBackwardButton;
/* 1370:     */     public int leadingTabIndex;
/* 1371:1617 */     private Point tabViewPosition = new Point(0, 0);
/* 1372:     */     
/* 1373:     */     ScrollableTabSupport(int tabPlacement)
/* 1374:     */     {
/* 1375:1620 */       this.viewport = new PlasticTabbedPaneUI.ScrollableTabViewport(PlasticTabbedPaneUI.this);
/* 1376:1621 */       this.tabPanel = new PlasticTabbedPaneUI.ScrollableTabPanel(PlasticTabbedPaneUI.this);
/* 1377:1622 */       this.viewport.setView(this.tabPanel);
/* 1378:1623 */       this.viewport.addChangeListener(this);
/* 1379:1624 */       createButtons();
/* 1380:     */     }
/* 1381:     */     
/* 1382:     */     void createButtons()
/* 1383:     */     {
/* 1384:1631 */       if (this.scrollForwardButton != null)
/* 1385:     */       {
/* 1386:1632 */         PlasticTabbedPaneUI.this.tabPane.remove(this.scrollForwardButton);
/* 1387:1633 */         this.scrollForwardButton.removeActionListener(this);
/* 1388:1634 */         PlasticTabbedPaneUI.this.tabPane.remove(this.scrollBackwardButton);
/* 1389:1635 */         this.scrollBackwardButton.removeActionListener(this);
/* 1390:     */       }
/* 1391:1637 */       int tabPlacement = PlasticTabbedPaneUI.this.tabPane.getTabPlacement();
/* 1392:1638 */       int width = UIManager.getInt("ScrollBar.width");
/* 1393:1639 */       if ((tabPlacement == 1) || (tabPlacement == 3))
/* 1394:     */       {
/* 1395:1640 */         this.scrollForwardButton = new PlasticTabbedPaneUI.ArrowButton(3, width);
/* 1396:1641 */         this.scrollBackwardButton = new PlasticTabbedPaneUI.ArrowButton(7, width);
/* 1397:     */       }
/* 1398:     */       else
/* 1399:     */       {
/* 1400:1643 */         this.scrollForwardButton = new PlasticTabbedPaneUI.ArrowButton(5, width);
/* 1401:1644 */         this.scrollBackwardButton = new PlasticTabbedPaneUI.ArrowButton(1, width);
/* 1402:     */       }
/* 1403:1646 */       this.scrollForwardButton.addActionListener(this);
/* 1404:1647 */       this.scrollBackwardButton.addActionListener(this);
/* 1405:1648 */       PlasticTabbedPaneUI.this.tabPane.add(this.scrollForwardButton);
/* 1406:1649 */       PlasticTabbedPaneUI.this.tabPane.add(this.scrollBackwardButton);
/* 1407:     */     }
/* 1408:     */     
/* 1409:     */     public void scrollForward(int tabPlacement)
/* 1410:     */     {
/* 1411:1653 */       Dimension viewSize = this.viewport.getViewSize();
/* 1412:1654 */       Rectangle viewRect = this.viewport.getViewRect();
/* 1413:1656 */       if ((tabPlacement == 1) || (tabPlacement == 3))
/* 1414:     */       {
/* 1415:1657 */         if (viewRect.width < viewSize.width - viewRect.x) {}
/* 1416:     */       }
/* 1417:1661 */       else if (viewRect.height >= viewSize.height - viewRect.y) {
/* 1418:1662 */         return;
/* 1419:     */       }
/* 1420:1665 */       setLeadingTabIndex(tabPlacement, this.leadingTabIndex + 1);
/* 1421:     */     }
/* 1422:     */     
/* 1423:     */     public void scrollBackward(int tabPlacement)
/* 1424:     */     {
/* 1425:1669 */       if (this.leadingTabIndex == 0) {
/* 1426:1670 */         return;
/* 1427:     */       }
/* 1428:1672 */       setLeadingTabIndex(tabPlacement, this.leadingTabIndex - 1);
/* 1429:     */     }
/* 1430:     */     
/* 1431:     */     public void setLeadingTabIndex(int tabPlacement, int index)
/* 1432:     */     {
/* 1433:1676 */       this.leadingTabIndex = index;
/* 1434:1677 */       Dimension viewSize = this.viewport.getViewSize();
/* 1435:1678 */       Rectangle viewRect = this.viewport.getViewRect();
/* 1436:1680 */       switch (tabPlacement)
/* 1437:     */       {
/* 1438:     */       case 1: 
/* 1439:     */       case 3: 
/* 1440:1683 */         this.tabViewPosition.x = (this.leadingTabIndex == 0 ? 0 : PlasticTabbedPaneUI.this.rects[this.leadingTabIndex].x - PlasticTabbedPaneUI.this.renderer.getTabsOverlay());
/* 1441:1686 */         if (viewSize.width - this.tabViewPosition.x < viewRect.width)
/* 1442:     */         {
/* 1443:1690 */           Dimension extentSize = new Dimension(viewSize.width - this.tabViewPosition.x, viewRect.height);
/* 1444:     */           
/* 1445:1692 */           this.viewport.setExtentSize(extentSize);
/* 1446:     */         }
/* 1447:1693 */         break;
/* 1448:     */       case 2: 
/* 1449:     */       case 4: 
/* 1450:1697 */         this.tabViewPosition.y = (this.leadingTabIndex == 0 ? 0 : PlasticTabbedPaneUI.this.rects[this.leadingTabIndex].y);
/* 1451:1700 */         if (viewSize.height - this.tabViewPosition.y < viewRect.height)
/* 1452:     */         {
/* 1453:1704 */           Dimension extentSize = new Dimension(viewRect.width, viewSize.height - this.tabViewPosition.y);
/* 1454:     */           
/* 1455:1706 */           this.viewport.setExtentSize(extentSize);
/* 1456:     */         }
/* 1457:     */         break;
/* 1458:     */       }
/* 1459:1709 */       this.viewport.setViewPosition(this.tabViewPosition);
/* 1460:     */     }
/* 1461:     */     
/* 1462:     */     public void stateChanged(ChangeEvent e)
/* 1463:     */     {
/* 1464:1713 */       JViewport viewport = (JViewport)e.getSource();
/* 1465:1714 */       int tabPlacement = PlasticTabbedPaneUI.this.tabPane.getTabPlacement();
/* 1466:1715 */       int tabCount = PlasticTabbedPaneUI.this.tabPane.getTabCount();
/* 1467:1716 */       Rectangle vpRect = viewport.getBounds();
/* 1468:1717 */       Dimension viewSize = viewport.getViewSize();
/* 1469:1718 */       Rectangle viewRect = viewport.getViewRect();
/* 1470:     */       
/* 1471:1720 */       this.leadingTabIndex = PlasticTabbedPaneUI.this.getClosestTab(viewRect.x, viewRect.y);
/* 1472:1723 */       if (this.leadingTabIndex + 1 < tabCount) {
/* 1473:1724 */         switch (tabPlacement)
/* 1474:     */         {
/* 1475:     */         case 1: 
/* 1476:     */         case 3: 
/* 1477:1727 */           if (PlasticTabbedPaneUI.this.rects[this.leadingTabIndex].x < viewRect.x) {
/* 1478:1728 */             this.leadingTabIndex += 1;
/* 1479:     */           }
/* 1480:     */           break;
/* 1481:     */         case 2: 
/* 1482:     */         case 4: 
/* 1483:1733 */           if (PlasticTabbedPaneUI.this.rects[this.leadingTabIndex].y < viewRect.y) {
/* 1484:1734 */             this.leadingTabIndex += 1;
/* 1485:     */           }
/* 1486:     */           break;
/* 1487:     */         }
/* 1488:     */       }
/* 1489:1739 */       Insets contentInsets = PlasticTabbedPaneUI.this.getContentBorderInsets(tabPlacement);
/* 1490:1740 */       switch (tabPlacement)
/* 1491:     */       {
/* 1492:     */       case 2: 
/* 1493:1742 */         PlasticTabbedPaneUI.this.tabPane.repaint(vpRect.x + vpRect.width, vpRect.y, contentInsets.left, vpRect.height);
/* 1494:     */         
/* 1495:1744 */         this.scrollBackwardButton.setEnabled((viewRect.y > 0) && (this.leadingTabIndex > 0));
/* 1496:     */         
/* 1497:1746 */         this.scrollForwardButton.setEnabled((this.leadingTabIndex < tabCount - 1) && (viewSize.height - viewRect.y > viewRect.height));
/* 1498:     */         
/* 1499:1748 */         break;
/* 1500:     */       case 4: 
/* 1501:1750 */         PlasticTabbedPaneUI.this.tabPane.repaint(vpRect.x - contentInsets.right, vpRect.y, contentInsets.right, vpRect.height);
/* 1502:     */         
/* 1503:1752 */         this.scrollBackwardButton.setEnabled((viewRect.y > 0) && (this.leadingTabIndex > 0));
/* 1504:     */         
/* 1505:1754 */         this.scrollForwardButton.setEnabled((this.leadingTabIndex < tabCount - 1) && (viewSize.height - viewRect.y > viewRect.height));
/* 1506:     */         
/* 1507:1756 */         break;
/* 1508:     */       case 3: 
/* 1509:1758 */         PlasticTabbedPaneUI.this.tabPane.repaint(vpRect.x, vpRect.y - contentInsets.bottom, vpRect.width, contentInsets.bottom);
/* 1510:     */         
/* 1511:1760 */         this.scrollBackwardButton.setEnabled((viewRect.x > 0) && (this.leadingTabIndex > 0));
/* 1512:     */         
/* 1513:1762 */         this.scrollForwardButton.setEnabled((this.leadingTabIndex < tabCount - 1) && (viewSize.width - viewRect.x > viewRect.width));
/* 1514:     */         
/* 1515:1764 */         break;
/* 1516:     */       case 1: 
/* 1517:     */       default: 
/* 1518:1767 */         PlasticTabbedPaneUI.this.tabPane.repaint(vpRect.x, vpRect.y + vpRect.height, vpRect.width, contentInsets.top);
/* 1519:     */         
/* 1520:1769 */         this.scrollBackwardButton.setEnabled((viewRect.x > 0) && (this.leadingTabIndex > 0));
/* 1521:     */         
/* 1522:1771 */         this.scrollForwardButton.setEnabled((this.leadingTabIndex < tabCount - 1) && (viewSize.width - viewRect.x > viewRect.width));
/* 1523:     */       }
/* 1524:     */     }
/* 1525:     */     
/* 1526:     */     public void actionPerformed(ActionEvent e)
/* 1527:     */     {
/* 1528:1780 */       ActionMap map = PlasticTabbedPaneUI.this.tabPane.getActionMap();
/* 1529:1782 */       if (map != null)
/* 1530:     */       {
/* 1531:     */         String actionKey;
/* 1532:     */         String actionKey;
/* 1533:1785 */         if (e.getSource() == this.scrollForwardButton) {
/* 1534:1786 */           actionKey = "scrollTabsForwardAction";
/* 1535:     */         } else {
/* 1536:1788 */           actionKey = "scrollTabsBackwardAction";
/* 1537:     */         }
/* 1538:1790 */         Action action = map.get(actionKey);
/* 1539:1792 */         if ((action != null) && (action.isEnabled())) {
/* 1540:1793 */           action.actionPerformed(new ActionEvent(PlasticTabbedPaneUI.this.tabPane, 1001, null, e.getWhen(), e.getModifiers()));
/* 1541:     */         }
/* 1542:     */       }
/* 1543:     */     }
/* 1544:     */   }
/* 1545:     */   
/* 1546:     */   private class ScrollableTabViewport
/* 1547:     */     extends JViewport
/* 1548:     */     implements UIResource
/* 1549:     */   {
/* 1550:     */     public ScrollableTabViewport()
/* 1551:     */     {
/* 1552:1806 */       setName("TabbedPane.scrollableViewport");
/* 1553:1807 */       setScrollMode(0);
/* 1554:1808 */       setOpaque(PlasticTabbedPaneUI.this.tabPane.isOpaque());
/* 1555:1809 */       Color bgColor = UIManager.getColor("TabbedPane.tabAreaBackground");
/* 1556:1810 */       if (bgColor == null) {
/* 1557:1811 */         bgColor = PlasticTabbedPaneUI.this.tabPane.getBackground();
/* 1558:     */       }
/* 1559:1813 */       setBackground(bgColor);
/* 1560:     */     }
/* 1561:     */   }
/* 1562:     */   
/* 1563:     */   private class ScrollableTabPanel
/* 1564:     */     extends JPanel
/* 1565:     */     implements UIResource
/* 1566:     */   {
/* 1567:     */     public ScrollableTabPanel()
/* 1568:     */     {
/* 1569:1820 */       super();
/* 1570:1821 */       setOpaque(PlasticTabbedPaneUI.this.tabPane.isOpaque());
/* 1571:1822 */       Color bgColor = UIManager.getColor("TabbedPane.tabAreaBackground");
/* 1572:1823 */       if (bgColor == null) {
/* 1573:1824 */         bgColor = PlasticTabbedPaneUI.this.tabPane.getBackground();
/* 1574:     */       }
/* 1575:1826 */       setBackground(bgColor);
/* 1576:     */     }
/* 1577:     */     
/* 1578:     */     public void paintComponent(Graphics g)
/* 1579:     */     {
/* 1580:1830 */       super.paintComponent(g);
/* 1581:1831 */       PlasticTabbedPaneUI.this.paintTabArea(g, PlasticTabbedPaneUI.this.tabPane.getTabPlacement(), PlasticTabbedPaneUI.this.tabPane.getSelectedIndex());
/* 1582:     */     }
/* 1583:     */   }
/* 1584:     */   
/* 1585:     */   private static class ArrowButton
/* 1586:     */     extends JButton
/* 1587:     */     implements UIResource
/* 1588:     */   {
/* 1589:     */     private final int buttonWidth;
/* 1590:     */     private final int direction;
/* 1591:     */     private boolean mouseIsOver;
/* 1592:     */     
/* 1593:     */     ArrowButton(int direction, int buttonWidth)
/* 1594:     */     {
/* 1595:1844 */       this.direction = direction;
/* 1596:1845 */       this.buttonWidth = buttonWidth;
/* 1597:1846 */       setRequestFocusEnabled(false);
/* 1598:     */     }
/* 1599:     */     
/* 1600:     */     protected void processMouseEvent(MouseEvent e)
/* 1601:     */     {
/* 1602:1850 */       super.processMouseEvent(e);
/* 1603:1851 */       switch (e.getID())
/* 1604:     */       {
/* 1605:     */       case 504: 
/* 1606:1853 */         this.mouseIsOver = true;
/* 1607:1854 */         revalidate();
/* 1608:1855 */         repaint();
/* 1609:1856 */         break;
/* 1610:     */       case 505: 
/* 1611:1858 */         this.mouseIsOver = false;
/* 1612:1859 */         revalidate();
/* 1613:1860 */         repaint();
/* 1614:     */       }
/* 1615:     */     }
/* 1616:     */     
/* 1617:     */     protected void paintBorder(Graphics g)
/* 1618:     */     {
/* 1619:1866 */       if ((this.mouseIsOver) && (isEnabled())) {
/* 1620:1867 */         super.paintBorder(g);
/* 1621:     */       }
/* 1622:     */     }
/* 1623:     */     
/* 1624:     */     protected void paintComponent(Graphics g)
/* 1625:     */     {
/* 1626:1872 */       if (this.mouseIsOver)
/* 1627:     */       {
/* 1628:1873 */         super.paintComponent(g);
/* 1629:     */       }
/* 1630:     */       else
/* 1631:     */       {
/* 1632:1875 */         g.setColor(getBackground());
/* 1633:1876 */         g.fillRect(0, 0, getWidth(), getHeight());
/* 1634:     */       }
/* 1635:1878 */       paintArrow(g);
/* 1636:     */     }
/* 1637:     */     
/* 1638:     */     private void paintArrow(Graphics g)
/* 1639:     */     {
/* 1640:1882 */       Color oldColor = g.getColor();
/* 1641:     */       
/* 1642:1884 */       boolean isEnabled = isEnabled();
/* 1643:1885 */       g.setColor(isEnabled ? PlasticLookAndFeel.getControlInfo() : PlasticLookAndFeel.getControlDisabled());
/* 1644:     */       int arrowWidth;
/* 1645:     */       int arrowHeight;
/* 1646:1889 */       switch (this.direction)
/* 1647:     */       {
/* 1648:     */       case 1: 
/* 1649:     */       case 5: 
/* 1650:1892 */         arrowWidth = 9;
/* 1651:1893 */         arrowHeight = 5;
/* 1652:1894 */         break;
/* 1653:     */       case 2: 
/* 1654:     */       case 3: 
/* 1655:     */       case 4: 
/* 1656:     */       case 6: 
/* 1657:     */       case 7: 
/* 1658:     */       default: 
/* 1659:1898 */         arrowWidth = 5;
/* 1660:1899 */         arrowHeight = 9;
/* 1661:     */       }
/* 1662:1902 */       int x = (getWidth() - arrowWidth) / 2;
/* 1663:1903 */       int y = (getHeight() - arrowHeight) / 2;
/* 1664:1904 */       g.translate(x, y);
/* 1665:     */       
/* 1666:1906 */       boolean paintShadow = (!this.mouseIsOver) || (!isEnabled);
/* 1667:1907 */       Color shadow = isEnabled ? PlasticLookAndFeel.getControlShadow() : UIManager.getColor("ScrollBar.highlight");
/* 1668:1910 */       switch (this.direction)
/* 1669:     */       {
/* 1670:     */       case 1: 
/* 1671:1912 */         g.fillRect(0, 4, 9, 1);
/* 1672:1913 */         g.fillRect(1, 3, 7, 1);
/* 1673:1914 */         g.fillRect(2, 2, 5, 1);
/* 1674:1915 */         g.fillRect(3, 1, 3, 1);
/* 1675:1916 */         g.fillRect(4, 0, 1, 1);
/* 1676:1917 */         if (paintShadow)
/* 1677:     */         {
/* 1678:1918 */           g.setColor(shadow);
/* 1679:1919 */           g.fillRect(1, 5, 9, 1);
/* 1680:     */         }
/* 1681:     */         break;
/* 1682:     */       case 5: 
/* 1683:1923 */         g.fillRect(0, 0, 9, 1);
/* 1684:1924 */         g.fillRect(1, 1, 7, 1);
/* 1685:1925 */         g.fillRect(2, 2, 5, 1);
/* 1686:1926 */         g.fillRect(3, 3, 3, 1);
/* 1687:1927 */         g.fillRect(4, 4, 1, 1);
/* 1688:1928 */         if (paintShadow)
/* 1689:     */         {
/* 1690:1929 */           g.setColor(shadow);
/* 1691:1930 */           g.drawLine(5, 4, 8, 1);
/* 1692:1931 */           g.drawLine(5, 5, 9, 1);
/* 1693:     */         }
/* 1694:     */         break;
/* 1695:     */       case 7: 
/* 1696:1935 */         g.fillRect(0, 4, 1, 1);
/* 1697:1936 */         g.fillRect(1, 3, 1, 3);
/* 1698:1937 */         g.fillRect(2, 2, 1, 5);
/* 1699:1938 */         g.fillRect(3, 1, 1, 7);
/* 1700:1939 */         g.fillRect(4, 0, 1, 9);
/* 1701:1940 */         if (paintShadow)
/* 1702:     */         {
/* 1703:1941 */           g.setColor(shadow);
/* 1704:1942 */           g.fillRect(5, 1, 1, 9);
/* 1705:     */         }
/* 1706:     */         break;
/* 1707:     */       case 3: 
/* 1708:1946 */         g.fillRect(0, 0, 1, 9);
/* 1709:1947 */         g.fillRect(1, 1, 1, 7);
/* 1710:1948 */         g.fillRect(2, 2, 1, 5);
/* 1711:1949 */         g.fillRect(3, 3, 1, 3);
/* 1712:1950 */         g.fillRect(4, 4, 1, 1);
/* 1713:1951 */         if (paintShadow)
/* 1714:     */         {
/* 1715:1952 */           g.setColor(shadow);
/* 1716:1953 */           g.drawLine(1, 8, 4, 5);
/* 1717:1954 */           g.drawLine(1, 9, 5, 5);
/* 1718:     */         }
/* 1719:     */         break;
/* 1720:     */       }
/* 1721:1959 */       g.translate(-x, -y);
/* 1722:1960 */       g.setColor(oldColor);
/* 1723:     */     }
/* 1724:     */     
/* 1725:     */     public Dimension getPreferredSize()
/* 1726:     */     {
/* 1727:1964 */       return new Dimension(this.buttonWidth, this.buttonWidth);
/* 1728:     */     }
/* 1729:     */     
/* 1730:     */     public Dimension getMinimumSize()
/* 1731:     */     {
/* 1732:1968 */       return getPreferredSize();
/* 1733:     */     }
/* 1734:     */     
/* 1735:     */     public Dimension getMaximumSize()
/* 1736:     */     {
/* 1737:1972 */       return new Dimension(2147483647, 2147483647);
/* 1738:     */     }
/* 1739:     */   }
/* 1740:     */   
/* 1741:     */   private static abstract class AbstractRenderer
/* 1742:     */   {
/* 1743:     */     AbstractRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 1744:     */     {
/* 1745:1980 */       this(x0);
/* 1746:     */     }
/* 1747:     */     
/* 1748:1982 */     protected static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
/* 1749:1983 */     protected static final Insets NORTH_INSETS = new Insets(1, 0, 0, 0);
/* 1750:1984 */     protected static final Insets WEST_INSETS = new Insets(0, 1, 0, 0);
/* 1751:1985 */     protected static final Insets SOUTH_INSETS = new Insets(0, 0, 1, 0);
/* 1752:1986 */     protected static final Insets EAST_INSETS = new Insets(0, 0, 0, 1);
/* 1753:     */     protected final JTabbedPane tabPane;
/* 1754:     */     protected final int tabPlacement;
/* 1755:     */     protected Color shadowColor;
/* 1756:     */     protected Color darkShadow;
/* 1757:     */     protected Color selectColor;
/* 1758:     */     protected Color selectLight;
/* 1759:     */     protected Color selectHighlight;
/* 1760:     */     protected Color lightHighlight;
/* 1761:     */     protected Color focus;
/* 1762:     */     
/* 1763:     */     private AbstractRenderer(JTabbedPane tabPane)
/* 1764:     */     {
/* 1765:1999 */       initColors();
/* 1766:2000 */       this.tabPane = tabPane;
/* 1767:2001 */       this.tabPlacement = tabPane.getTabPlacement();
/* 1768:     */     }
/* 1769:     */     
/* 1770:     */     private static AbstractRenderer createRenderer(JTabbedPane tabPane)
/* 1771:     */     {
/* 1772:2005 */       switch (tabPane.getTabPlacement())
/* 1773:     */       {
/* 1774:     */       case 1: 
/* 1775:2007 */         return new PlasticTabbedPaneUI.TopRenderer(tabPane, null);
/* 1776:     */       case 3: 
/* 1777:2009 */         return new PlasticTabbedPaneUI.BottomRenderer(tabPane, null);
/* 1778:     */       case 2: 
/* 1779:2011 */         return new PlasticTabbedPaneUI.LeftRenderer(tabPane, null);
/* 1780:     */       case 4: 
/* 1781:2013 */         return new PlasticTabbedPaneUI.RightRenderer(tabPane, null);
/* 1782:     */       }
/* 1783:2015 */       return new PlasticTabbedPaneUI.TopRenderer(tabPane, null);
/* 1784:     */     }
/* 1785:     */     
/* 1786:     */     private static AbstractRenderer createEmbeddedRenderer(JTabbedPane tabPane)
/* 1787:     */     {
/* 1788:2020 */       switch (tabPane.getTabPlacement())
/* 1789:     */       {
/* 1790:     */       case 1: 
/* 1791:2022 */         return new PlasticTabbedPaneUI.TopEmbeddedRenderer(tabPane, null);
/* 1792:     */       case 3: 
/* 1793:2024 */         return new PlasticTabbedPaneUI.BottomEmbeddedRenderer(tabPane, null);
/* 1794:     */       case 2: 
/* 1795:2026 */         return new PlasticTabbedPaneUI.LeftEmbeddedRenderer(tabPane, null);
/* 1796:     */       case 4: 
/* 1797:2028 */         return new PlasticTabbedPaneUI.RightEmbeddedRenderer(tabPane, null);
/* 1798:     */       }
/* 1799:2030 */       return new PlasticTabbedPaneUI.TopEmbeddedRenderer(tabPane, null);
/* 1800:     */     }
/* 1801:     */     
/* 1802:     */     private void initColors()
/* 1803:     */     {
/* 1804:2035 */       this.shadowColor = UIManager.getColor("TabbedPane.shadow");
/* 1805:2036 */       this.darkShadow = UIManager.getColor("TabbedPane.darkShadow");
/* 1806:2037 */       this.selectColor = UIManager.getColor("TabbedPane.selected");
/* 1807:2038 */       this.focus = UIManager.getColor("TabbedPane.focus");
/* 1808:2039 */       this.selectHighlight = UIManager.getColor("TabbedPane.selectHighlight");
/* 1809:2040 */       this.lightHighlight = UIManager.getColor("TabbedPane.highlight");
/* 1810:2041 */       this.selectLight = new Color((2 * this.selectColor.getRed() + this.selectHighlight.getRed()) / 3, (2 * this.selectColor.getGreen() + this.selectHighlight.getGreen()) / 3, (2 * this.selectColor.getBlue() + this.selectHighlight.getBlue()) / 3);
/* 1811:     */     }
/* 1812:     */     
/* 1813:     */     protected boolean isFirstDisplayedTab(int tabIndex, int position, int paneBorder)
/* 1814:     */     {
/* 1815:2049 */       return tabIndex == 0;
/* 1816:     */     }
/* 1817:     */     
/* 1818:     */     protected Insets getTabAreaInsets(Insets defaultInsets)
/* 1819:     */     {
/* 1820:2054 */       return defaultInsets;
/* 1821:     */     }
/* 1822:     */     
/* 1823:     */     protected Insets getContentBorderInsets(Insets defaultInsets)
/* 1824:     */     {
/* 1825:2058 */       return defaultInsets;
/* 1826:     */     }
/* 1827:     */     
/* 1828:     */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected)
/* 1829:     */     {
/* 1830:2065 */       return 0;
/* 1831:     */     }
/* 1832:     */     
/* 1833:     */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected)
/* 1834:     */     {
/* 1835:2072 */       return 0;
/* 1836:     */     }
/* 1837:     */     
/* 1838:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 1839:     */     {
/* 1840:2079 */       return tabRunOverlay;
/* 1841:     */     }
/* 1842:     */     
/* 1843:     */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/* 1844:     */     {
/* 1845:2087 */       return aPriori;
/* 1846:     */     }
/* 1847:     */     
/* 1848:     */     protected int getTabRunIndent(int run)
/* 1849:     */     {
/* 1850:2096 */       return 0;
/* 1851:     */     }
/* 1852:     */     
/* 1853:     */     protected Insets getSelectedTabPadInsets()
/* 1854:     */     {
/* 1855:2131 */       return EMPTY_INSETS;
/* 1856:     */     }
/* 1857:     */     
/* 1858:     */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 1859:     */     {
/* 1860:2148 */       if (isContentBorderPainted)
/* 1861:     */       {
/* 1862:2149 */         g.setColor(this.selectHighlight);
/* 1863:2150 */         g.fillRect(x, y, w - 1, 1);
/* 1864:     */       }
/* 1865:     */     }
/* 1866:     */     
/* 1867:     */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 1868:     */     {
/* 1869:2168 */       if (isContentBorderPainted)
/* 1870:     */       {
/* 1871:2169 */         g.setColor(this.darkShadow);
/* 1872:2170 */         g.fillRect(x, y + h - 1, w - 1, 1);
/* 1873:     */       }
/* 1874:     */     }
/* 1875:     */     
/* 1876:     */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 1877:     */     {
/* 1878:2188 */       if (isContentBorderPainted)
/* 1879:     */       {
/* 1880:2189 */         g.setColor(this.selectHighlight);
/* 1881:2190 */         g.fillRect(x, y, 1, h - 1);
/* 1882:     */       }
/* 1883:     */     }
/* 1884:     */     
/* 1885:     */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 1886:     */     {
/* 1887:2208 */       if (isContentBorderPainted)
/* 1888:     */       {
/* 1889:2209 */         g.setColor(this.darkShadow);
/* 1890:2210 */         g.fillRect(x + w - 1, y, 1, h);
/* 1891:     */       }
/* 1892:     */     }
/* 1893:     */     
/* 1894:     */     protected int getTabsOverlay()
/* 1895:     */     {
/* 1896:2218 */       return 0;
/* 1897:     */     }
/* 1898:     */     
/* 1899:     */     protected abstract Insets getTabInsets(int paramInt, Insets paramInsets);
/* 1900:     */     
/* 1901:     */     protected abstract void paintFocusIndicator(Graphics paramGraphics, Rectangle[] paramArrayOfRectangle, int paramInt, Rectangle paramRectangle1, Rectangle paramRectangle2, boolean paramBoolean);
/* 1902:     */     
/* 1903:     */     protected abstract void paintTabBackground(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean);
/* 1904:     */     
/* 1905:     */     protected abstract void paintTabBorder(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean);
/* 1906:     */   }
/* 1907:     */   
/* 1908:     */   private static final class BottomEmbeddedRenderer
/* 1909:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 1910:     */   {
/* 1911:     */     BottomEmbeddedRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 1912:     */     {
/* 1913:2226 */       this(x0);
/* 1914:     */     }
/* 1915:     */     
/* 1916:     */     private BottomEmbeddedRenderer(JTabbedPane tabPane)
/* 1917:     */     {
/* 1918:2229 */       super(null);
/* 1919:     */     }
/* 1920:     */     
/* 1921:     */     protected Insets getTabAreaInsets(Insets insets)
/* 1922:     */     {
/* 1923:2233 */       return EMPTY_INSETS;
/* 1924:     */     }
/* 1925:     */     
/* 1926:     */     protected Insets getContentBorderInsets(Insets defaultInsets)
/* 1927:     */     {
/* 1928:2237 */       return SOUTH_INSETS;
/* 1929:     */     }
/* 1930:     */     
/* 1931:     */     protected Insets getSelectedTabPadInsets()
/* 1932:     */     {
/* 1933:2241 */       return EMPTY_INSETS;
/* 1934:     */     }
/* 1935:     */     
/* 1936:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 1937:     */     {
/* 1938:2245 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, tabInsets.right);
/* 1939:     */     }
/* 1940:     */     
/* 1941:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 1942:     */     {
/* 1943:2263 */       g.setColor(this.selectColor);
/* 1944:2264 */       g.fillRect(x, y, w + 1, h);
/* 1945:     */     }
/* 1946:     */     
/* 1947:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 1948:     */     {
/* 1949:2269 */       int bottom = h;
/* 1950:2270 */       int right = w + 1;
/* 1951:     */       
/* 1952:2272 */       g.translate(x, y);
/* 1953:2273 */       if (isFirstDisplayedTab(tabIndex, x, this.tabPane.getBounds().x))
/* 1954:     */       {
/* 1955:2274 */         if (isSelected)
/* 1956:     */         {
/* 1957:2276 */           g.setColor(this.shadowColor);
/* 1958:2277 */           g.fillRect(right, 0, 1, bottom - 1);
/* 1959:2278 */           g.fillRect(right - 1, bottom - 1, 1, 1);
/* 1960:     */           
/* 1961:     */ 
/* 1962:     */ 
/* 1963:     */ 
/* 1964:     */ 
/* 1965:2284 */           g.setColor(this.selectHighlight);
/* 1966:2285 */           g.fillRect(0, 0, 1, bottom);
/* 1967:2286 */           g.fillRect(right - 1, 0, 1, bottom - 1);
/* 1968:2287 */           g.fillRect(1, bottom - 1, right - 2, 1);
/* 1969:     */         }
/* 1970:     */       }
/* 1971:2292 */       else if (isSelected)
/* 1972:     */       {
/* 1973:2294 */         g.setColor(this.shadowColor);
/* 1974:2295 */         g.fillRect(0, 0, 1, bottom - 1);
/* 1975:2296 */         g.fillRect(1, bottom - 1, 1, 1);
/* 1976:2297 */         g.fillRect(right, 0, 1, bottom - 1);
/* 1977:2298 */         g.fillRect(right - 1, bottom - 1, 1, 1);
/* 1978:     */         
/* 1979:     */ 
/* 1980:2301 */         g.setColor(this.selectHighlight);
/* 1981:2302 */         g.fillRect(1, 0, 1, bottom - 1);
/* 1982:2303 */         g.fillRect(right - 1, 0, 1, bottom - 1);
/* 1983:2304 */         g.fillRect(2, bottom - 1, right - 3, 1);
/* 1984:     */       }
/* 1985:     */       else
/* 1986:     */       {
/* 1987:2306 */         g.setColor(this.shadowColor);
/* 1988:2307 */         g.fillRect(1, h / 2, 1, h - h / 2);
/* 1989:     */       }
/* 1990:2310 */       g.translate(-x, -y);
/* 1991:     */     }
/* 1992:     */     
/* 1993:     */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 1994:     */     {
/* 1995:2323 */       g.setColor(this.shadowColor);
/* 1996:2324 */       g.fillRect(x, y + h - 1, w, 1);
/* 1997:     */     }
/* 1998:     */     
/* 1999:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}
/* 2000:     */   }
/* 2001:     */   
/* 2002:     */   private static final class BottomRenderer
/* 2003:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2004:     */   {
/* 2005:     */     BottomRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2006:     */     {
/* 2007:2333 */       this(x0);
/* 2008:     */     }
/* 2009:     */     
/* 2010:     */     private BottomRenderer(JTabbedPane tabPane)
/* 2011:     */     {
/* 2012:2336 */       super(null);
/* 2013:     */     }
/* 2014:     */     
/* 2015:     */     protected Insets getTabAreaInsets(Insets defaultInsets)
/* 2016:     */     {
/* 2017:2340 */       return new Insets(defaultInsets.top, defaultInsets.left + 5, defaultInsets.bottom, defaultInsets.right);
/* 2018:     */     }
/* 2019:     */     
/* 2020:     */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected)
/* 2021:     */     {
/* 2022:2344 */       return isSelected ? 0 : -1;
/* 2023:     */     }
/* 2024:     */     
/* 2025:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2026:     */     {
/* 2027:2348 */       return tabRunOverlay - 2;
/* 2028:     */     }
/* 2029:     */     
/* 2030:     */     protected int getTabRunIndent(int run)
/* 2031:     */     {
/* 2032:2352 */       return 6 * run;
/* 2033:     */     }
/* 2034:     */     
/* 2035:     */     protected Insets getSelectedTabPadInsets()
/* 2036:     */     {
/* 2037:2356 */       return SOUTH_INSETS;
/* 2038:     */     }
/* 2039:     */     
/* 2040:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2041:     */     {
/* 2042:2360 */       return new Insets(tabInsets.top, tabInsets.left - 2, tabInsets.bottom, tabInsets.right - 2);
/* 2043:     */     }
/* 2044:     */     
/* 2045:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 2046:     */     {
/* 2047:2371 */       if ((!this.tabPane.hasFocus()) || (!isSelected)) {
/* 2048:2372 */         return;
/* 2049:     */       }
/* 2050:2373 */       Rectangle tabRect = rects[tabIndex];
/* 2051:2374 */       int top = tabRect.y;
/* 2052:2375 */       int left = tabRect.x + 6;
/* 2053:2376 */       int height = tabRect.height - 3;
/* 2054:2377 */       int width = tabRect.width - 12;
/* 2055:2378 */       g.setColor(this.focus);
/* 2056:2379 */       g.drawRect(left, top, width, height);
/* 2057:     */     }
/* 2058:     */     
/* 2059:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2060:     */     {
/* 2061:2384 */       g.setColor(this.selectColor);
/* 2062:2385 */       g.fillRect(x, y, w, h);
/* 2063:     */     }
/* 2064:     */     
/* 2065:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2066:     */     {
/* 2067:2390 */       int bottom = h - 1;
/* 2068:2391 */       int right = w + 4;
/* 2069:     */       
/* 2070:2393 */       g.translate(x - 3, y);
/* 2071:     */       
/* 2072:     */ 
/* 2073:2396 */       g.setColor(this.selectHighlight);
/* 2074:     */       
/* 2075:     */ 
/* 2076:2399 */       g.fillRect(0, 0, 1, 2);
/* 2077:2400 */       g.drawLine(0, 2, 4, bottom - 4);
/* 2078:2401 */       g.fillRect(5, bottom - 3, 1, 2);
/* 2079:2402 */       g.fillRect(6, bottom - 1, 1, 1);
/* 2080:     */       
/* 2081:     */ 
/* 2082:2405 */       g.fillRect(7, bottom, 1, 1);
/* 2083:2406 */       g.setColor(this.darkShadow);
/* 2084:2407 */       g.fillRect(8, bottom, right - 13, 1);
/* 2085:     */       
/* 2086:     */ 
/* 2087:2410 */       g.drawLine(right + 1, 0, right - 3, bottom - 4);
/* 2088:2411 */       g.fillRect(right - 4, bottom - 3, 1, 2);
/* 2089:2412 */       g.fillRect(right - 5, bottom - 1, 1, 1);
/* 2090:     */       
/* 2091:2414 */       g.translate(-x + 3, -y);
/* 2092:     */     }
/* 2093:     */     
/* 2094:     */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2095:     */     {
/* 2096:2426 */       int bottom = y + h - 1;
/* 2097:2427 */       int right = x + w - 1;
/* 2098:2428 */       g.translate(x, bottom);
/* 2099:2429 */       if ((drawBroken) && (selRect.x >= x) && (selRect.x <= x + w))
/* 2100:     */       {
/* 2101:2431 */         g.setColor(this.darkShadow);
/* 2102:2432 */         g.fillRect(0, 0, selRect.x - x - 2, 1);
/* 2103:2433 */         if (selRect.x + selRect.width < x + w - 2)
/* 2104:     */         {
/* 2105:2434 */           g.setColor(this.darkShadow);
/* 2106:2435 */           g.fillRect(selRect.x + selRect.width + 2 - x, 0, right - selRect.x - selRect.width - 2, 1);
/* 2107:     */         }
/* 2108:     */       }
/* 2109:     */       else
/* 2110:     */       {
/* 2111:2438 */         g.setColor(this.darkShadow);
/* 2112:2439 */         g.fillRect(0, 0, w - 1, 1);
/* 2113:     */       }
/* 2114:2441 */       g.translate(-x, -bottom);
/* 2115:     */     }
/* 2116:     */     
/* 2117:     */     protected int getTabsOverlay()
/* 2118:     */     {
/* 2119:2445 */       return 4;
/* 2120:     */     }
/* 2121:     */   }
/* 2122:     */   
/* 2123:     */   private static final class LeftEmbeddedRenderer
/* 2124:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2125:     */   {
/* 2126:     */     LeftEmbeddedRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2127:     */     {
/* 2128:2453 */       this(x0);
/* 2129:     */     }
/* 2130:     */     
/* 2131:     */     private LeftEmbeddedRenderer(JTabbedPane tabPane)
/* 2132:     */     {
/* 2133:2456 */       super(null);
/* 2134:     */     }
/* 2135:     */     
/* 2136:     */     protected Insets getTabAreaInsets(Insets insets)
/* 2137:     */     {
/* 2138:2460 */       return EMPTY_INSETS;
/* 2139:     */     }
/* 2140:     */     
/* 2141:     */     protected Insets getContentBorderInsets(Insets defaultInsets)
/* 2142:     */     {
/* 2143:2464 */       return WEST_INSETS;
/* 2144:     */     }
/* 2145:     */     
/* 2146:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2147:     */     {
/* 2148:2468 */       return 0;
/* 2149:     */     }
/* 2150:     */     
/* 2151:     */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/* 2152:     */     {
/* 2153:2472 */       return false;
/* 2154:     */     }
/* 2155:     */     
/* 2156:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2157:     */     {
/* 2158:2476 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, tabInsets.right);
/* 2159:     */     }
/* 2160:     */     
/* 2161:     */     protected Insets getSelectedTabPadInsets()
/* 2162:     */     {
/* 2163:2480 */       return EMPTY_INSETS;
/* 2164:     */     }
/* 2165:     */     
/* 2166:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2167:     */     {
/* 2168:2497 */       g.setColor(this.selectColor);
/* 2169:2498 */       g.fillRect(x, y, w, h);
/* 2170:     */     }
/* 2171:     */     
/* 2172:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2173:     */     {
/* 2174:2503 */       int bottom = h;
/* 2175:2504 */       int right = w;
/* 2176:     */       
/* 2177:2506 */       g.translate(x, y);
/* 2178:2508 */       if (isFirstDisplayedTab(tabIndex, y, this.tabPane.getBounds().y))
/* 2179:     */       {
/* 2180:2509 */         if (isSelected)
/* 2181:     */         {
/* 2182:2511 */           g.setColor(this.selectHighlight);
/* 2183:2512 */           g.fillRect(0, 0, right, 1);
/* 2184:2513 */           g.fillRect(0, 0, 1, bottom - 1);
/* 2185:2514 */           g.fillRect(1, bottom - 1, right - 1, 1);
/* 2186:2515 */           g.setColor(this.shadowColor);
/* 2187:2516 */           g.fillRect(0, bottom - 1, 1, 1);
/* 2188:2517 */           g.fillRect(1, bottom, right - 1, 1);
/* 2189:     */         }
/* 2190:     */       }
/* 2191:2524 */       else if (isSelected)
/* 2192:     */       {
/* 2193:2526 */         g.setColor(this.selectHighlight);
/* 2194:2527 */         g.fillRect(1, 1, right - 1, 1);
/* 2195:2528 */         g.fillRect(0, 2, 1, bottom - 2);
/* 2196:2529 */         g.fillRect(1, bottom - 1, right - 1, 1);
/* 2197:2530 */         g.setColor(this.shadowColor);
/* 2198:2531 */         g.fillRect(1, 0, right - 1, 1);
/* 2199:2532 */         g.fillRect(0, 1, 1, 1);
/* 2200:2533 */         g.fillRect(0, bottom - 1, 1, 1);
/* 2201:2534 */         g.fillRect(1, bottom, right - 1, 1);
/* 2202:     */       }
/* 2203:     */       else
/* 2204:     */       {
/* 2205:2538 */         g.setColor(this.shadowColor);
/* 2206:2539 */         g.fillRect(0, 0, right / 3, 1);
/* 2207:     */       }
/* 2208:2543 */       g.translate(-x, -y);
/* 2209:     */     }
/* 2210:     */     
/* 2211:     */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2212:     */     {
/* 2213:2555 */       g.setColor(this.shadowColor);
/* 2214:2556 */       g.fillRect(x, y, 1, h);
/* 2215:     */     }
/* 2216:     */     
/* 2217:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}
/* 2218:     */   }
/* 2219:     */   
/* 2220:     */   private static final class LeftRenderer
/* 2221:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2222:     */   {
/* 2223:     */     LeftRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2224:     */     {
/* 2225:2563 */       this(x0);
/* 2226:     */     }
/* 2227:     */     
/* 2228:     */     private LeftRenderer(JTabbedPane tabPane)
/* 2229:     */     {
/* 2230:2566 */       super(null);
/* 2231:     */     }
/* 2232:     */     
/* 2233:     */     protected Insets getTabAreaInsets(Insets defaultInsets)
/* 2234:     */     {
/* 2235:2570 */       return new Insets(defaultInsets.top + 4, defaultInsets.left, defaultInsets.bottom, defaultInsets.right);
/* 2236:     */     }
/* 2237:     */     
/* 2238:     */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected)
/* 2239:     */     {
/* 2240:2574 */       return 1;
/* 2241:     */     }
/* 2242:     */     
/* 2243:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2244:     */     {
/* 2245:2578 */       return 1;
/* 2246:     */     }
/* 2247:     */     
/* 2248:     */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/* 2249:     */     {
/* 2250:2582 */       return false;
/* 2251:     */     }
/* 2252:     */     
/* 2253:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2254:     */     {
/* 2255:2586 */       return new Insets(tabInsets.top, tabInsets.left - 5, tabInsets.bottom + 1, tabInsets.right - 5);
/* 2256:     */     }
/* 2257:     */     
/* 2258:     */     protected Insets getSelectedTabPadInsets()
/* 2259:     */     {
/* 2260:2590 */       return WEST_INSETS;
/* 2261:     */     }
/* 2262:     */     
/* 2263:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 2264:     */     {
/* 2265:2601 */       if ((!this.tabPane.hasFocus()) || (!isSelected)) {
/* 2266:2602 */         return;
/* 2267:     */       }
/* 2268:2603 */       Rectangle tabRect = rects[tabIndex];
/* 2269:2604 */       int top = tabRect.y + 2;
/* 2270:2605 */       int left = tabRect.x + 3;
/* 2271:2606 */       int height = tabRect.height - 5;
/* 2272:2607 */       int width = tabRect.width - 6;
/* 2273:2608 */       g.setColor(this.focus);
/* 2274:2609 */       g.drawRect(left, top, width, height);
/* 2275:     */     }
/* 2276:     */     
/* 2277:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2278:     */     {
/* 2279:2613 */       if (!isSelected)
/* 2280:     */       {
/* 2281:2614 */         g.setColor(this.selectLight);
/* 2282:2615 */         g.fillRect(x + 1, y + 1, w - 1, h - 2);
/* 2283:     */       }
/* 2284:     */       else
/* 2285:     */       {
/* 2286:2617 */         g.setColor(this.selectColor);
/* 2287:2618 */         g.fillRect(x + 1, y + 1, w - 3, h - 2);
/* 2288:     */       }
/* 2289:     */     }
/* 2290:     */     
/* 2291:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2292:     */     {
/* 2293:2624 */       int bottom = h - 1;
/* 2294:2625 */       int left = 0;
/* 2295:2626 */       g.translate(x, y);
/* 2296:     */       
/* 2297:     */ 
/* 2298:2629 */       g.setColor(this.selectHighlight);
/* 2299:     */       
/* 2300:2631 */       g.fillRect(left + 2, 0, w - 2 - left, 1);
/* 2301:     */       
/* 2302:     */ 
/* 2303:2634 */       g.fillRect(left + 1, 1, 1, 1);
/* 2304:2635 */       g.fillRect(left, 2, 1, bottom - 3);
/* 2305:2636 */       g.setColor(this.darkShadow);
/* 2306:2637 */       g.fillRect(left + 1, bottom - 1, 1, 1);
/* 2307:     */       
/* 2308:     */ 
/* 2309:2640 */       g.fillRect(left + 2, bottom, w - 2 - left, 1);
/* 2310:     */       
/* 2311:2642 */       g.translate(-x, -y);
/* 2312:     */     }
/* 2313:     */     
/* 2314:     */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2315:     */     {
/* 2316:2654 */       g.setColor(this.selectHighlight);
/* 2317:2655 */       if ((drawBroken) && (selRect.y >= y) && (selRect.y <= y + h))
/* 2318:     */       {
/* 2319:2657 */         g.fillRect(x, y, 1, selRect.y + 1 - y);
/* 2320:2658 */         if (selRect.y + selRect.height < y + h - 2) {
/* 2321:2659 */           g.fillRect(x, selRect.y + selRect.height - 1, 1, y + h - selRect.y - selRect.height);
/* 2322:     */         }
/* 2323:     */       }
/* 2324:     */       else
/* 2325:     */       {
/* 2326:2662 */         g.fillRect(x, y, 1, h - 1);
/* 2327:     */       }
/* 2328:     */     }
/* 2329:     */   }
/* 2330:     */   
/* 2331:     */   private static final class RightEmbeddedRenderer
/* 2332:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2333:     */   {
/* 2334:     */     RightEmbeddedRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2335:     */     {
/* 2336:2671 */       this(x0);
/* 2337:     */     }
/* 2338:     */     
/* 2339:     */     private RightEmbeddedRenderer(JTabbedPane tabPane)
/* 2340:     */     {
/* 2341:2674 */       super(null);
/* 2342:     */     }
/* 2343:     */     
/* 2344:     */     protected Insets getTabAreaInsets(Insets insets)
/* 2345:     */     {
/* 2346:2678 */       return EMPTY_INSETS;
/* 2347:     */     }
/* 2348:     */     
/* 2349:     */     protected Insets getContentBorderInsets(Insets defaultInsets)
/* 2350:     */     {
/* 2351:2682 */       return EAST_INSETS;
/* 2352:     */     }
/* 2353:     */     
/* 2354:     */     protected int getTabRunIndent(int run)
/* 2355:     */     {
/* 2356:2686 */       return 4 * run;
/* 2357:     */     }
/* 2358:     */     
/* 2359:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2360:     */     {
/* 2361:2690 */       return 0;
/* 2362:     */     }
/* 2363:     */     
/* 2364:     */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/* 2365:     */     {
/* 2366:2694 */       return false;
/* 2367:     */     }
/* 2368:     */     
/* 2369:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2370:     */     {
/* 2371:2698 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, tabInsets.right);
/* 2372:     */     }
/* 2373:     */     
/* 2374:     */     protected Insets getSelectedTabPadInsets()
/* 2375:     */     {
/* 2376:2702 */       return EMPTY_INSETS;
/* 2377:     */     }
/* 2378:     */     
/* 2379:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2380:     */     {
/* 2381:2720 */       g.setColor(this.selectColor);
/* 2382:2721 */       g.fillRect(x, y, w, h);
/* 2383:     */     }
/* 2384:     */     
/* 2385:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2386:     */     {
/* 2387:2726 */       int bottom = h;
/* 2388:2727 */       int right = w - 1;
/* 2389:     */       
/* 2390:2729 */       g.translate(x + 1, y);
/* 2391:2731 */       if (isFirstDisplayedTab(tabIndex, y, this.tabPane.getBounds().y))
/* 2392:     */       {
/* 2393:2732 */         if (isSelected)
/* 2394:     */         {
/* 2395:2734 */           g.setColor(this.shadowColor);
/* 2396:     */           
/* 2397:     */ 
/* 2398:     */ 
/* 2399:2738 */           g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2400:2739 */           g.fillRect(0, bottom, right - 1, 1);
/* 2401:2740 */           g.setColor(this.selectHighlight);
/* 2402:2741 */           g.fillRect(0, 0, right - 1, 1);
/* 2403:2742 */           g.fillRect(right - 1, 0, 1, bottom - 1);
/* 2404:2743 */           g.fillRect(0, bottom - 1, right - 1, 1);
/* 2405:     */         }
/* 2406:     */       }
/* 2407:2746 */       else if (isSelected)
/* 2408:     */       {
/* 2409:2748 */         g.setColor(this.shadowColor);
/* 2410:2749 */         g.fillRect(0, -1, right - 1, 1);
/* 2411:2750 */         g.fillRect(right - 1, 0, 1, 1);
/* 2412:     */         
/* 2413:     */ 
/* 2414:2753 */         g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2415:2754 */         g.fillRect(0, bottom, right - 1, 1);
/* 2416:2755 */         g.setColor(this.selectHighlight);
/* 2417:2756 */         g.fillRect(0, 0, right - 1, 1);
/* 2418:2757 */         g.fillRect(right - 1, 1, 1, bottom - 2);
/* 2419:2758 */         g.fillRect(0, bottom - 1, right - 1, 1);
/* 2420:     */       }
/* 2421:     */       else
/* 2422:     */       {
/* 2423:2761 */         g.setColor(this.shadowColor);
/* 2424:2762 */         g.fillRect(2 * right / 3, 0, right / 3, 1);
/* 2425:     */       }
/* 2426:2765 */       g.translate(-x - 1, -y);
/* 2427:     */     }
/* 2428:     */     
/* 2429:     */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2430:     */     {
/* 2431:2777 */       g.setColor(this.shadowColor);
/* 2432:2778 */       g.fillRect(x + w - 1, y, 1, h);
/* 2433:     */     }
/* 2434:     */     
/* 2435:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}
/* 2436:     */   }
/* 2437:     */   
/* 2438:     */   private static final class RightRenderer
/* 2439:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2440:     */   {
/* 2441:     */     RightRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2442:     */     {
/* 2443:2786 */       this(x0);
/* 2444:     */     }
/* 2445:     */     
/* 2446:     */     private RightRenderer(JTabbedPane tabPane)
/* 2447:     */     {
/* 2448:2789 */       super(null);
/* 2449:     */     }
/* 2450:     */     
/* 2451:     */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected)
/* 2452:     */     {
/* 2453:2793 */       return 1;
/* 2454:     */     }
/* 2455:     */     
/* 2456:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2457:     */     {
/* 2458:2797 */       return 1;
/* 2459:     */     }
/* 2460:     */     
/* 2461:     */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/* 2462:     */     {
/* 2463:2801 */       return false;
/* 2464:     */     }
/* 2465:     */     
/* 2466:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2467:     */     {
/* 2468:2805 */       return new Insets(tabInsets.top, tabInsets.left - 5, tabInsets.bottom + 1, tabInsets.right - 5);
/* 2469:     */     }
/* 2470:     */     
/* 2471:     */     protected Insets getSelectedTabPadInsets()
/* 2472:     */     {
/* 2473:2809 */       return EAST_INSETS;
/* 2474:     */     }
/* 2475:     */     
/* 2476:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 2477:     */     {
/* 2478:2820 */       if ((!this.tabPane.hasFocus()) || (!isSelected)) {
/* 2479:2821 */         return;
/* 2480:     */       }
/* 2481:2822 */       Rectangle tabRect = rects[tabIndex];
/* 2482:2823 */       int top = tabRect.y + 2;
/* 2483:2824 */       int left = tabRect.x + 3;
/* 2484:2825 */       int height = tabRect.height - 5;
/* 2485:2826 */       int width = tabRect.width - 6;
/* 2486:2827 */       g.setColor(this.focus);
/* 2487:2828 */       g.drawRect(left, top, width, height);
/* 2488:     */     }
/* 2489:     */     
/* 2490:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2491:     */     {
/* 2492:2832 */       if (!isSelected)
/* 2493:     */       {
/* 2494:2833 */         g.setColor(this.selectLight);
/* 2495:2834 */         g.fillRect(x, y, w, h);
/* 2496:     */       }
/* 2497:     */       else
/* 2498:     */       {
/* 2499:2836 */         g.setColor(this.selectColor);
/* 2500:2837 */         g.fillRect(x + 2, y, w - 2, h);
/* 2501:     */       }
/* 2502:     */     }
/* 2503:     */     
/* 2504:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2505:     */     {
/* 2506:2843 */       int bottom = h - 1;
/* 2507:2844 */       int right = w;
/* 2508:     */       
/* 2509:2846 */       g.translate(x, y);
/* 2510:     */       
/* 2511:     */ 
/* 2512:     */ 
/* 2513:2850 */       g.setColor(this.selectHighlight);
/* 2514:2851 */       g.fillRect(0, 0, right - 1, 1);
/* 2515:     */       
/* 2516:2853 */       g.setColor(this.darkShadow);
/* 2517:2854 */       g.fillRect(right - 1, 1, 1, 1);
/* 2518:2855 */       g.fillRect(right, 2, 1, bottom - 3);
/* 2519:     */       
/* 2520:2857 */       g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2521:2858 */       g.fillRect(0, bottom, right - 1, 1);
/* 2522:     */       
/* 2523:2860 */       g.translate(-x, -y);
/* 2524:     */     }
/* 2525:     */     
/* 2526:     */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2527:     */     {
/* 2528:2872 */       g.setColor(this.darkShadow);
/* 2529:2873 */       if ((drawBroken) && (selRect.y >= y) && (selRect.y <= y + h))
/* 2530:     */       {
/* 2531:2875 */         g.fillRect(x + w - 1, y, 1, selRect.y - y);
/* 2532:2876 */         if (selRect.y + selRect.height < y + h - 2) {
/* 2533:2877 */           g.fillRect(x + w - 1, selRect.y + selRect.height, 1, y + h - selRect.y - selRect.height);
/* 2534:     */         }
/* 2535:     */       }
/* 2536:     */       else
/* 2537:     */       {
/* 2538:2880 */         g.fillRect(x + w - 1, y, 1, h - 1);
/* 2539:     */       }
/* 2540:     */     }
/* 2541:     */   }
/* 2542:     */   
/* 2543:     */   private static final class TopEmbeddedRenderer
/* 2544:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2545:     */   {
/* 2546:     */     TopEmbeddedRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2547:     */     {
/* 2548:2888 */       this(x0);
/* 2549:     */     }
/* 2550:     */     
/* 2551:     */     private TopEmbeddedRenderer(JTabbedPane tabPane)
/* 2552:     */     {
/* 2553:2891 */       super(null);
/* 2554:     */     }
/* 2555:     */     
/* 2556:     */     protected Insets getTabAreaInsets(Insets insets)
/* 2557:     */     {
/* 2558:2895 */       return EMPTY_INSETS;
/* 2559:     */     }
/* 2560:     */     
/* 2561:     */     protected Insets getContentBorderInsets(Insets defaultInsets)
/* 2562:     */     {
/* 2563:2899 */       return NORTH_INSETS;
/* 2564:     */     }
/* 2565:     */     
/* 2566:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2567:     */     {
/* 2568:2903 */       return new Insets(tabInsets.top, tabInsets.left + 1, tabInsets.bottom, tabInsets.right);
/* 2569:     */     }
/* 2570:     */     
/* 2571:     */     protected Insets getSelectedTabPadInsets()
/* 2572:     */     {
/* 2573:2907 */       return EMPTY_INSETS;
/* 2574:     */     }
/* 2575:     */     
/* 2576:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2577:     */     {
/* 2578:2925 */       g.setColor(this.selectColor);
/* 2579:2926 */       g.fillRect(x, y, w, h);
/* 2580:     */     }
/* 2581:     */     
/* 2582:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2583:     */     {
/* 2584:2931 */       g.translate(x, y);
/* 2585:     */       
/* 2586:2933 */       int right = w;
/* 2587:2934 */       int bottom = h;
/* 2588:2936 */       if (isFirstDisplayedTab(tabIndex, x, this.tabPane.getBounds().x))
/* 2589:     */       {
/* 2590:2937 */         if (isSelected)
/* 2591:     */         {
/* 2592:2938 */           g.setColor(this.selectHighlight);
/* 2593:     */           
/* 2594:2940 */           g.fillRect(0, 0, 1, bottom);
/* 2595:     */           
/* 2596:2942 */           g.fillRect(0, 0, right - 1, 1);
/* 2597:     */           
/* 2598:2944 */           g.fillRect(right - 1, 0, 1, bottom);
/* 2599:2945 */           g.setColor(this.shadowColor);
/* 2600:     */           
/* 2601:2947 */           g.fillRect(right - 1, 0, 1, 1);
/* 2602:     */           
/* 2603:2949 */           g.fillRect(right, 1, 1, bottom);
/* 2604:     */         }
/* 2605:     */       }
/* 2606:2952 */       else if (isSelected)
/* 2607:     */       {
/* 2608:2953 */         g.setColor(this.selectHighlight);
/* 2609:     */         
/* 2610:2955 */         g.fillRect(1, 1, 1, bottom - 1);
/* 2611:     */         
/* 2612:2957 */         g.fillRect(2, 0, right - 3, 1);
/* 2613:     */         
/* 2614:2959 */         g.fillRect(right - 1, 1, 1, bottom - 1);
/* 2615:2960 */         g.setColor(this.shadowColor);
/* 2616:     */         
/* 2617:2962 */         g.fillRect(0, 1, 1, bottom - 1);
/* 2618:     */         
/* 2619:2964 */         g.fillRect(1, 0, 1, 1);
/* 2620:     */         
/* 2621:2966 */         g.fillRect(right - 1, 0, 1, 1);
/* 2622:     */         
/* 2623:2968 */         g.fillRect(right, 1, 1, bottom);
/* 2624:     */       }
/* 2625:     */       else
/* 2626:     */       {
/* 2627:2970 */         g.setColor(this.shadowColor);
/* 2628:2971 */         g.fillRect(0, 0, 1, bottom + 2 - bottom / 2);
/* 2629:     */       }
/* 2630:2974 */       g.translate(-x, -y);
/* 2631:     */     }
/* 2632:     */     
/* 2633:     */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2634:     */     {
/* 2635:2986 */       g.setColor(this.shadowColor);
/* 2636:2987 */       g.fillRect(x, y, w, 1);
/* 2637:     */     }
/* 2638:     */     
/* 2639:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}
/* 2640:     */   }
/* 2641:     */   
/* 2642:     */   private static final class TopRenderer
/* 2643:     */     extends PlasticTabbedPaneUI.AbstractRenderer
/* 2644:     */   {
/* 2645:     */     TopRenderer(JTabbedPane x0, PlasticTabbedPaneUI.1 x1)
/* 2646:     */     {
/* 2647:2995 */       this(x0);
/* 2648:     */     }
/* 2649:     */     
/* 2650:     */     private TopRenderer(JTabbedPane tabPane)
/* 2651:     */     {
/* 2652:2998 */       super(null);
/* 2653:     */     }
/* 2654:     */     
/* 2655:     */     protected Insets getTabAreaInsets(Insets defaultInsets)
/* 2656:     */     {
/* 2657:3002 */       return new Insets(defaultInsets.top, defaultInsets.left + 4, defaultInsets.bottom, defaultInsets.right);
/* 2658:     */     }
/* 2659:     */     
/* 2660:     */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected)
/* 2661:     */     {
/* 2662:3006 */       return isSelected ? -1 : 0;
/* 2663:     */     }
/* 2664:     */     
/* 2665:     */     protected int getTabRunOverlay(int tabRunOverlay)
/* 2666:     */     {
/* 2667:3010 */       return tabRunOverlay - 2;
/* 2668:     */     }
/* 2669:     */     
/* 2670:     */     protected int getTabRunIndent(int run)
/* 2671:     */     {
/* 2672:3014 */       return 6 * run;
/* 2673:     */     }
/* 2674:     */     
/* 2675:     */     protected Insets getSelectedTabPadInsets()
/* 2676:     */     {
/* 2677:3018 */       return NORTH_INSETS;
/* 2678:     */     }
/* 2679:     */     
/* 2680:     */     protected Insets getTabInsets(int tabIndex, Insets tabInsets)
/* 2681:     */     {
/* 2682:3022 */       return new Insets(tabInsets.top - 1, tabInsets.left - 4, tabInsets.bottom, tabInsets.right - 4);
/* 2683:     */     }
/* 2684:     */     
/* 2685:     */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 2686:     */     {
/* 2687:3033 */       if ((!this.tabPane.hasFocus()) || (!isSelected)) {
/* 2688:3034 */         return;
/* 2689:     */       }
/* 2690:3035 */       Rectangle tabRect = rects[tabIndex];
/* 2691:3036 */       int top = tabRect.y + 1;
/* 2692:3037 */       int left = tabRect.x + 4;
/* 2693:3038 */       int height = tabRect.height - 3;
/* 2694:3039 */       int width = tabRect.width - 9;
/* 2695:3040 */       g.setColor(this.focus);
/* 2696:3041 */       g.drawRect(left, top, width, height);
/* 2697:     */     }
/* 2698:     */     
/* 2699:     */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2700:     */     {
/* 2701:3046 */       int sel = isSelected ? 0 : 1;
/* 2702:3047 */       g.setColor(this.selectColor);
/* 2703:3048 */       g.fillRect(x, y + sel, w, h / 2);
/* 2704:3049 */       g.fillRect(x - 1, y + sel + h / 2, w + 2, h - h / 2);
/* 2705:     */     }
/* 2706:     */     
/* 2707:     */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 2708:     */     {
/* 2709:3054 */       g.translate(x - 4, y);
/* 2710:     */       
/* 2711:3056 */       int top = 0;
/* 2712:3057 */       int right = w + 6;
/* 2713:     */       
/* 2714:     */ 
/* 2715:3060 */       g.setColor(this.selectHighlight);
/* 2716:     */       
/* 2717:     */ 
/* 2718:3063 */       g.drawLine(1, h - 1, 4, top + 4);
/* 2719:3064 */       g.fillRect(5, top + 2, 1, 2);
/* 2720:3065 */       g.fillRect(6, top + 1, 1, 1);
/* 2721:     */       
/* 2722:     */ 
/* 2723:3068 */       g.fillRect(7, top, right - 12, 1);
/* 2724:     */       
/* 2725:     */ 
/* 2726:3071 */       g.setColor(this.darkShadow);
/* 2727:3072 */       g.drawLine(right, h - 1, right - 3, top + 4);
/* 2728:3073 */       g.fillRect(right - 4, top + 2, 1, 2);
/* 2729:3074 */       g.fillRect(right - 5, top + 1, 1, 1);
/* 2730:     */       
/* 2731:3076 */       g.translate(-x + 4, -y);
/* 2732:     */     }
/* 2733:     */     
/* 2734:     */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/* 2735:     */     {
/* 2736:3088 */       int right = x + w - 1;
/* 2737:3089 */       int top = y;
/* 2738:3090 */       g.setColor(this.selectHighlight);
/* 2739:3092 */       if ((drawBroken) && (selRect.x >= x) && (selRect.x <= x + w))
/* 2740:     */       {
/* 2741:3094 */         g.fillRect(x, top, selRect.x - 2 - x, 1);
/* 2742:3095 */         if (selRect.x + selRect.width < x + w - 2) {
/* 2743:3096 */           g.fillRect(selRect.x + selRect.width + 2, top, right - 2 - selRect.x - selRect.width, 1);
/* 2744:     */         } else {
/* 2745:3098 */           g.fillRect(x + w - 2, top, 1, 1);
/* 2746:     */         }
/* 2747:     */       }
/* 2748:     */       else
/* 2749:     */       {
/* 2750:3101 */         g.fillRect(x, top, w - 1, 1);
/* 2751:     */       }
/* 2752:     */     }
/* 2753:     */     
/* 2754:     */     protected int getTabsOverlay()
/* 2755:     */     {
/* 2756:3106 */       return 6;
/* 2757:     */     }
/* 2758:     */   }
/* 2759:     */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticTabbedPaneUI
 * JD-Core Version:    0.7.0.1
 */
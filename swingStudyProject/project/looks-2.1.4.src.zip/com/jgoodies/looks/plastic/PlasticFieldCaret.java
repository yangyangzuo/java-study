/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.EventQueue;
/*   4:    */ import java.awt.event.FocusEvent;
/*   5:    */ import java.awt.event.MouseEvent;
/*   6:    */ import javax.swing.JFormattedTextField;
/*   7:    */ import javax.swing.SwingUtilities;
/*   8:    */ import javax.swing.plaf.UIResource;
/*   9:    */ import javax.swing.text.DefaultCaret;
/*  10:    */ import javax.swing.text.Document;
/*  11:    */ import javax.swing.text.JTextComponent;
/*  12:    */ 
/*  13:    */ final class PlasticFieldCaret
/*  14:    */   extends DefaultCaret
/*  15:    */   implements UIResource
/*  16:    */ {
/*  17: 58 */   private boolean isKeyboardFocusEvent = true;
/*  18:    */   
/*  19:    */   public void focusGained(FocusEvent e)
/*  20:    */   {
/*  21: 62 */     if (getComponent().isEnabled())
/*  22:    */     {
/*  23: 63 */       setVisible(true);
/*  24: 64 */       setSelectionVisible(true);
/*  25:    */     }
/*  26: 67 */     final JTextComponent c = getComponent();
/*  27: 68 */     if ((c.isEnabled()) && (this.isKeyboardFocusEvent)) {
/*  28: 69 */       if ((c instanceof JFormattedTextField))
/*  29:    */       {
/*  30: 70 */         EventQueue.invokeLater(new Runnable()
/*  31:    */         {
/*  32:    */           private final JTextComponent val$c;
/*  33:    */           
/*  34:    */           public void run()
/*  35:    */           {
/*  36: 72 */             PlasticFieldCaret.this.setDot(0);
/*  37: 73 */             PlasticFieldCaret.this.moveDot(c.getDocument().getLength());
/*  38:    */           }
/*  39:    */         });
/*  40:    */       }
/*  41:    */       else
/*  42:    */       {
/*  43: 77 */         super.setDot(0);
/*  44: 78 */         super.moveDot(c.getDocument().getLength());
/*  45:    */       }
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void focusLost(FocusEvent e)
/*  50:    */   {
/*  51: 85 */     super.focusLost(e);
/*  52: 86 */     if (!e.isTemporary()) {
/*  53: 87 */       this.isKeyboardFocusEvent = true;
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void mousePressed(MouseEvent e)
/*  58:    */   {
/*  59: 93 */     if ((SwingUtilities.isLeftMouseButton(e)) || (e.isPopupTrigger())) {
/*  60: 94 */       this.isKeyboardFocusEvent = false;
/*  61:    */     }
/*  62: 96 */     super.mousePressed(e);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void mouseReleased(MouseEvent e)
/*  66:    */   {
/*  67:102 */     super.mouseReleased(e);
/*  68:103 */     if (e.isPopupTrigger())
/*  69:    */     {
/*  70:104 */       this.isKeyboardFocusEvent = false;
/*  71:105 */       if ((getComponent() != null) && (getComponent().isEnabled()) && (getComponent().isRequestFocusEnabled())) {
/*  72:107 */         getComponent().requestFocus();
/*  73:    */       }
/*  74:    */     }
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticFieldCaret
 * JD-Core Version:    0.7.0.1
 */
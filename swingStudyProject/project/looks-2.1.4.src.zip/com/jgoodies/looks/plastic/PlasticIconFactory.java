/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import javax.swing.ButtonModel;
/*   8:    */ import javax.swing.Icon;
/*   9:    */ import javax.swing.JCheckBox;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JMenuItem;
/*  12:    */ import javax.swing.plaf.UIResource;
/*  13:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  14:    */ 
/*  15:    */ final class PlasticIconFactory
/*  16:    */ {
/*  17:    */   private static Icon checkBoxIcon;
/*  18:    */   private static Icon checkBoxMenuItemIcon;
/*  19:    */   private static Icon radioButtonMenuItemIcon;
/*  20:    */   private static Icon menuArrowIcon;
/*  21:    */   private static Icon expandedTreeIcon;
/*  22:    */   private static Icon collapsedTreeIcon;
/*  23:    */   private static Icon comboBoxButtonIcon;
/*  24:    */   
/*  25:    */   private static void drawCheck(Graphics g, int x, int y)
/*  26:    */   {
/*  27: 70 */     g.translate(x, y);
/*  28: 71 */     g.drawLine(3, 5, 3, 5);
/*  29: 72 */     g.fillRect(3, 6, 2, 2);
/*  30: 73 */     g.drawLine(4, 8, 9, 3);
/*  31: 74 */     g.drawLine(5, 8, 9, 4);
/*  32: 75 */     g.drawLine(5, 9, 9, 5);
/*  33: 76 */     g.translate(-x, -y);
/*  34:    */   }
/*  35:    */   
/*  36:    */   private static class CheckBoxIcon
/*  37:    */     implements Icon, UIResource, Serializable
/*  38:    */   {
/*  39:    */     private static final int SIZE = 13;
/*  40:    */     
/*  41:    */     CheckBoxIcon(PlasticIconFactory.1 x0)
/*  42:    */     {
/*  43: 80 */       this();
/*  44:    */     }
/*  45:    */     
/*  46:    */     public int getIconWidth()
/*  47:    */     {
/*  48: 84 */       return 13;
/*  49:    */     }
/*  50:    */     
/*  51:    */     public int getIconHeight()
/*  52:    */     {
/*  53: 85 */       return 13;
/*  54:    */     }
/*  55:    */     
/*  56:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/*  57:    */     {
/*  58: 88 */       JCheckBox cb = (JCheckBox)c;
/*  59: 89 */       ButtonModel model = cb.getModel();
/*  60: 91 */       if (model.isEnabled())
/*  61:    */       {
/*  62: 92 */         if (cb.isBorderPaintedFlat())
/*  63:    */         {
/*  64: 93 */           g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/*  65: 94 */           g.drawRect(x, y, 11, 11);
/*  66:    */           
/*  67: 96 */           g.setColor(PlasticLookAndFeel.getControlHighlight());
/*  68: 97 */           g.fillRect(x + 1, y + 1, 10, 10);
/*  69:    */         }
/*  70: 98 */         else if ((model.isPressed()) && (model.isArmed()))
/*  71:    */         {
/*  72: 99 */           g.setColor(MetalLookAndFeel.getControlShadow());
/*  73:100 */           g.fillRect(x, y, 12, 12);
/*  74:101 */           PlasticUtils.drawPressed3DBorder(g, x, y, 13, 13);
/*  75:    */         }
/*  76:    */         else
/*  77:    */         {
/*  78:103 */           PlasticUtils.drawFlush3DBorder(g, x, y, 13, 13);
/*  79:    */         }
/*  80:105 */         g.setColor(MetalLookAndFeel.getControlInfo());
/*  81:    */       }
/*  82:    */       else
/*  83:    */       {
/*  84:107 */         g.setColor(MetalLookAndFeel.getControlShadow());
/*  85:108 */         g.drawRect(x, y, 11, 11);
/*  86:    */       }
/*  87:111 */       if (model.isSelected()) {
/*  88:112 */         PlasticIconFactory.drawCheck(g, x, y);
/*  89:    */       }
/*  90:    */     }
/*  91:    */     
/*  92:    */     private CheckBoxIcon() {}
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static class CheckBoxMenuItemIcon
/*  96:    */     implements Icon, UIResource, Serializable
/*  97:    */   {
/*  98:    */     private static final int SIZE = 13;
/*  99:    */     
/* 100:    */     CheckBoxMenuItemIcon(PlasticIconFactory.1 x0)
/* 101:    */     {
/* 102:119 */       this();
/* 103:    */     }
/* 104:    */     
/* 105:    */     public int getIconWidth()
/* 106:    */     {
/* 107:123 */       return 13;
/* 108:    */     }
/* 109:    */     
/* 110:    */     public int getIconHeight()
/* 111:    */     {
/* 112:124 */       return 13;
/* 113:    */     }
/* 114:    */     
/* 115:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 116:    */     {
/* 117:127 */       JMenuItem b = (JMenuItem)c;
/* 118:128 */       if (b.isSelected()) {
/* 119:129 */         PlasticIconFactory.drawCheck(g, x, y + 1);
/* 120:    */       }
/* 121:    */     }
/* 122:    */     
/* 123:    */     private CheckBoxMenuItemIcon() {}
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static class RadioButtonMenuItemIcon
/* 127:    */     implements Icon, UIResource, Serializable
/* 128:    */   {
/* 129:    */     private static final int SIZE = 13;
/* 130:    */     
/* 131:    */     RadioButtonMenuItemIcon(PlasticIconFactory.1 x0)
/* 132:    */     {
/* 133:135 */       this();
/* 134:    */     }
/* 135:    */     
/* 136:    */     public int getIconWidth()
/* 137:    */     {
/* 138:139 */       return 13;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public int getIconHeight()
/* 142:    */     {
/* 143:140 */       return 13;
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 147:    */     {
/* 148:143 */       JMenuItem b = (JMenuItem)c;
/* 149:144 */       if (b.isSelected()) {
/* 150:145 */         drawDot(g, x, y);
/* 151:    */       }
/* 152:    */     }
/* 153:    */     
/* 154:    */     private void drawDot(Graphics g, int x, int y)
/* 155:    */     {
/* 156:150 */       g.translate(x, y);
/* 157:151 */       g.drawLine(5, 4, 8, 4);
/* 158:152 */       g.fillRect(4, 5, 6, 4);
/* 159:153 */       g.drawLine(5, 9, 8, 9);
/* 160:154 */       g.translate(-x, -y);
/* 161:    */     }
/* 162:    */     
/* 163:    */     private RadioButtonMenuItemIcon() {}
/* 164:    */   }
/* 165:    */   
/* 166:    */   private static class MenuArrowIcon
/* 167:    */     implements Icon, UIResource, Serializable
/* 168:    */   {
/* 169:    */     private static final int WIDTH = 4;
/* 170:    */     private static final int HEIGHT = 8;
/* 171:    */     
/* 172:    */     MenuArrowIcon(PlasticIconFactory.1 x0)
/* 173:    */     {
/* 174:159 */       this();
/* 175:    */     }
/* 176:    */     
/* 177:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 178:    */     {
/* 179:165 */       JMenuItem b = (JMenuItem)c;
/* 180:    */       
/* 181:167 */       g.translate(x, y);
/* 182:168 */       if (PlasticUtils.isLeftToRight(b))
/* 183:    */       {
/* 184:169 */         g.drawLine(0, 0, 0, 7);
/* 185:170 */         g.drawLine(1, 1, 1, 6);
/* 186:171 */         g.drawLine(2, 2, 2, 5);
/* 187:172 */         g.drawLine(3, 3, 3, 4);
/* 188:    */       }
/* 189:    */       else
/* 190:    */       {
/* 191:174 */         g.drawLine(4, 0, 4, 7);
/* 192:175 */         g.drawLine(3, 1, 3, 6);
/* 193:176 */         g.drawLine(2, 2, 2, 5);
/* 194:177 */         g.drawLine(1, 3, 1, 4);
/* 195:    */       }
/* 196:179 */       g.translate(-x, -y);
/* 197:    */     }
/* 198:    */     
/* 199:    */     public int getIconWidth()
/* 200:    */     {
/* 201:182 */       return 4;
/* 202:    */     }
/* 203:    */     
/* 204:    */     public int getIconHeight()
/* 205:    */     {
/* 206:183 */       return 8;
/* 207:    */     }
/* 208:    */     
/* 209:    */     private MenuArrowIcon() {}
/* 210:    */   }
/* 211:    */   
/* 212:    */   private static class ExpandedTreeIcon
/* 213:    */     implements Icon, Serializable
/* 214:    */   {
/* 215:    */     protected static final int SIZE = 9;
/* 216:    */     protected static final int HALF_SIZE = 4;
/* 217:    */     
/* 218:    */     ExpandedTreeIcon(PlasticIconFactory.1 x0)
/* 219:    */     {
/* 220:192 */       this();
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 224:    */     {
/* 225:198 */       g.setColor(Color.WHITE);
/* 226:199 */       g.fillRect(x, y, 8, 8);
/* 227:200 */       g.setColor(Color.GRAY);
/* 228:201 */       g.drawRect(x, y, 8, 8);
/* 229:202 */       g.setColor(Color.BLACK);
/* 230:203 */       g.drawLine(x + 2, y + 4, x + 6, y + 4);
/* 231:    */     }
/* 232:    */     
/* 233:    */     public int getIconWidth()
/* 234:    */     {
/* 235:206 */       return 9;
/* 236:    */     }
/* 237:    */     
/* 238:    */     public int getIconHeight()
/* 239:    */     {
/* 240:207 */       return 9;
/* 241:    */     }
/* 242:    */     
/* 243:    */     private ExpandedTreeIcon() {}
/* 244:    */   }
/* 245:    */   
/* 246:    */   private static class CollapsedTreeIcon
/* 247:    */     extends PlasticIconFactory.ExpandedTreeIcon
/* 248:    */   {
/* 249:    */     CollapsedTreeIcon(PlasticIconFactory.1 x0)
/* 250:    */     {
/* 251:214 */       this();
/* 252:    */     }
/* 253:    */     
/* 254:    */     private CollapsedTreeIcon()
/* 255:    */     {
/* 256:214 */       super();
/* 257:    */     }
/* 258:    */     
/* 259:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 260:    */     {
/* 261:216 */       super.paintIcon(c, g, x, y);
/* 262:217 */       g.drawLine(x + 4, y + 2, x + 4, y + 6);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   private static class ComboBoxButtonIcon
/* 267:    */     implements Icon, Serializable
/* 268:    */   {
/* 269:    */     ComboBoxButtonIcon(PlasticIconFactory.1 x0)
/* 270:    */     {
/* 271:225 */       this();
/* 272:    */     }
/* 273:    */     
/* 274:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 275:    */     {
/* 276:228 */       JComponent component = (JComponent)c;
/* 277:229 */       int iconWidth = getIconWidth();
/* 278:    */       
/* 279:231 */       g.translate(x, y);
/* 280:    */       
/* 281:233 */       g.setColor(component.isEnabled() ? MetalLookAndFeel.getControlInfo() : MetalLookAndFeel.getControlShadow());
/* 282:    */       
/* 283:    */ 
/* 284:236 */       g.drawLine(0, 0, iconWidth - 1, 0);
/* 285:237 */       g.drawLine(1, 1, 1 + (iconWidth - 3), 1);
/* 286:238 */       g.drawLine(2, 2, 2 + (iconWidth - 5), 2);
/* 287:239 */       g.drawLine(3, 3, 3 + (iconWidth - 7), 3);
/* 288:    */       
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:254 */       g.translate(-x, -y);
/* 303:    */     }
/* 304:    */     
/* 305:    */     public int getIconWidth()
/* 306:    */     {
/* 307:257 */       return 8;
/* 308:    */     }
/* 309:    */     
/* 310:    */     public int getIconHeight()
/* 311:    */     {
/* 312:258 */       return 4;
/* 313:    */     }
/* 314:    */     
/* 315:    */     private ComboBoxButtonIcon() {}
/* 316:    */   }
/* 317:    */   
/* 318:    */   static Icon getCheckBoxIcon()
/* 319:    */   {
/* 320:277 */     if (checkBoxIcon == null) {
/* 321:278 */       checkBoxIcon = new CheckBoxIcon(null);
/* 322:    */     }
/* 323:280 */     return checkBoxIcon;
/* 324:    */   }
/* 325:    */   
/* 326:    */   static Icon getCheckBoxMenuItemIcon()
/* 327:    */   {
/* 328:288 */     if (checkBoxMenuItemIcon == null) {
/* 329:289 */       checkBoxMenuItemIcon = new CheckBoxMenuItemIcon(null);
/* 330:    */     }
/* 331:291 */     return checkBoxMenuItemIcon;
/* 332:    */   }
/* 333:    */   
/* 334:    */   static Icon getRadioButtonMenuItemIcon()
/* 335:    */   {
/* 336:299 */     if (radioButtonMenuItemIcon == null) {
/* 337:300 */       radioButtonMenuItemIcon = new RadioButtonMenuItemIcon(null);
/* 338:    */     }
/* 339:302 */     return radioButtonMenuItemIcon;
/* 340:    */   }
/* 341:    */   
/* 342:    */   static Icon getMenuArrowIcon()
/* 343:    */   {
/* 344:310 */     if (menuArrowIcon == null) {
/* 345:311 */       menuArrowIcon = new MenuArrowIcon(null);
/* 346:    */     }
/* 347:313 */     return menuArrowIcon;
/* 348:    */   }
/* 349:    */   
/* 350:    */   static Icon getExpandedTreeIcon()
/* 351:    */   {
/* 352:321 */     if (expandedTreeIcon == null) {
/* 353:322 */       expandedTreeIcon = new ExpandedTreeIcon(null);
/* 354:    */     }
/* 355:324 */     return expandedTreeIcon;
/* 356:    */   }
/* 357:    */   
/* 358:    */   static Icon getCollapsedTreeIcon()
/* 359:    */   {
/* 360:331 */     if (collapsedTreeIcon == null) {
/* 361:332 */       collapsedTreeIcon = new CollapsedTreeIcon(null);
/* 362:    */     }
/* 363:334 */     return collapsedTreeIcon;
/* 364:    */   }
/* 365:    */   
/* 366:    */   static Icon getComboBoxButtonIcon()
/* 367:    */   {
/* 368:341 */     if (comboBoxButtonIcon == null) {
/* 369:342 */       comboBoxButtonIcon = new ComboBoxButtonIcon(null);
/* 370:    */     }
/* 371:344 */     return comboBoxButtonIcon;
/* 372:    */   }
/* 373:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticIconFactory
 * JD-Core Version:    0.7.0.1
 */
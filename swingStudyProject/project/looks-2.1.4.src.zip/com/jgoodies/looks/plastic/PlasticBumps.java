/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import java.awt.Graphics2D;
/*   8:    */ import java.awt.GraphicsConfiguration;
/*   9:    */ import java.util.Enumeration;
/*  10:    */ import java.util.Vector;
/*  11:    */ import javax.swing.Icon;
/*  12:    */ 
/*  13:    */ final class PlasticBumps
/*  14:    */   implements Icon
/*  15:    */ {
/*  16:    */   protected int xBumps;
/*  17:    */   protected int yBumps;
/*  18:    */   protected Color topColor;
/*  19:    */   protected Color shadowColor;
/*  20:    */   protected Color backColor;
/*  21: 56 */   protected static Vector buffers = new Vector();
/*  22:    */   protected BumpBuffer buffer;
/*  23:    */   
/*  24:    */   public PlasticBumps(Dimension bumpArea)
/*  25:    */   {
/*  26: 60 */     this(bumpArea.width, bumpArea.height);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public PlasticBumps(int width, int height)
/*  30:    */   {
/*  31: 64 */     this(width, height, PlasticLookAndFeel.getPrimaryControlHighlight(), PlasticLookAndFeel.getPrimaryControlDarkShadow(), PlasticLookAndFeel.getPrimaryControlShadow());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public PlasticBumps(int width, int height, Color newTopColor, Color newShadowColor, Color newBackColor)
/*  35:    */   {
/*  36: 72 */     setBumpArea(width, height);
/*  37: 73 */     setBumpColors(newTopColor, newShadowColor, newBackColor);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private BumpBuffer getBuffer(GraphicsConfiguration gc, Color aTopColor, Color aShadowColor, Color aBackColor)
/*  41:    */   {
/*  42: 78 */     if ((this.buffer != null) && (this.buffer.hasSameConfiguration(gc, aTopColor, aShadowColor, aBackColor))) {
/*  43: 80 */       return this.buffer;
/*  44:    */     }
/*  45: 82 */     BumpBuffer result = null;
/*  46: 83 */     Enumeration elements = buffers.elements();
/*  47: 84 */     while (elements.hasMoreElements())
/*  48:    */     {
/*  49: 85 */       BumpBuffer aBuffer = (BumpBuffer)elements.nextElement();
/*  50: 86 */       if (aBuffer.hasSameConfiguration(gc, aTopColor, aShadowColor, aBackColor))
/*  51:    */       {
/*  52: 87 */         result = aBuffer;
/*  53: 88 */         break;
/*  54:    */       }
/*  55:    */     }
/*  56: 91 */     if (result == null)
/*  57:    */     {
/*  58: 92 */       result = new BumpBuffer(gc, this.topColor, this.shadowColor, this.backColor);
/*  59: 93 */       buffers.addElement(result);
/*  60:    */     }
/*  61: 95 */     return result;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setBumpArea(Dimension bumpArea)
/*  65:    */   {
/*  66: 99 */     setBumpArea(bumpArea.width, bumpArea.height);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setBumpArea(int width, int height)
/*  70:    */   {
/*  71:103 */     this.xBumps = (width / 2);
/*  72:104 */     this.yBumps = (height / 2);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setBumpColors(Color newTopColor, Color newShadowColor, Color newBackColor)
/*  76:    */   {
/*  77:108 */     this.topColor = newTopColor;
/*  78:109 */     this.shadowColor = newShadowColor;
/*  79:110 */     this.backColor = newBackColor;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void paintIcon(Component c, Graphics g, int x, int y)
/*  83:    */   {
/*  84:114 */     GraphicsConfiguration gc = (g instanceof Graphics2D) ? ((Graphics2D)g).getDeviceConfiguration() : null;
/*  85:    */     
/*  86:    */ 
/*  87:    */ 
/*  88:118 */     this.buffer = getBuffer(gc, this.topColor, this.shadowColor, this.backColor);
/*  89:    */     
/*  90:120 */     int bufferWidth = this.buffer.getImageSize().width;
/*  91:121 */     int bufferHeight = this.buffer.getImageSize().height;
/*  92:122 */     int iconWidth = getIconWidth();
/*  93:123 */     int iconHeight = getIconHeight();
/*  94:124 */     int x2 = x + iconWidth;
/*  95:125 */     int y2 = y + iconHeight;
/*  96:126 */     int savex = x;
/*  97:128 */     while (y < y2)
/*  98:    */     {
/*  99:129 */       int h = Math.min(y2 - y, bufferHeight);
/* 100:130 */       for (x = savex; x < x2; x += bufferWidth)
/* 101:    */       {
/* 102:131 */         int w = Math.min(x2 - x, bufferWidth);
/* 103:132 */         g.drawImage(this.buffer.getImage(), x, y, x + w, y + h, 0, 0, w, h, null);
/* 104:    */       }
/* 105:134 */       y += bufferHeight;
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int getIconWidth()
/* 110:    */   {
/* 111:138 */     return this.xBumps * 2;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public int getIconHeight()
/* 115:    */   {
/* 116:139 */     return this.yBumps * 2;
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticBumps
 * JD-Core Version:    0.7.0.1
 */
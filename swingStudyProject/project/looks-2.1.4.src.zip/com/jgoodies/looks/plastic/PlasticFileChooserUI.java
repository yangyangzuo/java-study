/*  1:   */ package com.jgoodies.looks.plastic;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import javax.swing.Icon;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.JFileChooser;
/*  7:   */ import javax.swing.UIManager;
/*  8:   */ import javax.swing.filechooser.FileSystemView;
/*  9:   */ import javax.swing.filechooser.FileView;
/* 10:   */ import javax.swing.plaf.ComponentUI;
/* 11:   */ import javax.swing.plaf.basic.BasicFileChooserUI;
/* 12:   */ import javax.swing.plaf.basic.BasicFileChooserUI.BasicFileView;
/* 13:   */ import javax.swing.plaf.metal.MetalFileChooserUI;
/* 14:   */ 
/* 15:   */ public final class PlasticFileChooserUI
/* 16:   */   extends MetalFileChooserUI
/* 17:   */ {
/* 18:57 */   private final BasicFileChooserUI.BasicFileView fileView = new SystemIconFileView(null);
/* 19:   */   
/* 20:   */   public static ComponentUI createUI(JComponent c)
/* 21:   */   {
/* 22:61 */     return new PlasticFileChooserUI((JFileChooser)c);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public PlasticFileChooserUI(JFileChooser fileChooser)
/* 26:   */   {
/* 27:66 */     super(fileChooser);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void clearIconCache()
/* 31:   */   {
/* 32:71 */     this.fileView.clearIconCache();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public FileView getFileView(JFileChooser fc)
/* 36:   */   {
/* 37:76 */     return this.fileView;
/* 38:   */   }
/* 39:   */   
/* 40:   */   private final class SystemIconFileView
/* 41:   */     extends BasicFileChooserUI.BasicFileView
/* 42:   */   {
/* 43:   */     SystemIconFileView(PlasticFileChooserUI.1 x1)
/* 44:   */     {
/* 45:84 */       this();
/* 46:   */     }
/* 47:   */     
/* 48:   */     private SystemIconFileView()
/* 49:   */     {
/* 50:84 */       super();
/* 51:   */     }
/* 52:   */     
/* 53:   */     public Icon getIcon(File f)
/* 54:   */     {
/* 55:87 */       Icon icon = getCachedIcon(f);
/* 56:88 */       if (icon != null) {
/* 57:89 */         return icon;
/* 58:   */       }
/* 59:91 */       if ((f != null) && (UIManager.getBoolean("FileChooser.useSystemIcons"))) {
/* 60:92 */         icon = PlasticFileChooserUI.this.getFileChooser().getFileSystemView().getSystemIcon(f);
/* 61:   */       }
/* 62:94 */       if (icon == null) {
/* 63:95 */         return super.getIcon(f);
/* 64:   */       }
/* 65:97 */       cacheIcon(f, icon);
/* 66:98 */       return icon;
/* 67:   */     }
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticFileChooserUI
 * JD-Core Version:    0.7.0.1
 */
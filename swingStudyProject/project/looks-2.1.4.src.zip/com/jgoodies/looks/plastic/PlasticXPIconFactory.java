/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.LookUtils;
/*   4:    */ import java.awt.BasicStroke;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.GradientPaint;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Graphics2D;
/*  10:    */ import java.awt.RenderingHints;
/*  11:    */ import java.awt.RenderingHints.Key;
/*  12:    */ import java.awt.Stroke;
/*  13:    */ import java.io.Serializable;
/*  14:    */ import javax.swing.AbstractButton;
/*  15:    */ import javax.swing.ButtonModel;
/*  16:    */ import javax.swing.Icon;
/*  17:    */ import javax.swing.JCheckBox;
/*  18:    */ import javax.swing.UIManager;
/*  19:    */ import javax.swing.plaf.ColorUIResource;
/*  20:    */ import javax.swing.plaf.UIResource;
/*  21:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  22:    */ 
/*  23:    */ public final class PlasticXPIconFactory
/*  24:    */ {
/*  25:    */   private static CheckBoxIcon checkBoxIcon;
/*  26:    */   private static RadioButtonIcon radioButtonIcon;
/*  27:    */   
/*  28:    */   static Icon getCheckBoxIcon()
/*  29:    */   {
/*  30: 77 */     if (checkBoxIcon == null) {
/*  31: 78 */       checkBoxIcon = new CheckBoxIcon(null);
/*  32:    */     }
/*  33: 80 */     return checkBoxIcon;
/*  34:    */   }
/*  35:    */   
/*  36:    */   static Icon getRadioButtonIcon()
/*  37:    */   {
/*  38: 89 */     if (radioButtonIcon == null) {
/*  39: 90 */       radioButtonIcon = new RadioButtonIcon(null);
/*  40:    */     }
/*  41: 92 */     return radioButtonIcon;
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static final class CheckBoxIcon
/*  45:    */     implements Icon, UIResource, Serializable
/*  46:    */   {
/*  47:    */     CheckBoxIcon(PlasticXPIconFactory.1 x0)
/*  48:    */     {
/*  49: 99 */       this();
/*  50:    */     }
/*  51:    */     
/*  52:101 */     private static final int SIZE = LookUtils.IS_LOW_RESOLUTION ? 13 : 15;
/*  53:    */     
/*  54:    */     public int getIconWidth()
/*  55:    */     {
/*  56:103 */       return SIZE;
/*  57:    */     }
/*  58:    */     
/*  59:    */     public int getIconHeight()
/*  60:    */     {
/*  61:104 */       return SIZE;
/*  62:    */     }
/*  63:    */     
/*  64:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/*  65:    */     {
/*  66:107 */       JCheckBox cb = (JCheckBox)c;
/*  67:108 */       ButtonModel model = cb.getModel();
/*  68:109 */       Graphics2D g2 = (Graphics2D)g;
/*  69:110 */       boolean paintFocus = ((model.isArmed()) && (!model.isPressed())) || ((cb.hasFocus()) && (PlasticXPIconFactory.isBlank(cb.getText())));
/*  70:    */       
/*  71:    */ 
/*  72:113 */       RenderingHints.Key key = RenderingHints.KEY_ANTIALIASING;
/*  73:114 */       Object newAAHint = RenderingHints.VALUE_ANTIALIAS_ON;
/*  74:115 */       Object oldAAHint = g2.getRenderingHint(key);
/*  75:116 */       if (newAAHint != oldAAHint) {
/*  76:117 */         g2.setRenderingHint(key, newAAHint);
/*  77:    */       } else {
/*  78:119 */         oldAAHint = null;
/*  79:    */       }
/*  80:122 */       drawBorder(g2, model.isEnabled(), x, y, SIZE - 1, SIZE - 1);
/*  81:123 */       drawFill(g2, model.isPressed(), x + 1, y + 1, SIZE - 2, SIZE - 2);
/*  82:124 */       if (paintFocus) {
/*  83:125 */         drawFocus(g2, x + 1, y + 1, SIZE - 3, SIZE - 3);
/*  84:    */       }
/*  85:127 */       if (model.isSelected()) {
/*  86:128 */         drawCheck(g2, model.isEnabled(), x + 3, y + 3, SIZE - 7, SIZE - 7);
/*  87:    */       }
/*  88:131 */       if (oldAAHint != null) {
/*  89:132 */         g2.setRenderingHint(key, oldAAHint);
/*  90:    */       }
/*  91:    */     }
/*  92:    */     
/*  93:    */     private void drawBorder(Graphics2D g2, boolean enabled, int x, int y, int width, int height)
/*  94:    */     {
/*  95:137 */       g2.setColor(enabled ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlDisabled());
/*  96:    */       
/*  97:    */ 
/*  98:140 */       g2.drawRect(x, y, width, height);
/*  99:    */     }
/* 100:    */     
/* 101:    */     private void drawCheck(Graphics2D g2, boolean enabled, int x, int y, int width, int height)
/* 102:    */     {
/* 103:144 */       g2.setColor(enabled ? UIManager.getColor("CheckBox.check") : MetalLookAndFeel.getControlDisabled());
/* 104:    */       
/* 105:    */ 
/* 106:147 */       int right = x + width;
/* 107:148 */       int bottom = y + height;
/* 108:149 */       int startY = y + height / 3;
/* 109:150 */       int turnX = x + width / 2 - 2;
/* 110:151 */       g2.drawLine(x, startY, turnX, bottom - 3);
/* 111:152 */       g2.drawLine(x, startY + 1, turnX, bottom - 2);
/* 112:153 */       g2.drawLine(x, startY + 2, turnX, bottom - 1);
/* 113:154 */       g2.drawLine(turnX + 1, bottom - 2, right, y);
/* 114:155 */       g2.drawLine(turnX + 1, bottom - 1, right, y + 1);
/* 115:156 */       g2.drawLine(turnX + 1, bottom, right, y + 2);
/* 116:    */     }
/* 117:    */     
/* 118:    */     private void drawFill(Graphics2D g2, boolean pressed, int x, int y, int w, int h)
/* 119:    */     {
/* 120:    */       Color lowerRight;
/* 121:    */       Color upperLeft;
/* 122:    */       Color lowerRight;
/* 123:162 */       if (pressed)
/* 124:    */       {
/* 125:163 */         Color upperLeft = MetalLookAndFeel.getControlShadow();
/* 126:164 */         lowerRight = PlasticLookAndFeel.getControlHighlight();
/* 127:    */       }
/* 128:    */       else
/* 129:    */       {
/* 130:166 */         upperLeft = PlasticLookAndFeel.getControl();
/* 131:167 */         lowerRight = PlasticLookAndFeel.getControlHighlight().brighter();
/* 132:    */       }
/* 133:169 */       g2.setPaint(new GradientPaint(x, y, upperLeft, x + w, y + h, lowerRight));
/* 134:170 */       g2.fillRect(x, y, w, h);
/* 135:    */     }
/* 136:    */     
/* 137:    */     private void drawFocus(Graphics2D g2, int x, int y, int width, int height)
/* 138:    */     {
/* 139:174 */       g2.setPaint(new GradientPaint(x, y, PlasticLookAndFeel.getFocusColor().brighter(), width, height, PlasticLookAndFeel.getFocusColor()));
/* 140:    */       
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:182 */       g2.drawRect(x, y, width, height);
/* 148:183 */       g2.drawRect(x + 1, y + 1, width - 2, height - 2);
/* 149:    */     }
/* 150:    */     
/* 151:    */     private CheckBoxIcon() {}
/* 152:    */   }
/* 153:    */   
/* 154:    */   private static final class RadioButtonIcon
/* 155:    */     implements Icon, UIResource, Serializable
/* 156:    */   {
/* 157:    */     RadioButtonIcon(PlasticXPIconFactory.1 x0)
/* 158:    */     {
/* 159:192 */       this();
/* 160:    */     }
/* 161:    */     
/* 162:194 */     private static final int SIZE = LookUtils.IS_LOW_RESOLUTION ? 13 : 15;
/* 163:196 */     private static final Stroke FOCUS_STROKE = new BasicStroke(2.0F);
/* 164:    */     
/* 165:    */     public int getIconWidth()
/* 166:    */     {
/* 167:198 */       return SIZE;
/* 168:    */     }
/* 169:    */     
/* 170:    */     public int getIconHeight()
/* 171:    */     {
/* 172:199 */       return SIZE;
/* 173:    */     }
/* 174:    */     
/* 175:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 176:    */     {
/* 177:202 */       Graphics2D g2 = (Graphics2D)g;
/* 178:203 */       AbstractButton rb = (AbstractButton)c;
/* 179:204 */       ButtonModel model = rb.getModel();
/* 180:205 */       boolean paintFocus = ((model.isArmed()) && (!model.isPressed())) || ((rb.hasFocus()) && (PlasticXPIconFactory.isBlank(rb.getText())));
/* 181:    */       
/* 182:    */ 
/* 183:208 */       RenderingHints.Key key = RenderingHints.KEY_ANTIALIASING;
/* 184:209 */       Object newAAHint = RenderingHints.VALUE_ANTIALIAS_ON;
/* 185:210 */       Object oldAAHint = g2.getRenderingHint(key);
/* 186:211 */       if (newAAHint != oldAAHint) {
/* 187:212 */         g2.setRenderingHint(key, newAAHint);
/* 188:    */       } else {
/* 189:214 */         oldAAHint = null;
/* 190:    */       }
/* 191:217 */       drawFill(g2, model.isPressed(), x, y, SIZE - 1, SIZE - 1);
/* 192:218 */       if (paintFocus) {
/* 193:219 */         drawFocus(g2, x + 1, y + 1, SIZE - 3, SIZE - 3);
/* 194:    */       }
/* 195:221 */       if (model.isSelected()) {
/* 196:222 */         drawCheck(g2, c, model.isEnabled(), x + 4, y + 4, SIZE - 8, SIZE - 8);
/* 197:    */       }
/* 198:224 */       drawBorder(g2, model.isEnabled(), x, y, SIZE - 1, SIZE - 1);
/* 199:226 */       if (oldAAHint != null) {
/* 200:227 */         g2.setRenderingHint(key, oldAAHint);
/* 201:    */       }
/* 202:    */     }
/* 203:    */     
/* 204:    */     private void drawBorder(Graphics2D g2, boolean enabled, int x, int y, int w, int h)
/* 205:    */     {
/* 206:232 */       g2.setColor(enabled ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlDisabled());
/* 207:    */       
/* 208:    */ 
/* 209:235 */       g2.drawOval(x, y, w, h);
/* 210:    */     }
/* 211:    */     
/* 212:    */     private void drawCheck(Graphics2D g2, Component c, boolean enabled, int x, int y, int w, int h)
/* 213:    */     {
/* 214:239 */       g2.translate(x, y);
/* 215:240 */       if (enabled)
/* 216:    */       {
/* 217:241 */         g2.setColor(UIManager.getColor("RadioButton.check"));
/* 218:242 */         g2.fillOval(0, 0, w, h);
/* 219:243 */         UIManager.getIcon("RadioButton.checkIcon").paintIcon(c, g2, 0, 0);
/* 220:    */       }
/* 221:    */       else
/* 222:    */       {
/* 223:245 */         g2.setColor(MetalLookAndFeel.getControlDisabled());
/* 224:246 */         g2.fillOval(0, 0, w, h);
/* 225:    */       }
/* 226:248 */       g2.translate(-x, -y);
/* 227:    */     }
/* 228:    */     
/* 229:    */     private void drawFill(Graphics2D g2, boolean pressed, int x, int y, int w, int h)
/* 230:    */     {
/* 231:    */       Color lowerRight;
/* 232:    */       Color upperLeft;
/* 233:    */       Color lowerRight;
/* 234:254 */       if (pressed)
/* 235:    */       {
/* 236:255 */         Color upperLeft = MetalLookAndFeel.getControlShadow();
/* 237:256 */         lowerRight = PlasticLookAndFeel.getControlHighlight();
/* 238:    */       }
/* 239:    */       else
/* 240:    */       {
/* 241:258 */         upperLeft = PlasticLookAndFeel.getControl();
/* 242:259 */         lowerRight = PlasticLookAndFeel.getControlHighlight().brighter();
/* 243:    */       }
/* 244:261 */       g2.setPaint(new GradientPaint(x, y, upperLeft, x + w, y + h, lowerRight));
/* 245:262 */       g2.fillOval(x, y, w, h);
/* 246:    */     }
/* 247:    */     
/* 248:    */     private void drawFocus(Graphics2D g2, int x, int y, int w, int h)
/* 249:    */     {
/* 250:266 */       g2.setPaint(new GradientPaint(x, y, PlasticLookAndFeel.getFocusColor().brighter(), w, h, PlasticLookAndFeel.getFocusColor()));
/* 251:    */       
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:274 */       Stroke stroke = g2.getStroke();
/* 259:275 */       g2.setStroke(FOCUS_STROKE);
/* 260:276 */       g2.drawOval(x, y, w, h);
/* 261:277 */       g2.setStroke(stroke);
/* 262:    */     }
/* 263:    */     
/* 264:    */     private RadioButtonIcon() {}
/* 265:    */   }
/* 266:    */   
/* 267:    */   private static boolean isBlank(String str)
/* 268:    */   {
/* 269:    */     int length;
/* 270:304 */     if ((str == null) || ((length = str.length()) == 0)) {
/* 271:305 */       return true;
/* 272:    */     }
/* 273:    */     int length;
/* 274:306 */     for (int i = length - 1; i >= 0; i--) {
/* 275:307 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 276:308 */         return false;
/* 277:    */       }
/* 278:    */     }
/* 279:310 */     return true;
/* 280:    */   }
/* 281:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPIconFactory
 * JD-Core Version:    0.7.0.1
 */
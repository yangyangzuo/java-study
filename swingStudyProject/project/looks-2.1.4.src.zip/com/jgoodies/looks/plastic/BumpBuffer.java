/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.GraphicsConfiguration;
/*   7:    */ import java.awt.Image;
/*   8:    */ import java.awt.image.BufferedImage;
/*   9:    */ import java.awt.image.IndexColorModel;
/*  10:    */ 
/*  11:    */ final class BumpBuffer
/*  12:    */ {
/*  13:    */   static final int IMAGE_SIZE = 64;
/*  14:145 */   static Dimension imageSize = new Dimension(64, 64);
/*  15:    */   transient Image image;
/*  16:    */   Color topColor;
/*  17:    */   Color shadowColor;
/*  18:    */   Color backColor;
/*  19:    */   private GraphicsConfiguration gc;
/*  20:    */   
/*  21:    */   public BumpBuffer(GraphicsConfiguration gc, Color aTopColor, Color aShadowColor, Color aBackColor)
/*  22:    */   {
/*  23:158 */     this.gc = gc;
/*  24:159 */     this.topColor = aTopColor;
/*  25:160 */     this.shadowColor = aShadowColor;
/*  26:161 */     this.backColor = aBackColor;
/*  27:162 */     createImage();
/*  28:163 */     fillBumpBuffer();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public boolean hasSameConfiguration(GraphicsConfiguration aGC, Color aTopColor, Color aShadowColor, Color aBackColor)
/*  32:    */   {
/*  33:171 */     if (this.gc != null)
/*  34:    */     {
/*  35:172 */       if (!this.gc.equals(aGC)) {
/*  36:173 */         return false;
/*  37:    */       }
/*  38:    */     }
/*  39:175 */     else if (aGC != null) {
/*  40:176 */       return false;
/*  41:    */     }
/*  42:178 */     return (this.topColor.equals(aTopColor)) && (this.shadowColor.equals(aShadowColor)) && (this.backColor.equals(aBackColor));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Image getImage()
/*  46:    */   {
/*  47:187 */     return this.image;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Dimension getImageSize()
/*  51:    */   {
/*  52:189 */     return imageSize;
/*  53:    */   }
/*  54:    */   
/*  55:    */   private void fillBumpBuffer()
/*  56:    */   {
/*  57:195 */     Graphics g = this.image.getGraphics();
/*  58:    */     
/*  59:197 */     g.setColor(this.backColor);
/*  60:198 */     g.fillRect(0, 0, 64, 64);
/*  61:    */     
/*  62:200 */     g.setColor(this.topColor);
/*  63:201 */     for (int x = 0; x < 64; x += 4) {
/*  64:202 */       for (int y = 0; y < 64; y += 4)
/*  65:    */       {
/*  66:203 */         g.drawLine(x, y, x, y);
/*  67:204 */         g.drawLine(x + 2, y + 2, x + 2, y + 2);
/*  68:    */       }
/*  69:    */     }
/*  70:208 */     g.setColor(this.shadowColor);
/*  71:209 */     for (int x = 0; x < 64; x += 4) {
/*  72:210 */       for (int y = 0; y < 64; y += 4)
/*  73:    */       {
/*  74:211 */         g.drawLine(x + 1, y + 1, x + 1, y + 1);
/*  75:212 */         g.drawLine(x + 3, y + 3, x + 3, y + 3);
/*  76:    */       }
/*  77:    */     }
/*  78:215 */     g.dispose();
/*  79:    */   }
/*  80:    */   
/*  81:    */   private void createImage()
/*  82:    */   {
/*  83:223 */     if (this.gc != null)
/*  84:    */     {
/*  85:224 */       this.image = this.gc.createCompatibleImage(64, 64);
/*  86:    */     }
/*  87:    */     else
/*  88:    */     {
/*  89:226 */       int[] cmap = { this.backColor.getRGB(), this.topColor.getRGB(), this.shadowColor.getRGB() };
/*  90:227 */       IndexColorModel icm = new IndexColorModel(8, 3, cmap, 0, false, -1, 0);
/*  91:    */       
/*  92:229 */       this.image = new BufferedImage(64, 64, 13, icm);
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.BumpBuffer
 * JD-Core Version:    0.7.0.1
 */
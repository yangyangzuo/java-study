/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.common.ExtBasicArrowButtonHandler;
/*   4:    */ import com.jgoodies.looks.common.ExtBasicSpinnerLayout;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.LayoutManager;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ import javax.swing.JPanel;
/*  10:    */ import javax.swing.JSpinner;
/*  11:    */ import javax.swing.JSpinner.DefaultEditor;
/*  12:    */ import javax.swing.JTextField;
/*  13:    */ import javax.swing.UIManager;
/*  14:    */ import javax.swing.border.EmptyBorder;
/*  15:    */ import javax.swing.plaf.ComponentUI;
/*  16:    */ import javax.swing.plaf.basic.BasicSpinnerUI;
/*  17:    */ 
/*  18:    */ public class PlasticSpinnerUI
/*  19:    */   extends BasicSpinnerUI
/*  20:    */ {
/*  21:    */   public static ComponentUI createUI(JComponent b)
/*  22:    */   {
/*  23: 58 */     return new PlasticSpinnerUI();
/*  24:    */   }
/*  25:    */   
/*  26: 70 */   private static final ExtBasicArrowButtonHandler nextButtonHandler = new ExtBasicArrowButtonHandler("increment", true);
/*  27: 72 */   private static final ExtBasicArrowButtonHandler previousButtonHandler = new ExtBasicArrowButtonHandler("decrement", false);
/*  28:    */   
/*  29:    */   protected Component createPreviousButton()
/*  30:    */   {
/*  31: 90 */     return new SpinnerArrowButton(5, previousButtonHandler, null);
/*  32:    */   }
/*  33:    */   
/*  34:    */   protected Component createNextButton()
/*  35:    */   {
/*  36:108 */     return new SpinnerArrowButton(1, nextButtonHandler, null);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected LayoutManager createLayout()
/*  40:    */   {
/*  41:126 */     return new ExtBasicSpinnerLayout();
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected JComponent createEditor()
/*  45:    */   {
/*  46:154 */     JComponent editor = this.spinner.getEditor();
/*  47:155 */     configureEditorBorder(editor);
/*  48:156 */     return editor;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected void replaceEditor(JComponent oldEditor, JComponent newEditor)
/*  52:    */   {
/*  53:175 */     this.spinner.remove(oldEditor);
/*  54:176 */     configureEditorBorder(newEditor);
/*  55:177 */     this.spinner.add(newEditor, "Editor");
/*  56:    */   }
/*  57:    */   
/*  58:    */   private void configureEditorBorder(JComponent editor)
/*  59:    */   {
/*  60:185 */     if ((editor instanceof JSpinner.DefaultEditor))
/*  61:    */     {
/*  62:186 */       JSpinner.DefaultEditor defaultEditor = (JSpinner.DefaultEditor)editor;
/*  63:187 */       JTextField editorField = defaultEditor.getTextField();
/*  64:188 */       Insets insets = UIManager.getInsets("Spinner.defaultEditorInsets");
/*  65:189 */       editorField.setBorder(new EmptyBorder(insets));
/*  66:    */     }
/*  67:190 */     else if (((editor instanceof JPanel)) && (editor.getBorder() == null) && (editor.getComponentCount() > 0))
/*  68:    */     {
/*  69:193 */       JComponent editorField = (JComponent)editor.getComponent(0);
/*  70:194 */       Insets insets = UIManager.getInsets("Spinner.defaultEditorInsets");
/*  71:195 */       editorField.setBorder(new EmptyBorder(insets));
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static final class SpinnerArrowButton
/*  76:    */     extends PlasticArrowButton
/*  77:    */   {
/*  78:    */     SpinnerArrowButton(int x0, ExtBasicArrowButtonHandler x1, PlasticSpinnerUI.1 x2)
/*  79:    */     {
/*  80:203 */       this(x0, x1);
/*  81:    */     }
/*  82:    */     
/*  83:    */     private SpinnerArrowButton(int direction, ExtBasicArrowButtonHandler handler)
/*  84:    */     {
/*  85:206 */       super(UIManager.getInt("ScrollBar.width"), true);
/*  86:207 */       addActionListener(handler);
/*  87:208 */       addMouseListener(handler);
/*  88:    */     }
/*  89:    */     
/*  90:    */     protected int calculateArrowHeight(int height, int width)
/*  91:    */     {
/*  92:212 */       int arrowHeight = Math.min((height - 4) / 3, (width - 4) / 3);
/*  93:213 */       return Math.max(arrowHeight, 3);
/*  94:    */     }
/*  95:    */     
/*  96:    */     protected int calculateArrowOffset()
/*  97:    */     {
/*  98:217 */       return 1;
/*  99:    */     }
/* 100:    */     
/* 101:    */     protected boolean isPaintingNorthBottom()
/* 102:    */     {
/* 103:221 */       return true;
/* 104:    */     }
/* 105:    */   }
/* 106:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticSpinnerUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.awt.Insets;
/*   6:    */ import javax.swing.AbstractButton;
/*   7:    */ import javax.swing.ButtonModel;
/*   8:    */ import javax.swing.JButton;
/*   9:    */ import javax.swing.JInternalFrame;
/*  10:    */ import javax.swing.JMenuItem;
/*  11:    */ import javax.swing.JToggleButton;
/*  12:    */ import javax.swing.UIManager;
/*  13:    */ import javax.swing.border.AbstractBorder;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import javax.swing.border.CompoundBorder;
/*  16:    */ import javax.swing.border.EmptyBorder;
/*  17:    */ import javax.swing.plaf.BorderUIResource;
/*  18:    */ import javax.swing.plaf.BorderUIResource.CompoundBorderUIResource;
/*  19:    */ import javax.swing.plaf.UIResource;
/*  20:    */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*  21:    */ import javax.swing.plaf.metal.MetalBorders.ScrollPaneBorder;
/*  22:    */ import javax.swing.text.JTextComponent;
/*  23:    */ 
/*  24:    */ final class PlasticBorders
/*  25:    */ {
/*  26:    */   private static Border comboBoxEditorBorder;
/*  27:    */   private static Border comboBoxArrowButtonBorder;
/*  28:    */   private static Border etchedBorder;
/*  29:    */   private static Border flush3DBorder;
/*  30:    */   private static Border menuBarHeaderBorder;
/*  31:    */   private static Border menuBorder;
/*  32:    */   private static Border menuItemBorder;
/*  33:    */   private static Border popupMenuBorder;
/*  34:    */   private static Border noMarginPopupMenuBorder;
/*  35:    */   private static Border rolloverButtonBorder;
/*  36:    */   private static Border scrollPaneBorder;
/*  37:    */   private static Border separatorBorder;
/*  38:    */   private static Border textFieldBorder;
/*  39:    */   private static Border thinLoweredBorder;
/*  40:    */   private static Border thinRaisedBorder;
/*  41:    */   private static Border toolBarHeaderBorder;
/*  42:    */   
/*  43:    */   static Border getButtonBorder(Insets buttonMargin)
/*  44:    */   {
/*  45: 90 */     return new BorderUIResource.CompoundBorderUIResource(new ButtonBorder(buttonMargin), new BasicBorders.MarginBorder());
/*  46:    */   }
/*  47:    */   
/*  48:    */   static Border getComboBoxArrowButtonBorder()
/*  49:    */   {
/*  50:101 */     if (comboBoxArrowButtonBorder == null) {
/*  51:102 */       comboBoxArrowButtonBorder = new CompoundBorder(new ComboBoxArrowButtonBorder(null), new BasicBorders.MarginBorder());
/*  52:    */     }
/*  53:106 */     return comboBoxArrowButtonBorder;
/*  54:    */   }
/*  55:    */   
/*  56:    */   static Border getComboBoxEditorBorder()
/*  57:    */   {
/*  58:115 */     if (comboBoxEditorBorder == null) {
/*  59:116 */       comboBoxEditorBorder = new CompoundBorder(new ComboBoxEditorBorder(null), new BasicBorders.MarginBorder());
/*  60:    */     }
/*  61:120 */     return comboBoxEditorBorder;
/*  62:    */   }
/*  63:    */   
/*  64:    */   static Border getEtchedBorder()
/*  65:    */   {
/*  66:130 */     if (etchedBorder == null) {
/*  67:131 */       etchedBorder = new BorderUIResource.CompoundBorderUIResource(new EtchedBorder(null), new BasicBorders.MarginBorder());
/*  68:    */     }
/*  69:135 */     return etchedBorder;
/*  70:    */   }
/*  71:    */   
/*  72:    */   static Border getFlush3DBorder()
/*  73:    */   {
/*  74:144 */     if (flush3DBorder == null) {
/*  75:145 */       flush3DBorder = new Flush3DBorder(null);
/*  76:    */     }
/*  77:147 */     return flush3DBorder;
/*  78:    */   }
/*  79:    */   
/*  80:    */   static Border getInternalFrameBorder()
/*  81:    */   {
/*  82:156 */     return new InternalFrameBorder(null);
/*  83:    */   }
/*  84:    */   
/*  85:    */   static Border getMenuBarHeaderBorder()
/*  86:    */   {
/*  87:166 */     if (menuBarHeaderBorder == null) {
/*  88:167 */       menuBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(new MenuBarHeaderBorder(null), new BasicBorders.MarginBorder());
/*  89:    */     }
/*  90:171 */     return menuBarHeaderBorder;
/*  91:    */   }
/*  92:    */   
/*  93:    */   static Border getMenuBorder()
/*  94:    */   {
/*  95:180 */     if (menuBorder == null) {
/*  96:181 */       menuBorder = new BorderUIResource.CompoundBorderUIResource(new MenuBorder(null), new BasicBorders.MarginBorder());
/*  97:    */     }
/*  98:185 */     return menuBorder;
/*  99:    */   }
/* 100:    */   
/* 101:    */   static Border getMenuItemBorder()
/* 102:    */   {
/* 103:194 */     if (menuItemBorder == null) {
/* 104:195 */       menuItemBorder = new BorderUIResource(new BasicBorders.MarginBorder());
/* 105:    */     }
/* 106:198 */     return menuItemBorder;
/* 107:    */   }
/* 108:    */   
/* 109:    */   static Border getPopupMenuBorder()
/* 110:    */   {
/* 111:207 */     if (popupMenuBorder == null) {
/* 112:208 */       popupMenuBorder = new PopupMenuBorder(null);
/* 113:    */     }
/* 114:210 */     return popupMenuBorder;
/* 115:    */   }
/* 116:    */   
/* 117:    */   static Border getNoMarginPopupMenuBorder()
/* 118:    */   {
/* 119:220 */     if (noMarginPopupMenuBorder == null) {
/* 120:221 */       noMarginPopupMenuBorder = new NoMarginPopupMenuBorder(null);
/* 121:    */     }
/* 122:223 */     return noMarginPopupMenuBorder;
/* 123:    */   }
/* 124:    */   
/* 125:    */   static Border getPaletteBorder()
/* 126:    */   {
/* 127:232 */     return new PaletteBorder(null);
/* 128:    */   }
/* 129:    */   
/* 130:    */   static Border getRolloverButtonBorder()
/* 131:    */   {
/* 132:241 */     if (rolloverButtonBorder == null) {
/* 133:242 */       rolloverButtonBorder = new CompoundBorder(new RolloverButtonBorder(null), new RolloverMarginBorder());
/* 134:    */     }
/* 135:246 */     return rolloverButtonBorder;
/* 136:    */   }
/* 137:    */   
/* 138:    */   static Border getScrollPaneBorder()
/* 139:    */   {
/* 140:255 */     if (scrollPaneBorder == null) {
/* 141:256 */       scrollPaneBorder = new ScrollPaneBorder(null);
/* 142:    */     }
/* 143:258 */     return scrollPaneBorder;
/* 144:    */   }
/* 145:    */   
/* 146:    */   static Border getSeparatorBorder()
/* 147:    */   {
/* 148:268 */     if (separatorBorder == null) {
/* 149:269 */       separatorBorder = new BorderUIResource.CompoundBorderUIResource(new SeparatorBorder(null), new BasicBorders.MarginBorder());
/* 150:    */     }
/* 151:273 */     return separatorBorder;
/* 152:    */   }
/* 153:    */   
/* 154:    */   static Border getTextFieldBorder()
/* 155:    */   {
/* 156:282 */     if (textFieldBorder == null) {
/* 157:283 */       textFieldBorder = new BorderUIResource.CompoundBorderUIResource(new TextFieldBorder(null), new BasicBorders.MarginBorder());
/* 158:    */     }
/* 159:287 */     return textFieldBorder;
/* 160:    */   }
/* 161:    */   
/* 162:    */   static Border getThinLoweredBorder()
/* 163:    */   {
/* 164:296 */     if (thinLoweredBorder == null) {
/* 165:297 */       thinLoweredBorder = new ThinLoweredBorder(null);
/* 166:    */     }
/* 167:299 */     return thinLoweredBorder;
/* 168:    */   }
/* 169:    */   
/* 170:    */   static Border getThinRaisedBorder()
/* 171:    */   {
/* 172:308 */     if (thinRaisedBorder == null) {
/* 173:309 */       thinRaisedBorder = new ThinRaisedBorder(null);
/* 174:    */     }
/* 175:311 */     return thinRaisedBorder;
/* 176:    */   }
/* 177:    */   
/* 178:    */   static Border getToggleButtonBorder(Insets buttonMargin)
/* 179:    */   {
/* 180:320 */     return new BorderUIResource.CompoundBorderUIResource(new ToggleButtonBorder(buttonMargin, null), new BasicBorders.MarginBorder());
/* 181:    */   }
/* 182:    */   
/* 183:    */   static Border getToolBarHeaderBorder()
/* 184:    */   {
/* 185:332 */     if (toolBarHeaderBorder == null) {
/* 186:333 */       toolBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(new ToolBarHeaderBorder(null), new BasicBorders.MarginBorder());
/* 187:    */     }
/* 188:337 */     return toolBarHeaderBorder;
/* 189:    */   }
/* 190:    */   
/* 191:    */   private static class Flush3DBorder
/* 192:    */     extends AbstractBorder
/* 193:    */     implements UIResource
/* 194:    */   {
/* 195:    */     Flush3DBorder(PlasticBorders.1 x0)
/* 196:    */     {
/* 197:340 */       this();
/* 198:    */     }
/* 199:    */     
/* 200:342 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 201:    */     
/* 202:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 203:    */     {
/* 204:345 */       if (c.isEnabled()) {
/* 205:346 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 206:    */       } else {
/* 207:348 */         PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/* 208:    */       }
/* 209:    */     }
/* 210:    */     
/* 211:    */     public Insets getBorderInsets(Component c)
/* 212:    */     {
/* 213:351 */       return INSETS;
/* 214:    */     }
/* 215:    */     
/* 216:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 217:    */     {
/* 218:354 */       newInsets.top = INSETS.top;
/* 219:355 */       newInsets.left = INSETS.left;
/* 220:356 */       newInsets.bottom = INSETS.bottom;
/* 221:357 */       newInsets.right = INSETS.right;
/* 222:358 */       return newInsets;
/* 223:    */     }
/* 224:    */     
/* 225:    */     private Flush3DBorder() {}
/* 226:    */   }
/* 227:    */   
/* 228:    */   private static class ButtonBorder
/* 229:    */     extends AbstractBorder
/* 230:    */     implements UIResource
/* 231:    */   {
/* 232:    */     protected final Insets insets;
/* 233:    */     
/* 234:    */     protected ButtonBorder(Insets insets)
/* 235:    */     {
/* 236:368 */       this.insets = insets;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 240:    */     {
/* 241:372 */       AbstractButton button = (AbstractButton)c;
/* 242:373 */       ButtonModel model = button.getModel();
/* 243:375 */       if (model.isEnabled())
/* 244:    */       {
/* 245:376 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 246:377 */         boolean isDefault = ((button instanceof JButton)) && (((JButton)button).isDefaultButton());
/* 247:380 */         if ((isPressed) && (isDefault)) {
/* 248:381 */           PlasticUtils.drawDefaultButtonPressedBorder(g, x, y, w, h);
/* 249:382 */         } else if (isPressed) {
/* 250:383 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 251:384 */         } else if (isDefault) {
/* 252:385 */           PlasticUtils.drawDefaultButtonBorder(g, x, y, w, h, false);
/* 253:    */         } else {
/* 254:387 */           PlasticUtils.drawButtonBorder(g, x, y, w, h, false);
/* 255:    */         }
/* 256:    */       }
/* 257:    */       else
/* 258:    */       {
/* 259:389 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/* 260:    */       }
/* 261:    */     }
/* 262:    */     
/* 263:    */     public Insets getBorderInsets(Component c)
/* 264:    */     {
/* 265:393 */       return this.insets;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 269:    */     {
/* 270:396 */       newInsets.top = this.insets.top;
/* 271:397 */       newInsets.left = this.insets.left;
/* 272:398 */       newInsets.bottom = this.insets.bottom;
/* 273:399 */       newInsets.right = this.insets.right;
/* 274:400 */       return newInsets;
/* 275:    */     }
/* 276:    */   }
/* 277:    */   
/* 278:    */   private static final class ComboBoxArrowButtonBorder
/* 279:    */     extends AbstractBorder
/* 280:    */     implements UIResource
/* 281:    */   {
/* 282:    */     ComboBoxArrowButtonBorder(PlasticBorders.1 x0)
/* 283:    */     {
/* 284:405 */       this();
/* 285:    */     }
/* 286:    */     
/* 287:407 */     protected static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 288:    */     
/* 289:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 290:    */     {
/* 291:410 */       AbstractButton button = (AbstractButton)c;
/* 292:411 */       ButtonModel model = button.getModel();
/* 293:413 */       if (model.isEnabled())
/* 294:    */       {
/* 295:414 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 296:416 */         if (isPressed) {
/* 297:417 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 298:    */         } else {
/* 299:419 */           PlasticUtils.drawButtonBorder(g, x, y, w, h, false);
/* 300:    */         }
/* 301:    */       }
/* 302:    */       else
/* 303:    */       {
/* 304:421 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/* 305:    */       }
/* 306:    */     }
/* 307:    */     
/* 308:    */     public Insets getBorderInsets(Component c)
/* 309:    */     {
/* 310:425 */       return INSETS;
/* 311:    */     }
/* 312:    */     
/* 313:    */     private ComboBoxArrowButtonBorder() {}
/* 314:    */   }
/* 315:    */   
/* 316:    */   private static final class ComboBoxEditorBorder
/* 317:    */     extends AbstractBorder
/* 318:    */   {
/* 319:    */     ComboBoxEditorBorder(PlasticBorders.1 x0)
/* 320:    */     {
/* 321:429 */       this();
/* 322:    */     }
/* 323:    */     
/* 324:431 */     private static final Insets INSETS = new Insets(2, 2, 2, 0);
/* 325:    */     
/* 326:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 327:    */     {
/* 328:434 */       if (c.isEnabled())
/* 329:    */       {
/* 330:435 */         PlasticUtils.drawFlush3DBorder(g, x, y, w + 2, h);
/* 331:    */       }
/* 332:    */       else
/* 333:    */       {
/* 334:437 */         PlasticUtils.drawDisabledBorder(g, x, y, w + 2, h - 1);
/* 335:438 */         g.setColor(UIManager.getColor("control"));
/* 336:439 */         g.drawLine(x, y + h - 1, x + w, y + h - 1);
/* 337:    */       }
/* 338:    */     }
/* 339:    */     
/* 340:    */     public Insets getBorderInsets(Component c)
/* 341:    */     {
/* 342:443 */       return INSETS;
/* 343:    */     }
/* 344:    */     
/* 345:    */     private ComboBoxEditorBorder() {}
/* 346:    */   }
/* 347:    */   
/* 348:    */   private static final class InternalFrameBorder
/* 349:    */     extends AbstractBorder
/* 350:    */     implements UIResource
/* 351:    */   {
/* 352:    */     InternalFrameBorder(PlasticBorders.1 x0)
/* 353:    */     {
/* 354:450 */       this();
/* 355:    */     }
/* 356:    */     
/* 357:452 */     private static final Insets NORMAL_INSETS = new Insets(1, 1, 1, 1);
/* 358:453 */     private static final Insets MAXIMIZED_INSETS = new Insets(1, 1, 0, 0);
/* 359:    */     
/* 360:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 361:    */     {
/* 362:457 */       JInternalFrame frame = (JInternalFrame)c;
/* 363:458 */       if (frame.isMaximum()) {
/* 364:459 */         paintMaximizedBorder(g, x, y, w, h);
/* 365:    */       } else {
/* 366:461 */         PlasticUtils.drawThinFlush3DBorder(g, x, y, w, h);
/* 367:    */       }
/* 368:    */     }
/* 369:    */     
/* 370:    */     private void paintMaximizedBorder(Graphics g, int x, int y, int w, int h)
/* 371:    */     {
/* 372:465 */       g.translate(x, y);
/* 373:466 */       g.setColor(PlasticLookAndFeel.getControlHighlight());
/* 374:467 */       g.drawLine(0, 0, w - 2, 0);
/* 375:468 */       g.drawLine(0, 0, 0, h - 2);
/* 376:469 */       g.translate(-x, -y);
/* 377:    */     }
/* 378:    */     
/* 379:    */     public Insets getBorderInsets(Component c)
/* 380:    */     {
/* 381:473 */       return ((JInternalFrame)c).isMaximum() ? MAXIMIZED_INSETS : NORMAL_INSETS;
/* 382:    */     }
/* 383:    */     
/* 384:    */     private InternalFrameBorder() {}
/* 385:    */   }
/* 386:    */   
/* 387:    */   private static final class PaletteBorder
/* 388:    */     extends AbstractBorder
/* 389:    */     implements UIResource
/* 390:    */   {
/* 391:    */     PaletteBorder(PlasticBorders.1 x0)
/* 392:    */     {
/* 393:481 */       this();
/* 394:    */     }
/* 395:    */     
/* 396:483 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 397:    */     
/* 398:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 399:    */     {
/* 400:486 */       g.translate(x, y);
/* 401:487 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 402:488 */       g.drawRect(0, 0, w - 1, h - 1);
/* 403:489 */       g.translate(-x, -y);
/* 404:    */     }
/* 405:    */     
/* 406:    */     public Insets getBorderInsets(Component c)
/* 407:    */     {
/* 408:492 */       return INSETS;
/* 409:    */     }
/* 410:    */     
/* 411:    */     private PaletteBorder() {}
/* 412:    */   }
/* 413:    */   
/* 414:    */   private static final class SeparatorBorder
/* 415:    */     extends AbstractBorder
/* 416:    */     implements UIResource
/* 417:    */   {
/* 418:    */     SeparatorBorder(PlasticBorders.1 x0)
/* 419:    */     {
/* 420:500 */       this();
/* 421:    */     }
/* 422:    */     
/* 423:502 */     private static final Insets INSETS = new Insets(0, 0, 2, 1);
/* 424:    */     
/* 425:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 426:    */     {
/* 427:505 */       g.translate(x, y);
/* 428:506 */       g.setColor(UIManager.getColor("Separator.foreground"));
/* 429:507 */       g.drawLine(0, h - 2, w - 1, h - 2);
/* 430:    */       
/* 431:509 */       g.setColor(UIManager.getColor("Separator.background"));
/* 432:510 */       g.drawLine(0, h - 1, w - 1, h - 1);
/* 433:511 */       g.translate(-x, -y);
/* 434:    */     }
/* 435:    */     
/* 436:    */     public Insets getBorderInsets(Component c)
/* 437:    */     {
/* 438:513 */       return INSETS;
/* 439:    */     }
/* 440:    */     
/* 441:    */     private SeparatorBorder() {}
/* 442:    */   }
/* 443:    */   
/* 444:    */   private static final class ThinRaisedBorder
/* 445:    */     extends AbstractBorder
/* 446:    */     implements UIResource
/* 447:    */   {
/* 448:    */     ThinRaisedBorder(PlasticBorders.1 x0)
/* 449:    */     {
/* 450:517 */       this();
/* 451:    */     }
/* 452:    */     
/* 453:518 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 454:    */     
/* 455:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 456:    */     {
/* 457:521 */       PlasticUtils.drawThinFlush3DBorder(g, x, y, w, h);
/* 458:    */     }
/* 459:    */     
/* 460:    */     public Insets getBorderInsets(Component c)
/* 461:    */     {
/* 462:524 */       return INSETS;
/* 463:    */     }
/* 464:    */     
/* 465:    */     private ThinRaisedBorder() {}
/* 466:    */   }
/* 467:    */   
/* 468:    */   private static final class ThinLoweredBorder
/* 469:    */     extends AbstractBorder
/* 470:    */     implements UIResource
/* 471:    */   {
/* 472:    */     ThinLoweredBorder(PlasticBorders.1 x0)
/* 473:    */     {
/* 474:528 */       this();
/* 475:    */     }
/* 476:    */     
/* 477:529 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 478:    */     
/* 479:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 480:    */     {
/* 481:532 */       PlasticUtils.drawThinPressed3DBorder(g, x, y, w, h);
/* 482:    */     }
/* 483:    */     
/* 484:    */     public Insets getBorderInsets(Component c)
/* 485:    */     {
/* 486:535 */       return INSETS;
/* 487:    */     }
/* 488:    */     
/* 489:    */     private ThinLoweredBorder() {}
/* 490:    */   }
/* 491:    */   
/* 492:    */   private static final class EtchedBorder
/* 493:    */     extends AbstractBorder
/* 494:    */     implements UIResource
/* 495:    */   {
/* 496:    */     EtchedBorder(PlasticBorders.1 x0)
/* 497:    */     {
/* 498:545 */       this();
/* 499:    */     }
/* 500:    */     
/* 501:547 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 502:    */     
/* 503:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 504:    */     {
/* 505:550 */       PlasticUtils.drawThinPressed3DBorder(g, x, y, w, h);
/* 506:551 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y + 1, w - 2, h - 2);
/* 507:    */     }
/* 508:    */     
/* 509:    */     public Insets getBorderInsets(Component c)
/* 510:    */     {
/* 511:554 */       return INSETS;
/* 512:    */     }
/* 513:    */     
/* 514:    */     private EtchedBorder() {}
/* 515:    */   }
/* 516:    */   
/* 517:    */   private static final class MenuBarHeaderBorder
/* 518:    */     extends AbstractBorder
/* 519:    */     implements UIResource
/* 520:    */   {
/* 521:    */     MenuBarHeaderBorder(PlasticBorders.1 x0)
/* 522:    */     {
/* 523:563 */       this();
/* 524:    */     }
/* 525:    */     
/* 526:565 */     private static final Insets INSETS = new Insets(2, 2, 1, 2);
/* 527:    */     
/* 528:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 529:    */     {
/* 530:568 */       PlasticUtils.drawThinPressed3DBorder(g, x, y, w, h + 1);
/* 531:569 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y + 1, w - 2, h - 1);
/* 532:    */     }
/* 533:    */     
/* 534:    */     public Insets getBorderInsets(Component c)
/* 535:    */     {
/* 536:572 */       return INSETS;
/* 537:    */     }
/* 538:    */     
/* 539:    */     private MenuBarHeaderBorder() {}
/* 540:    */   }
/* 541:    */   
/* 542:    */   private static final class ToolBarHeaderBorder
/* 543:    */     extends AbstractBorder
/* 544:    */     implements UIResource
/* 545:    */   {
/* 546:    */     ToolBarHeaderBorder(PlasticBorders.1 x0)
/* 547:    */     {
/* 548:581 */       this();
/* 549:    */     }
/* 550:    */     
/* 551:583 */     private static final Insets INSETS = new Insets(1, 2, 2, 2);
/* 552:    */     
/* 553:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 554:    */     {
/* 555:586 */       PlasticUtils.drawThinPressed3DBorder(g, x, y - 1, w, h + 1);
/* 556:587 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y, w - 2, h - 1);
/* 557:    */     }
/* 558:    */     
/* 559:    */     public Insets getBorderInsets(Component c)
/* 560:    */     {
/* 561:590 */       return INSETS;
/* 562:    */     }
/* 563:    */     
/* 564:    */     private ToolBarHeaderBorder() {}
/* 565:    */   }
/* 566:    */   
/* 567:    */   private static final class MenuBorder
/* 568:    */     extends AbstractBorder
/* 569:    */     implements UIResource
/* 570:    */   {
/* 571:    */     MenuBorder(PlasticBorders.1 x0)
/* 572:    */     {
/* 573:594 */       this();
/* 574:    */     }
/* 575:    */     
/* 576:595 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 577:    */     
/* 578:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 579:    */     {
/* 580:598 */       JMenuItem b = (JMenuItem)c;
/* 581:599 */       ButtonModel model = b.getModel();
/* 582:601 */       if ((model.isArmed()) || (model.isSelected()))
/* 583:    */       {
/* 584:602 */         g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 585:603 */         g.drawLine(0, 0, w - 2, 0);
/* 586:604 */         g.drawLine(0, 0, 0, h - 1);
/* 587:    */         
/* 588:    */ 
/* 589:607 */         g.setColor(PlasticLookAndFeel.getPrimaryControlHighlight());
/* 590:608 */         g.drawLine(w - 1, 0, w - 1, h - 1);
/* 591:    */       }
/* 592:609 */       else if (model.isRollover())
/* 593:    */       {
/* 594:610 */         g.translate(x, y);
/* 595:611 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 596:612 */         g.translate(-x, -y);
/* 597:    */       }
/* 598:    */     }
/* 599:    */     
/* 600:    */     public Insets getBorderInsets(Component c)
/* 601:    */     {
/* 602:616 */       return INSETS;
/* 603:    */     }
/* 604:    */     
/* 605:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 606:    */     {
/* 607:619 */       newInsets.top = INSETS.top;
/* 608:620 */       newInsets.left = INSETS.left;
/* 609:621 */       newInsets.bottom = INSETS.bottom;
/* 610:622 */       newInsets.right = INSETS.right;
/* 611:623 */       return newInsets;
/* 612:    */     }
/* 613:    */     
/* 614:    */     private MenuBorder() {}
/* 615:    */   }
/* 616:    */   
/* 617:    */   private static final class PopupMenuBorder
/* 618:    */     extends AbstractBorder
/* 619:    */     implements UIResource
/* 620:    */   {
/* 621:    */     PopupMenuBorder(PlasticBorders.1 x0)
/* 622:    */     {
/* 623:628 */       this();
/* 624:    */     }
/* 625:    */     
/* 626:629 */     private static final Insets INSETS = new Insets(3, 3, 3, 3);
/* 627:    */     
/* 628:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 629:    */     {
/* 630:632 */       g.translate(x, y);
/* 631:633 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 632:634 */       g.drawRect(0, 0, w - 1, h - 1);
/* 633:635 */       g.setColor(PlasticLookAndFeel.getMenuItemBackground());
/* 634:636 */       g.drawRect(1, 1, w - 3, h - 3);
/* 635:637 */       g.drawRect(2, 2, w - 5, h - 5);
/* 636:638 */       g.translate(-x, -y);
/* 637:    */     }
/* 638:    */     
/* 639:    */     public Insets getBorderInsets(Component c)
/* 640:    */     {
/* 641:641 */       return INSETS;
/* 642:    */     }
/* 643:    */     
/* 644:    */     private PopupMenuBorder() {}
/* 645:    */   }
/* 646:    */   
/* 647:    */   private static final class NoMarginPopupMenuBorder
/* 648:    */     extends AbstractBorder
/* 649:    */     implements UIResource
/* 650:    */   {
/* 651:    */     NoMarginPopupMenuBorder(PlasticBorders.1 x0)
/* 652:    */     {
/* 653:645 */       this();
/* 654:    */     }
/* 655:    */     
/* 656:646 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 657:    */     
/* 658:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 659:    */     {
/* 660:649 */       g.translate(x, y);
/* 661:650 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 662:651 */       g.drawRect(0, 0, w - 1, h - 1);
/* 663:652 */       g.translate(-x, -y);
/* 664:    */     }
/* 665:    */     
/* 666:    */     public Insets getBorderInsets(Component c)
/* 667:    */     {
/* 668:655 */       return INSETS;
/* 669:    */     }
/* 670:    */     
/* 671:    */     private NoMarginPopupMenuBorder() {}
/* 672:    */   }
/* 673:    */   
/* 674:    */   private static class RolloverButtonBorder
/* 675:    */     extends PlasticBorders.ButtonBorder
/* 676:    */   {
/* 677:    */     RolloverButtonBorder(PlasticBorders.1 x0)
/* 678:    */     {
/* 679:659 */       this();
/* 680:    */     }
/* 681:    */     
/* 682:    */     private RolloverButtonBorder()
/* 683:    */     {
/* 684:662 */       super();
/* 685:    */     }
/* 686:    */     
/* 687:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 688:    */     {
/* 689:666 */       AbstractButton b = (AbstractButton)c;
/* 690:667 */       ButtonModel model = b.getModel();
/* 691:669 */       if (!model.isEnabled()) {
/* 692:670 */         return;
/* 693:    */       }
/* 694:672 */       if (!(c instanceof JToggleButton))
/* 695:    */       {
/* 696:673 */         if ((model.isRollover()) && ((!model.isPressed()) || (model.isArmed()))) {
/* 697:674 */           super.paintBorder(c, g, x, y, w, h);
/* 698:    */         }
/* 699:676 */         return;
/* 700:    */       }
/* 701:683 */       if (model.isRollover())
/* 702:    */       {
/* 703:684 */         if ((model.isPressed()) && (model.isArmed())) {
/* 704:685 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 705:    */         } else {
/* 706:687 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 707:    */         }
/* 708:    */       }
/* 709:689 */       else if (model.isSelected()) {
/* 710:690 */         PlasticUtils.drawDark3DBorder(g, x, y, w, h);
/* 711:    */       }
/* 712:    */     }
/* 713:    */   }
/* 714:    */   
/* 715:    */   static final class RolloverMarginBorder
/* 716:    */     extends EmptyBorder
/* 717:    */   {
/* 718:    */     RolloverMarginBorder()
/* 719:    */     {
/* 720:702 */       super(1, 1, 1);
/* 721:    */     }
/* 722:    */     
/* 723:    */     public Insets getBorderInsets(Component c)
/* 724:    */     {
/* 725:707 */       return getBorderInsets(c, new Insets(0, 0, 0, 0));
/* 726:    */     }
/* 727:    */     
/* 728:    */     public Insets getBorderInsets(Component c, Insets insets)
/* 729:    */     {
/* 730:712 */       Insets margin = null;
/* 731:714 */       if ((c instanceof AbstractButton)) {
/* 732:715 */         margin = ((AbstractButton)c).getMargin();
/* 733:    */       }
/* 734:717 */       if ((margin == null) || ((margin instanceof UIResource)))
/* 735:    */       {
/* 736:719 */         insets.left = this.left;
/* 737:720 */         insets.top = this.top;
/* 738:721 */         insets.right = this.right;
/* 739:722 */         insets.bottom = this.bottom;
/* 740:    */       }
/* 741:    */       else
/* 742:    */       {
/* 743:725 */         insets.left = margin.left;
/* 744:726 */         insets.top = margin.top;
/* 745:727 */         insets.right = margin.right;
/* 746:728 */         insets.bottom = margin.bottom;
/* 747:    */       }
/* 748:730 */       return insets;
/* 749:    */     }
/* 750:    */   }
/* 751:    */   
/* 752:    */   private static final class ScrollPaneBorder
/* 753:    */     extends MetalBorders.ScrollPaneBorder
/* 754:    */   {
/* 755:    */     ScrollPaneBorder(PlasticBorders.1 x0)
/* 756:    */     {
/* 757:739 */       this();
/* 758:    */     }
/* 759:    */     
/* 760:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 761:    */     {
/* 762:742 */       g.translate(x, y);
/* 763:    */       
/* 764:744 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 765:745 */       g.drawRect(0, 0, w - 2, h - 2);
/* 766:746 */       g.setColor(PlasticLookAndFeel.getControlHighlight());
/* 767:747 */       g.drawLine(w - 1, 0, w - 1, h - 1);
/* 768:748 */       g.drawLine(0, h - 1, w - 1, h - 1);
/* 769:    */       
/* 770:750 */       g.translate(-x, -y);
/* 771:    */     }
/* 772:    */     
/* 773:    */     private ScrollPaneBorder() {}
/* 774:    */   }
/* 775:    */   
/* 776:    */   private static final class TextFieldBorder
/* 777:    */     extends PlasticBorders.Flush3DBorder
/* 778:    */   {
/* 779:    */     TextFieldBorder(PlasticBorders.1 x0)
/* 780:    */     {
/* 781:755 */       this();
/* 782:    */     }
/* 783:    */     
/* 784:    */     private TextFieldBorder()
/* 785:    */     {
/* 786:755 */       super();
/* 787:    */     }
/* 788:    */     
/* 789:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 790:    */     {
/* 791:758 */       if (!(c instanceof JTextComponent))
/* 792:    */       {
/* 793:760 */         if (c.isEnabled()) {
/* 794:761 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 795:    */         } else {
/* 796:763 */           PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/* 797:    */         }
/* 798:765 */         return;
/* 799:    */       }
/* 800:768 */       if ((c.isEnabled()) && (((JTextComponent)c).isEditable())) {
/* 801:769 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 802:    */       } else {
/* 803:771 */         PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/* 804:    */       }
/* 805:    */     }
/* 806:    */   }
/* 807:    */   
/* 808:    */   private static final class ToggleButtonBorder
/* 809:    */     extends PlasticBorders.ButtonBorder
/* 810:    */   {
/* 811:    */     ToggleButtonBorder(Insets x0, PlasticBorders.1 x1)
/* 812:    */     {
/* 813:776 */       this(x0);
/* 814:    */     }
/* 815:    */     
/* 816:    */     private ToggleButtonBorder(Insets insets)
/* 817:    */     {
/* 818:779 */       super();
/* 819:    */     }
/* 820:    */     
/* 821:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 822:    */     {
/* 823:783 */       if (!c.isEnabled())
/* 824:    */       {
/* 825:784 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/* 826:    */       }
/* 827:    */       else
/* 828:    */       {
/* 829:786 */         AbstractButton button = (AbstractButton)c;
/* 830:787 */         ButtonModel model = button.getModel();
/* 831:788 */         if ((model.isPressed()) && (model.isArmed())) {
/* 832:789 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 833:790 */         } else if (model.isSelected()) {
/* 834:791 */           PlasticUtils.drawDark3DBorder(g, x, y, w, h);
/* 835:    */         } else {
/* 836:793 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 837:    */         }
/* 838:    */       }
/* 839:    */     }
/* 840:    */   }
/* 841:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticBorders
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.common.ExtBasicArrowButtonHandler;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import javax.swing.ButtonModel;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ import javax.swing.UIManager;
/*  10:    */ import javax.swing.plaf.ComponentUI;
/*  11:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  12:    */ 
/*  13:    */ public final class PlasticXPSpinnerUI
/*  14:    */   extends PlasticSpinnerUI
/*  15:    */ {
/*  16:    */   public static ComponentUI createUI(JComponent b)
/*  17:    */   {
/*  18: 57 */     return new PlasticXPSpinnerUI();
/*  19:    */   }
/*  20:    */   
/*  21: 69 */   private static final ExtBasicArrowButtonHandler NEXT_BUTTON_HANDLER = new ExtBasicArrowButtonHandler("increment", true);
/*  22: 71 */   private static final ExtBasicArrowButtonHandler PREVIOUS_BUTTON_HANDLER = new ExtBasicArrowButtonHandler("decrement", false);
/*  23:    */   
/*  24:    */   protected Component createPreviousButton()
/*  25:    */   {
/*  26: 89 */     return new SpinnerXPArrowButton(5, PREVIOUS_BUTTON_HANDLER);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected Component createNextButton()
/*  30:    */   {
/*  31:107 */     return new SpinnerXPArrowButton(1, NEXT_BUTTON_HANDLER);
/*  32:    */   }
/*  33:    */   
/*  34:    */   private static final class SpinnerXPArrowButton
/*  35:    */     extends PlasticArrowButton
/*  36:    */   {
/*  37:    */     SpinnerXPArrowButton(int direction, ExtBasicArrowButtonHandler handler)
/*  38:    */     {
/*  39:120 */       super(UIManager.getInt("ScrollBar.width") - 1, false);
/*  40:121 */       addActionListener(handler);
/*  41:122 */       addMouseListener(handler);
/*  42:    */     }
/*  43:    */     
/*  44:    */     protected int calculateArrowHeight(int height, int width)
/*  45:    */     {
/*  46:126 */       int arrowHeight = Math.min((height - 4) / 3, (width - 4) / 3);
/*  47:127 */       return Math.max(arrowHeight, 3);
/*  48:    */     }
/*  49:    */     
/*  50:    */     protected boolean isPaintingNorthBottom()
/*  51:    */     {
/*  52:131 */       return true;
/*  53:    */     }
/*  54:    */     
/*  55:    */     protected int calculateArrowOffset()
/*  56:    */     {
/*  57:135 */       return 1;
/*  58:    */     }
/*  59:    */     
/*  60:    */     protected void paintNorth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset, boolean paintBottom)
/*  61:    */     {
/*  62:142 */       if (!this.isFreeStanding)
/*  63:    */       {
/*  64:143 */         height++;
/*  65:144 */         g.translate(0, -1);
/*  66:145 */         if (!leftToRight)
/*  67:    */         {
/*  68:146 */           width++;
/*  69:147 */           g.translate(-1, 0);
/*  70:    */         }
/*  71:    */         else
/*  72:    */         {
/*  73:149 */           width += 2;
/*  74:    */         }
/*  75:    */       }
/*  76:154 */       g.setColor(arrowColor);
/*  77:155 */       int startY = 1 + (h + 1 - arrowHeight) / 2;
/*  78:156 */       int startX = w / 2;
/*  79:158 */       for (int line = 0; line < arrowHeight; line++) {
/*  80:159 */         g.fillRect(startX - line - arrowOffset, startY + line, 2 * (line + 1), 1);
/*  81:    */       }
/*  82:163 */       paintNorthBorder(g, isEnabled, width, height, paintBottom);
/*  83:165 */       if (!this.isFreeStanding)
/*  84:    */       {
/*  85:166 */         height--;
/*  86:167 */         g.translate(0, 1);
/*  87:168 */         if (!leftToRight)
/*  88:    */         {
/*  89:169 */           width--;
/*  90:170 */           g.translate(1, 0);
/*  91:    */         }
/*  92:    */         else
/*  93:    */         {
/*  94:172 */           width -= 2;
/*  95:    */         }
/*  96:    */       }
/*  97:    */     }
/*  98:    */     
/*  99:    */     private void paintNorthBorder(Graphics g, boolean isEnabled, int w, int h, boolean paintBottom)
/* 100:    */     {
/* 101:178 */       if (isEnabled)
/* 102:    */       {
/* 103:179 */         boolean isPressed = (this.model.isPressed()) && (this.model.isArmed());
/* 104:180 */         if (isPressed) {
/* 105:181 */           PlasticXPUtils.drawPressedButtonBorder(g, 0, 1, w - 2, h);
/* 106:    */         } else {
/* 107:183 */           PlasticXPUtils.drawPlainButtonBorder(g, 0, 1, w - 2, h);
/* 108:    */         }
/* 109:    */       }
/* 110:    */       else
/* 111:    */       {
/* 112:186 */         PlasticXPUtils.drawDisabledButtonBorder(g, 0, 1, w - 2, h + 1);
/* 113:    */       }
/* 114:189 */       g.setColor(isEnabled ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 115:    */       
/* 116:    */ 
/* 117:192 */       g.fillRect(0, 1, 1, 1);
/* 118:194 */       if (paintBottom) {
/* 119:195 */         g.fillRect(0, h - 1, w - 1, 1);
/* 120:    */       }
/* 121:    */     }
/* 122:    */     
/* 123:    */     protected void paintSouth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset)
/* 124:    */     {
/* 125:204 */       if (!this.isFreeStanding)
/* 126:    */       {
/* 127:205 */         height++;
/* 128:206 */         if (!leftToRight)
/* 129:    */         {
/* 130:207 */           width++;
/* 131:208 */           g.translate(-1, 0);
/* 132:    */         }
/* 133:    */         else
/* 134:    */         {
/* 135:210 */           width += 2;
/* 136:    */         }
/* 137:    */       }
/* 138:215 */       g.setColor(arrowColor);
/* 139:    */       
/* 140:217 */       int startY = (h + 0 - arrowHeight) / 2 + arrowHeight - 2;
/* 141:218 */       int startX = w / 2;
/* 142:222 */       for (int line = 0; line < arrowHeight; line++) {
/* 143:223 */         g.fillRect(startX - line - arrowOffset, startY - line, 2 * (line + 1), 1);
/* 144:    */       }
/* 145:227 */       paintSouthBorder(g, isEnabled, width, height);
/* 146:229 */       if (!this.isFreeStanding)
/* 147:    */       {
/* 148:230 */         height--;
/* 149:231 */         if (!leftToRight)
/* 150:    */         {
/* 151:232 */           width--;
/* 152:233 */           g.translate(1, 0);
/* 153:    */         }
/* 154:    */         else
/* 155:    */         {
/* 156:235 */           width -= 2;
/* 157:    */         }
/* 158:    */       }
/* 159:    */     }
/* 160:    */     
/* 161:    */     private void paintSouthBorder(Graphics g, boolean isEnabled, int w, int h)
/* 162:    */     {
/* 163:241 */       if (isEnabled)
/* 164:    */       {
/* 165:242 */         boolean isPressed = (this.model.isPressed()) && (this.model.isArmed());
/* 166:243 */         if (isPressed) {
/* 167:244 */           PlasticXPUtils.drawPressedButtonBorder(g, 0, -2, w - 2, h + 1);
/* 168:    */         } else {
/* 169:246 */           PlasticXPUtils.drawPlainButtonBorder(g, 0, -2, w - 2, h + 1);
/* 170:    */         }
/* 171:    */       }
/* 172:    */       else
/* 173:    */       {
/* 174:249 */         PlasticXPUtils.drawDisabledButtonBorder(g, 0, -2, w - 2, h + 1);
/* 175:    */       }
/* 176:252 */       g.setColor(isEnabled ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 177:    */       
/* 178:    */ 
/* 179:255 */       g.fillRect(0, h - 2, 1, 1);
/* 180:    */     }
/* 181:    */   }
/* 182:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPSpinnerUI
 * JD-Core Version:    0.7.0.1
 */
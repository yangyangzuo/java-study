/*  1:   */ package com.jgoodies.looks.plastic.theme;
/*  2:   */ 
/*  3:   */ public class SkyBlue
/*  4:   */   extends AbstractSkyTheme
/*  5:   */ {
/*  6:   */   public String getName()
/*  7:   */   {
/*  8:43 */     return "Sky Blue";
/*  9:   */   }
/* 10:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.theme.SkyBlue
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.FontMetrics;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.Rectangle;
/*   9:    */ import javax.swing.Icon;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JInternalFrame;
/*  12:    */ import javax.swing.SwingUtilities;
/*  13:    */ import javax.swing.plaf.metal.MetalInternalFrameTitlePane;
/*  14:    */ 
/*  15:    */ public final class PlasticInternalFrameTitlePane
/*  16:    */   extends MetalInternalFrameTitlePane
/*  17:    */ {
/*  18:    */   private PlasticBumps paletteBumps;
/*  19: 55 */   private final PlasticBumps activeBumps = new PlasticBumps(0, 0, PlasticLookAndFeel.getPrimaryControlHighlight(), PlasticLookAndFeel.getPrimaryControlDarkShadow(), PlasticLookAndFeel.getPrimaryControl());
/*  20: 63 */   private final PlasticBumps inactiveBumps = new PlasticBumps(0, 0, PlasticLookAndFeel.getControlHighlight(), PlasticLookAndFeel.getControlDarkShadow(), PlasticLookAndFeel.getControl());
/*  21:    */   
/*  22:    */   public PlasticInternalFrameTitlePane(JInternalFrame frame)
/*  23:    */   {
/*  24: 72 */     super(frame);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void paintPalette(Graphics g)
/*  28:    */   {
/*  29: 76 */     boolean leftToRight = PlasticUtils.isLeftToRight(this.frame);
/*  30:    */     
/*  31: 78 */     int width = getWidth();
/*  32: 79 */     int height = getHeight();
/*  33: 81 */     if (this.paletteBumps == null) {
/*  34: 82 */       this.paletteBumps = new PlasticBumps(0, 0, PlasticLookAndFeel.getPrimaryControlHighlight(), PlasticLookAndFeel.getPrimaryControlInfo(), PlasticLookAndFeel.getPrimaryControlShadow());
/*  35:    */     }
/*  36: 91 */     Color background = PlasticLookAndFeel.getPrimaryControlShadow();
/*  37: 92 */     Color darkShadow = PlasticLookAndFeel.getControlDarkShadow();
/*  38:    */     
/*  39: 94 */     g.setColor(background);
/*  40: 95 */     g.fillRect(0, 0, width, height);
/*  41:    */     
/*  42: 97 */     g.setColor(darkShadow);
/*  43: 98 */     g.drawLine(0, height - 1, width, height - 1);
/*  44:    */     
/*  45:100 */     int buttonsWidth = getButtonsWidth();
/*  46:101 */     int xOffset = leftToRight ? 4 : buttonsWidth + 4;
/*  47:102 */     int bumpLength = width - buttonsWidth - 8;
/*  48:103 */     int bumpHeight = getHeight() - 4;
/*  49:104 */     this.paletteBumps.setBumpArea(bumpLength, bumpHeight);
/*  50:105 */     this.paletteBumps.paintIcon(this, g, xOffset, 2);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void paintComponent(Graphics g)
/*  54:    */   {
/*  55:109 */     if (this.isPalette)
/*  56:    */     {
/*  57:110 */       paintPalette(g);
/*  58:111 */       return;
/*  59:    */     }
/*  60:114 */     boolean leftToRight = PlasticUtils.isLeftToRight(this.frame);
/*  61:115 */     boolean isSelected = this.frame.isSelected();
/*  62:    */     
/*  63:117 */     int width = getWidth();
/*  64:118 */     int height = getHeight();
/*  65:    */     
/*  66:120 */     Color background = null;
/*  67:121 */     Color foreground = null;
/*  68:122 */     Color shadow = null;
/*  69:    */     PlasticBumps bumps;
/*  70:    */     PlasticBumps bumps;
/*  71:126 */     if (isSelected)
/*  72:    */     {
/*  73:127 */       background = PlasticLookAndFeel.getWindowTitleBackground();
/*  74:128 */       foreground = PlasticLookAndFeel.getWindowTitleForeground();
/*  75:129 */       bumps = this.activeBumps;
/*  76:    */     }
/*  77:    */     else
/*  78:    */     {
/*  79:131 */       background = PlasticLookAndFeel.getWindowTitleInactiveBackground();
/*  80:132 */       foreground = PlasticLookAndFeel.getWindowTitleInactiveForeground();
/*  81:133 */       bumps = this.inactiveBumps;
/*  82:    */     }
/*  83:136 */     shadow = PlasticLookAndFeel.getControlDarkShadow();
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:169 */     g.setColor(background);
/* 117:170 */     g.fillRect(0, 0, width, height);
/* 118:    */     
/* 119:172 */     g.setColor(shadow);
/* 120:173 */     g.drawLine(0, height - 1, width, height - 1);
/* 121:174 */     g.drawLine(0, 0, 0, 0);
/* 122:175 */     g.drawLine(width - 1, 0, width - 1, 0);
/* 123:    */     
/* 124:177 */     int titleLength = 0;
/* 125:178 */     int xOffset = leftToRight ? 5 : width - 5;
/* 126:179 */     String frameTitle = this.frame.getTitle();
/* 127:    */     
/* 128:181 */     Icon icon = this.frame.getFrameIcon();
/* 129:182 */     if (icon != null)
/* 130:    */     {
/* 131:183 */       if (!leftToRight) {
/* 132:184 */         xOffset -= icon.getIconWidth();
/* 133:    */       }
/* 134:185 */       int iconY = height / 2 - icon.getIconHeight() / 2;
/* 135:186 */       icon.paintIcon(this.frame, g, xOffset, iconY);
/* 136:187 */       xOffset += (leftToRight ? icon.getIconWidth() + 5 : -5);
/* 137:    */     }
/* 138:190 */     if (frameTitle != null)
/* 139:    */     {
/* 140:191 */       Font f = getFont();
/* 141:192 */       g.setFont(f);
/* 142:193 */       FontMetrics fm = g.getFontMetrics();
/* 143:    */       
/* 144:    */ 
/* 145:196 */       g.setColor(foreground);
/* 146:    */       
/* 147:198 */       int yOffset = (height - fm.getHeight()) / 2 + fm.getAscent();
/* 148:    */       
/* 149:200 */       Rectangle rect = new Rectangle(0, 0, 0, 0);
/* 150:201 */       if (this.frame.isIconifiable()) {
/* 151:202 */         rect = this.iconButton.getBounds();
/* 152:203 */       } else if (this.frame.isMaximizable()) {
/* 153:204 */         rect = this.maxButton.getBounds();
/* 154:205 */       } else if (this.frame.isClosable()) {
/* 155:206 */         rect = this.closeButton.getBounds();
/* 156:    */       }
/* 157:210 */       if (leftToRight)
/* 158:    */       {
/* 159:211 */         if (rect.x == 0) {
/* 160:212 */           rect.x = (this.frame.getWidth() - this.frame.getInsets().right - 2);
/* 161:    */         }
/* 162:214 */         int titleW = rect.x - xOffset - 4;
/* 163:215 */         frameTitle = getTitle(frameTitle, fm, titleW);
/* 164:    */       }
/* 165:    */       else
/* 166:    */       {
/* 167:217 */         int titleW = xOffset - rect.x - rect.width - 4;
/* 168:218 */         frameTitle = getTitle(frameTitle, fm, titleW);
/* 169:219 */         xOffset -= SwingUtilities.computeStringWidth(fm, frameTitle);
/* 170:    */       }
/* 171:222 */       titleLength = SwingUtilities.computeStringWidth(fm, frameTitle);
/* 172:223 */       g.drawString(frameTitle, xOffset, yOffset);
/* 173:224 */       xOffset += (leftToRight ? titleLength + 5 : -5);
/* 174:    */     }
/* 175:229 */     int buttonsWidth = getButtonsWidth();
/* 176:    */     int bumpXOffset;
/* 177:    */     int bumpLength;
/* 178:    */     int bumpXOffset;
/* 179:230 */     if (leftToRight)
/* 180:    */     {
/* 181:231 */       int bumpLength = width - buttonsWidth - xOffset - 5;
/* 182:232 */       bumpXOffset = xOffset;
/* 183:    */     }
/* 184:    */     else
/* 185:    */     {
/* 186:234 */       bumpLength = xOffset - buttonsWidth - 5;
/* 187:235 */       bumpXOffset = buttonsWidth + 5;
/* 188:    */     }
/* 189:237 */     int bumpYOffset = 3;
/* 190:238 */     int bumpHeight = getHeight() - 2 * bumpYOffset;
/* 191:239 */     bumps.setBumpArea(bumpLength, bumpHeight);
/* 192:240 */     bumps.paintIcon(this, g, bumpXOffset, bumpYOffset);
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected String getTitle(String text, FontMetrics fm, int availTextWidth)
/* 196:    */   {
/* 197:247 */     if ((text == null) || (text.equals(""))) {
/* 198:248 */       return "";
/* 199:    */     }
/* 200:249 */     int textWidth = SwingUtilities.computeStringWidth(fm, text);
/* 201:250 */     String clipString = "...";
/* 202:251 */     if (textWidth > availTextWidth)
/* 203:    */     {
/* 204:252 */       int totalWidth = SwingUtilities.computeStringWidth(fm, clipString);
/* 205:254 */       for (int nChars = 0; nChars < text.length(); nChars++)
/* 206:    */       {
/* 207:255 */         totalWidth += fm.charWidth(text.charAt(nChars));
/* 208:256 */         if (totalWidth > availTextWidth) {
/* 209:    */           break;
/* 210:    */         }
/* 211:    */       }
/* 212:260 */       text = text.substring(0, nChars) + clipString;
/* 213:    */     }
/* 214:262 */     return text;
/* 215:    */   }
/* 216:    */   
/* 217:    */   private int getButtonsWidth()
/* 218:    */   {
/* 219:266 */     boolean leftToRight = PlasticUtils.isLeftToRight(this.frame);
/* 220:    */     
/* 221:268 */     int w = getWidth();
/* 222:269 */     int x = leftToRight ? w : 0;
/* 223:    */     
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:274 */     int buttonWidth = this.closeButton.getIcon().getIconWidth();
/* 228:276 */     if (this.frame.isClosable()) {
/* 229:277 */       if (this.isPalette)
/* 230:    */       {
/* 231:278 */         int spacing = 3;
/* 232:279 */         x += (leftToRight ? -spacing - (buttonWidth + 2) : spacing);
/* 233:280 */         if (!leftToRight) {
/* 234:281 */           x += buttonWidth + 2;
/* 235:    */         }
/* 236:    */       }
/* 237:    */       else
/* 238:    */       {
/* 239:283 */         int spacing = 4;
/* 240:284 */         x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 241:285 */         if (!leftToRight) {
/* 242:286 */           x += buttonWidth;
/* 243:    */         }
/* 244:    */       }
/* 245:    */     }
/* 246:290 */     if ((this.frame.isMaximizable()) && (!this.isPalette))
/* 247:    */     {
/* 248:291 */       int spacing = this.frame.isClosable() ? 10 : 4;
/* 249:292 */       x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 250:293 */       if (!leftToRight) {
/* 251:294 */         x += buttonWidth;
/* 252:    */       }
/* 253:    */     }
/* 254:297 */     if ((this.frame.isIconifiable()) && (!this.isPalette))
/* 255:    */     {
/* 256:298 */       int spacing = this.frame.isClosable() ? 10 : this.frame.isMaximizable() ? 2 : 4;
/* 257:    */       
/* 258:300 */       x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 259:301 */       if (!leftToRight) {
/* 260:302 */         x += buttonWidth;
/* 261:    */       }
/* 262:    */     }
/* 263:305 */     return leftToRight ? w - x : x;
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticInternalFrameTitlePane
 * JD-Core Version:    0.7.0.1
 */
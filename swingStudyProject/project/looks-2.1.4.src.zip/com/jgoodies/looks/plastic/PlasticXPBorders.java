/*   1:    */ package com.jgoodies.looks.plastic;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.awt.Insets;
/*   6:    */ import javax.swing.AbstractButton;
/*   7:    */ import javax.swing.ButtonModel;
/*   8:    */ import javax.swing.JButton;
/*   9:    */ import javax.swing.JComboBox;
/*  10:    */ import javax.swing.JToggleButton;
/*  11:    */ import javax.swing.UIManager;
/*  12:    */ import javax.swing.border.AbstractBorder;
/*  13:    */ import javax.swing.border.Border;
/*  14:    */ import javax.swing.border.CompoundBorder;
/*  15:    */ import javax.swing.plaf.BorderUIResource.CompoundBorderUIResource;
/*  16:    */ import javax.swing.plaf.UIResource;
/*  17:    */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*  18:    */ import javax.swing.plaf.metal.MetalBorders.ScrollPaneBorder;
/*  19:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  20:    */ import javax.swing.text.JTextComponent;
/*  21:    */ 
/*  22:    */ final class PlasticXPBorders
/*  23:    */ {
/*  24:    */   private static Border comboBoxArrowButtonBorder;
/*  25:    */   private static Border comboBoxEditorBorder;
/*  26:    */   private static Border scrollPaneBorder;
/*  27:    */   private static Border textFieldBorder;
/*  28:    */   private static Border spinnerBorder;
/*  29:    */   private static Border rolloverButtonBorder;
/*  30:    */   
/*  31:    */   static Border getButtonBorder(Insets buttonMargin)
/*  32:    */   {
/*  33: 79 */     return new BorderUIResource.CompoundBorderUIResource(new XPButtonBorder(buttonMargin), new BasicBorders.MarginBorder());
/*  34:    */   }
/*  35:    */   
/*  36:    */   static Border getComboBoxArrowButtonBorder()
/*  37:    */   {
/*  38: 88 */     if (comboBoxArrowButtonBorder == null) {
/*  39: 89 */       comboBoxArrowButtonBorder = new CompoundBorder(new XPComboBoxArrowButtonBorder(null), new BasicBorders.MarginBorder());
/*  40:    */     }
/*  41: 93 */     return comboBoxArrowButtonBorder;
/*  42:    */   }
/*  43:    */   
/*  44:    */   static Border getComboBoxEditorBorder()
/*  45:    */   {
/*  46:100 */     if (comboBoxEditorBorder == null) {
/*  47:101 */       comboBoxEditorBorder = new CompoundBorder(new XPComboBoxEditorBorder(null), new BasicBorders.MarginBorder());
/*  48:    */     }
/*  49:105 */     return comboBoxEditorBorder;
/*  50:    */   }
/*  51:    */   
/*  52:    */   static Border getScrollPaneBorder()
/*  53:    */   {
/*  54:112 */     if (scrollPaneBorder == null) {
/*  55:113 */       scrollPaneBorder = new XPScrollPaneBorder(null);
/*  56:    */     }
/*  57:115 */     return scrollPaneBorder;
/*  58:    */   }
/*  59:    */   
/*  60:    */   static Border getTextFieldBorder()
/*  61:    */   {
/*  62:122 */     if (textFieldBorder == null) {
/*  63:123 */       textFieldBorder = new BorderUIResource.CompoundBorderUIResource(new XPTextFieldBorder(null), new BasicBorders.MarginBorder());
/*  64:    */     }
/*  65:127 */     return textFieldBorder;
/*  66:    */   }
/*  67:    */   
/*  68:    */   static Border getToggleButtonBorder(Insets buttonMargin)
/*  69:    */   {
/*  70:134 */     return new BorderUIResource.CompoundBorderUIResource(new XPButtonBorder(buttonMargin), new BasicBorders.MarginBorder());
/*  71:    */   }
/*  72:    */   
/*  73:    */   static Border getSpinnerBorder()
/*  74:    */   {
/*  75:143 */     if (spinnerBorder == null) {
/*  76:144 */       spinnerBorder = new XPSpinnerBorder(null);
/*  77:    */     }
/*  78:146 */     return spinnerBorder;
/*  79:    */   }
/*  80:    */   
/*  81:    */   static Border getRolloverButtonBorder()
/*  82:    */   {
/*  83:156 */     if (rolloverButtonBorder == null) {
/*  84:157 */       rolloverButtonBorder = new CompoundBorder(new RolloverButtonBorder(null), new PlasticBorders.RolloverMarginBorder());
/*  85:    */     }
/*  86:161 */     return rolloverButtonBorder;
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static class XPButtonBorder
/*  90:    */     extends AbstractBorder
/*  91:    */     implements UIResource
/*  92:    */   {
/*  93:    */     protected final Insets insets;
/*  94:    */     
/*  95:    */     protected XPButtonBorder(Insets insets)
/*  96:    */     {
/*  97:172 */       this.insets = insets;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 101:    */     {
/* 102:176 */       AbstractButton button = (AbstractButton)c;
/* 103:177 */       ButtonModel model = button.getModel();
/* 104:179 */       if (!model.isEnabled())
/* 105:    */       {
/* 106:180 */         PlasticXPUtils.drawDisabledButtonBorder(g, x, y, w, h);
/* 107:181 */         return;
/* 108:    */       }
/* 109:184 */       boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 110:185 */       boolean isDefault = ((button instanceof JButton)) && (((JButton)button).isDefaultButton());
/* 111:    */       
/* 112:187 */       boolean isFocused = (button.isFocusPainted()) && (button.hasFocus());
/* 113:189 */       if (isPressed) {
/* 114:190 */         PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 115:191 */       } else if (isFocused) {
/* 116:192 */         PlasticXPUtils.drawFocusedButtonBorder(g, x, y, w, h);
/* 117:193 */       } else if (isDefault) {
/* 118:194 */         PlasticXPUtils.drawDefaultButtonBorder(g, x, y, w, h);
/* 119:    */       } else {
/* 120:196 */         PlasticXPUtils.drawPlainButtonBorder(g, x, y, w, h);
/* 121:    */       }
/* 122:    */     }
/* 123:    */     
/* 124:    */     public Insets getBorderInsets(Component c)
/* 125:    */     {
/* 126:199 */       return this.insets;
/* 127:    */     }
/* 128:    */     
/* 129:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 130:    */     {
/* 131:202 */       newInsets.top = this.insets.top;
/* 132:203 */       newInsets.left = this.insets.left;
/* 133:204 */       newInsets.bottom = this.insets.bottom;
/* 134:205 */       newInsets.right = this.insets.right;
/* 135:206 */       return newInsets;
/* 136:    */     }
/* 137:    */   }
/* 138:    */   
/* 139:    */   private static final class XPComboBoxArrowButtonBorder
/* 140:    */     extends AbstractBorder
/* 141:    */     implements UIResource
/* 142:    */   {
/* 143:    */     XPComboBoxArrowButtonBorder(PlasticXPBorders.1 x0)
/* 144:    */     {
/* 145:214 */       this();
/* 146:    */     }
/* 147:    */     
/* 148:216 */     protected static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 149:    */     
/* 150:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 151:    */     {
/* 152:219 */       PlasticComboBoxButton button = (PlasticComboBoxButton)c;
/* 153:220 */       JComboBox comboBox = button.getComboBox();
/* 154:221 */       ButtonModel model = button.getModel();
/* 155:223 */       if (!model.isEnabled())
/* 156:    */       {
/* 157:224 */         PlasticXPUtils.drawDisabledButtonBorder(g, x, y, w, h);
/* 158:    */       }
/* 159:    */       else
/* 160:    */       {
/* 161:226 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 162:227 */         boolean isFocused = comboBox.hasFocus();
/* 163:228 */         if (isPressed) {
/* 164:229 */           PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 165:230 */         } else if (isFocused) {
/* 166:231 */           PlasticXPUtils.drawFocusedButtonBorder(g, x, y, w, h);
/* 167:    */         } else {
/* 168:233 */           PlasticXPUtils.drawPlainButtonBorder(g, x, y, w, h);
/* 169:    */         }
/* 170:    */       }
/* 171:235 */       if (comboBox.isEditable())
/* 172:    */       {
/* 173:237 */         g.setColor(model.isEnabled() ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 174:    */         
/* 175:    */ 
/* 176:240 */         g.fillRect(x, y, 1, 1);
/* 177:241 */         g.fillRect(x, y + h - 1, 1, 1);
/* 178:    */       }
/* 179:    */     }
/* 180:    */     
/* 181:    */     public Insets getBorderInsets(Component c)
/* 182:    */     {
/* 183:245 */       return INSETS;
/* 184:    */     }
/* 185:    */     
/* 186:    */     private XPComboBoxArrowButtonBorder() {}
/* 187:    */   }
/* 188:    */   
/* 189:    */   private static final class XPComboBoxEditorBorder
/* 190:    */     extends AbstractBorder
/* 191:    */   {
/* 192:    */     XPComboBoxEditorBorder(PlasticXPBorders.1 x0)
/* 193:    */     {
/* 194:252 */       this();
/* 195:    */     }
/* 196:    */     
/* 197:254 */     private static final Insets INSETS = new Insets(1, 1, 1, 0);
/* 198:    */     
/* 199:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 200:    */     {
/* 201:257 */       g.setColor(c.isEnabled() ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 202:    */       
/* 203:    */ 
/* 204:260 */       PlasticXPUtils.drawRect(g, x, y, w + 1, h - 1);
/* 205:    */     }
/* 206:    */     
/* 207:    */     public Insets getBorderInsets(Component c)
/* 208:    */     {
/* 209:263 */       return INSETS;
/* 210:    */     }
/* 211:    */     
/* 212:    */     private XPComboBoxEditorBorder() {}
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static final class XPTextFieldBorder
/* 216:    */     extends AbstractBorder
/* 217:    */   {
/* 218:    */     XPTextFieldBorder(PlasticXPBorders.1 x0)
/* 219:    */     {
/* 220:270 */       this();
/* 221:    */     }
/* 222:    */     
/* 223:272 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 224:    */     
/* 225:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 226:    */     {
/* 227:276 */       boolean enabled = (((c instanceof JTextComponent)) && (c.isEnabled()) && (((JTextComponent)c).isEditable())) || (c.isEnabled());
/* 228:    */       
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:281 */       g.setColor(enabled ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 233:    */       
/* 234:    */ 
/* 235:284 */       PlasticXPUtils.drawRect(g, x, y, w - 1, h - 1);
/* 236:    */     }
/* 237:    */     
/* 238:    */     public Insets getBorderInsets(Component c)
/* 239:    */     {
/* 240:287 */       return INSETS;
/* 241:    */     }
/* 242:    */     
/* 243:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 244:    */     {
/* 245:290 */       newInsets.top = INSETS.top;
/* 246:291 */       newInsets.left = INSETS.left;
/* 247:292 */       newInsets.bottom = INSETS.bottom;
/* 248:293 */       newInsets.right = INSETS.right;
/* 249:294 */       return newInsets;
/* 250:    */     }
/* 251:    */     
/* 252:    */     private XPTextFieldBorder() {}
/* 253:    */   }
/* 254:    */   
/* 255:    */   private static final class XPScrollPaneBorder
/* 256:    */     extends MetalBorders.ScrollPaneBorder
/* 257:    */   {
/* 258:    */     XPScrollPaneBorder(PlasticXPBorders.1 x0)
/* 259:    */     {
/* 260:304 */       this();
/* 261:    */     }
/* 262:    */     
/* 263:306 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 264:    */     
/* 265:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 266:    */     {
/* 267:309 */       g.setColor(c.isEnabled() ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 268:    */       
/* 269:    */ 
/* 270:312 */       PlasticXPUtils.drawRect(g, x, y, w - 1, h - 1);
/* 271:    */     }
/* 272:    */     
/* 273:    */     public Insets getBorderInsets(Component c)
/* 274:    */     {
/* 275:315 */       return INSETS;
/* 276:    */     }
/* 277:    */     
/* 278:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 279:    */     {
/* 280:318 */       newInsets.top = INSETS.top;
/* 281:319 */       newInsets.left = INSETS.left;
/* 282:320 */       newInsets.bottom = INSETS.bottom;
/* 283:321 */       newInsets.right = INSETS.right;
/* 284:322 */       return newInsets;
/* 285:    */     }
/* 286:    */     
/* 287:    */     private XPScrollPaneBorder() {}
/* 288:    */   }
/* 289:    */   
/* 290:    */   private static final class XPSpinnerBorder
/* 291:    */     extends MetalBorders.ScrollPaneBorder
/* 292:    */   {
/* 293:    */     XPSpinnerBorder(PlasticXPBorders.1 x0)
/* 294:    */     {
/* 295:330 */       this();
/* 296:    */     }
/* 297:    */     
/* 298:332 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 299:    */     
/* 300:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 301:    */     {
/* 302:335 */       g.setColor(c.isEnabled() ? PlasticLookAndFeel.getControlDarkShadow() : MetalLookAndFeel.getControlShadow());
/* 303:    */       
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:340 */       int arrowButtonWidth = UIManager.getInt("ScrollBar.width") - 1;
/* 308:341 */       w -= arrowButtonWidth;
/* 309:342 */       g.fillRect(x, y, w, 1);
/* 310:343 */       g.fillRect(x, y + 1, 1, h - 1);
/* 311:344 */       g.fillRect(x + 1, y + h - 1, w - 1, 1);
/* 312:    */     }
/* 313:    */     
/* 314:    */     public Insets getBorderInsets(Component c)
/* 315:    */     {
/* 316:347 */       return INSETS;
/* 317:    */     }
/* 318:    */     
/* 319:    */     public Insets getBorderInsets(Component c, Insets newInsets)
/* 320:    */     {
/* 321:350 */       newInsets.top = INSETS.top;
/* 322:351 */       newInsets.left = INSETS.left;
/* 323:352 */       newInsets.bottom = INSETS.bottom;
/* 324:353 */       newInsets.right = INSETS.right;
/* 325:354 */       return newInsets;
/* 326:    */     }
/* 327:    */     
/* 328:    */     private XPSpinnerBorder() {}
/* 329:    */   }
/* 330:    */   
/* 331:    */   private static final class RolloverButtonBorder
/* 332:    */     extends PlasticXPBorders.XPButtonBorder
/* 333:    */   {
/* 334:    */     RolloverButtonBorder(PlasticXPBorders.1 x0)
/* 335:    */     {
/* 336:362 */       this();
/* 337:    */     }
/* 338:    */     
/* 339:    */     private RolloverButtonBorder()
/* 340:    */     {
/* 341:365 */       super();
/* 342:    */     }
/* 343:    */     
/* 344:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 345:    */     {
/* 346:369 */       AbstractButton b = (AbstractButton)c;
/* 347:370 */       ButtonModel model = b.getModel();
/* 348:372 */       if (!model.isEnabled()) {
/* 349:373 */         return;
/* 350:    */       }
/* 351:375 */       if (!(c instanceof JToggleButton))
/* 352:    */       {
/* 353:376 */         if ((model.isRollover()) && ((!model.isPressed()) || (model.isArmed()))) {
/* 354:377 */           super.paintBorder(c, g, x, y, w, h);
/* 355:    */         }
/* 356:379 */         return;
/* 357:    */       }
/* 358:382 */       if (model.isRollover())
/* 359:    */       {
/* 360:383 */         if ((model.isPressed()) && (model.isArmed())) {
/* 361:384 */           PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 362:    */         } else {
/* 363:386 */           PlasticXPUtils.drawPlainButtonBorder(g, x, y, w, h);
/* 364:    */         }
/* 365:    */       }
/* 366:388 */       else if (model.isSelected()) {
/* 367:389 */         PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 368:    */       }
/* 369:    */     }
/* 370:    */   }
/* 371:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPBorders
 * JD-Core Version:    0.7.0.1
 */
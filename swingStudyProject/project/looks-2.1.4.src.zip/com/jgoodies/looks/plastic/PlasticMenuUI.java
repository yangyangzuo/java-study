/*  1:   */ package com.jgoodies.looks.plastic;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.LookUtils;
/*  4:   */ import com.jgoodies.looks.common.ExtBasicMenuUI;
/*  5:   */ import java.awt.Color;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ import javax.swing.ButtonModel;
/*  8:   */ import javax.swing.Icon;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.JMenu;
/* 11:   */ import javax.swing.JMenuItem;
/* 12:   */ import javax.swing.plaf.ComponentUI;
/* 13:   */ 
/* 14:   */ public final class PlasticMenuUI
/* 15:   */   extends ExtBasicMenuUI
/* 16:   */ {
/* 17:   */   private boolean oldOpaque;
/* 18:   */   
/* 19:   */   public static ComponentUI createUI(JComponent b)
/* 20:   */   {
/* 21:60 */     return new PlasticMenuUI();
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected void installDefaults()
/* 25:   */   {
/* 26:64 */     super.installDefaults();
/* 27:65 */     this.oldOpaque = this.menuItem.isOpaque();
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected void uninstallDefaults()
/* 31:   */   {
/* 32:69 */     super.uninstallDefaults();
/* 33:72 */     if ((!LookUtils.IS_OS_WINDOWS_VISTA) && (!LookUtils.IS_JAVA_6_OR_LATER)) {
/* 34:73 */       this.menuItem.setOpaque(this.oldOpaque);
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected void paintMenuItem(Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap)
/* 39:   */   {
/* 40:84 */     JMenuItem b = (JMenuItem)c;
/* 41:86 */     if (((JMenu)this.menuItem).isTopLevelMenu())
/* 42:   */     {
/* 43:87 */       b.setOpaque(false);
/* 44:88 */       if (b.getModel().isSelected())
/* 45:   */       {
/* 46:89 */         int menuWidth = this.menuItem.getWidth();
/* 47:90 */         int menuHeight = this.menuItem.getHeight();
/* 48:91 */         Color oldColor = g.getColor();
/* 49:92 */         g.setColor(background);
/* 50:93 */         g.fillRect(0, 0, menuWidth, menuHeight);
/* 51:94 */         g.setColor(oldColor);
/* 52:   */       }
/* 53:   */     }
/* 54:97 */     super.paintMenuItem(g, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap);
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticMenuUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.beans.PropertyChangeEvent;
/*   5:    */ import javax.swing.JComponent;
/*   6:    */ import javax.swing.UIManager;
/*   7:    */ import javax.swing.plaf.ComponentUI;
/*   8:    */ import javax.swing.plaf.UIResource;
/*   9:    */ import javax.swing.text.JTextComponent;
/*  10:    */ 
/*  11:    */ public final class WindowsTextAreaUI
/*  12:    */   extends com.sun.java.swing.plaf.windows.WindowsTextAreaUI
/*  13:    */ {
/*  14:    */   public static ComponentUI createUI(JComponent c)
/*  15:    */   {
/*  16: 60 */     return new WindowsTextAreaUI();
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void installUI(JComponent c)
/*  20:    */   {
/*  21: 66 */     super.installUI(c);
/*  22: 67 */     updateBackground((JTextComponent)c);
/*  23:    */   }
/*  24:    */   
/*  25:    */   protected void propertyChange(PropertyChangeEvent evt)
/*  26:    */   {
/*  27: 78 */     super.propertyChange(evt);
/*  28: 79 */     String propertyName = evt.getPropertyName();
/*  29: 80 */     if (("editable".equals(propertyName)) || ("enabled".equals(propertyName))) {
/*  30: 82 */       updateBackground((JTextComponent)evt.getSource());
/*  31:    */     }
/*  32:    */   }
/*  33:    */   
/*  34:    */   private void updateBackground(JTextComponent c)
/*  35:    */   {
/*  36: 88 */     Color background = c.getBackground();
/*  37: 89 */     if (!(background instanceof UIResource)) {
/*  38: 90 */       return;
/*  39:    */     }
/*  40: 92 */     Color newColor = null;
/*  41: 93 */     if (!c.isEnabled()) {
/*  42: 94 */       newColor = UIManager.getColor("TextArea.disabledBackground");
/*  43:    */     }
/*  44: 96 */     if ((newColor == null) && (!c.isEditable())) {
/*  45: 97 */       newColor = UIManager.getColor("TextArea.inactiveBackground");
/*  46:    */     }
/*  47: 99 */     if (newColor == null) {
/*  48:100 */       newColor = UIManager.getColor("TextArea.background");
/*  49:    */     }
/*  50:102 */     if ((newColor != null) && (newColor != background)) {
/*  51:103 */       c.setBackground(newColor);
/*  52:    */     }
/*  53:    */   }
/*  54:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsTextAreaUI
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.common.ExtButtonAreaLayout;
/*  4:   */ import java.awt.Container;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.JPanel;
/*  7:   */ import javax.swing.UIManager;
/*  8:   */ import javax.swing.plaf.ComponentUI;
/*  9:   */ import javax.swing.plaf.basic.BasicOptionPaneUI;
/* 10:   */ 
/* 11:   */ public final class WindowsOptionPaneUI
/* 12:   */   extends BasicOptionPaneUI
/* 13:   */ {
/* 14:   */   public static ComponentUI createUI(JComponent b)
/* 15:   */   {
/* 16:54 */     return new WindowsOptionPaneUI();
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected Container createButtonArea()
/* 20:   */   {
/* 21:62 */     JPanel bottom = new JPanel(new ExtButtonAreaLayout(true, 6));
/* 22:63 */     bottom.setBorder(UIManager.getBorder("OptionPane.buttonAreaBorder"));
/* 23:64 */     addButtonComponents(bottom, getButtons(), getInitialValueIndex());
/* 24:65 */     return bottom;
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsOptionPaneUI
 * JD-Core Version:    0.7.0.1
 */
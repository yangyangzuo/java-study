/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.BorderStyle;
/*   4:    */ import com.jgoodies.looks.HeaderStyle;
/*   5:    */ import com.sun.java.swing.plaf.windows.WindowsToolBarUI;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.Container;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import javax.swing.AbstractButton;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ import javax.swing.JToolBar;
/*  13:    */ import javax.swing.LookAndFeel;
/*  14:    */ import javax.swing.plaf.ComponentUI;
/*  15:    */ 
/*  16:    */ public final class WindowsXPToolBarUI
/*  17:    */   extends WindowsToolBarUI
/*  18:    */ {
/*  19:    */   private PropertyChangeListener listener;
/*  20:    */   
/*  21:    */   public static ComponentUI createUI(JComponent b)
/*  22:    */   {
/*  23: 59 */     return new WindowsXPToolBarUI();
/*  24:    */   }
/*  25:    */   
/*  26:    */   protected void installDefaults()
/*  27:    */   {
/*  28: 66 */     super.installDefaults();
/*  29: 67 */     installSpecialBorder();
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected void installListeners()
/*  33:    */   {
/*  34: 72 */     super.installListeners();
/*  35: 73 */     this.listener = createBorderStyleListener();
/*  36: 74 */     this.toolBar.addPropertyChangeListener(this.listener);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected void uninstallListeners()
/*  40:    */   {
/*  41: 79 */     this.toolBar.removePropertyChangeListener(this.listener);
/*  42: 80 */     super.uninstallListeners();
/*  43:    */   }
/*  44:    */   
/*  45:    */   private PropertyChangeListener createBorderStyleListener()
/*  46:    */   {
/*  47: 85 */     new PropertyChangeListener()
/*  48:    */     {
/*  49:    */       public void propertyChange(PropertyChangeEvent e)
/*  50:    */       {
/*  51: 88 */         String prop = e.getPropertyName();
/*  52: 89 */         if ((prop.equals("jgoodies.headerStyle")) || (prop.equals("jgoodies.windows.borderStyle"))) {
/*  53: 91 */           WindowsXPToolBarUI.this.installSpecialBorder();
/*  54:    */         }
/*  55:    */       }
/*  56:    */     };
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void installSpecialBorder()
/*  60:    */   {
/*  61:109 */     BorderStyle borderStyle = BorderStyle.from(this.toolBar, "jgoodies.windows.borderStyle");
/*  62:    */     String suffix;
/*  63:    */     String suffix;
/*  64:111 */     if (borderStyle == BorderStyle.EMPTY)
/*  65:    */     {
/*  66:112 */       suffix = "emptyBorder";
/*  67:    */     }
/*  68:    */     else
/*  69:    */     {
/*  70:    */       String suffix;
/*  71:113 */       if (borderStyle == BorderStyle.SEPARATOR)
/*  72:    */       {
/*  73:114 */         suffix = "separatorBorder";
/*  74:    */       }
/*  75:    */       else
/*  76:    */       {
/*  77:    */         String suffix;
/*  78:115 */         if (borderStyle == BorderStyle.ETCHED)
/*  79:    */         {
/*  80:116 */           suffix = "etchedBorder";
/*  81:    */         }
/*  82:    */         else
/*  83:    */         {
/*  84:    */           String suffix;
/*  85:117 */           if (HeaderStyle.from(this.toolBar) == HeaderStyle.BOTH) {
/*  86:118 */             suffix = "headerBorder";
/*  87:    */           } else {
/*  88:120 */             suffix = "border";
/*  89:    */           }
/*  90:    */         }
/*  91:    */       }
/*  92:    */     }
/*  93:121 */     LookAndFeel.installBorder(this.toolBar, "ToolBar." + suffix);
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected void setBorderToRollover(Component c)
/*  97:    */   {
/*  98:128 */     if ((c instanceof AbstractButton))
/*  99:    */     {
/* 100:129 */       super.setBorderToRollover(c);
/* 101:    */     }
/* 102:130 */     else if ((c instanceof Container))
/* 103:    */     {
/* 104:131 */       Container cont = (Container)c;
/* 105:132 */       for (int i = 0; i < cont.getComponentCount(); i++) {
/* 106:133 */         super.setBorderToRollover(cont.getComponent(i));
/* 107:    */       }
/* 108:    */     }
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsXPToolBarUI
 * JD-Core Version:    0.7.0.1
 */
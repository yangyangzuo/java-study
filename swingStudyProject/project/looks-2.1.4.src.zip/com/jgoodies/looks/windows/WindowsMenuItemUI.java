/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.common.ExtBasicMenuItemUI;
/*  4:   */ import com.jgoodies.looks.common.MenuItemRenderer;
/*  5:   */ import java.awt.Color;
/*  6:   */ import java.awt.Font;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import javax.swing.JMenuItem;
/*  9:   */ import javax.swing.plaf.ComponentUI;
/* 10:   */ 
/* 11:   */ public final class WindowsMenuItemUI
/* 12:   */   extends ExtBasicMenuItemUI
/* 13:   */ {
/* 14:   */   public static ComponentUI createUI(JComponent b)
/* 15:   */   {
/* 16:57 */     return new WindowsMenuItemUI();
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected MenuItemRenderer createRenderer(JMenuItem menuItem, boolean iconBorderEnabled, Font acceleratorFont, Color selectionForeground, Color disabledForeground, Color acceleratorForeground, Color acceleratorSelectionForeground)
/* 20:   */   {
/* 21:69 */     return new WindowsMenuItemRenderer(menuItem, iconBorderEnabled(), acceleratorFont, selectionForeground, disabledForeground, acceleratorForeground, acceleratorSelectionForeground);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsMenuItemUI
 * JD-Core Version:    0.7.0.1
 */
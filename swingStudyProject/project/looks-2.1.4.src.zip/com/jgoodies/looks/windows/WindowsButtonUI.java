/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import javax.swing.AbstractButton;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.plaf.ComponentUI;
/*  7:   */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  8:   */ 
/*  9:   */ public final class WindowsButtonUI
/* 10:   */   extends com.sun.java.swing.plaf.windows.WindowsButtonUI
/* 11:   */ {
/* 12:   */   public static ComponentUI createUI(JComponent b)
/* 13:   */   {
/* 14:51 */     return new WindowsButtonUI();
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Dimension getPreferredSize(JComponent c)
/* 18:   */   {
/* 19:55 */     AbstractButton b = (AbstractButton)c;
/* 20:56 */     Dimension d = BasicGraphicsUtils.getPreferredButtonSize(b, b.getIconTextGap());
/* 21:62 */     if ((d != null) && (b.isFocusPainted()) && 
/* 22:63 */       (d.width % 2 == 0)) {
/* 23:64 */       d.width += 1;
/* 24:   */     }
/* 25:67 */     return d;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsButtonUI
 * JD-Core Version:    0.7.0.1
 */
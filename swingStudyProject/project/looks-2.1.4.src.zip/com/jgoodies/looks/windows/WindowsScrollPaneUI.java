/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeEvent;
/*  4:   */ import java.beans.PropertyChangeListener;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.JScrollPane;
/*  7:   */ import javax.swing.LookAndFeel;
/*  8:   */ import javax.swing.plaf.ComponentUI;
/*  9:   */ 
/* 10:   */ public final class WindowsScrollPaneUI
/* 11:   */   extends com.sun.java.swing.plaf.windows.WindowsScrollPaneUI
/* 12:   */ {
/* 13:   */   private PropertyChangeListener borderStyleChangeHandler;
/* 14:   */   
/* 15:   */   public static ComponentUI createUI(JComponent b)
/* 16:   */   {
/* 17:58 */     return new WindowsScrollPaneUI();
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected void installDefaults(JScrollPane scrollPane)
/* 21:   */   {
/* 22:62 */     super.installDefaults(scrollPane);
/* 23:63 */     installEtchedBorder(scrollPane);
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected void installEtchedBorder(JScrollPane scrollPane)
/* 27:   */   {
/* 28:67 */     Object value = scrollPane.getClientProperty("jgoodies.isEtched");
/* 29:68 */     boolean hasEtchedBorder = Boolean.TRUE.equals(value);
/* 30:69 */     LookAndFeel.installBorder(scrollPane, hasEtchedBorder ? "ScrollPane.etchedBorder" : "ScrollPane.border");
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void installListeners(JScrollPane scrollPane)
/* 34:   */   {
/* 35:79 */     super.installListeners(scrollPane);
/* 36:80 */     this.borderStyleChangeHandler = new BorderStyleChangeHandler(null);
/* 37:81 */     scrollPane.addPropertyChangeListener("jgoodies.isEtched", this.borderStyleChangeHandler);
/* 38:   */   }
/* 39:   */   
/* 40:   */   protected void uninstallListeners(JComponent c)
/* 41:   */   {
/* 42:85 */     ((JScrollPane)c).removePropertyChangeListener("jgoodies.isEtched", this.borderStyleChangeHandler);
/* 43:   */     
/* 44:87 */     super.uninstallListeners(c);
/* 45:   */   }
/* 46:   */   
/* 47:   */   private class BorderStyleChangeHandler
/* 48:   */     implements PropertyChangeListener
/* 49:   */   {
/* 50:   */     BorderStyleChangeHandler(WindowsScrollPaneUI.1 x1)
/* 51:   */     {
/* 52:90 */       this();
/* 53:   */     }
/* 54:   */     
/* 55:   */     public void propertyChange(PropertyChangeEvent evt)
/* 56:   */     {
/* 57:93 */       JScrollPane scrollPane = (JScrollPane)evt.getSource();
/* 58:94 */       WindowsScrollPaneUI.this.installEtchedBorder(scrollPane);
/* 59:   */     }
/* 60:   */     
/* 61:   */     private BorderStyleChangeHandler() {}
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsScrollPaneUI
 * JD-Core Version:    0.7.0.1
 */
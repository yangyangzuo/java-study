/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import javax.swing.JComponent;
/*  4:   */ import javax.swing.plaf.ComponentUI;
/*  5:   */ import javax.swing.plaf.basic.BasicFormattedTextFieldUI;
/*  6:   */ import javax.swing.text.Caret;
/*  7:   */ 
/*  8:   */ public final class WindowsFormattedTextFieldUI
/*  9:   */   extends BasicFormattedTextFieldUI
/* 10:   */ {
/* 11:   */   public static ComponentUI createUI(JComponent c)
/* 12:   */   {
/* 13:55 */     return new WindowsFormattedTextFieldUI();
/* 14:   */   }
/* 15:   */   
/* 16:   */   protected Caret createCaret()
/* 17:   */   {
/* 18:65 */     return new WindowsFieldCaret();
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsFormattedTextFieldUI
 * JD-Core Version:    0.7.0.1
 */
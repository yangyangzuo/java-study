/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.BorderStyle;
/*   4:    */ import com.jgoodies.looks.HeaderStyle;
/*   5:    */ import java.beans.PropertyChangeEvent;
/*   6:    */ import java.beans.PropertyChangeListener;
/*   7:    */ import javax.swing.JComponent;
/*   8:    */ import javax.swing.JMenuBar;
/*   9:    */ import javax.swing.LookAndFeel;
/*  10:    */ import javax.swing.plaf.ComponentUI;
/*  11:    */ 
/*  12:    */ public final class WindowsMenuBarUI
/*  13:    */   extends com.sun.java.swing.plaf.windows.WindowsMenuBarUI
/*  14:    */ {
/*  15:    */   private PropertyChangeListener listener;
/*  16:    */   
/*  17:    */   public static ComponentUI createUI(JComponent b)
/*  18:    */   {
/*  19: 59 */     return new WindowsMenuBarUI();
/*  20:    */   }
/*  21:    */   
/*  22:    */   protected void installDefaults()
/*  23:    */   {
/*  24: 66 */     super.installDefaults();
/*  25: 67 */     installSpecialBorder();
/*  26:    */   }
/*  27:    */   
/*  28:    */   protected void installListeners()
/*  29:    */   {
/*  30: 72 */     super.installListeners();
/*  31: 73 */     this.listener = createBorderStyleListener();
/*  32: 74 */     this.menuBar.addPropertyChangeListener(this.listener);
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected void uninstallListeners()
/*  36:    */   {
/*  37: 79 */     this.menuBar.removePropertyChangeListener(this.listener);
/*  38: 80 */     super.uninstallListeners();
/*  39:    */   }
/*  40:    */   
/*  41:    */   private PropertyChangeListener createBorderStyleListener()
/*  42:    */   {
/*  43: 85 */     new PropertyChangeListener()
/*  44:    */     {
/*  45:    */       public void propertyChange(PropertyChangeEvent e)
/*  46:    */       {
/*  47: 88 */         String prop = e.getPropertyName();
/*  48: 89 */         if ((prop.equals("jgoodies.headerStyle")) || (prop.equals("jgoodies.windows.borderStyle"))) {
/*  49: 91 */           WindowsMenuBarUI.this.installSpecialBorder();
/*  50:    */         }
/*  51:    */       }
/*  52:    */     };
/*  53:    */   }
/*  54:    */   
/*  55:    */   private void installSpecialBorder()
/*  56:    */   {
/*  57:110 */     BorderStyle borderStyle = BorderStyle.from(this.menuBar, "jgoodies.windows.borderStyle");
/*  58:    */     String suffix;
/*  59:112 */     if (borderStyle == BorderStyle.EMPTY)
/*  60:    */     {
/*  61:113 */       suffix = "emptyBorder";
/*  62:    */     }
/*  63:    */     else
/*  64:    */     {
/*  65:    */       String suffix;
/*  66:114 */       if (borderStyle == BorderStyle.ETCHED)
/*  67:    */       {
/*  68:115 */         suffix = "etchedBorder";
/*  69:    */       }
/*  70:    */       else
/*  71:    */       {
/*  72:    */         String suffix;
/*  73:116 */         if (borderStyle == BorderStyle.SEPARATOR)
/*  74:    */         {
/*  75:117 */           suffix = "separatorBorder";
/*  76:    */         }
/*  77:    */         else
/*  78:    */         {
/*  79:    */           String suffix;
/*  80:118 */           if (HeaderStyle.from(this.menuBar) == HeaderStyle.BOTH) {
/*  81:119 */             suffix = "headerBorder";
/*  82:    */           } else {
/*  83:    */             return;
/*  84:    */           }
/*  85:    */         }
/*  86:    */       }
/*  87:    */     }
/*  88:    */     String suffix;
/*  89:123 */     LookAndFeel.installBorder(this.menuBar, "MenuBar." + suffix);
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsMenuBarUI
 * JD-Core Version:    0.7.0.1
 */
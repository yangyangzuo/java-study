/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.BorderStyle;
/*   4:    */ import com.jgoodies.looks.HeaderStyle;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.beans.PropertyChangeEvent;
/*   8:    */ import java.beans.PropertyChangeListener;
/*   9:    */ import javax.swing.AbstractButton;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JToolBar;
/*  12:    */ import javax.swing.LookAndFeel;
/*  13:    */ import javax.swing.border.Border;
/*  14:    */ import javax.swing.event.MouseInputListener;
/*  15:    */ import javax.swing.plaf.ComponentUI;
/*  16:    */ import javax.swing.plaf.basic.BasicToolBarUI.DockingListener;
/*  17:    */ import javax.swing.plaf.metal.MetalToolBarUI;
/*  18:    */ 
/*  19:    */ public final class WindowsToolBarUI
/*  20:    */   extends MetalToolBarUI
/*  21:    */ {
/*  22:    */   private PropertyChangeListener listener;
/*  23:    */   
/*  24:    */   public static ComponentUI createUI(JComponent b)
/*  25:    */   {
/*  26: 62 */     return new WindowsToolBarUI();
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected void installDefaults()
/*  30:    */   {
/*  31: 68 */     super.installDefaults();
/*  32: 69 */     installSpecialBorder();
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected void installListeners()
/*  36:    */   {
/*  37: 73 */     super.installListeners();
/*  38: 74 */     this.listener = createBorderStyleListener();
/*  39: 75 */     this.toolBar.addPropertyChangeListener(this.listener);
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected void uninstallListeners()
/*  43:    */   {
/*  44: 79 */     this.toolBar.removePropertyChangeListener(this.listener);
/*  45: 80 */     super.uninstallListeners();
/*  46:    */   }
/*  47:    */   
/*  48:    */   private PropertyChangeListener createBorderStyleListener()
/*  49:    */   {
/*  50: 84 */     new PropertyChangeListener()
/*  51:    */     {
/*  52:    */       public void propertyChange(PropertyChangeEvent e)
/*  53:    */       {
/*  54: 87 */         String prop = e.getPropertyName();
/*  55: 88 */         if ((prop.equals("jgoodies.headerStyle")) || (prop.equals("jgoodies.windows.borderStyle"))) {
/*  56: 90 */           WindowsToolBarUI.this.installSpecialBorder();
/*  57:    */         }
/*  58:    */       }
/*  59:    */     };
/*  60:    */   }
/*  61:    */   
/*  62:    */   private void installSpecialBorder()
/*  63:    */   {
/*  64:107 */     BorderStyle borderStyle = BorderStyle.from(this.toolBar, "jgoodies.windows.borderStyle");
/*  65:    */     String suffix;
/*  66:109 */     if (borderStyle == BorderStyle.EMPTY)
/*  67:    */     {
/*  68:110 */       suffix = "emptyBorder";
/*  69:    */     }
/*  70:    */     else
/*  71:    */     {
/*  72:    */       String suffix;
/*  73:111 */       if (borderStyle == BorderStyle.SEPARATOR)
/*  74:    */       {
/*  75:112 */         suffix = "separatorBorder";
/*  76:    */       }
/*  77:    */       else
/*  78:    */       {
/*  79:    */         String suffix;
/*  80:113 */         if (borderStyle == BorderStyle.ETCHED)
/*  81:    */         {
/*  82:114 */           suffix = "etchedBorder";
/*  83:    */         }
/*  84:    */         else
/*  85:    */         {
/*  86:    */           String suffix;
/*  87:115 */           if (HeaderStyle.from(this.toolBar) == HeaderStyle.BOTH) {
/*  88:116 */             suffix = "headerBorder";
/*  89:    */           } else {
/*  90:    */             return;
/*  91:    */           }
/*  92:    */         }
/*  93:    */       }
/*  94:    */     }
/*  95:    */     String suffix;
/*  96:119 */     LookAndFeel.installBorder(this.toolBar, "ToolBar." + suffix);
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected MouseInputListener createDockingListener()
/* 100:    */   {
/* 101:130 */     return new BasicToolBarUI.DockingListener(this, this.toolBar);
/* 102:    */   }
/* 103:    */   
/* 104:    */   protected Border createRolloverBorder()
/* 105:    */   {
/* 106:137 */     return WindowsBorders.getRolloverButtonBorder();
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected void setBorderToRollover(Component c)
/* 110:    */   {
/* 111:141 */     if ((c instanceof AbstractButton))
/* 112:    */     {
/* 113:142 */       super.setBorderToRollover(c);
/* 114:    */     }
/* 115:143 */     else if ((c instanceof Container))
/* 116:    */     {
/* 117:144 */       Container cont = (Container)c;
/* 118:145 */       for (int i = 0; i < cont.getComponentCount(); i++) {
/* 119:146 */         super.setBorderToRollover(cont.getComponent(i));
/* 120:    */       }
/* 121:    */     }
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsToolBarUI
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.common.ComboBoxEditorTextField;
/*  4:   */ import javax.swing.JTextField;
/*  5:   */ import javax.swing.plaf.UIResource;
/*  6:   */ import javax.swing.plaf.basic.BasicComboBoxEditor;
/*  7:   */ 
/*  8:   */ class WindowsComboBoxEditor
/*  9:   */   extends BasicComboBoxEditor
/* 10:   */ {
/* 11:   */   WindowsComboBoxEditor(boolean isTableCellEditor)
/* 12:   */   {
/* 13:50 */     this.editor = new ComboBoxEditorTextField(isTableCellEditor);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void setItem(Object item)
/* 17:   */   {
/* 18:54 */     super.setItem(item);
/* 19:55 */     this.editor.selectAll();
/* 20:   */   }
/* 21:   */   
/* 22:   */   static final class UIResource
/* 23:   */     extends WindowsComboBoxEditor
/* 24:   */     implements UIResource
/* 25:   */   {
/* 26:   */     UIResource(boolean isTableCellEditor)
/* 27:   */     {
/* 28:68 */       super();
/* 29:   */     }
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsComboBoxEditor
 * JD-Core Version:    0.7.0.1
 */
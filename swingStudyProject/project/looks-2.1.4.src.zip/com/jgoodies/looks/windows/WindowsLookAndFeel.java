/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.FontPolicies;
/*   4:    */ import com.jgoodies.looks.FontPolicy;
/*   5:    */ import com.jgoodies.looks.FontSet;
/*   6:    */ import com.jgoodies.looks.LookUtils;
/*   7:    */ import com.jgoodies.looks.MicroLayout;
/*   8:    */ import com.jgoodies.looks.MicroLayoutPolicies;
/*   9:    */ import com.jgoodies.looks.MicroLayoutPolicy;
/*  10:    */ import com.jgoodies.looks.Options;
/*  11:    */ import com.jgoodies.looks.common.MinimumSizedIcon;
/*  12:    */ import com.jgoodies.looks.common.RGBGrayFilter;
/*  13:    */ import com.jgoodies.looks.common.ShadowPopupFactory;
/*  14:    */ import java.awt.Color;
/*  15:    */ import java.awt.Dimension;
/*  16:    */ import java.awt.Font;
/*  17:    */ import java.awt.Insets;
/*  18:    */ import java.lang.reflect.Method;
/*  19:    */ import javax.swing.Icon;
/*  20:    */ import javax.swing.JComponent;
/*  21:    */ import javax.swing.UIDefaults;
/*  22:    */ import javax.swing.UIDefaults.LazyValue;
/*  23:    */ import javax.swing.UIDefaults.ProxyLazyValue;
/*  24:    */ import javax.swing.UIManager;
/*  25:    */ import javax.swing.border.Border;
/*  26:    */ import javax.swing.border.EmptyBorder;
/*  27:    */ import javax.swing.plaf.DimensionUIResource;
/*  28:    */ import javax.swing.plaf.IconUIResource;
/*  29:    */ import javax.swing.plaf.InsetsUIResource;
/*  30:    */ import javax.swing.plaf.basic.BasicBorders.FieldBorder;
/*  31:    */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*  32:    */ 
/*  33:    */ public final class WindowsLookAndFeel
/*  34:    */   extends com.sun.java.swing.plaf.windows.WindowsLookAndFeel
/*  35:    */ {
/*  36:    */   public static final String BORDER_STYLE_KEY = "jgoodies.windows.borderStyle";
/*  37:    */   
/*  38:    */   public String getID()
/*  39:    */   {
/*  40: 73 */     return "JGoodies Windows";
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getName()
/*  44:    */   {
/*  45: 78 */     return "JGoodies Windows";
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getDescription()
/*  49:    */   {
/*  50: 83 */     return "The JGoodies Windows Look and Feel - © 2001-2007 JGoodies Karsten Lentzsch";
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static FontPolicy getFontPolicy()
/*  54:    */   {
/*  55:111 */     FontPolicy policy = (FontPolicy)UIManager.get("Windows.fontPolicy");
/*  56:113 */     if (policy != null) {
/*  57:114 */       return policy;
/*  58:    */     }
/*  59:116 */     FontPolicy defaultPolicy = FontPolicies.getDefaultWindowsPolicy();
/*  60:117 */     return FontPolicies.customSettingsPolicy(defaultPolicy);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void setFontPolicy(FontPolicy fontPolicy)
/*  64:    */   {
/*  65:132 */     UIManager.put("Windows.fontPolicy", fontPolicy);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static MicroLayoutPolicy getMicroLayoutPolicy()
/*  69:    */   {
/*  70:151 */     MicroLayoutPolicy policy = (MicroLayoutPolicy)UIManager.get("Windows.MicroLayoutPolicy");
/*  71:    */     
/*  72:153 */     return policy != null ? policy : MicroLayoutPolicies.getDefaultWindowsPolicy();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void setMicroLayoutPolicy(MicroLayout microLayoutPolicy)
/*  76:    */   {
/*  77:171 */     UIManager.put("Windows.MicroLayoutPolicy", microLayoutPolicy);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void initialize()
/*  81:    */   {
/*  82:184 */     super.initialize();
/*  83:185 */     ShadowPopupFactory.install();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void uninitialize()
/*  87:    */   {
/*  88:196 */     super.uninitialize();
/*  89:197 */     ShadowPopupFactory.uninstall();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public Icon getDisabledIcon(JComponent component, Icon icon)
/*  93:    */   {
/*  94:212 */     Icon disabledIcon = RGBGrayFilter.getDisabledIcon(component, icon);
/*  95:213 */     return disabledIcon != null ? new IconUIResource(disabledIcon) : null;
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected void initClassDefaults(UIDefaults table)
/*  99:    */   {
/* 100:224 */     super.initClassDefaults(table);
/* 101:225 */     String windowsPrefix = "com.jgoodies.looks.windows.Windows";
/* 102:226 */     String commonPrefix = "com.jgoodies.looks.common.ExtBasic";
/* 103:    */     
/* 104:    */ 
/* 105:229 */     Object[] uiDefaults = { "ComboBoxUI", "com.jgoodies.looks.windows.WindowsComboBoxUI", "ButtonUI", "com.jgoodies.looks.windows.WindowsButtonUI", "ScrollPaneUI", "com.jgoodies.looks.windows.WindowsScrollPaneUI", "MenuBarUI", "com.jgoodies.looks.windows.WindowsMenuBarUI", "PopupMenuUI", "com.jgoodies.looks.windows.WindowsPopupMenuUI", "OptionPaneUI", "com.jgoodies.looks.windows.WindowsOptionPaneUI", "SplitPaneUI", "com.jgoodies.looks.windows.WindowsSplitPaneUI", "TabbedPaneUI", "com.jgoodies.looks.windows.WindowsTabbedPaneUI", "TextFieldUI", "com.jgoodies.looks.windows.WindowsTextFieldUI", "FormattedTextFieldUI", "com.jgoodies.looks.windows.WindowsFormattedTextFieldUI", "PasswordFieldUI", "com.jgoodies.looks.windows.WindowsPasswordFieldUI", "TextAreaUI", "com.jgoodies.looks.windows.WindowsTextAreaUI", "TreeUI", "com.jgoodies.looks.windows.WindowsTreeUI", "SeparatorUI", "com.jgoodies.looks.windows.WindowsSeparatorUI" };
/* 106:272 */     if (LookUtils.IS_JAVA_1_4_2_OR_LATER) {
/* 107:274 */       uiDefaults = append(uiDefaults, "SpinnerUI", "com.jgoodies.looks.windows.WindowsSpinnerUI");
/* 108:    */     }
/* 109:279 */     if ((!LookUtils.IS_JAVA_6_OR_LATER) || (!LookUtils.IS_OS_WINDOWS_VISTA) || (!LookUtils.IS_LAF_WINDOWS_XP_ENABLED))
/* 110:    */     {
/* 111:282 */       uiDefaults = append(uiDefaults, "MenuItemUI", "com.jgoodies.looks.windows.WindowsMenuItemUI");
/* 112:    */       
/* 113:284 */       uiDefaults = append(uiDefaults, "CheckBoxMenuItemUI", "com.jgoodies.looks.common.ExtBasicCheckBoxMenuItemUI");
/* 114:    */       
/* 115:286 */       uiDefaults = append(uiDefaults, "RadioButtonMenuItemUI", "com.jgoodies.looks.common.ExtBasicRadioButtonMenuItemUI");
/* 116:    */       
/* 117:    */ 
/* 118:289 */       uiDefaults = append(uiDefaults, "PopupMenuSeparatorUI", "com.jgoodies.looks.common.ExtBasicPopupMenuSeparatorUI");
/* 119:    */     }
/* 120:293 */     if (LookUtils.IS_LAF_WINDOWS_XP_ENABLED)
/* 121:    */     {
/* 122:295 */       if ((!LookUtils.IS_JAVA_6_OR_LATER) || (!LookUtils.IS_OS_WINDOWS_VISTA)) {
/* 123:296 */         uiDefaults = append(uiDefaults, "MenuUI", "com.jgoodies.looks.windows.WindowsXPMenuUI");
/* 124:    */       }
/* 125:302 */       uiDefaults = append(uiDefaults, "ToolBarUI", "com.jgoodies.looks.windows.WindowsXPToolBarUI");
/* 126:    */       
/* 127:    */ 
/* 128:    */ 
/* 129:306 */       uiDefaults = append(uiDefaults, "TableHeaderUI", "com.jgoodies.looks.windows.WindowsXPTableHeaderUI");
/* 130:    */     }
/* 131:    */     else
/* 132:    */     {
/* 133:310 */       uiDefaults = append(uiDefaults, "MenuUI", "com.jgoodies.looks.common.ExtBasicMenuUI");
/* 134:    */       
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:315 */       uiDefaults = append(uiDefaults, "ToolBarUI", "com.jgoodies.looks.windows.WindowsToolBarUI");
/* 139:    */       
/* 140:    */ 
/* 141:    */ 
/* 142:319 */       uiDefaults = append(uiDefaults, "ScrollBarUI", "com.jgoodies.looks.windows.WindowsScrollBarUI");
/* 143:322 */       if (!LookUtils.IS_JAVA_1_4_2_OR_LATER) {
/* 144:324 */         uiDefaults = append(uiDefaults, "ToolBarSeparatorUI", "com.jgoodies.looks.windows.WindowsToolBarSeparatorUI");
/* 145:    */       }
/* 146:    */     }
/* 147:328 */     table.putDefaults(uiDefaults);
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected void initComponentDefaults(UIDefaults table)
/* 151:    */   {
/* 152:335 */     super.initComponentDefaults(table);
/* 153:    */     
/* 154:337 */     boolean isXP = LookUtils.IS_LAF_WINDOWS_XP_ENABLED;
/* 155:338 */     boolean isClassic = !isXP;
/* 156:339 */     boolean isVista = LookUtils.IS_OS_WINDOWS_VISTA;
/* 157:    */     
/* 158:341 */     initFontDefaults(table);
/* 159:343 */     if (isClassic) {
/* 160:344 */       initComponentDefaultsClassic(table);
/* 161:    */     }
/* 162:346 */     if ((isXP) && (LookUtils.IS_JAVA_1_4)) {
/* 163:347 */       initComponentDefaultsXP14(table);
/* 164:    */     }
/* 165:350 */     MicroLayout microLayout = getMicroLayoutPolicy().getMicroLayout("Windows", table);
/* 166:351 */     if ((!isVista) || (!LookUtils.IS_JAVA_6_OR_LATER) || (!LookUtils.IS_LAF_WINDOWS_XP_ENABLED)) {
/* 167:352 */       initMenuItemDefaults(table, microLayout);
/* 168:    */     }
/* 169:355 */     Object marginBorder = new BasicBorders.MarginBorder();
/* 170:356 */     Object checkBoxMargin = microLayout.getCheckBoxMargin();
/* 171:    */     
/* 172:358 */     Object etchedBorder = new UIDefaults.ProxyLazyValue("javax.swing.plaf.BorderUIResource", "getEtchedBorderUIResource");
/* 173:    */     
/* 174:    */ 
/* 175:361 */     Object buttonBorder = new SimpleProxyLazyValue("com.jgoodies.looks.windows.WindowsLookAndFeel", "getButtonBorder");
/* 176:    */     
/* 177:    */ 
/* 178:    */ 
/* 179:365 */     Object menuBorder = isXP ? WindowsBorders.getXPMenuBorder() : WindowsBorders.getMenuBorder();
/* 180:    */     
/* 181:    */ 
/* 182:    */ 
/* 183:369 */     Object menuBarEmptyBorder = marginBorder;
/* 184:370 */     Object menuBarSeparatorBorder = WindowsBorders.getSeparatorBorder();
/* 185:371 */     Object menuBarEtchedBorder = WindowsBorders.getEtchedBorder();
/* 186:372 */     Object menuBarHeaderBorder = WindowsBorders.getMenuBarHeaderBorder();
/* 187:    */     
/* 188:374 */     Object toolBarEmptyBorder = marginBorder;
/* 189:375 */     Object toolBarSeparatorBorder = WindowsBorders.getSeparatorBorder();
/* 190:376 */     Object toolBarEtchedBorder = WindowsBorders.getEtchedBorder();
/* 191:377 */     Object toolBarHeaderBorder = WindowsBorders.getToolBarHeaderBorder();
/* 192:    */     
/* 193:379 */     Object buttonMargin = microLayout.getButtonMargin();
/* 194:    */     
/* 195:381 */     Object toolBarSeparatorSize = LookUtils.IS_JAVA_1_4_2_OR_LATER ? null : new DimensionUIResource(6, Options.getDefaultIconSize().height);
/* 196:    */     
/* 197:    */ 
/* 198:    */ 
/* 199:385 */     Object textInsets = microLayout.getTextInsets();
/* 200:386 */     Object wrappedTextInsets = microLayout.getWrappedTextInsets();
/* 201:387 */     Insets comboEditorInsets = microLayout.getComboBoxEditorInsets();
/* 202:    */     
/* 203:389 */     int comboBorderSize = microLayout.getComboBorderSize();
/* 204:390 */     int comboPopupBorderSize = microLayout.getComboPopupBorderSize();
/* 205:391 */     int comboRendererGap = comboEditorInsets.left + comboBorderSize - comboPopupBorderSize;
/* 206:392 */     Object comboRendererBorder = new EmptyBorder(1, comboRendererGap, 1, comboRendererGap);
/* 207:393 */     Object comboTableEditorInsets = new Insets(0, 0, 0, 0);
/* 208:    */     
/* 209:395 */     Object popupMenuSeparatorMargin = microLayout.getPopupMenuSeparatorMargin();
/* 210:    */     
/* 211:    */ 
/* 212:398 */     int treeFontSize = table.getFont("Tree.font").getSize();
/* 213:399 */     Integer rowHeight = new Integer(treeFontSize + 6);
/* 214:    */     
/* 215:401 */     Class superclass = getClass().getSuperclass();
/* 216:402 */     Color controlColor = table.getColor("control");
/* 217:403 */     Object disabledTextBackground = table.getColor("TextField.disabledBackground");
/* 218:404 */     Object inactiveTextBackground = table.getColor("TextField.inactiveBackground");
/* 219:    */     
/* 220:406 */     Object comboBoxDisabledBackground = (isVista) && (isXP) ? table.getColor("ComboBox.background") : disabledTextBackground;
/* 221:    */     
/* 222:    */ 
/* 223:    */ 
/* 224:410 */     Object menuBarBackground = isXP ? table.get("control") : table.get("menu");
/* 225:    */     
/* 226:    */ 
/* 227:413 */     Object menuSelectionBackground = isXP ? table.get("MenuItem.selectionBackground") : table.get("Menu.background");
/* 228:    */     
/* 229:    */ 
/* 230:416 */     Object menuSelectionForeground = isXP ? table.get("MenuItem.selectionForeground") : table.get("Menu.foreground");
/* 231:    */     
/* 232:    */ 
/* 233:    */ 
/* 234:420 */     Character passwordEchoChar = new Character(isXP ? '●' : '*');
/* 235:    */     
/* 236:422 */     Object[] defaults = { "Button.border", buttonBorder, "Button.margin", buttonMargin, "CheckBox.border", marginBorder, "CheckBox.margin", checkBoxMargin, "ComboBox.disabledBackground", comboBoxDisabledBackground, "ComboBox.editorBorder", marginBorder, "ComboBox.editorColumns", new Integer(5), "ComboBox.editorInsets", comboEditorInsets, "ComboBox.tableEditorInsets", comboTableEditorInsets, "ComboBox.rendererBorder", comboRendererBorder, "EditorPane.margin", wrappedTextInsets, "Menu.border", menuBorder, "Menu.borderPainted", Boolean.TRUE, "Menu.background", menuBarBackground, "Menu.selectionForeground", menuSelectionForeground, "Menu.selectionBackground", menuSelectionBackground, "MenuBar.background", menuBarBackground, "MenuBar.border", menuBarSeparatorBorder, "MenuBar.emptyBorder", menuBarEmptyBorder, "MenuBar.separatorBorder", menuBarSeparatorBorder, "MenuBar.etchedBorder", menuBarEtchedBorder, "MenuBar.headerBorder", menuBarHeaderBorder, "FormattedTextField.disabledBackground", disabledTextBackground, "FormattedTextField.inactiveBackground", inactiveTextBackground, "FormattedTextField.margin", textInsets, "PasswordField.margin", textInsets, "PasswordField.echoChar", passwordEchoChar, "PopupMenu.border", WindowsBorders.getPopupMenuBorder(), "PopupMenu.noMarginBorder", WindowsBorders.getNoMarginPopupMenuBorder(), "PopupMenuSeparator.margin", popupMenuSeparatorMargin, "ScrollPane.etchedBorder", etchedBorder, "Spinner.defaultEditorInsets", textInsets, "RadioButton.border", marginBorder, "RadioButton.margin", checkBoxMargin, "Table.gridColor", controlColor, "TextArea.margin", wrappedTextInsets, "TextArea.disabledBackground", disabledTextBackground, "TextArea.inactiveBackground", inactiveTextBackground, "TextField.margin", textInsets, "ToggleButton.margin", buttonMargin, "ToolBar.emptyBorder", toolBarEmptyBorder, "ToolBar.separatorBorder", toolBarSeparatorBorder, "ToolBar.etchedBorder", toolBarEtchedBorder, "ToolBar.headerBorder", toolBarHeaderBorder, "ToolBar.separatorSize", toolBarSeparatorSize, "ToolBar.margin", new InsetsUIResource(0, 10, 0, 0), "Tree.selectionBorderColor", controlColor, "Tree.rowHeight", rowHeight };
/* 237:492 */     if (LookUtils.IS_JAVA_1_4) {
/* 238:493 */       defaults = append(defaults, new Object[] { "InternalFrame.icon", makeIcon(superclass, "icons/JavaCup.gif"), "OptionPane.errorIcon", isXP ? makeIcon(getClass(), "icons/xp/Error.png") : makeIcon(superclass, "icons/Error.gif"), "OptionPane.informationIcon", isXP ? makeIcon(getClass(), "icons/xp/Inform.png") : makeIcon(superclass, "icons/Inform.gif"), "OptionPane.warningIcon", isXP ? makeIcon(getClass(), "icons/xp/Warn.png") : makeIcon(superclass, "icons/Warn.gif"), "OptionPane.questionIcon", isXP ? makeIcon(getClass(), "icons/xp/Inform.png") : makeIcon(superclass, "icons/Question.gif") });
/* 239:    */     }
/* 240:505 */     if ((LookUtils.IS_JAVA_1_4) || (LookUtils.IS_JAVA_5)) {
/* 241:506 */       defaults = append(defaults, new Object[] { "Tree.openIcon", isXP ? makeIcon(getClass(), "icons/xp/TreeOpen.png") : makeIcon(getClass(), "icons/TreeOpen.gif"), "Tree.closedIcon", isXP ? makeIcon(getClass(), "icons/xp/TreeClosed.png") : makeIcon(getClass(), "icons/TreeClosed.gif") });
/* 242:    */     }
/* 243:513 */     if (LookUtils.IS_JAVA_6_OR_LATER) {
/* 244:514 */       defaults = append(defaults, new Object[] { "Spinner.border", table.get("TextField.border") });
/* 245:    */     }
/* 246:518 */     table.putDefaults(defaults);
/* 247:    */   }
/* 248:    */   
/* 249:    */   private void initComponentDefaultsClassic(UIDefaults table)
/* 250:    */   {
/* 251:525 */     Object checkBoxIcon = new SimpleProxyLazyValue("com.jgoodies.looks.windows.WindowsLookAndFeel", "getCheckBoxIcon");
/* 252:    */     
/* 253:    */ 
/* 254:    */ 
/* 255:529 */     Object radioButtonIcon = new SimpleProxyLazyValue("com.jgoodies.looks.windows.WindowsLookAndFeel", "getRadioButtonIcon");
/* 256:    */     
/* 257:    */ 
/* 258:    */ 
/* 259:533 */     Border winInsetBorder = new BasicBorders.FieldBorder(table.getColor("controlShadow"), table.getColor("controlDkShadow"), table.getColor("controlHighlight"), table.getColor("controlLtHighlight"));
/* 260:    */     
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:539 */     Object[] defaults = { "CheckBox.checkColor", table.get("controlText"), "CheckBox.icon", checkBoxIcon, "RadioButton.checkColor", table.get("controlText"), "RadioButton.icon", radioButtonIcon, "Table.scrollPaneBorder", winInsetBorder };
/* 266:    */     
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */ 
/* 273:547 */     table.putDefaults(defaults);
/* 274:    */   }
/* 275:    */   
/* 276:    */   private void initComponentDefaultsXP14(UIDefaults table)
/* 277:    */   {
/* 278:554 */     Object[] defaults = { "TitledBorder.titleColor", table.getColor("activeCaption") };
/* 279:    */     
/* 280:    */ 
/* 281:557 */     table.putDefaults(defaults);
/* 282:    */   }
/* 283:    */   
/* 284:    */   private void initFontDefaults(UIDefaults table)
/* 285:    */   {
/* 286:564 */     FontPolicy fontChoicePolicy = getFontPolicy();
/* 287:565 */     FontSet fontSet = fontChoicePolicy.getFontSet("Windows", table);
/* 288:566 */     initFontDefaults(table, fontSet);
/* 289:    */   }
/* 290:    */   
/* 291:    */   private void initMenuItemDefaults(UIDefaults table, MicroLayout microLayout)
/* 292:    */   {
/* 293:571 */     Object menuMargin = microLayout.getMenuMargin();
/* 294:572 */     Object menuItemMargin = microLayout.getMenuItemMargin();
/* 295:573 */     Icon menuItemCheckIcon = new MinimumSizedIcon();
/* 296:574 */     Object[] defaults = { "Menu.margin", menuMargin, "MenuItem.borderPainted", Boolean.TRUE, "MenuItem.checkIcon", menuItemCheckIcon, "MenuItem.margin", menuItemMargin, "CheckBoxMenuItem.margin", menuItemMargin, "RadioButtonMenuItem.margin", menuItemMargin };
/* 297:    */     
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:584 */     table.putDefaults(defaults);
/* 307:    */   }
/* 308:    */   
/* 309:    */   private static void initFontDefaults(UIDefaults table, FontSet fontSet)
/* 310:    */   {
/* 311:596 */     Font controlFont = fontSet.getControlFont();
/* 312:597 */     Font menuFont = fontSet.getMenuFont();
/* 313:598 */     Font messageFont = fontSet.getMessageFont();
/* 314:599 */     Font toolTipFont = fontSet.getSmallFont();
/* 315:600 */     Font titleFont = fontSet.getTitleFont();
/* 316:601 */     Font windowFont = fontSet.getWindowTitleFont();
/* 317:    */     
/* 318:603 */     Object[] defaults = { "Button.font", controlFont, "CheckBox.font", controlFont, "ColorChooser.font", controlFont, "ComboBox.font", controlFont, "EditorPane.font", controlFont, "FormattedTextField.font", controlFont, "Label.font", controlFont, "List.font", controlFont, "Panel.font", controlFont, "PasswordField.font", controlFont, "ProgressBar.font", controlFont, "RadioButton.font", controlFont, "ScrollPane.font", controlFont, "Spinner.font", controlFont, "TabbedPane.font", controlFont, "Table.font", controlFont, "TableHeader.font", controlFont, "TextArea.font", controlFont, "TextField.font", controlFont, "TextPane.font", controlFont, "ToolBar.font", controlFont, "ToggleButton.font", controlFont, "Tree.font", controlFont, "Viewport.font", controlFont, "InternalFrame.titleFont", windowFont, "OptionPane.font", messageFont, "OptionPane.messageFont", messageFont, "OptionPane.buttonFont", messageFont, "TitledBorder.font", titleFont, "ToolTip.font", toolTipFont, "CheckBoxMenuItem.font", menuFont, "CheckBoxMenuItem.acceleratorFont", menuFont, "Menu.font", menuFont, "Menu.acceleratorFont", menuFont, "MenuBar.font", menuFont, "MenuItem.font", menuFont, "MenuItem.acceleratorFont", menuFont, "PopupMenu.font", menuFont, "RadioButtonMenuItem.font", menuFont, "RadioButtonMenuItem.acceleratorFont", menuFont };
/* 319:    */     
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:    */ 
/* 330:    */ 
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */ 
/* 349:    */ 
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:    */ 
/* 356:    */ 
/* 357:    */ 
/* 358:    */ 
/* 359:    */ 
/* 360:    */ 
/* 361:    */ 
/* 362:647 */     table.putDefaults(defaults);
/* 363:    */   }
/* 364:    */   
/* 365:    */   public static Border getButtonBorder()
/* 366:    */   {
/* 367:654 */     return WindowsBorders.getButtonBorder();
/* 368:    */   }
/* 369:    */   
/* 370:    */   public static Icon getCheckBoxIcon()
/* 371:    */   {
/* 372:658 */     return WindowsIconFactory.getCheckBoxIcon();
/* 373:    */   }
/* 374:    */   
/* 375:    */   public static Icon getRadioButtonIcon()
/* 376:    */   {
/* 377:662 */     return WindowsIconFactory.getRadioButtonIcon();
/* 378:    */   }
/* 379:    */   
/* 380:    */   private static Object[] append(Object[] source, String key, Object value)
/* 381:    */   {
/* 382:675 */     int length = source.length;
/* 383:676 */     Object[] destination = new Object[length + 2];
/* 384:677 */     System.arraycopy(source, 0, destination, 0, length);
/* 385:678 */     destination[length] = key;
/* 386:679 */     destination[(length + 1)] = value;
/* 387:680 */     return destination;
/* 388:    */   }
/* 389:    */   
/* 390:    */   private static Object[] append(Object[] source, Object[] keysAndValues)
/* 391:    */   {
/* 392:691 */     int length = source.length;
/* 393:692 */     Object[] destination = new Object[length + keysAndValues.length];
/* 394:693 */     System.arraycopy(source, 0, destination, 0, length);
/* 395:694 */     for (int i = 0; i < keysAndValues.length; i++) {
/* 396:695 */       destination[(length + i)] = keysAndValues[i];
/* 397:    */     }
/* 398:697 */     return destination;
/* 399:    */   }
/* 400:    */   
/* 401:    */   private static class SimpleProxyLazyValue
/* 402:    */     implements UIDefaults.LazyValue
/* 403:    */   {
/* 404:    */     private final String className;
/* 405:    */     private final String methodName;
/* 406:    */     
/* 407:    */     public SimpleProxyLazyValue(String c, String m)
/* 408:    */     {
/* 409:727 */       this.className = c;
/* 410:728 */       this.methodName = m;
/* 411:    */     }
/* 412:    */     
/* 413:    */     public Object createValue(UIDefaults table)
/* 414:    */     {
/* 415:739 */       Object instance = null;
/* 416:    */       try
/* 417:    */       {
/* 418:743 */         ClassLoader classLoader = table != null ? (ClassLoader)table.get("ClassLoader") : Thread.currentThread().getContextClassLoader();
/* 419:746 */         if (classLoader == null) {
/* 420:747 */           classLoader = getClass().getClassLoader();
/* 421:    */         }
/* 422:749 */         Class c = Class.forName(this.className, true, classLoader);
/* 423:750 */         Method m = c.getMethod(this.methodName, null);
/* 424:751 */         instance = m.invoke(c, null);
/* 425:    */       }
/* 426:    */       catch (Throwable t)
/* 427:    */       {
/* 428:753 */         LookUtils.log("Problem creating " + this.className + " with method " + this.methodName + t);
/* 429:    */       }
/* 430:756 */       return instance;
/* 431:    */     }
/* 432:    */   }
/* 433:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsLookAndFeel
 * JD-Core Version:    0.7.0.1
 */
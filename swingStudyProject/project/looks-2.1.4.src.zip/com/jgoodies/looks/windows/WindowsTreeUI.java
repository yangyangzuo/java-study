/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.beans.PropertyChangeEvent;
/*   6:    */ import java.beans.PropertyChangeListener;
/*   7:    */ import javax.swing.Icon;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ import javax.swing.plaf.ComponentUI;
/*  10:    */ 
/*  11:    */ public final class WindowsTreeUI
/*  12:    */   extends com.sun.java.swing.plaf.windows.WindowsTreeUI
/*  13:    */ {
/*  14:    */   private boolean linesEnabled;
/*  15:    */   private PropertyChangeListener lineStyleHandler;
/*  16:    */   
/*  17:    */   public WindowsTreeUI()
/*  18:    */   {
/*  19: 77 */     this.linesEnabled = true;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static ComponentUI createUI(JComponent b)
/*  23:    */   {
/*  24: 81 */     return new WindowsTreeUI();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void installUI(JComponent c)
/*  28:    */   {
/*  29: 88 */     super.installUI(c);
/*  30: 89 */     updateLineStyle(c.getClientProperty("JTree.lineStyle"));
/*  31: 90 */     this.lineStyleHandler = new LineStyleHandler(null);
/*  32: 91 */     c.addPropertyChangeListener(this.lineStyleHandler);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void uninstallUI(JComponent c)
/*  36:    */   {
/*  37: 95 */     c.removePropertyChangeListener(this.lineStyleHandler);
/*  38: 96 */     super.uninstallUI(c);
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected void paintVerticalLine(Graphics g, JComponent c, int x, int top, int bottom)
/*  42:    */   {
/*  43:103 */     if (this.linesEnabled) {
/*  44:104 */       super.paintVerticalLine(g, c, x, top, bottom);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   protected void paintHorizontalLine(Graphics g, JComponent c, int y, int left, int right)
/*  49:    */   {
/*  50:109 */     if (this.linesEnabled) {
/*  51:110 */       super.paintHorizontalLine(g, c, y, left, right);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected void drawCentered(Component c, Graphics graphics, Icon icon, int x, int y)
/*  56:    */   {
/*  57:116 */     icon.paintIcon(c, graphics, x - icon.getIconWidth() / 2 - 1, y - icon.getIconHeight() / 2);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private void updateLineStyle(Object lineStyle)
/*  61:    */   {
/*  62:125 */     this.linesEnabled = (!"None".equals(lineStyle));
/*  63:    */   }
/*  64:    */   
/*  65:    */   private class LineStyleHandler
/*  66:    */     implements PropertyChangeListener
/*  67:    */   {
/*  68:    */     LineStyleHandler(WindowsTreeUI.1 x1)
/*  69:    */     {
/*  70:129 */       this();
/*  71:    */     }
/*  72:    */     
/*  73:    */     public void propertyChange(PropertyChangeEvent e)
/*  74:    */     {
/*  75:131 */       String name = e.getPropertyName();
/*  76:132 */       Object value = e.getNewValue();
/*  77:133 */       if (name.equals("JTree.lineStyle")) {
/*  78:134 */         WindowsTreeUI.this.updateLineStyle(value);
/*  79:    */       }
/*  80:    */     }
/*  81:    */     
/*  82:    */     private LineStyleHandler() {}
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsTreeUI
 * JD-Core Version:    0.7.0.1
 */
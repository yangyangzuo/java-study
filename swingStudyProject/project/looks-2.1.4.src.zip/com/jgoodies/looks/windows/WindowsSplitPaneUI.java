/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import javax.swing.JComponent;
/*  4:   */ import javax.swing.plaf.ComponentUI;
/*  5:   */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*  6:   */ 
/*  7:   */ public final class WindowsSplitPaneUI
/*  8:   */   extends com.sun.java.swing.plaf.windows.WindowsSplitPaneUI
/*  9:   */ {
/* 10:   */   public static ComponentUI createUI(JComponent x)
/* 11:   */   {
/* 12:54 */     return new WindowsSplitPaneUI();
/* 13:   */   }
/* 14:   */   
/* 15:   */   public BasicSplitPaneDivider createDefaultDivider()
/* 16:   */   {
/* 17:62 */     return new WindowsSplitPaneDivider(this);
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsSplitPaneUI
 * JD-Core Version:    0.7.0.1
 */
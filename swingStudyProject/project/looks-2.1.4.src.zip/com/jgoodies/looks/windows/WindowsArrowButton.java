/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import javax.swing.UIManager;
/*   7:    */ import javax.swing.plaf.basic.BasicArrowButton;
/*   8:    */ 
/*   9:    */ final class WindowsArrowButton
/*  10:    */   extends BasicArrowButton
/*  11:    */ {
/*  12:    */   public WindowsArrowButton(int direction)
/*  13:    */   {
/*  14: 55 */     super(direction);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public Dimension getPreferredSize()
/*  18:    */   {
/*  19: 59 */     int width = Math.max(5, UIManager.getInt("ScrollBar.width"));
/*  20: 60 */     return new Dimension(width, width);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public void paintTriangle(Graphics g, int x, int y, int size, int triangleDirection, boolean isEnabled)
/*  24:    */   {
/*  25: 70 */     Color oldColor = g.getColor();
/*  26:    */     
/*  27:    */ 
/*  28: 73 */     int j = 0;
/*  29: 74 */     size = Math.max(size, 2);
/*  30: 75 */     int mid = (size - 1) / 2;
/*  31:    */     
/*  32: 77 */     g.translate(x, y);
/*  33: 78 */     if (isEnabled) {
/*  34: 79 */       g.setColor(Color.black);
/*  35:    */     } else {
/*  36: 81 */       g.setColor(UIManager.getColor("controlShadow"));
/*  37:    */     }
/*  38:    */     int i;
/*  39:    */     int i;
/*  40: 83 */     switch (triangleDirection)
/*  41:    */     {
/*  42:    */     case 1: 
/*  43: 85 */       for (i = 0; i < size; i++) {
/*  44: 86 */         g.drawLine(mid - i, i, mid + i, i);
/*  45:    */       }
/*  46: 88 */       if (!isEnabled)
/*  47:    */       {
/*  48: 89 */         g.setColor(UIManager.getColor("controlLtHighlight"));
/*  49: 90 */         g.drawLine(mid - i + 2, i, mid + i, i);
/*  50:    */       }
/*  51:    */       break;
/*  52:    */     case 5: 
/*  53: 94 */       if (!isEnabled)
/*  54:    */       {
/*  55: 95 */         g.translate(1, 1);
/*  56: 96 */         g.setColor(UIManager.getColor("controlLtHighlight"));
/*  57: 97 */         for (i = size - 1; i >= 0; i--)
/*  58:    */         {
/*  59: 98 */           g.drawLine(mid - i, j, mid + i, j);
/*  60: 99 */           j++;
/*  61:    */         }
/*  62:101 */         g.translate(-1, -1);
/*  63:102 */         g.setColor(UIManager.getColor("controlShadow"));
/*  64:    */       }
/*  65:105 */       j = 0;
/*  66:106 */       for (i = size - 1; i >= 0;)
/*  67:    */       {
/*  68:107 */         g.drawLine(mid - i, j, mid + i, j);
/*  69:108 */         j++;i--; continue;
/*  70:112 */         for (i = 0; i < size; i++) {
/*  71:113 */           g.drawLine(i, mid - i, i, mid + i);
/*  72:    */         }
/*  73:115 */         if (!isEnabled)
/*  74:    */         {
/*  75:116 */           g.setColor(UIManager.getColor("controlLtHighlight"));
/*  76:117 */           g.drawLine(i, mid - i + 2, i, mid + i); break;
/*  77:121 */           if (!isEnabled)
/*  78:    */           {
/*  79:122 */             g.translate(1, 1);
/*  80:123 */             g.setColor(UIManager.getColor("controlLtHighlight"));
/*  81:124 */             for (i = size - 1; i >= 0; i--)
/*  82:    */             {
/*  83:125 */               g.drawLine(j, mid - i, j, mid + i);
/*  84:126 */               j++;
/*  85:    */             }
/*  86:128 */             g.translate(-1, -1);
/*  87:129 */             g.setColor(UIManager.getColor("controlShadow"));
/*  88:    */           }
/*  89:132 */           j = 0;
/*  90:133 */           for (int i = size - 1; i >= 0; i--)
/*  91:    */           {
/*  92:134 */             g.drawLine(j, mid - i, j, mid + i);
/*  93:135 */             j++;
/*  94:    */           }
/*  95:    */         }
/*  96:    */       }
/*  97:    */     }
/*  98:139 */     g.translate(-x, -y);
/*  99:140 */     g.setColor(oldColor);
/* 100:    */   }
/* 101:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsArrowButton
 * JD-Core Version:    0.7.0.1
 */
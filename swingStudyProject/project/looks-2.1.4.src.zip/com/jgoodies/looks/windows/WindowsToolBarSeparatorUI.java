/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.LookUtils;
/*  4:   */ import java.awt.Color;
/*  5:   */ import java.awt.Dimension;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import javax.swing.JSeparator;
/*  9:   */ import javax.swing.UIManager;
/* 10:   */ import javax.swing.plaf.ComponentUI;
/* 11:   */ import javax.swing.plaf.basic.BasicToolBarSeparatorUI;
/* 12:   */ 
/* 13:   */ public final class WindowsToolBarSeparatorUI
/* 14:   */   extends BasicToolBarSeparatorUI
/* 15:   */ {
/* 16:58 */   private static final int VERTICAL = LookUtils.IS_JAVA_1_4_2_OR_LATER ? 1 : 0;
/* 17:   */   private static WindowsToolBarSeparatorUI toolBarSeparatorUI;
/* 18:   */   
/* 19:   */   public static ComponentUI createUI(JComponent c)
/* 20:   */   {
/* 21:66 */     if (toolBarSeparatorUI == null) {
/* 22:67 */       toolBarSeparatorUI = new WindowsToolBarSeparatorUI();
/* 23:   */     }
/* 24:69 */     return toolBarSeparatorUI;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void paint(Graphics g, JComponent c)
/* 28:   */   {
/* 29:73 */     Color temp = g.getColor();
/* 30:   */     
/* 31:75 */     Color shadowColor = UIManager.getColor("ToolBar.shadow");
/* 32:76 */     Color highlightColor = UIManager.getColor("ToolBar.highlight");
/* 33:   */     
/* 34:78 */     Dimension size = c.getSize();
/* 35:80 */     if (((JSeparator)c).getOrientation() == VERTICAL)
/* 36:   */     {
/* 37:81 */       int x = size.width / 2 - 1;
/* 38:82 */       g.setColor(shadowColor);
/* 39:83 */       g.drawLine(x, 0, x, size.height - 1);
/* 40:84 */       g.setColor(highlightColor);
/* 41:85 */       g.drawLine(x + 1, 0, x + 1, size.height - 1);
/* 42:   */     }
/* 43:   */     else
/* 44:   */     {
/* 45:87 */       int y = size.height / 2 - 1;
/* 46:88 */       g.setColor(shadowColor);
/* 47:89 */       g.drawLine(0, y, size.width - 1, y);
/* 48:90 */       g.setColor(highlightColor);
/* 49:91 */       g.drawLine(0, y + 1, size.width - 1, y + 1);
/* 50:   */     }
/* 51:93 */     g.setColor(temp);
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsToolBarSeparatorUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Graphics;
/*   4:    */ import javax.swing.UIManager;
/*   5:    */ 
/*   6:    */ final class WindowsUtils
/*   7:    */ {
/*   8:    */   public static void drawRoundedDashedRect(Graphics g, int x, int y, int width, int height)
/*   9:    */   {
/*  10:195 */     for (int vx = x + 1; vx < x + width; vx += 2)
/*  11:    */     {
/*  12:196 */       g.fillRect(vx, y, 1, 1);
/*  13:197 */       g.fillRect(vx, y + height - 1, 1, 1);
/*  14:    */     }
/*  15:199 */     int offset = (width + 1) % 2;
/*  16:200 */     for (int vy = y + 1; vy < y + height - offset; vy += 2)
/*  17:    */     {
/*  18:201 */       g.fillRect(x, vy, 1, 1);
/*  19:202 */       g.fillRect(x + width - 1, vy + offset, 1, 1);
/*  20:    */     }
/*  21:    */   }
/*  22:    */   
/*  23:    */   static void drawFlush3DBorder(Graphics g, int x, int y, int w, int h)
/*  24:    */   {
/*  25:208 */     g.translate(x, y);
/*  26:209 */     g.setColor(UIManager.getColor("controlLtHighlight"));
/*  27:210 */     g.drawLine(0, 0, w - 2, 0);
/*  28:211 */     g.drawLine(0, 0, 0, h - 2);
/*  29:212 */     g.setColor(UIManager.getColor("controlShadow"));
/*  30:213 */     g.drawLine(w - 1, 0, w - 1, h - 1);
/*  31:214 */     g.drawLine(0, h - 1, w - 1, h - 1);
/*  32:215 */     g.translate(-x, -y);
/*  33:    */   }
/*  34:    */   
/*  35:    */   static void drawPressed3DBorder(Graphics g, int x, int y, int w, int h)
/*  36:    */   {
/*  37:220 */     g.translate(x, y);
/*  38:221 */     g.setColor(UIManager.getColor("controlShadow"));
/*  39:222 */     g.drawLine(0, 0, w - 2, 0);
/*  40:223 */     g.drawLine(0, 0, 0, h - 2);
/*  41:224 */     g.setColor(UIManager.getColor("controlLtHighlight"));
/*  42:225 */     g.drawLine(w - 1, 0, w - 1, h - 1);
/*  43:226 */     g.drawLine(0, h - 1, w - 1, h - 1);
/*  44:227 */     g.translate(-x, -y);
/*  45:    */   }
/*  46:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsUtils
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import javax.swing.JComponent;
/*  4:   */ import javax.swing.plaf.ComponentUI;
/*  5:   */ import javax.swing.plaf.basic.BasicSeparatorUI;
/*  6:   */ 
/*  7:   */ public final class WindowsSeparatorUI
/*  8:   */   extends BasicSeparatorUI
/*  9:   */ {
/* 10:   */   private static ComponentUI separatorUI;
/* 11:   */   
/* 12:   */   public static ComponentUI createUI(JComponent c)
/* 13:   */   {
/* 14:51 */     if (separatorUI == null) {
/* 15:52 */       separatorUI = new WindowsSeparatorUI();
/* 16:   */     }
/* 17:54 */     return separatorUI;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsSeparatorUI
 * JD-Core Version:    0.7.0.1
 */
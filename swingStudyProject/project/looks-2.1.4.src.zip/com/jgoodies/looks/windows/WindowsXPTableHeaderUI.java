/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.sun.java.swing.plaf.windows.WindowsTableHeaderUI;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.ComponentOrientation;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.Point;
/*   9:    */ import java.awt.Rectangle;
/*  10:    */ import javax.swing.CellRendererPane;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ import javax.swing.JTable;
/*  13:    */ import javax.swing.plaf.ComponentUI;
/*  14:    */ import javax.swing.table.JTableHeader;
/*  15:    */ import javax.swing.table.TableCellRenderer;
/*  16:    */ import javax.swing.table.TableColumn;
/*  17:    */ import javax.swing.table.TableColumnModel;
/*  18:    */ 
/*  19:    */ public final class WindowsXPTableHeaderUI
/*  20:    */   extends WindowsTableHeaderUI
/*  21:    */ {
/*  22:    */   private TableCellRenderer xpRenderer;
/*  23:    */   
/*  24:    */   public static ComponentUI createUI(JComponent h)
/*  25:    */   {
/*  26: 63 */     return new WindowsXPTableHeaderUI();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void installUI(JComponent c)
/*  30:    */   {
/*  31: 67 */     super.installUI(c);
/*  32: 68 */     this.xpRenderer = this.header.getDefaultRenderer();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void uninstallUI(JComponent c)
/*  36:    */   {
/*  37: 72 */     this.xpRenderer = null;
/*  38: 73 */     super.uninstallUI(c);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void paint(Graphics g, JComponent c)
/*  42:    */   {
/*  43: 77 */     TableColumnModel cm = this.header.getColumnModel();
/*  44: 78 */     if (cm.getColumnCount() <= 0) {
/*  45: 79 */       return;
/*  46:    */     }
/*  47: 81 */     boolean ltr = this.header.getComponentOrientation().isLeftToRight();
/*  48:    */     
/*  49: 83 */     Rectangle clip = g.getClipBounds();
/*  50: 84 */     Point left = clip.getLocation();
/*  51: 85 */     Point right = new Point(clip.x + clip.width - 1, clip.y);
/*  52: 86 */     int cMin = this.header.columnAtPoint(ltr ? left : right);
/*  53: 87 */     int cMax = this.header.columnAtPoint(ltr ? right : left);
/*  54: 89 */     if (cMin == -1) {
/*  55: 90 */       cMin = 0;
/*  56:    */     }
/*  57: 95 */     if (cMax == -1) {
/*  58: 96 */       cMax = cm.getColumnCount() - 1;
/*  59:    */     }
/*  60: 99 */     TableColumn draggedColumn = this.header.getDraggedColumn();
/*  61:    */     
/*  62:101 */     Rectangle cellRect = this.header.getHeaderRect(cMin);
/*  63:103 */     if (ltr) {
/*  64:104 */       for (int column = cMin; column <= cMax; column++)
/*  65:    */       {
/*  66:105 */         TableColumn aColumn = cm.getColumn(column);
/*  67:106 */         int columnWidth = aColumn.getWidth();
/*  68:107 */         cellRect.width = columnWidth;
/*  69:108 */         if (aColumn != draggedColumn) {
/*  70:109 */           paintCell(g, cellRect, column);
/*  71:    */         }
/*  72:111 */         cellRect.x += columnWidth;
/*  73:    */       }
/*  74:    */     } else {
/*  75:114 */       for (int column = cMax; column >= cMin; column--)
/*  76:    */       {
/*  77:115 */         TableColumn aColumn = cm.getColumn(column);
/*  78:116 */         int columnWidth = aColumn.getWidth();
/*  79:117 */         cellRect.width = columnWidth;
/*  80:118 */         if (aColumn != draggedColumn) {
/*  81:119 */           paintCell(g, cellRect, column);
/*  82:    */         }
/*  83:121 */         cellRect.x += columnWidth;
/*  84:    */       }
/*  85:    */     }
/*  86:126 */     if (draggedColumn != null)
/*  87:    */     {
/*  88:127 */       int draggedColumnIndex = viewIndexForColumn(draggedColumn);
/*  89:128 */       Rectangle draggedCellRect = this.header.getHeaderRect(draggedColumnIndex);
/*  90:    */       
/*  91:    */ 
/*  92:    */ 
/*  93:132 */       g.setColor(this.header.getParent().getBackground());
/*  94:133 */       g.fillRect(draggedCellRect.x, draggedCellRect.y, draggedCellRect.width, draggedCellRect.height);
/*  95:    */       
/*  96:    */ 
/*  97:136 */       draggedCellRect.x += this.header.getDraggedDistance();
/*  98:    */       
/*  99:    */ 
/* 100:139 */       g.setColor(this.header.getBackground());
/* 101:140 */       g.fillRect(draggedCellRect.x, draggedCellRect.y, draggedCellRect.width, draggedCellRect.height);
/* 102:    */       
/* 103:    */ 
/* 104:143 */       paintCell(g, draggedCellRect, draggedColumnIndex);
/* 105:    */     }
/* 106:147 */     this.rendererPane.removeAll();
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex)
/* 110:    */   {
/* 111:151 */     TableColumn aColumn = this.header.getColumnModel().getColumn(columnIndex);
/* 112:152 */     TableCellRenderer renderer = aColumn.getHeaderRenderer();
/* 113:153 */     if (renderer == null) {
/* 114:154 */       renderer = this.header.getDefaultRenderer();
/* 115:    */     }
/* 116:157 */     JTable table = this.header.getTable();
/* 117:158 */     Component background = this.xpRenderer.getTableCellRendererComponent(table, null, false, false, -1, columnIndex);
/* 118:    */     
/* 119:160 */     Component c = renderer.getTableCellRendererComponent(table, aColumn.getHeaderValue(), false, false, -1, columnIndex);
/* 120:163 */     if (c != background)
/* 121:    */     {
/* 122:169 */       this.rendererPane.add(c);
/* 123:170 */       if (!c.isOpaque())
/* 124:    */       {
/* 125:171 */         this.rendererPane.paintComponent(g, background, this.header, cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
/* 126:179 */         if (((c instanceof JComponent)) && ((background instanceof JComponent))) {
/* 127:181 */           ((JComponent)c).setBorder(((JComponent)background).getBorder());
/* 128:    */         }
/* 129:    */       }
/* 130:    */     }
/* 131:187 */     this.rendererPane.paintComponent(g, c, this.header, cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
/* 132:    */   }
/* 133:    */   
/* 134:    */   private int viewIndexForColumn(TableColumn aColumn)
/* 135:    */   {
/* 136:192 */     TableColumnModel cm = this.header.getColumnModel();
/* 137:193 */     for (int column = cm.getColumnCount() - 1; column >= 0; column--) {
/* 138:194 */       if (cm.getColumn(column) == aColumn) {
/* 139:195 */         return column;
/* 140:    */       }
/* 141:    */     }
/* 142:198 */     return -1;
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsXPTableHeaderUI
 * JD-Core Version:    0.7.0.1
 */
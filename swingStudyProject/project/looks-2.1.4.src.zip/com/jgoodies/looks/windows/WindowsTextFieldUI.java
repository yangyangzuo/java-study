/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import javax.swing.JComponent;
/*  4:   */ import javax.swing.plaf.ComponentUI;
/*  5:   */ import javax.swing.text.Caret;
/*  6:   */ 
/*  7:   */ public final class WindowsTextFieldUI
/*  8:   */   extends com.sun.java.swing.plaf.windows.WindowsTextFieldUI
/*  9:   */ {
/* 10:   */   public static ComponentUI createUI(JComponent c)
/* 11:   */   {
/* 12:56 */     return new WindowsTextFieldUI();
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected Caret createCaret()
/* 16:   */   {
/* 17:66 */     return new WindowsFieldCaret();
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsTextFieldUI
 * JD-Core Version:    0.7.0.1
 */
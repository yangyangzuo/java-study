/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.LayoutManager;
/*   9:    */ import javax.swing.ButtonModel;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JSplitPane;
/*  12:    */ import javax.swing.UIManager;
/*  13:    */ import javax.swing.border.Border;
/*  14:    */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*  15:    */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*  16:    */ 
/*  17:    */ final class WindowsSplitPaneDivider
/*  18:    */   extends BasicSplitPaneDivider
/*  19:    */ {
/*  20:    */   private static final int EXT_ONE_TOUCH_SIZE = 5;
/*  21:    */   private static final int EXT_ONE_TOUCH_OFFSET = 2;
/*  22:    */   private static final int EXT_BLOCKSIZE = 6;
/*  23:    */   
/*  24:    */   public final class ExtWindowsDividerLayout
/*  25:    */     implements LayoutManager
/*  26:    */   {
/*  27:    */     public ExtWindowsDividerLayout() {}
/*  28:    */     
/*  29:    */     public void layoutContainer(Container c)
/*  30:    */     {
/*  31: 71 */       JButton theLeftButton = WindowsSplitPaneDivider.this.getLeftButtonFromSuper();
/*  32: 72 */       JButton theRightButton = WindowsSplitPaneDivider.this.getRightButtonFromSuper();
/*  33: 73 */       JSplitPane theSplitPane = WindowsSplitPaneDivider.this.getSplitPaneFromSuper();
/*  34: 74 */       int theOrientation = WindowsSplitPaneDivider.this.getOrientationFromSuper();
/*  35: 75 */       int oneTouchSize = WindowsSplitPaneDivider.this.getOneTouchSize();
/*  36: 76 */       int oneTouchOffset = WindowsSplitPaneDivider.this.getOneTouchOffset();
/*  37: 77 */       int blockSize = 5;
/*  38: 84 */       if ((theLeftButton != null) && (theRightButton != null) && (c == WindowsSplitPaneDivider.this)) {
/*  39: 87 */         if (theSplitPane.isOneTouchExpandable())
/*  40:    */         {
/*  41: 88 */           if (theOrientation == 0)
/*  42:    */           {
/*  43: 89 */             theLeftButton.setBounds(oneTouchOffset, 0, blockSize * 2, blockSize);
/*  44:    */             
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48: 94 */             theRightButton.setBounds(oneTouchOffset + oneTouchSize * 2, 0, blockSize * 2, blockSize);
/*  49:    */           }
/*  50:    */           else
/*  51:    */           {
/*  52:100 */             theLeftButton.setBounds(0, oneTouchOffset, blockSize, blockSize * 2);
/*  53:    */             
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:105 */             theRightButton.setBounds(0, oneTouchOffset + oneTouchSize * 2, blockSize, blockSize * 2);
/*  58:    */           }
/*  59:    */         }
/*  60:    */         else
/*  61:    */         {
/*  62:112 */           theLeftButton.setBounds(-5, -5, 1, 1);
/*  63:113 */           theRightButton.setBounds(-5, -5, 1, 1);
/*  64:    */         }
/*  65:    */       }
/*  66:    */     }
/*  67:    */     
/*  68:    */     public Dimension minimumLayoutSize(Container c)
/*  69:    */     {
/*  70:119 */       return new Dimension(0, 0);
/*  71:    */     }
/*  72:    */     
/*  73:    */     public Dimension preferredLayoutSize(Container c)
/*  74:    */     {
/*  75:122 */       return new Dimension(0, 0);
/*  76:    */     }
/*  77:    */     
/*  78:    */     public void removeLayoutComponent(Component c) {}
/*  79:    */     
/*  80:    */     public void addLayoutComponent(String string, Component c) {}
/*  81:    */   }
/*  82:    */   
/*  83:    */   public WindowsSplitPaneDivider(BasicSplitPaneUI ui)
/*  84:    */   {
/*  85:133 */     super(ui);
/*  86:134 */     setLayout(new ExtWindowsDividerLayout());
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected JButton createLeftOneTouchButton()
/*  90:    */   {
/*  91:142 */     JButton b = new JButton()
/*  92:    */     {
/*  93:144 */       int[][] buffer = { { 0, 0, 0, 2, 2, 0, 0, 0, 0 }, { 0, 0, 2, 1, 1, 1, 0, 0, 0 }, { 0, 2, 1, 1, 1, 1, 1, 0, 0 }, { 2, 1, 1, 1, 1, 1, 1, 1, 0 }, { 0, 3, 3, 3, 3, 3, 3, 3, 3 } };
/*  94:    */       
/*  95:    */       public void setBorder(Border border) {}
/*  96:    */       
/*  97:    */       public void paint(Graphics g)
/*  98:    */       {
/*  99:156 */         JSplitPane theSplitPane = WindowsSplitPaneDivider.this.getSplitPaneFromSuper();
/* 100:157 */         if (theSplitPane != null)
/* 101:    */         {
/* 102:158 */           int theOrientation = WindowsSplitPaneDivider.this.getOrientationFromSuper();
/* 103:159 */           int blockSize = this.buffer.length + 1;
/* 104:    */           
/* 105:    */ 
/* 106:    */ 
/* 107:163 */           Color[] colors = { getBackground(), UIManager.getColor("controlDkShadow"), Color.black, UIManager.getColor("controlLtHighlight") };
/* 108:    */           
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:172 */           g.setColor(getBackground());
/* 117:173 */           g.fillRect(0, 0, getWidth(), getHeight());
/* 118:176 */           if (getModel().isPressed()) {
/* 119:178 */             colors[1] = colors[2];
/* 120:    */           }
/* 121:180 */           if (theOrientation == 0) {
/* 122:182 */             for (int i = 1; i <= this.buffer[0].length; i++) {
/* 123:183 */               for (int j = 1; j < blockSize; j++) {
/* 124:184 */                 if (this.buffer[(j - 1)][(i - 1)] != 0)
/* 125:    */                 {
/* 126:187 */                   g.setColor(colors[this.buffer[(j - 1)][(i - 1)]]);
/* 127:188 */                   g.drawLine(i - 1, j, i - 1, j);
/* 128:    */                 }
/* 129:    */               }
/* 130:    */             }
/* 131:    */           } else {
/* 132:198 */             for (int i = 1; i <= this.buffer[0].length; i++) {
/* 133:199 */               for (int j = 1; j < blockSize; j++) {
/* 134:200 */                 if (this.buffer[(j - 1)][(i - 1)] != 0)
/* 135:    */                 {
/* 136:207 */                   g.setColor(colors[this.buffer[(j - 1)][(i - 1)]]);
/* 137:    */                   
/* 138:209 */                   g.drawLine(j - 1, i, j - 1, i);
/* 139:    */                 }
/* 140:    */               }
/* 141:    */             }
/* 142:    */           }
/* 143:    */         }
/* 144:    */       }
/* 145:216 */     };
/* 146:217 */     b.setFocusPainted(false);
/* 147:218 */     b.setBorderPainted(false);
/* 148:219 */     b.setFocusable(false);
/* 149:220 */     b.setOpaque(false);
/* 150:221 */     return b;
/* 151:    */   }
/* 152:    */   
/* 153:    */   protected JButton createRightOneTouchButton()
/* 154:    */   {
/* 155:229 */     JButton b = new JButton()
/* 156:    */     {
/* 157:231 */       int[][] buffer = { { 2, 2, 2, 2, 2, 2, 2, 2 }, { 0, 1, 1, 1, 1, 1, 1, 3 }, { 0, 0, 1, 1, 1, 1, 3, 0 }, { 0, 0, 0, 1, 1, 3, 0, 0 }, { 0, 0, 0, 0, 3, 0, 0, 0 } };
/* 158:    */       
/* 159:    */       public void setBorder(Border border) {}
/* 160:    */       
/* 161:    */       public void paint(Graphics g)
/* 162:    */       {
/* 163:243 */         JSplitPane theSplitPane = WindowsSplitPaneDivider.this.getSplitPaneFromSuper();
/* 164:244 */         if (theSplitPane != null)
/* 165:    */         {
/* 166:245 */           int theOrientation = WindowsSplitPaneDivider.this.getOrientationFromSuper();
/* 167:246 */           int blockSize = this.buffer.length + 1;
/* 168:    */           
/* 169:    */ 
/* 170:    */ 
/* 171:250 */           Color[] colors = { getBackground(), UIManager.getColor("controlDkShadow"), Color.black, UIManager.getColor("controlLtHighlight") };
/* 172:    */           
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:259 */           g.setColor(getBackground());
/* 181:260 */           g.fillRect(0, 0, getWidth(), getHeight());
/* 182:263 */           if (getModel().isPressed()) {
/* 183:265 */             colors[1] = colors[2];
/* 184:    */           }
/* 185:267 */           if (theOrientation == 0) {
/* 186:269 */             for (int i = 1; i <= this.buffer[0].length; i++) {
/* 187:270 */               for (int j = 1; j < blockSize; j++) {
/* 188:271 */                 if (this.buffer[(j - 1)][(i - 1)] != 0)
/* 189:    */                 {
/* 190:274 */                   g.setColor(colors[this.buffer[(j - 1)][(i - 1)]]);
/* 191:275 */                   g.drawLine(i, j, i, j);
/* 192:    */                 }
/* 193:    */               }
/* 194:    */             }
/* 195:    */           } else {
/* 196:285 */             for (int i = 1; i <= this.buffer[0].length; i++) {
/* 197:286 */               for (int j = 1; j < blockSize; j++) {
/* 198:287 */                 if (this.buffer[(j - 1)][(i - 1)] != 0)
/* 199:    */                 {
/* 200:294 */                   g.setColor(colors[this.buffer[(j - 1)][(i - 1)]]);
/* 201:    */                   
/* 202:296 */                   g.drawLine(j - 1, i, j - 1, i);
/* 203:    */                 }
/* 204:    */               }
/* 205:    */             }
/* 206:    */           }
/* 207:    */         }
/* 208:    */       }
/* 209:302 */     };
/* 210:303 */     b.setFocusPainted(false);
/* 211:304 */     b.setBorderPainted(false);
/* 212:305 */     b.setFocusable(false);
/* 213:306 */     b.setOpaque(false);
/* 214:307 */     return b;
/* 215:    */   }
/* 216:    */   
/* 217:    */   int getBlockSize()
/* 218:    */   {
/* 219:311 */     return 6;
/* 220:    */   }
/* 221:    */   
/* 222:    */   int getOneTouchOffset()
/* 223:    */   {
/* 224:315 */     return 2;
/* 225:    */   }
/* 226:    */   
/* 227:    */   int getOneTouchSize()
/* 228:    */   {
/* 229:319 */     return 5;
/* 230:    */   }
/* 231:    */   
/* 232:    */   int getOrientationFromSuper()
/* 233:    */   {
/* 234:323 */     return this.orientation;
/* 235:    */   }
/* 236:    */   
/* 237:    */   JButton getLeftButtonFromSuper()
/* 238:    */   {
/* 239:327 */     return this.leftButton;
/* 240:    */   }
/* 241:    */   
/* 242:    */   JButton getRightButtonFromSuper()
/* 243:    */   {
/* 244:331 */     return this.rightButton;
/* 245:    */   }
/* 246:    */   
/* 247:    */   JSplitPane getSplitPaneFromSuper()
/* 248:    */   {
/* 249:335 */     return this.splitPane;
/* 250:    */   }
/* 251:    */   
/* 252:    */   public void paint(Graphics g)
/* 253:    */   {
/* 254:339 */     if (this.splitPane.isOpaque())
/* 255:    */     {
/* 256:340 */       Color bgColor = this.splitPane.hasFocus() ? UIManager.getColor("SplitPane.shadow") : getBackground();
/* 257:344 */       if (bgColor != null)
/* 258:    */       {
/* 259:345 */         g.setColor(bgColor);
/* 260:346 */         g.fillRect(0, 0, getWidth(), getHeight());
/* 261:    */       }
/* 262:    */     }
/* 263:349 */     super.paint(g);
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsSplitPaneDivider
 * JD-Core Version:    0.7.0.1
 */
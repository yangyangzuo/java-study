/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.LookUtils;
/*   4:    */ import com.sun.java.swing.plaf.windows.WindowsTextFieldUI;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.ComponentOrientation;
/*   8:    */ import java.awt.Container;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.Graphics;
/*  11:    */ import java.awt.Insets;
/*  12:    */ import java.awt.LayoutManager;
/*  13:    */ import java.awt.Rectangle;
/*  14:    */ import java.beans.PropertyChangeEvent;
/*  15:    */ import java.beans.PropertyChangeListener;
/*  16:    */ import javax.swing.CellRendererPane;
/*  17:    */ import javax.swing.ComboBoxEditor;
/*  18:    */ import javax.swing.DefaultListCellRenderer;
/*  19:    */ import javax.swing.JButton;
/*  20:    */ import javax.swing.JComboBox;
/*  21:    */ import javax.swing.JComponent;
/*  22:    */ import javax.swing.JList;
/*  23:    */ import javax.swing.JPanel;
/*  24:    */ import javax.swing.JScrollBar;
/*  25:    */ import javax.swing.JScrollPane;
/*  26:    */ import javax.swing.JTextField;
/*  27:    */ import javax.swing.ListCellRenderer;
/*  28:    */ import javax.swing.UIManager;
/*  29:    */ import javax.swing.border.Border;
/*  30:    */ import javax.swing.border.EmptyBorder;
/*  31:    */ import javax.swing.plaf.ComponentUI;
/*  32:    */ import javax.swing.plaf.UIResource;
/*  33:    */ import javax.swing.plaf.basic.BasicComboBoxRenderer;
/*  34:    */ import javax.swing.plaf.basic.BasicComboBoxRenderer.UIResource;
/*  35:    */ import javax.swing.plaf.basic.BasicComboBoxUI;
/*  36:    */ import javax.swing.plaf.basic.BasicComboBoxUI.ComboBoxLayoutManager;
/*  37:    */ import javax.swing.plaf.basic.BasicComboPopup;
/*  38:    */ import javax.swing.plaf.basic.ComboPopup;
/*  39:    */ 
/*  40:    */ public class WindowsComboBoxUI
/*  41:    */   extends com.sun.java.swing.plaf.windows.WindowsComboBoxUI
/*  42:    */ {
/*  43:    */   private static final String CELL_EDITOR_KEY = "JComboBox.isTableCellEditor";
/*  44: 75 */   private static final JTextField PHANTOM = new JTextField("Phantom");
/*  45: 77 */   private static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
/*  46: 78 */   private static final Border EMPTY_BORDER = new EmptyBorder(EMPTY_INSETS);
/*  47:    */   private boolean tableCellEditor;
/*  48:    */   private PropertyChangeListener propertyChangeListener;
/*  49:    */   
/*  50:    */   public static ComponentUI createUI(JComponent b)
/*  51:    */   {
/*  52: 88 */     ensurePhantomHasWindowsUI();
/*  53: 89 */     return new WindowsComboBoxUI();
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static void ensurePhantomHasWindowsUI()
/*  57:    */   {
/*  58: 97 */     if (!(PHANTOM.getUI() instanceof WindowsTextFieldUI)) {
/*  59: 98 */       PHANTOM.updateUI();
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void installUI(JComponent c)
/*  64:    */   {
/*  65:106 */     super.installUI(c);
/*  66:107 */     this.tableCellEditor = isTableCellEditor();
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected void installListeners()
/*  70:    */   {
/*  71:111 */     super.installListeners();
/*  72:112 */     this.propertyChangeListener = new TableCellEditorPropertyChangeHandler(null);
/*  73:113 */     this.comboBox.addPropertyChangeListener("JComboBox.isTableCellEditor", this.propertyChangeListener);
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected void uninstallListeners()
/*  77:    */   {
/*  78:117 */     super.uninstallListeners();
/*  79:118 */     this.comboBox.removePropertyChangeListener("JComboBox.isTableCellEditor", this.propertyChangeListener);
/*  80:119 */     this.propertyChangeListener = null;
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected JButton createArrowButton()
/*  84:    */   {
/*  85:129 */     return LookUtils.IS_LAF_WINDOWS_XP_ENABLED ? super.createArrowButton() : new WindowsArrowButton(5);
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected ComboBoxEditor createEditor()
/*  89:    */   {
/*  90:141 */     return new WindowsComboBoxEditor.UIResource(this.tableCellEditor);
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected LayoutManager createLayoutManager()
/*  94:    */   {
/*  95:154 */     return new WindowsComboBoxLayoutManager(null);
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected void configureEditor()
/*  99:    */   {
/* 100:159 */     super.configureEditor();
/* 101:160 */     if (!this.comboBox.isEnabled()) {
/* 102:161 */       this.editor.setBackground(UIManager.getColor("ComboBox.disabledBackground"));
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected ComboPopup createPopup()
/* 107:    */   {
/* 108:170 */     return new WindowsComboPopup(this.comboBox, null);
/* 109:    */   }
/* 110:    */   
/* 111:    */   protected ListCellRenderer createRenderer()
/* 112:    */   {
/* 113:187 */     if (this.tableCellEditor) {
/* 114:188 */       return super.createRenderer();
/* 115:    */     }
/* 116:190 */     BasicComboBoxRenderer renderer = new BasicComboBoxRenderer.UIResource();
/* 117:191 */     renderer.setBorder(UIManager.getBorder("ComboBox.rendererBorder"));
/* 118:192 */     return renderer;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Dimension getMinimumSize(JComponent c)
/* 122:    */   {
/* 123:200 */     if (!this.isMinimumSizeDirty) {
/* 124:201 */       return new Dimension(this.cachedMinimumSize);
/* 125:    */     }
/* 126:203 */     Dimension size = getDisplaySize();
/* 127:204 */     Insets insets = getInsets();
/* 128:205 */     size.height += insets.top + insets.bottom;
/* 129:206 */     int buttonWidth = getEditableButtonWidth();
/* 130:207 */     size.width += insets.left + insets.right + buttonWidth;
/* 131:    */     
/* 132:    */ 
/* 133:    */ 
/* 134:211 */     size.width += 1;
/* 135:    */     
/* 136:    */ 
/* 137:214 */     ListCellRenderer renderer = this.comboBox.getRenderer();
/* 138:215 */     if ((renderer instanceof JComponent))
/* 139:    */     {
/* 140:216 */       JComponent component = (JComponent)renderer;
/* 141:217 */       Insets rendererInsets = component.getInsets();
/* 142:218 */       Insets editorInsets = UIManager.getInsets("ComboBox.editorInsets");
/* 143:219 */       int offsetLeft = Math.max(0, editorInsets.left - rendererInsets.left);
/* 144:220 */       int offsetRight = Math.max(0, editorInsets.right - rendererInsets.right);
/* 145:    */       
/* 146:    */ 
/* 147:223 */       size.width += offsetLeft + offsetRight;
/* 148:    */     }
/* 149:228 */     Dimension textFieldSize = PHANTOM.getMinimumSize();
/* 150:229 */     size.height = ((LookUtils.IS_OS_WINDOWS_VISTA) && (!LookUtils.IS_LAF_WINDOWS_XP_ENABLED) ? textFieldSize.height : Math.max(textFieldSize.height, size.height));
/* 151:    */     
/* 152:    */ 
/* 153:    */ 
/* 154:233 */     this.cachedMinimumSize.setSize(size.width, size.height);
/* 155:234 */     this.isMinimumSizeDirty = false;
/* 156:    */     
/* 157:236 */     return new Dimension(size);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public Dimension getPreferredSize(JComponent c)
/* 161:    */   {
/* 162:244 */     return getMinimumSize(c);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus)
/* 166:    */   {
/* 167:252 */     ListCellRenderer renderer = this.comboBox.getRenderer();
/* 168:    */     
/* 169:254 */     boolean isVistaReadOnlyCombo = isVistaXPStyleReadOnlyCombo();
/* 170:    */     Component c;
/* 171:    */     Component c;
/* 172:256 */     if ((hasFocus) && (!isPopupVisible(this.comboBox)))
/* 173:    */     {
/* 174:257 */       c = renderer.getListCellRendererComponent(this.listBox, this.comboBox.getSelectedItem(), -1, true, false);
/* 175:    */     }
/* 176:    */     else
/* 177:    */     {
/* 178:263 */       c = renderer.getListCellRendererComponent(this.listBox, this.comboBox.getSelectedItem(), -1, false, false);
/* 179:    */       
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:268 */       c.setBackground(UIManager.getColor("ComboBox.background"));
/* 184:    */     }
/* 185:270 */     Border oldBorder = null;
/* 186:271 */     Rectangle originalBounds = new Rectangle(bounds);
/* 187:272 */     if (((c instanceof JComponent)) && (!this.tableCellEditor))
/* 188:    */     {
/* 189:273 */       JComponent component = (JComponent)c;
/* 190:274 */       if (isRendererBorderRemovable(component))
/* 191:    */       {
/* 192:275 */         oldBorder = component.getBorder();
/* 193:276 */         component.setBorder(EMPTY_BORDER);
/* 194:    */       }
/* 195:278 */       Insets rendererInsets = component.getInsets();
/* 196:279 */       Insets editorInsets = UIManager.getInsets("ComboBox.editorInsets");
/* 197:280 */       int offsetLeft = Math.max(0, editorInsets.left - rendererInsets.left);
/* 198:281 */       int offsetRight = Math.max(0, editorInsets.right - rendererInsets.right);
/* 199:282 */       int offsetTop = Math.max(0, editorInsets.top - rendererInsets.top);
/* 200:283 */       int offsetBottom = Math.max(0, editorInsets.bottom - rendererInsets.bottom);
/* 201:284 */       bounds.x += offsetLeft;
/* 202:285 */       bounds.y += offsetTop;
/* 203:286 */       bounds.width -= offsetLeft + offsetRight - 1;
/* 204:287 */       bounds.height -= offsetTop + offsetBottom;
/* 205:    */     }
/* 206:290 */     c.setFont(this.comboBox.getFont());
/* 207:291 */     if ((hasFocus) && (!isPopupVisible(this.comboBox)) && (!isVistaReadOnlyCombo))
/* 208:    */     {
/* 209:292 */       c.setForeground(this.listBox.getSelectionForeground());
/* 210:293 */       c.setBackground(this.listBox.getSelectionBackground());
/* 211:    */     }
/* 212:295 */     else if (this.comboBox.isEnabled())
/* 213:    */     {
/* 214:296 */       c.setForeground(this.comboBox.getForeground());
/* 215:297 */       c.setBackground(this.comboBox.getBackground());
/* 216:    */     }
/* 217:    */     else
/* 218:    */     {
/* 219:299 */       c.setForeground(UIManager.getColor("ComboBox.disabledForeground"));
/* 220:300 */       c.setBackground(UIManager.getColor("ComboBox.disabledBackground"));
/* 221:    */     }
/* 222:305 */     boolean shouldValidate = c instanceof JPanel;
/* 223:    */     
/* 224:307 */     Boolean oldOpaque = null;
/* 225:308 */     if ((isVistaReadOnlyCombo) && ((c instanceof JComponent)) && (!(c instanceof DefaultListCellRenderer)))
/* 226:    */     {
/* 227:309 */       oldOpaque = Boolean.valueOf(c.isOpaque());
/* 228:310 */       ((JComponent)c).setOpaque(false);
/* 229:    */     }
/* 230:312 */     this.currentValuePane.paintComponent(g, c, this.comboBox, bounds.x, bounds.y, bounds.width, bounds.height, shouldValidate);
/* 231:314 */     if (hasFocus)
/* 232:    */     {
/* 233:315 */       Color oldColor = g.getColor();
/* 234:316 */       g.setColor(this.comboBox.getForeground());
/* 235:317 */       if (isVistaReadOnlyCombo)
/* 236:    */       {
/* 237:318 */         int width = originalBounds.width - 2;
/* 238:319 */         if (width % 2 == 0) {
/* 239:320 */           width++;
/* 240:    */         }
/* 241:322 */         WindowsUtils.drawRoundedDashedRect(g, originalBounds.x + 1, originalBounds.y + 1, width, originalBounds.height - 2);
/* 242:    */       }
/* 243:329 */       g.setColor(oldColor);
/* 244:    */     }
/* 245:331 */     if (oldOpaque != null) {
/* 246:332 */       ((JComponent)c).setOpaque(oldOpaque.booleanValue());
/* 247:    */     }
/* 248:334 */     if (oldBorder != null) {
/* 249:335 */       ((JComponent)c).setBorder(oldBorder);
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   protected boolean isRendererBorderRemovable(JComponent rendererComponent)
/* 254:    */   {
/* 255:360 */     if ((rendererComponent instanceof BasicComboBoxRenderer.UIResource)) {
/* 256:361 */       return true;
/* 257:    */     }
/* 258:362 */     Object hint = rendererComponent.getClientProperty("isBorderRemovable");
/* 259:363 */     if (hint != null) {
/* 260:364 */       return Boolean.TRUE.equals(hint);
/* 261:    */     }
/* 262:365 */     Border border = rendererComponent.getBorder();
/* 263:366 */     return border instanceof EmptyBorder;
/* 264:    */   }
/* 265:    */   
/* 266:    */   private boolean isVistaXPStyleReadOnlyCombo()
/* 267:    */   {
/* 268:371 */     return (LookUtils.IS_OS_WINDOWS_VISTA) && (LookUtils.IS_LAF_WINDOWS_XP_ENABLED) && (!this.comboBox.isEditable());
/* 269:    */   }
/* 270:    */   
/* 271:    */   protected Rectangle rectangleForCurrentValue()
/* 272:    */   {
/* 273:381 */     int width = this.comboBox.getWidth();
/* 274:382 */     int height = this.comboBox.getHeight();
/* 275:383 */     Insets insets = getInsets();
/* 276:384 */     int buttonWidth = getEditableButtonWidth();
/* 277:385 */     if (this.arrowButton != null) {
/* 278:386 */       buttonWidth = this.arrowButton.getWidth();
/* 279:    */     }
/* 280:388 */     if (this.comboBox.getComponentOrientation().isLeftToRight()) {
/* 281:389 */       return new Rectangle(insets.left, insets.top, width - (insets.left + insets.right + buttonWidth), height - (insets.top + insets.bottom));
/* 282:    */     }
/* 283:395 */     return new Rectangle(insets.left + buttonWidth, insets.top, width - (insets.left + insets.right + buttonWidth), height - (insets.top + insets.bottom));
/* 284:    */   }
/* 285:    */   
/* 286:    */   private int getEditableButtonWidth()
/* 287:    */   {
/* 288:412 */     return UIManager.getInt("ScrollBar.width");
/* 289:    */   }
/* 290:    */   
/* 291:    */   private boolean isTableCellEditor()
/* 292:    */   {
/* 293:423 */     return Boolean.TRUE.equals(this.comboBox.getClientProperty("JComboBox.isTableCellEditor"));
/* 294:    */   }
/* 295:    */   
/* 296:    */   private final class WindowsComboBoxLayoutManager
/* 297:    */     extends BasicComboBoxUI.ComboBoxLayoutManager
/* 298:    */   {
/* 299:    */     WindowsComboBoxLayoutManager(WindowsComboBoxUI.1 x1)
/* 300:    */     {
/* 301:436 */       this();
/* 302:    */     }
/* 303:    */     
/* 304:    */     private WindowsComboBoxLayoutManager()
/* 305:    */     {
/* 306:436 */       super();
/* 307:    */     }
/* 308:    */     
/* 309:    */     public void layoutContainer(Container parent)
/* 310:    */     {
/* 311:440 */       JComboBox cb = (JComboBox)parent;
/* 312:    */       
/* 313:442 */       int width = cb.getWidth();
/* 314:443 */       int height = cb.getHeight();
/* 315:    */       
/* 316:445 */       Insets insets = WindowsComboBoxUI.this.getInsets();
/* 317:446 */       int buttonWidth = WindowsComboBoxUI.this.getEditableButtonWidth();
/* 318:447 */       int buttonHeight = height - (insets.top + insets.bottom);
/* 319:449 */       if (WindowsComboBoxUI.this.arrowButton != null) {
/* 320:450 */         if (cb.getComponentOrientation().isLeftToRight()) {
/* 321:451 */           WindowsComboBoxUI.this.arrowButton.setBounds(width - (insets.right + buttonWidth), insets.top, buttonWidth, buttonHeight);
/* 322:    */         } else {
/* 323:457 */           WindowsComboBoxUI.this.arrowButton.setBounds(insets.left, insets.top, buttonWidth, buttonHeight);
/* 324:    */         }
/* 325:    */       }
/* 326:464 */       if (WindowsComboBoxUI.this.editor != null) {
/* 327:465 */         WindowsComboBoxUI.this.editor.setBounds(WindowsComboBoxUI.this.rectangleForCurrentValue());
/* 328:    */       }
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   private static final class WindowsComboPopup
/* 333:    */     extends BasicComboPopup
/* 334:    */   {
/* 335:    */     WindowsComboPopup(JComboBox x0, WindowsComboBoxUI.1 x1)
/* 336:    */     {
/* 337:476 */       this(x0);
/* 338:    */     }
/* 339:    */     
/* 340:    */     private WindowsComboPopup(JComboBox combo)
/* 341:    */     {
/* 342:479 */       super();
/* 343:    */     }
/* 344:    */     
/* 345:    */     protected Rectangle computePopupBounds(int px, int py, int pw, int ph)
/* 346:    */     {
/* 347:511 */       Rectangle defaultBounds = super.computePopupBounds(px, py, pw, ph);
/* 348:512 */       Object popupPrototypeDisplayValue = this.comboBox.getClientProperty("ComboBox.popupPrototypeDisplayValue");
/* 349:514 */       if (popupPrototypeDisplayValue == null) {
/* 350:515 */         return defaultBounds;
/* 351:    */       }
/* 352:518 */       ListCellRenderer renderer = this.list.getCellRenderer();
/* 353:519 */       Component c = renderer.getListCellRendererComponent(this.list, popupPrototypeDisplayValue, -1, true, true);
/* 354:    */       
/* 355:521 */       pw = c.getPreferredSize().width;
/* 356:522 */       boolean hasVerticalScrollBar = this.comboBox.getItemCount() > this.comboBox.getMaximumRowCount();
/* 357:524 */       if (hasVerticalScrollBar)
/* 358:    */       {
/* 359:526 */         JScrollBar verticalBar = this.scroller.getVerticalScrollBar();
/* 360:527 */         pw += verticalBar.getPreferredSize().width;
/* 361:    */       }
/* 362:529 */       Rectangle prototypeBasedBounds = super.computePopupBounds(px, py, pw, ph);
/* 363:530 */       return prototypeBasedBounds.width > defaultBounds.width ? prototypeBasedBounds : defaultBounds;
/* 364:    */     }
/* 365:    */   }
/* 366:    */   
/* 367:    */   private final class TableCellEditorPropertyChangeHandler
/* 368:    */     implements PropertyChangeListener
/* 369:    */   {
/* 370:    */     TableCellEditorPropertyChangeHandler(WindowsComboBoxUI.1 x1)
/* 371:    */     {
/* 372:545 */       this();
/* 373:    */     }
/* 374:    */     
/* 375:    */     public void propertyChange(PropertyChangeEvent evt)
/* 376:    */     {
/* 377:547 */       WindowsComboBoxUI.this.tableCellEditor = WindowsComboBoxUI.this.isTableCellEditor();
/* 378:548 */       if ((WindowsComboBoxUI.this.comboBox.getRenderer() == null) || ((WindowsComboBoxUI.this.comboBox.getRenderer() instanceof UIResource))) {
/* 379:549 */         WindowsComboBoxUI.this.comboBox.setRenderer(WindowsComboBoxUI.this.createRenderer());
/* 380:    */       }
/* 381:551 */       if ((WindowsComboBoxUI.this.comboBox.getEditor() == null) || ((WindowsComboBoxUI.this.comboBox.getEditor() instanceof UIResource))) {
/* 382:552 */         WindowsComboBoxUI.this.comboBox.setEditor(WindowsComboBoxUI.this.createEditor());
/* 383:    */       }
/* 384:    */     }
/* 385:    */     
/* 386:    */     private TableCellEditorPropertyChangeHandler() {}
/* 387:    */   }
/* 388:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsComboBoxUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.LookUtils;
/*   4:    */ import com.jgoodies.looks.common.ExtBasicArrowButtonHandler;
/*   5:    */ import com.jgoodies.looks.common.ExtBasicSpinnerLayout;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.LayoutManager;
/*   9:    */ import javax.swing.JButton;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JPanel;
/*  12:    */ import javax.swing.JSpinner;
/*  13:    */ import javax.swing.JSpinner.DefaultEditor;
/*  14:    */ import javax.swing.JTextField;
/*  15:    */ import javax.swing.UIManager;
/*  16:    */ import javax.swing.border.EmptyBorder;
/*  17:    */ import javax.swing.plaf.ComponentUI;
/*  18:    */ 
/*  19:    */ public final class WindowsSpinnerUI
/*  20:    */   extends com.sun.java.swing.plaf.windows.WindowsSpinnerUI
/*  21:    */ {
/*  22:    */   public static ComponentUI createUI(JComponent b)
/*  23:    */   {
/*  24: 57 */     return new WindowsSpinnerUI();
/*  25:    */   }
/*  26:    */   
/*  27: 67 */   private static final ExtBasicArrowButtonHandler NEXT_BUTTON_HANDLER = new ExtBasicArrowButtonHandler("increment", true);
/*  28: 69 */   private static final ExtBasicArrowButtonHandler PREVIOUS_BUTTON_HANDLER = new ExtBasicArrowButtonHandler("decrement", false);
/*  29:    */   
/*  30:    */   protected Component createPreviousButton()
/*  31:    */   {
/*  32: 87 */     if (LookUtils.IS_LAF_WINDOWS_XP_ENABLED) {
/*  33: 88 */       return super.createPreviousButton();
/*  34:    */     }
/*  35: 90 */     JButton b = new WindowsArrowButton(5);
/*  36: 91 */     b.addActionListener(PREVIOUS_BUTTON_HANDLER);
/*  37: 92 */     b.addMouseListener(PREVIOUS_BUTTON_HANDLER);
/*  38: 93 */     return b;
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected Component createNextButton()
/*  42:    */   {
/*  43:110 */     if (LookUtils.IS_LAF_WINDOWS_XP_ENABLED) {
/*  44:111 */       return super.createNextButton();
/*  45:    */     }
/*  46:113 */     JButton b = new WindowsArrowButton(1);
/*  47:114 */     b.addActionListener(NEXT_BUTTON_HANDLER);
/*  48:115 */     b.addMouseListener(NEXT_BUTTON_HANDLER);
/*  49:116 */     return b;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected JComponent createEditor()
/*  53:    */   {
/*  54:143 */     JComponent editor = this.spinner.getEditor();
/*  55:144 */     configureEditorBorder(editor);
/*  56:145 */     return editor;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected LayoutManager createLayout()
/*  60:    */   {
/*  61:163 */     return new ExtBasicSpinnerLayout();
/*  62:    */   }
/*  63:    */   
/*  64:    */   protected void replaceEditor(JComponent oldEditor, JComponent newEditor)
/*  65:    */   {
/*  66:185 */     this.spinner.remove(oldEditor);
/*  67:186 */     configureEditorBorder(newEditor);
/*  68:187 */     this.spinner.add(newEditor, "Editor");
/*  69:    */   }
/*  70:    */   
/*  71:    */   private void configureEditorBorder(JComponent editor)
/*  72:    */   {
/*  73:195 */     if ((editor instanceof JSpinner.DefaultEditor))
/*  74:    */     {
/*  75:196 */       JSpinner.DefaultEditor defaultEditor = (JSpinner.DefaultEditor)editor;
/*  76:197 */       JTextField editorField = defaultEditor.getTextField();
/*  77:198 */       Insets insets = UIManager.getInsets("Spinner.defaultEditorInsets");
/*  78:199 */       editorField.setBorder(new EmptyBorder(insets));
/*  79:    */     }
/*  80:200 */     else if (((editor instanceof JPanel)) && (editor.getBorder() == null) && (editor.getComponentCount() > 0))
/*  81:    */     {
/*  82:203 */       JComponent editorField = (JComponent)editor.getComponent(0);
/*  83:204 */       Insets insets = UIManager.getInsets("Spinner.defaultEditorInsets");
/*  84:205 */       editorField.setBorder(new EmptyBorder(insets));
/*  85:    */     }
/*  86:    */   }
/*  87:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsSpinnerUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.common.PopupMenuLayout;
/*   4:    */ import java.beans.PropertyChangeEvent;
/*   5:    */ import java.beans.PropertyChangeListener;
/*   6:    */ import javax.swing.JComponent;
/*   7:    */ import javax.swing.JPopupMenu;
/*   8:    */ import javax.swing.LookAndFeel;
/*   9:    */ import javax.swing.plaf.ComponentUI;
/*  10:    */ import javax.swing.plaf.UIResource;
/*  11:    */ 
/*  12:    */ public final class WindowsPopupMenuUI
/*  13:    */   extends com.sun.java.swing.plaf.windows.WindowsPopupMenuUI
/*  14:    */ {
/*  15:    */   private PropertyChangeListener borderListener;
/*  16:    */   
/*  17:    */   public static ComponentUI createUI(JComponent b)
/*  18:    */   {
/*  19: 64 */     return new WindowsPopupMenuUI();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void installDefaults()
/*  23:    */   {
/*  24: 69 */     super.installDefaults();
/*  25: 70 */     installBorder();
/*  26: 71 */     if ((this.popupMenu.getLayout() == null) || ((this.popupMenu.getLayout() instanceof UIResource))) {
/*  27: 73 */       this.popupMenu.setLayout(new PopupMenuLayout(this.popupMenu, 1));
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void installListeners()
/*  32:    */   {
/*  33: 78 */     super.installListeners();
/*  34: 79 */     this.borderListener = new BorderStyleChangeHandler(null);
/*  35: 80 */     this.popupMenu.addPropertyChangeListener("JPopupMenu.noMargin", this.borderListener);
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected void uninstallListeners()
/*  39:    */   {
/*  40: 84 */     this.popupMenu.removePropertyChangeListener("JPopupMenu.noMargin", this.borderListener);
/*  41: 85 */     super.uninstallListeners();
/*  42:    */   }
/*  43:    */   
/*  44:    */   private final class BorderStyleChangeHandler
/*  45:    */     implements PropertyChangeListener
/*  46:    */   {
/*  47:    */     BorderStyleChangeHandler(WindowsPopupMenuUI.1 x1)
/*  48:    */     {
/*  49: 90 */       this();
/*  50:    */     }
/*  51:    */     
/*  52:    */     public void propertyChange(PropertyChangeEvent e)
/*  53:    */     {
/*  54: 93 */       WindowsPopupMenuUI.this.installBorder();
/*  55:    */     }
/*  56:    */     
/*  57:    */     private BorderStyleChangeHandler() {}
/*  58:    */   }
/*  59:    */   
/*  60:    */   private void installBorder()
/*  61:    */   {
/*  62:103 */     boolean useNarrowBorder = Boolean.TRUE.equals(this.popupMenu.getClientProperty("JPopupMenu.noMargin"));
/*  63:    */     
/*  64:105 */     String suffix = useNarrowBorder ? "noMarginBorder" : "border";
/*  65:106 */     LookAndFeel.installBorder(this.popupMenu, "PopupMenu." + suffix);
/*  66:    */   }
/*  67:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsPopupMenuUI
 * JD-Core Version:    0.7.0.1
 */
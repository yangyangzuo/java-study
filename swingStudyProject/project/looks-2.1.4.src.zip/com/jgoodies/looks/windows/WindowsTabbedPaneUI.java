/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.LookUtils;
/*   4:    */ import com.jgoodies.looks.Options;
/*   5:    */ import java.awt.FontMetrics;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.Rectangle;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import javax.swing.Icon;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.JTabbedPane;
/*  14:    */ import javax.swing.SwingUtilities;
/*  15:    */ import javax.swing.plaf.ComponentUI;
/*  16:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  17:    */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*  18:    */ import javax.swing.plaf.basic.BasicTabbedPaneUI.PropertyChangeHandler;
/*  19:    */ import javax.swing.text.View;
/*  20:    */ 
/*  21:    */ public final class WindowsTabbedPaneUI
/*  22:    */   extends com.sun.java.swing.plaf.windows.WindowsTabbedPaneUI
/*  23:    */ {
/*  24: 63 */   private static final boolean IS_XP_LAF_5_OR_LATER = (LookUtils.IS_JAVA_5_OR_LATER) && (LookUtils.IS_LAF_WINDOWS_XP_ENABLED);
/*  25: 67 */   private static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
/*  26: 70 */   private static final int INSET = IS_XP_LAF_5_OR_LATER ? -1 : 1;
/*  27: 71 */   private static final Insets NO_CONTENT_BORDER_NORTH_INSETS = new Insets(INSET, 0, 0, 0);
/*  28: 72 */   private static final Insets NO_CONTENT_BORDER_WEST_INSETS = new Insets(0, INSET, 0, 0);
/*  29: 73 */   private static final Insets NO_CONTENT_BORDER_SOUTH_INSETS = new Insets(0, 0, INSET, 0);
/*  30: 74 */   private static final Insets NO_CONTENT_BORDER_EAST_INSETS = new Insets(0, 0, 0, INSET);
/*  31: 77 */   private static final Insets CONTENT_BORDER_NORTH_INSETS = new Insets(0, 2, 4, 4);
/*  32: 78 */   private static final Insets CONTENT_BORDER_WEST_INSETS = new Insets(2, 0, 4, 4);
/*  33: 79 */   private static final Insets CONTENT_BORDER_SOUTH_INSETS = new Insets(4, 2, 0, 4);
/*  34: 80 */   private static final Insets CONTENT_BORDER_EAST_INSETS = new Insets(2, 4, 4, 0);
/*  35: 86 */   private static boolean isTabIconsEnabled = Options.isTabIconsEnabled();
/*  36:    */   private Boolean noContentBorder;
/*  37:    */   private Boolean embeddedTabs;
/*  38:    */   
/*  39:    */   public static ComponentUI createUI(JComponent x)
/*  40:    */   {
/*  41:109 */     return new WindowsTabbedPaneUI();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void installUI(JComponent c)
/*  45:    */   {
/*  46:119 */     super.installUI(c);
/*  47:120 */     this.embeddedTabs = ((Boolean)c.getClientProperty("jgoodies.embeddedTabs"));
/*  48:121 */     this.noContentBorder = ((Boolean)c.getClientProperty("jgoodies.noContentBorder"));
/*  49:    */   }
/*  50:    */   
/*  51:    */   private boolean hasNoContentBorder()
/*  52:    */   {
/*  53:131 */     return (hasEmbeddedTabs()) || (Boolean.TRUE.equals(this.noContentBorder));
/*  54:    */   }
/*  55:    */   
/*  56:    */   private boolean hasEmbeddedTabs()
/*  57:    */   {
/*  58:138 */     return this.embeddedTabs == null ? false : this.embeddedTabs.booleanValue();
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected PropertyChangeListener createPropertyChangeListener()
/*  62:    */   {
/*  63:149 */     return new MyPropertyChangeHandler(null);
/*  64:    */   }
/*  65:    */   
/*  66:    */   private void doLayout()
/*  67:    */   {
/*  68:153 */     this.tabPane.revalidate();
/*  69:154 */     this.tabPane.repaint();
/*  70:    */   }
/*  71:    */   
/*  72:    */   private void embeddedTabsPropertyChanged(Boolean newValue)
/*  73:    */   {
/*  74:162 */     this.embeddedTabs = newValue;
/*  75:163 */     doLayout();
/*  76:    */   }
/*  77:    */   
/*  78:    */   private void noContentBorderPropertyChanged(Boolean newValue)
/*  79:    */   {
/*  80:172 */     this.noContentBorder = newValue;
/*  81:173 */     doLayout();
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected Icon getIconForTab(int tabIndex)
/*  85:    */   {
/*  86:184 */     String title = this.tabPane.getTitleAt(tabIndex);
/*  87:185 */     boolean hasTitle = (title != null) && (title.length() > 0);
/*  88:186 */     return (!isTabIconsEnabled) && (hasTitle) ? null : super.getIconForTab(tabIndex);
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected Insets getContentBorderInsets(int tabPlacement)
/*  92:    */   {
/*  93:192 */     if (!hasNoContentBorder())
/*  94:    */     {
/*  95:193 */       if (IS_XP_LAF_5_OR_LATER)
/*  96:    */       {
/*  97:194 */         switch (tabPlacement)
/*  98:    */         {
/*  99:    */         case 4: 
/* 100:196 */           return CONTENT_BORDER_EAST_INSETS;
/* 101:    */         case 2: 
/* 102:198 */           return CONTENT_BORDER_WEST_INSETS;
/* 103:    */         case 1: 
/* 104:200 */           return CONTENT_BORDER_NORTH_INSETS;
/* 105:    */         }
/* 106:203 */         return CONTENT_BORDER_SOUTH_INSETS;
/* 107:    */       }
/* 108:206 */       return this.contentBorderInsets;
/* 109:    */     }
/* 110:207 */     if (hasEmbeddedTabs()) {
/* 111:208 */       return EMPTY_INSETS;
/* 112:    */     }
/* 113:210 */     switch (tabPlacement)
/* 114:    */     {
/* 115:    */     case 4: 
/* 116:212 */       return NO_CONTENT_BORDER_EAST_INSETS;
/* 117:    */     case 2: 
/* 118:214 */       return NO_CONTENT_BORDER_WEST_INSETS;
/* 119:    */     case 1: 
/* 120:216 */       return NO_CONTENT_BORDER_NORTH_INSETS;
/* 121:    */     }
/* 122:219 */     return NO_CONTENT_BORDER_SOUTH_INSETS;
/* 123:    */   }
/* 124:    */   
/* 125:    */   protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected)
/* 126:    */   {
/* 127:225 */     switch (tabPlacement)
/* 128:    */     {
/* 129:    */     case 4: 
/* 130:227 */       return isSelected ? 2 : 0;
/* 131:    */     case 2: 
/* 132:229 */       return isSelected ? -2 : 0;
/* 133:    */     }
/* 134:233 */     return 0;
/* 135:    */   }
/* 136:    */   
/* 137:    */   protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected)
/* 138:    */   {
/* 139:238 */     return 0;
/* 140:    */   }
/* 141:    */   
/* 142:    */   protected Insets getSelectedTabPadInsets(int tabPlacement)
/* 143:    */   {
/* 144:242 */     if (hasEmbeddedTabs()) {
/* 145:243 */       return EMPTY_INSETS;
/* 146:    */     }
/* 147:244 */     if (hasNoContentBorder())
/* 148:    */     {
/* 149:245 */       int inset = IS_XP_LAF_5_OR_LATER ? 1 : 0;
/* 150:246 */       switch (tabPlacement)
/* 151:    */       {
/* 152:    */       case 2: 
/* 153:247 */         return new Insets(1, 2, 1, inset);
/* 154:    */       case 4: 
/* 155:248 */         return new Insets(1, inset, 1, 2);
/* 156:    */       case 1: 
/* 157:249 */         return new Insets(2, 2, inset, 2);
/* 158:    */       case 3: 
/* 159:250 */         return new Insets(inset, 2, 2, 2);
/* 160:    */       }
/* 161:251 */       return EMPTY_INSETS;
/* 162:    */     }
/* 163:254 */     Insets superInsets = super.getSelectedTabPadInsets(tabPlacement);
/* 164:255 */     int equalized = superInsets.left + superInsets.right / 2;
/* 165:256 */     superInsets.left = (superInsets.right = equalized);
/* 166:257 */     return superInsets;
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected Insets getTabAreaInsets(int tabPlacement)
/* 170:    */   {
/* 171:263 */     return hasEmbeddedTabs() ? EMPTY_INSETS : super.getTabAreaInsets(tabPlacement);
/* 172:    */   }
/* 173:    */   
/* 174:    */   protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/* 175:    */   {
/* 176:274 */     if ((hasNoContentBorder()) && (tabPlacement != 1)) {
/* 177:275 */       return;
/* 178:    */     }
/* 179:277 */     Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, this.calcRect);
/* 180:280 */     if ((tabPlacement != 1) || (selectedIndex < 0) || (selRect.y + selRect.height + 1 < y) || (selRect.x < x) || (selRect.x > x + w))
/* 181:    */     {
/* 182:284 */       super.paintContentBorderTopEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/* 183:    */     }
/* 184:    */     else
/* 185:    */     {
/* 186:286 */       g.setColor(this.lightHighlight);
/* 187:287 */       g.fillRect(x, y, selRect.x + 1 - x, 1);
/* 188:288 */       g.fillRect(selRect.x + selRect.width, y, x + w - 2 - selRect.x - selRect.width, 1);
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/* 193:    */   {
/* 194:299 */     if (!hasNoContentBorder())
/* 195:    */     {
/* 196:300 */       Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, this.calcRect);
/* 197:302 */       if ((tabPlacement != 3) || (selectedIndex < 0) || (selRect.y - 1 > h + y) || (selRect.x < x) || (selRect.x > x + w))
/* 198:    */       {
/* 199:306 */         super.paintContentBorderBottomEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/* 200:    */       }
/* 201:    */       else
/* 202:    */       {
/* 203:308 */         g.setColor(this.lightHighlight);
/* 204:309 */         g.fillRect(x, y + h - 1, 1, 1);
/* 205:310 */         g.setColor(this.shadow);
/* 206:311 */         g.fillRect(x + 1, y + h - 2, selRect.x - 1 - x, 1);
/* 207:312 */         g.fillRect(selRect.x + selRect.width, y + h - 2, x + w - 2 - selRect.x - selRect.width, 1);
/* 208:313 */         g.setColor(this.darkShadow);
/* 209:314 */         g.fillRect(x, y + h - 1, selRect.x - x, 1);
/* 210:315 */         g.fillRect(selRect.x + selRect.width - 1, y + h - 1, x + w - selRect.x - selRect.width, 1);
/* 211:    */       }
/* 212:    */     }
/* 213:317 */     else if (tabPlacement == 3)
/* 214:    */     {
/* 215:321 */       g.setColor(this.shadow);
/* 216:322 */       g.fillRect(x, y + h, w, 1);
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/* 221:    */   {
/* 222:332 */     if (!hasNoContentBorder())
/* 223:    */     {
/* 224:333 */       Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, this.calcRect);
/* 225:335 */       if ((tabPlacement != 2) || (selectedIndex < 0) || (selRect.x + selRect.width + 1 < x) || (selRect.y < y) || (selRect.y > y + h))
/* 226:    */       {
/* 227:339 */         super.paintContentBorderLeftEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/* 228:    */       }
/* 229:    */       else
/* 230:    */       {
/* 231:341 */         g.setColor(this.lightHighlight);
/* 232:342 */         g.fillRect(x, y, 1, selRect.y + 1 - y);
/* 233:343 */         g.fillRect(x, selRect.y + selRect.height, 1, y + h - 1 - selRect.y - selRect.height);
/* 234:    */       }
/* 235:    */     }
/* 236:347 */     else if (tabPlacement == 2)
/* 237:    */     {
/* 238:351 */       g.setColor(this.shadow);
/* 239:352 */       g.fillRect(x, y, 1, h);
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/* 244:    */   {
/* 245:362 */     if (!hasNoContentBorder())
/* 246:    */     {
/* 247:363 */       Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, this.calcRect);
/* 248:365 */       if ((tabPlacement != 4) || (selectedIndex < 0) || (selRect.x - 1 > x + w) || (selRect.y < y) || (selRect.y > y + h))
/* 249:    */       {
/* 250:369 */         super.paintContentBorderRightEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/* 251:    */       }
/* 252:    */       else
/* 253:    */       {
/* 254:371 */         g.setColor(this.lightHighlight);
/* 255:372 */         g.fillRect(x + w - 1, y, 1, 1);
/* 256:373 */         g.setColor(this.shadow);
/* 257:374 */         g.fillRect(x + w - 2, y + 1, 1, selRect.y - 1 - y);
/* 258:375 */         g.fillRect(x + w - 2, selRect.y + selRect.height, 1, y + h - 1 - selRect.y - selRect.height);
/* 259:    */         
/* 260:377 */         g.setColor(this.darkShadow);
/* 261:378 */         g.fillRect(x + w - 1, y, 1, selRect.y - y);
/* 262:379 */         g.fillRect(x + w - 1, selRect.y + selRect.height - 1, 1, y + h - selRect.y - selRect.height);
/* 263:    */       }
/* 264:    */     }
/* 265:383 */     else if (tabPlacement == 4)
/* 266:    */     {
/* 267:387 */       g.setColor(this.shadow);
/* 268:388 */       g.fillRect(x + w, y, 1, h);
/* 269:    */     }
/* 270:    */   }
/* 271:    */   
/* 272:    */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 273:    */   {
/* 274:405 */     if (!hasEmbeddedTabs())
/* 275:    */     {
/* 276:406 */       super.paintTabBorder(g, tabPlacement, tabIndex, x, y, w, h, isSelected);
/* 277:407 */       return;
/* 278:    */     }
/* 279:409 */     g.translate(x - 1, y - 1);
/* 280:    */     int w1;
/* 281:    */     int w2;
/* 282:    */     int w3;
/* 283:    */     int h1;
/* 284:    */     int h2;
/* 285:    */     int h3;
/* 286:412 */     switch (tabPlacement)
/* 287:    */     {
/* 288:    */     case 1: 
/* 289:414 */       w1 = 1;
/* 290:415 */       w2 = w - 2;
/* 291:416 */       w3 = 1;
/* 292:417 */       h1 = 1;
/* 293:418 */       h2 = h - 1;
/* 294:419 */       h3 = 0;
/* 295:420 */       break;
/* 296:    */     case 3: 
/* 297:422 */       w1 = 1;
/* 298:423 */       w2 = w - 2;
/* 299:424 */       w3 = 1;
/* 300:425 */       h1 = 0;
/* 301:426 */       h2 = h - 1;
/* 302:427 */       h3 = 1;
/* 303:428 */       break;
/* 304:    */     case 2: 
/* 305:430 */       w1 = 1;
/* 306:431 */       w2 = w - 1;
/* 307:432 */       w3 = 0;
/* 308:433 */       h1 = 1;
/* 309:434 */       h2 = h - 3;
/* 310:435 */       h3 = 1;
/* 311:436 */       break;
/* 312:    */     case 4: 
/* 313:    */     default: 
/* 314:439 */       w1 = 0;
/* 315:440 */       w2 = w - 1;
/* 316:441 */       w3 = 1;
/* 317:442 */       h1 = 1;
/* 318:443 */       h2 = h - 3;
/* 319:444 */       h3 = 1;
/* 320:    */     }
/* 321:446 */     if (isSelected)
/* 322:    */     {
/* 323:447 */       g.setColor(this.lightHighlight);
/* 324:448 */       g.drawRect(w1, h1, w1 + w2 + w3, h1 + h2 + h3);
/* 325:449 */       g.setColor(this.shadow);
/* 326:450 */       g.fillRect(1 + w1, 0, w2, h1);
/* 327:451 */       g.fillRect(0, 1 + h1, w1, h2);
/* 328:452 */       g.fillRect(2 * w1 + w2 + 2 * w3, 1 + h1, w3, h2);
/* 329:453 */       g.fillRect(1 + w1, 2 * h1 + h2 + 2 * h3, w2, h3);
/* 330:454 */       g.fillRect(1, 1, w1, h1);
/* 331:455 */       g.fillRect(2 * w1 + w2 + w3, 1, w3, h1);
/* 332:456 */       g.fillRect(1, 2 * h1 + h2 + h3, w1, h3);
/* 333:457 */       g.fillRect(2 * w1 + w2 + w3, 2 * h1 + h2 + h3, w3, h3);
/* 334:    */     }
/* 335:    */     else
/* 336:    */     {
/* 337:459 */       g.setColor(this.shadow);
/* 338:460 */       g.fillRect(w1 + w2 + 2 * w3, h3 * h2 / 2, w3, h2 * 2 / 3);
/* 339:461 */       g.fillRect(w3 * w2 / 2, h1 + h2 + 2 * h3, w2 / 2 + 2, h3);
/* 340:    */     }
/* 341:463 */     g.translate(-x + 1, -y + 1);
/* 342:    */   }
/* 343:    */   
/* 344:    */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rectangles, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 345:    */   {
/* 346:474 */     if (!hasEmbeddedTabs())
/* 347:    */     {
/* 348:475 */       super.paintFocusIndicator(g, tabPlacement, rectangles, tabIndex, iconRect, textRect, isSelected);
/* 349:476 */       return;
/* 350:    */     }
/* 351:478 */     if ((this.tabPane.hasFocus()) && (isSelected))
/* 352:    */     {
/* 353:479 */       g.setColor(this.focus);
/* 354:480 */       BasicGraphicsUtils.drawDashedRect(g, textRect.x - 2, textRect.y, textRect.width + 3, textRect.height);
/* 355:    */     }
/* 356:    */   }
/* 357:    */   
/* 358:    */   protected boolean shouldRotateTabRuns(int tabPlacement)
/* 359:    */   {
/* 360:485 */     return !hasEmbeddedTabs();
/* 361:    */   }
/* 362:    */   
/* 363:    */   protected void layoutLabel(int tabPlacement, FontMetrics metrics, int tabIndex, String title, Icon icon, Rectangle tabRect, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/* 364:    */   {
/* 365:502 */     textRect.x = (textRect.y = iconRect.x = iconRect.y = 0);
/* 366:    */     
/* 367:    */ 
/* 368:505 */     View v = getTextViewForTab(tabIndex);
/* 369:506 */     if (v != null) {
/* 370:507 */       this.tabPane.putClientProperty("html", v);
/* 371:    */     }
/* 372:510 */     int xNudge = getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
/* 373:511 */     int yNudge = getTabLabelShiftY(tabPlacement, tabIndex, isSelected);
/* 374:512 */     if (((tabPlacement == 4) || (tabPlacement == 2)) && (icon != null) && (title != null) && (!title.equals("")))
/* 375:    */     {
/* 376:514 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 0, 2, 0, 11, tabRect, iconRect, textRect, this.textIconGap);
/* 377:    */       
/* 378:    */ 
/* 379:    */ 
/* 380:    */ 
/* 381:    */ 
/* 382:    */ 
/* 383:    */ 
/* 384:    */ 
/* 385:    */ 
/* 386:    */ 
/* 387:    */ 
/* 388:    */ 
/* 389:527 */       xNudge += 4;
/* 390:    */     }
/* 391:    */     else
/* 392:    */     {
/* 393:529 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 0, 0, 0, 11, tabRect, iconRect, textRect, this.textIconGap);
/* 394:    */     }
/* 395:545 */     this.tabPane.putClientProperty("html", null);
/* 396:    */     
/* 397:547 */     iconRect.x += xNudge;
/* 398:548 */     iconRect.y += yNudge;
/* 399:549 */     textRect.x += xNudge;
/* 400:550 */     textRect.y += yNudge;
/* 401:    */   }
/* 402:    */   
/* 403:    */   private final class MyPropertyChangeHandler
/* 404:    */     extends BasicTabbedPaneUI.PropertyChangeHandler
/* 405:    */   {
/* 406:    */     MyPropertyChangeHandler(WindowsTabbedPaneUI.1 x1)
/* 407:    */     {
/* 408:559 */       this();
/* 409:    */     }
/* 410:    */     
/* 411:    */     private MyPropertyChangeHandler()
/* 412:    */     {
/* 413:559 */       super();
/* 414:    */     }
/* 415:    */     
/* 416:    */     public void propertyChange(PropertyChangeEvent e)
/* 417:    */     {
/* 418:562 */       super.propertyChange(e);
/* 419:    */       
/* 420:564 */       String pName = e.getPropertyName();
/* 421:565 */       if (null == pName) {
/* 422:566 */         return;
/* 423:    */       }
/* 424:568 */       if (pName.equals("jgoodies.embeddedTabs"))
/* 425:    */       {
/* 426:569 */         WindowsTabbedPaneUI.this.embeddedTabsPropertyChanged((Boolean)e.getNewValue());
/* 427:570 */         return;
/* 428:    */       }
/* 429:572 */       if (pName.equals("jgoodies.noContentBorder"))
/* 430:    */       {
/* 431:573 */         WindowsTabbedPaneUI.this.noContentBorderPropertyChanged((Boolean)e.getNewValue());
/* 432:574 */         return;
/* 433:    */       }
/* 434:    */     }
/* 435:    */   }
/* 436:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsTabbedPaneUI
 * JD-Core Version:    0.7.0.1
 */
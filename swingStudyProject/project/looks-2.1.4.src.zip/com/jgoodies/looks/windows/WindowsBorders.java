/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import javax.swing.AbstractButton;
/*   8:    */ import javax.swing.ButtonModel;
/*   9:    */ import javax.swing.JButton;
/*  10:    */ import javax.swing.JToggleButton;
/*  11:    */ import javax.swing.UIDefaults;
/*  12:    */ import javax.swing.UIManager;
/*  13:    */ import javax.swing.border.AbstractBorder;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import javax.swing.border.CompoundBorder;
/*  16:    */ import javax.swing.border.EmptyBorder;
/*  17:    */ import javax.swing.plaf.BorderUIResource;
/*  18:    */ import javax.swing.plaf.BorderUIResource.CompoundBorderUIResource;
/*  19:    */ import javax.swing.plaf.UIResource;
/*  20:    */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*  21:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  22:    */ 
/*  23:    */ final class WindowsBorders
/*  24:    */ {
/*  25:    */   private static Border menuBorder;
/*  26:    */   private static Border xpMenuBorder;
/*  27:    */   private static Border menuItemBorder;
/*  28:    */   private static Border popupMenuBorder;
/*  29:    */   private static Border noMarginPopupMenuBorder;
/*  30:    */   private static Border separatorBorder;
/*  31:    */   private static Border etchedBorder;
/*  32:    */   private static Border menuBarHeaderBorder;
/*  33:    */   private static Border toolBarHeaderBorder;
/*  34:    */   private static Border rolloverButtonBorder;
/*  35:    */   
/*  36:    */   public static Border getButtonBorder()
/*  37:    */   {
/*  38: 84 */     UIDefaults table = UIManager.getLookAndFeelDefaults();
/*  39: 85 */     Border outerBorder = new ButtonBorder(table.getColor("Button.shadow"), table.getColor("Button.darkShadow"), table.getColor("Button.light"), table.getColor("Button.highlight"), table.getColor("controlText"));
/*  40:    */     
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45: 91 */     Border buttonBorder = new BorderUIResource.CompoundBorderUIResource(outerBorder, new BasicBorders.MarginBorder());
/*  46:    */     
/*  47: 93 */     return buttonBorder;
/*  48:    */   }
/*  49:    */   
/*  50:    */   static Border getMenuBorder()
/*  51:    */   {
/*  52:101 */     if (menuBorder == null) {
/*  53:102 */       menuBorder = new BorderUIResource.CompoundBorderUIResource(new MenuBorder(null), new BasicBorders.MarginBorder());
/*  54:    */     }
/*  55:106 */     return menuBorder;
/*  56:    */   }
/*  57:    */   
/*  58:    */   static Border getXPMenuBorder()
/*  59:    */   {
/*  60:113 */     if (xpMenuBorder == null) {
/*  61:114 */       xpMenuBorder = new BasicBorders.MarginBorder();
/*  62:    */     }
/*  63:116 */     return xpMenuBorder;
/*  64:    */   }
/*  65:    */   
/*  66:    */   static Border getMenuItemBorder()
/*  67:    */   {
/*  68:123 */     if (menuItemBorder == null) {
/*  69:124 */       menuItemBorder = new BorderUIResource(new BasicBorders.MarginBorder());
/*  70:    */     }
/*  71:126 */     return menuItemBorder;
/*  72:    */   }
/*  73:    */   
/*  74:    */   static Border getSeparatorBorder()
/*  75:    */   {
/*  76:133 */     if (separatorBorder == null) {
/*  77:134 */       separatorBorder = new BorderUIResource.CompoundBorderUIResource(new SeparatorBorder(null), new BasicBorders.MarginBorder());
/*  78:    */     }
/*  79:138 */     return separatorBorder;
/*  80:    */   }
/*  81:    */   
/*  82:    */   static Border getEtchedBorder()
/*  83:    */   {
/*  84:145 */     if (etchedBorder == null) {
/*  85:146 */       etchedBorder = new BorderUIResource.CompoundBorderUIResource(new EtchedBorder(null), new BasicBorders.MarginBorder());
/*  86:    */     }
/*  87:150 */     return etchedBorder;
/*  88:    */   }
/*  89:    */   
/*  90:    */   static Border getMenuBarHeaderBorder()
/*  91:    */   {
/*  92:158 */     if (menuBarHeaderBorder == null) {
/*  93:159 */       menuBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(new MenuBarHeaderBorder(null), new BasicBorders.MarginBorder());
/*  94:    */     }
/*  95:163 */     return menuBarHeaderBorder;
/*  96:    */   }
/*  97:    */   
/*  98:    */   static Border getPopupMenuBorder()
/*  99:    */   {
/* 100:172 */     if (popupMenuBorder == null) {
/* 101:173 */       popupMenuBorder = new PopupMenuBorder(null);
/* 102:    */     }
/* 103:175 */     return popupMenuBorder;
/* 104:    */   }
/* 105:    */   
/* 106:    */   static Border getNoMarginPopupMenuBorder()
/* 107:    */   {
/* 108:184 */     if (noMarginPopupMenuBorder == null) {
/* 109:185 */       noMarginPopupMenuBorder = new NoMarginPopupMenuBorder(null);
/* 110:    */     }
/* 111:187 */     return noMarginPopupMenuBorder;
/* 112:    */   }
/* 113:    */   
/* 114:    */   static Border getToolBarHeaderBorder()
/* 115:    */   {
/* 116:195 */     if (toolBarHeaderBorder == null) {
/* 117:196 */       toolBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(new ToolBarHeaderBorder(null), new BasicBorders.MarginBorder());
/* 118:    */     }
/* 119:200 */     return toolBarHeaderBorder;
/* 120:    */   }
/* 121:    */   
/* 122:    */   static Border getRolloverButtonBorder()
/* 123:    */   {
/* 124:207 */     if (rolloverButtonBorder == null) {
/* 125:208 */       rolloverButtonBorder = new CompoundBorder(new RolloverButtonBorder(null), new RolloverMarginBorder(null));
/* 126:    */     }
/* 127:212 */     return rolloverButtonBorder;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static final class ButtonBorder
/* 131:    */     extends AbstractBorder
/* 132:    */     implements UIResource
/* 133:    */   {
/* 134:222 */     private static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
/* 135:    */     private final Color shadow;
/* 136:    */     private final Color darkShadow;
/* 137:    */     private final Color highlight;
/* 138:    */     private final Color lightHighlight;
/* 139:    */     private final Color defaultColor;
/* 140:    */     
/* 141:    */     public ButtonBorder(Color shadow, Color darkShadow, Color highlight, Color lightHighlight, Color defaultColor)
/* 142:    */     {
/* 143:232 */       this.shadow = shadow;
/* 144:233 */       this.darkShadow = darkShadow;
/* 145:234 */       this.highlight = highlight;
/* 146:235 */       this.lightHighlight = lightHighlight;
/* 147:236 */       this.defaultColor = defaultColor;
/* 148:    */     }
/* 149:    */     
/* 150:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 151:    */     {
/* 152:240 */       boolean isPressed = false;
/* 153:241 */       boolean isDefault = false;
/* 154:243 */       if ((c instanceof AbstractButton))
/* 155:    */       {
/* 156:244 */         AbstractButton b = (AbstractButton)c;
/* 157:245 */         ButtonModel model = b.getModel();
/* 158:    */         
/* 159:247 */         isPressed = (model.isPressed()) && (model.isArmed());
/* 160:248 */         if ((c instanceof JButton)) {
/* 161:249 */           isDefault = ((JButton)c).isDefaultButton();
/* 162:    */         }
/* 163:    */       }
/* 164:252 */       WindowsBorders.drawBezel(g, x, y, width, height, isPressed, isDefault, this.shadow, this.darkShadow, this.highlight, this.lightHighlight, this.defaultColor);
/* 165:    */     }
/* 166:    */     
/* 167:    */     public Insets getBorderInsets(Component c)
/* 168:    */     {
/* 169:257 */       return getBorderInsets(c, EMPTY_INSETS);
/* 170:    */     }
/* 171:    */     
/* 172:    */     public Insets getBorderInsets(Component c, Insets insets)
/* 173:    */     {
/* 174:262 */       insets.top = 2;
/* 175:263 */       insets.left = (insets.bottom = insets.right = 3);
/* 176:264 */       return insets;
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static abstract class AbstractButtonBorder
/* 181:    */     extends AbstractBorder
/* 182:    */     implements UIResource
/* 183:    */   {
/* 184:    */     AbstractButtonBorder(WindowsBorders.1 x0)
/* 185:    */     {
/* 186:272 */       this();
/* 187:    */     }
/* 188:    */     
/* 189:274 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 190:    */     
/* 191:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 192:    */     {
/* 193:277 */       AbstractButton button = (AbstractButton)c;
/* 194:278 */       ButtonModel model = button.getModel();
/* 195:284 */       if (model.isPressed()) {
/* 196:285 */         WindowsUtils.drawPressed3DBorder(g, x, y, w, h);
/* 197:    */       } else {
/* 198:287 */         WindowsUtils.drawFlush3DBorder(g, x, y, w, h);
/* 199:    */       }
/* 200:    */     }
/* 201:    */     
/* 202:    */     public Insets getBorderInsets(Component c)
/* 203:    */     {
/* 204:290 */       return INSETS;
/* 205:    */     }
/* 206:    */     
/* 207:    */     private AbstractButtonBorder() {}
/* 208:    */   }
/* 209:    */   
/* 210:    */   private static final class RolloverButtonBorder
/* 211:    */     extends WindowsBorders.AbstractButtonBorder
/* 212:    */   {
/* 213:    */     RolloverButtonBorder(WindowsBorders.1 x0)
/* 214:    */     {
/* 215:297 */       this();
/* 216:    */     }
/* 217:    */     
/* 218:    */     private RolloverButtonBorder()
/* 219:    */     {
/* 220:297 */       super();
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 224:    */     {
/* 225:300 */       AbstractButton b = (AbstractButton)c;
/* 226:301 */       ButtonModel model = b.getModel();
/* 227:303 */       if (!model.isEnabled()) {
/* 228:304 */         return;
/* 229:    */       }
/* 230:306 */       if (!(c instanceof JToggleButton))
/* 231:    */       {
/* 232:307 */         if (model.isRollover()) {
/* 233:308 */           super.paintBorder(c, g, x, y, w, h);
/* 234:    */         }
/* 235:309 */         return;
/* 236:    */       }
/* 237:312 */       if (model.isSelected()) {
/* 238:313 */         WindowsUtils.drawPressed3DBorder(g, x, y, w, h);
/* 239:314 */       } else if (model.isRollover()) {
/* 240:315 */         super.paintBorder(c, g, x, y, w, h);
/* 241:    */       }
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   private static final class RolloverMarginBorder
/* 246:    */     extends EmptyBorder
/* 247:    */   {
/* 248:    */     RolloverMarginBorder(WindowsBorders.1 x0)
/* 249:    */     {
/* 250:331 */       this();
/* 251:    */     }
/* 252:    */     
/* 253:    */     private RolloverMarginBorder()
/* 254:    */     {
/* 255:334 */       super(1, 1, 1);
/* 256:    */     }
/* 257:    */     
/* 258:    */     public Insets getBorderInsets(Component c)
/* 259:    */     {
/* 260:339 */       return getBorderInsets(c, new Insets(0, 0, 0, 0));
/* 261:    */     }
/* 262:    */     
/* 263:    */     public Insets getBorderInsets(Component c, Insets insets)
/* 264:    */     {
/* 265:344 */       Insets margin = null;
/* 266:346 */       if ((c instanceof AbstractButton)) {
/* 267:347 */         margin = ((AbstractButton)c).getMargin();
/* 268:    */       }
/* 269:349 */       if ((margin == null) || ((margin instanceof UIResource)))
/* 270:    */       {
/* 271:351 */         insets.left = this.left;
/* 272:352 */         insets.top = this.top;
/* 273:353 */         insets.right = this.right;
/* 274:354 */         insets.bottom = this.bottom;
/* 275:    */       }
/* 276:    */       else
/* 277:    */       {
/* 278:357 */         insets.left = margin.left;
/* 279:358 */         insets.top = margin.top;
/* 280:359 */         insets.right = margin.right;
/* 281:360 */         insets.bottom = margin.bottom;
/* 282:    */       }
/* 283:362 */       return insets;
/* 284:    */     }
/* 285:    */   }
/* 286:    */   
/* 287:    */   private static final class SeparatorBorder
/* 288:    */     extends AbstractBorder
/* 289:    */     implements UIResource
/* 290:    */   {
/* 291:    */     SeparatorBorder(WindowsBorders.1 x0)
/* 292:    */     {
/* 293:369 */       this();
/* 294:    */     }
/* 295:    */     
/* 296:371 */     private static final Insets INSETS = new Insets(0, 3, 2, 1);
/* 297:    */     
/* 298:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 299:    */     {
/* 300:374 */       g.translate(x, y);
/* 301:375 */       g.setColor(UIManager.getColor("Separator.foreground"));
/* 302:376 */       g.drawLine(0, h - 2, w - 1, h - 2);
/* 303:    */       
/* 304:378 */       g.setColor(UIManager.getColor("Separator.background"));
/* 305:379 */       g.drawLine(0, h - 1, w - 1, h - 1);
/* 306:380 */       g.translate(-x, -y);
/* 307:    */     }
/* 308:    */     
/* 309:    */     public Insets getBorderInsets(Component c)
/* 310:    */     {
/* 311:383 */       return INSETS;
/* 312:    */     }
/* 313:    */     
/* 314:    */     private SeparatorBorder() {}
/* 315:    */   }
/* 316:    */   
/* 317:    */   static final class ThinRaisedBorder
/* 318:    */     extends AbstractBorder
/* 319:    */     implements UIResource
/* 320:    */   {
/* 321:392 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 322:    */     
/* 323:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 324:    */     {
/* 325:395 */       WindowsUtils.drawFlush3DBorder(g, x, y, w, h);
/* 326:    */     }
/* 327:    */     
/* 328:    */     public Insets getBorderInsets(Component c)
/* 329:    */     {
/* 330:398 */       return INSETS;
/* 331:    */     }
/* 332:    */   }
/* 333:    */   
/* 334:    */   static final class ThinLoweredBorder
/* 335:    */     extends AbstractBorder
/* 336:    */     implements UIResource
/* 337:    */   {
/* 338:407 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 339:    */     
/* 340:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 341:    */     {
/* 342:410 */       WindowsUtils.drawPressed3DBorder(g, x, y, w, h);
/* 343:    */     }
/* 344:    */     
/* 345:    */     public Insets getBorderInsets(Component c)
/* 346:    */     {
/* 347:413 */       return INSETS;
/* 348:    */     }
/* 349:    */   }
/* 350:    */   
/* 351:    */   private static final class EtchedBorder
/* 352:    */     extends AbstractBorder
/* 353:    */     implements UIResource
/* 354:    */   {
/* 355:    */     EtchedBorder(WindowsBorders.1 x0)
/* 356:    */     {
/* 357:422 */       this();
/* 358:    */     }
/* 359:    */     
/* 360:424 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/* 361:    */     
/* 362:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 363:    */     {
/* 364:427 */       WindowsUtils.drawPressed3DBorder(g, x, y, w, h);
/* 365:428 */       WindowsUtils.drawFlush3DBorder(g, x + 1, y + 1, w - 2, h - 2);
/* 366:    */     }
/* 367:    */     
/* 368:    */     public Insets getBorderInsets(Component c)
/* 369:    */     {
/* 370:431 */       return INSETS;
/* 371:    */     }
/* 372:    */     
/* 373:    */     private EtchedBorder() {}
/* 374:    */   }
/* 375:    */   
/* 376:    */   private static final class MenuBarHeaderBorder
/* 377:    */     extends AbstractBorder
/* 378:    */     implements UIResource
/* 379:    */   {
/* 380:    */     MenuBarHeaderBorder(WindowsBorders.1 x0)
/* 381:    */     {
/* 382:440 */       this();
/* 383:    */     }
/* 384:    */     
/* 385:442 */     private static final Insets INSETS = new Insets(2, 2, 1, 2);
/* 386:    */     
/* 387:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 388:    */     {
/* 389:445 */       WindowsUtils.drawPressed3DBorder(g, x, y, w, h + 1);
/* 390:446 */       WindowsUtils.drawFlush3DBorder(g, x + 1, y + 1, w - 2, h - 1);
/* 391:    */     }
/* 392:    */     
/* 393:    */     public Insets getBorderInsets(Component c)
/* 394:    */     {
/* 395:449 */       return INSETS;
/* 396:    */     }
/* 397:    */     
/* 398:    */     private MenuBarHeaderBorder() {}
/* 399:    */   }
/* 400:    */   
/* 401:    */   private static final class PopupMenuBorder
/* 402:    */     extends AbstractBorder
/* 403:    */     implements UIResource
/* 404:    */   {
/* 405:    */     PopupMenuBorder(WindowsBorders.1 x0)
/* 406:    */     {
/* 407:453 */       this();
/* 408:    */     }
/* 409:    */     
/* 410:455 */     private static final Insets INSETS = new Insets(3, 3, 3, 3);
/* 411:    */     
/* 412:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 413:    */     {
/* 414:458 */       g.translate(x, y);
/* 415:459 */       g.setColor(UIManager.getColor("controlShadow"));
/* 416:460 */       g.drawRect(0, 0, w - 1, h - 1);
/* 417:461 */       g.setColor(UIManager.getColor("MenuItem.background"));
/* 418:462 */       g.drawRect(1, 1, w - 3, h - 3);
/* 419:463 */       g.drawRect(2, 2, w - 5, h - 5);
/* 420:464 */       g.translate(-x, -y);
/* 421:    */     }
/* 422:    */     
/* 423:    */     public Insets getBorderInsets(Component c)
/* 424:    */     {
/* 425:467 */       return INSETS;
/* 426:    */     }
/* 427:    */     
/* 428:    */     private PopupMenuBorder() {}
/* 429:    */   }
/* 430:    */   
/* 431:    */   private static final class NoMarginPopupMenuBorder
/* 432:    */     extends AbstractBorder
/* 433:    */     implements UIResource
/* 434:    */   {
/* 435:    */     NoMarginPopupMenuBorder(WindowsBorders.1 x0)
/* 436:    */     {
/* 437:471 */       this();
/* 438:    */     }
/* 439:    */     
/* 440:473 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 441:    */     
/* 442:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 443:    */     {
/* 444:476 */       g.translate(x, y);
/* 445:477 */       g.setColor(UIManager.getColor("controlShadow"));
/* 446:478 */       g.drawRect(0, 0, w - 1, h - 1);
/* 447:    */       
/* 448:    */ 
/* 449:481 */       g.translate(-x, -y);
/* 450:    */     }
/* 451:    */     
/* 452:    */     public Insets getBorderInsets(Component c)
/* 453:    */     {
/* 454:484 */       return INSETS;
/* 455:    */     }
/* 456:    */     
/* 457:    */     private NoMarginPopupMenuBorder() {}
/* 458:    */   }
/* 459:    */   
/* 460:    */   private static final class ToolBarHeaderBorder
/* 461:    */     extends AbstractBorder
/* 462:    */     implements UIResource
/* 463:    */   {
/* 464:    */     ToolBarHeaderBorder(WindowsBorders.1 x0)
/* 465:    */     {
/* 466:492 */       this();
/* 467:    */     }
/* 468:    */     
/* 469:494 */     private static final Insets INSETS = new Insets(1, 2, 2, 2);
/* 470:    */     
/* 471:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 472:    */     {
/* 473:497 */       WindowsUtils.drawPressed3DBorder(g, x, y - 1, w, h + 1);
/* 474:498 */       WindowsUtils.drawFlush3DBorder(g, x + 1, y, w - 2, h - 1);
/* 475:    */     }
/* 476:    */     
/* 477:    */     public Insets getBorderInsets(Component c)
/* 478:    */     {
/* 479:501 */       return INSETS;
/* 480:    */     }
/* 481:    */     
/* 482:    */     private ToolBarHeaderBorder() {}
/* 483:    */   }
/* 484:    */   
/* 485:    */   private static final class MenuBorder
/* 486:    */     extends AbstractBorder
/* 487:    */     implements UIResource
/* 488:    */   {
/* 489:    */     MenuBorder(WindowsBorders.1 x0)
/* 490:    */     {
/* 491:508 */       this();
/* 492:    */     }
/* 493:    */     
/* 494:510 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/* 495:    */     
/* 496:    */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/* 497:    */     {
/* 498:513 */       AbstractButton b = (AbstractButton)c;
/* 499:514 */       ButtonModel model = b.getModel();
/* 500:518 */       if (model.isSelected()) {
/* 501:519 */         WindowsUtils.drawPressed3DBorder(g, x, y, w, h);
/* 502:520 */       } else if (model.isRollover()) {
/* 503:521 */         WindowsUtils.drawFlush3DBorder(g, x, y, w, h);
/* 504:    */       }
/* 505:    */     }
/* 506:    */     
/* 507:    */     public Insets getBorderInsets(Component c)
/* 508:    */     {
/* 509:525 */       return INSETS;
/* 510:    */     }
/* 511:    */     
/* 512:    */     private MenuBorder() {}
/* 513:    */   }
/* 514:    */   
/* 515:    */   private static void drawBezel(Graphics g, int x, int y, int w, int h, boolean isPressed, boolean isDefault, Color shadow, Color darkShadow, Color highlight, Color lightHighlight, Color defaultColor)
/* 516:    */   {
/* 517:538 */     Color oldColor = g.getColor();
/* 518:539 */     g.translate(x, y);
/* 519:541 */     if ((isPressed) && (isDefault))
/* 520:    */     {
/* 521:542 */       g.setColor(darkShadow);
/* 522:543 */       g.drawRect(0, 0, w - 1, h - 1);
/* 523:544 */       g.setColor(shadow);
/* 524:545 */       g.drawRect(1, 1, w - 3, h - 3);
/* 525:    */     }
/* 526:546 */     else if (isPressed)
/* 527:    */     {
/* 528:547 */       BasicGraphicsUtils.drawLoweredBezel(g, x, y, w, h, shadow, darkShadow, highlight, lightHighlight);
/* 529:    */     }
/* 530:549 */     else if (isDefault)
/* 531:    */     {
/* 532:550 */       g.setColor(defaultColor);
/* 533:551 */       g.drawRect(0, 0, w - 1, h - 1);
/* 534:    */       
/* 535:553 */       g.setColor(lightHighlight);
/* 536:554 */       g.drawLine(1, 1, 1, h - 3);
/* 537:555 */       g.drawLine(2, 1, w - 3, 1);
/* 538:    */       
/* 539:557 */       g.setColor(highlight);
/* 540:558 */       g.drawLine(2, 2, 2, h - 4);
/* 541:559 */       g.drawLine(3, 2, w - 4, 2);
/* 542:    */       
/* 543:561 */       g.setColor(shadow);
/* 544:562 */       g.drawLine(2, h - 3, w - 3, h - 3);
/* 545:563 */       g.drawLine(w - 3, 2, w - 3, h - 4);
/* 546:    */       
/* 547:565 */       g.setColor(darkShadow);
/* 548:566 */       g.drawLine(1, h - 2, w - 2, h - 2);
/* 549:567 */       g.drawLine(w - 2, h - 2, w - 2, 1);
/* 550:    */     }
/* 551:    */     else
/* 552:    */     {
/* 553:569 */       g.setColor(lightHighlight);
/* 554:570 */       g.drawLine(0, 0, 0, h - 1);
/* 555:571 */       g.drawLine(1, 0, w - 2, 0);
/* 556:    */       
/* 557:573 */       g.setColor(highlight);
/* 558:574 */       g.drawLine(1, 1, 1, h - 3);
/* 559:575 */       g.drawLine(2, 1, w - 3, 1);
/* 560:    */       
/* 561:577 */       g.setColor(shadow);
/* 562:578 */       g.drawLine(1, h - 2, w - 2, h - 2);
/* 563:579 */       g.drawLine(w - 2, 1, w - 2, h - 3);
/* 564:    */       
/* 565:581 */       g.setColor(darkShadow);
/* 566:582 */       g.drawLine(0, h - 1, w - 1, h - 1);
/* 567:583 */       g.drawLine(w - 1, h - 1, w - 1, 0);
/* 568:    */     }
/* 569:585 */     g.translate(-x, -y);
/* 570:586 */     g.setColor(oldColor);
/* 571:    */   }
/* 572:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsBorders
 * JD-Core Version:    0.7.0.1
 */
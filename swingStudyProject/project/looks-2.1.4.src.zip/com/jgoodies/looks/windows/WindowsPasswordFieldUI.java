/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.LookUtils;
/*  4:   */ import com.jgoodies.looks.common.ExtPasswordView;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.plaf.ComponentUI;
/*  7:   */ import javax.swing.text.Caret;
/*  8:   */ import javax.swing.text.Element;
/*  9:   */ import javax.swing.text.View;
/* 10:   */ 
/* 11:   */ public final class WindowsPasswordFieldUI
/* 12:   */   extends com.sun.java.swing.plaf.windows.WindowsPasswordFieldUI
/* 13:   */ {
/* 14:   */   public static ComponentUI createUI(JComponent c)
/* 15:   */   {
/* 16:63 */     return new WindowsPasswordFieldUI();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public View create(Element elem)
/* 20:   */   {
/* 21:86 */     return LookUtils.IS_JAVA_1_4_OR_5 ? new ExtPasswordView(elem) : super.create(elem);
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected Caret createCaret()
/* 25:   */   {
/* 26:98 */     return new WindowsFieldCaret();
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsPasswordFieldUI
 * JD-Core Version:    0.7.0.1
 */
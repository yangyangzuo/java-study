/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import com.jgoodies.looks.LookUtils;
/*  4:   */ import com.jgoodies.looks.common.MenuItemRenderer;
/*  5:   */ import java.awt.Color;
/*  6:   */ import java.awt.Font;
/*  7:   */ import javax.swing.JMenuItem;
/*  8:   */ import javax.swing.UIManager;
/*  9:   */ 
/* 10:   */ final class WindowsMenuItemRenderer
/* 11:   */   extends MenuItemRenderer
/* 12:   */ {
/* 13:   */   public WindowsMenuItemRenderer(JMenuItem menuItem, boolean iconBorderEnabled, Font acceleratorFont, Color selectionForeground, Color disabledForeground, Color acceleratorForeground, Color acceleratorSelectionForeground)
/* 14:   */   {
/* 15:61 */     super(menuItem, iconBorderEnabled, acceleratorFont, selectionForeground, disabledForeground, acceleratorForeground, acceleratorSelectionForeground);
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected boolean isMnemonicHidden()
/* 19:   */   {
/* 20:67 */     return WindowsLookAndFeel.isMnemonicHidden();
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected boolean disabledTextHasShadow()
/* 24:   */   {
/* 25:72 */     return (!LookUtils.IS_LAF_WINDOWS_XP_ENABLED) || (UIManager.getColor("MenuItem.disabledForeground") == null);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsMenuItemRenderer
 * JD-Core Version:    0.7.0.1
 */
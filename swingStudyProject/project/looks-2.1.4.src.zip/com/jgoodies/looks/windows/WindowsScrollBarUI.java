/*  1:   */ package com.jgoodies.looks.windows;
/*  2:   */ 
/*  3:   */ import javax.swing.JButton;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ import javax.swing.plaf.ComponentUI;
/*  6:   */ 
/*  7:   */ public final class WindowsScrollBarUI
/*  8:   */   extends com.sun.java.swing.plaf.windows.WindowsScrollBarUI
/*  9:   */ {
/* 10:   */   public static ComponentUI createUI(JComponent b)
/* 11:   */   {
/* 12:49 */     return new WindowsScrollBarUI();
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected JButton createDecreaseButton(int orientation)
/* 16:   */   {
/* 17:54 */     return new WindowsArrowButton(orientation);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected JButton createIncreaseButton(int orientation)
/* 21:   */   {
/* 22:59 */     return createDecreaseButton(orientation);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsScrollBarUI
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.common.MenuItemRenderer;
/*   4:    */ import com.sun.java.swing.plaf.windows.WindowsMenuUI;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import javax.swing.ButtonModel;
/*   9:    */ import javax.swing.Icon;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JMenu;
/*  12:    */ import javax.swing.JMenuItem;
/*  13:    */ import javax.swing.UIManager;
/*  14:    */ import javax.swing.plaf.ComponentUI;
/*  15:    */ import javax.swing.plaf.UIResource;
/*  16:    */ 
/*  17:    */ public final class WindowsXPMenuUI
/*  18:    */   extends WindowsMenuUI
/*  19:    */ {
/*  20:    */   private static final String MENU_PROPERTY_PREFIX = "Menu";
/*  21:    */   private static final String SUBMENU_PROPERTY_PREFIX = "MenuItem";
/*  22: 67 */   private String propertyPrefix = "Menu";
/*  23:    */   private MenuItemRenderer renderer;
/*  24:    */   
/*  25:    */   public static ComponentUI createUI(JComponent b)
/*  26:    */   {
/*  27: 72 */     return new WindowsXPMenuUI();
/*  28:    */   }
/*  29:    */   
/*  30:    */   protected void installDefaults()
/*  31:    */   {
/*  32: 78 */     super.installDefaults();
/*  33: 79 */     if ((this.arrowIcon == null) || ((this.arrowIcon instanceof UIResource))) {
/*  34: 80 */       this.arrowIcon = UIManager.getIcon("Menu.arrowIcon");
/*  35:    */     }
/*  36: 82 */     this.renderer = new MenuItemRenderer(this.menuItem, false, this.acceleratorFont, this.selectionForeground, this.disabledForeground, this.acceleratorForeground, this.acceleratorSelectionForeground);
/*  37:    */     
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45: 91 */     Integer gap = (Integer)UIManager.get(getPropertyPrefix() + ".textIconGap");
/*  46:    */     
/*  47: 93 */     this.defaultTextIconGap = (gap != null ? gap.intValue() : 2);
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected void uninstallDefaults()
/*  51:    */   {
/*  52: 97 */     super.uninstallDefaults();
/*  53: 98 */     this.renderer = null;
/*  54:    */   }
/*  55:    */   
/*  56:    */   protected String getPropertyPrefix()
/*  57:    */   {
/*  58:102 */     return this.propertyPrefix;
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected Dimension getPreferredMenuItemSize(JComponent c, Icon aCheckIcon, Icon anArrowIcon, int textIconGap)
/*  62:    */   {
/*  63:111 */     if (isSubMenu(this.menuItem))
/*  64:    */     {
/*  65:112 */       ensureSubMenuInstalled();
/*  66:113 */       return this.renderer.getPreferredMenuItemSize(c, aCheckIcon, anArrowIcon, textIconGap);
/*  67:    */     }
/*  68:119 */     Dimension size = super.getPreferredMenuItemSize(c, aCheckIcon, anArrowIcon, textIconGap);
/*  69:    */     
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:125 */     int width = size.width;
/*  75:126 */     int height = size.height;
/*  76:127 */     if (height % 2 == 1) {
/*  77:128 */       height--;
/*  78:    */     }
/*  79:129 */     return new Dimension(width, height);
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected void paintMenuItem(Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap)
/*  83:    */   {
/*  84:141 */     if (isSubMenu(this.menuItem)) {
/*  85:142 */       this.renderer.paintMenuItem(g, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap);
/*  86:    */     } else {
/*  87:151 */       super.paintMenuItem(g, c, aCheckIcon, anArrowIcon, background, foreground, textIconGap);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   private void ensureSubMenuInstalled()
/*  92:    */   {
/*  93:167 */     if (this.propertyPrefix.equals("MenuItem")) {
/*  94:168 */       return;
/*  95:    */     }
/*  96:170 */     ButtonModel model = this.menuItem.getModel();
/*  97:    */     
/*  98:    */ 
/*  99:    */ 
/* 100:174 */     boolean oldArmed = model.isArmed();
/* 101:175 */     boolean oldSelected = model.isSelected();
/* 102:    */     
/* 103:177 */     uninstallDefaults();
/* 104:178 */     this.propertyPrefix = "MenuItem";
/* 105:179 */     installDefaults();
/* 106:    */     
/* 107:    */ 
/* 108:182 */     model.setArmed(oldArmed);
/* 109:183 */     model.setSelected(oldSelected);
/* 110:    */   }
/* 111:    */   
/* 112:    */   private boolean isSubMenu(JMenuItem aMenuItem)
/* 113:    */   {
/* 114:190 */     return !((JMenu)aMenuItem).isTopLevelMenu();
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsXPMenuUI
 * JD-Core Version:    0.7.0.1
 */
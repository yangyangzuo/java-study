/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import javax.swing.AbstractButton;
/*   7:    */ import javax.swing.ButtonModel;
/*   8:    */ import javax.swing.Icon;
/*   9:    */ import javax.swing.JCheckBox;
/*  10:    */ import javax.swing.UIManager;
/*  11:    */ import javax.swing.plaf.UIResource;
/*  12:    */ 
/*  13:    */ final class WindowsIconFactory
/*  14:    */ {
/*  15:    */   private static Icon checkBoxIcon;
/*  16:    */   private static Icon radioButtonIcon;
/*  17:    */   
/*  18:    */   static Icon getCheckBoxIcon()
/*  19:    */   {
/*  20: 66 */     if (checkBoxIcon == null) {
/*  21: 67 */       checkBoxIcon = new CheckBoxIcon(null);
/*  22:    */     }
/*  23: 69 */     return checkBoxIcon;
/*  24:    */   }
/*  25:    */   
/*  26:    */   static Icon getRadioButtonIcon()
/*  27:    */   {
/*  28: 77 */     if (radioButtonIcon == null) {
/*  29: 78 */       radioButtonIcon = new RadioButtonIcon(null);
/*  30:    */     }
/*  31: 80 */     return radioButtonIcon;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private static class CheckBoxIcon
/*  35:    */     implements Icon, Serializable
/*  36:    */   {
/*  37:    */     private static final int SIZE = 13;
/*  38:    */     
/*  39:    */     CheckBoxIcon(WindowsIconFactory.1 x0)
/*  40:    */     {
/*  41: 87 */       this();
/*  42:    */     }
/*  43:    */     
/*  44:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/*  45:    */     {
/*  46: 92 */       JCheckBox cb = (JCheckBox)c;
/*  47: 93 */       ButtonModel model = cb.getModel();
/*  48: 96 */       if (!cb.isBorderPaintedFlat())
/*  49:    */       {
/*  50: 98 */         g.setColor(UIManager.getColor("CheckBox.shadow"));
/*  51: 99 */         g.drawLine(x, y, x + 11, y);
/*  52:100 */         g.drawLine(x, y + 1, x, y + 11);
/*  53:    */         
/*  54:    */ 
/*  55:103 */         g.setColor(UIManager.getColor("CheckBox.highlight"));
/*  56:104 */         g.drawLine(x + 12, y, x + 12, y + 12);
/*  57:105 */         g.drawLine(x, y + 12, x + 11, y + 12);
/*  58:    */         
/*  59:    */ 
/*  60:108 */         g.setColor(UIManager.getColor("CheckBox.darkShadow"));
/*  61:109 */         g.drawLine(x + 1, y + 1, x + 10, y + 1);
/*  62:110 */         g.drawLine(x + 1, y + 2, x + 1, y + 10);
/*  63:    */         
/*  64:    */ 
/*  65:113 */         g.setColor(UIManager.getColor("CheckBox.light"));
/*  66:114 */         g.drawLine(x + 1, y + 11, x + 11, y + 11);
/*  67:115 */         g.drawLine(x + 11, y + 1, x + 11, y + 10);
/*  68:    */       }
/*  69:    */       else
/*  70:    */       {
/*  71:117 */         g.setColor(UIManager.getColor("CheckBox.shadow"));
/*  72:118 */         g.drawRect(x + 1, y + 1, 10, 10);
/*  73:    */       }
/*  74:121 */       g.setColor(UIManager.getColor(((model.isPressed()) && (model.isArmed())) || (!model.isEnabled()) ? "CheckBox.background" : "CheckBox.interiorBackground"));
/*  75:    */       
/*  76:    */ 
/*  77:    */ 
/*  78:125 */       g.fillRect(x + 2, y + 2, 9, 9);
/*  79:    */       
/*  80:127 */       g.setColor(UIManager.getColor(model.isEnabled() ? "CheckBox.checkColor" : "CheckBox.shadow"));
/*  81:132 */       if (model.isSelected())
/*  82:    */       {
/*  83:133 */         g.drawLine(x + 9, y + 3, x + 9, y + 3);
/*  84:134 */         g.drawLine(x + 8, y + 4, x + 9, y + 4);
/*  85:135 */         g.drawLine(x + 7, y + 5, x + 9, y + 5);
/*  86:136 */         g.drawLine(x + 6, y + 6, x + 8, y + 6);
/*  87:137 */         g.drawLine(x + 3, y + 7, x + 7, y + 7);
/*  88:138 */         g.drawLine(x + 4, y + 8, x + 6, y + 8);
/*  89:139 */         g.drawLine(x + 5, y + 9, x + 5, y + 9);
/*  90:140 */         g.drawLine(x + 3, y + 5, x + 3, y + 5);
/*  91:141 */         g.drawLine(x + 3, y + 6, x + 4, y + 6);
/*  92:    */       }
/*  93:    */     }
/*  94:    */     
/*  95:    */     public int getIconWidth()
/*  96:    */     {
/*  97:145 */       return 13;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public int getIconHeight()
/* 101:    */     {
/* 102:146 */       return 13;
/* 103:    */     }
/* 104:    */     
/* 105:    */     private CheckBoxIcon() {}
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static class RadioButtonIcon
/* 109:    */     implements Icon, UIResource, Serializable
/* 110:    */   {
/* 111:    */     private static final int SIZE = 13;
/* 112:    */     
/* 113:    */     RadioButtonIcon(WindowsIconFactory.1 x0)
/* 114:    */     {
/* 115:151 */       this();
/* 116:    */     }
/* 117:    */     
/* 118:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 119:    */     {
/* 120:156 */       AbstractButton b = (AbstractButton)c;
/* 121:157 */       ButtonModel model = b.getModel();
/* 122:    */       
/* 123:    */ 
/* 124:160 */       g.setColor(UIManager.getColor(((model.isPressed()) && (model.isArmed())) || (!model.isEnabled()) ? "RadioButton.background" : "RadioButton.interiorBackground"));
/* 125:    */       
/* 126:    */ 
/* 127:    */ 
/* 128:164 */       g.fillRect(x + 2, y + 2, 8, 8);
/* 129:    */       
/* 130:    */ 
/* 131:    */ 
/* 132:168 */       g.setColor(UIManager.getColor("RadioButton.shadow"));
/* 133:169 */       g.drawLine(x + 4, y + 0, x + 7, y + 0);
/* 134:170 */       g.drawLine(x + 2, y + 1, x + 3, y + 1);
/* 135:171 */       g.drawLine(x + 8, y + 1, x + 9, y + 1);
/* 136:172 */       g.drawLine(x + 1, y + 2, x + 1, y + 3);
/* 137:173 */       g.drawLine(x + 0, y + 4, x + 0, y + 7);
/* 138:174 */       g.drawLine(x + 1, y + 8, x + 1, y + 9);
/* 139:    */       
/* 140:    */ 
/* 141:177 */       g.setColor(UIManager.getColor("RadioButton.highlight"));
/* 142:178 */       g.drawLine(x + 2, y + 10, x + 3, y + 10);
/* 143:179 */       g.drawLine(x + 4, y + 11, x + 7, y + 11);
/* 144:180 */       g.drawLine(x + 8, y + 10, x + 9, y + 10);
/* 145:181 */       g.drawLine(x + 10, y + 9, x + 10, y + 8);
/* 146:182 */       g.drawLine(x + 11, y + 7, x + 11, y + 4);
/* 147:183 */       g.drawLine(x + 10, y + 3, x + 10, y + 2);
/* 148:    */       
/* 149:    */ 
/* 150:    */ 
/* 151:187 */       g.setColor(UIManager.getColor("RadioButton.darkShadow"));
/* 152:188 */       g.drawLine(x + 4, y + 1, x + 7, y + 1);
/* 153:189 */       g.drawLine(x + 2, y + 2, x + 3, y + 2);
/* 154:190 */       g.drawLine(x + 8, y + 2, x + 9, y + 2);
/* 155:191 */       g.drawLine(x + 2, y + 3, x + 2, y + 3);
/* 156:192 */       g.drawLine(x + 1, y + 4, x + 1, y + 7);
/* 157:193 */       g.drawLine(x + 2, y + 8, x + 2, y + 8);
/* 158:    */       
/* 159:    */ 
/* 160:    */ 
/* 161:197 */       g.setColor(UIManager.getColor("RadioButton.light"));
/* 162:198 */       g.drawLine(x + 2, y + 9, x + 3, y + 9);
/* 163:199 */       g.drawLine(x + 4, y + 10, x + 7, y + 10);
/* 164:200 */       g.drawLine(x + 8, y + 9, x + 9, y + 9);
/* 165:201 */       g.drawLine(x + 9, y + 8, x + 9, y + 8);
/* 166:202 */       g.drawLine(x + 10, y + 7, x + 10, y + 4);
/* 167:203 */       g.drawLine(x + 9, y + 3, x + 9, y + 3);
/* 168:207 */       if (model.isSelected())
/* 169:    */       {
/* 170:208 */         g.setColor(UIManager.getColor("RadioButton.checkColor"));
/* 171:209 */         g.fillRect(x + 4, y + 5, 4, 2);
/* 172:210 */         g.fillRect(x + 5, y + 4, 2, 4);
/* 173:    */       }
/* 174:    */     }
/* 175:    */     
/* 176:    */     public int getIconWidth()
/* 177:    */     {
/* 178:214 */       return 13;
/* 179:    */     }
/* 180:    */     
/* 181:    */     public int getIconHeight()
/* 182:    */     {
/* 183:215 */       return 13;
/* 184:    */     }
/* 185:    */     
/* 186:    */     private RadioButtonIcon() {}
/* 187:    */   }
/* 188:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsIconFactory
 * JD-Core Version:    0.7.0.1
 */
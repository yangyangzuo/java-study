/*   1:    */ package com.jgoodies.looks.windows;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.EventQueue;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.Rectangle;
/*   8:    */ import java.awt.Shape;
/*   9:    */ import java.awt.event.FocusEvent;
/*  10:    */ import java.awt.event.MouseEvent;
/*  11:    */ import javax.swing.BoundedRangeModel;
/*  12:    */ import javax.swing.JFormattedTextField;
/*  13:    */ import javax.swing.JTextField;
/*  14:    */ import javax.swing.SwingUtilities;
/*  15:    */ import javax.swing.plaf.TextUI;
/*  16:    */ import javax.swing.plaf.UIResource;
/*  17:    */ import javax.swing.text.BadLocationException;
/*  18:    */ import javax.swing.text.DefaultCaret;
/*  19:    */ import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
/*  20:    */ import javax.swing.text.Document;
/*  21:    */ import javax.swing.text.Highlighter.HighlightPainter;
/*  22:    */ import javax.swing.text.JTextComponent;
/*  23:    */ import javax.swing.text.LayeredHighlighter.LayerPainter;
/*  24:    */ import javax.swing.text.Position.Bias;
/*  25:    */ import javax.swing.text.View;
/*  26:    */ 
/*  27:    */ final class WindowsFieldCaret
/*  28:    */   extends DefaultCaret
/*  29:    */   implements UIResource
/*  30:    */ {
/*  31: 57 */   private static final LayeredHighlighter.LayerPainter WindowsPainter = new WindowsHighlightPainter(null);
/*  32: 68 */   private boolean isKeyboardFocusEvent = true;
/*  33:    */   
/*  34:    */   public void focusGained(FocusEvent e)
/*  35:    */   {
/*  36: 72 */     if (getComponent().isEnabled())
/*  37:    */     {
/*  38: 73 */       setVisible(true);
/*  39: 74 */       setSelectionVisible(true);
/*  40:    */     }
/*  41: 77 */     final JTextComponent c = getComponent();
/*  42: 78 */     if ((c.isEnabled()) && (this.isKeyboardFocusEvent)) {
/*  43: 79 */       if ((c instanceof JFormattedTextField))
/*  44:    */       {
/*  45: 80 */         EventQueue.invokeLater(new Runnable()
/*  46:    */         {
/*  47:    */           private final JTextComponent val$c;
/*  48:    */           
/*  49:    */           public void run()
/*  50:    */           {
/*  51: 82 */             WindowsFieldCaret.this.setDot(0);
/*  52: 83 */             WindowsFieldCaret.this.moveDot(c.getDocument().getLength());
/*  53:    */           }
/*  54:    */         });
/*  55:    */       }
/*  56:    */       else
/*  57:    */       {
/*  58: 87 */         super.setDot(0);
/*  59: 88 */         super.moveDot(c.getDocument().getLength());
/*  60:    */       }
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void focusLost(FocusEvent e)
/*  65:    */   {
/*  66: 95 */     super.focusLost(e);
/*  67: 96 */     if (!e.isTemporary()) {
/*  68: 97 */       this.isKeyboardFocusEvent = true;
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void mousePressed(MouseEvent e)
/*  73:    */   {
/*  74:103 */     if ((SwingUtilities.isLeftMouseButton(e)) || (e.isPopupTrigger())) {
/*  75:104 */       this.isKeyboardFocusEvent = false;
/*  76:    */     }
/*  77:106 */     super.mousePressed(e);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void mouseReleased(MouseEvent e)
/*  81:    */   {
/*  82:112 */     super.mouseReleased(e);
/*  83:115 */     if (e.isPopupTrigger())
/*  84:    */     {
/*  85:116 */       this.isKeyboardFocusEvent = false;
/*  86:117 */       if ((getComponent() != null) && (getComponent().isEnabled()) && (getComponent().isRequestFocusEnabled())) {
/*  87:119 */         getComponent().requestFocus();
/*  88:    */       }
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   protected void adjustVisibility(Rectangle r)
/*  93:    */   {
/*  94:133 */     SwingUtilities.invokeLater(new SafeScroller(r));
/*  95:    */   }
/*  96:    */   
/*  97:    */   protected Highlighter.HighlightPainter getSelectionPainter()
/*  98:    */   {
/*  99:143 */     return WindowsPainter;
/* 100:    */   }
/* 101:    */   
/* 102:    */   private final class SafeScroller
/* 103:    */     implements Runnable
/* 104:    */   {
/* 105:    */     private Rectangle r;
/* 106:    */     
/* 107:    */     SafeScroller(Rectangle r)
/* 108:    */     {
/* 109:150 */       this.r = r;
/* 110:    */     }
/* 111:    */     
/* 112:    */     public void run()
/* 113:    */     {
/* 114:155 */       JTextField field = (JTextField)WindowsFieldCaret.this.getComponent();
/* 115:156 */       if (field != null)
/* 116:    */       {
/* 117:157 */         TextUI ui = field.getUI();
/* 118:158 */         int dot = WindowsFieldCaret.this.getDot();
/* 119:    */         
/* 120:160 */         Position.Bias bias = Position.Bias.Forward;
/* 121:161 */         Rectangle startRect = null;
/* 122:    */         try
/* 123:    */         {
/* 124:163 */           startRect = ui.modelToView(field, dot, bias);
/* 125:    */         }
/* 126:    */         catch (BadLocationException ble) {}
/* 127:166 */         Insets i = field.getInsets();
/* 128:167 */         BoundedRangeModel vis = field.getHorizontalVisibility();
/* 129:168 */         int x = this.r.x + vis.getValue() - i.left;
/* 130:169 */         int quarterSpan = vis.getExtent() / 4;
/* 131:170 */         if (this.r.x < i.left) {
/* 132:171 */           vis.setValue(x - quarterSpan);
/* 133:172 */         } else if (this.r.x + this.r.width > i.left + vis.getExtent()) {
/* 134:173 */           vis.setValue(x - 3 * quarterSpan);
/* 135:    */         }
/* 136:179 */         if (startRect != null) {
/* 137:    */           try
/* 138:    */           {
/* 139:182 */             Rectangle endRect = ui.modelToView(field, dot, bias);
/* 140:183 */             if ((endRect != null) && (!endRect.equals(startRect))) {
/* 141:184 */               WindowsFieldCaret.this.damage(endRect);
/* 142:    */             }
/* 143:    */           }
/* 144:    */           catch (BadLocationException ble) {}
/* 145:    */         }
/* 146:    */       }
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   private static final class WindowsHighlightPainter
/* 151:    */     extends DefaultHighlighter.DefaultHighlightPainter
/* 152:    */   {
/* 153:    */     WindowsHighlightPainter(Color c)
/* 154:    */     {
/* 155:199 */       super();
/* 156:    */     }
/* 157:    */     
/* 158:    */     public void paint(Graphics g, int offs0, int offs1, Shape bounds, JTextComponent c)
/* 159:    */     {
/* 160:216 */       Rectangle alloc = bounds.getBounds();
/* 161:    */       try
/* 162:    */       {
/* 163:219 */         TextUI mapper = c.getUI();
/* 164:220 */         Rectangle p0 = mapper.modelToView(c, offs0);
/* 165:221 */         Rectangle p1 = mapper.modelToView(c, offs1);
/* 166:    */         
/* 167:    */ 
/* 168:224 */         Color color = getColor();
/* 169:226 */         if (color == null) {
/* 170:227 */           g.setColor(c.getSelectionColor());
/* 171:    */         } else {
/* 172:229 */           g.setColor(color);
/* 173:    */         }
/* 174:231 */         boolean firstIsDot = false;
/* 175:232 */         boolean secondIsDot = false;
/* 176:233 */         if (c.isEditable())
/* 177:    */         {
/* 178:234 */           int dot = c.getCaretPosition();
/* 179:235 */           firstIsDot = offs0 == dot;
/* 180:236 */           secondIsDot = offs1 == dot;
/* 181:    */         }
/* 182:238 */         if (p0.y == p1.y)
/* 183:    */         {
/* 184:240 */           Rectangle r = p0.union(p1);
/* 185:241 */           if (r.width > 0) {
/* 186:242 */             if (firstIsDot)
/* 187:    */             {
/* 188:243 */               r.x += 1;
/* 189:244 */               r.width -= 1;
/* 190:    */             }
/* 191:245 */             else if (secondIsDot)
/* 192:    */             {
/* 193:246 */               r.width -= 1;
/* 194:    */             }
/* 195:    */           }
/* 196:249 */           g.fillRect(r.x, r.y, r.width, r.height);
/* 197:    */         }
/* 198:    */         else
/* 199:    */         {
/* 200:252 */           int p0ToMarginWidth = alloc.x + alloc.width - p0.x;
/* 201:253 */           if ((firstIsDot) && (p0ToMarginWidth > 0))
/* 202:    */           {
/* 203:254 */             p0.x += 1;
/* 204:255 */             p0ToMarginWidth--;
/* 205:    */           }
/* 206:257 */           g.fillRect(p0.x, p0.y, p0ToMarginWidth, p0.height);
/* 207:258 */           if (p0.y + p0.height != p1.y) {
/* 208:259 */             g.fillRect(alloc.x, p0.y + p0.height, alloc.width, p1.y - (p0.y + p0.height));
/* 209:    */           }
/* 210:262 */           if ((secondIsDot) && (p1.x > alloc.x)) {
/* 211:263 */             p1.x -= 1;
/* 212:    */           }
/* 213:265 */           g.fillRect(alloc.x, p1.y, p1.x - alloc.x, p1.height);
/* 214:    */         }
/* 215:    */       }
/* 216:    */       catch (BadLocationException e) {}
/* 217:    */     }
/* 218:    */     
/* 219:    */     public Shape paintLayer(Graphics g, int offs0, int offs1, Shape bounds, JTextComponent c, View view)
/* 220:    */     {
/* 221:288 */       Color color = getColor();
/* 222:290 */       if (color == null) {
/* 223:291 */         g.setColor(c.getSelectionColor());
/* 224:    */       } else {
/* 225:293 */         g.setColor(color);
/* 226:    */       }
/* 227:295 */       boolean firstIsDot = false;
/* 228:296 */       boolean secondIsDot = false;
/* 229:297 */       if (c.isEditable())
/* 230:    */       {
/* 231:298 */         int dot = c.getCaretPosition();
/* 232:299 */         firstIsDot = offs0 == dot;
/* 233:300 */         secondIsDot = offs1 == dot;
/* 234:    */       }
/* 235:302 */       if ((offs0 == view.getStartOffset()) && (offs1 == view.getEndOffset()))
/* 236:    */       {
/* 237:    */         Rectangle alloc;
/* 238:    */         Rectangle alloc;
/* 239:305 */         if ((bounds instanceof Rectangle)) {
/* 240:306 */           alloc = (Rectangle)bounds;
/* 241:    */         } else {
/* 242:308 */           alloc = bounds.getBounds();
/* 243:    */         }
/* 244:310 */         if ((firstIsDot) && (alloc.width > 0)) {
/* 245:311 */           g.fillRect(alloc.x + 1, alloc.y, alloc.width - 1, alloc.height);
/* 246:313 */         } else if ((secondIsDot) && (alloc.width > 0)) {
/* 247:314 */           g.fillRect(alloc.x, alloc.y, alloc.width - 1, alloc.height);
/* 248:    */         } else {
/* 249:316 */           g.fillRect(alloc.x, alloc.y, alloc.width, alloc.height);
/* 250:    */         }
/* 251:318 */         return alloc;
/* 252:    */       }
/* 253:    */       try
/* 254:    */       {
/* 255:323 */         Shape shape = view.modelToView(offs0, Position.Bias.Forward, offs1, Position.Bias.Backward, bounds);
/* 256:    */         
/* 257:    */ 
/* 258:326 */         Rectangle r = (shape instanceof Rectangle) ? (Rectangle)shape : shape.getBounds();
/* 259:329 */         if ((firstIsDot) && (r.width > 0)) {
/* 260:330 */           g.fillRect(r.x + 1, r.y, r.width - 1, r.height);
/* 261:331 */         } else if ((secondIsDot) && (r.width > 0)) {
/* 262:332 */           g.fillRect(r.x, r.y, r.width - 1, r.height);
/* 263:    */         } else {
/* 264:334 */           g.fillRect(r.x, r.y, r.width, r.height);
/* 265:    */         }
/* 266:336 */         return r;
/* 267:    */       }
/* 268:    */       catch (BadLocationException e) {}
/* 269:342 */       return null;
/* 270:    */     }
/* 271:    */   }
/* 272:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.windows.WindowsFieldCaret
 * JD-Core Version:    0.7.0.1
 */
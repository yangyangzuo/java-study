package com.jgoodies.looks;

import javax.swing.UIDefaults;

public abstract interface FontPolicy
{
  public abstract FontSet getFontSet(String paramString, UIDefaults paramUIDefaults);
}


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.FontPolicy
 * JD-Core Version:    0.7.0.1
 */
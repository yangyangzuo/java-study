/*   1:    */ package com.jgoodies.looks;
/*   2:    */ 
/*   3:    */ import javax.swing.UIDefaults;
/*   4:    */ 
/*   5:    */ public final class MicroLayoutPolicies
/*   6:    */ {
/*   7:    */   public static MicroLayoutPolicy getDefaultPlasticPolicy()
/*   8:    */   {
/*   9: 66 */     return new DefaultPlasticPolicy(null);
/*  10:    */   }
/*  11:    */   
/*  12:    */   public static MicroLayoutPolicy getDefaultWindowsPolicy()
/*  13:    */   {
/*  14: 77 */     return new DefaultWindowsPolicy(null);
/*  15:    */   }
/*  16:    */   
/*  17:    */   private static final class DefaultPlasticPolicy
/*  18:    */     implements MicroLayoutPolicy
/*  19:    */   {
/*  20:    */     DefaultPlasticPolicy(MicroLayoutPolicies.1 x0)
/*  21:    */     {
/*  22: 87 */       this();
/*  23:    */     }
/*  24:    */     
/*  25:    */     public MicroLayout getMicroLayout(String lafName, UIDefaults table)
/*  26:    */     {
/*  27: 90 */       boolean isClassic = !LookUtils.IS_LAF_WINDOWS_XP_ENABLED;
/*  28: 91 */       boolean isVista = LookUtils.IS_OS_WINDOWS_VISTA;
/*  29: 92 */       boolean isLowRes = LookUtils.IS_LOW_RESOLUTION;
/*  30: 93 */       boolean isPlasticXP = lafName.equals("JGoodies Plastic XP");
/*  31: 94 */       if (isPlasticXP)
/*  32:    */       {
/*  33: 95 */         if (isVista) {
/*  34: 96 */           return isClassic ? MicroLayouts.createPlasticXPVistaClassicMicroLayout() : MicroLayouts.createPlasticXPVistaMicroLayout();
/*  35:    */         }
/*  36:100 */         return isLowRes ? MicroLayouts.createPlasticXPLowResMicroLayout() : MicroLayouts.createPlasticXPHiResMicroLayout();
/*  37:    */       }
/*  38:105 */       if (isVista) {
/*  39:106 */         return isClassic ? MicroLayouts.createPlasticVistaClassicMicroLayout() : MicroLayouts.createPlasticVistaMicroLayout();
/*  40:    */       }
/*  41:110 */       return isLowRes ? MicroLayouts.createPlasticLowResMicroLayout() : MicroLayouts.createPlasticHiResMicroLayout();
/*  42:    */     }
/*  43:    */     
/*  44:    */     private DefaultPlasticPolicy() {}
/*  45:    */   }
/*  46:    */   
/*  47:    */   private static final class DefaultWindowsPolicy
/*  48:    */     implements MicroLayoutPolicy
/*  49:    */   {
/*  50:    */     DefaultWindowsPolicy(MicroLayoutPolicies.1 x0)
/*  51:    */     {
/*  52:123 */       this();
/*  53:    */     }
/*  54:    */     
/*  55:    */     public MicroLayout getMicroLayout(String lafName, UIDefaults table)
/*  56:    */     {
/*  57:126 */       boolean isClassic = !LookUtils.IS_LAF_WINDOWS_XP_ENABLED;
/*  58:127 */       boolean isVista = LookUtils.IS_OS_WINDOWS_VISTA;
/*  59:128 */       boolean isLowRes = LookUtils.IS_LOW_RESOLUTION;
/*  60:129 */       if (isClassic) {
/*  61:130 */         return isLowRes ? MicroLayouts.createWindowsClassicLowResMicroLayout() : MicroLayouts.createWindowsClassicHiResMicroLayout();
/*  62:    */       }
/*  63:133 */       if (isVista) {
/*  64:134 */         return isLowRes ? MicroLayouts.createWindowsVistaLowResMicroLayout() : MicroLayouts.createWindowsVistaHiResMicroLayout();
/*  65:    */       }
/*  66:138 */       return isLowRes ? MicroLayouts.createWindowsXPLowResMicroLayout() : MicroLayouts.createWindowsXPHiResMicroLayout();
/*  67:    */     }
/*  68:    */     
/*  69:    */     private DefaultWindowsPolicy() {}
/*  70:    */   }
/*  71:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.MicroLayoutPolicies
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.jgoodies.looks;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.common.ShadowPopup;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Map;
/*   7:    */ import javax.swing.UIManager;
/*   8:    */ 
/*   9:    */ public final class Options
/*  10:    */ {
/*  11:    */   public static final String PLASTIC_NAME = "com.jgoodies.looks.plastic.PlasticLookAndFeel";
/*  12:    */   public static final String PLASTIC3D_NAME = "com.jgoodies.looks.plastic.Plastic3DLookAndFeel";
/*  13:    */   public static final String PLASTICXP_NAME = "com.jgoodies.looks.plastic.PlasticXPLookAndFeel";
/*  14:    */   public static final String JGOODIES_WINDOWS_NAME = "com.jgoodies.looks.windows.WindowsLookAndFeel";
/*  15:    */   public static final String DEFAULT_LOOK_NAME = "com.jgoodies.looks.plastic.PlasticXPLookAndFeel";
/*  16:102 */   private static final Map LAF_REPLACEMENTS = new HashMap();
/*  17:    */   public static final String PLASTIC_FONT_POLICY_KEY = "Plastic.fontPolicy";
/*  18:    */   public static final String PLASTIC_CONTROL_FONT_KEY = "Plastic.controlFont";
/*  19:    */   public static final String PLASTIC_MENU_FONT_KEY = "Plastic.menuFont";
/*  20:    */   public static final String WINDOWS_FONT_POLICY_KEY = "Windows.fontPolicy";
/*  21:    */   public static final String WINDOWS_CONTROL_FONT_KEY = "Windows.controlFont";
/*  22:    */   public static final String WINDOWS_MENU_FONT_KEY = "Windows.menuFont";
/*  23:    */   public static final String USE_SYSTEM_FONTS_KEY = "swing.useSystemFontSettings";
/*  24:    */   public static final String USE_SYSTEM_FONTS_APP_KEY = "Application.useSystemFontSettings";
/*  25:    */   public static final String PLASTIC_MICRO_LAYOUT_POLICY_KEY = "Plastic.MicroLayoutPolicy";
/*  26:    */   public static final String WINDOWS_MICRO_LAYOUT_POLICY_KEY = "Windows.MicroLayoutPolicy";
/*  27:    */   public static final String DEFAULT_ICON_SIZE_KEY = "jgoodies.defaultIconSize";
/*  28:    */   public static final String USE_NARROW_BUTTONS_KEY = "jgoodies.useNarrowButtons";
/*  29:    */   public static final String TAB_ICONS_ENABLED_KEY = "jgoodies.tabIconsEnabled";
/*  30:    */   public static final String POPUP_DROP_SHADOW_ENABLED_KEY = "jgoodies.popupDropShadowEnabled";
/*  31:    */   public static final String HI_RES_GRAY_FILTER_ENABLED_KEY = "HiResGrayFilterEnabled";
/*  32:    */   public static final String IS_ETCHED_KEY = "jgoodies.isEtched";
/*  33:    */   public static final String HEADER_STYLE_KEY = "jgoodies.headerStyle";
/*  34:    */   public static final String NO_ICONS_KEY = "jgoodies.noIcons";
/*  35:    */   public static final String NO_MARGIN_KEY = "JPopupMenu.noMargin";
/*  36:    */   public static final String TREE_LINE_STYLE_KEY = "JTree.lineStyle";
/*  37:    */   public static final String TREE_LINE_STYLE_ANGLED_VALUE = "Angled";
/*  38:    */   public static final String TREE_LINE_STYLE_NONE_VALUE = "None";
/*  39:    */   public static final String NO_CONTENT_BORDER_KEY = "jgoodies.noContentBorder";
/*  40:    */   public static final String EMBEDDED_TABS_KEY = "jgoodies.embeddedTabs";
/*  41:    */   public static final String COMBO_POPUP_PROTOTYPE_DISPLAY_VALUE_KEY = "ComboBox.popupPrototypeDisplayValue";
/*  42:    */   public static final String COMBO_RENDERER_IS_BORDER_REMOVABLE = "isBorderRemovable";
/*  43:    */   public static final String HI_RES_DISABLED_ICON_CLIENT_KEY = "generateHiResDisabledIcon";
/*  44:    */   
/*  45:    */   static
/*  46:    */   {
/*  47:103 */     initializeDefaultReplacements();
/*  48:    */   }
/*  49:    */   
/*  50:364 */   private static final Boolean USE_SYSTEM_FONTS_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty("swing.useSystemFontSettings", "Use system fonts");
/*  51:376 */   private static final Boolean USE_NARROW_BUTTONS_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty("jgoodies.useNarrowButtons", "Use narrow buttons");
/*  52:388 */   private static final Boolean TAB_ICONS_ENABLED_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty("jgoodies.tabIconsEnabled", "Icons in tabbed panes");
/*  53:406 */   private static final Boolean POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty("jgoodies.popupDropShadowEnabled", "Popup drop shadows");
/*  54:413 */   private static final Dimension DEFAULT_ICON_SIZE = new Dimension(20, 20);
/*  55:    */   public static final String NO_REPLACEMENT = "none";
/*  56:    */   
/*  57:    */   public static boolean getUseSystemFonts()
/*  58:    */   {
/*  59:434 */     return !Boolean.FALSE.equals(UIManager.get("Application.useSystemFontSettings")) ? true : USE_SYSTEM_FONTS_SYSTEM_VALUE != null ? USE_SYSTEM_FONTS_SYSTEM_VALUE.booleanValue() : false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static void setUseSystemFonts(boolean useSystemFonts)
/*  63:    */   {
/*  64:450 */     UIManager.put("Application.useSystemFontSettings", Boolean.valueOf(useSystemFonts));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static Dimension getDefaultIconSize()
/*  68:    */   {
/*  69:463 */     Dimension size = UIManager.getDimension("jgoodies.defaultIconSize");
/*  70:464 */     return size == null ? DEFAULT_ICON_SIZE : size;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static void setDefaultIconSize(Dimension defaultIconSize)
/*  74:    */   {
/*  75:475 */     UIManager.put("jgoodies.defaultIconSize", defaultIconSize);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static boolean getUseNarrowButtons()
/*  79:    */   {
/*  80:514 */     return !Boolean.FALSE.equals(UIManager.get("jgoodies.useNarrowButtons")) ? true : USE_NARROW_BUTTONS_SYSTEM_VALUE != null ? USE_NARROW_BUTTONS_SYSTEM_VALUE.booleanValue() : false;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void setUseNarrowButtons(boolean b)
/*  84:    */   {
/*  85:532 */     UIManager.put("jgoodies.useNarrowButtons", Boolean.valueOf(b));
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static boolean isTabIconsEnabled()
/*  89:    */   {
/*  90:544 */     return !Boolean.FALSE.equals(UIManager.get("jgoodies.tabIconsEnabled")) ? true : TAB_ICONS_ENABLED_SYSTEM_VALUE != null ? TAB_ICONS_ENABLED_SYSTEM_VALUE.booleanValue() : false;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static void setTabIconsEnabled(boolean b)
/*  94:    */   {
/*  95:557 */     UIManager.put("jgoodies.tabIconsEnabled", Boolean.valueOf(b));
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static boolean isPopupDropShadowActive()
/*  99:    */   {
/* 100:578 */     return (!LookUtils.getToolkitUsesNativeDropShadows()) && (ShadowPopup.canSnapshot()) && (isPopupDropShadowEnabled());
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static boolean isPopupDropShadowEnabled()
/* 104:    */   {
/* 105:594 */     if (POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE != null) {
/* 106:595 */       return POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE.booleanValue();
/* 107:    */     }
/* 108:597 */     Object value = UIManager.get("jgoodies.popupDropShadowEnabled");
/* 109:598 */     return value == null ? isPopupDropShadowEnabledDefault() : Boolean.TRUE.equals(value);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void setPopupDropShadowEnabled(boolean b)
/* 113:    */   {
/* 114:617 */     UIManager.put("jgoodies.popupDropShadowEnabled", Boolean.valueOf(b));
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static boolean isPopupDropShadowEnabledDefault()
/* 118:    */   {
/* 119:635 */     return LookUtils.IS_OS_WINDOWS_MODERN;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static boolean isHiResGrayFilterEnabled()
/* 123:    */   {
/* 124:652 */     return !Boolean.FALSE.equals(UIManager.get("HiResGrayFilterEnabled"));
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static void setHiResGrayFilterEnabled(boolean b)
/* 128:    */   {
/* 129:668 */     UIManager.put("HiResGrayFilterEnabled", Boolean.valueOf(b));
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static void putLookAndFeelReplacement(String original, String replacement)
/* 133:    */   {
/* 134:686 */     LAF_REPLACEMENTS.put(original, replacement);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static void removeLookAndFeelReplacement(String original)
/* 138:    */   {
/* 139:698 */     LAF_REPLACEMENTS.remove(original);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private static void initializeDefaultReplacements()
/* 143:    */   {
/* 144:723 */     putLookAndFeelReplacement("javax.swing.plaf.metal.MetalLookAndFeel", "com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
/* 145:    */     
/* 146:    */ 
/* 147:726 */     putLookAndFeelReplacement("com.sun.java.swing.plaf.windows.WindowsLookAndFeel", "com.jgoodies.looks.windows.WindowsLookAndFeel");
/* 148:    */     
/* 149:    */ 
/* 150:729 */     putLookAndFeelReplacement("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel", "none");
/* 151:    */   }
/* 152:    */   
/* 153:    */   public static String getReplacementClassNameFor(String className)
/* 154:    */   {
/* 155:745 */     String replacement = (String)LAF_REPLACEMENTS.get(className);
/* 156:746 */     if (replacement == null) {
/* 157:747 */       return className;
/* 158:    */     }
/* 159:748 */     if (replacement.equals("none")) {
/* 160:749 */       return null;
/* 161:    */     }
/* 162:751 */     return replacement;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static String getCrossPlatformLookAndFeelClassName()
/* 166:    */   {
/* 167:762 */     return "com.jgoodies.looks.plastic.PlasticXPLookAndFeel";
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static String getSystemLookAndFeelClassName()
/* 171:    */   {
/* 172:772 */     if (LookUtils.IS_OS_WINDOWS) {
/* 173:773 */       return "com.jgoodies.looks.windows.WindowsLookAndFeel";
/* 174:    */     }
/* 175:774 */     if (LookUtils.IS_OS_MAC) {
/* 176:775 */       return UIManager.getSystemLookAndFeelClassName();
/* 177:    */     }
/* 178:777 */     return getCrossPlatformLookAndFeelClassName();
/* 179:    */   }
/* 180:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.Options
 * JD-Core Version:    0.7.0.1
 */
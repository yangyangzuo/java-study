/*   1:    */ package com.jgoodies.looks.common;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.ComponentOrientation;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.LayoutManager;
/*   9:    */ import javax.swing.UIManager;
/*  10:    */ 
/*  11:    */ public final class ExtBasicSpinnerLayout
/*  12:    */   implements LayoutManager
/*  13:    */ {
/*  14: 56 */   private static final Dimension ZERO_SIZE = new Dimension(0, 0);
/*  15: 59 */   private Component nextButton = null;
/*  16: 60 */   private Component previousButton = null;
/*  17: 61 */   private Component editor = null;
/*  18:    */   
/*  19:    */   public void addLayoutComponent(String name, Component c)
/*  20:    */   {
/*  21: 65 */     if ("Next".equals(name)) {
/*  22: 66 */       this.nextButton = c;
/*  23: 67 */     } else if ("Previous".equals(name)) {
/*  24: 68 */       this.previousButton = c;
/*  25: 69 */     } else if ("Editor".equals(name)) {
/*  26: 70 */       this.editor = c;
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void removeLayoutComponent(Component c)
/*  31:    */   {
/*  32: 76 */     if (c == this.nextButton) {
/*  33: 77 */       c = null;
/*  34: 78 */     } else if (c == this.previousButton) {
/*  35: 79 */       this.previousButton = null;
/*  36: 80 */     } else if (c == this.editor) {
/*  37: 81 */       this.editor = null;
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   private Dimension preferredSize(Component c)
/*  42:    */   {
/*  43: 87 */     return c == null ? ZERO_SIZE : c.getPreferredSize();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Dimension preferredLayoutSize(Container parent)
/*  47:    */   {
/*  48: 92 */     Dimension nextD = preferredSize(this.nextButton);
/*  49: 93 */     Dimension previousD = preferredSize(this.previousButton);
/*  50: 94 */     Dimension editorD = preferredSize(this.editor);
/*  51:    */     
/*  52: 96 */     Dimension size = new Dimension(editorD.width, editorD.height);
/*  53: 97 */     size.width += Math.max(nextD.width, previousD.width);
/*  54: 98 */     Insets insets = parent.getInsets();
/*  55: 99 */     size.width += insets.left + insets.right;
/*  56:100 */     size.height += insets.top + insets.bottom;
/*  57:101 */     return size;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Dimension minimumLayoutSize(Container parent)
/*  61:    */   {
/*  62:106 */     return preferredLayoutSize(parent);
/*  63:    */   }
/*  64:    */   
/*  65:    */   private void setBounds(Component c, int x, int y, int width, int height)
/*  66:    */   {
/*  67:111 */     if (c != null) {
/*  68:112 */       c.setBounds(x, y, width, height);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void layoutContainer(Container parent)
/*  73:    */   {
/*  74:118 */     int width = parent.getWidth();
/*  75:119 */     int height = parent.getHeight();
/*  76:    */     
/*  77:121 */     Insets insets = parent.getInsets();
/*  78:122 */     Dimension nextD = preferredSize(this.nextButton);
/*  79:123 */     Dimension previousD = preferredSize(this.previousButton);
/*  80:124 */     int buttonsWidth = Math.max(nextD.width, previousD.width);
/*  81:125 */     int editorHeight = height - (insets.top + insets.bottom);
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:132 */     Insets buttonInsets = UIManager.getInsets("Spinner.arrowButtonInsets");
/*  89:134 */     if (buttonInsets == null) {
/*  90:135 */       buttonInsets = insets;
/*  91:    */     }
/*  92:    */     int buttonsX;
/*  93:    */     int buttonsX;
/*  94:    */     int editorX;
/*  95:    */     int editorWidth;
/*  96:142 */     if (parent.getComponentOrientation().isLeftToRight())
/*  97:    */     {
/*  98:143 */       int editorX = insets.left;
/*  99:144 */       int editorWidth = width - insets.left - buttonsWidth - buttonInsets.right;
/* 100:    */       
/* 101:146 */       buttonsX = width - buttonsWidth - buttonInsets.right;
/* 102:    */     }
/* 103:    */     else
/* 104:    */     {
/* 105:148 */       buttonsX = buttonInsets.left;
/* 106:149 */       editorX = buttonsX + buttonsWidth;
/* 107:150 */       editorWidth = width - buttonInsets.left - buttonsWidth - insets.right;
/* 108:    */     }
/* 109:154 */     int nextY = buttonInsets.top;
/* 110:155 */     int nextHeight = height / 2 + height % 2 - nextY;
/* 111:156 */     int previousY = buttonInsets.top + nextHeight;
/* 112:157 */     int previousHeight = height - previousY - buttonInsets.bottom;
/* 113:    */     
/* 114:159 */     setBounds(this.editor, editorX, insets.top, editorWidth, editorHeight);
/* 115:160 */     setBounds(this.nextButton, buttonsX, nextY, buttonsWidth, nextHeight);
/* 116:161 */     setBounds(this.previousButton, buttonsX, previousY, buttonsWidth, previousHeight);
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicSpinnerLayout
 * JD-Core Version:    0.7.0.1
 */
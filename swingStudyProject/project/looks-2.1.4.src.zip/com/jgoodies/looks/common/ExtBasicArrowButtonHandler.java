/*   1:    */ package com.jgoodies.looks.common;
/*   2:    */ 
/*   3:    */ import java.awt.AWTEvent;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.FocusTraversalPolicy;
/*   7:    */ import java.awt.KeyboardFocusManager;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.FocusEvent;
/*  10:    */ import java.awt.event.FocusListener;
/*  11:    */ import java.awt.event.MouseEvent;
/*  12:    */ import java.awt.event.MouseListener;
/*  13:    */ import java.text.AttributedCharacterIterator;
/*  14:    */ import java.text.DateFormat.Field;
/*  15:    */ import java.text.Format;
/*  16:    */ import java.text.Format.Field;
/*  17:    */ import java.text.ParseException;
/*  18:    */ import java.util.Map;
/*  19:    */ import javax.swing.AbstractAction;
/*  20:    */ import javax.swing.ButtonModel;
/*  21:    */ import javax.swing.JButton;
/*  22:    */ import javax.swing.JComponent;
/*  23:    */ import javax.swing.JFormattedTextField;
/*  24:    */ import javax.swing.JFormattedTextField.AbstractFormatter;
/*  25:    */ import javax.swing.JSpinner;
/*  26:    */ import javax.swing.JSpinner.DateEditor;
/*  27:    */ import javax.swing.LookAndFeel;
/*  28:    */ import javax.swing.SpinnerDateModel;
/*  29:    */ import javax.swing.SwingUtilities;
/*  30:    */ import javax.swing.Timer;
/*  31:    */ import javax.swing.UIManager;
/*  32:    */ import javax.swing.text.Document;
/*  33:    */ import javax.swing.text.InternationalFormatter;
/*  34:    */ 
/*  35:    */ public final class ExtBasicArrowButtonHandler
/*  36:    */   extends AbstractAction
/*  37:    */   implements MouseListener, FocusListener
/*  38:    */ {
/*  39:    */   private final Timer autoRepeatTimer;
/*  40:    */   private final boolean isNext;
/*  41:    */   private JSpinner spinner;
/*  42:    */   private JButton arrowButton;
/*  43:    */   
/*  44:    */   public ExtBasicArrowButtonHandler(String name, boolean isNext)
/*  45:    */   {
/*  46: 64 */     super(name);
/*  47: 65 */     this.isNext = isNext;
/*  48: 66 */     this.autoRepeatTimer = new Timer(60, this);
/*  49: 67 */     this.autoRepeatTimer.setInitialDelay(300);
/*  50:    */   }
/*  51:    */   
/*  52:    */   private JSpinner eventToSpinner(AWTEvent e)
/*  53:    */   {
/*  54: 72 */     Object src = e.getSource();
/*  55: 73 */     while (((src instanceof Component)) && (!(src instanceof JSpinner))) {
/*  56: 74 */       src = ((Component)src).getParent();
/*  57:    */     }
/*  58: 76 */     return (src instanceof JSpinner) ? (JSpinner)src : null;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void actionPerformed(ActionEvent e)
/*  62:    */   {
/*  63: 81 */     JSpinner spinner = this.spinner;
/*  64: 83 */     if (!(e.getSource() instanceof Timer))
/*  65:    */     {
/*  66: 85 */       spinner = eventToSpinner(e);
/*  67: 86 */       if ((e.getSource() instanceof JButton)) {
/*  68: 87 */         this.arrowButton = ((JButton)e.getSource());
/*  69:    */       }
/*  70:    */     }
/*  71: 90 */     else if ((this.arrowButton != null) && (!this.arrowButton.getModel().isPressed()) && (this.autoRepeatTimer.isRunning()))
/*  72:    */     {
/*  73: 92 */       this.autoRepeatTimer.stop();
/*  74: 93 */       spinner = null;
/*  75: 94 */       this.arrowButton = null;
/*  76:    */     }
/*  77: 97 */     if (spinner != null) {
/*  78:    */       try
/*  79:    */       {
/*  80: 99 */         int calendarField = getCalendarField(spinner);
/*  81:100 */         spinner.commitEdit();
/*  82:101 */         if (calendarField != -1) {
/*  83:102 */           ((SpinnerDateModel)spinner.getModel()).setCalendarField(calendarField);
/*  84:    */         }
/*  85:105 */         Object value = this.isNext ? spinner.getNextValue() : spinner.getPreviousValue();
/*  86:107 */         if (value != null)
/*  87:    */         {
/*  88:108 */           spinner.setValue(value);
/*  89:109 */           select(spinner);
/*  90:    */         }
/*  91:    */       }
/*  92:    */       catch (IllegalArgumentException iae)
/*  93:    */       {
/*  94:112 */         UIManager.getLookAndFeel().provideErrorFeedback(spinner);
/*  95:    */       }
/*  96:    */       catch (ParseException pe)
/*  97:    */       {
/*  98:114 */         UIManager.getLookAndFeel().provideErrorFeedback(spinner);
/*  99:    */       }
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   private void select(JSpinner aSpinner)
/* 104:    */   {
/* 105:125 */     JComponent editor = aSpinner.getEditor();
/* 106:127 */     if ((editor instanceof JSpinner.DateEditor))
/* 107:    */     {
/* 108:128 */       JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
/* 109:129 */       JFormattedTextField ftf = dateEditor.getTextField();
/* 110:130 */       Format format = dateEditor.getFormat();
/* 111:    */       Object value;
/* 112:133 */       if ((format != null) && ((value = aSpinner.getValue()) != null))
/* 113:    */       {
/* 114:134 */         SpinnerDateModel model = dateEditor.getModel();
/* 115:135 */         DateFormat.Field field = DateFormat.Field.ofCalendarField(model.getCalendarField());
/* 116:138 */         if (field != null) {
/* 117:    */           try
/* 118:    */           {
/* 119:140 */             AttributedCharacterIterator iterator = format.formatToCharacterIterator(value);
/* 120:142 */             if ((!select(ftf, iterator, field)) && (field == DateFormat.Field.HOUR0)) {
/* 121:144 */               select(ftf, iterator, DateFormat.Field.HOUR1);
/* 122:    */             }
/* 123:    */           }
/* 124:    */           catch (IllegalArgumentException iae) {}
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private boolean select(JFormattedTextField ftf, AttributedCharacterIterator iterator, DateFormat.Field field)
/* 131:    */   {
/* 132:160 */     int max = ftf.getDocument().getLength();
/* 133:    */     
/* 134:162 */     iterator.first();
/* 135:    */     do
/* 136:    */     {
/* 137:164 */       Map attrs = iterator.getAttributes();
/* 138:166 */       if ((attrs != null) && (attrs.containsKey(field)))
/* 139:    */       {
/* 140:167 */         int start = iterator.getRunStart(field);
/* 141:168 */         int end = iterator.getRunLimit(field);
/* 142:170 */         if ((start != -1) && (end != -1) && (start <= max) && (end <= max)) {
/* 143:171 */           ftf.select(start, end);
/* 144:    */         }
/* 145:173 */         return true;
/* 146:    */       }
/* 147:175 */     } while (iterator.next() != 65535);
/* 148:176 */     return false;
/* 149:    */   }
/* 150:    */   
/* 151:    */   private int getCalendarField(JSpinner aSpinner)
/* 152:    */   {
/* 153:186 */     JComponent editor = aSpinner.getEditor();
/* 154:188 */     if ((editor instanceof JSpinner.DateEditor))
/* 155:    */     {
/* 156:189 */       JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
/* 157:190 */       JFormattedTextField ftf = dateEditor.getTextField();
/* 158:191 */       int start = ftf.getSelectionStart();
/* 159:192 */       JFormattedTextField.AbstractFormatter formatter = ftf.getFormatter();
/* 160:195 */       if ((formatter instanceof InternationalFormatter))
/* 161:    */       {
/* 162:196 */         Format.Field[] fields = ((InternationalFormatter)formatter).getFields(start);
/* 163:199 */         for (int counter = 0; counter < fields.length; counter++) {
/* 164:200 */           if ((fields[counter] instanceof DateFormat.Field))
/* 165:    */           {
/* 166:    */             int calendarField;
/* 167:    */             int calendarField;
/* 168:203 */             if (fields[counter] == DateFormat.Field.HOUR1) {
/* 169:204 */               calendarField = 10;
/* 170:    */             } else {
/* 171:206 */               calendarField = ((DateFormat.Field)fields[counter]).getCalendarField();
/* 172:    */             }
/* 173:209 */             if (calendarField != -1) {
/* 174:209 */               return calendarField;
/* 175:    */             }
/* 176:    */           }
/* 177:    */         }
/* 178:    */       }
/* 179:    */     }
/* 180:214 */     return -1;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void mousePressed(MouseEvent e)
/* 184:    */   {
/* 185:219 */     if ((SwingUtilities.isLeftMouseButton(e)) && (e.getComponent().isEnabled()))
/* 186:    */     {
/* 187:220 */       this.spinner = eventToSpinner(e);
/* 188:221 */       this.autoRepeatTimer.start();
/* 189:222 */       focusSpinnerIfNecessary();
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void mouseReleased(MouseEvent e)
/* 194:    */   {
/* 195:228 */     this.autoRepeatTimer.stop();
/* 196:229 */     this.spinner = null;
/* 197:230 */     this.arrowButton = null;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void mouseClicked(MouseEvent e) {}
/* 201:    */   
/* 202:    */   public void mouseEntered(MouseEvent e)
/* 203:    */   {
/* 204:240 */     if ((this.spinner != null) && (!this.autoRepeatTimer.isRunning())) {
/* 205:241 */       this.autoRepeatTimer.start();
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void mouseExited(MouseEvent e)
/* 210:    */   {
/* 211:247 */     if (this.autoRepeatTimer.isRunning()) {
/* 212:248 */       this.autoRepeatTimer.stop();
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */   private void focusSpinnerIfNecessary()
/* 217:    */   {
/* 218:258 */     Component fo = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 219:260 */     if ((this.spinner.isRequestFocusEnabled()) && ((fo == null) || (!SwingUtilities.isDescendingFrom(fo, this.spinner))))
/* 220:    */     {
/* 221:262 */       Container root = this.spinner;
/* 222:264 */       if (!root.isFocusCycleRoot()) {
/* 223:265 */         root = root.getFocusCycleRootAncestor();
/* 224:    */       }
/* 225:267 */       if (root != null)
/* 226:    */       {
/* 227:268 */         FocusTraversalPolicy ftp = root.getFocusTraversalPolicy();
/* 228:269 */         Component child = ftp.getComponentAfter(root, this.spinner);
/* 229:271 */         if ((child != null) && (SwingUtilities.isDescendingFrom(child, this.spinner))) {
/* 230:273 */           child.requestFocus();
/* 231:    */         }
/* 232:    */       }
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   public void focusGained(FocusEvent e) {}
/* 237:    */   
/* 238:    */   public void focusLost(FocusEvent e)
/* 239:    */   {
/* 240:286 */     if (this.autoRepeatTimer.isRunning()) {
/* 241:287 */       this.autoRepeatTimer.stop();
/* 242:    */     }
/* 243:289 */     this.spinner = null;
/* 244:290 */     if (this.arrowButton != null)
/* 245:    */     {
/* 246:291 */       ButtonModel model = this.arrowButton.getModel();
/* 247:292 */       model.setPressed(false);
/* 248:293 */       model.setArmed(false);
/* 249:294 */       this.arrowButton = null;
/* 250:    */     }
/* 251:    */   }
/* 252:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicArrowButtonHandler
 * JD-Core Version:    0.7.0.1
 */
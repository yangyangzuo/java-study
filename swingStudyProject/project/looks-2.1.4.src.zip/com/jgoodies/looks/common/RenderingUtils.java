/*   1:    */ package com.jgoodies.looks.common;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.LookUtils;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.awt.Graphics2D;
/*   6:    */ import java.awt.GraphicsConfiguration;
/*   7:    */ import java.awt.GraphicsDevice;
/*   8:    */ import java.awt.PrintGraphics;
/*   9:    */ import java.awt.RenderingHints;
/*  10:    */ import java.awt.RenderingHints.Key;
/*  11:    */ import java.awt.Toolkit;
/*  12:    */ import java.awt.print.PrinterGraphics;
/*  13:    */ import java.lang.reflect.InvocationTargetException;
/*  14:    */ import java.lang.reflect.Method;
/*  15:    */ import java.util.HashMap;
/*  16:    */ import java.util.Iterator;
/*  17:    */ import java.util.Map;
/*  18:    */ import java.util.Set;
/*  19:    */ import javax.swing.JComponent;
/*  20:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  21:    */ 
/*  22:    */ public final class RenderingUtils
/*  23:    */ {
/*  24:    */   private static final String PROP_DESKTOPHINTS = "awt.font.desktophints";
/*  25: 69 */   private static final String SWING_UTILITIES2_NAME = LookUtils.IS_JAVA_6_OR_LATER ? "sun.swing.SwingUtilities2" : "com.sun.java.swing.SwingUtilities2";
/*  26: 79 */   private static Method drawStringUnderlineCharAtMethod = null;
/*  27:    */   
/*  28:    */   static
/*  29:    */   {
/*  30: 82 */     if (LookUtils.IS_JAVA_5_OR_LATER) {
/*  31: 83 */       drawStringUnderlineCharAtMethod = getMethodDrawStringUnderlineCharAt();
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void drawStringUnderlineCharAt(JComponent c, Graphics g, String text, int underlinedIndex, int x, int y)
/*  36:    */   {
/*  37:105 */     if (LookUtils.IS_JAVA_5_OR_LATER)
/*  38:    */     {
/*  39:106 */       if (drawStringUnderlineCharAtMethod != null) {
/*  40:    */         try
/*  41:    */         {
/*  42:108 */           drawStringUnderlineCharAtMethod.invoke(null, new Object[] { c, g, text, new Integer(underlinedIndex), new Integer(x), new Integer(y) });
/*  43:    */           
/*  44:    */ 
/*  45:111 */           return;
/*  46:    */         }
/*  47:    */         catch (IllegalArgumentException e) {}catch (IllegalAccessException e) {}catch (InvocationTargetException e) {}
/*  48:    */       }
/*  49:120 */       Graphics2D g2 = (Graphics2D)g;
/*  50:121 */       Map oldRenderingHints = installDesktopHints(g2);
/*  51:122 */       BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, underlinedIndex, x, y);
/*  52:123 */       if (oldRenderingHints != null) {
/*  53:124 */         g2.addRenderingHints(oldRenderingHints);
/*  54:    */       }
/*  55:126 */       return;
/*  56:    */     }
/*  57:128 */     BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, underlinedIndex, x, y);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static Method getMethodDrawStringUnderlineCharAt()
/*  61:    */   {
/*  62:    */     try
/*  63:    */     {
/*  64:137 */       Class clazz = Class.forName(SWING_UTILITIES2_NAME);
/*  65:138 */       return clazz.getMethod("drawStringUnderlineCharAt", new Class[] { JComponent.class, Graphics.class, String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*  66:    */     }
/*  67:    */     catch (ClassNotFoundException e) {}catch (SecurityException e) {}catch (NoSuchMethodException e) {}
/*  68:149 */     return null;
/*  69:    */   }
/*  70:    */   
/*  71:    */   private static Map installDesktopHints(Graphics2D g2)
/*  72:    */   {
/*  73:154 */     Map oldRenderingHints = null;
/*  74:155 */     if (LookUtils.IS_JAVA_6_OR_LATER)
/*  75:    */     {
/*  76:156 */       Map desktopHints = desktopHints(g2);
/*  77:157 */       if ((desktopHints != null) && (!desktopHints.isEmpty()))
/*  78:    */       {
/*  79:158 */         oldRenderingHints = new HashMap(desktopHints.size());
/*  80:160 */         for (Iterator i = desktopHints.keySet().iterator(); i.hasNext();)
/*  81:    */         {
/*  82:161 */           RenderingHints.Key key = (RenderingHints.Key)i.next();
/*  83:162 */           oldRenderingHints.put(key, g2.getRenderingHint(key));
/*  84:    */         }
/*  85:164 */         g2.addRenderingHints(desktopHints);
/*  86:    */       }
/*  87:    */     }
/*  88:167 */     return oldRenderingHints;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static Map desktopHints(Graphics2D g2)
/*  92:    */   {
/*  93:172 */     if (isPrinting(g2)) {
/*  94:173 */       return null;
/*  95:    */     }
/*  96:175 */     Toolkit toolkit = Toolkit.getDefaultToolkit();
/*  97:176 */     GraphicsDevice device = g2.getDeviceConfiguration().getDevice();
/*  98:177 */     Map desktopHints = (Map)toolkit.getDesktopProperty("awt.font.desktophints." + device.getIDstring());
/*  99:179 */     if (desktopHints == null) {
/* 100:180 */       desktopHints = (Map)toolkit.getDesktopProperty("awt.font.desktophints");
/* 101:    */     }
/* 102:183 */     if (desktopHints != null)
/* 103:    */     {
/* 104:184 */       Object aaHint = desktopHints.get(RenderingHints.KEY_TEXT_ANTIALIASING);
/* 105:185 */       if ((aaHint == RenderingHints.VALUE_TEXT_ANTIALIAS_OFF) || (aaHint == RenderingHints.VALUE_TEXT_ANTIALIAS_DEFAULT)) {
/* 106:187 */         desktopHints = null;
/* 107:    */       }
/* 108:    */     }
/* 109:190 */     return desktopHints;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static boolean isPrinting(Graphics g)
/* 113:    */   {
/* 114:195 */     return ((g instanceof PrintGraphics)) || ((g instanceof PrinterGraphics));
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.common.RenderingUtils
 * JD-Core Version:    0.7.0.1
 */
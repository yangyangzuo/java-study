/*   1:    */ package com.jgoodies.looks;
/*   2:    */ 
/*   3:    */ import java.awt.Font;
/*   4:    */ import javax.swing.UIDefaults;
/*   5:    */ 
/*   6:    */ public final class FontPolicies
/*   7:    */ {
/*   8:    */   public static FontPolicy createFixedPolicy(FontSet fontSet)
/*   9:    */   {
/*  10: 81 */     return new FixedPolicy(fontSet);
/*  11:    */   }
/*  12:    */   
/*  13:    */   public static FontPolicy customSettingsPolicy(FontPolicy defaultPolicy)
/*  14:    */   {
/*  15: 96 */     return new CustomSettingsPolicy(defaultPolicy);
/*  16:    */   }
/*  17:    */   
/*  18:    */   public static FontPolicy getDefaultPlasticOnWindowsPolicy()
/*  19:    */   {
/*  20:122 */     return new DefaultPlasticOnWindowsPolicy(null);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static FontPolicy getDefaultPlasticPolicy()
/*  24:    */   {
/*  25:138 */     if (LookUtils.IS_OS_WINDOWS) {
/*  26:139 */       return getDefaultPlasticOnWindowsPolicy();
/*  27:    */     }
/*  28:141 */     return getLogicalFontsPolicy();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static FontPolicy getDefaultWindowsPolicy()
/*  32:    */   {
/*  33:158 */     return new DefaultWindowsPolicy(null);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static FontPolicy getLogicalFontsPolicy()
/*  37:    */   {
/*  38:169 */     return createFixedPolicy(FontSets.getLogicalFontSet());
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static FontPolicy getLooks1xPlasticPolicy()
/*  42:    */   {
/*  43:183 */     Font controlFont = Fonts.getDefaultGUIFontWesternModernWindowsNormal();
/*  44:184 */     Font menuFont = controlFont;
/*  45:185 */     Font titleFont = controlFont.deriveFont(1);
/*  46:186 */     FontSet fontSet = FontSets.createDefaultFontSet(controlFont, menuFont, titleFont);
/*  47:187 */     return createFixedPolicy(fontSet);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static FontPolicy getLooks1xWindowsPolicy()
/*  51:    */   {
/*  52:201 */     return new Looks1xWindowsPolicy(null);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static FontPolicy getTransitionalPlasticPolicy()
/*  56:    */   {
/*  57:215 */     return LookUtils.IS_OS_WINDOWS ? getDefaultPlasticOnWindowsPolicy() : getLooks1xPlasticPolicy();
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static FontSet getCustomFontSet(String lafName)
/*  61:    */   {
/*  62:233 */     String controlFontKey = lafName + ".controlFont";
/*  63:234 */     String menuFontKey = lafName + ".menuFont";
/*  64:235 */     String decodedControlFont = LookUtils.getSystemProperty(controlFontKey);
/*  65:236 */     if (decodedControlFont == null) {
/*  66:237 */       return null;
/*  67:    */     }
/*  68:238 */     Font controlFont = Font.decode(decodedControlFont);
/*  69:239 */     String decodedMenuFont = LookUtils.getSystemProperty(menuFontKey);
/*  70:240 */     Font menuFont = decodedMenuFont != null ? Font.decode(decodedMenuFont) : null;
/*  71:    */     
/*  72:    */ 
/*  73:243 */     Font titleFont = "Plastic".equals(lafName) ? controlFont.deriveFont(1) : controlFont;
/*  74:    */     
/*  75:    */ 
/*  76:246 */     return FontSets.createDefaultFontSet(controlFont, menuFont, titleFont);
/*  77:    */   }
/*  78:    */   
/*  79:    */   private static FontPolicy getCustomPolicy(String lafName)
/*  80:    */   {
/*  81:261 */     return null;
/*  82:    */   }
/*  83:    */   
/*  84:    */   private static final class CustomSettingsPolicy
/*  85:    */     implements FontPolicy
/*  86:    */   {
/*  87:    */     private final FontPolicy wrappedPolicy;
/*  88:    */     
/*  89:    */     CustomSettingsPolicy(FontPolicy wrappedPolicy)
/*  90:    */     {
/*  91:270 */       this.wrappedPolicy = wrappedPolicy;
/*  92:    */     }
/*  93:    */     
/*  94:    */     public FontSet getFontSet(String lafName, UIDefaults table)
/*  95:    */     {
/*  96:274 */       FontPolicy customPolicy = FontPolicies.getCustomPolicy(lafName);
/*  97:275 */       if (customPolicy != null) {
/*  98:276 */         return customPolicy.getFontSet(null, table);
/*  99:    */       }
/* 100:278 */       FontSet customFontSet = FontPolicies.getCustomFontSet(lafName);
/* 101:279 */       if (customFontSet != null) {
/* 102:280 */         return customFontSet;
/* 103:    */       }
/* 104:282 */       return this.wrappedPolicy.getFontSet(lafName, table);
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static final class DefaultPlasticOnWindowsPolicy
/* 109:    */     implements FontPolicy
/* 110:    */   {
/* 111:    */     DefaultPlasticOnWindowsPolicy(FontPolicies.1 x0)
/* 112:    */     {
/* 113:302 */       this();
/* 114:    */     }
/* 115:    */     
/* 116:    */     public FontSet getFontSet(String lafName, UIDefaults table)
/* 117:    */     {
/* 118:305 */       Font windowsControlFont = Fonts.getWindowsControlFont();
/* 119:    */       Font controlFont;
/* 120:    */       Font controlFont;
/* 121:307 */       if (windowsControlFont != null)
/* 122:    */       {
/* 123:308 */         controlFont = windowsControlFont;
/* 124:    */       }
/* 125:    */       else
/* 126:    */       {
/* 127:    */         Font controlFont;
/* 128:309 */         if (table != null) {
/* 129:310 */           controlFont = table.getFont("Button.font");
/* 130:    */         } else {
/* 131:312 */           controlFont = new Font("Dialog", 0, 12);
/* 132:    */         }
/* 133:    */       }
/* 134:315 */       Font menuFont = table == null ? controlFont : table.getFont("Menu.font");
/* 135:    */       
/* 136:    */ 
/* 137:318 */       Font titleFont = controlFont.deriveFont(1);
/* 138:    */       
/* 139:320 */       return FontSets.createDefaultFontSet(controlFont, menuFont, titleFont);
/* 140:    */     }
/* 141:    */     
/* 142:    */     private DefaultPlasticOnWindowsPolicy() {}
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static final class DefaultWindowsPolicy
/* 146:    */     implements FontPolicy
/* 147:    */   {
/* 148:    */     DefaultWindowsPolicy(FontPolicies.1 x0)
/* 149:    */     {
/* 150:328 */       this();
/* 151:    */     }
/* 152:    */     
/* 153:    */     public FontSet getFontSet(String lafName, UIDefaults table)
/* 154:    */     {
/* 155:331 */       Font windowsControlFont = Fonts.getWindowsControlFont();
/* 156:    */       Font controlFont;
/* 157:    */       Font controlFont;
/* 158:333 */       if (windowsControlFont != null)
/* 159:    */       {
/* 160:334 */         controlFont = windowsControlFont;
/* 161:    */       }
/* 162:    */       else
/* 163:    */       {
/* 164:    */         Font controlFont;
/* 165:335 */         if (table != null) {
/* 166:336 */           controlFont = table.getFont("Button.font");
/* 167:    */         } else {
/* 168:338 */           controlFont = new Font("Dialog", 0, 12);
/* 169:    */         }
/* 170:    */       }
/* 171:340 */       Font menuFont = table == null ? controlFont : table.getFont("Menu.font");
/* 172:    */       
/* 173:    */ 
/* 174:343 */       Font titleFont = controlFont;
/* 175:344 */       Font messageFont = table == null ? controlFont : table.getFont("OptionPane.font");
/* 176:    */       
/* 177:    */ 
/* 178:347 */       Font smallFont = table == null ? controlFont.deriveFont(controlFont.getSize2D() - 2.0F) : table.getFont("ToolTip.font");
/* 179:    */       
/* 180:    */ 
/* 181:350 */       Font windowTitleFont = table == null ? controlFont : table.getFont("InternalFrame.titleFont");
/* 182:    */       
/* 183:    */ 
/* 184:353 */       return FontSets.createDefaultFontSet(controlFont, menuFont, titleFont, messageFont, smallFont, windowTitleFont);
/* 185:    */     }
/* 186:    */     
/* 187:    */     private DefaultWindowsPolicy() {}
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static final class FixedPolicy
/* 191:    */     implements FontPolicy
/* 192:    */   {
/* 193:    */     private final FontSet fontSet;
/* 194:    */     
/* 195:    */     FixedPolicy(FontSet fontSet)
/* 196:    */     {
/* 197:373 */       this.fontSet = fontSet;
/* 198:    */     }
/* 199:    */     
/* 200:    */     public FontSet getFontSet(String lafName, UIDefaults table)
/* 201:    */     {
/* 202:377 */       return this.fontSet;
/* 203:    */     }
/* 204:    */   }
/* 205:    */   
/* 206:    */   private static final class Looks1xWindowsPolicy
/* 207:    */     implements FontPolicy
/* 208:    */   {
/* 209:    */     Looks1xWindowsPolicy(FontPolicies.1 x0)
/* 210:    */     {
/* 211:385 */       this();
/* 212:    */     }
/* 213:    */     
/* 214:    */     public FontSet getFontSet(String lafName, UIDefaults table)
/* 215:    */     {
/* 216:388 */       Font windowsControlFont = Fonts.getLooks1xWindowsControlFont();
/* 217:    */       Font controlFont;
/* 218:    */       Font controlFont;
/* 219:390 */       if (windowsControlFont != null)
/* 220:    */       {
/* 221:391 */         controlFont = windowsControlFont;
/* 222:    */       }
/* 223:    */       else
/* 224:    */       {
/* 225:    */         Font controlFont;
/* 226:392 */         if (table != null) {
/* 227:393 */           controlFont = table.getFont("Button.font");
/* 228:    */         } else {
/* 229:395 */           controlFont = new Font("Dialog", 0, 12);
/* 230:    */         }
/* 231:    */       }
/* 232:397 */       return FontSets.createDefaultFontSet(controlFont);
/* 233:    */     }
/* 234:    */     
/* 235:    */     private Looks1xWindowsPolicy() {}
/* 236:    */   }
/* 237:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.FontPolicies
 * JD-Core Version:    0.7.0.1
 */
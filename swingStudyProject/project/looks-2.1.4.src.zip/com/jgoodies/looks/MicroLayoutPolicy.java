package com.jgoodies.looks;

import javax.swing.UIDefaults;

public abstract interface MicroLayoutPolicy
{
  public abstract MicroLayout getMicroLayout(String paramString, UIDefaults paramUIDefaults);
}


/* Location:           C:\Users\Administrator\Desktop\download\looks-2.1.4.jar
 * Qualified Name:     com.jgoodies.looks.MicroLayoutPolicy
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import twaver.TWaverUtil;
/*  6:   */ 
/*  7:   */ public class FreeGarbageCollectButton
/*  8:   */   extends FreeToolbarButton
/*  9:   */ {
/* 10:   */   public FreeGarbageCollectButton()
/* 11:   */   {
/* 12:10 */     setIcon(TWaverUtil.getIcon("/free/test/gc.png"));
/* 13:11 */     setToolTipText("Click to call garbage collector");
/* 14:12 */     addActionListener(new ActionListener()
/* 15:   */     {
/* 16:   */       public void actionPerformed(ActionEvent e) {}
/* 17:   */     });
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeGarbageCollectButton
 * JD-Core Version:    0.7.0.1
 */
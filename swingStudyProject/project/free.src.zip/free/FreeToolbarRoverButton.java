/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Image;
/*  5:   */ import javax.swing.Icon;
/*  6:   */ import javax.swing.ImageIcon;
/*  7:   */ 
/*  8:   */ public class FreeToolbarRoverButton
/*  9:   */   extends FreeToolbarButton
/* 10:   */ {
/* 11:10 */   private Color roverDyeColor = new Color(86, 146, 61);
/* 12:   */   
/* 13:   */   public FreeToolbarRoverButton()
/* 14:   */   {
/* 15:13 */     this(null, null);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public FreeToolbarRoverButton(String text)
/* 19:   */   {
/* 20:17 */     this(text, null);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public FreeToolbarRoverButton(Icon icon)
/* 24:   */   {
/* 25:21 */     this(null, icon);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public FreeToolbarRoverButton(String text, Icon icon)
/* 29:   */   {
/* 30:25 */     setText(text);
/* 31:26 */     setIcon(icon);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setIcon(Icon icon)
/* 35:   */   {
/* 36:31 */     super.setIcon(icon);
/* 37:34 */     if (icon == null)
/* 38:   */     {
/* 39:35 */       setPressedIcon(null);
/* 40:36 */       setRolloverIcon(null);
/* 41:   */     }
/* 42:   */     else
/* 43:   */     {
/* 44:38 */       Image image = FreeUtil.iconToImage(icon);
/* 45:39 */       Icon roverIcon = FreeUtil.createDyedIcon(new ImageIcon(image), this.roverDyeColor);
/* 46:40 */       Icon pressedIcon = FreeUtil.createMovedIcon(roverIcon);
/* 47:41 */       setRolloverIcon(roverIcon);
/* 48:42 */       setPressedIcon(pressedIcon);
/* 49:   */     }
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeToolbarRoverButton
 * JD-Core Version:    0.7.0.1
 */
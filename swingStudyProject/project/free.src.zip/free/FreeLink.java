/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import twaver.RotatableNode;
/*  4:   */ 
/*  5:   */ public class FreeLink
/*  6:   */   extends RotatableNode
/*  7:   */ {
/*  8: 8 */   private int direction = 3;
/*  9:   */   
/* 10:   */   public FreeLink()
/* 11:   */   {
/* 12:11 */     init();
/* 13:   */   }
/* 14:   */   
/* 15:   */   public FreeLink(Object id)
/* 16:   */   {
/* 17:15 */     super(id);
/* 18:16 */     init();
/* 19:   */   }
/* 20:   */   
/* 21:   */   private void init()
/* 22:   */   {
/* 23:20 */     putBorderVisible(false);
/* 24:21 */     putLabelFont(FreeUtil.FONT_12_BOLD);
/* 25:22 */     putLabelColor(FreeUtil.DEFAULT_TEXT_COLOR);
/* 26:23 */     putLabelHighlightable(false);
/* 27:24 */     setDirection(this.direction);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setDirection(int direction)
/* 31:   */   {
/* 32:28 */     if (direction == 3) {
/* 33:29 */       setImage(FreeUtil.getImageURL("arrow_right.png"));
/* 34:   */     }
/* 35:31 */     if (direction == 7) {
/* 36:32 */       setImage(FreeUtil.getImageURL("arrow_left.png"));
/* 37:   */     }
/* 38:34 */     if (direction == 1) {
/* 39:35 */       setImage(FreeUtil.getImageURL("arrow_up.png"));
/* 40:   */     }
/* 41:37 */     if (direction == 5) {
/* 42:38 */       setImage(FreeUtil.getImageURL("arrow_down.png"));
/* 43:   */     }
/* 44:41 */     if (direction == 2) {
/* 45:42 */       setImage(FreeUtil.getImageURL("arrow_right_up.png"));
/* 46:   */     }
/* 47:44 */     if (direction == 4) {
/* 48:45 */       setImage(FreeUtil.getImageURL("arrow_right_down.png"));
/* 49:   */     }
/* 50:47 */     if (direction == 8) {
/* 51:48 */       setImage(FreeUtil.getImageURL("arrow_left_up.png"));
/* 52:   */     }
/* 53:50 */     if (direction == 6) {
/* 54:51 */       setImage(FreeUtil.getImageURL("arrow_left_down.png"));
/* 55:   */     }
/* 56:54 */     this.direction = direction;
/* 57:55 */     updateUI();
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeLink
 * JD-Core Version:    0.7.0.1
 */
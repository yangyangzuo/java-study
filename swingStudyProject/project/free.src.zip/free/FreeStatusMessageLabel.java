/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import javax.swing.ImageIcon;
/*  4:   */ 
/*  5:   */ public class FreeStatusMessageLabel
/*  6:   */   extends FreeStatusLabel
/*  7:   */ {
/*  8: 7 */   private static final ImageIcon ICON_ORANGE = FreeUtil.getImageIcon("statusbar_message_light_orange.png");
/*  9: 8 */   private static final ImageIcon ICON_RED = FreeUtil.getImageIcon("statusbar_message_light_red.png");
/* 10: 9 */   private static final ImageIcon ICON_GREEN = FreeUtil.getImageIcon("statusbar_message_light_green.png");
/* 11:   */   
/* 12:   */   protected void init()
/* 13:   */   {
/* 14:13 */     super.init();
/* 15:14 */     setFont(FreeUtil.FONT_14_BOLD);
/* 16:15 */     setGreenLight();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setRedLight()
/* 20:   */   {
/* 21:19 */     setIcon(ICON_RED);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setGreenLight()
/* 25:   */   {
/* 26:23 */     setIcon(ICON_GREEN);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setOrangeLight()
/* 30:   */   {
/* 31:27 */     setIcon(ICON_ORANGE);
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeStatusMessageLabel
 * JD-Core Version:    0.7.0.1
 */
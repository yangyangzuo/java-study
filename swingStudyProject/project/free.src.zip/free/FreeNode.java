/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.event.ActionListener;
/*   4:    */ import twaver.Node;
/*   5:    */ import twaver.TDataBox;
/*   6:    */ 
/*   7:    */ public class FreeNode
/*   8:    */   extends Node
/*   9:    */ {
/*  10:  9 */   private int labelYOffsetSingleLine = -30;
/*  11: 10 */   private int labelYOffsetMultiLine = -38;
/*  12: 11 */   private int labelXOffset = -12;
/*  13: 12 */   private String defaultImage = FreeUtil.getImageURL("module_node.png");
/*  14: 13 */   private String moduleIcon = null;
/*  15: 14 */   private String buttonIcon1 = null;
/*  16: 15 */   private String buttonIcon2 = null;
/*  17: 16 */   private String buttonIcon3 = null;
/*  18: 17 */   private String buttonTooltip1 = null;
/*  19: 18 */   private String buttonTooltip2 = null;
/*  20: 19 */   private String buttonTooltip3 = null;
/*  21: 20 */   private ActionListener action = null;
/*  22: 21 */   private ActionListener buttonAction1 = null;
/*  23: 22 */   private ActionListener buttonAction2 = null;
/*  24: 23 */   private ActionListener buttonAction3 = null;
/*  25: 24 */   private String actionCommand1 = null;
/*  26: 25 */   private String actionCommand2 = null;
/*  27: 26 */   private String actionCommand3 = null;
/*  28: 27 */   private FreeNodeButtonAttachment buttonAttachment = new FreeNodeButtonAttachment(this);
/*  29: 28 */   private String networkName = null;
/*  30: 29 */   private TDataBox shortcutData = null;
/*  31:    */   
/*  32:    */   public FreeNode()
/*  33:    */   {
/*  34: 32 */     init();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public FreeNode(Object id)
/*  38:    */   {
/*  39: 36 */     super(id);
/*  40: 37 */     init();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public FreeNodeButtonAttachment getButtonAttachment()
/*  44:    */   {
/*  45: 41 */     return this.buttonAttachment;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void init()
/*  49:    */   {
/*  50: 45 */     setImage(this.defaultImage);
/*  51: 46 */     putBorderVisible(false);
/*  52: 47 */     putLabelFont(FreeUtil.FONT_12_BOLD);
/*  53: 48 */     putLabelColor(FreeUtil.DEFAULT_TEXT_COLOR);
/*  54: 49 */     putLabelHighlightable(false);
/*  55: 50 */     putLabelYOffset(this.labelYOffsetSingleLine);
/*  56: 51 */     putLabelXOffset(this.labelXOffset);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getUIClassID()
/*  60:    */   {
/*  61: 56 */     return FreeNodeUI.class.getName();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getModuleIcon()
/*  65:    */   {
/*  66: 60 */     return this.moduleIcon;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setModuleIcon(String moduleIcon)
/*  70:    */   {
/*  71: 64 */     this.moduleIcon = moduleIcon;
/*  72: 65 */     updateUI();
/*  73: 66 */     updateComponentAttachment();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public String getButtonIcon1()
/*  77:    */   {
/*  78: 70 */     return this.buttonIcon1;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setButtonIcon1(String buttonIcon1)
/*  82:    */   {
/*  83: 74 */     this.buttonIcon1 = buttonIcon1;
/*  84: 75 */     updateUI();
/*  85: 76 */     updateComponentAttachment();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String getButtonIcon3()
/*  89:    */   {
/*  90: 80 */     return this.buttonIcon3;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setButtonIcon3(String buttonIcon3)
/*  94:    */   {
/*  95: 84 */     this.buttonIcon3 = buttonIcon3;
/*  96: 85 */     updateUI();
/*  97: 86 */     updateComponentAttachment();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String getButtonIcon2()
/* 101:    */   {
/* 102: 90 */     return this.buttonIcon2;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setButtonIcon2(String buttonIcon2)
/* 106:    */   {
/* 107: 94 */     this.buttonIcon2 = buttonIcon2;
/* 108: 95 */     updateUI();
/* 109: 96 */     updateComponentAttachment();
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void updateComponentAttachment()
/* 113:    */   {
/* 114:100 */     this.buttonAttachment.updateProperties();
/* 115:    */   }
/* 116:    */   
/* 117:    */   public String getButtonTooltip1()
/* 118:    */   {
/* 119:104 */     return this.buttonTooltip1;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setButtonTooltip1(String buttonTooltip1)
/* 123:    */   {
/* 124:108 */     this.buttonTooltip1 = buttonTooltip1;
/* 125:109 */     updateComponentAttachment();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getButtonTooltip2()
/* 129:    */   {
/* 130:113 */     return this.buttonTooltip2;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setButtonTooltip2(String buttonTooltip2)
/* 134:    */   {
/* 135:117 */     this.buttonTooltip2 = buttonTooltip2;
/* 136:118 */     updateComponentAttachment();
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getButtonTooltip3()
/* 140:    */   {
/* 141:122 */     return this.buttonTooltip3;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setButtonTooltip3(String buttonTooltip3)
/* 145:    */   {
/* 146:126 */     this.buttonTooltip3 = buttonTooltip3;
/* 147:127 */     updateComponentAttachment();
/* 148:    */   }
/* 149:    */   
/* 150:    */   public ActionListener getButtonAction1()
/* 151:    */   {
/* 152:131 */     return this.buttonAction1;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setButtonAction1(ActionListener buttonAction1)
/* 156:    */   {
/* 157:135 */     this.buttonAction1 = buttonAction1;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public ActionListener getButtonAction2()
/* 161:    */   {
/* 162:139 */     return this.buttonAction2;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void setButtonAction2(ActionListener buttonAction2)
/* 166:    */   {
/* 167:143 */     this.buttonAction2 = buttonAction2;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public ActionListener getButtonAction3()
/* 171:    */   {
/* 172:147 */     return this.buttonAction3;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void setButtonAction3(ActionListener buttonAction3)
/* 176:    */   {
/* 177:151 */     this.buttonAction3 = buttonAction3;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public String getNetworkName()
/* 181:    */   {
/* 182:155 */     return this.networkName;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setNetworkName(String networkName)
/* 186:    */   {
/* 187:159 */     this.networkName = networkName;
/* 188:160 */     if ((networkName != null) && (networkName.contains("<br>"))) {
/* 189:161 */       putLabelYOffset(this.labelYOffsetMultiLine);
/* 190:    */     } else {
/* 191:163 */       putLabelYOffset(this.labelYOffsetSingleLine);
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public String getActionCommand1()
/* 196:    */   {
/* 197:168 */     return this.actionCommand1;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setActionCommand1(String actionCommand1)
/* 201:    */   {
/* 202:172 */     this.actionCommand1 = actionCommand1;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public String getActionCommand2()
/* 206:    */   {
/* 207:176 */     return this.actionCommand2;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void setActionCommand2(String actionCommand2)
/* 211:    */   {
/* 212:180 */     this.actionCommand2 = actionCommand2;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public String getActionCommand3()
/* 216:    */   {
/* 217:184 */     return this.actionCommand3;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setActionCommand3(String actionCommand3)
/* 221:    */   {
/* 222:188 */     this.actionCommand3 = actionCommand3;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public ActionListener getAction()
/* 226:    */   {
/* 227:192 */     return this.action;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void setAction(ActionListener action)
/* 231:    */   {
/* 232:196 */     this.action = action;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public boolean isShortcutLoaded()
/* 236:    */   {
/* 237:200 */     return this.shortcutData == null;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public TDataBox getShortcuts()
/* 241:    */   {
/* 242:204 */     return this.shortcutData;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void setShortcuts(TDataBox shortcutData)
/* 246:    */   {
/* 247:208 */     this.shortcutData = shortcutData;
/* 248:    */   }
/* 249:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeNode
 * JD-Core Version:    0.7.0.1
 */
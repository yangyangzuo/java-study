/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import javax.swing.BorderFactory;
/*  6:   */ import javax.swing.JList;
/*  7:   */ import javax.swing.border.Border;
/*  8:   */ import twaver.list.TListCellRenderer;
/*  9:   */ 
/* 10:   */ public class FreeOutlookListRenderer
/* 11:   */   extends TListCellRenderer
/* 12:   */ {
/* 13:13 */   private Color selectedColor = FreeUtil.DEFAULT_SELECTION_COLOR;
/* 14:14 */   private Border normalBorder = BorderFactory.createEmptyBorder(3, 19, 3, 2);
/* 15:15 */   private Border shrinkedBorder = BorderFactory.createEmptyBorder(3, 2, 3, 2);
/* 16:   */   
/* 17:   */   public FreeOutlookListRenderer(FreeOutlookList list)
/* 18:   */   {
/* 19:18 */     super(list);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 23:   */   {
/* 24:25 */     super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 25:   */     
/* 26:27 */     setToolTipText(getText());
/* 27:28 */     FreeOutlookList outlookList = (FreeOutlookList)list;
/* 28:29 */     if (outlookList.getFreeOutlookBar().getFreeOutlookPane().isShrinked())
/* 29:   */     {
/* 30:30 */       setBorder(this.shrinkedBorder);
/* 31:31 */       setText(null);
/* 32:32 */       setHorizontalAlignment(0);
/* 33:33 */       setIconTextGap(0);
/* 34:   */     }
/* 35:   */     else
/* 36:   */     {
/* 37:35 */       setBorder(this.normalBorder);
/* 38:36 */       setHorizontalAlignment(10);
/* 39:37 */       setIconTextGap(5);
/* 40:   */     }
/* 41:40 */     if (isSelected) {
/* 42:41 */       setBackground(this.selectedColor);
/* 43:   */     }
/* 44:43 */     return this;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookListRenderer
 * JD-Core Version:    0.7.0.1
 */
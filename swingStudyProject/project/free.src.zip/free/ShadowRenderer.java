/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.image.BufferedImage;
/*   5:    */ import java.beans.PropertyChangeListener;
/*   6:    */ import java.beans.PropertyChangeSupport;
/*   7:    */ 
/*   8:    */ class ShadowRenderer
/*   9:    */ {
/*  10:    */   public static final String SIZE_CHANGED_PROPERTY = "shadow_size";
/*  11:    */   public static final String OPACITY_CHANGED_PROPERTY = "shadow_opacity";
/*  12:    */   public static final String COLOR_CHANGED_PROPERTY = "shadow_color";
/*  13:619 */   private int size = 5;
/*  14:621 */   private float opacity = 0.5F;
/*  15:623 */   private Color color = Color.BLACK;
/*  16:    */   private PropertyChangeSupport changeSupport;
/*  17:    */   
/*  18:    */   public ShadowRenderer()
/*  19:    */   {
/*  20:638 */     this(5, 0.5F, Color.BLACK);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public ShadowRenderer(int size, float opacity, Color color)
/*  24:    */   {
/*  25:657 */     this.changeSupport = new PropertyChangeSupport(this);
/*  26:    */     
/*  27:659 */     setSize(size);
/*  28:660 */     setOpacity(opacity);
/*  29:661 */     setColor(color);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*  33:    */   {
/*  34:673 */     this.changeSupport.addPropertyChangeListener(listener);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*  38:    */   {
/*  39:686 */     this.changeSupport.removePropertyChangeListener(listener);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Color getColor()
/*  43:    */   {
/*  44:694 */     return this.color;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setColor(Color shadowColor)
/*  48:    */   {
/*  49:705 */     if (shadowColor != null)
/*  50:    */     {
/*  51:706 */       Color oldColor = this.color;
/*  52:707 */       this.color = shadowColor;
/*  53:708 */       this.changeSupport.firePropertyChange("shadow_color", oldColor, this.color);
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public float getOpacity()
/*  58:    */   {
/*  59:721 */     return this.opacity;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setOpacity(float shadowOpacity)
/*  63:    */   {
/*  64:734 */     float oldOpacity = this.opacity;
/*  65:736 */     if (shadowOpacity < 0.0D) {
/*  66:737 */       this.opacity = 0.0F;
/*  67:738 */     } else if (shadowOpacity > 1.0F) {
/*  68:739 */       this.opacity = 1.0F;
/*  69:    */     } else {
/*  70:741 */       this.opacity = shadowOpacity;
/*  71:    */     }
/*  72:744 */     this.changeSupport.firePropertyChange("shadow_opacity", Float.valueOf(oldOpacity), Float.valueOf(this.opacity));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int getSize()
/*  76:    */   {
/*  77:754 */     return this.size;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setSize(int shadowSize)
/*  81:    */   {
/*  82:766 */     int oldSize = this.size;
/*  83:768 */     if (shadowSize < 0) {
/*  84:769 */       this.size = 0;
/*  85:    */     } else {
/*  86:771 */       this.size = shadowSize;
/*  87:    */     }
/*  88:774 */     this.changeSupport.firePropertyChange("shadow_size", new Integer(oldSize), new Integer(this.size));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public BufferedImage createShadow(BufferedImage image)
/*  92:    */   {
/*  93:792 */     int shadowSize = this.size * 2;
/*  94:    */     
/*  95:794 */     int srcWidth = image.getWidth();
/*  96:795 */     int srcHeight = image.getHeight();
/*  97:    */     
/*  98:797 */     int dstWidth = srcWidth + shadowSize;
/*  99:798 */     int dstHeight = srcHeight + shadowSize;
/* 100:    */     
/* 101:800 */     int left = this.size;
/* 102:801 */     int right = shadowSize - left;
/* 103:    */     
/* 104:803 */     int yStop = dstHeight - right;
/* 105:    */     
/* 106:805 */     int shadowRgb = this.color.getRGB() & 0xFFFFFF;
/* 107:806 */     int[] aHistory = new int[shadowSize];
/* 108:    */     
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:811 */     BufferedImage dst = new BufferedImage(dstWidth, dstHeight, 2);
/* 113:    */     
/* 114:    */ 
/* 115:814 */     int[] dstBuffer = new int[dstWidth * dstHeight];
/* 116:815 */     int[] srcBuffer = new int[srcWidth * srcHeight];
/* 117:    */     
/* 118:817 */     GraphicsUtilities.getPixels(image, 0, 0, srcWidth, srcHeight, srcBuffer);
/* 119:    */     
/* 120:819 */     int lastPixelOffset = right * dstWidth;
/* 121:820 */     float hSumDivider = 1.0F / shadowSize;
/* 122:821 */     float vSumDivider = this.opacity / shadowSize;
/* 123:    */     
/* 124:823 */     int[] hSumLookup = new int[256 * shadowSize];
/* 125:824 */     for (int i = 0; i < hSumLookup.length; i++) {
/* 126:825 */       hSumLookup[i] = ((int)(i * hSumDivider));
/* 127:    */     }
/* 128:828 */     int[] vSumLookup = new int[256 * shadowSize];
/* 129:829 */     for (int i = 0; i < vSumLookup.length; i++) {
/* 130:830 */       vSumLookup[i] = ((int)(i * vSumDivider));
/* 131:    */     }
/* 132:837 */     int srcY = 0;
/* 133:837 */     for (int dstOffset = left * dstWidth; srcY < srcHeight; srcY++)
/* 134:    */     {
/* 135:840 */       for (int historyIdx = 0; historyIdx < shadowSize;) {
/* 136:841 */         aHistory[(historyIdx++)] = 0;
/* 137:    */       }
/* 138:844 */       int aSum = 0;
/* 139:845 */       historyIdx = 0;
/* 140:846 */       int srcOffset = srcY * srcWidth;
/* 141:849 */       for (int srcX = 0; srcX < srcWidth; srcX++)
/* 142:    */       {
/* 143:851 */         int a = hSumLookup[aSum];
/* 144:852 */         dstBuffer[(dstOffset++)] = (a << 24);
/* 145:    */         
/* 146:    */ 
/* 147:855 */         aSum -= aHistory[historyIdx];
/* 148:    */         
/* 149:    */ 
/* 150:858 */         a = srcBuffer[(srcOffset + srcX)] >>> 24;
/* 151:859 */         aHistory[historyIdx] = a;
/* 152:860 */         aSum += a;
/* 153:    */         
/* 154:862 */         historyIdx++;
/* 155:862 */         if (historyIdx >= shadowSize) {
/* 156:863 */           historyIdx -= shadowSize;
/* 157:    */         }
/* 158:    */       }
/* 159:868 */       for (int i = 0; i < shadowSize; i++)
/* 160:    */       {
/* 161:870 */         int a = hSumLookup[aSum];
/* 162:871 */         dstBuffer[(dstOffset++)] = (a << 24);
/* 163:    */         
/* 164:    */ 
/* 165:874 */         aSum -= aHistory[historyIdx];
/* 166:    */         
/* 167:876 */         historyIdx++;
/* 168:876 */         if (historyIdx >= shadowSize) {
/* 169:877 */           historyIdx -= shadowSize;
/* 170:    */         }
/* 171:    */       }
/* 172:    */     }
/* 173:883 */     int x = 0;
/* 174:883 */     for (int bufferOffset = 0; x < dstWidth; bufferOffset = x)
/* 175:    */     {
/* 176:885 */       int aSum = 0;
/* 177:888 */       for (int historyIdx = 0; historyIdx < left;) {
/* 178:889 */         aHistory[(historyIdx++)] = 0;
/* 179:    */       }
/* 180:893 */       for (int y = 0; y < right; bufferOffset += dstWidth)
/* 181:    */       {
/* 182:894 */         int a = dstBuffer[bufferOffset] >>> 24;
/* 183:895 */         aHistory[(historyIdx++)] = a;
/* 184:896 */         aSum += a;y++;
/* 185:    */       }
/* 186:899 */       bufferOffset = x;
/* 187:900 */       historyIdx = 0;
/* 188:903 */       for (int y = 0; y < yStop; bufferOffset += dstWidth)
/* 189:    */       {
/* 190:905 */         int a = vSumLookup[aSum];
/* 191:906 */         dstBuffer[bufferOffset] = (a << 24 | shadowRgb);
/* 192:    */         
/* 193:908 */         aSum -= aHistory[historyIdx];
/* 194:    */         
/* 195:910 */         a = dstBuffer[(bufferOffset + lastPixelOffset)] >>> 24;
/* 196:911 */         aHistory[historyIdx] = a;
/* 197:912 */         aSum += a;
/* 198:    */         
/* 199:914 */         historyIdx++;
/* 200:914 */         if (historyIdx >= shadowSize) {
/* 201:915 */           historyIdx -= shadowSize;
/* 202:    */         }
/* 203:903 */         y++;
/* 204:    */       }
/* 205:920 */       for (int y = yStop; y < dstHeight; bufferOffset += dstWidth)
/* 206:    */       {
/* 207:922 */         int a = vSumLookup[aSum];
/* 208:923 */         dstBuffer[bufferOffset] = (a << 24 | shadowRgb);
/* 209:    */         
/* 210:925 */         aSum -= aHistory[historyIdx];
/* 211:    */         
/* 212:927 */         historyIdx++;
/* 213:927 */         if (historyIdx >= shadowSize) {
/* 214:928 */           historyIdx -= shadowSize;
/* 215:    */         }
/* 216:920 */         y++;
/* 217:    */       }
/* 218:883 */       x++;
/* 219:    */     }
/* 220:933 */     GraphicsUtilities.setPixels(dst, 0, 0, dstWidth, dstHeight, dstBuffer);
/* 221:934 */     return dst;
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.ShadowRenderer
 * JD-Core Version:    0.7.0.1
 */
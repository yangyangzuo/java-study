/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Graphics2D;
/*  6:   */ import java.awt.Image;
/*  7:   */ import java.awt.TexturePaint;
/*  8:   */ import javax.swing.BorderFactory;
/*  9:   */ import javax.swing.ImageIcon;
/* 10:   */ import javax.swing.JMenuBar;
/* 11:   */ import javax.swing.border.Border;
/* 12:   */ import twaver.TWaverUtil;
/* 13:   */ 
/* 14:   */ public class FreeMenuBar
/* 15:   */   extends JMenuBar
/* 16:   */ {
/* 17:16 */   private String backgroundImageURL = FreeUtil.getImageURL("menubar_background.png");
/* 18:17 */   private Image backgroundLeftImage = FreeUtil.getImage("menubar_background_left.png");
/* 19:18 */   private Image backgroundRightImage = FreeUtil.getImage("menubar_background_right.png");
/* 20:19 */   private ImageIcon backgroundImageIcon = TWaverUtil.getImageIcon(this.backgroundImageURL);
/* 21:20 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 22:21 */   private Border border = BorderFactory.createEmptyBorder();
/* 23:   */   
/* 24:   */   public FreeMenuBar()
/* 25:   */   {
/* 26:24 */     init();
/* 27:   */   }
/* 28:   */   
/* 29:   */   private void init()
/* 30:   */   {
/* 31:28 */     setBorder(this.border);
/* 32:   */   }
/* 33:   */   
/* 34:   */   protected void paintComponent(Graphics g)
/* 35:   */   {
/* 36:33 */     super.paintComponent(g);
/* 37:   */     
/* 38:35 */     Graphics2D g2d = (Graphics2D)g;
/* 39:36 */     g2d.setPaint(this.paint);
/* 40:37 */     g2d.fillRect(0, 0, getWidth(), getHeight());
/* 41:   */     
/* 42:   */ 
/* 43:40 */     g2d.drawImage(this.backgroundLeftImage, 0, 0, null);
/* 44:   */     
/* 45:   */ 
/* 46:43 */     g2d.drawImage(this.backgroundRightImage, getWidth() - this.backgroundRightImage.getWidth(null), 0, null);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Dimension getPreferredSize()
/* 50:   */   {
/* 51:48 */     return new Dimension(super.getPreferredSize().width, this.backgroundImageIcon.getIconHeight());
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeMenuBar
 * JD-Core Version:    0.7.0.1
 */
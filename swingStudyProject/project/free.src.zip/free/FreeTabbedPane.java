/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import javax.swing.ImageIcon;
/*  5:   */ import javax.swing.JTabbedPane;
/*  6:   */ import javax.swing.event.ChangeEvent;
/*  7:   */ import javax.swing.event.ChangeListener;
/*  8:   */ 
/*  9:   */ public class FreeTabbedPane
/* 10:   */   extends JTabbedPane
/* 11:   */ {
/* 12:11 */   private int preferredUnselectedTabWidth = 80;
/* 13:12 */   private int preferredTabHeight = FreeUtil.getImageIcon("tab_header_background.png").getIconHeight();
/* 14:   */   
/* 15:   */   public FreeTabbedPane()
/* 16:   */   {
/* 17:15 */     init();
/* 18:   */   }
/* 19:   */   
/* 20:   */   private void init()
/* 21:   */   {
/* 22:19 */     setFont(FreeUtil.FONT_12_BOLD);
/* 23:20 */     setForeground(FreeUtil.DEFAULT_TEXT_COLOR);
/* 24:21 */     setBorder(null);
/* 25:22 */     setFocusable(false);
/* 26:23 */     setTabLayoutPolicy(1);
/* 27:24 */     setOpaque(false);
/* 28:25 */     setUI(new FreeTabbedPaneUI(this));
/* 29:26 */     addChangeListener(new ChangeListener()
/* 30:   */     {
/* 31:   */       public void stateChanged(ChangeEvent e)
/* 32:   */       {
/* 33:30 */         FreeTabbedPane.this.updateTabComponents();
/* 34:   */       }
/* 35:   */     });
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void addTab(String title, Component component)
/* 39:   */   {
/* 40:37 */     super.addTab(title, component);
/* 41:38 */     int index = getTabCount() - 1;
/* 42:39 */     FreeTabComponent tabComponent = new FreeTabComponent(this);
/* 43:40 */     tabComponent.setTitle(title);
/* 44:41 */     setTabComponentAt(index, tabComponent);
/* 45:42 */     setToolTipTextAt(index, title);
/* 46:43 */     updateTabComponents();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public int getPreferredTabHeight()
/* 50:   */   {
/* 51:47 */     return this.preferredTabHeight;
/* 52:   */   }
/* 53:   */   
/* 54:   */   private void updateTabComponents()
/* 55:   */   {
/* 56:51 */     int selectedIndex = getSelectedIndex();
/* 57:52 */     for (int i = 0; i < getTabCount(); i++)
/* 58:   */     {
/* 59:53 */       Component c = getTabComponentAt(i);
/* 60:54 */       if ((c instanceof FreeTabComponent))
/* 61:   */       {
/* 62:55 */         FreeTabComponent component = (FreeTabComponent)c;
/* 63:56 */         boolean selected = selectedIndex == i;
/* 64:57 */         component.updateSelection(selected);
/* 65:   */       }
/* 66:   */     }
/* 67:   */   }
/* 68:   */   
/* 69:   */   public int getPreferredUnselectedTabWidth()
/* 70:   */   {
/* 71:63 */     return this.preferredUnselectedTabWidth;
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTabbedPane
 * JD-Core Version:    0.7.0.1
 */
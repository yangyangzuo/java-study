/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import javax.swing.BorderFactory;
/*  6:   */ import javax.swing.JLabel;
/*  7:   */ import javax.swing.JPanel;
/*  8:   */ import javax.swing.JScrollPane;
/*  9:   */ import javax.swing.JTable;
/* 10:   */ import javax.swing.JTextField;
/* 11:   */ import javax.swing.border.Border;
/* 12:   */ 
/* 13:   */ public class FreeReportPage
/* 14:   */   extends FreePagePane
/* 15:   */ {
/* 16:16 */   private FreeTable table = new FreeTable();
/* 17:17 */   private JScrollPane scroll = new JScrollPane(this.table);
/* 18:18 */   private int descriptionHeight = 25;
/* 19:19 */   private JTextField lbDescription = new JTextField()
/* 20:   */   {
/* 21:   */     public Dimension getPreferredSize()
/* 22:   */     {
/* 23:23 */       Dimension size = super.getPreferredSize();
/* 24:24 */       return new Dimension(size.width, FreeReportPage.this.descriptionHeight);
/* 25:   */     }
/* 26:   */   };
/* 27:27 */   private Border descriptionBorder = BorderFactory.createEmptyBorder(0, 5, 0, 0);
/* 28:28 */   private Color descriptionTextColor = new Color(120, 123, 154);
/* 29:29 */   private Color descriptionBackgroundColor = new Color(226, 228, 229);
/* 30:   */   
/* 31:   */   public FreeReportPage()
/* 32:   */   {
/* 33:32 */     init();
/* 34:   */   }
/* 35:   */   
/* 36:   */   private void init()
/* 37:   */   {
/* 38:36 */     this.scroll.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 39:37 */     getCenterPane().add(this.scroll, "Center");
/* 40:38 */     getCenterPane().add(this.lbDescription, "North");
/* 41:   */     
/* 42:40 */     JLabel lbCorner = new JLabel();
/* 43:41 */     lbCorner.setOpaque(true);
/* 44:42 */     lbCorner.setBackground(this.descriptionBackgroundColor);
/* 45:43 */     this.scroll.setCorner("UPPER_RIGHT_CORNER", lbCorner);
/* 46:   */     
/* 47:45 */     this.lbDescription.setForeground(this.descriptionTextColor);
/* 48:46 */     this.lbDescription.setBackground(this.descriptionBackgroundColor);
/* 49:47 */     this.lbDescription.setOpaque(true);
/* 50:48 */     this.lbDescription.setBorder(this.descriptionBorder);
/* 51:49 */     this.lbDescription.setEditable(false);
/* 52:50 */     this.lbDescription.setFont(FreeUtil.FONT_12_BOLD);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void setDescription(String description)
/* 56:   */   {
/* 57:54 */     this.lbDescription.setText(description);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public JTable getTable()
/* 61:   */   {
/* 62:58 */     return this.table;
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeReportPage
 * JD-Core Version:    0.7.0.1
 */
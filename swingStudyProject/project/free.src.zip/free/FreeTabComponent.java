/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import java.awt.Graphics2D;
/*   8:    */ import java.awt.Image;
/*   9:    */ import java.awt.TexturePaint;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.ActionListener;
/*  12:    */ import javax.swing.BorderFactory;
/*  13:    */ import javax.swing.ImageIcon;
/*  14:    */ import javax.swing.JButton;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.border.Border;
/*  18:    */ 
/*  19:    */ public class FreeTabComponent
/*  20:    */   extends JPanel
/*  21:    */ {
/*  22: 22 */   private String backgroundSelectedImageURL = FreeUtil.getImageURL("tab_header_background.png");
/*  23: 23 */   private String backgroundUnselectedImageURL = FreeUtil.getImageURL("tab_header_unselected_background.png");
/*  24: 24 */   private TexturePaint selectedPaint = FreeUtil.createTexturePaint(this.backgroundSelectedImageURL);
/*  25: 25 */   private TexturePaint unselectedPaint = FreeUtil.createTexturePaint(this.backgroundUnselectedImageURL);
/*  26: 26 */   private ImageIcon icon = FreeUtil.getImageIcon("tab_close.png");
/*  27: 27 */   private ImageIcon pressedIcon = FreeUtil.getImageIcon("tab_close_pressed.png");
/*  28: 28 */   private Image unselectedLeftImage = FreeUtil.getImage("tab_header_unselected_background_left.png");
/*  29: 29 */   private Image unselectedRightImage = FreeUtil.getImage("tab_header_unselected_background_right.png");
/*  30: 30 */   private Image selectedLeftImage = FreeUtil.getImage("tab_header_selected_background_left.png");
/*  31: 31 */   private Image selectedRightImage = FreeUtil.getImage("tab_header_selected_background_right.png");
/*  32: 32 */   private JButton btnClose = new JButton();
/*  33: 33 */   private JLabel lbTitle = new JLabel();
/*  34: 34 */   private FreeTabbedPane tab = null;
/*  35: 35 */   private Color selectedTitleColor = new Color(120, 120, 125);
/*  36: 36 */   private Color unselectedTitleColor = Color.white;
/*  37: 37 */   private Border border = BorderFactory.createEmptyBorder(0, 5, 0, 5);
/*  38:    */   
/*  39:    */   public FreeTabComponent(FreeTabbedPane tab)
/*  40:    */   {
/*  41: 40 */     this.tab = tab;
/*  42: 41 */     init();
/*  43:    */   }
/*  44:    */   
/*  45:    */   private void init()
/*  46:    */   {
/*  47: 45 */     this.btnClose.setIcon(this.icon);
/*  48: 46 */     this.btnClose.setPressedIcon(this.pressedIcon);
/*  49: 47 */     this.btnClose.setToolTipText("Close this tab");
/*  50: 48 */     this.btnClose.setMargin(FreeUtil.ZERO_INSETS);
/*  51: 49 */     this.btnClose.setFocusPainted(false);
/*  52: 50 */     this.btnClose.setBorder(BorderFactory.createEmptyBorder(0, 3, 1, 3));
/*  53: 51 */     this.btnClose.setContentAreaFilled(false);
/*  54: 52 */     this.btnClose.addActionListener(new ActionListener()
/*  55:    */     {
/*  56:    */       public void actionPerformed(ActionEvent e)
/*  57:    */       {
/*  58: 55 */         FreeTabComponent.this.closeTab();
/*  59:    */       }
/*  60: 58 */     });
/*  61: 59 */     this.lbTitle.setOpaque(false);
/*  62: 60 */     this.lbTitle.setBorder(BorderFactory.createEmptyBorder(0, 3, 0, 3));
/*  63: 61 */     this.lbTitle.setVerticalAlignment(0);
/*  64: 62 */     this.lbTitle.setFont(FreeUtil.FONT_12_BOLD);
/*  65:    */     
/*  66: 64 */     setLayout(new BorderLayout());
/*  67: 65 */     add(this.btnClose, "East");
/*  68: 66 */     add(this.lbTitle, "Center");
/*  69: 67 */     setBorder(this.border);
/*  70: 68 */     setOpaque(false);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void paintComponent(Graphics g)
/*  74:    */   {
/*  75: 73 */     Graphics2D g2d = (Graphics2D)g;
/*  76: 75 */     if (isTabSelected())
/*  77:    */     {
/*  78: 76 */       g2d.drawImage(this.selectedLeftImage, 0, 0, null);
/*  79: 77 */       g2d.setPaint(this.selectedPaint);
/*  80: 78 */       int x = this.selectedLeftImage.getWidth(null);
/*  81: 79 */       int y = 0;
/*  82: 80 */       int width = getWidth() - x - this.selectedRightImage.getWidth(null);
/*  83: 81 */       int height = getHeight();
/*  84: 82 */       g2d.fillRect(x, y, width, height);
/*  85: 83 */       g2d.drawImage(this.selectedRightImage, x + width, 0, null);
/*  86:    */     }
/*  87:    */     else
/*  88:    */     {
/*  89: 85 */       g2d.drawImage(this.unselectedLeftImage, 0, 0, null);
/*  90: 86 */       g2d.setPaint(this.unselectedPaint);
/*  91: 87 */       int x = this.unselectedLeftImage.getWidth(null);
/*  92: 88 */       int y = 0;
/*  93: 89 */       int width = getWidth() - x - this.selectedRightImage.getWidth(null);
/*  94: 90 */       int height = getHeight();
/*  95: 91 */       g2d.fillRect(x, y, width, height);
/*  96: 92 */       g2d.drawImage(this.unselectedRightImage, x + width, 0, null);
/*  97:    */       
/*  98:    */ 
/*  99: 95 */       g2d.setColor(FreeUtil.TAB_BOTTOM_LINE_COLOR);
/* 100: 96 */       int lineY = getHeight() - 1;
/* 101: 97 */       g2d.drawLine(0, lineY, getWidth(), lineY);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Dimension getPreferredSize()
/* 106:    */   {
/* 107:103 */     int width = super.getPreferredSize().width;
/* 108:104 */     if (!isTabSelected()) {
/* 109:105 */       width = Math.min(width, this.tab.getPreferredUnselectedTabWidth());
/* 110:    */     }
/* 111:107 */     int height = this.tab.getPreferredTabHeight();
/* 112:108 */     return new Dimension(width, height);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean isTabSelected()
/* 116:    */   {
/* 117:112 */     int index = this.tab.indexOfTabComponent(this);
/* 118:113 */     int selectedIndex = this.tab.getSelectedIndex();
/* 119:114 */     return selectedIndex == index;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setTitle(String title)
/* 123:    */   {
/* 124:118 */     this.lbTitle.setText(title);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void updateSelection(boolean selected)
/* 128:    */   {
/* 129:122 */     if (selected) {
/* 130:123 */       this.lbTitle.setForeground(this.selectedTitleColor);
/* 131:    */     } else {
/* 132:125 */       this.lbTitle.setForeground(this.unselectedTitleColor);
/* 133:    */     }
/* 134:127 */     this.btnClose.setVisible(selected);
/* 135:    */   }
/* 136:    */   
/* 137:    */   private void closeTab()
/* 138:    */   {
/* 139:131 */     int index = this.tab.indexOfTabComponent(this);
/* 140:132 */     this.tab.removeTabAt(index);
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTabComponent
 * JD-Core Version:    0.7.0.1
 */
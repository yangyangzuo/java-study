/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Font;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.awt.event.ItemEvent;
/*   9:    */ import java.awt.event.ItemListener;
/*  10:    */ import javax.swing.JCheckBox;
/*  11:    */ import javax.swing.JComboBox;
/*  12:    */ import javax.swing.JToolBar;
/*  13:    */ import twaver.Element;
/*  14:    */ import twaver.Node;
/*  15:    */ import twaver.TDataBox;
/*  16:    */ import twaver.TUIManager;
/*  17:    */ import twaver.chart.LineChart;
/*  18:    */ 
/*  19:    */ public class MobileChart
/*  20:    */   extends Portlet
/*  21:    */ {
/*  22: 23 */   private Element developedElement = new Node();
/*  23: 24 */   private Element developingElement = new Node();
/*  24: 25 */   private Element worldElement = new Node();
/*  25: 26 */   private TDataBox box = new TDataBox();
/*  26: 27 */   private LineChart chart = new LineChart(this.box);
/*  27:    */   
/*  28:    */   public MobileChart()
/*  29:    */   {
/*  30: 30 */     super.initialize(this.chart);
/*  31: 31 */     this.chart.setTitle("<html>Mobile Cellular Telephone Subscribers<br><center>Per 100 Inhabitants,1994~2006</center></html>");
/*  32: 32 */     this.chart.setLowerLimit(0.0D);
/*  33: 33 */     this.chart.setUpperLimit(100.0D);
/*  34: 34 */     this.chart.setYScaleValueGap(20.0D);
/*  35: 35 */     this.chart.setYScaleTextVisible(true);
/*  36: 36 */     this.chart.setXScaleLineVisible(true);
/*  37: 37 */     this.chart.setXScaleTextOrientation(3);
/*  38: 38 */     this.chart.setXGap(15);
/*  39: 39 */     this.chart.setYGap(15);
/*  40: 40 */     this.chart.setValueTextVisible(true);
/*  41: 41 */     this.chart.setValueTextFont(TUIManager.getDefaultFont().deriveFont(9.0F));
/*  42: 42 */     this.chart.setInflexionVisible(true);
/*  43:    */     
/*  44: 44 */     addElement(this.developedElement, "Developed", Color.BLUE, 4);
/*  45: 45 */     addElement(this.worldElement, "World", Color.RED, 3);
/*  46: 46 */     addElement(this.developingElement, "Developing", Color.GREEN, 2);
/*  47:    */     
/*  48: 48 */     addValue("1994", 5.2D, 1.0D, 0.19D);
/*  49: 49 */     addValue("1995", 8.199999999999999D, 1.6D, 0.4D);
/*  50: 50 */     addValue("1996", 12.699999999999999D, 2.5D, 0.6D);
/*  51: 51 */     addValue("1997", 17.600000000000001D, 3.7D, 1.1D);
/*  52: 52 */     addValue("1998", 24.600000000000001D, 5.4D, 1.9D);
/*  53: 53 */     addValue("1999", 35.299999999999997D, 8.199999999999999D, 3.2D);
/*  54: 54 */     addValue("2000", 49.600000000000001D, 12.199999999999999D, 5.4D);
/*  55: 55 */     addValue("2001", 58.5D, 15.699999999999999D, 8.0D);
/*  56: 56 */     addValue("2002", 64.700000000000003D, 18.800000000000001D, 10.800000000000001D);
/*  57: 57 */     addValue("2003", 69.599999999999994D, 22.600000000000001D, 14.199999999999999D);
/*  58: 58 */     addValue("2004", 76.799999999999997D, 27.699999999999999D, 19.100000000000001D);
/*  59: 59 */     addValue("2005", 85.200000000000003D, 34.399999999999999D, 25.600000000000001D);
/*  60: 60 */     addValue("2006", 90.900000000000006D, 41.0D, 32.399999999999999D);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private void addElement(Element element, String name, Color color, int style)
/*  64:    */   {
/*  65: 65 */     element.setName(name);
/*  66: 66 */     element.putChartColor(color);
/*  67: 67 */     element.putChartInflexionStyle(style);
/*  68: 68 */     this.box.addElement(element);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public JToolBar getControlPanel()
/*  72:    */   {
/*  73: 72 */     JToolBar toolbar = super.getControlPanel();
/*  74: 73 */     final JCheckBox showText = new JCheckBox("Text");
/*  75: 74 */     showText.setPreferredSize(new Dimension(showText.getPreferredSize().width + 5, 20));
/*  76: 75 */     showText.setSelected(true);
/*  77: 76 */     showText.addActionListener(new ActionListener()
/*  78:    */     {
/*  79:    */       public void actionPerformed(ActionEvent e)
/*  80:    */       {
/*  81: 79 */         MobileChart.this.chart.setValueTextVisible(showText.isSelected());
/*  82:    */       }
/*  83: 82 */     });
/*  84: 83 */     final JCheckBox inflexion = new JCheckBox("Inflexion");
/*  85: 84 */     inflexion.setPreferredSize(new Dimension(inflexion.getPreferredSize().width + 5, 20));
/*  86: 85 */     inflexion.setSelected(true);
/*  87: 86 */     inflexion.addActionListener(new ActionListener()
/*  88:    */     {
/*  89:    */       public void actionPerformed(ActionEvent e)
/*  90:    */       {
/*  91: 89 */         MobileChart.this.chart.setInflexionVisible(inflexion.isSelected());
/*  92:    */       }
/*  93: 92 */     });
/*  94: 93 */     final JComboBox lineType = new JComboBox();
/*  95: 94 */     lineType.addItem("Default");
/*  96: 95 */     lineType.addItem("Area");
/*  97: 96 */     lineType.addItem("Pole");
/*  98: 97 */     lineType.setPreferredSize(new Dimension(lineType.getPreferredSize().width, 20));
/*  99: 98 */     lineType.addItemListener(new ItemListener()
/* 100:    */     {
/* 101:    */       public void itemStateChanged(ItemEvent e)
/* 102:    */       {
/* 103:101 */         int index = lineType.getSelectedIndex();
/* 104:102 */         switch (index)
/* 105:    */         {
/* 106:    */         case 0: 
/* 107:104 */           MobileChart.this.chart.setLineType(1);
/* 108:105 */           break;
/* 109:    */         case 1: 
/* 110:107 */           MobileChart.this.chart.setLineType(2);
/* 111:108 */           break;
/* 112:    */         case 2: 
/* 113:110 */           MobileChart.this.chart.setLineType(3);
/* 114:    */         }
/* 115:    */       }
/* 116:114 */     });
/* 117:115 */     lineType.setSelectedIndex(0);
/* 118:    */     
/* 119:117 */     toolbar.add(showText);
/* 120:118 */     toolbar.add(inflexion);
/* 121:119 */     toolbar.add(lineType);
/* 122:120 */     return toolbar;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private void addValue(String year, double developed, double world, double developing)
/* 126:    */   {
/* 127:124 */     this.chart.addXScaleText(year);
/* 128:125 */     this.developedElement.addChartValue(developed);
/* 129:126 */     this.worldElement.addChartValue(world);
/* 130:127 */     this.developingElement.addChartValue(developing);
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.MobileChart
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Point;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.List;
/*   7:    */ import twaver.ResizableNode;
/*   8:    */ import twaver.TWaverUtil;
/*   9:    */ 
/*  10:    */ public class StateNode
/*  11:    */   extends ResizableNode
/*  12:    */ {
/*  13:    */   private double c2000;
/*  14:    */   private double p2005;
/*  15:    */   private double p2010;
/*  16:    */   private double p2015;
/*  17:    */   private double p2020;
/*  18:    */   private double p2025;
/*  19:    */   private double p2030;
/*  20: 30 */   private List valueList = new ArrayList();
/*  21: 32 */   private int attachmentDirection = 2;
/*  22:    */   
/*  23:    */   public void init(double c2000, double p2005, double p2010, double p2015, double p2020, double p2025, double p2030)
/*  24:    */   {
/*  25: 38 */     this.c2000 = c2000;
/*  26: 39 */     this.p2005 = p2005;
/*  27: 40 */     this.p2010 = p2010;
/*  28: 41 */     this.p2015 = p2015;
/*  29: 42 */     this.p2020 = p2020;
/*  30: 43 */     this.p2025 = p2025;
/*  31: 44 */     this.p2030 = p2030;
/*  32:    */     
/*  33: 46 */     double sum = c2000 + p2005 + p2010 + p2015 + p2020 + p2025 + p2030;
/*  34:    */     
/*  35: 48 */     this.valueList.add(new Double(c2000 / sum));
/*  36: 49 */     this.valueList.add(new Double(p2005 / sum));
/*  37: 50 */     this.valueList.add(new Double(p2010 / sum));
/*  38: 51 */     this.valueList.add(new Double(p2015 / sum));
/*  39: 52 */     this.valueList.add(new Double(p2020 / sum));
/*  40: 53 */     this.valueList.add(new Double(p2025 / sum));
/*  41: 54 */     this.valueList.add(new Double(p2030 / sum));
/*  42:    */     
/*  43: 56 */     putCustomDrawFillColor(Color.ORANGE);
/*  44: 57 */     putBorderColor(Color.YELLOW);
/*  45: 58 */     putBorderStroke("solid.middle");
/*  46: 59 */     putCustomDrawOutline(false);
/*  47: 60 */     putLabelFont(TWaverUtil.getFont(1, 10.0F));
/*  48: 61 */     putLabelColor(Color.WHITE);
/*  49: 62 */     putLabelHighlightForeground(Color.GREEN);
/*  50:    */     
/*  51: 64 */     int size = (int)(8.0D + Math.sqrt(c2000 / 300000000.0D) * 150.0D);
/*  52: 65 */     Point point = getCenterLocation();
/*  53: 66 */     setSize(size, size);
/*  54: 67 */     setCenterLocation(point.x, point.y);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public double getC2000()
/*  58:    */   {
/*  59: 71 */     return this.c2000;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public double getP2005()
/*  63:    */   {
/*  64: 75 */     return this.p2005;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public double getP2010()
/*  68:    */   {
/*  69: 79 */     return this.p2010;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public double getP2015()
/*  73:    */   {
/*  74: 83 */     return this.p2015;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public double getP2020()
/*  78:    */   {
/*  79: 87 */     return this.p2020;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public double getP2025()
/*  83:    */   {
/*  84: 91 */     return this.p2025;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public double getP2030()
/*  88:    */   {
/*  89: 95 */     return this.p2030;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public int getAttachmentDirection()
/*  93:    */   {
/*  94: 99 */     return this.attachmentDirection;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setAttachmentDirection(int attachmentDirection)
/*  98:    */   {
/*  99:103 */     if (this.attachmentDirection != attachmentDirection)
/* 100:    */     {
/* 101:104 */       int oldValue = this.attachmentDirection;
/* 102:105 */       this.attachmentDirection = attachmentDirection;
/* 103:106 */       firePropertyChange("attachmentDirection", oldValue, attachmentDirection);
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public List getValueList()
/* 108:    */   {
/* 109:111 */     return this.valueList;
/* 110:    */   }
/* 111:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.StateNode
 * JD-Core Version:    0.7.0.1
 */
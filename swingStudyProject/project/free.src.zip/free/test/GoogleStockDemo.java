/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.GridLayout;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.io.BufferedReader;
/*   9:    */ import java.io.InputStream;
/*  10:    */ import java.io.InputStreamReader;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.swing.JCheckBox;
/*  14:    */ import javax.swing.JPanel;
/*  15:    */ import twaver.Element;
/*  16:    */ import twaver.Node;
/*  17:    */ import twaver.TDataBox;
/*  18:    */ import twaver.TWaverUtil;
/*  19:    */ 
/*  20:    */ public class GoogleStockDemo
/*  21:    */   extends JPanel
/*  22:    */ {
/*  23:    */   public GoogleStockDemo()
/*  24:    */   {
/*  25: 25 */     List dates = new ArrayList();
/*  26:    */     
/*  27: 27 */     Element open = new Node();
/*  28: 28 */     Element high = new Node();
/*  29: 29 */     Element low = new Node();
/*  30: 30 */     Element history = new Node();
/*  31: 31 */     Element volume = new Node();
/*  32: 32 */     Element close = new Node();
/*  33:    */     try
/*  34:    */     {
/*  35: 35 */       InputStream in = TWaverUtil.getInputStream("/free/test/google.txt");
/*  36: 36 */       BufferedReader reader = new BufferedReader(new InputStreamReader(in));
/*  37: 37 */       String line = null;
/*  38: 38 */       while ((line = reader.readLine()) != null)
/*  39:    */       {
/*  40: 39 */         String[] ss = line.split("\\,");
/*  41: 40 */         dates.add(0, ss[0]);
/*  42: 41 */         open.getChartValues().add(0, Double.valueOf(ss[1]));
/*  43: 42 */         high.getChartValues().add(0, Double.valueOf(ss[2]));
/*  44: 43 */         low.getChartValues().add(0, Double.valueOf(ss[3]));
/*  45: 44 */         history.getChartValues().add(0, Double.valueOf(ss[4]));
/*  46: 45 */         volume.getChartValues().add(0, Double.valueOf(ss[5]));
/*  47: 46 */         close.getChartValues().add(0, Double.valueOf(ss[4]));
/*  48:    */       }
/*  49:    */     }
/*  50:    */     catch (Exception e)
/*  51:    */     {
/*  52: 49 */       e.printStackTrace();
/*  53:    */     }
/*  54: 52 */     open.setName("Open");
/*  55: 53 */     high.setName("High");
/*  56: 54 */     low.setName("Low");
/*  57: 55 */     history.setName("Close");
/*  58: 56 */     volume.setName("Volume");
/*  59: 57 */     close.setName("Close");
/*  60:    */     
/*  61: 59 */     open.putChartColor(Color.GREEN);
/*  62: 60 */     high.putChartColor(Color.RED);
/*  63: 61 */     low.putChartColor(Color.YELLOW);
/*  64: 62 */     history.putChartColor(Color.BLUE);
/*  65: 63 */     volume.putChartColor(Color.BLUE);
/*  66: 64 */     close.putChartColor(Color.BLUE);
/*  67:    */     
/*  68: 66 */     RangeChart rangeChart = new RangeChart();
/*  69: 67 */     VolumeChart volumeChart = new VolumeChart();
/*  70: 68 */     HistoryChart historyChart = new HistoryChart(rangeChart, volumeChart, close.getChartValues().size());
/*  71:    */     
/*  72: 70 */     historyChart.setXScaleTextList(dates);
/*  73: 71 */     historyChart.getDataBox().addElement(history);
/*  74:    */     
/*  75: 73 */     rangeChart.setXScaleTextList(dates);
/*  76: 74 */     TDataBox box = rangeChart.getDataBox();
/*  77: 75 */     box.addElement(low);
/*  78: 76 */     box.addElement(close);
/*  79: 77 */     box.addElement(high);
/*  80:    */     
/*  81: 79 */     JPanel pane = new JPanel(new BorderLayout());
/*  82: 80 */     pane.add(historyChart);
/*  83:    */     
/*  84: 82 */     volumeChart.setXScaleTextList(dates);
/*  85: 83 */     volumeChart.getDataBox().addElement(volume);
/*  86:    */     
/*  87: 85 */     GridLayout layout = new GridLayout(3, 1);
/*  88: 86 */     layout.setVgap(10);
/*  89: 87 */     setLayout(layout);
/*  90: 88 */     add(pane);
/*  91: 89 */     add(rangeChart);
/*  92: 90 */     add(volumeChart);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private JCheckBox createCheckBox(final Element element, final TDataBox box)
/*  96:    */   {
/*  97: 94 */     final JCheckBox checkBox = new JCheckBox(element.getName(), box.contains(element));
/*  98: 95 */     checkBox.setForeground(element.getChartColor());
/*  99: 96 */     checkBox.addActionListener(new ActionListener()
/* 100:    */     {
/* 101:    */       public void actionPerformed(ActionEvent e)
/* 102:    */       {
/* 103: 99 */         if (checkBox.isSelected()) {
/* 104:100 */           box.addElement(element);
/* 105:    */         } else {
/* 106:102 */           box.removeElement(element);
/* 107:    */         }
/* 108:    */       }
/* 109:105 */     });
/* 110:106 */     return checkBox;
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.GoogleStockDemo
 * JD-Core Version:    0.7.0.1
 */
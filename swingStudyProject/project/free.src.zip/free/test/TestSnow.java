/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import com.sun.awt.AWTUtilities;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Graphics2D;
/*  6:   */ import java.awt.Image;
/*  7:   */ import java.awt.Rectangle;
/*  8:   */ import javax.swing.JFrame;
/*  9:   */ import javax.swing.JPanel;
/* 10:   */ import twaver.TWaverUtil;
/* 11:   */ 
/* 12:   */ public class TestSnow
/* 13:   */ {
/* 14:   */   public static void main(String[] args)
/* 15:   */   {
/* 16:15 */     JFrame frame = new JFrame();
/* 17:16 */     frame.setAlwaysOnTop(true);
/* 18:17 */     frame.setDefaultCloseOperation(3);
/* 19:18 */     frame.setUndecorated(true);
/* 20:19 */     frame.setExtendedState(6);
/* 21:20 */     AWTUtilities.setWindowOpaque(frame, false);
/* 22:   */     
/* 23:22 */     JPanel pane = new JPanel()
/* 24:   */     {
/* 25:24 */       private int[] snowX = null;
/* 26:25 */       private int[] snowY = null;
/* 27:26 */       private int[] angles = null;
/* 28:27 */       private int count = 50;
/* 29:   */       
/* 30:   */       public void paint(Graphics g)
/* 31:   */       {
/* 32:31 */         super.paint(g);
/* 33:32 */         Rectangle bounds = this.val$frame.getBounds();
/* 34:33 */         if (this.snowX == null)
/* 35:   */         {
/* 36:35 */           this.snowX = new int[this.count];
/* 37:36 */           for (int i = 0; i < this.snowX.length; i++) {
/* 38:37 */             this.snowX[i] = TWaverUtil.getRandomInt(bounds.width);
/* 39:   */           }
/* 40:39 */           this.snowY = new int[this.count];
/* 41:40 */           for (int i = 0; i < this.snowY.length; i++) {
/* 42:41 */             this.snowY[i] = TWaverUtil.getRandomInt(bounds.height);
/* 43:   */           }
/* 44:43 */           this.angles = new int[this.count];
/* 45:44 */           for (int i = 0; i < this.snowY.length; i++) {
/* 46:45 */             this.angles[i] = TWaverUtil.getRandomInt(360);
/* 47:   */           }
/* 48:   */         }
/* 49:49 */         Graphics2D g2d = (Graphics2D)g;
/* 50:50 */         Image image = TWaverUtil.getImage("/free/test/snow.png");
/* 51:51 */         for (int i = 0; i < this.count; i++)
/* 52:   */         {
/* 53:52 */           this.snowX[i] += TWaverUtil.getRandomInt(5) - 3;
/* 54:53 */           this.snowY[i] += 5;
/* 55:54 */           this.angles[i] += i / 5;
/* 56:55 */           this.snowY[i] = (this.snowY[i] > bounds.height ? 0 : this.snowY[i]);
/* 57:56 */           this.angles[i] = (this.angles[i] > 360 ? 0 : this.angles[i]);
/* 58:57 */           int x = this.snowX[i];
/* 59:58 */           int y = this.snowY[i];
/* 60:59 */           int angle = this.angles[i];
/* 61:60 */           g2d.translate(x, y);
/* 62:61 */           double angleValue = Math.toRadians(angle);
/* 63:62 */           g2d.rotate(angleValue);
/* 64:63 */           g2d.drawImage(image, 0, 0, null);
/* 65:64 */           g2d.rotate(-angleValue);
/* 66:65 */           g2d.translate(-x, -y);
/* 67:   */         }
/* 68:   */       }
/* 69:69 */     };
/* 70:70 */     frame.setContentPane(pane);
/* 71:71 */     frame.setVisible(true);
/* 72:72 */     Thread thread = new Thread()
/* 73:   */     {
/* 74:   */       public void run()
/* 75:   */       {
/* 76:   */         for (;;)
/* 77:   */         {
/* 78:   */           try
/* 79:   */           {
/* 80:78 */             Thread.sleep(10L);
/* 81:   */           }
/* 82:   */           catch (Exception ex)
/* 83:   */           {
/* 84:80 */             ex.printStackTrace();
/* 85:   */           }
/* 86:82 */           this.val$pane.repaint();
/* 87:   */         }
/* 88:   */       }
/* 89:86 */     };
/* 90:87 */     thread.start();
/* 91:   */   }
/* 92:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.TestSnow
 * JD-Core Version:    0.7.0.1
 */
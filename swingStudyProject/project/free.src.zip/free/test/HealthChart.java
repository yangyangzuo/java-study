/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Font;
/*   6:    */ import java.awt.event.ItemEvent;
/*   7:    */ import java.awt.event.ItemListener;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.List;
/*  10:    */ import javax.swing.JComboBox;
/*  11:    */ import javax.swing.JToolBar;
/*  12:    */ import twaver.Element;
/*  13:    */ import twaver.ElementCallbackHandler;
/*  14:    */ import twaver.Node;
/*  15:    */ import twaver.TDataBox;
/*  16:    */ import twaver.chart.Marker;
/*  17:    */ import twaver.chart.PercentChart;
/*  18:    */ 
/*  19:    */ public class HealthChart
/*  20:    */   extends Portlet
/*  21:    */ {
/*  22: 24 */   private TDataBox box = new TDataBox();
/*  23: 25 */   private PercentChart chart = new PercentChart(this.box);
/*  24:    */   
/*  25:    */   public HealthChart()
/*  26:    */   {
/*  27: 28 */     super.initialize(this.chart);
/*  28: 29 */     this.chart.setTitle("Server Health Monitor");
/*  29: 30 */     this.chart.setGradient(true);
/*  30: 31 */     this.chart.setPercentLabelFont(new Font("Forte", 0, 13));
/*  31: 32 */     this.chart.setPercentLabelColor(Color.blue);
/*  32: 33 */     this.chart.setSegmentCount(10);
/*  33: 34 */     this.chart.setMarkerStartPosition(2);
/*  34: 35 */     addElement("CPU", 16.0D, 50, 90, 3).setUserObject(Boolean.TRUE);
/*  35: 36 */     addElement("Memory", 70.0D, 60, 80, 1).setUserObject(Boolean.FALSE);
/*  36: 37 */     addElement("Storage", 64.0D, 30, 60, 2).setUserObject(Boolean.TRUE);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private Element addElement(String name, double current, int marker1, int marker2, int style)
/*  40:    */   {
/*  41: 41 */     List markers = new ArrayList();
/*  42: 42 */     Marker marker = new Marker();
/*  43: 43 */     marker.setColor(Color.GREEN);
/*  44: 44 */     marker.setTextColor(marker.getColor());
/*  45: 45 */     marker.setValue(0.0D);
/*  46: 46 */     marker.setText("0%");
/*  47: 47 */     markers.add(marker);
/*  48:    */     
/*  49: 49 */     marker = new Marker();
/*  50: 50 */     marker.setColor(Color.ORANGE);
/*  51: 51 */     marker.setTextColor(marker.getColor());
/*  52: 52 */     marker.setValue(marker1);
/*  53: 53 */     marker.setText(marker1 + "%");
/*  54: 54 */     markers.add(marker);
/*  55:    */     
/*  56: 56 */     marker = new Marker();
/*  57: 57 */     marker.setColor(Color.RED);
/*  58: 58 */     marker.setTextColor(marker.getColor());
/*  59: 59 */     marker.setValue(marker2);
/*  60: 60 */     marker.setText(marker2 + "%");
/*  61: 61 */     markers.add(marker);
/*  62:    */     
/*  63: 63 */     Element element = new Node();
/*  64: 64 */     element.putChartPercentSpareFill(true);
/*  65: 65 */     element.setName(name);
/*  66: 66 */     element.putChartValue(current);
/*  67: 67 */     element.putChartPercentStyle(style);
/*  68: 68 */     element.putChartMarkers(markers);
/*  69:    */     
/*  70: 70 */     this.box.addElement(element);
/*  71: 71 */     return element;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void run()
/*  75:    */   {
/*  76: 75 */     if (!isRunning()) {
/*  77: 76 */       return;
/*  78:    */     }
/*  79: 78 */     this.box.iterator(new ElementCallbackHandler()
/*  80:    */     {
/*  81:    */       public boolean processElement(Element element)
/*  82:    */       {
/*  83: 81 */         double value = element.getChartValue();
/*  84: 82 */         if (Boolean.TRUE.equals(element.getUserObject()))
/*  85:    */         {
/*  86: 83 */           value += 2.0D;
/*  87: 84 */           if (value >= 100.0D) {
/*  88: 85 */             element.setUserObject(Boolean.FALSE);
/*  89:    */           }
/*  90:    */         }
/*  91:    */         else
/*  92:    */         {
/*  93: 88 */           value -= 2.0D;
/*  94: 89 */           if (value <= 0.0D) {
/*  95: 90 */             element.setUserObject(Boolean.TRUE);
/*  96:    */           }
/*  97:    */         }
/*  98: 93 */         element.putChartValue(value);
/*  99: 94 */         return true;
/* 100:    */       }
/* 101:    */     });
/* 102:    */   }
/* 103:    */   
/* 104:    */   public JToolBar getControlPanel()
/* 105:    */   {
/* 106:100 */     JToolBar toolbar = super.getControlPanel();
/* 107:101 */     toolbar.add(getRunButton());
/* 108:102 */     final JComboBox prorateCombobox = new JComboBox();
/* 109:103 */     prorateCombobox.addItem("0.1");
/* 110:104 */     prorateCombobox.addItem("0.2");
/* 111:105 */     prorateCombobox.addItem("0.3");
/* 112:106 */     prorateCombobox.addItem("0.4");
/* 113:107 */     prorateCombobox.addItem("0.5");
/* 114:108 */     prorateCombobox.addItem("0.6");
/* 115:109 */     prorateCombobox.addItem("0.7");
/* 116:110 */     prorateCombobox.addItem("0.8");
/* 117:111 */     prorateCombobox.addItem("0.9");
/* 118:112 */     prorateCombobox.addItemListener(new ItemListener()
/* 119:    */     {
/* 120:    */       public void itemStateChanged(ItemEvent e)
/* 121:    */       {
/* 122:115 */         String value = prorateCombobox.getSelectedItem().toString();
/* 123:116 */         HealthChart.this.chart.setSegmentSectionProrate(Double.valueOf(value).doubleValue());
/* 124:    */       }
/* 125:118 */     });
/* 126:119 */     prorateCombobox.setSelectedItem("0.5");
/* 127:120 */     prorateCombobox.setPreferredSize(new Dimension(prorateCombobox.getPreferredSize().width, 20));
/* 128:121 */     toolbar.add(prorateCombobox);
/* 129:122 */     final JComboBox combobox = new JComboBox();
/* 130:123 */     combobox.addItem("horizontal");
/* 131:124 */     combobox.addItem("vertical ");
/* 132:125 */     combobox.addItemListener(new ItemListener()
/* 133:    */     {
/* 134:    */       public void itemStateChanged(ItemEvent e)
/* 135:    */       {
/* 136:128 */         if (combobox.getSelectedIndex() == 0)
/* 137:    */         {
/* 138:129 */           HealthChart.this.chart.setPercentType(1);
/* 139:130 */           HealthChart.this.chart.setPercentLabelCenter(false);
/* 140:    */         }
/* 141:131 */         else if (combobox.getSelectedIndex() == 1)
/* 142:    */         {
/* 143:132 */           HealthChart.this.chart.setPercentType(2);
/* 144:133 */           HealthChart.this.chart.setPercentLabelCenter(true);
/* 145:    */         }
/* 146:    */       }
/* 147:136 */     });
/* 148:137 */     combobox.setPreferredSize(new Dimension(combobox.getPreferredSize().width, 20));
/* 149:138 */     toolbar.add(combobox);
/* 150:139 */     final JComboBox position = new JComboBox();
/* 151:140 */     position.addItem("Default");
/* 152:141 */     position.addItem("InnerDefault");
/* 153:142 */     position.addItem("Top");
/* 154:143 */     position.addItem("Bottom");
/* 155:144 */     position.addItem("Left");
/* 156:145 */     position.addItem("Right");
/* 157:146 */     position.addItem("InnerTop");
/* 158:147 */     position.addItem("InnerBottom");
/* 159:148 */     position.addItem("InnerLeft");
/* 160:149 */     position.addItem("InnerRight");
/* 161:    */     
/* 162:151 */     position.addItemListener(new ItemListener()
/* 163:    */     {
/* 164:    */       public void itemStateChanged(ItemEvent e)
/* 165:    */       {
/* 166:154 */         if (position.getSelectedIndex() == 2) {
/* 167:155 */           HealthChart.this.chart.setMarkerPosition(2);
/* 168:156 */         } else if (position.getSelectedIndex() == 3) {
/* 169:157 */           HealthChart.this.chart.setMarkerPosition(4);
/* 170:158 */         } else if (position.getSelectedIndex() == 4) {
/* 171:159 */           HealthChart.this.chart.setMarkerPosition(6);
/* 172:160 */         } else if (position.getSelectedIndex() == 5) {
/* 173:161 */           HealthChart.this.chart.setMarkerPosition(8);
/* 174:162 */         } else if (position.getSelectedIndex() == 6) {
/* 175:163 */           HealthChart.this.chart.setMarkerPosition(3);
/* 176:164 */         } else if (position.getSelectedIndex() == 7) {
/* 177:165 */           HealthChart.this.chart.setMarkerPosition(5);
/* 178:166 */         } else if (position.getSelectedIndex() == 8) {
/* 179:167 */           HealthChart.this.chart.setMarkerPosition(7);
/* 180:168 */         } else if (position.getSelectedIndex() == 9) {
/* 181:169 */           HealthChart.this.chart.setMarkerPosition(9);
/* 182:170 */         } else if (position.getSelectedIndex() == 1) {
/* 183:171 */           HealthChart.this.chart.setMarkerPosition(10);
/* 184:    */         } else {
/* 185:173 */           HealthChart.this.chart.setMarkerPosition(1);
/* 186:    */         }
/* 187:    */       }
/* 188:176 */     });
/* 189:177 */     position.setSelectedIndex(0);
/* 190:178 */     position.setPreferredSize(new Dimension(position.getPreferredSize().width, 20));
/* 191:179 */     toolbar.add(position);
/* 192:180 */     return toolbar;
/* 193:    */   }
/* 194:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.HealthChart
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Graphics2D;
/*   5:    */ import java.awt.Point;
/*   6:    */ import java.awt.Rectangle;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ import java.awt.event.MouseEvent;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JMenuItem;
/*  12:    */ import javax.swing.JPanel;
/*  13:    */ import javax.swing.JPopupMenu;
/*  14:    */ import javax.swing.SwingUtilities;
/*  15:    */ import twaver.PopupMenuGenerator;
/*  16:    */ import twaver.TView;
/*  17:    */ import twaver.chart.LineChart;
/*  18:    */ 
/*  19:    */ public class HistoryChart
/*  20:    */   extends LineChart
/*  21:    */ {
/*  22: 22 */   private int valuesCount = 0;
/*  23: 23 */   private LineChart rangeChart = null;
/*  24: 24 */   private LineChart volumeChart = null;
/*  25: 25 */   private Point startPoint = null;
/*  26: 26 */   private Point endPoint = null;
/*  27: 27 */   private Point lastPoint = null;
/*  28:    */   
/*  29:    */   public void paintChart(Graphics2D g2d, int width, int height)
/*  30:    */   {
/*  31: 30 */     super.paintChart(g2d, width, height);
/*  32: 31 */     if ((this.startPoint != null) && (this.endPoint != null))
/*  33:    */     {
/*  34: 32 */       Rectangle bounds = getBackgroundBounds();
/*  35: 33 */       g2d.setColor(new Color(0, 255, 0, 128));
/*  36: 34 */       int x = Math.min(this.startPoint.x, this.endPoint.x);
/*  37: 35 */       int y = bounds.y;
/*  38: 36 */       int w = Math.abs(this.endPoint.x - this.startPoint.x);
/*  39: 37 */       int h = bounds.height;
/*  40: 38 */       g2d.fillRect(x, y, w, h);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   private boolean isValidEvent(MouseEvent e)
/*  45:    */   {
/*  46: 43 */     if (SwingUtilities.isLeftMouseButton(e))
/*  47:    */     {
/*  48: 44 */       Rectangle bounds = getBackgroundBounds();
/*  49: 45 */       bounds.grow(1, 1);
/*  50: 46 */       if (bounds.contains(e.getPoint())) {
/*  51: 47 */         return true;
/*  52:    */       }
/*  53:    */     }
/*  54: 50 */     return false;
/*  55:    */   }
/*  56:    */   
/*  57:    */   private boolean isInsideEvent(MouseEvent e)
/*  58:    */   {
/*  59: 54 */     if ((this.startPoint != null) && (this.endPoint != null))
/*  60:    */     {
/*  61: 55 */       if ((e.getX() >= this.startPoint.x) && (e.getX() <= this.endPoint.getX())) {
/*  62: 56 */         return true;
/*  63:    */       }
/*  64: 58 */       if ((e.getX() >= this.endPoint.x) && (e.getX() <= this.startPoint.getX())) {
/*  65: 59 */         return true;
/*  66:    */       }
/*  67:    */     }
/*  68: 62 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void mousePressed(MouseEvent e)
/*  72:    */   {
/*  73: 66 */     this.lastPoint = null;
/*  74: 67 */     if (isValidEvent(e))
/*  75:    */     {
/*  76: 68 */       if (isInsideEvent(e))
/*  77:    */       {
/*  78: 69 */         this.lastPoint = e.getPoint();
/*  79:    */       }
/*  80:    */       else
/*  81:    */       {
/*  82: 71 */         this.startPoint = e.getPoint();
/*  83: 72 */         this.endPoint = e.getPoint();
/*  84: 73 */         this.lastPoint = null;
/*  85:    */       }
/*  86: 75 */       changeRange();
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void mouseDragged(MouseEvent e)
/*  91:    */   {
/*  92: 80 */     if ((isValidEvent(e)) && (this.startPoint != null))
/*  93:    */     {
/*  94: 81 */       if (this.lastPoint != null)
/*  95:    */       {
/*  96: 82 */         int offset = this.lastPoint.x - e.getX();
/*  97: 83 */         this.startPoint.x -= offset;
/*  98: 84 */         this.endPoint.x -= offset;
/*  99: 85 */         this.lastPoint = e.getPoint();
/* 100:    */       }
/* 101:    */       else
/* 102:    */       {
/* 103: 87 */         this.endPoint = e.getPoint();
/* 104:    */       }
/* 105: 89 */       changeRange();
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void changeRange()
/* 110:    */   {
/* 111: 94 */     getChartPane().repaint();
/* 112: 96 */     if (this.startPoint.x == this.endPoint.x)
/* 113:    */     {
/* 114: 97 */       this.rangeChart.setStartIndex(0);
/* 115: 98 */       this.rangeChart.setEndIndex(2147483647);
/* 116: 99 */       this.volumeChart.setStartIndex(0);
/* 117:100 */       this.volumeChart.setEndIndex(2147483647);
/* 118:101 */       this.rangeChart.setXScaleTextSpanCount(30);
/* 119:102 */       this.volumeChart.setXScaleTextSpanCount(30);
/* 120:    */     }
/* 121:    */     else
/* 122:    */     {
/* 123:104 */       double x1 = getStartX();
/* 124:105 */       double x2 = getEndX();
/* 125:106 */       double w = (x2 - x1) / (this.valuesCount - 1);
/* 126:107 */       int s = (int)((this.startPoint.x - x1) / w);
/* 127:108 */       int e = (int)((this.endPoint.x - x1) / w);
/* 128:109 */       if (s > e)
/* 129:    */       {
/* 130:110 */         int tmp = e;
/* 131:111 */         e = s;
/* 132:112 */         s = tmp;
/* 133:    */       }
/* 134:114 */       if (s < 0) {
/* 135:115 */         s = 0;
/* 136:    */       }
/* 137:117 */       if (e > this.valuesCount) {
/* 138:118 */         e = this.valuesCount;
/* 139:    */       }
/* 140:121 */       this.rangeChart.setStartIndex(s);
/* 141:122 */       this.rangeChart.setEndIndex(e);
/* 142:123 */       this.volumeChart.setStartIndex(s);
/* 143:124 */       this.volumeChart.setEndIndex(e);
/* 144:    */       
/* 145:126 */       int span = Math.max(1, 15 * (e - s) / this.rangeChart.getBackgroundBounds().width - 1);
/* 146:127 */       this.rangeChart.setXScaleTextSpanCount(span);
/* 147:128 */       this.volumeChart.setXScaleTextSpanCount(span);
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public HistoryChart(LineChart rangeChart, LineChart volumeChart, int valuesCount)
/* 152:    */   {
/* 153:134 */     this.rangeChart = rangeChart;
/* 154:135 */     this.volumeChart = volumeChart;
/* 155:136 */     this.valuesCount = valuesCount;
/* 156:137 */     setEnableXTranslate(false);
/* 157:138 */     setEnableXZoom(false);
/* 158:139 */     setEnableYTranslate(false);
/* 159:140 */     setEnableYZoom(false);
/* 160:141 */     setLineType(2);
/* 161:142 */     setValueSpanCount(7);
/* 162:143 */     setXScaleTextSpanCount(35);
/* 163:144 */     setXScaleTextOrientation(4);
/* 164:145 */     setLowerLimit(0.0D);
/* 165:146 */     setYScaleTextVisible(true);
/* 166:147 */     setYScaleValueGap(100.0D);
/* 167:148 */     setLegendLayout(2);
/* 168:149 */     getLegendPane().setVisible(false);
/* 169:150 */     setEnableToolTipText(false);
/* 170:    */     
/* 171:152 */     setPopupMenuGenerator(new PopupMenuGenerator()
/* 172:    */     {
/* 173:    */       public JPopupMenu generate(TView tview, MouseEvent mouseEvent)
/* 174:    */       {
/* 175:155 */         JPopupMenu popup = new JPopupMenu();
/* 176:156 */         popup.add(HistoryChart.this.createMenuItem(1, 15));
/* 177:157 */         popup.add(HistoryChart.this.createMenuItem(3, 30));
/* 178:158 */         popup.add(HistoryChart.this.createMenuItem(7, 35));
/* 179:159 */         popup.add(HistoryChart.this.createMenuItem(15, 45));
/* 180:160 */         popup.add(HistoryChart.this.createMenuItem(30, 60));
/* 181:161 */         popup.add(HistoryChart.this.createMenuItem(60, 60));
/* 182:162 */         popup.add(HistoryChart.this.createMenuItem(120, 120));
/* 183:163 */         return popup;
/* 184:    */       }
/* 185:    */     });
/* 186:    */   }
/* 187:    */   
/* 188:    */   private JMenuItem createMenuItem(final int valueSpanCount, final int textSpanCount)
/* 189:    */   {
/* 190:169 */     JMenuItem item = new JMenuItem("Value Span:" + valueSpanCount + "|Text Span:" + textSpanCount);
/* 191:170 */     item.addActionListener(new ActionListener()
/* 192:    */     {
/* 193:    */       public void actionPerformed(ActionEvent e)
/* 194:    */       {
/* 195:173 */         HistoryChart.this.setValueSpanCount(valueSpanCount);
/* 196:174 */         HistoryChart.this.setXScaleTextSpanCount(textSpanCount);
/* 197:    */       }
/* 198:176 */     });
/* 199:177 */     return item;
/* 200:    */   }
/* 201:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.HistoryChart
 * JD-Core Version:    0.7.0.1
 */
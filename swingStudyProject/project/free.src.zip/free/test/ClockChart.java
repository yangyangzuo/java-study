/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.event.ItemEvent;
/*   7:    */ import java.awt.event.ItemListener;
/*   8:    */ import java.util.Calendar;
/*   9:    */ import javax.swing.Icon;
/*  10:    */ import javax.swing.JComboBox;
/*  11:    */ import javax.swing.JList;
/*  12:    */ import javax.swing.JPanel;
/*  13:    */ import javax.swing.JToolBar;
/*  14:    */ import javax.swing.ListCellRenderer;
/*  15:    */ import javax.swing.plaf.basic.BasicComboBoxRenderer;
/*  16:    */ import twaver.Element;
/*  17:    */ import twaver.EnumType;
/*  18:    */ import twaver.EnumTypeManager;
/*  19:    */ import twaver.Node;
/*  20:    */ import twaver.TDataBox;
/*  21:    */ import twaver.TUIManager;
/*  22:    */ import twaver.TWaverUtil;
/*  23:    */ import twaver.TaskAdapter;
/*  24:    */ import twaver.TaskScheduler;
/*  25:    */ import twaver.chart.DialChart;
/*  26:    */ 
/*  27:    */ public class ClockChart
/*  28:    */   extends Portlet
/*  29:    */ {
/*  30:    */   private Element hour;
/*  31:    */   private Element minute;
/*  32:    */   private Element second;
/*  33: 34 */   private TDataBox box = new TDataBox();
/*  34: 35 */   private DialChart chart = new DialChart(this.box)
/*  35:    */   {
/*  36:    */     public String getToolTipText(Element element)
/*  37:    */     {
/*  38: 38 */       double value = element.getChartValue();
/*  39: 39 */       if (element == ClockChart.this.hour) {
/*  40: 40 */         return element.getName() + ":" + (int)value;
/*  41:    */       }
/*  42: 42 */       return element.getName() + ":" + (int)(value * 5.0D);
/*  43:    */     }
/*  44:    */   };
/*  45:    */   
/*  46:    */   public ClockChart()
/*  47:    */   {
/*  48: 47 */     super.initialize(this.chart);
/*  49: 48 */     this.chart.setTitle("Clock");
/*  50: 49 */     this.chart.setStartAngle(-90.0D);
/*  51: 50 */     this.chart.setEndAngle(270.0D);
/*  52: 51 */     this.chart.setMaxValue(12.0D);
/*  53: 52 */     this.chart.setScaleMajorCount(12);
/*  54: 53 */     this.chart.setScaleMinorCount(4);
/*  55: 54 */     this.chart.setScaleInside(true);
/*  56: 55 */     this.chart.setScaleLength(12.0D);
/*  57: 56 */     this.chart.setScaleStyle(1);
/*  58: 57 */     this.chart.setBallSize(8.0D);
/*  59: 58 */     this.chart.getLegendPane().setVisible(false);
/*  60: 59 */     this.chart.setRingFillColor(Color.DARK_GRAY);
/*  61: 60 */     this.chart.setRingGradientColor(Color.LIGHT_GRAY);
/*  62: 61 */     this.chart.setRingGradientFactory(10);
/*  63: 62 */     this.chart.setRingStroke("solid.5");
/*  64: 63 */     this.chart.setValueTextVisible(false);
/*  65:    */     
/*  66: 65 */     Calendar calendar = Calendar.getInstance();
/*  67: 66 */     double secondValue = calendar.get(13);
/*  68: 67 */     double minuteValue = calendar.get(12) + secondValue / 60.0D;
/*  69: 68 */     double hourValue = calendar.get(10) + minuteValue / 60.0D;
/*  70:    */     
/*  71: 70 */     this.hour = new Node();
/*  72: 71 */     this.hour.setName("hour");
/*  73: 72 */     this.hour.putChartDialHandLength(0.7D);
/*  74: 73 */     this.hour.putChartDialHandStyle(3);
/*  75: 74 */     this.hour.putChartValue(hourValue);
/*  76: 75 */     this.hour.putChartColor(Color.GREEN.darker());
/*  77: 76 */     this.hour.putChartStroke("solid.6");
/*  78:    */     
/*  79: 78 */     this.minute = new Node();
/*  80: 79 */     this.minute.setName("minute");
/*  81: 80 */     this.minute.putChartDialHandLength(0.8D);
/*  82: 81 */     this.minute.putChartDialHandStyle(2);
/*  83: 82 */     this.minute.putChartValue(minuteValue / 5.0D);
/*  84: 83 */     this.minute.putChartColor(Color.ORANGE);
/*  85: 84 */     this.minute.putChartStroke("solid.12");
/*  86:    */     
/*  87: 86 */     this.second = new Node();
/*  88: 87 */     this.second.setName("second");
/*  89: 88 */     this.second.putChartDialHandLength(0.9D);
/*  90: 89 */     this.second.putChartDialHandStyle(1);
/*  91: 90 */     this.second.putChartValue(secondValue / 5.0D);
/*  92: 91 */     this.second.putChartColor(Color.BLACK);
/*  93: 92 */     this.box.addElement(this.hour);
/*  94: 93 */     this.box.addElement(this.minute);
/*  95: 94 */     this.box.addElement(this.second);
/*  96:    */     
/*  97: 96 */     TaskScheduler.getInstance().register(new TaskAdapter()
/*  98:    */     {
/*  99:    */       public int getInterval()
/* 100:    */       {
/* 101: 99 */         return 1000;
/* 102:    */       }
/* 103:    */       
/* 104:    */       public void run(long clock)
/* 105:    */       {
/* 106:103 */         if (!ClockChart.this.isRunning()) {
/* 107:104 */           return;
/* 108:    */         }
/* 109:106 */         Calendar calendar = Calendar.getInstance();
/* 110:107 */         double secondValue = calendar.get(13);
/* 111:108 */         double minuteValue = calendar.get(12) + secondValue / 60.0D;
/* 112:109 */         double hourValue = calendar.get(10) + minuteValue / 60.0D;
/* 113:110 */         ClockChart.this.hour.putChartValue(hourValue);
/* 114:111 */         ClockChart.this.minute.putChartValue(minuteValue / 5.0D);
/* 115:112 */         ClockChart.this.second.putChartValue(secondValue / 5.0D);
/* 116:    */       }
/* 117:    */     });
/* 118:    */   }
/* 119:    */   
/* 120:    */   public JToolBar getControlPanel()
/* 121:    */   {
/* 122:118 */     JToolBar toolbar = super.getControlPanel();
/* 123:119 */     toolbar.add(getRunButton());
/* 124:120 */     final JComboBox combobox = new JComboBox();
/* 125:121 */     final BasicComboBoxRenderer renderer = new BasicComboBoxRenderer();
/* 126:122 */     TWaverUtil.setHorizontalAlignment(renderer, TUIManager.getString("table.alignment.enumtype"));
/* 127:123 */     combobox.setRenderer(new ListCellRenderer()
/* 128:    */     {
/* 129:    */       public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 130:    */       {
/* 131:126 */         String text = null;
/* 132:127 */         Icon icon = null;
/* 133:128 */         Color background = null;
/* 134:129 */         Color foreground = null;
/* 135:130 */         if ((value instanceof EnumType))
/* 136:    */         {
/* 137:131 */           EnumType enumType = (EnumType)value;
/* 138:132 */           text = enumType.toString();
/* 139:133 */           icon = enumType.getIcon();
/* 140:134 */           background = enumType.getBackground();
/* 141:135 */           foreground = enumType.getForeground();
/* 142:136 */           if ((background != null) && (isSelected)) {
/* 143:137 */             background = background.darker();
/* 144:    */           }
/* 145:    */         }
/* 146:140 */         renderer.getListCellRendererComponent(list, text, index, isSelected, cellHasFocus);
/* 147:141 */         renderer.setIcon(icon);
/* 148:142 */         renderer.setToolTipText(text);
/* 149:143 */         if (foreground != null) {
/* 150:144 */           renderer.setForeground(foreground);
/* 151:    */         }
/* 152:146 */         if (background != null) {
/* 153:147 */           renderer.setBackground(background);
/* 154:    */         }
/* 155:149 */         return renderer;
/* 156:    */       }
/* 157:151 */     });
/* 158:152 */     combobox.setPreferredSize(new Dimension(combobox.getPreferredSize().width, 20));
/* 159:153 */     final Object[] gradientTypes = EnumTypeManager.getInstance().getEnumTypes("twaver.gradient");
/* 160:154 */     final int length = gradientTypes.length;
/* 161:155 */     for (int i = 0; i < length; i++)
/* 162:    */     {
/* 163:156 */       EnumType enumeration = (EnumType)gradientTypes[i];
/* 164:157 */       combobox.addItem(enumeration);
/* 165:158 */       if (10 == ((Integer)enumeration.getValue()).intValue()) {
/* 166:159 */         combobox.setSelectedIndex(i);
/* 167:    */       }
/* 168:    */     }
/* 169:162 */     combobox.addItemListener(new ItemListener()
/* 170:    */     {
/* 171:    */       public void itemStateChanged(ItemEvent e)
/* 172:    */       {
/* 173:165 */         Object object = combobox.getSelectedItem();
/* 174:166 */         for (int i = 0; i < length; i++)
/* 175:    */         {
/* 176:167 */           EnumType enumeration = (EnumType)gradientTypes[i];
/* 177:168 */           if (enumeration == object) {
/* 178:169 */             ClockChart.this.chart.setRingGradientFactory(((Integer)enumeration.getValue()).intValue());
/* 179:    */           }
/* 180:    */         }
/* 181:    */       }
/* 182:173 */     });
/* 183:174 */     toolbar.add(combobox);
/* 184:175 */     return toolbar;
/* 185:    */   }
/* 186:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.ClockChart
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.event.ItemEvent;
/*   6:    */ import java.awt.event.ItemListener;
/*   7:    */ import javax.swing.JComboBox;
/*   8:    */ import javax.swing.JToolBar;
/*   9:    */ import twaver.Element;
/*  10:    */ import twaver.ElementCallbackHandler;
/*  11:    */ import twaver.Node;
/*  12:    */ import twaver.TDataBox;
/*  13:    */ import twaver.TWaverUtil;
/*  14:    */ import twaver.chart.BarChart;
/*  15:    */ import twaver.chart.Marker;
/*  16:    */ 
/*  17:    */ public class MarkerChart
/*  18:    */   extends Portlet
/*  19:    */ {
/*  20: 22 */   private TDataBox box = new TDataBox();
/*  21: 23 */   private BarChart chart = new BarChart(this.box)
/*  22:    */   {
/*  23:    */     public Color getColor(Element element)
/*  24:    */     {
/*  25: 26 */       double value = element.getChartValue();
/*  26: 27 */       if (value < -70.0D) {
/*  27: 28 */         return Color.RED;
/*  28:    */       }
/*  29: 30 */       if (value > 70.0D) {
/*  30: 31 */         return Color.ORANGE;
/*  31:    */       }
/*  32: 33 */       return Color.GREEN;
/*  33:    */     }
/*  34:    */   };
/*  35:    */   
/*  36:    */   public MarkerChart()
/*  37:    */   {
/*  38: 38 */     super.initialize(this.chart);
/*  39: 39 */     this.chart.setSelectedOffset(0);
/*  40: 40 */     this.chart.setShadowOffset(0);
/*  41: 41 */     this.chart.setGradient(true);
/*  42: 42 */     this.chart.setUpperLimit(100.0D);
/*  43: 43 */     this.chart.setLowerLimit(-100.0D);
/*  44: 44 */     this.chart.setYScaleValueGap(10.0D);
/*  45: 45 */     this.chart.setYScaleTextVisible(true);
/*  46: 46 */     this.chart.setYScaleMinTextVisible(true);
/*  47:    */     
/*  48: 48 */     Marker marker = new Marker(70.0D, Color.ORANGE);
/*  49: 49 */     marker.setText("high level marker");
/*  50: 50 */     marker.setColor(Color.ORANGE);
/*  51: 51 */     this.chart.addMarker(marker);
/*  52:    */     
/*  53: 53 */     marker = new Marker(-70.0D, Color.RED);
/*  54: 54 */     marker.setText("low level marker");
/*  55: 55 */     marker.setColor(Color.RED);
/*  56: 56 */     this.chart.addMarker(marker);
/*  57: 58 */     for (int i = 1; i < 8; i++)
/*  58:    */     {
/*  59: 59 */       Element element = new Node();
/*  60: 60 */       element.putChartValue(TWaverUtil.getRandomInt(100));
/*  61: 61 */       element.setUserObject(TWaverUtil.getRandomBoolean());
/*  62: 62 */       element.setName("C" + i);
/*  63: 63 */       this.box.addElement(element);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void run()
/*  68:    */   {
/*  69: 68 */     if (!isRunning()) {
/*  70: 69 */       return;
/*  71:    */     }
/*  72: 71 */     this.box.iterator(new ElementCallbackHandler()
/*  73:    */     {
/*  74:    */       public boolean processElement(Element element)
/*  75:    */       {
/*  76: 74 */         double value = element.getChartValue();
/*  77: 75 */         if (Boolean.TRUE.equals(element.getUserObject()))
/*  78:    */         {
/*  79: 76 */           value += 3.0D;
/*  80: 77 */           if (value >= 98.0D) {
/*  81: 78 */             element.setUserObject(Boolean.FALSE);
/*  82:    */           }
/*  83:    */         }
/*  84:    */         else
/*  85:    */         {
/*  86: 81 */           value -= 3.0D;
/*  87: 82 */           if (value <= -98.0D) {
/*  88: 83 */             element.setUserObject(Boolean.TRUE);
/*  89:    */           }
/*  90:    */         }
/*  91: 86 */         element.putChartValue(value);
/*  92: 87 */         return true;
/*  93:    */       }
/*  94:    */     });
/*  95:    */   }
/*  96:    */   
/*  97:    */   public JToolBar getControlPanel()
/*  98:    */   {
/*  99: 93 */     JToolBar toolbar = super.getControlPanel();
/* 100: 94 */     toolbar.add(getRunButton());
/* 101: 95 */     final JComboBox combobox = new JComboBox();
/* 102: 96 */     combobox.setPreferredSize(new Dimension(combobox.getPreferredSize().width, 20));
/* 103: 97 */     combobox.addItem("South");
/* 104: 98 */     combobox.addItem("East");
/* 105: 99 */     combobox.addItem("West");
/* 106:100 */     combobox.addItem("North");
/* 107:    */     
/* 108:102 */     combobox.addItemListener(new ItemListener()
/* 109:    */     {
/* 110:    */       public void itemStateChanged(ItemEvent e)
/* 111:    */       {
/* 112:105 */         if (combobox.getSelectedItem().toString().equals("South"))
/* 113:    */         {
/* 114:106 */           MarkerChart.this.chart.setLegendLayout(1);
/* 115:107 */           MarkerChart.this.chart.setLegendOrientation(1);
/* 116:    */         }
/* 117:108 */         else if (combobox.getSelectedItem().toString().equals("East"))
/* 118:    */         {
/* 119:109 */           MarkerChart.this.chart.setLegendLayout(2);
/* 120:110 */           MarkerChart.this.chart.setLegendOrientation(1);
/* 121:    */         }
/* 122:111 */         else if (combobox.getSelectedItem().toString().equals("West"))
/* 123:    */         {
/* 124:112 */           MarkerChart.this.chart.setLegendLayout(7);
/* 125:113 */           MarkerChart.this.chart.setLegendOrientation(1);
/* 126:    */         }
/* 127:114 */         else if (combobox.getSelectedItem().toString().equals("North"))
/* 128:    */         {
/* 129:115 */           MarkerChart.this.chart.setLegendLayout(5);
/* 130:116 */           MarkerChart.this.chart.setLegendOrientation(2);
/* 131:    */         }
/* 132:    */       }
/* 133:120 */     });
/* 134:121 */     toolbar.add(combobox);
/* 135:    */     
/* 136:123 */     return toolbar;
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.MarkerChart
 * JD-Core Version:    0.7.0.1
 */
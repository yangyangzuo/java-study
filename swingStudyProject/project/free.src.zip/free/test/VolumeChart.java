/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import twaver.chart.LineChart;
/*  4:   */ 
/*  5:   */ public class VolumeChart
/*  6:   */   extends LineChart
/*  7:   */ {
/*  8:   */   public VolumeChart()
/*  9:   */   {
/* 10: 9 */     setEnableYTranslate(false);
/* 11:10 */     setEnableYZoom(false);
/* 12:11 */     setLineType(3);
/* 13:12 */     setLowerLimit(0.0D);
/* 14:13 */     setXScaleTextSpanCount(30);
/* 15:14 */     setXScaleTextOrientation(4);
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.VolumeChart
 * JD-Core Version:    0.7.0.1
 */
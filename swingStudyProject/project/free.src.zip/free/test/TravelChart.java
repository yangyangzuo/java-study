/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.event.ItemEvent;
/*  6:   */ import java.awt.event.ItemListener;
/*  7:   */ import javax.swing.JComboBox;
/*  8:   */ import javax.swing.JToolBar;
/*  9:   */ import twaver.Element;
/* 10:   */ import twaver.Node;
/* 11:   */ import twaver.TDataBox;
/* 12:   */ import twaver.chart.BarChart;
/* 13:   */ 
/* 14:   */ public class TravelChart
/* 15:   */   extends Portlet
/* 16:   */ {
/* 17:19 */   private TDataBox box = new TDataBox();
/* 18:20 */   private BarChart chart = new BarChart(this.box);
/* 19:   */   
/* 20:   */   public TravelChart()
/* 21:   */   {
/* 22:23 */     super.initialize(this.chart);
/* 23:24 */     this.chart.setTitle("Travel expenditure on legisure trips");
/* 24:25 */     this.chart.setBarType(4);
/* 25:26 */     this.chart.setShadowOffset(0);
/* 26:27 */     this.chart.setSelectedOffset(0);
/* 27:28 */     this.chart.setXScaleTextOrientation(4);
/* 28:29 */     this.chart.setXScaleTextColor(Color.CYAN.darker());
/* 29:   */     
/* 30:31 */     this.chart.addXScaleText("Europe");
/* 31:32 */     this.chart.addXScaleText("Oceania");
/* 32:33 */     this.chart.addXScaleText("North America");
/* 33:34 */     this.chart.addXScaleText("<html>Africa<br>Central America<br>South America</html>");
/* 34:35 */     this.chart.addXScaleText("<html>HK<br>Macao</html>");
/* 35:36 */     this.chart.addXScaleText("Other Asian regions");
/* 36:   */     
/* 37:38 */     Element before = new Node();
/* 38:39 */     Element total = new Node();
/* 39:   */     
/* 40:41 */     before.putChartColor(new Color(102, 153, 255).darker());
/* 41:42 */     total.putChartColor(new Color(102, 153, 255));
/* 42:   */     
/* 43:44 */     before.setName("Before the trip");
/* 44:45 */     total.setName("Total");
/* 45:   */     
/* 46:47 */     before.putChartValueTextPosition(1);
/* 47:   */     
/* 48:49 */     before.addChartValue(2108.0D);
/* 49:50 */     before.addChartValue(2369.0D);
/* 50:51 */     before.addChartValue(1475.0D);
/* 51:52 */     before.addChartValue(1826.0D);
/* 52:53 */     before.addChartValue(459.0D);
/* 53:54 */     before.addChartValue(821.0D);
/* 54:   */     
/* 55:56 */     total.addChartValue(5253.0D);
/* 56:57 */     total.addChartValue(4978.0D);
/* 57:58 */     total.addChartValue(3786.0D);
/* 58:59 */     total.addChartValue(2991.0D);
/* 59:60 */     total.addChartValue(2185.0D);
/* 60:61 */     total.addChartValue(1904.0D);
/* 61:   */     
/* 62:63 */     this.box.addElement(before);
/* 63:64 */     this.box.addElement(total);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public JToolBar getControlPanel()
/* 67:   */   {
/* 68:69 */     JToolBar toolbar = super.getControlPanel();
/* 69:70 */     final JComboBox comboBox = new JComboBox();
/* 70:71 */     comboBox.setPreferredSize(new Dimension(comboBox.getPreferredSize().width, 20));
/* 71:72 */     comboBox.addItem("Group");
/* 72:73 */     comboBox.addItem("Stack");
/* 73:74 */     comboBox.addItem("Layer");
/* 74:75 */     comboBox.addItem("PerCent");
/* 75:76 */     comboBox.setSelectedIndex(2);
/* 76:77 */     comboBox.addItemListener(new ItemListener()
/* 77:   */     {
/* 78:   */       public void itemStateChanged(ItemEvent e)
/* 79:   */       {
/* 80:80 */         if (comboBox.getSelectedItem().toString().equals("Group")) {
/* 81:81 */           TravelChart.this.chart.setBarType(2);
/* 82:82 */         } else if (comboBox.getSelectedItem().toString().equals("Stack")) {
/* 83:83 */           TravelChart.this.chart.setBarType(3);
/* 84:84 */         } else if (comboBox.getSelectedItem().toString().equals("Layer")) {
/* 85:85 */           TravelChart.this.chart.setBarType(4);
/* 86:86 */         } else if (comboBox.getSelectedItem().toString().equals("PerCent")) {
/* 87:87 */           TravelChart.this.chart.setBarType(5);
/* 88:   */         }
/* 89:   */       }
/* 90:90 */     });
/* 91:91 */     toolbar.add(comboBox);
/* 92:   */     
/* 93:93 */     return toolbar;
/* 94:   */   }
/* 95:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.TravelChart
 * JD-Core Version:    0.7.0.1
 */
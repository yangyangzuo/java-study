/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.GridLayout;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.text.NumberFormat;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.swing.JOptionPane;
/*  12:    */ import javax.swing.JPanel;
/*  13:    */ import javax.swing.SwingUtilities;
/*  14:    */ import twaver.Element;
/*  15:    */ import twaver.MouseActionEvent;
/*  16:    */ import twaver.TWaverConst;
/*  17:    */ import twaver.chart.AbstractChart;
/*  18:    */ 
/*  19:    */ public class CompositionDemo
/*  20:    */   extends JPanel
/*  21:    */   implements PortletPanel
/*  22:    */ {
/*  23: 21 */   private List chartList = new ArrayList();
/*  24: 22 */   private MarkerChart markerChart = new MarkerChart();
/*  25: 23 */   private JapanChart japanChart = new JapanChart();
/*  26: 24 */   private TravelChart travelChart = new TravelChart();
/*  27: 25 */   private AdoptionChart adoptionChart = new AdoptionChart();
/*  28: 26 */   private ShareChart shareChart = new ShareChart();
/*  29: 27 */   private MobileChart mobileChart = new MobileChart();
/*  30: 28 */   private HealthChart healthChart = new HealthChart();
/*  31: 29 */   private WeatherChart weatherChart = new WeatherChart();
/*  32: 30 */   private ClockChart clockChart = new ClockChart();
/*  33: 31 */   private GridLayout layout = new GridLayout();
/*  34: 32 */   private boolean isFullScreen = false;
/*  35: 33 */   ActionListener listener = new ActionListener()
/*  36:    */   {
/*  37:    */     public void actionPerformed(ActionEvent e)
/*  38:    */     {
/*  39: 36 */       MouseActionEvent event = (MouseActionEvent)e;
/*  40: 37 */       Element element = (Element)event.getSource();
/*  41: 38 */       int index = event.getIndex();
/*  42: 39 */       Component comp = (Component)event.getView();
/*  43:    */       
/*  44: 41 */       Double value = (Double)element.getClientProperty("chart.value");
/*  45:    */       String message;
/*  46:    */       String message;
/*  47: 42 */       if (value == null)
/*  48:    */       {
/*  49:    */         String message;
/*  50: 43 */         if (index < 0) {
/*  51: 44 */           message = element.getName();
/*  52:    */         } else {
/*  53: 46 */           message = element.getName() + "," + element.getChartValues().get(index);
/*  54:    */         }
/*  55:    */       }
/*  56:    */       else
/*  57:    */       {
/*  58: 49 */         message = element.getName() + "," + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(value.doubleValue());
/*  59:    */       }
/*  60: 51 */       JOptionPane.showMessageDialog(comp, message);
/*  61:    */     }
/*  62:    */   };
/*  63:    */   
/*  64:    */   public void initialize()
/*  65:    */   {
/*  66: 56 */     int size = this.chartList.size();
/*  67: 57 */     setLayout(this.layout);
/*  68: 58 */     for (int i = 0; i < size; i++) {
/*  69: 59 */       add((Portlet)this.chartList.get(i));
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void fullScreen(Portlet portlet)
/*  74:    */   {
/*  75: 64 */     removeAll();
/*  76: 65 */     this.isFullScreen = (!this.isFullScreen);
/*  77: 66 */     if (this.isFullScreen)
/*  78:    */     {
/*  79: 67 */       setLayout(new BorderLayout());
/*  80: 68 */       add(portlet, "Center");
/*  81:    */     }
/*  82:    */     else
/*  83:    */     {
/*  84: 70 */       initialize();
/*  85:    */     }
/*  86: 72 */     portlet.getChart().reset();
/*  87: 73 */     repaint();
/*  88: 74 */     revalidate();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public CompositionDemo()
/*  92:    */   {
/*  93: 78 */     this.layout.setColumns(3);
/*  94: 79 */     this.layout.setHgap(3);
/*  95: 80 */     this.layout.setRows(3);
/*  96: 81 */     this.layout.setVgap(3);
/*  97:    */     
/*  98: 83 */     this.chartList.add(this.markerChart);
/*  99: 84 */     this.chartList.add(this.japanChart);
/* 100: 85 */     this.chartList.add(this.travelChart);
/* 101: 86 */     this.chartList.add(this.adoptionChart);
/* 102: 87 */     this.chartList.add(this.shareChart);
/* 103: 88 */     this.chartList.add(this.mobileChart);
/* 104: 89 */     this.chartList.add(this.healthChart);
/* 105: 90 */     this.chartList.add(this.weatherChart);
/* 106: 91 */     this.chartList.add(this.clockChart);
/* 107: 92 */     int size = this.chartList.size();
/* 108: 93 */     for (int i = 0; i < size; i++) {
/* 109: 94 */       ((Portlet)this.chartList.get(i)).getChart().addElementDoubleClickedActionListener(this.listener);
/* 110:    */     }
/* 111: 96 */     initialize();
/* 112:    */     
/* 113: 98 */     Thread t = new Thread(new Runnable()
/* 114:    */     {
/* 115:    */       public void run()
/* 116:    */       {
/* 117:    */         try
/* 118:    */         {
/* 119:    */           for (;;)
/* 120:    */           {
/* 121:103 */             if (CompositionDemo.this.isShowing()) {
/* 122:104 */               SwingUtilities.invokeAndWait(new Runnable()
/* 123:    */               {
/* 124:    */                 public void run()
/* 125:    */                 {
/* 126:107 */                   int size = CompositionDemo.this.chartList.size();
/* 127:108 */                   for (int i = 0; i < size; i++) {
/* 128:109 */                     ((Portlet)CompositionDemo.this.chartList.get(i)).run();
/* 129:    */                   }
/* 130:    */                 }
/* 131:    */               });
/* 132:    */             }
/* 133:114 */             Thread.sleep(150L);
/* 134:    */           }
/* 135:    */         }
/* 136:    */         catch (Exception e) {}
/* 137:    */       }
/* 138:119 */     });
/* 139:120 */     t.start();
/* 140:    */   }
/* 141:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.CompositionDemo
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.awt.event.ActionListener;
/*  7:   */ import javax.swing.JCheckBox;
/*  8:   */ import javax.swing.JPanel;
/*  9:   */ import javax.swing.JToolBar;
/* 10:   */ import twaver.Element;
/* 11:   */ import twaver.Node;
/* 12:   */ import twaver.TDataBox;
/* 13:   */ import twaver.chart.BarChart;
/* 14:   */ 
/* 15:   */ public class JapanChart
/* 16:   */   extends Portlet
/* 17:   */ {
/* 18:19 */   private Element subOfTotal = new Node();
/* 19:20 */   private Element subOf3G = new Node();
/* 20:21 */   private TDataBox box = new TDataBox();
/* 21:22 */   private BarChart chart = new BarChart(this.box);
/* 22:   */   
/* 23:   */   public JapanChart()
/* 24:   */   {
/* 25:25 */     super.initialize(this.chart);
/* 26:26 */     this.chart.setBarType(2);
/* 27:27 */     this.chart.setTitle("<html>Japan's cellular subs & 3G penetration<br><center>by carrier,2005(millions)</center></html>");
/* 28:28 */     this.chart.setShadowOffset(10);
/* 29:29 */     this.chart.setYScaleTextVisible(true);
/* 30:30 */     this.chart.setYScaleMinTextVisible(true);
/* 31:31 */     this.chart.setUpperLimit(60.0D);
/* 32:32 */     this.chart.setYScaleValueGap(10.0D);
/* 33:   */     
/* 34:34 */     this.chart.addXScaleText("NTT DoCoMo");
/* 35:35 */     this.chart.addXScaleText("KDDI");
/* 36:36 */     this.chart.addXScaleText("Vodafone");
/* 37:   */     
/* 38:38 */     addElement(this.subOf3G, "3G subs", Color.GREEN.brighter());
/* 39:39 */     addElement(this.subOfTotal, "Total subs", Color.ORANGE.darker());
/* 40:   */     
/* 41:41 */     addValue(this.subOfTotal, 50.560000000000002D, 24.690000000000001D, 15.109999999999999D);
/* 42:42 */     addValue(this.subOf3G, 20.120000000000001D, 20.579999999999998D, 2.31D);
/* 43:   */   }
/* 44:   */   
/* 45:   */   private void addElement(Element element, String name, Color color)
/* 46:   */   {
/* 47:46 */     element.setName(name);
/* 48:47 */     element.putChartColor(color);
/* 49:48 */     this.box.addElement(element);
/* 50:   */   }
/* 51:   */   
/* 52:   */   private void addValue(Element element, double value1, double value2, double value3)
/* 53:   */   {
/* 54:52 */     element.addChartValue(value1);
/* 55:53 */     element.addChartValue(value2);
/* 56:54 */     element.addChartValue(value3);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public JToolBar getControlPanel()
/* 60:   */   {
/* 61:58 */     JToolBar toolbar = super.getControlPanel();
/* 62:59 */     final JCheckBox check = new JCheckBox("Legend Visble");
/* 63:60 */     check.setOpaque(false);
/* 64:61 */     check.setSelected(this.chart.getLegendPane().isVisible());
/* 65:62 */     check.setPreferredSize(new Dimension(check.getPreferredSize().width, 20));
/* 66:63 */     check.addActionListener(new ActionListener()
/* 67:   */     {
/* 68:   */       public void actionPerformed(ActionEvent e)
/* 69:   */       {
/* 70:66 */         JapanChart.this.chart.getLegendPane().setVisible(check.isSelected());
/* 71:   */       }
/* 72:68 */     });
/* 73:69 */     toolbar.add(check);
/* 74:70 */     return toolbar;
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.JapanChart
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Font;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.awt.event.ItemEvent;
/*   9:    */ import java.awt.event.ItemListener;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ import javax.swing.JCheckBox;
/*  13:    */ import javax.swing.JComboBox;
/*  14:    */ import javax.swing.JToolBar;
/*  15:    */ import twaver.Element;
/*  16:    */ import twaver.Node;
/*  17:    */ import twaver.TDataBox;
/*  18:    */ import twaver.chart.RadarChart;
/*  19:    */ 
/*  20:    */ public class WeatherChart
/*  21:    */   extends Portlet
/*  22:    */ {
/*  23: 25 */   private TDataBox box = new TDataBox();
/*  24: 26 */   private RadarChart chart = new RadarChart(this.box);
/*  25:    */   
/*  26:    */   public WeatherChart()
/*  27:    */   {
/*  28: 29 */     super.initialize(this.chart);
/*  29: 30 */     this.chart.setScaleMajorCount(5);
/*  30: 31 */     this.chart.setRingMinVisible(false);
/*  31: 32 */     this.chart.setShapeFillGradient(false);
/*  32: 33 */     this.chart.setRadarFillColor(new Color(50, 170, 160));
/*  33: 34 */     this.chart.setAxisTextFont(new Font("dialog", 0, 12));
/*  34: 35 */     this.chart.setScaleMajorCount(4);
/*  35: 36 */     this.chart.setTitle("Weather Status");
/*  36: 37 */     this.chart.setScaleMajorTextVisible(false);
/*  37:    */     
/*  38: 39 */     this.chart.addAxisText("Rainy");
/*  39: 40 */     this.chart.addAxisText("Snowy");
/*  40: 41 */     this.chart.addAxisText("Windy");
/*  41: 42 */     this.chart.addAxisText("Cloudy");
/*  42: 43 */     this.chart.addAxisText("Iced");
/*  43: 44 */     this.chart.addAxisText("Fine");
/*  44: 45 */     List janList = new ArrayList();
/*  45: 46 */     janList.add("0.1");
/*  46: 47 */     janList.add("0.4");
/*  47: 48 */     janList.add("0.6");
/*  48: 49 */     janList.add("0.4");
/*  49: 50 */     janList.add("0.5");
/*  50: 51 */     janList.add("0.2");
/*  51: 52 */     List febList = new ArrayList();
/*  52: 53 */     febList.add("0.4");
/*  53: 54 */     febList.add("0.2");
/*  54: 55 */     febList.add("0.5");
/*  55: 56 */     febList.add("0.6");
/*  56: 57 */     febList.add("0.2");
/*  57: 58 */     febList.add("0.5");
/*  58:    */     
/*  59: 60 */     this.chart.setScaleMaxValue(0.8D);
/*  60: 61 */     addElement("Jan.", Color.GREEN, 1, "solid.1", janList);
/*  61: 62 */     addElement("Feb.", Color.ORANGE, 1, "solid.1", febList);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void addElement(String name, Color color, int style, String stroke, List list)
/*  65:    */   {
/*  66: 66 */     Element element = new Node();
/*  67: 67 */     element.setName(name);
/*  68: 68 */     element.putChartColor(color);
/*  69: 69 */     element.putChartInflexionStyle(style);
/*  70: 70 */     element.putChartStroke(stroke);
/*  71: 71 */     int size = list.size();
/*  72: 72 */     for (int i = 0; i < size; i++) {
/*  73: 73 */       element.addChartValue(Double.valueOf(list.get(i).toString()).doubleValue());
/*  74:    */     }
/*  75: 75 */     this.box.addElement(element);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public JToolBar getControlPanel()
/*  79:    */   {
/*  80: 79 */     JToolBar toolbar = super.getControlPanel();
/*  81: 80 */     final JCheckBox checkBox = new JCheckBox("Fill");
/*  82: 81 */     checkBox.setPreferredSize(new Dimension(checkBox.getPreferredSize().width + 5, 20));
/*  83: 82 */     checkBox.setSelected(true);
/*  84: 83 */     checkBox.addActionListener(new ActionListener()
/*  85:    */     {
/*  86:    */       public void actionPerformed(ActionEvent e)
/*  87:    */       {
/*  88: 86 */         WeatherChart.this.chart.setAreaFill(checkBox.isSelected());
/*  89:    */       }
/*  90: 89 */     });
/*  91: 90 */     final JComboBox combobox = new JComboBox();
/*  92: 91 */     combobox.setPreferredSize(new Dimension(combobox.getPreferredSize().width, 20));
/*  93: 92 */     combobox.addItem("Line");
/*  94: 93 */     combobox.addItem("Ellipse");
/*  95: 94 */     combobox.addItemListener(new ItemListener()
/*  96:    */     {
/*  97:    */       public void itemStateChanged(ItemEvent e)
/*  98:    */       {
/*  99: 97 */         if (combobox.getSelectedItem().toString().equals("Line")) {
/* 100: 98 */           WeatherChart.this.chart.setRingStyle(1);
/* 101:    */         } else {
/* 102:100 */           WeatherChart.this.chart.setRingStyle(2);
/* 103:    */         }
/* 104:    */       }
/* 105:103 */     });
/* 106:104 */     toolbar.add(checkBox);
/* 107:105 */     toolbar.add(combobox);
/* 108:106 */     return toolbar;
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.WeatherChart
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import twaver.chart.LineChart;
/*  4:   */ 
/*  5:   */ public class RangeChart
/*  6:   */   extends LineChart
/*  7:   */ {
/*  8:   */   public RangeChart()
/*  9:   */   {
/* 10: 9 */     setEnableXTranslate(false);
/* 11:10 */     setEnableXZoom(false);
/* 12:11 */     setXScaleTextSpanCount(30);
/* 13:12 */     setXScaleTextOrientation(4);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.RangeChart
 * JD-Core Version:    0.7.0.1
 */
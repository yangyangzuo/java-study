/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.awt.event.ActionListener;
/*  7:   */ import javax.swing.JCheckBox;
/*  8:   */ import javax.swing.JToolBar;
/*  9:   */ import twaver.DataBoxSelectionModel;
/* 10:   */ import twaver.Element;
/* 11:   */ import twaver.Node;
/* 12:   */ import twaver.TDataBox;
/* 13:   */ import twaver.chart.PieChart;
/* 14:   */ 
/* 15:   */ public class ShareChart
/* 16:   */   extends Portlet
/* 17:   */ {
/* 18:19 */   private TDataBox box = new TDataBox();
/* 19:20 */   private PieChart chart = new PieChart(this.box);
/* 20:   */   
/* 21:   */   public ShareChart()
/* 22:   */   {
/* 23:23 */     super.initialize(this.chart);
/* 24:24 */     addElement("Sprint", 23.0D, Color.BLUE);
/* 25:25 */     addElement("Verizon", 26.0D, Color.YELLOW);
/* 26:26 */     addElement("AT&T", 26.0D, Color.GREEN);
/* 27:27 */     addElement("T-Mobile", 11.0D, Color.MAGENTA);
/* 28:28 */     addElement("Alltel", 5.0D, Color.CYAN);
/* 29:29 */     addElement("Rest", 9.0D, Color.RED);
/* 30:   */     
/* 31:31 */     this.chart.setTitle("US Carrier Market Share");
/* 32:32 */     this.chart.setLegendOrientation(4);
/* 33:33 */     this.chart.setHollow(true);
/* 34:34 */     this.chart.set3D(true);
/* 35:   */   }
/* 36:   */   
/* 37:   */   private void addElement(String name, double value, Color color)
/* 38:   */   {
/* 39:38 */     Element element = new Node();
/* 40:39 */     element.setName(name);
/* 41:40 */     element.putChartValue(value);
/* 42:41 */     element.putChartColor(color);
/* 43:42 */     this.box.addElement(element);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public JToolBar getControlPanel()
/* 47:   */   {
/* 48:46 */     JToolBar toolbar = super.getControlPanel();
/* 49:47 */     toolbar.add(getRunButton());
/* 50:48 */     final JCheckBox percentage = new JCheckBox("Percentage");
/* 51:49 */     percentage.setPreferredSize(new Dimension(percentage.getPreferredSize().width, 20));
/* 52:50 */     percentage.addActionListener(new ActionListener()
/* 53:   */     {
/* 54:   */       public void actionPerformed(ActionEvent e)
/* 55:   */       {
/* 56:53 */         ShareChart.this.chart.setValueTextPercent(percentage.isSelected());
/* 57:   */       }
/* 58:56 */     });
/* 59:57 */     final JCheckBox hollow = new JCheckBox("Hollow");
/* 60:58 */     hollow.setPreferredSize(new Dimension(hollow.getPreferredSize().width, 20));
/* 61:59 */     hollow.setSelected(true);
/* 62:60 */     hollow.addActionListener(new ActionListener()
/* 63:   */     {
/* 64:   */       public void actionPerformed(ActionEvent e)
/* 65:   */       {
/* 66:63 */         ShareChart.this.chart.setHollow(hollow.isSelected());
/* 67:   */       }
/* 68:66 */     });
/* 69:67 */     final JCheckBox is3d = new JCheckBox("3D", false);
/* 70:68 */     is3d.setPreferredSize(new Dimension(is3d.getPreferredSize().width, 20));
/* 71:69 */     is3d.addActionListener(new ActionListener()
/* 72:   */     {
/* 73:   */       public void actionPerformed(ActionEvent e)
/* 74:   */       {
/* 75:72 */         ShareChart.this.chart.set3D(is3d.isSelected());
/* 76:   */       }
/* 77:74 */     });
/* 78:75 */     is3d.setSelected(true);
/* 79:   */     
/* 80:77 */     toolbar.add(percentage);
/* 81:78 */     toolbar.add(hollow);
/* 82:79 */     toolbar.add(is3d);
/* 83:80 */     return toolbar;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public void run()
/* 87:   */   {
/* 88:84 */     if ((this.box.getSelectionModel().size() == 0) && (isRunning())) {
/* 89:85 */       this.chart.setStartAngle(this.chart.getStartAngle() + 1.0D);
/* 90:   */     }
/* 91:   */   }
/* 92:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.ShareChart
 * JD-Core Version:    0.7.0.1
 */
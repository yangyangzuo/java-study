/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Point;
/*  4:   */ import java.beans.PropertyChangeEvent;
/*  5:   */ import java.beans.PropertyChangeListener;
/*  6:   */ import twaver.network.TNetwork;
/*  7:   */ 
/*  8:   */ public class PropertyChangeProcessor
/*  9:   */   implements PropertyChangeListener
/* 10:   */ {
/* 11:   */   TNetwork network;
/* 12:   */   
/* 13:   */   public PropertyChangeProcessor(TNetwork network)
/* 14:   */   {
/* 15:21 */     this.network = network;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void propertyChange(PropertyChangeEvent evt)
/* 19:   */   {
/* 20:25 */     if (!(evt.getSource() instanceof StateNode)) {
/* 21:26 */       return;
/* 22:   */     }
/* 23:28 */     StateNode node = (StateNode)evt.getSource();
/* 24:29 */     String name = evt.getPropertyName();
/* 25:31 */     if (name.equals("selected")) {
/* 26:32 */       if (node.containsAttachment("population")) {
/* 27:33 */         node.removeAttachment("population");
/* 28:   */       } else {
/* 29:35 */         node.addAttachment("population");
/* 30:   */       }
/* 31:   */     }
/* 32:39 */     if ((name.equals("selected")) || (name.equals("location")))
/* 33:   */     {
/* 34:41 */       Point location = node.getCenterLocation();
/* 35:42 */       Point center = this.network.getLogicalCenterPoint();
/* 36:43 */       if ((location.x > center.x) && (location.y < center.y)) {
/* 37:44 */         node.setAttachmentDirection(3);
/* 38:46 */       } else if ((location.x > center.x) && (location.y > center.y)) {
/* 39:47 */         node.setAttachmentDirection(1);
/* 40:49 */       } else if ((location.x < center.x) && (location.y < center.y)) {
/* 41:50 */         node.setAttachmentDirection(4);
/* 42:   */       } else {
/* 43:53 */         node.setAttachmentDirection(2);
/* 44:   */       }
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.PropertyChangeProcessor
 * JD-Core Version:    0.7.0.1
 */
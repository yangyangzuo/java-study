package free.test;

public abstract interface PortletPanel
{
  public abstract void fullScreen(Portlet paramPortlet);
}


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.PortletPanel
 * JD-Core Version:    0.7.0.1
 */
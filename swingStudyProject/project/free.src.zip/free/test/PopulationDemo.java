/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.event.KeyAdapter;
/*   7:    */ import java.awt.event.KeyEvent;
/*   8:    */ import java.text.NumberFormat;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.swing.BorderFactory;
/*  12:    */ import javax.swing.JCheckBox;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JInternalFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JLayeredPane;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ import javax.swing.JSlider;
/*  19:    */ import javax.swing.JTextField;
/*  20:    */ import javax.swing.JToolBar;
/*  21:    */ import javax.swing.event.ChangeEvent;
/*  22:    */ import javax.swing.event.ChangeListener;
/*  23:    */ import twaver.DataBoxQuickFinder;
/*  24:    */ import twaver.DataBoxSelectionModel;
/*  25:    */ import twaver.Element;
/*  26:    */ import twaver.ElementCallbackHandler;
/*  27:    */ import twaver.MovableFilter;
/*  28:    */ import twaver.TDataBox;
/*  29:    */ import twaver.TUIManager;
/*  30:    */ import twaver.TWaverConst;
/*  31:    */ import twaver.VisibleFilter;
/*  32:    */ import twaver.network.TNetwork;
/*  33:    */ import twaver.network.background.ImageBackground;
/*  34:    */ import twaver.swing.TableLayout;
/*  35:    */ 
/*  36:    */ public class PopulationDemo
/*  37:    */   extends JPanel
/*  38:    */ {
/*  39:    */   static
/*  40:    */   {
/*  41: 36 */     TUIManager.registerAttachment("population", PopulationAttachment.class);
/*  42:    */   }
/*  43:    */   
/*  44: 38 */   TDataBox box = new TDataBox();
/*  45: 39 */   TNetwork network = new TNetwork(this.box);
/*  46: 40 */   DataBoxQuickFinder finder = this.box.createJavaBeanFinder("name");
/*  47: 41 */   ImageBackground background = new ImageBackground("/free/test/usa.gif");
/*  48:    */   
/*  49:    */   public PopulationDemo()
/*  50:    */   {
/*  51: 44 */     setLayout(new BorderLayout());
/*  52: 45 */     add(this.network, "Center");
/*  53: 46 */     this.network.getToolbar().setBorder(null);
/*  54:    */     try
/*  55:    */     {
/*  56: 50 */       this.box.parse("/free/test/population.xml");
/*  57:    */     }
/*  58:    */     catch (Exception ex)
/*  59:    */     {
/*  60: 52 */       ex.printStackTrace();
/*  61:    */     }
/*  62: 56 */     this.background.setTextureURL("/free/test/background.png");
/*  63: 57 */     this.network.setBackground(this.background);
/*  64:    */     
/*  65: 59 */     createInternalFrame("ControlPane", this.network, createControlPane());
/*  66:    */     
/*  67: 61 */     this.box.addElementPropertyChangeListener(new PropertyChangeProcessor(this.network));
/*  68:    */     
/*  69:    */ 
/*  70: 64 */     init("Alabama", 4447100.0D, 4527166.0D, 4596330.0D, 4663111.0D, 4728915.0D, 4800092.0D, 4874243.0D);
/*  71: 65 */     init("Alaska", 626932.0D, 661110.0D, 694109.0D, 732544.0D, 774421.0D, 820881.0D, 867674.0D);
/*  72: 66 */     init("Arizona", 5130632.0D, 5868004.0D, 6637381.0D, 7495238.0D, 8456448.0D, 9531537.0D, 10712397.0D);
/*  73: 67 */     init("Arkansas", 2673400.0D, 2777007.0D, 2875039.0D, 2968913.0D, 3060219.0D, 3151005.0D, 3240208.0D);
/*  74: 68 */     init("California", 33871648.0D, 36038859.0D, 38067134.0D, 40123232.0D, 42206743.0D, 44305177.0D, 46444861.0D);
/*  75: 69 */     init("Colorado", 4301261.0D, 4617962.0D, 4831554.0D, 5049493.0D, 5278867.0D, 5522803.0D, 5792357.0D);
/*  76: 70 */     init("Connecticut", 3405565.0D, 3503185.0D, 3577490.0D, 3635414.0D, 3675650.0D, 3691016.0D, 3688630.0D);
/*  77: 71 */     init("Delaware", 783600.0D, 836687.0D, 884342.0D, 927400.0D, 963209.0D, 990694.0D, 1012658.0D);
/*  78: 72 */     init("Dist of Columbia", 572059.0D, 551136.0D, 529785.0D, 506323.0D, 480540.0D, 455108.0D, 433414.0D);
/*  79: 73 */     init("Florida", 15982378.0D, 17509827.0D, 19251691.0D, 21204132.0D, 23406525.0D, 25912458.0D, 28685769.0D);
/*  80: 74 */     init("Georgia", 8186453.0D, 8925796.0D, 9589080.0D, 10230578.0D, 10843753.0D, 11438622.0D, 12017838.0D);
/*  81: 75 */     init("Hawaii", 1211537.0D, 1276552.0D, 1340674.0D, 1385952.0D, 1412373.0D, 1438720.0D, 1466046.0D);
/*  82: 76 */     init("Idaho", 1293953.0D, 1407060.0D, 1517291.0D, 1630045.0D, 1741333.0D, 1852627.0D, 1969624.0D);
/*  83: 77 */     init("Illinois", 12419293.0D, 12699336.0D, 12916894.0D, 13097218.0D, 13236720.0D, 13340507.0D, 13432892.0D);
/*  84: 78 */     init("Indiana", 6080485.0D, 6249617.0D, 6392139.0D, 6517631.0D, 6627008.0D, 6721322.0D, 6810108.0D);
/*  85: 79 */     init("Iowa", 2926324.0D, 2973700.0D, 3009907.0D, 3026380.0D, 3020496.0D, 2993222.0D, 2955172.0D);
/*  86: 80 */     init("Kansas", 2688418.0D, 2751509.0D, 2805470.0D, 2852690.0D, 2890566.0D, 2919002.0D, 2940084.0D);
/*  87: 81 */     init("Kentucky", 4041769.0D, 4163360.0D, 4265117.0D, 4351188.0D, 4424431.0D, 4489662.0D, 4554998.0D);
/*  88: 82 */     init("Louisiana", 4468976.0D, 4534310.0D, 4612679.0D, 4673721.0D, 4719160.0D, 4762398.0D, 4802633.0D);
/*  89: 83 */     init("Maine", 1274923.0D, 1318557.0D, 1357134.0D, 1388878.0D, 1408665.0D, 1414402.0D, 1411097.0D);
/*  90: 84 */     init("Maryland", 5296486.0D, 5600563.0D, 5904970.0D, 6208392.0D, 6497626.0D, 6762732.0D, 7022251.0D);
/*  91: 85 */     init("Mass", 6349097.0D, 6518868.0D, 6649441.0D, 6758580.0D, 6855546.0D, 6938636.0D, 7012009.0D);
/*  92: 86 */     init("Michigan", 9938444.0D, 10207421.0D, 10428683.0D, 10599122.0D, 10695993.0D, 10713730.0D, 10694172.0D);
/*  93: 87 */     init("Minnesota", 4919479.0D, 5174743.0D, 5420636.0D, 5668211.0D, 5900769.0D, 6108787.0D, 6306130.0D);
/*  94: 88 */     init("Mississippi", 2844658.0D, 2915696.0D, 2971412.0D, 3014409.0D, 3044812.0D, 3069420.0D, 3092410.0D);
/*  95: 89 */     init("Missouri", 5595211.0D, 5765166.0D, 5922078.0D, 6069556.0D, 6199882.0D, 6315366.0D, 6430173.0D);
/*  96: 90 */     init("Montana", 902195.0D, 933005.0D, 968598.0D, 999489.0D, 1022735.0D, 1037387.0D, 1044898.0D);
/*  97: 91 */     init("Nebraska", 1711263.0D, 1744370.0D, 1768997.0D, 1788508.0D, 1802678.0D, 1812787.0D, 1820247.0D);
/*  98: 92 */     init("Nevada", 1998257.0D, 2352086.0D, 2690531.0D, 3058190.0D, 3452283.0D, 3863298.0D, 4282102.0D);
/*  99: 93 */     init("New Hampshire", 1235786.0D, 1314821.0D, 1385560.0D, 1456679.0D, 1524751.0D, 1586348.0D, 1646471.0D);
/* 100: 94 */     init("New Jersey", 8414350.0D, 8745279.0D, 9018231.0D, 9255769.0D, 9461635.0D, 9636644.0D, 9802440.0D);
/* 101: 95 */     init("New Mexico", 1819046.0D, 1902057.0D, 1980225.0D, 2041539.0D, 2084341.0D, 2106584.0D, 2099708.0D);
/* 102: 96 */     init("New York", 18976457.0D, 19258082.0D, 19443672.0D, 19546699.0D, 19576920.0D, 19540179.0D, 19477429.0D);
/* 103: 97 */     init("North Carolina", 8049313.0D, 8702410.0D, 9345823.0D, 10010770.0D, 10709289.0D, 11449153.0D, 12227739.0D);
/* 104: 98 */     init("North Dakota", 642200.0D, 635468.0D, 636623.0D, 635133.0D, 630112.0D, 620777.0D, 606566.0D);
/* 105: 99 */     init("Ohio", 11353140.0D, 11477557.0D, 11576181.0D, 11635446.0D, 11644058.0D, 11605738.0D, 11550528.0D);
/* 106:100 */     init("Oklahoma", 3450654.0D, 3521379.0D, 3591516.0D, 3661694.0D, 3735690.0D, 3820994.0D, 3913251.0D);
/* 107:101 */     init("Oregon", 3421399.0D, 3596083.0D, 3790996.0D, 4012924.0D, 4260393.0D, 4536418.0D, 4833918.0D);
/* 108:102 */     init("Pennsylvania", 12281054.0D, 12426603.0D, 12584487.0D, 12710938.0D, 12787354.0D, 12801945.0D, 12768184.0D);
/* 109:103 */     init("Rhode Island", 1048319.0D, 1086575.0D, 1116652.0D, 1139543.0D, 1154230.0D, 1157855.0D, 1152941.0D);
/* 110:104 */     init("South Carolina", 4012012.0D, 4239310.0D, 4446704.0D, 4642137.0D, 4822577.0D, 4989550.0D, 5148569.0D);
/* 111:105 */     init("South Dakota", 754844.0D, 771803.0D, 786399.0D, 796954.0D, 801939.0D, 801845.0D, 800462.0D);
/* 112:106 */     init("Tennessee", 5689283.0D, 5965317.0D, 6230852.0D, 6502017.0D, 6780670.0D, 7073125.0D, 7380634.0D);
/* 113:107 */     init("Texas", 20851820.0D, 22775044.0D, 24648888.0D, 26585801.0D, 28634896.0D, 30865134.0D, 33317744.0D);
/* 114:108 */     init("Utah", 2233169.0D, 2417998.0D, 2595013.0D, 2783040.0D, 2990094.0D, 3225680.0D, 3485367.0D);
/* 115:109 */     init("Vermont", 608827.0D, 630979.0D, 652512.0D, 673169.0D, 690686.0D, 703288.0D, 711867.0D);
/* 116:110 */     init("Virginia", 7078515.0D, 7552581.0D, 8010245.0D, 8466864.0D, 8917395.0D, 9364304.0D, 9825019.0D);
/* 117:111 */     init("Washington", 5894121.0D, 6204632.0D, 6541963.0D, 6950610.0D, 7432136.0D, 7996400.0D, 8624801.0D);
/* 118:112 */     init("West Virginia", 1808344.0D, 1818887.0D, 1829141.0D, 1822758.0D, 1801112.0D, 1766435.0D, 1719959.0D);
/* 119:113 */     init("Wisconsin", 5363675.0D, 5554343.0D, 5727426.0D, 5882760.0D, 6004954.0D, 6088374.0D, 6150764.0D);
/* 120:114 */     init("Wyoming", 493782.0D, 507268.0D, 519886.0D, 528005.0D, 530948.0D, 529031.0D, 522979.0D);
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static JInternalFrame createInternalFrame(String title, TNetwork network, JComponent mainPane)
/* 124:    */   {
/* 125:119 */     JInternalFrame frame = new JInternalFrame();
/* 126:120 */     frame.getContentPane().add(mainPane);
/* 127:121 */     frame.setTitle(title);
/* 128:122 */     frame.pack();
/* 129:123 */     frame.setLocation(30, 30);
/* 130:124 */     frame.setVisible(true);
/* 131:125 */     network.getLayeredPane().add(frame, 0);
/* 132:126 */     return frame;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private JPanel createControlPane()
/* 136:    */   {
/* 137:130 */     final JTextField quickSearch = new JTextField();
/* 138:131 */     final JSlider pSlider = new JSlider(0, 35, 0);
/* 139:132 */     final JLabel pLabel = new JLabel(pSlider.getValue() + "  million");
/* 140:133 */     final JSlider bSlider = new JSlider(0, 100, 100);
/* 141:134 */     final JLabel bLabel = new JLabel("background 1");
/* 142:135 */     final JSlider eSlider = new JSlider(0, 100, 100);
/* 143:136 */     final JLabel eLabel = new JLabel("element 1");
/* 144:137 */     final JCheckBox movable = new JCheckBox("Enable Moving Node");
/* 145:    */     
/* 146:139 */     pSlider.setPaintLabels(true);
/* 147:140 */     pSlider.setPaintTicks(true);
/* 148:141 */     pSlider.setMinorTickSpacing(1);
/* 149:142 */     pSlider.setMajorTickSpacing(5);
/* 150:143 */     pSlider.setSnapToTicks(true);
/* 151:    */     
/* 152:145 */     double[] rows = { -2.0D, -2.0D, -2.0D, -2.0D, -2.0D };
/* 153:146 */     double[] columns = { -2.0D, -1.0D };
/* 154:    */     
/* 155:148 */     TableLayout layout = new TableLayout(columns, rows);
/* 156:149 */     layout.setVGap(2);
/* 157:150 */     layout.setHGap(2);
/* 158:151 */     JPanel controlPane = new JPanel(layout);
/* 159:152 */     controlPane.add(new JLabel("Quick Search"), "0,0");
/* 160:153 */     controlPane.add(quickSearch, "1,0");
/* 161:154 */     controlPane.add(pLabel, "0,1");
/* 162:155 */     controlPane.add(pSlider, "1,1");
/* 163:156 */     controlPane.add(bLabel, "0,2");
/* 164:157 */     controlPane.add(bSlider, "1,2");
/* 165:158 */     controlPane.add(eLabel, "0,3");
/* 166:159 */     controlPane.add(eSlider, "1,3");
/* 167:160 */     controlPane.add(movable, "1,4");
/* 168:161 */     controlPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/* 169:    */     
/* 170:163 */     quickSearch.addKeyListener(new KeyAdapter()
/* 171:    */     {
/* 172:    */       public void keyReleased(KeyEvent e)
/* 173:    */       {
/* 174:166 */         PopulationDemo.this.box.getSelectionModel().clearSelection();
/* 175:167 */         final String text = quickSearch.getText();
/* 176:168 */         if ((text != null) && (!text.trim().equals("")))
/* 177:    */         {
/* 178:169 */           final List elements = new ArrayList();
/* 179:170 */           PopulationDemo.this.box.iterator(new ElementCallbackHandler()
/* 180:    */           {
/* 181:    */             public boolean processElement(Element element)
/* 182:    */             {
/* 183:173 */               String name = element.getName();
/* 184:174 */               if ((name != null) && (PopulationDemo.this.network.isVisible(element)) && (name.toLowerCase().indexOf(text.toLowerCase()) >= 0)) {
/* 185:175 */                 elements.add(element);
/* 186:    */               }
/* 187:177 */               return true;
/* 188:    */             }
/* 189:179 */           });
/* 190:180 */           PopulationDemo.this.box.getSelectionModel().setSelection(elements);
/* 191:    */         }
/* 192:    */       }
/* 193:184 */     });
/* 194:185 */     this.network.addVisibleFilter(new VisibleFilter()
/* 195:    */     {
/* 196:    */       public boolean isVisible(Element element)
/* 197:    */       {
/* 198:188 */         if ((element instanceof StateNode))
/* 199:    */         {
/* 200:189 */           StateNode node = (StateNode)element;
/* 201:190 */           return node.getC2000() > pSlider.getValue() * 1000000;
/* 202:    */         }
/* 203:192 */         return true;
/* 204:    */       }
/* 205:195 */     });
/* 206:196 */     this.network.addMovableFilter(new MovableFilter()
/* 207:    */     {
/* 208:    */       public boolean isMovable(Element element)
/* 209:    */       {
/* 210:199 */         return movable.isSelected();
/* 211:    */       }
/* 212:201 */     });
/* 213:202 */     pSlider.addChangeListener(new ChangeListener()
/* 214:    */     {
/* 215:    */       public void stateChanged(ChangeEvent e)
/* 216:    */       {
/* 217:205 */         pLabel.setText(pSlider.getValue() + "  million");
/* 218:206 */         PopulationDemo.this.network.getCanvas().repaint();
/* 219:    */       }
/* 220:208 */     });
/* 221:209 */     eSlider.addChangeListener(new ChangeListener()
/* 222:    */     {
/* 223:    */       public void stateChanged(ChangeEvent e)
/* 224:    */       {
/* 225:212 */         eLabel.setText("element " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(eSlider.getValue() / 100.0F));
/* 226:213 */         final Float alpha = new Float(eSlider.getValue() / 100.0F);
/* 227:214 */         PopulationDemo.this.box.iterator(new ElementCallbackHandler()
/* 228:    */         {
/* 229:    */           public boolean processElement(Element element)
/* 230:    */           {
/* 231:217 */             element.putClientProperty("render.alpha", alpha);
/* 232:218 */             return true;
/* 233:    */           }
/* 234:    */         });
/* 235:    */       }
/* 236:222 */     });
/* 237:223 */     bSlider.addChangeListener(new ChangeListener()
/* 238:    */     {
/* 239:    */       public void stateChanged(ChangeEvent e)
/* 240:    */       {
/* 241:226 */         bLabel.setText("background " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(bSlider.getValue() / 100.0F));
/* 242:227 */         PopulationDemo.this.background.setAlpha(bSlider.getValue() / 100.0F);
/* 243:228 */         PopulationDemo.this.network.getCanvas().repaint();
/* 244:    */       }
/* 245:231 */     });
/* 246:232 */     return controlPane;
/* 247:    */   }
/* 248:    */   
/* 249:    */   private void init(String stateName, double c2000, double p2005, double p2010, double p2015, double p2020, double p2025, double p2030)
/* 250:    */   {
/* 251:236 */     StateNode node = (StateNode)this.finder.findFirst(stateName);
/* 252:237 */     node.putChartColor(Color.ORANGE);
/* 253:238 */     node.putChartInflexionStyle(1);
/* 254:239 */     node.init(c2000, p2005, p2010, p2015, p2020, p2025, p2030);
/* 255:    */   }
/* 256:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.PopulationDemo
 * JD-Core Version:    0.7.0.1
 */
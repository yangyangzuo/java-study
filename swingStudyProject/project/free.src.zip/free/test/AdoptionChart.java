/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.awt.event.ActionListener;
/*  7:   */ import java.awt.event.ItemEvent;
/*  8:   */ import java.awt.event.ItemListener;
/*  9:   */ import javax.swing.JCheckBox;
/* 10:   */ import javax.swing.JComboBox;
/* 11:   */ import javax.swing.JLabel;
/* 12:   */ import javax.swing.JToolBar;
/* 13:   */ import twaver.Element;
/* 14:   */ import twaver.Node;
/* 15:   */ import twaver.TDataBox;
/* 16:   */ import twaver.chart.BarChart;
/* 17:   */ 
/* 18:   */ public class AdoptionChart
/* 19:   */   extends Portlet
/* 20:   */ {
/* 21:23 */   private TDataBox box = new TDataBox();
/* 22:24 */   private BarChart chart = new BarChart(this.box);
/* 23:   */   
/* 24:   */   public AdoptionChart()
/* 25:   */   {
/* 26:27 */     super.initialize(this.chart);
/* 27:28 */     this.chart.setTitle("Enterprise 2.0 Adoption");
/* 28:29 */     this.chart.setYAxisText("<html>North American and European IT<br>decision-makers at enterprises and SMBs</html>");
/* 29:30 */     this.chart.setBarType(5);
/* 30:31 */     this.chart.addXScaleText("Small");
/* 31:32 */     this.chart.addXScaleText("Medium-Small");
/* 32:33 */     this.chart.addXScaleText("Medium-Large");
/* 33:34 */     this.chart.addXScaleText("Large");
/* 34:35 */     this.chart.addXScaleText("Very-Large");
/* 35:36 */     this.chart.addXScaleText("Global2000");
/* 36:37 */     this.chart.setValueTextCenter(true);
/* 37:38 */     addElement("Not Considering", 0.6800000000000001D, 0.58D, 0.52D, 0.44D, 0.44D, 0.37D, Color.GREEN.darker().darker());
/* 38:39 */     addElement("Considering Only", 0.12D, 0.16D, 0.15D, 0.15D, 0.16D, 0.12D, Color.GREEN.darker());
/* 39:40 */     addElement("Buying", 0.2D, 0.26D, 0.33D, 0.41D, 0.4D, 0.51D, Color.GREEN);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void addElement(String name, double v1, double v2, double v3, double v4, double v5, double v6, Color color)
/* 43:   */   {
/* 44:44 */     Element node = new Node();
/* 45:45 */     node.putChartColor(color);
/* 46:46 */     node.setName(name);
/* 47:47 */     node.addChartValue(v1);
/* 48:48 */     node.addChartValue(v2);
/* 49:49 */     node.addChartValue(v3);
/* 50:50 */     node.addChartValue(v4);
/* 51:51 */     node.addChartValue(v5);
/* 52:52 */     node.addChartValue(v6);
/* 53:53 */     this.box.addElement(node);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public JToolBar getControlPanel()
/* 57:   */   {
/* 58:57 */     JToolBar toolbar = super.getControlPanel();
/* 59:58 */     final JCheckBox checkBox = new JCheckBox("Value");
/* 60:59 */     checkBox.setPreferredSize(new Dimension(checkBox.getPreferredSize().width + 5, 20));
/* 61:60 */     checkBox.addActionListener(new ActionListener()
/* 62:   */     {
/* 63:   */       public void actionPerformed(ActionEvent e)
/* 64:   */       {
/* 65:63 */         AdoptionChart.this.chart.setPercentTypeValueVisible(checkBox.isSelected());
/* 66:   */       }
/* 67:65 */     });
/* 68:66 */     toolbar.add(checkBox);
/* 69:67 */     JLabel label = new JLabel("Bundle:");
/* 70:68 */     toolbar.add(label);
/* 71:69 */     final JComboBox combobox = new JComboBox();
/* 72:70 */     combobox.setPreferredSize(new Dimension(combobox.getPreferredSize().width, 20));
/* 73:71 */     combobox.setLightWeightPopupEnabled(true);
/* 74:72 */     combobox.addItem("1");
/* 75:73 */     combobox.addItem("2");
/* 76:74 */     combobox.addItem("3");
/* 77:75 */     toolbar.add(combobox);
/* 78:76 */     combobox.addItemListener(new ItemListener()
/* 79:   */     {
/* 80:   */       public void itemStateChanged(ItemEvent e)
/* 81:   */       {
/* 82:79 */         AdoptionChart.this.chart.setBundleSize(new Integer(combobox.getSelectedItem().toString()).intValue());
/* 83:   */       }
/* 84:81 */     });
/* 85:82 */     return toolbar;
/* 86:   */   }
/* 87:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.AdoptionChart
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free.test;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.event.ActionEvent;
/*   5:    */ import java.awt.event.ActionListener;
/*   6:    */ import javax.swing.JButton;
/*   7:    */ import javax.swing.JFileChooser;
/*   8:    */ import javax.swing.JPanel;
/*   9:    */ import javax.swing.JToolBar;
/*  10:    */ import twaver.TWaverConst;
/*  11:    */ import twaver.TWaverUtil;
/*  12:    */ import twaver.chart.AbstractChart;
/*  13:    */ import twaver.swing.TExpandPane;
/*  14:    */ 
/*  15:    */ public abstract class Portlet
/*  16:    */   extends JPanel
/*  17:    */   implements Runnable
/*  18:    */ {
/*  19: 19 */   private boolean running = true;
/*  20:    */   private static JFileChooser chooser;
/*  21:    */   private AbstractChart chart;
/*  22:    */   
/*  23:    */   public void initialize(AbstractChart chart)
/*  24:    */   {
/*  25: 24 */     this.chart = chart;
/*  26: 25 */     JToolBar toolbar = getControlPanel();
/*  27: 26 */     TExpandPane searchPopup = new TExpandPane(toolbar, 2, true, false);
/*  28:    */     
/*  29: 28 */     setLayout(new BorderLayout());
/*  30: 29 */     add(chart, "Center");
/*  31: 30 */     add(searchPopup, "South");
/*  32:    */   }
/*  33:    */   
/*  34:    */   public AbstractChart getChart()
/*  35:    */   {
/*  36: 34 */     return this.chart;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public JToolBar getControlPanel()
/*  40:    */   {
/*  41: 38 */     JToolBar toolbar = new JToolBar();
/*  42: 39 */     toolbar.setRollover(true);
/*  43: 40 */     toolbar.setFloatable(false);
/*  44:    */     
/*  45: 42 */     JButton export = createButton("/resource/image/network/exportToImage.png");
/*  46: 43 */     export.addActionListener(new ActionListener()
/*  47:    */     {
/*  48:    */       public void actionPerformed(ActionEvent e)
/*  49:    */       {
/*  50: 46 */         if (Portlet.chooser == null) {
/*  51: 47 */           Portlet.access$002(TWaverUtil.createImageFileChooser());
/*  52:    */         }
/*  53: 49 */         Portlet.this.chart.exportImage(Portlet.chooser, true);
/*  54:    */       }
/*  55: 51 */     });
/*  56: 52 */     toolbar.add(export);
/*  57:    */     
/*  58: 54 */     JButton zoomIn = createButton("/resource/image/network/zoomIn.png");
/*  59: 55 */     zoomIn.addActionListener(new ActionListener()
/*  60:    */     {
/*  61:    */       public void actionPerformed(ActionEvent e)
/*  62:    */       {
/*  63: 58 */         Portlet.this.chart.zoomIn();
/*  64:    */       }
/*  65: 60 */     });
/*  66: 61 */     toolbar.add(zoomIn);
/*  67:    */     
/*  68: 63 */     JButton zoomOut = createButton("/resource/image/network/zoomOut.png");
/*  69: 64 */     zoomOut.addActionListener(new ActionListener()
/*  70:    */     {
/*  71:    */       public void actionPerformed(ActionEvent e)
/*  72:    */       {
/*  73: 67 */         Portlet.this.chart.zoomOut();
/*  74:    */       }
/*  75: 69 */     });
/*  76: 70 */     toolbar.add(zoomOut);
/*  77:    */     
/*  78: 72 */     JButton reset = createButton("/resource/image/network/zoomReset.png");
/*  79: 73 */     reset.addActionListener(new ActionListener()
/*  80:    */     {
/*  81:    */       public void actionPerformed(ActionEvent e)
/*  82:    */       {
/*  83: 76 */         Portlet.this.chart.reset();
/*  84:    */       }
/*  85: 78 */     });
/*  86: 79 */     toolbar.add(reset);
/*  87:    */     
/*  88: 81 */     JButton fullScreen = createButton("/resource/image/network/fullScreen.png");
/*  89: 82 */     fullScreen.addActionListener(new ActionListener()
/*  90:    */     {
/*  91:    */       public void actionPerformed(ActionEvent e)
/*  92:    */       {
/*  93: 85 */         PortletPanel container = (PortletPanel)Portlet.this.getParent();
/*  94: 86 */         container.fullScreen(Portlet.this);
/*  95:    */       }
/*  96: 88 */     });
/*  97: 89 */     toolbar.add(fullScreen);
/*  98: 90 */     return toolbar;
/*  99:    */   }
/* 100:    */   
/* 101:    */   private JButton createButton(String icon)
/* 102:    */   {
/* 103: 94 */     JButton button = new JButton(TWaverUtil.getIcon(icon));
/* 104: 95 */     button.setMargin(TWaverConst.NONE_INSETS);
/* 105: 96 */     return button;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public JButton getRunButton()
/* 109:    */   {
/* 110:100 */     final JButton button = createButton("/free/test/stop.gif");
/* 111:101 */     button.setMargin(TWaverConst.NONE_INSETS);
/* 112:102 */     button.addActionListener(new ActionListener()
/* 113:    */     {
/* 114:    */       public void actionPerformed(ActionEvent e)
/* 115:    */       {
/* 116:105 */         if (Portlet.this.isRunning())
/* 117:    */         {
/* 118:106 */           Portlet.this.stopRun();
/* 119:107 */           button.setIcon(TWaverUtil.getIcon("/free/test/start.gif"));
/* 120:    */         }
/* 121:    */         else
/* 122:    */         {
/* 123:109 */           Portlet.this.startRun();
/* 124:110 */           button.setIcon(TWaverUtil.getIcon("/free/test/stop.gif"));
/* 125:    */         }
/* 126:    */       }
/* 127:113 */     });
/* 128:114 */     return button;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void startRun()
/* 132:    */   {
/* 133:118 */     this.running = true;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public void stopRun()
/* 137:    */   {
/* 138:122 */     this.running = false;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean isRunning()
/* 142:    */   {
/* 143:126 */     return this.running;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void run() {}
/* 147:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.Portlet
 * JD-Core Version:    0.7.0.1
 */
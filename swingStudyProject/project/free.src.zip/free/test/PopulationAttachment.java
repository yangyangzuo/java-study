/*  1:   */ package free.test;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.text.NumberFormat;
/*  5:   */ import java.util.Vector;
/*  6:   */ import twaver.TWaverConst;
/*  7:   */ import twaver.TWaverUtil;
/*  8:   */ import twaver.chart.BarChart;
/*  9:   */ import twaver.chart.Item;
/* 10:   */ import twaver.network.ui.ComponentAttachment;
/* 11:   */ import twaver.network.ui.ElementUI;
/* 12:   */ 
/* 13:   */ public class PopulationAttachment
/* 14:   */   extends ComponentAttachment
/* 15:   */ {
/* 16:23 */   private static final Color bodyColor = new Color(0, 0, 0, 168);
/* 17:24 */   private static final Color gradientColor = new Color(25, 255, 255, 108);
/* 18:   */   private static BarChart bar;
/* 19:   */   private static Item c2000;
/* 20:   */   private static Item p2005;
/* 21:   */   private static Item p2010;
/* 22:   */   private static Item p2015;
/* 23:   */   private static Item p2020;
/* 24:   */   private static Item p2025;
/* 25:   */   private static Item p2030;
/* 26:   */   
/* 27:   */   static
/* 28:   */   {
/* 29:36 */     Vector items = new Vector();
/* 30:37 */     items.add(PopulationAttachment.c2000 = new Item("Census April 1, 2000", new Color(255, 0, 255)));
/* 31:38 */     items.add(PopulationAttachment.p2005 = new Item("Projections July 1, 2005", new Color(220, 0, 255)));
/* 32:39 */     items.add(PopulationAttachment.p2010 = new Item("Projections July 1, 2010", new Color(170, 0, 255)));
/* 33:40 */     items.add(PopulationAttachment.p2015 = new Item("Projections July 1, 2015", new Color(130, 0, 255)));
/* 34:41 */     items.add(PopulationAttachment.p2020 = new Item("Projections July 1, 2020", new Color(100, 0, 255)));
/* 35:42 */     items.add(PopulationAttachment.p2025 = new Item("Projections July 1, 2025", new Color(70, 0, 255)));
/* 36:43 */     items.add(PopulationAttachment.p2030 = new Item("Projections July 1, 2030", new Color(40, 0, 255)));
/* 37:44 */     bar = new BarChart(items, null, Color.BLACK);
/* 38:45 */     bar.setLegendLayout(2);
/* 39:46 */     bar.setValueTextVisible(false);
/* 40:47 */     bar.setForeground(Color.WHITE);
/* 41:48 */     bar.setLegendFont(TWaverUtil.getFont(2, 9.0F));
/* 42:49 */     bar.setYAxisOutlineColor(Color.WHITE);
/* 43:50 */     bar.setXAxisOutlineColor(Color.WHITE);
/* 44:51 */     bar.setOpaque(false);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public PopulationAttachment(String name, ElementUI ui)
/* 48:   */   {
/* 49:55 */     super(name, ui);
/* 50:56 */     setStyle(2);
/* 51:57 */     setPosition(1);
/* 52:58 */     setBorderVisible(true);
/* 53:59 */     setBorderColor(Color.BLACK);
/* 54:60 */     setBodyVisible(true);
/* 55:61 */     setBodyGradient(true);
/* 56:62 */     setBodyColor(bodyColor);
/* 57:63 */     setBodyGradientColor(gradientColor);
/* 58:64 */     setBodyGradientType(7);
/* 59:65 */     setBorderColor(Color.RED);
/* 60:66 */     setBorderVisible(false);
/* 61:67 */     setStyle(2);
/* 62:68 */     setComponent(bar);
/* 63:69 */     setWidth(200);
/* 64:70 */     setHeight(100);
/* 65:   */   }
/* 66:   */   
/* 67:   */   protected void update()
/* 68:   */   {
/* 69:74 */     updateAttachment();
/* 70:75 */     invalidate();
/* 71:76 */     super.update();
/* 72:   */   }
/* 73:   */   
/* 74:   */   private void updateAttachment()
/* 75:   */   {
/* 76:80 */     StateNode node = (StateNode)this.element;
/* 77:   */     
/* 78:82 */     setDirection(node.getAttachmentDirection());
/* 79:   */     
/* 80:84 */     c2000.setValue(node.getC2000());
/* 81:85 */     p2005.setValue(node.getP2005());
/* 82:86 */     p2010.setValue(node.getP2010());
/* 83:87 */     p2015.setValue(node.getP2015());
/* 84:88 */     p2020.setValue(node.getP2020());
/* 85:89 */     p2025.setValue(node.getP2025());
/* 86:90 */     p2030.setValue(node.getP2030());
/* 87:   */     
/* 88:92 */     c2000.setName("2000 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(c2000.getValue()));
/* 89:93 */     p2005.setName("2005 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2005.getValue()));
/* 90:94 */     p2010.setName("2010 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2010.getValue()));
/* 91:95 */     p2015.setName("2015 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2015.getValue()));
/* 92:96 */     p2020.setName("2020 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2020.getValue()));
/* 93:97 */     p2025.setName("2025 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2025.getValue()));
/* 94:98 */     p2030.setName("2030 > " + TWaverConst.DEFAULT_DOUBLE_FORMATER.format(p2030.getValue()));
/* 95:   */   }
/* 96:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.test.PopulationAttachment
 * JD-Core Version:    0.7.0.1
 */
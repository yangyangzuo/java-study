/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ import javax.swing.JPanel;
/*  6:   */ 
/*  7:   */ public class FreePagePane
/*  8:   */   extends JPanel
/*  9:   */ {
/* 10: 9 */   private FreeToolBar leftToolbar = new FreeToolBar();
/* 11:10 */   private FreeToolBar rightToolbar = new FreeToolBar();
/* 12:11 */   private JPanel toolbarPane = new JPanel(new BorderLayout());
/* 13:12 */   private JPanel centerPane = new JPanel(new BorderLayout());
/* 14:   */   
/* 15:   */   public FreePagePane()
/* 16:   */   {
/* 17:15 */     this(null);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public FreePagePane(JComponent contentComponent)
/* 21:   */   {
/* 22:19 */     init(contentComponent);
/* 23:   */   }
/* 24:   */   
/* 25:   */   private void init(JComponent contentComponent)
/* 26:   */   {
/* 27:23 */     setLayout(new BorderLayout());
/* 28:   */     
/* 29:25 */     this.toolbarPane.add(this.leftToolbar, "Center");
/* 30:26 */     this.toolbarPane.add(this.rightToolbar, "East");
/* 31:27 */     add(this.toolbarPane, "North");
/* 32:28 */     add(this.centerPane, "Center");
/* 33:29 */     if (contentComponent != null) {
/* 34:30 */       this.centerPane.add(contentComponent, "Center");
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public JPanel getCenterPane()
/* 39:   */   {
/* 40:35 */     return this.centerPane;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public FreeToolBar getLeftToolBar()
/* 44:   */   {
/* 45:39 */     return this.leftToolbar;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public FreeToolBar getRightToolBar()
/* 49:   */   {
/* 50:43 */     return this.rightToolbar;
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreePagePane
 * JD-Core Version:    0.7.0.1
 */
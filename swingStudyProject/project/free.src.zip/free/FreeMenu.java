/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Graphics2D;
/*  7:   */ import javax.swing.BorderFactory;
/*  8:   */ import javax.swing.JMenu;
/*  9:   */ import javax.swing.border.Border;
/* 10:   */ 
/* 11:   */ public class FreeMenu
/* 12:   */   extends JMenu
/* 13:   */ {
/* 14:13 */   private Color backgroundColor = FreeUtil.MENUITEM_BACKGROUND;
/* 15:14 */   private Color foregroundColor = FreeUtil.DEFAULT_TEXT_COLOR;
/* 16:15 */   private int borderThickness = 1;
/* 17:16 */   private Border border = BorderFactory.createLineBorder(this.backgroundColor, this.borderThickness);
/* 18:17 */   private int preferredHeight = 25;
/* 19:   */   
/* 20:   */   public FreeMenu()
/* 21:   */   {
/* 22:20 */     init();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public FreeMenu(String text)
/* 26:   */   {
/* 27:24 */     super(text);
/* 28:25 */     init();
/* 29:   */   }
/* 30:   */   
/* 31:   */   private void init()
/* 32:   */   {
/* 33:29 */     setForeground(this.foregroundColor);
/* 34:30 */     setFont(FreeUtil.FONT_14_BOLD);
/* 35:31 */     setOpaque(true);
/* 36:32 */     setBackground(this.backgroundColor);
/* 37:33 */     setBorder(this.border);
/* 38:   */   }
/* 39:   */   
/* 40:   */   protected void paintComponent(Graphics g)
/* 41:   */   {
/* 42:39 */     if (isSelected())
/* 43:   */     {
/* 44:40 */       Graphics2D g2d = (Graphics2D)g;
/* 45:41 */       g2d.setColor(FreeUtil.MENUITEM_SELECTED_BACKGROUND);
/* 46:42 */       g2d.fillRect(0, 0, getWidth(), getHeight());
/* 47:43 */       super.paintComponent(g);
/* 48:   */     }
/* 49:   */     else
/* 50:   */     {
/* 51:45 */       super.paintComponent(g);
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public Dimension getPreferredSize()
/* 56:   */   {
/* 57:51 */     return new Dimension(super.getPreferredSize().width, this.preferredHeight);
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeMenu
 * JD-Core Version:    0.7.0.1
 */
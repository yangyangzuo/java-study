/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.AlphaComposite;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Graphics2D;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.awt.image.BufferedImage;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import java.net.URL;
/*  12:    */ import javax.swing.ImageIcon;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JScrollPane;
/*  15:    */ import javax.swing.SwingUtilities;
/*  16:    */ import twaver.DataBoxAdapter;
/*  17:    */ import twaver.DataBoxEvent;
/*  18:    */ import twaver.DataBoxSelectionEvent;
/*  19:    */ import twaver.DataBoxSelectionListener;
/*  20:    */ import twaver.DataBoxSelectionModel;
/*  21:    */ import twaver.Element;
/*  22:    */ import twaver.Generator;
/*  23:    */ import twaver.MovableFilter;
/*  24:    */ import twaver.Node;
/*  25:    */ import twaver.SelectableFilter;
/*  26:    */ import twaver.TDataBox;
/*  27:    */ import twaver.TWaverUtil;
/*  28:    */ import twaver.network.TNetwork;
/*  29:    */ import twaver.network.background.ColorBackground;
/*  30:    */ 
/*  31:    */ public class FreeNetwork
/*  32:    */   extends TNetwork
/*  33:    */ {
/*  34: 31 */   private Color canvasColor = FreeUtil.NETWORK_BACKGROUND;
/*  35: 32 */   private int shadowSize = 6;
/*  36: 33 */   private float shadowOpacity = 0.3F;
/*  37:    */   
/*  38:    */   public FreeNetwork()
/*  39:    */   {
/*  40: 36 */     init();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public FreeNetwork(TDataBox box)
/*  44:    */   {
/*  45: 40 */     super(box);
/*  46: 41 */     init();
/*  47:    */   }
/*  48:    */   
/*  49:    */   private void init()
/*  50:    */   {
/*  51: 45 */     setToolbar(null);
/*  52: 46 */     setBorder(null);
/*  53: 47 */     getCanvasScrollPane().setBorder(null);
/*  54: 48 */     setNetworkBackground(new ColorBackground(this.canvasColor));
/*  55: 49 */     addMovableFilter(new MovableFilter()
/*  56:    */     {
/*  57:    */       public boolean isMovable(Element elmnt)
/*  58:    */       {
/*  59: 52 */         return false;
/*  60:    */       }
/*  61: 55 */     });
/*  62: 56 */     getDataBox().getSelectionModel().addDataBoxSelectionListener(new DataBoxSelectionListener()
/*  63:    */     {
/*  64: 58 */       private boolean adjusting = false;
/*  65:    */       
/*  66:    */       public void selectionChanged(DataBoxSelectionEvent e)
/*  67:    */       {
/*  68: 61 */         if (this.adjusting) {
/*  69: 62 */           return;
/*  70:    */         }
/*  71: 64 */         if (FreeNetwork.this.getDataBox().getSelectionModel().size() > 1) {
/*  72: 65 */           SwingUtilities.invokeLater(new Runnable()
/*  73:    */           {
/*  74:    */             public void run()
/*  75:    */             {
/*  76: 68 */               if (FreeNetwork.this.getDataBox().getSelectionModel().size() > 1)
/*  77:    */               {
/*  78: 69 */                 FreeNetwork.2.this.adjusting = true;
/*  79: 70 */                 FreeNetwork.this.getDataBox().getSelectionModel().setSelection(FreeNetwork.this.getDataBox().getSelectionModel().lastElement());
/*  80: 71 */                 FreeNetwork.2.this.adjusting = false;
/*  81:    */               }
/*  82:    */             }
/*  83:    */           });
/*  84:    */         }
/*  85:    */       }
/*  86: 77 */     });
/*  87: 78 */     addSelectableFilter(new SelectableFilter()
/*  88:    */     {
/*  89:    */       public boolean isSelectable(Element element)
/*  90:    */       {
/*  91: 81 */         return element instanceof FreeNode;
/*  92:    */       }
/*  93: 84 */     });
/*  94: 85 */     getDataBox().addDataBoxListener(new DataBoxAdapter()
/*  95:    */     {
/*  96:    */       public void elementAdded(DataBoxEvent e)
/*  97:    */       {
/*  98: 89 */         Element element = e.getElement();
/*  99: 90 */         if ((element instanceof Node))
/* 100:    */         {
/* 101: 91 */           Node node = (Node)element;
/* 102: 92 */           FreeNetwork.this.updateShadow(node);
/* 103: 94 */           if ((element instanceof FreeNode))
/* 104:    */           {
/* 105: 95 */             FreeNode freeNode = (FreeNode)element;
/* 106: 96 */             FreeNodeButtonAttachment attachment = freeNode.getButtonAttachment();
/* 107: 97 */             if (attachment != null)
/* 108:    */             {
/* 109: 98 */               FreeNetwork.this.getCanvas().add(attachment);
/* 110: 99 */               attachment.updateBounds();
/* 111:    */             }
/* 112:    */           }
/* 113:    */         }
/* 114:    */       }
/* 115:    */       
/* 116:    */       public void elementRemoved(DataBoxEvent e)
/* 117:    */       {
/* 118:107 */         Element element = e.getElement();
/* 119:108 */         if ((element instanceof FreeNode))
/* 120:    */         {
/* 121:109 */           FreeNode freeNode = (FreeNode)element;
/* 122:110 */           JComponent attachment = freeNode.getButtonAttachment();
/* 123:111 */           if (attachment != null) {
/* 124:112 */             FreeNetwork.this.getCanvas().remove(attachment);
/* 125:    */           }
/* 126:    */         }
/* 127:    */       }
/* 128:118 */     });
/* 129:119 */     getDataBox().addElementPropertyChangeListener(new PropertyChangeListener()
/* 130:    */     {
/* 131:    */       public void propertyChange(PropertyChangeEvent evt)
/* 132:    */       {
/* 133:122 */         Object source = evt.getSource();
/* 134:123 */         if (((source instanceof FreeNode)) && 
/* 135:124 */           (TWaverUtil.getPropertyName(evt).equalsIgnoreCase("location")))
/* 136:    */         {
/* 137:125 */           FreeNode node = (FreeNode)source;
/* 138:126 */           FreeNodeButtonAttachment attachment = node.getButtonAttachment();
/* 139:127 */           attachment.updateBounds();
/* 140:    */         }
/* 141:    */       }
/* 142:132 */     });
/* 143:133 */     addCanvasCushion(new FreeNetworkShadowCushion(this));
/* 144:    */     
/* 145:    */ 
/* 146:136 */     setElementLabelGenerator(new Generator()
/* 147:    */     {
/* 148:    */       public Object generate(Object o)
/* 149:    */       {
/* 150:139 */         if ((o instanceof FreeNode))
/* 151:    */         {
/* 152:140 */           FreeNode node = (FreeNode)o;
/* 153:141 */           return node.getNetworkName();
/* 154:    */         }
/* 155:143 */         return ((Element)o).getName();
/* 156:    */       }
/* 157:148 */     });
/* 158:149 */     getDataBox().getSelectionModel().addDataBoxSelectionListener(new DataBoxSelectionListener()
/* 159:    */     {
/* 160:    */       public void selectionChanged(DataBoxSelectionEvent e)
/* 161:    */       {
/* 162:152 */         if (e.getBoxSelectionModel().size() == 1)
/* 163:    */         {
/* 164:153 */           Element element = e.getBoxSelectionModel().lastElement();
/* 165:154 */           if ((element instanceof FreeNode))
/* 166:    */           {
/* 167:155 */             FreeNode node = (FreeNode)element;
/* 168:156 */             ActionListener nodeAction = node.getAction();
/* 169:157 */             if (nodeAction != null)
/* 170:    */             {
/* 171:158 */               ActionEvent event = new ActionEvent(FreeNetwork.this, 0, null);
/* 172:159 */               nodeAction.actionPerformed(event);
/* 173:    */             }
/* 174:    */           }
/* 175:    */         }
/* 176:    */       }
/* 177:    */     });
/* 178:    */   }
/* 179:    */   
/* 180:    */   private void updateShadow(Node node)
/* 181:    */   {
/* 182:168 */     if (node != null)
/* 183:    */     {
/* 184:169 */       ImageIcon imageIcon = node.getImage();
/* 185:170 */       if (imageIcon != null)
/* 186:    */       {
/* 187:171 */         String urlString = node.getImageURL();
/* 188:172 */         URL url = getClass().getResource(urlString);
/* 189:    */         try
/* 190:    */         {
/* 191:174 */           BufferedImage imageSource = GraphicsUtilities.loadCompatibleImage(url);
/* 192:175 */           BufferedImage imageDest = FreeUtil.createDropShadow(imageSource, this.shadowSize);
/* 193:    */           
/* 194:177 */           BufferedImage imageShadow = new BufferedImage(imageDest.getWidth(), imageDest.getHeight(), 2);
/* 195:    */           
/* 196:    */ 
/* 197:180 */           Graphics2D g2d = imageShadow.createGraphics();
/* 198:181 */           g2d.setComposite(AlphaComposite.SrcOver.derive(this.shadowOpacity));
/* 199:182 */           g2d.drawImage(imageDest, 0, 0, null);
/* 200:183 */           g2d.dispose();
/* 201:    */           
/* 202:185 */           FreeUtil.setNodeShadowImage(node, imageShadow);
/* 203:    */         }
/* 204:    */         catch (Exception e)
/* 205:    */         {
/* 206:187 */           e.printStackTrace();
/* 207:    */         }
/* 208:    */       }
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   public int getShadowSize()
/* 213:    */   {
/* 214:194 */     return this.shadowSize;
/* 215:    */   }
/* 216:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeNetwork
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Container;
/*  5:   */ import java.awt.Cursor;
/*  6:   */ import java.awt.Dimension;
/*  7:   */ import java.awt.LayoutManager;
/*  8:   */ import java.awt.Rectangle;
/*  9:   */ import java.awt.event.ActionEvent;
/* 10:   */ import java.awt.event.ActionListener;
/* 11:   */ import javax.swing.BorderFactory;
/* 12:   */ import javax.swing.ImageIcon;
/* 13:   */ import javax.swing.border.Border;
/* 14:   */ 
/* 15:   */ public class FreeSearchTextField
/* 16:   */   extends FreeTextField
/* 17:   */ {
/* 18:17 */   private ImageIcon icon = FreeUtil.getImageIcon("textfield_search.png");
/* 19:18 */   private FreeToolbarRoverButton button = new FreeToolbarRoverButton(this.icon);
/* 20:19 */   private int buttonVGap = 2;
/* 21:20 */   private int buttonHGap = 4;
/* 22:21 */   private LayoutManager layout = new LayoutManager()
/* 23:   */   {
/* 24:   */     public void addLayoutComponent(String name, Component comp) {}
/* 25:   */     
/* 26:   */     public void removeLayoutComponent(Component comp) {}
/* 27:   */     
/* 28:   */     public Dimension preferredLayoutSize(Container parent)
/* 29:   */     {
/* 30:30 */       return null;
/* 31:   */     }
/* 32:   */     
/* 33:   */     public Dimension minimumLayoutSize(Container parent)
/* 34:   */     {
/* 35:34 */       return null;
/* 36:   */     }
/* 37:   */     
/* 38:   */     public void layoutContainer(Container parent)
/* 39:   */     {
/* 40:38 */       synchronized (parent.getTreeLock())
/* 41:   */       {
/* 42:39 */         Rectangle bound = FreeSearchTextField.this.getBounds();
/* 43:40 */         int x = bound.width - FreeSearchTextField.this.icon.getIconWidth() - FreeSearchTextField.this.buttonHGap * 2;
/* 44:41 */         int y = FreeSearchTextField.this.buttonVGap;
/* 45:42 */         int width = FreeSearchTextField.this.icon.getIconWidth() + FreeSearchTextField.this.buttonHGap * 2;
/* 46:43 */         int height = FreeSearchTextField.this.icon.getIconHeight() + FreeSearchTextField.this.buttonVGap * 2;
/* 47:44 */         FreeSearchTextField.this.button.setBounds(x, y, width, height);
/* 48:   */       }
/* 49:   */     }
/* 50:   */   };
/* 51:48 */   private Border border = BorderFactory.createEmptyBorder(1, 3, 1, this.icon.getIconWidth() + this.buttonHGap * 2);
/* 52:   */   
/* 53:   */   public FreeSearchTextField()
/* 54:   */   {
/* 55:51 */     init();
/* 56:   */   }
/* 57:   */   
/* 58:   */   private void init()
/* 59:   */   {
/* 60:55 */     setBorder(this.border);
/* 61:56 */     setLayout(this.layout);
/* 62:57 */     add(this.button);
/* 63:58 */     this.button.setCursor(Cursor.getDefaultCursor());
/* 64:59 */     this.button.setRoverBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
/* 65:60 */     this.button.setFocusable(false);
/* 66:61 */     this.button.addActionListener(new ActionListener()
/* 67:   */     {
/* 68:   */       public void actionPerformed(ActionEvent e)
/* 69:   */       {
/* 70:64 */         FreeSearchTextField.this.fireActionPerformed();
/* 71:   */       }
/* 72:   */     });
/* 73:   */   }
/* 74:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeSearchTextField
 * JD-Core Version:    0.7.0.1
 */
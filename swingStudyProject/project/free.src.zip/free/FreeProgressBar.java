/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Font;
/*   6:    */ import java.awt.FontMetrics;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.Graphics2D;
/*   9:    */ import java.awt.Image;
/*  10:    */ import java.awt.Paint;
/*  11:    */ import java.awt.Rectangle;
/*  12:    */ import java.awt.RenderingHints;
/*  13:    */ import java.awt.Shape;
/*  14:    */ import java.awt.TexturePaint;
/*  15:    */ import java.awt.geom.Area;
/*  16:    */ import java.awt.geom.Rectangle2D;
/*  17:    */ import java.awt.geom.RoundRectangle2D.Float;
/*  18:    */ import javax.swing.ImageIcon;
/*  19:    */ import javax.swing.JProgressBar;
/*  20:    */ import javax.swing.event.ChangeEvent;
/*  21:    */ import javax.swing.event.ChangeListener;
/*  22:    */ import twaver.TWaverConst;
/*  23:    */ import twaver.TWaverUtil;
/*  24:    */ 
/*  25:    */ public class FreeProgressBar
/*  26:    */   extends JProgressBar
/*  27:    */ {
/*  28: 26 */   private String selectedBackgroundImageURL = FreeUtil.getImageURL("progress_select_background.png");
/*  29: 27 */   private String unselectedBackgroundImageURL = FreeUtil.getImageURL("progress_unselect_background.png");
/*  30: 28 */   private ImageIcon selectedBackgroundImageIcon = TWaverUtil.getImageIcon(this.selectedBackgroundImageURL);
/*  31: 29 */   private Image selectedBackgroundLeft = FreeUtil.getImage("progress_selected_left.png");
/*  32: 30 */   private Image selectedBackgroundRight = FreeUtil.getImage("progress_selected_right.png");
/*  33: 31 */   private TexturePaint selectedPaint = FreeUtil.createTexturePaint(this.selectedBackgroundImageURL);
/*  34: 32 */   private TexturePaint unselectedPaint = FreeUtil.createTexturePaint(this.unselectedBackgroundImageURL);
/*  35: 33 */   private Color selectedBorderColor = new Color(233, 145, 17);
/*  36: 34 */   private Color unselectedBorderColor = new Color(105, 166, 44);
/*  37: 35 */   private int roundArc = 6;
/*  38: 36 */   private Font font = FreeUtil.FONT_12_BOLD;
/*  39:    */   
/*  40:    */   public FreeProgressBar()
/*  41:    */   {
/*  42: 39 */     this(0, 0, 100);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public FreeProgressBar(int min, int max)
/*  46:    */   {
/*  47: 43 */     this(0, min, max);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public FreeProgressBar(int value, int min, int max)
/*  51:    */   {
/*  52: 47 */     super(min, max);
/*  53: 48 */     setValue(value);
/*  54: 49 */     init();
/*  55:    */   }
/*  56:    */   
/*  57:    */   private void init()
/*  58:    */   {
/*  59: 53 */     setOpaque(false);
/*  60: 54 */     setBackground(Color.white);
/*  61: 55 */     setBorder(null);
/*  62: 56 */     setStringPainted(true);
/*  63: 57 */     setFont(this.font);
/*  64: 58 */     setForeground(FreeUtil.DEFAULT_TEXT_COLOR);
/*  65: 59 */     addChangeListener(new ChangeListener()
/*  66:    */     {
/*  67:    */       public void stateChanged(ChangeEvent e)
/*  68:    */       {
/*  69: 62 */         FreeProgressBar.this.updateString();
/*  70:    */       }
/*  71: 64 */     });
/*  72: 65 */     updateString();
/*  73:    */   }
/*  74:    */   
/*  75:    */   private void updateString()
/*  76:    */   {
/*  77: 69 */     int percent = getValue() * 100 / getMaximum();
/*  78: 70 */     setString(percent + "%, " + getValue() + "M/" + getMaximum() + "M");
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected void paintComponent(Graphics g)
/*  82:    */   {
/*  83: 75 */     Graphics2D g2d = (Graphics2D)g;
/*  84: 76 */     Object oldHint = g2d.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/*  85: 77 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  86:    */     
/*  87:    */ 
/*  88: 80 */     Shape allShape = getAllShape();
/*  89: 81 */     paintShape(g2d, allShape, allShape, this.unselectedPaint, this.unselectedBorderColor, null, null);
/*  90:    */     
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94: 86 */     Shape selectedShape = getSelectedShape();
/*  95: 87 */     paintShape(g2d, allShape, selectedShape, this.selectedPaint, this.selectedBorderColor, this.selectedBackgroundLeft, this.selectedBackgroundRight);
/*  96:    */     
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100: 92 */     g2d.setFont(getFont());
/* 101: 93 */     g2d.setColor(FreeUtil.DEFAULT_TEXT_COLOR);
/* 102: 94 */     Rectangle2D bounds = g2d.getFontMetrics().getStringBounds(getString(), g);
/* 103: 95 */     int x = (int)((getWidth() - bounds.getWidth()) / 2.0D);
/* 104: 96 */     int y = (int)((getHeight() - bounds.getHeight()) / 2.0D) + g2d.getFontMetrics().getAscent() + 1;
/* 105:    */     
/* 106: 98 */     g2d.drawString(getString(), x, y);
/* 107:    */     
/* 108:    */ 
/* 109:101 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, oldHint);
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void paintShape(Graphics2D g2d, Shape shape, Shape clip, Paint fillPaint, Color borderColor, Image leftImage, Image rightImage)
/* 113:    */   {
/* 114:107 */     Shape oldClip = g2d.getClip();
/* 115:108 */     if (clip != null) {
/* 116:109 */       g2d.setClip(clip);
/* 117:    */     }
/* 118:113 */     g2d.setPaint(fillPaint);
/* 119:114 */     g2d.fill(shape);
/* 120:115 */     if (leftImage != null) {
/* 121:116 */       g2d.drawImage(leftImage, 0, 0, null);
/* 122:    */     }
/* 123:118 */     if (rightImage != null)
/* 124:    */     {
/* 125:119 */       int x = getWidth() - rightImage.getWidth(null);
/* 126:120 */       int y = 0;
/* 127:121 */       g2d.drawImage(rightImage, x, y, this);
/* 128:    */     }
/* 129:124 */     g2d.setClip(oldClip);
/* 130:    */     
/* 131:    */ 
/* 132:127 */     g2d.setColor(borderColor);
/* 133:128 */     g2d.setStroke(TWaverConst.BASIC_STROKE);
/* 134:129 */     g2d.draw(clip);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public Dimension getPreferredSize()
/* 138:    */   {
/* 139:134 */     return new Dimension(super.getPreferredSize().width, this.selectedBackgroundImageIcon.getIconHeight());
/* 140:    */   }
/* 141:    */   
/* 142:    */   private Shape getSelectedShape()
/* 143:    */   {
/* 144:138 */     Shape round = getAllShape();
/* 145:139 */     double percent = getValue() / getMaximum();
/* 146:140 */     int x = (int)(getWidth() * percent);
/* 147:141 */     int y = 0;
/* 148:142 */     int width = getWidth() - x;
/* 149:143 */     int height = getHeight() - 1;
/* 150:144 */     Rectangle unselectedRect = new Rectangle(x, y, width, height);
/* 151:145 */     Area selectedShape = new Area(round);
/* 152:146 */     selectedShape.subtract(new Area(unselectedRect));
/* 153:147 */     return selectedShape;
/* 154:    */   }
/* 155:    */   
/* 156:    */   private Shape getAllShape()
/* 157:    */   {
/* 158:151 */     int width = getWidth() - 1;
/* 159:152 */     int height = getHeight() - 1;
/* 160:153 */     return new RoundRectangle2D.Float(0.0F, 0.0F, width, height, this.roundArc, this.roundArc);
/* 161:    */   }
/* 162:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeProgressBar
 * JD-Core Version:    0.7.0.1
 */
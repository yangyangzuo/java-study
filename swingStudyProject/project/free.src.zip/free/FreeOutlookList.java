/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import twaver.Element;
/*  4:   */ import twaver.TDataBox;
/*  5:   */ import twaver.VisibleFilter;
/*  6:   */ import twaver.list.TList;
/*  7:   */ 
/*  8:   */ public class FreeOutlookList
/*  9:   */   extends TList
/* 10:   */ {
/* 11:11 */   private FreeOutlookBar bar = null;
/* 12:   */   
/* 13:   */   public FreeOutlookList(FreeOutlookBar bar, TDataBox box)
/* 14:   */   {
/* 15:14 */     super(box);
/* 16:15 */     this.bar = bar;
/* 17:16 */     init();
/* 18:   */   }
/* 19:   */   
/* 20:   */   private void init()
/* 21:   */   {
/* 22:20 */     setCellRenderer(new FreeOutlookListRenderer(this));
/* 23:21 */     setFont(FreeUtil.FONT_12_BOLD);
/* 24:22 */     setForeground(FreeUtil.OUTLOOK_TEXT_COLOR);
/* 25:23 */     setSelectionMode(0);
/* 26:24 */     addVisibleFilter(new VisibleFilter()
/* 27:   */     {
/* 28:   */       public boolean isVisible(Element element)
/* 29:   */       {
/* 30:27 */         return element instanceof FreeNode;
/* 31:   */       }
/* 32:   */     });
/* 33:   */   }
/* 34:   */   
/* 35:   */   public FreeOutlookBar getFreeOutlookBar()
/* 36:   */   {
/* 37:33 */     return this.bar;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookList
 * JD-Core Version:    0.7.0.1
 */
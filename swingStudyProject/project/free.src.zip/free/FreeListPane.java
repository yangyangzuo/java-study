/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Cursor;
/*  6:   */ import java.awt.Dimension;
/*  7:   */ import java.awt.Graphics;
/*  8:   */ import java.awt.Insets;
/*  9:   */ import javax.swing.JPanel;
/* 10:   */ import javax.swing.border.Border;
/* 11:   */ 
/* 12:   */ public class FreeListPane
/* 13:   */   extends JPanel
/* 14:   */ {
/* 15:14 */   private FreeList list = new FreeList();
/* 16:15 */   private JPanel split = new JPanel(new BorderLayout());
/* 17:16 */   private FreeHeader header = new FreeHeader()
/* 18:   */   {
/* 19:   */     public void setShrink(boolean shrinked)
/* 20:   */     {
/* 21:20 */       super.setShrink(shrinked);
/* 22:22 */       if (shrinked) {
/* 23:23 */         FreeListPane.this.split.setCursor(Cursor.getDefaultCursor());
/* 24:   */       } else {
/* 25:25 */         FreeListPane.this.split.setCursor(Cursor.getPredefinedCursor(10));
/* 26:   */       }
/* 27:   */     }
/* 28:   */   };
/* 29:29 */   private FreeListSplitListener splitListener = new FreeListSplitListener(this.header);
/* 30:   */   
/* 31:   */   public FreeListPane()
/* 32:   */   {
/* 33:32 */     init();
/* 34:   */   }
/* 35:   */   
/* 36:   */   private void init()
/* 37:   */   {
/* 38:36 */     setLayout(new BorderLayout());
/* 39:   */     
/* 40:38 */     JPanel rightInsetPane = new JPanel();
/* 41:39 */     rightInsetPane.setPreferredSize(new Dimension(2, 0));
/* 42:40 */     rightInsetPane.setBackground(FreeUtil.LIST_BACKGROUND);
/* 43:41 */     add(rightInsetPane, "East");
/* 44:42 */     add(this.header, "North");
/* 45:   */     
/* 46:44 */     this.split.setBorder(new Border()
/* 47:   */     {
/* 48:   */       public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 49:   */       {
/* 50:47 */         g.setColor(FreeUtil.LIST_SPLIT_COLOR);
/* 51:48 */         g.drawLine(x, y, x, y + height);
/* 52:   */       }
/* 53:   */       
/* 54:   */       public Insets getBorderInsets(Component c)
/* 55:   */       {
/* 56:52 */         return new Insets(0, 1, 0, 0);
/* 57:   */       }
/* 58:   */       
/* 59:   */       public boolean isBorderOpaque()
/* 60:   */       {
/* 61:56 */         return true;
/* 62:   */       }
/* 63:58 */     });
/* 64:59 */     this.split.setOpaque(true);
/* 65:60 */     this.split.setPreferredSize(new Dimension(4, 0));
/* 66:61 */     this.split.setBackground(FreeUtil.LIST_BACKGROUND);
/* 67:62 */     this.split.setCursor(Cursor.getPredefinedCursor(10));
/* 68:63 */     this.split.addMouseListener(this.splitListener);
/* 69:64 */     this.split.addMouseMotionListener(this.splitListener);
/* 70:   */     
/* 71:66 */     add(this.split, "West");
/* 72:67 */     add(this.list, "Center");
/* 73:   */   }
/* 74:   */   
/* 75:   */   public FreeList getList()
/* 76:   */   {
/* 77:71 */     return this.list;
/* 78:   */   }
/* 79:   */   
/* 80:   */   public void setTitle(String title)
/* 81:   */   {
/* 82:75 */     this.header.setTitle(title);
/* 83:   */   }
/* 84:   */   
/* 85:   */   public String getTitle()
/* 86:   */   {
/* 87:79 */     return this.header.getTitle();
/* 88:   */   }
/* 89:   */   
/* 90:   */   public void setShrink(boolean shrinked)
/* 91:   */   {
/* 92:83 */     this.header.setShrink(shrinked);
/* 93:   */   }
/* 94:   */   
/* 95:   */   public boolean isShrinked()
/* 96:   */   {
/* 97:87 */     return this.header.isShrinked();
/* 98:   */   }
/* 99:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeListPane
 * JD-Core Version:    0.7.0.1
 */
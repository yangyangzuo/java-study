/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Graphics;
/*  4:   */ import java.awt.Graphics2D;
/*  5:   */ import java.awt.Image;
/*  6:   */ import java.awt.TexturePaint;
/*  7:   */ import javax.swing.JSeparator;
/*  8:   */ 
/*  9:   */ public class FreeSeparator
/* 10:   */   extends JSeparator
/* 11:   */ {
/* 12:11 */   private String imageName = "separator_background.png";
/* 13:12 */   private String backgroundImageURL = FreeUtil.getImageURL(this.imageName);
/* 14:13 */   private Image image = FreeUtil.getImage(this.imageName);
/* 15:14 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 16:   */   
/* 17:   */   public FreeSeparator() {}
/* 18:   */   
/* 19:   */   public FreeSeparator(int direction)
/* 20:   */   {
/* 21:20 */     super(direction);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void paintComponent(Graphics g)
/* 25:   */   {
/* 26:25 */     Graphics2D g2d = (Graphics2D)g;
/* 27:26 */     g2d.setPaint(this.paint);
/* 28:27 */     int x = 0;
/* 29:28 */     int y = 0;
/* 30:29 */     int width = getWidth();
/* 31:30 */     int height = this.image.getHeight(null);
/* 32:31 */     g2d.fillRect(x, y, width, height);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeSeparator
 * JD-Core Version:    0.7.0.1
 */
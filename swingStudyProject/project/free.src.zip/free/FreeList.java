/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import java.awt.event.MouseEvent;
/*  6:   */ import javax.swing.event.MouseInputAdapter;
/*  7:   */ import javax.swing.event.MouseInputListener;
/*  8:   */ import twaver.DataBoxSelectionModel;
/*  9:   */ import twaver.Element;
/* 10:   */ import twaver.Group;
/* 11:   */ import twaver.TDataBox;
/* 12:   */ import twaver.list.TList;
/* 13:   */ 
/* 14:   */ public class FreeList
/* 15:   */   extends TList
/* 16:   */ {
/* 17:   */   public FreeList()
/* 18:   */   {
/* 19:16 */     init();
/* 20:   */   }
/* 21:   */   
/* 22:   */   private void init()
/* 23:   */   {
/* 24:20 */     setFont(FreeUtil.FONT_12_BOLD);
/* 25:21 */     setForeground(FreeUtil.DEFAULT_TEXT_COLOR);
/* 26:22 */     setBackground(FreeUtil.LIST_BACKGROUND);
/* 27:23 */     setCellRenderer(new FreeListRenderer(this));
/* 28:24 */     setSelectionMode(0);
/* 29:   */     
/* 30:   */ 
/* 31:27 */     MouseInputListener mouseListener = new MouseInputAdapter()
/* 32:   */     {
/* 33:   */       public void mouseMoved(MouseEvent e)
/* 34:   */       {
/* 35:31 */         Element element = FreeList.this.getElementByPoint(e.getPoint());
/* 36:32 */         FreeList.this.getDataBox().getSelectionModel().clearSelection();
/* 37:33 */         if (element != null) {
/* 38:35 */           if (!(element instanceof Group)) {
/* 39:36 */             element.setSelected(true);
/* 40:   */           }
/* 41:   */         }
/* 42:   */       }
/* 43:   */       
/* 44:   */       public void mouseExited(MouseEvent e)
/* 45:   */       {
/* 46:43 */         FreeList.this.getDataBox().getSelectionModel().clearSelection();
/* 47:   */       }
/* 48:   */       
/* 49:   */       public void mouseClicked(MouseEvent e)
/* 50:   */       {
/* 51:48 */         Element element = FreeList.this.getDataBox().getSelectionModel().lastElement();
/* 52:49 */         if ((element != null) && 
/* 53:50 */           (!(element instanceof Group)))
/* 54:   */         {
/* 55:51 */           ActionListener action = (ActionListener)element.getUserObject();
/* 56:52 */           String command = (String)element.getBusinessObject();
/* 57:54 */           if (action != null)
/* 58:   */           {
/* 59:55 */             ActionEvent event = new ActionEvent(element, 0, command);
/* 60:56 */             action.actionPerformed(event);
/* 61:   */           }
/* 62:   */         }
/* 63:   */       }
/* 64:61 */     };
/* 65:62 */     addMouseMotionListener(mouseListener);
/* 66:63 */     addMouseListener(mouseListener);
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeList
 * JD-Core Version:    0.7.0.1
 */
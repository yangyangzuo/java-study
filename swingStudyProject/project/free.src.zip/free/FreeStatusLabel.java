/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import javax.swing.BorderFactory;
/*  4:   */ import javax.swing.Icon;
/*  5:   */ import javax.swing.JLabel;
/*  6:   */ 
/*  7:   */ public class FreeStatusLabel
/*  8:   */   extends JLabel
/*  9:   */ {
/* 10:   */   public FreeStatusLabel()
/* 11:   */   {
/* 12:11 */     this(null, null);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public FreeStatusLabel(String text)
/* 16:   */   {
/* 17:15 */     this(text, null);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public FreeStatusLabel(Icon icon)
/* 21:   */   {
/* 22:19 */     this(null, icon);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public FreeStatusLabel(String text, Icon icon)
/* 26:   */   {
/* 27:23 */     super(text, icon, 10);
/* 28:24 */     init();
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected void init()
/* 32:   */   {
/* 33:28 */     setOpaque(false);
/* 34:29 */     setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 35:30 */     setFont(FreeUtil.FONT_12_BOLD);
/* 36:31 */     setForeground(FreeUtil.DEFAULT_TEXT_COLOR);
/* 37:32 */     setVerticalAlignment(0);
/* 38:33 */     setVerticalTextPosition(0);
/* 39:34 */     setIconTextGap(5);
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeStatusLabel
 * JD-Core Version:    0.7.0.1
 */
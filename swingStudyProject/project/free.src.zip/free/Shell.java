/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import free.test.CompositionDemo;
/*   4:    */ import free.test.GoogleStockDemo;
/*   5:    */ import free.test.PopulationDemo;
/*   6:    */ import java.awt.BorderLayout;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ import java.awt.event.MouseAdapter;
/*  10:    */ import java.awt.event.MouseEvent;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.Vector;
/*  13:    */ import javax.swing.BorderFactory;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.JFrame;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JTable;
/*  18:    */ import javax.swing.SwingUtilities;
/*  19:    */ import javax.swing.plaf.TabbedPaneUI;
/*  20:    */ import javax.swing.table.DefaultTableModel;
/*  21:    */ import twaver.TWaverUtil;
/*  22:    */ 
/*  23:    */ public class Shell
/*  24:    */   extends JFrame
/*  25:    */ {
/*  26: 24 */   private String menuBarXML = "/free/menubar.xml";
/*  27: 25 */   private String toolbarXML = "/free/toolbar.xml";
/*  28: 26 */   private String outlookPaneXML = "/free/outlook.xml";
/*  29: 27 */   private ActionListener defaultAction = new ActionListener()
/*  30:    */   {
/*  31:    */     public void actionPerformed(ActionEvent e)
/*  32:    */     {
/*  33: 30 */       String command = e.getActionCommand();
/*  34: 31 */       Shell.this.command(command);
/*  35:    */     }
/*  36:    */   };
/*  37: 34 */   private String productName = "2BizBox";
/*  38: 35 */   private String companyName = "Serva Software";
/*  39: 36 */   private FreeMenuBar menubar = FreeUtil.loadMenuBar(this.menuBarXML, this.defaultAction);
/*  40: 37 */   private FreeContentPane contentPane = new FreeContentPane();
/*  41: 38 */   private FreeStatusBar statusBar = new FreeStatusBar();
/*  42: 39 */   private FreeMemoryBar memoryBar = new FreeMemoryBar();
/*  43: 40 */   private FreeStatusMessageLabel lbStatusMessage = new FreeStatusMessageLabel();
/*  44: 41 */   private FreeStatusTimeLabel lbStatusTime = new FreeStatusTimeLabel();
/*  45: 42 */   private FreeStatusLabel lbServer = createStatusLabel("218.83.152.220", "/free/test/server.png");
/*  46: 43 */   private FreeStatusLabel lbUser = createStatusLabel("admin", "/free/test/user.png");
/*  47: 44 */   private FreeStatusLabel lbVersion = createStatusLabel("v3.0.0", null);
/*  48: 45 */   private FreeListPane shortcutPane = new FreeListPane();
/*  49: 46 */   private FreeOutlookPane outlookPane = new FreeOutlookPane(this.shortcutPane);
/*  50: 47 */   private FreeTabbedPane tab = new FreeTabbedPane();
/*  51:    */   
/*  52:    */   public Shell()
/*  53:    */   {
/*  54: 50 */     initSwing();
/*  55: 51 */     initOutlookPane();
/*  56: 52 */     initTab();
/*  57: 53 */     initShortcutList();
/*  58: 54 */     initStatusBar();
/*  59: 55 */     initMockers();
/*  60:    */   }
/*  61:    */   
/*  62:    */   private void initSwing()
/*  63:    */   {
/*  64: 59 */     setTitle(this.productName + " v3.0 - Best Free ERP in the World [" + this.companyName + "]");
/*  65: 60 */     setDefaultCloseOperation(3);
/*  66: 61 */     setSize(1024, 768);
/*  67: 62 */     setIconImage(TWaverUtil.getImage("/free/test/logo.png"));
/*  68:    */     
/*  69: 64 */     setContentPane(this.contentPane);
/*  70: 65 */     TWaverUtil.centerWindow(this);
/*  71: 66 */     this.contentPane.add(this.menubar, "North");
/*  72: 67 */     this.contentPane.add(this.statusBar, "South");
/*  73:    */     
/*  74: 69 */     JPanel centerPane = new JPanel(new BorderLayout());
/*  75: 70 */     centerPane.setOpaque(true);
/*  76: 71 */     centerPane.setBackground(FreeUtil.CONTENT_PANE_BACKGROUND);
/*  77: 72 */     centerPane.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
/*  78: 73 */     centerPane.add(this.shortcutPane, "East");
/*  79: 74 */     centerPane.add(this.outlookPane, "West");
/*  80: 75 */     this.contentPane.add(centerPane, "Center");
/*  81: 76 */     centerPane.add(this.tab, "Center");
/*  82: 77 */     this.lbStatusMessage.setText("Server is connected");
/*  83:    */   }
/*  84:    */   
/*  85:    */   private void initOutlookPane()
/*  86:    */   {
/*  87: 81 */     FreeUtil.loadOutlookToolBar(this.toolbarXML, this.outlookPane.getHeader(), this.defaultAction);
/*  88:    */     
/*  89: 83 */     ActionListener nodeActionListener = new ActionListener()
/*  90:    */     {
/*  91:    */       public void actionPerformed(ActionEvent e)
/*  92:    */       {
/*  93: 86 */         Object source = e.getSource();
/*  94: 87 */         if ((source instanceof FreeNetwork))
/*  95:    */         {
/*  96: 88 */           FreeNetwork network = (FreeNetwork)source;
/*  97: 89 */           FreeOutlookBar bar = Shell.this.outlookPane.getBarByNetwork(network);
/*  98: 90 */           bar.setSelected(true);
/*  99: 93 */           if (network.getParent() == null)
/* 100:    */           {
/* 101: 94 */             String title = bar.getTitle();
/* 102: 95 */             Shell.this.tab.addTab(title, Shell.this.createPage(network));
/* 103:    */           }
/* 104:    */           else
/* 105:    */           {
/* 106: 97 */             FreePagePane pagePane = FreeUtil.getPagePane(network);
/* 107: 98 */             Shell.this.tab.setSelectedComponent(pagePane);
/* 108:    */           }
/* 109:    */         }
/* 110:    */       }
/* 111:102 */     };
/* 112:103 */     ActionListener nodeButtonAction = this.defaultAction;
/* 113:104 */     ActionListener shortcutAction = this.defaultAction;
/* 114:105 */     FreeUtil.loadOutlookPane(this.outlookPaneXML, this.outlookPane, nodeActionListener, nodeButtonAction, shortcutAction);
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void initTab()
/* 118:    */   {
/* 119:111 */     this.tab.addMouseListener(new MouseAdapter()
/* 120:    */     {
/* 121:    */       private boolean isMaximized()
/* 122:    */       {
/* 123:114 */         return (Shell.this.outlookPane.isShrinked()) && (Shell.this.shortcutPane.isShrinked());
/* 124:    */       }
/* 125:    */       
/* 126:    */       public void mouseClicked(MouseEvent e)
/* 127:    */       {
/* 128:119 */         if (e.getClickCount() > 1)
/* 129:    */         {
/* 130:120 */           TabbedPaneUI ui = Shell.this.tab.getUI();
/* 131:121 */           int tabIndex = ui.tabForCoordinate(Shell.this.tab, e.getX(), e.getY());
/* 132:123 */           if (tabIndex != -1)
/* 133:    */           {
/* 134:124 */             boolean maxed = isMaximized();
/* 135:125 */             Shell.this.outlookPane.setShrink(!maxed);
/* 136:126 */             Shell.this.shortcutPane.setShrink(!maxed);
/* 137:    */           }
/* 138:    */         }
/* 139:    */       }
/* 140:131 */     });
/* 141:132 */     this.tab.addTab("All Purchase Orders", createReportPage());
/* 142:133 */     this.tab.addTab("Dashboard", createPage(new CompositionDemo()));
/* 143:134 */     this.tab.addTab("Google Stock", createPage(new GoogleStockDemo()));
/* 144:135 */     this.tab.addTab("Global Customers", createPage(new PopulationDemo()));
/* 145:    */   }
/* 146:    */   
/* 147:    */   private FreeReportPage createReportPage()
/* 148:    */   {
/* 149:139 */     DefaultTableModel model = new DefaultTableModel();
/* 150:140 */     model.addColumn("ID");
/* 151:141 */     model.addColumn("Name");
/* 152:142 */     model.addColumn("Price");
/* 153:143 */     model.addColumn("Title");
/* 154:144 */     model.addColumn("Publisher");
/* 155:145 */     model.addColumn("Comments");
/* 156:147 */     for (int i = 0; i < 100; i++)
/* 157:    */     {
/* 158:148 */       Vector row = new Vector();
/* 159:149 */       row.add("5223");
/* 160:150 */       row.add("Bill Gates");
/* 161:151 */       row.add("$12,444.00");
/* 162:152 */       row.add("Sales Manager");
/* 163:153 */       row.add("Doubleday");
/* 164:154 */       row.add("director or manager misappropriates company funds or takes company funds and lends them to");
/* 165:155 */       model.addRow(row);
/* 166:    */     }
/* 167:158 */     FreeReportPage page = new FreeReportPage();
/* 168:159 */     page.getTable().setModel(model);
/* 169:160 */     page.setDescription("All Work Order Items by Part Number. Created " + new Date().toString());
/* 170:161 */     setupPageToolbar(page);
/* 171:    */     
/* 172:163 */     return page;
/* 173:    */   }
/* 174:    */   
/* 175:    */   private void initShortcutList()
/* 176:    */   {
/* 177:167 */     this.shortcutPane.setTitle("Start a Task");
/* 178:    */   }
/* 179:    */   
/* 180:    */   private void initStatusBar()
/* 181:    */   {
/* 182:171 */     this.statusBar.getLeftPane().add(this.lbStatusMessage, "Center");
/* 183:172 */     this.statusBar.addSeparator();
/* 184:173 */     this.statusBar.getRightPane().add(this.memoryBar);
/* 185:174 */     this.statusBar.addSeparator();
/* 186:175 */     this.statusBar.getRightPane().add(new FreeGarbageCollectButton());
/* 187:176 */     this.statusBar.addSeparator();
/* 188:177 */     this.statusBar.getRightPane().add(this.lbServer);
/* 189:178 */     this.statusBar.addSeparator();
/* 190:179 */     this.statusBar.getRightPane().add(this.lbUser);
/* 191:180 */     this.statusBar.addSeparator();
/* 192:181 */     this.statusBar.getRightPane().add(this.lbStatusTime);
/* 193:182 */     this.statusBar.addSeparator();
/* 194:183 */     this.statusBar.getRightPane().add(this.lbVersion);
/* 195:184 */     this.statusBar.addSeparator();
/* 196:185 */     this.statusBar.getRightPane().add(createStatusLabel("Powered by " + this.productName, null));
/* 197:    */   }
/* 198:    */   
/* 199:    */   public void setServer(String server)
/* 200:    */   {
/* 201:189 */     this.lbServer.setText(server);
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void setUser(String username)
/* 205:    */   {
/* 206:193 */     this.lbUser.setText(username);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void setVersion(String version)
/* 210:    */   {
/* 211:197 */     this.lbVersion.setText(version);
/* 212:    */   }
/* 213:    */   
/* 214:    */   private void initMockers()
/* 215:    */   {
/* 216:202 */     Thread thread = new Thread()
/* 217:    */     {
/* 218:    */       public void run()
/* 219:    */       {
/* 220:    */         for (;;)
/* 221:    */         {
/* 222:207 */           for (int i = 0; i < 3; i++) {
/* 223:    */             try
/* 224:    */             {
/* 225:209 */               Thread.sleep(5000L);
/* 226:210 */               if (i == 0)
/* 227:    */               {
/* 228:211 */                 Shell.this.lbStatusMessage.setGreenLight();
/* 229:212 */                 Shell.this.lbStatusMessage.setText("Server is connected");
/* 230:    */               }
/* 231:214 */               if (i == 1)
/* 232:    */               {
/* 233:215 */                 Shell.this.lbStatusMessage.setOrangeLight();
/* 234:216 */                 Shell.this.lbStatusMessage.setText("Server connection is slow");
/* 235:    */               }
/* 236:218 */               if (i == 2)
/* 237:    */               {
/* 238:219 */                 Shell.this.lbStatusMessage.setRedLight();
/* 239:220 */                 Shell.this.lbStatusMessage.setText("Server connection is broken");
/* 240:    */               }
/* 241:    */             }
/* 242:    */             catch (InterruptedException ex)
/* 243:    */             {
/* 244:223 */               ex.printStackTrace();
/* 245:    */             }
/* 246:    */           }
/* 247:    */         }
/* 248:    */       }
/* 249:228 */     };
/* 250:229 */     thread.start();
/* 251:    */   }
/* 252:    */   
/* 253:    */   private FreePagePane createPage(JComponent pageContent)
/* 254:    */   {
/* 255:233 */     FreePagePane page = new FreePagePane(pageContent);
/* 256:234 */     setupPageToolbar(page);
/* 257:235 */     return page;
/* 258:    */   }
/* 259:    */   
/* 260:    */   private void setupPageToolbar(FreePagePane page)
/* 261:    */   {
/* 262:239 */     page.getLeftToolBar().add(createButton("/free/test/home.png", "Click to go home", false));
/* 263:240 */     page.getLeftToolBar().add(createButton("/free/test/left.png", "Click to go left", false));
/* 264:241 */     page.getLeftToolBar().add(createButton("/free/test/right.png", "Click to go right", false));
/* 265:    */     
/* 266:243 */     FreeSearchTextField txtSearch = new FreeSearchTextField();
/* 267:244 */     txtSearch.setColumns(10);
/* 268:245 */     page.getRightToolBar().add(txtSearch);
/* 269:246 */     page.getRightToolBar().add(createButton("/free/test/add.png", "Click to go right", true));
/* 270:247 */     page.getRightToolBar().add(createButton("/free/test/update.png", "Click to go right", true));
/* 271:248 */     page.getRightToolBar().add(createButton("/free/test/refresh.png", "Click to go right", true));
/* 272:249 */     page.getRightToolBar().add(createButton("/free/test/print.png", "Click to go right", true));
/* 273:    */   }
/* 274:    */   
/* 275:    */   private FreeToolbarButton createButton(String icon, String tooltip, boolean rover)
/* 276:    */   {
/* 277:253 */     FreeToolbarButton button = null;
/* 278:254 */     if (rover) {
/* 279:255 */       button = new FreeToolbarRoverButton();
/* 280:    */     } else {
/* 281:257 */       button = new FreeToolbarButton();
/* 282:    */     }
/* 283:259 */     button.setIcon(TWaverUtil.getIcon(icon));
/* 284:260 */     button.setToolTipText(tooltip);
/* 285:261 */     return button;
/* 286:    */   }
/* 287:    */   
/* 288:    */   private FreeStatusLabel createStatusLabel(String text, String imageURL)
/* 289:    */   {
/* 290:265 */     if (imageURL != null) {
/* 291:266 */       return new FreeStatusLabel(text, TWaverUtil.getIcon(imageURL));
/* 292:    */     }
/* 293:268 */     return new FreeStatusLabel(text);
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void command(String action)
/* 297:    */   {
/* 298:273 */     String message = "Perform action " + action + ".";
/* 299:274 */     this.lbStatusMessage.setText(message);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public static void main(String[] args)
/* 303:    */   {
/* 304:278 */     SwingUtilities.invokeLater(new Runnable()
/* 305:    */     {
/* 306:    */       public void run()
/* 307:    */       {
/* 308:281 */         FreeUtil.setupLookAndFeel();
/* 309:282 */         Shell shell = new Shell();
/* 310:283 */         shell.setVisible(true);
/* 311:    */       }
/* 312:    */     });
/* 313:    */   }
/* 314:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.Shell
 * JD-Core Version:    0.7.0.1
 */
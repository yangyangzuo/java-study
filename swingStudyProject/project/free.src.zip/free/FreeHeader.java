/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.Cursor;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Graphics2D;
/*  10:    */ import java.awt.Image;
/*  11:    */ import java.awt.TexturePaint;
/*  12:    */ import java.awt.event.MouseAdapter;
/*  13:    */ import java.awt.event.MouseEvent;
/*  14:    */ import java.awt.event.MouseListener;
/*  15:    */ import javax.swing.BorderFactory;
/*  16:    */ import javax.swing.ImageIcon;
/*  17:    */ import javax.swing.JComponent;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.border.Border;
/*  21:    */ import twaver.TWaverUtil;
/*  22:    */ 
/*  23:    */ public class FreeHeader
/*  24:    */   extends JPanel
/*  25:    */ {
/*  26: 25 */   public static final ImageIcon RIGHT_ARROW_ICON = FreeUtil.getImageIcon("shrink_handler_right.png");
/*  27: 26 */   public static final ImageIcon LEFT_ARROW_ICON = FreeUtil.getImageIcon("shrink_handler_left.png");
/*  28: 27 */   private Color titleColor = new Color(215, 215, 216);
/*  29: 28 */   private boolean shrinked = false;
/*  30: 29 */   private String selectedBackgroundImageURL = FreeUtil.getImageURL("header_background.png");
/*  31: 30 */   private ImageIcon backgroundImageIcon = TWaverUtil.getImageIcon(this.selectedBackgroundImageURL);
/*  32: 31 */   private Image backgroundLeftImage = FreeUtil.getImage("header_background_left.png");
/*  33: 32 */   private Image backgroundRightImage = FreeUtil.getImage("header_background_right.png");
/*  34: 33 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.selectedBackgroundImageURL);
/*  35: 34 */   private int preferredHeight = this.backgroundImageIcon.getIconHeight();
/*  36: 35 */   private JLabel lbResizeHandler = new JLabel(FreeUtil.getImageIcon("resize_handler.png"));
/*  37: 36 */   private JLabel lbShrinkHandler = new JLabel(getShrinkIcon(this.shrinked));
/*  38: 37 */   private JLabel lbTitle = new JLabel();
/*  39: 38 */   private int normalPreferredWidth = 0;
/*  40: 39 */   private FreeListSplitListener splitListener = createSplitListener();
/*  41: 40 */   private MouseListener shrinkListener = new MouseAdapter()
/*  42:    */   {
/*  43:    */     public void mouseClicked(MouseEvent e)
/*  44:    */     {
/*  45: 44 */       FreeHeader.this.changeShrink();
/*  46:    */     }
/*  47:    */   };
/*  48:    */   
/*  49:    */   public FreeHeader()
/*  50:    */   {
/*  51: 49 */     init();
/*  52:    */   }
/*  53:    */   
/*  54:    */   protected FreeListSplitListener createSplitListener()
/*  55:    */   {
/*  56: 53 */     return new FreeListSplitListener(this);
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected Border createBorder()
/*  60:    */   {
/*  61: 57 */     return BorderFactory.createEmptyBorder(4, 7, 0, 0);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void init()
/*  65:    */   {
/*  66: 61 */     setBorder(createBorder());
/*  67: 62 */     setOpaque(false);
/*  68: 63 */     setLayout(new BorderLayout());
/*  69: 64 */     add(this.lbResizeHandler, getResizeHandlerLayoutConstraint());
/*  70: 65 */     add(this.lbShrinkHandler, getShrinkHandlerLayoutConstraint());
/*  71: 66 */     JComponent centerComponent = getCenterComponent();
/*  72: 67 */     if (centerComponent != null) {
/*  73: 68 */       add(centerComponent, "Center");
/*  74:    */     }
/*  75: 71 */     this.lbResizeHandler.addMouseMotionListener(this.splitListener);
/*  76: 72 */     this.lbResizeHandler.addMouseListener(this.splitListener);
/*  77: 73 */     this.lbShrinkHandler.addMouseListener(this.shrinkListener);
/*  78: 74 */     this.lbTitle.setFont(FreeUtil.FONT_14_BOLD);
/*  79: 75 */     this.lbTitle.setForeground(this.titleColor);
/*  80: 76 */     this.lbTitle.setBorder(BorderFactory.createEmptyBorder(2, 8, 0, 0));
/*  81:    */     
/*  82: 78 */     updateCursor();
/*  83:    */     
/*  84:    */ 
/*  85: 81 */     this.lbShrinkHandler.setBorder(BorderFactory.createEmptyBorder(0, 8, 2, 5));
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected JComponent getCenterComponent()
/*  89:    */   {
/*  90: 85 */     return this.lbTitle;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected Object getResizeHandlerLayoutConstraint()
/*  94:    */   {
/*  95: 89 */     return "West";
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected Object getShrinkHandlerLayoutConstraint()
/*  99:    */   {
/* 100: 93 */     return "East";
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected void paintComponent(Graphics g)
/* 104:    */   {
/* 105: 99 */     Graphics2D g2d = (Graphics2D)g;
/* 106:    */     
/* 107:    */ 
/* 108:102 */     g2d.setPaint(this.paint);
/* 109:103 */     g2d.fillRect(0, 0, getWidth(), getHeight());
/* 110:    */     
/* 111:    */ 
/* 112:106 */     g2d.drawImage(this.backgroundLeftImage, 0, 0, null);
/* 113:    */     
/* 114:    */ 
/* 115:109 */     int x = getWidth() - this.backgroundRightImage.getWidth(null);
/* 116:110 */     int y = 0;
/* 117:111 */     g2d.drawImage(this.backgroundRightImage, x, y, null);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Dimension getPreferredSize()
/* 121:    */   {
/* 122:116 */     return new Dimension(super.getPreferredSize().width, this.preferredHeight);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void revalidateParent()
/* 126:    */   {
/* 127:120 */     if ((getParent() instanceof JComponent)) {
/* 128:121 */       ((JComponent)getParent()).revalidate();
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void changeShrink()
/* 133:    */   {
/* 134:126 */     setShrink(!isShrinked());
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void setShrink(boolean shrinked)
/* 138:    */   {
/* 139:130 */     if (shrinked != this.shrinked)
/* 140:    */     {
/* 141:131 */       Container parent = getParent();
/* 142:132 */       Dimension size = parent.getPreferredSize();
/* 143:133 */       if (shrinked)
/* 144:    */       {
/* 145:134 */         this.normalPreferredWidth = size.width;
/* 146:135 */         size = new Dimension(getShrinkedWidth(), size.height);
/* 147:    */       }
/* 148:    */       else
/* 149:    */       {
/* 150:137 */         int width = this.normalPreferredWidth;
/* 151:138 */         int height = parent.getPreferredSize().height;
/* 152:139 */         size = new Dimension(width, height);
/* 153:    */       }
/* 154:141 */       parent.setPreferredSize(size);
/* 155:142 */       this.lbShrinkHandler.setIcon(getShrinkIcon(shrinked));
/* 156:143 */       revalidateParent();
/* 157:144 */       this.shrinked = shrinked;
/* 158:145 */       updateCursor();
/* 159:146 */       this.lbTitle.setVisible(!shrinked);
/* 160:147 */       this.lbResizeHandler.setVisible(!shrinked);
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   protected ImageIcon getShrinkIcon(boolean shrinked)
/* 165:    */   {
/* 166:152 */     if (shrinked) {
/* 167:153 */       return LEFT_ARROW_ICON;
/* 168:    */     }
/* 169:155 */     return RIGHT_ARROW_ICON;
/* 170:    */   }
/* 171:    */   
/* 172:    */   private void updateCursor()
/* 173:    */   {
/* 174:160 */     if (this.shrinked) {
/* 175:161 */       this.lbResizeHandler.setCursor(Cursor.getDefaultCursor());
/* 176:    */     } else {
/* 177:163 */       this.lbResizeHandler.setCursor(Cursor.getPredefinedCursor(10));
/* 178:    */     }
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean isShrinked()
/* 182:    */   {
/* 183:168 */     return this.shrinked;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void setTitle(String title)
/* 187:    */   {
/* 188:172 */     this.lbTitle.setText(title);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public String getTitle()
/* 192:    */   {
/* 193:176 */     return this.lbTitle.getText();
/* 194:    */   }
/* 195:    */   
/* 196:    */   protected int getShrinkedWidth()
/* 197:    */   {
/* 198:180 */     return 37;
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeHeader
 * JD-Core Version:    0.7.0.1
 */
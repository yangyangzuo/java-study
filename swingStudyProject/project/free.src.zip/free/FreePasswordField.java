/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Graphics2D;
/*  7:   */ import java.awt.Image;
/*  8:   */ import java.awt.TexturePaint;
/*  9:   */ import javax.swing.BorderFactory;
/* 10:   */ import javax.swing.ImageIcon;
/* 11:   */ import javax.swing.JPasswordField;
/* 12:   */ import javax.swing.border.Border;
/* 13:   */ import javax.swing.plaf.metal.MetalTextFieldUI;
/* 14:   */ import twaver.TWaverUtil;
/* 15:   */ 
/* 16:   */ public class FreePasswordField
/* 17:   */   extends JPasswordField
/* 18:   */ {
/* 19:18 */   private String backgroundImageURL = FreeUtil.getImageURL("textfield_background.png");
/* 20:19 */   private Image backgroundLeftImage = FreeUtil.getImage("textfield_background_left.png");
/* 21:20 */   private Image backgroundRightImage = FreeUtil.getImage("textfield_background_right.png");
/* 22:21 */   private ImageIcon backgroundImageIcon = TWaverUtil.getImageIcon(this.backgroundImageURL);
/* 23:22 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 24:23 */   private Border border = BorderFactory.createEmptyBorder(1, 3, 1, 3);
/* 25:24 */   private Font font = FreeUtil.FONT_12_PLAIN;
/* 26:   */   
/* 27:   */   public FreePasswordField()
/* 28:   */   {
/* 29:27 */     init();
/* 30:   */   }
/* 31:   */   
/* 32:   */   private void init()
/* 33:   */   {
/* 34:31 */     setBorder(this.border);
/* 35:32 */     setUI(new MetalTextFieldUI()
/* 36:   */     {
/* 37:   */       protected void paintBackground(Graphics g)
/* 38:   */       {
/* 39:36 */         Graphics2D g2d = (Graphics2D)g;
/* 40:37 */         g2d.setPaint(FreePasswordField.this.paint);
/* 41:38 */         g2d.fillRect(0, 0, FreePasswordField.this.getWidth(), FreePasswordField.this.getHeight());
/* 42:   */         
/* 43:   */ 
/* 44:41 */         g2d.drawImage(FreePasswordField.this.backgroundLeftImage, 0, 0, null);
/* 45:   */         
/* 46:   */ 
/* 47:44 */         g2d.drawImage(FreePasswordField.this.backgroundRightImage, FreePasswordField.this.getWidth() - FreePasswordField.this.backgroundRightImage.getWidth(null), 0, null);
/* 48:   */       }
/* 49:47 */     });
/* 50:48 */     setFont(this.font);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Dimension getPreferredSize()
/* 54:   */   {
/* 55:53 */     return new Dimension(super.getPreferredSize().width, this.backgroundImageIcon.getIconHeight());
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreePasswordField
 * JD-Core Version:    0.7.0.1
 */
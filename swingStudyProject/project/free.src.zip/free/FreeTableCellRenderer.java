/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import javax.swing.BorderFactory;
/*  6:   */ import javax.swing.JTable;
/*  7:   */ import javax.swing.border.Border;
/*  8:   */ import javax.swing.table.DefaultTableCellRenderer;
/*  9:   */ 
/* 10:   */ public class FreeTableCellRenderer
/* 11:   */   extends DefaultTableCellRenderer
/* 12:   */ {
/* 13:12 */   private Color backgroundEven = Color.white;
/* 14:13 */   private Color backgroundOdd = FreeUtil.TABLE_ODD_ROW_COLOR;
/* 15:14 */   private Color backgroundSelected = new Color(255, 223, 156);
/* 16:15 */   private Color selectedTextColor = Color.BLACK;
/* 17:16 */   private Color textColor = FreeUtil.TABLE_TEXT_COLOR;
/* 18:17 */   private Border border = BorderFactory.createEmptyBorder(0, 5, 0, 0);
/* 19:   */   
/* 20:   */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 21:   */   {
/* 22:22 */     super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 23:   */     
/* 24:24 */     setFont(FreeUtil.TABLE_CELL_FONT);
/* 25:25 */     setBorder(this.border);
/* 26:26 */     if (!isSelected)
/* 27:   */     {
/* 28:27 */       if (row % 2 == 1) {
/* 29:28 */         setBackground(this.backgroundOdd);
/* 30:   */       } else {
/* 31:30 */         setBackground(this.backgroundEven);
/* 32:   */       }
/* 33:32 */       setForeground(this.textColor);
/* 34:   */     }
/* 35:   */     else
/* 36:   */     {
/* 37:34 */       setBackground(this.backgroundSelected);
/* 38:35 */       setForeground(this.selectedTextColor);
/* 39:   */     }
/* 40:37 */     return this;
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTableCellRenderer
 * JD-Core Version:    0.7.0.1
 */
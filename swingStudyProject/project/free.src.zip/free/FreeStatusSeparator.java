/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import javax.swing.BorderFactory;
/*  4:   */ import javax.swing.ImageIcon;
/*  5:   */ import javax.swing.JLabel;
/*  6:   */ 
/*  7:   */ public class FreeStatusSeparator
/*  8:   */   extends JLabel
/*  9:   */ {
/* 10: 9 */   private ImageIcon imageIcon = FreeUtil.getImageIcon("statusbar_separator.png");
/* 11:   */   
/* 12:   */   public FreeStatusSeparator()
/* 13:   */   {
/* 14:12 */     init();
/* 15:   */   }
/* 16:   */   
/* 17:   */   private void init()
/* 18:   */   {
/* 19:16 */     setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 20:17 */     setOpaque(false);
/* 21:18 */     setIcon(this.imageIcon);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeStatusSeparator
 * JD-Core Version:    0.7.0.1
 */
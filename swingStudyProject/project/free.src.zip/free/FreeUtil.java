/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import com.jgoodies.looks.plastic.PlasticLookAndFeel;
/*   4:    */ import com.jgoodies.looks.plastic.PlasticTheme;
/*   5:    */ import com.jgoodies.looks.plastic.theme.ExperienceGreen;
/*   6:    */ import java.awt.AlphaComposite;
/*   7:    */ import java.awt.Color;
/*   8:    */ import java.awt.Component;
/*   9:    */ import java.awt.Font;
/*  10:    */ import java.awt.Graphics;
/*  11:    */ import java.awt.Graphics2D;
/*  12:    */ import java.awt.Image;
/*  13:    */ import java.awt.Insets;
/*  14:    */ import java.awt.Rectangle;
/*  15:    */ import java.awt.TexturePaint;
/*  16:    */ import java.awt.event.ActionListener;
/*  17:    */ import java.awt.image.BufferedImage;
/*  18:    */ import java.awt.image.ConvolveOp;
/*  19:    */ import java.awt.image.Kernel;
/*  20:    */ import java.awt.image.PixelGrabber;
/*  21:    */ import java.net.URL;
/*  22:    */ import java.util.Locale;
/*  23:    */ import javax.swing.BorderFactory;
/*  24:    */ import javax.swing.Box;
/*  25:    */ import javax.swing.Icon;
/*  26:    */ import javax.swing.ImageIcon;
/*  27:    */ import javax.swing.JLabel;
/*  28:    */ import javax.swing.JMenuItem;
/*  29:    */ import javax.swing.UIDefaults;
/*  30:    */ import javax.swing.UIManager;
/*  31:    */ import javax.swing.plaf.FontUIResource;
/*  32:    */ import javax.xml.parsers.DocumentBuilder;
/*  33:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  34:    */ import org.w3c.dom.Document;
/*  35:    */ import org.w3c.dom.Element;
/*  36:    */ import org.w3c.dom.NamedNodeMap;
/*  37:    */ import org.w3c.dom.NodeList;
/*  38:    */ import twaver.Group;
/*  39:    */ import twaver.PixelFilter;
/*  40:    */ import twaver.TDataBox;
/*  41:    */ import twaver.TWaverConst;
/*  42:    */ import twaver.TWaverUtil;
/*  43:    */ 
/*  44:    */ public class FreeUtil
/*  45:    */ {
/*  46:    */   public static final int DEFAULT_ICON_SIZE = 16;
/*  47: 44 */   public static Icon BLANK_ICON = new Icon()
/*  48:    */   {
/*  49:    */     public void paintIcon(Component c, Graphics g, int x, int y) {}
/*  50:    */     
/*  51:    */     public int getIconWidth()
/*  52:    */     {
/*  53: 51 */       return 16;
/*  54:    */     }
/*  55:    */     
/*  56:    */     public int getIconHeight()
/*  57:    */     {
/*  58: 55 */       return 16;
/*  59:    */     }
/*  60:    */   };
/*  61:    */   public static final int DEFAULT_BUTTON_SIZE = 20;
/*  62: 59 */   public static final Insets ZERO_INSETS = new Insets(0, 0, 0, 0);
/*  63:    */   public static final int LIST_SHRINKED_WIDTH = 37;
/*  64:    */   public static final int OUTLOOK_SHRINKED_WIDTH = 37;
/*  65:    */   public static final int DEFAULT_SPLIT_WIDTH = 4;
/*  66:    */   public static final int TABLE_CELL_LEADING_SPACE = 5;
/*  67: 64 */   public static final Color DEFAULT_SELECTION_COLOR = new Color(253, 192, 47);
/*  68: 65 */   public static final Color BUTTON_ROVER_COLOR = new Color(196, 196, 197);
/*  69: 66 */   public static final Color TABLE_HEADER_BACKGROUND_COLOR = new Color(239, 240, 241);
/*  70: 67 */   public static final Color TABLE_HEADER_BORDER_BRIGHT_COLOR = Color.white;
/*  71: 68 */   public static final Color TABLE_HEADER_BORDER_DARK_COLOR = new Color(215, 219, 223);
/*  72: 69 */   public static final Color TABLE_ODD_ROW_COLOR = new Color(233, 231, 235);
/*  73: 70 */   public static final Color TABLE_TEXT_COLOR = new Color(74, 74, 81);
/*  74: 71 */   public static final Color NETWORK_BACKGROUND = new Color(226, 228, 229);
/*  75: 72 */   public static final Color TAB_BOTTOM_LINE_COLOR = new Color(167, 173, 175);
/*  76: 73 */   public static final Color OUTLOOK_TEXT_COLOR = new Color(120, 120, 125);
/*  77: 74 */   public static final Color OUTLOOK_SPLIT_COLOR = new Color(174, 171, 162);
/*  78: 75 */   public static final Color LIST_SPLIT_COLOR = new Color(105, 113, 120);
/*  79: 76 */   public static final Color LIST_BACKGROUND = new Color(175, 174, 176);
/*  80: 77 */   public static final Color LIST_TEXT_COLOR = new Color(49, 52, 58);
/*  81: 78 */   public static final Color CONTENT_PANE_BACKGROUND = new Color(92, 153, 45);
/*  82: 79 */   public static final Color MENUITEM_SELECTED_BACKGROUND = new Color(166, 188, 140);
/*  83: 80 */   public static final Color MENUITEM_BACKGROUND = new Color(228, 235, 218);
/*  84: 81 */   public static final Color DEFAULT_TEXT_COLOR = new Color(37, 81, 54);
/*  85: 82 */   public static final Color NO_COLOR = new Color(0, 0, 0, 0);
/*  86: 83 */   public static final Font TABLE_HEADER_FONT = new Font("Tahoma", 1, 11);
/*  87: 84 */   public static final Font TABLE_CELL_FONT = new Font("Tahoma", 0, 11);
/*  88: 85 */   public static final Font FONT_14_BOLD = new Font("Calibri", 1, 14);
/*  89: 86 */   public static final Font FONT_12_BOLD = new Font("Calibri", 1, 12);
/*  90: 87 */   public static final Font FONT_14_PLAIN = new Font("Calibri", 0, 14);
/*  91: 88 */   public static final Font FONT_12_PLAIN = new Font("Calibri", 0, 12);
/*  92:    */   private static final String IMAGE_URL_PREFIX = "/free/images/";
/*  93:    */   
/*  94:    */   public static TexturePaint createTexturePaint(String imageURL)
/*  95:    */   {
/*  96: 92 */     return createTexturePaint(TWaverUtil.getImage(imageURL));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static TexturePaint createTexturePaint(Image image)
/* 100:    */   {
/* 101: 96 */     int imageWidth = image.getWidth(null);
/* 102: 97 */     int imageHeight = image.getHeight(null);
/* 103: 98 */     BufferedImage bi = new BufferedImage(imageWidth, imageHeight, 2);
/* 104: 99 */     Graphics2D g2d = bi.createGraphics();
/* 105:100 */     g2d.drawImage(image, 0, 0, null);
/* 106:101 */     g2d.dispose();
/* 107:102 */     return new TexturePaint(bi, new Rectangle(0, 0, imageWidth, imageHeight));
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static String getImageURL(String imageName)
/* 111:    */   {
/* 112:106 */     return "/free/images/" + imageName;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static Image getImage(String imageName)
/* 116:    */   {
/* 117:110 */     return TWaverUtil.getImage(getImageURL(imageName));
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static ImageIcon getImageIcon(String imageName)
/* 121:    */   {
/* 122:114 */     return TWaverUtil.getImageIcon(getImageURL(imageName));
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static BufferedImage createDropShadow(BufferedImage image, int size)
/* 126:    */   {
/* 127:118 */     BufferedImage shadow = new BufferedImage(image.getWidth() + 4 * size, image.getHeight() + 4 * size, 2);
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:123 */     Graphics2D g2 = shadow.createGraphics();
/* 133:124 */     g2.drawImage(image, size * 2, size * 2, null);
/* 134:    */     
/* 135:126 */     g2.setComposite(AlphaComposite.SrcIn);
/* 136:127 */     g2.setColor(Color.BLACK);
/* 137:128 */     g2.fillRect(0, 0, shadow.getWidth(), shadow.getHeight());
/* 138:    */     
/* 139:130 */     g2.dispose();
/* 140:    */     
/* 141:132 */     shadow = getGaussianBlurFilter(size, true).filter(shadow, null);
/* 142:133 */     shadow = getGaussianBlurFilter(size, false).filter(shadow, null);
/* 143:    */     
/* 144:135 */     return shadow;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static ConvolveOp getGaussianBlurFilter(int radius, boolean horizontal)
/* 148:    */   {
/* 149:139 */     if (radius < 1) {
/* 150:140 */       throw new IllegalArgumentException("Radius must be >= 1");
/* 151:    */     }
/* 152:143 */     int size = radius * 2 + 1;
/* 153:144 */     float[] data = new float[size];
/* 154:    */     
/* 155:146 */     float sigma = radius / 3.0F;
/* 156:147 */     float twoSigmaSquare = 2.0F * sigma * sigma;
/* 157:148 */     float sigmaRoot = (float)Math.sqrt(twoSigmaSquare * 3.141592653589793D);
/* 158:149 */     float total = 0.0F;
/* 159:151 */     for (int i = -radius; i <= radius; i++)
/* 160:    */     {
/* 161:152 */       float distance = i * i;
/* 162:153 */       int index = i + radius;
/* 163:154 */       data[index] = ((float)Math.exp(-distance / twoSigmaSquare) / sigmaRoot);
/* 164:155 */       total += data[index];
/* 165:    */     }
/* 166:158 */     for (int i = 0; i < data.length; i++) {
/* 167:159 */       data[i] /= total;
/* 168:    */     }
/* 169:162 */     Kernel kernel = null;
/* 170:163 */     if (horizontal) {
/* 171:164 */       kernel = new Kernel(size, 1, data);
/* 172:    */     } else {
/* 173:166 */       kernel = new Kernel(1, size, data);
/* 174:    */     }
/* 175:168 */     return new ConvolveOp(kernel, 1, null);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static Image getNodeShadowImage(twaver.Node node)
/* 179:    */   {
/* 180:172 */     Object value = node.getUserProperty("shadow");
/* 181:173 */     if ((value instanceof Image)) {
/* 182:174 */       return (Image)value;
/* 183:    */     }
/* 184:176 */     return null;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static void setNodeShadowImage(twaver.Node node, Image shadowImage)
/* 188:    */   {
/* 189:180 */     node.putUserProperty("shadow", shadowImage);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static FreeMenuBar loadMenuBar(String xml, ActionListener action)
/* 193:    */   {
/* 194:184 */     FreeMenuBar menuBar = null;
/* 195:    */     try
/* 196:    */     {
/* 197:186 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 198:187 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 199:188 */       Document doc = db.parse(FreeUtil.class.getResource(xml).openStream());
/* 200:    */       
/* 201:190 */       Element root = doc.getDocumentElement();
/* 202:191 */       NodeList rootMenus = root.getChildNodes();
/* 203:192 */       if (rootMenus != null)
/* 204:    */       {
/* 205:193 */         menuBar = new FreeMenuBar();
/* 206:194 */         for (int i = 0; i < rootMenus.getLength(); i++)
/* 207:    */         {
/* 208:195 */           org.w3c.dom.Node menu = rootMenus.item(i);
/* 209:196 */           if (menu.getNodeType() == 1)
/* 210:    */           {
/* 211:197 */             if (menu.getNodeName().equalsIgnoreCase("menu"))
/* 212:    */             {
/* 213:198 */               String text = getStringAttribute(menu, "text");
/* 214:199 */               FreeRootMenu rootMenu = new FreeRootMenu();
/* 215:200 */               rootMenu.setText(text);
/* 216:201 */               menuBar.add(rootMenu);
/* 217:    */               
/* 218:203 */               processMenuItem(menu, rootMenu, action);
/* 219:    */             }
/* 220:205 */             if (menu.getNodeName().equalsIgnoreCase("logo"))
/* 221:    */             {
/* 222:206 */               String tooltip = getStringAttribute(menu, "tooltip");
/* 223:207 */               String imageURL = getStringAttribute(menu, "image");
/* 224:    */               
/* 225:    */ 
/* 226:210 */               menuBar.add(Box.createGlue());
/* 227:211 */               JLabel label = new JLabel(TWaverUtil.getImageIcon(imageURL));
/* 228:212 */               label.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 229:213 */               label.setToolTipText(tooltip);
/* 230:214 */               menuBar.add(label);
/* 231:    */             }
/* 232:    */           }
/* 233:    */         }
/* 234:    */       }
/* 235:    */     }
/* 236:    */     catch (Exception ex)
/* 237:    */     {
/* 238:220 */       ex.printStackTrace();
/* 239:    */     }
/* 240:222 */     return menuBar;
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static void processMenuItem(org.w3c.dom.Node menu, JMenuItem parentMenu, ActionListener action)
/* 244:    */   {
/* 245:227 */     NodeList children = menu.getChildNodes();
/* 246:228 */     if (children != null) {
/* 247:229 */       for (int j = 0; j < children.getLength(); j++)
/* 248:    */       {
/* 249:230 */         org.w3c.dom.Node itemNode = children.item(j);
/* 250:231 */         if (itemNode.getNodeType() == 1)
/* 251:    */         {
/* 252:232 */           boolean isMenuItem = itemNode.getNodeName().equalsIgnoreCase("menuitem");
/* 253:233 */           boolean isMenu = itemNode.getNodeName().equalsIgnoreCase("menu");
/* 254:234 */           if ((isMenuItem) || (isMenu))
/* 255:    */           {
/* 256:235 */             String text = getStringAttribute(itemNode, "text");
/* 257:236 */             String tooltip = getStringAttribute(itemNode, "tooltip");
/* 258:237 */             Icon icon = getIconAttribute(itemNode, "icon");
/* 259:238 */             String command = getStringAttribute(itemNode, "action");
/* 260:    */             
/* 261:240 */             JMenuItem menuItem = null;
/* 262:242 */             if (isMenu)
/* 263:    */             {
/* 264:243 */               menuItem = new FreeMenu();
/* 265:    */             }
/* 266:    */             else
/* 267:    */             {
/* 268:245 */               menuItem = new FreeMenuItem();
/* 269:246 */               menuItem.addActionListener(action);
/* 270:    */             }
/* 271:248 */             menuItem.setText(text);
/* 272:249 */             menuItem.setToolTipText(tooltip);
/* 273:250 */             menuItem.setActionCommand(command);
/* 274:251 */             menuItem.setIcon(icon);
/* 275:252 */             parentMenu.add(menuItem);
/* 276:254 */             if (isMenu) {
/* 277:255 */               processMenuItem(itemNode, menuItem, action);
/* 278:    */             }
/* 279:    */           }
/* 280:    */         }
/* 281:    */       }
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static String getStringAttribute(org.w3c.dom.Node node, String name)
/* 286:    */   {
/* 287:265 */     org.w3c.dom.Node attribute = node.getAttributes().getNamedItem(name);
/* 288:266 */     if (attribute != null) {
/* 289:267 */       return attribute.getNodeValue();
/* 290:    */     }
/* 291:269 */     return null;
/* 292:    */   }
/* 293:    */   
/* 294:    */   private static Icon getIconAttribute(org.w3c.dom.Node node, String name)
/* 295:    */   {
/* 296:274 */     String iconURL = getStringAttribute(node, name);
/* 297:275 */     if ((iconURL != null) && (!iconURL.isEmpty())) {
/* 298:276 */       return TWaverUtil.getIcon(iconURL);
/* 299:    */     }
/* 300:278 */     return null;
/* 301:    */   }
/* 302:    */   
/* 303:    */   private static int getIntAttribute(org.w3c.dom.Node node, String name)
/* 304:    */   {
/* 305:282 */     String value = getStringAttribute(node, name);
/* 306:283 */     if ((value != null) && (!value.isEmpty())) {
/* 307:284 */       return Integer.valueOf(value).intValue();
/* 308:    */     }
/* 309:286 */     return 0;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public static void loadOutlookToolBar(String xml, FreeOutlookHeader header, ActionListener action)
/* 313:    */   {
/* 314:    */     try
/* 315:    */     {
/* 316:291 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 317:292 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 318:293 */       Document doc = db.parse(FreeUtil.class.getResource(xml).openStream());
/* 319:    */       
/* 320:295 */       Element root = doc.getDocumentElement();
/* 321:296 */       NodeList buttons = root.getChildNodes();
/* 322:297 */       if (buttons != null) {
/* 323:298 */         for (int i = 0; i < buttons.getLength(); i++)
/* 324:    */         {
/* 325:299 */           org.w3c.dom.Node buttonNode = buttons.item(i);
/* 326:300 */           if (buttonNode.getNodeType() == 1)
/* 327:    */           {
/* 328:301 */             if (buttonNode.getNodeName().equalsIgnoreCase("button"))
/* 329:    */             {
/* 330:302 */               String tooltip = getStringAttribute(buttonNode, "tooltip");
/* 331:303 */               Icon icon = getIconAttribute(buttonNode, "icon");
/* 332:304 */               String command = getStringAttribute(buttonNode, "action");
/* 333:305 */               header.addButton(icon, tooltip, action, command);
/* 334:    */             }
/* 335:307 */             if (buttonNode.getNodeName().equalsIgnoreCase("separator")) {
/* 336:308 */               header.addSeparator();
/* 337:    */             }
/* 338:    */           }
/* 339:    */         }
/* 340:    */       }
/* 341:    */     }
/* 342:    */     catch (Exception ex)
/* 343:    */     {
/* 344:314 */       ex.printStackTrace();
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static void loadOutlookPane(String xml, FreeOutlookPane outlookPane, ActionListener nodeAction, ActionListener nodeButtonAction, ActionListener shortcutAction)
/* 349:    */   {
/* 350:    */     try
/* 351:    */     {
/* 352:324 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 353:325 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 354:326 */       Document doc = db.parse(FreeUtil.class.getResource(xml).openStream());
/* 355:    */       
/* 356:328 */       Element root = doc.getDocumentElement();
/* 357:329 */       NodeList modules = root.getChildNodes();
/* 358:330 */       if (modules != null) {
/* 359:331 */         for (int i = 0; i < modules.getLength(); i++)
/* 360:    */         {
/* 361:332 */           org.w3c.dom.Node moduleNode = modules.item(i);
/* 362:333 */           if ((moduleNode.getNodeType() == 1) && 
/* 363:334 */             (moduleNode.getNodeName().equalsIgnoreCase("module")))
/* 364:    */           {
/* 365:335 */             String text = getStringAttribute(moduleNode, "text");
/* 366:336 */             Icon icon = getIconAttribute(moduleNode, "icon");
/* 367:337 */             Icon iconSelected = getIconAttribute(moduleNode, "selected_icon");
/* 368:338 */             String networkXml = getStringAttribute(moduleNode, "network");
/* 369:339 */             FreeOutlookBar bar = outlookPane.addBar(text, icon, iconSelected);
/* 370:340 */             loadNetwork(networkXml, bar.getNetwork(), nodeAction, nodeButtonAction, shortcutAction);
/* 371:    */           }
/* 372:    */         }
/* 373:    */       }
/* 374:    */     }
/* 375:    */     catch (Exception ex)
/* 376:    */     {
/* 377:347 */       ex.printStackTrace();
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   public static void loadNetwork(String xml, FreeNetwork network, ActionListener nodeAction, ActionListener nodeButtonAction, ActionListener shortcutAction)
/* 382:    */   {
/* 383:    */     try
/* 384:    */     {
/* 385:356 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 386:357 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 387:358 */       Document doc = db.parse(FreeUtil.class.getResource(xml).openStream());
/* 388:    */       
/* 389:360 */       Element root = doc.getDocumentElement();
/* 390:361 */       NodeList elements = root.getChildNodes();
/* 391:362 */       if (elements != null) {
/* 392:363 */         for (int i = 0; i < elements.getLength(); i++)
/* 393:    */         {
/* 394:364 */           org.w3c.dom.Node elementNode = elements.item(i);
/* 395:365 */           if (elementNode.getNodeType() == 1)
/* 396:    */           {
/* 397:366 */             if (elementNode.getNodeName().equalsIgnoreCase("node"))
/* 398:    */             {
/* 399:367 */               String networkName = getHtmlLabelText(getStringAttribute(elementNode, "network_text"));
/* 400:368 */               String text = getStringAttribute(elementNode, "text");
/* 401:369 */               int x = getIntAttribute(elementNode, "x");
/* 402:370 */               int y = getIntAttribute(elementNode, "y");
/* 403:371 */               String moduleIcon = getStringAttribute(elementNode, "icon");
/* 404:372 */               String tooltip = getStringAttribute(elementNode, "tooltip");
/* 405:373 */               String listIcon = getStringAttribute(elementNode, "list_icon");
/* 406:    */               
/* 407:375 */               FreeNode twaverNode = new FreeNode();
/* 408:376 */               twaverNode.setLocation(x, y);
/* 409:377 */               twaverNode.setModuleIcon(moduleIcon);
/* 410:378 */               twaverNode.setIcon(listIcon);
/* 411:379 */               twaverNode.setName(text);
/* 412:380 */               twaverNode.setNetworkName(networkName);
/* 413:381 */               twaverNode.setToolTipText(tooltip);
/* 414:382 */               twaverNode.setAction(nodeAction);
/* 415:    */               
/* 416:    */ 
/* 417:385 */               readNodeButtons(elementNode, twaverNode, nodeButtonAction);
/* 418:    */               
/* 419:    */ 
/* 420:388 */               TDataBox shortcutBox = new TDataBox();
/* 421:389 */               readNodeShortcuts(elementNode, shortcutBox, shortcutAction);
/* 422:390 */               twaverNode.setShortcuts(shortcutBox);
/* 423:    */               
/* 424:392 */               network.getDataBox().addElement(twaverNode);
/* 425:    */             }
/* 426:394 */             if (elementNode.getNodeName().equalsIgnoreCase("arrow"))
/* 427:    */             {
/* 428:395 */               int x = getIntAttribute(elementNode, "x");
/* 429:396 */               int y = getIntAttribute(elementNode, "y");
/* 430:397 */               String direction = getStringAttribute(elementNode, "direction");
/* 431:398 */               int rotation = getIntAttribute(elementNode, "rotation");
/* 432:    */               
/* 433:400 */               FreeLink arrow = new FreeLink();
/* 434:401 */               arrow.setLocation(x, y);
/* 435:402 */               arrow.setAngle(rotation);
/* 436:403 */               arrow.setDirection(getArrowDirection(direction));
/* 437:    */               
/* 438:405 */               network.getDataBox().addElement(arrow);
/* 439:    */             }
/* 440:    */           }
/* 441:    */         }
/* 442:    */       }
/* 443:    */     }
/* 444:    */     catch (Exception ex)
/* 445:    */     {
/* 446:411 */       ex.printStackTrace();
/* 447:    */     }
/* 448:    */   }
/* 449:    */   
/* 450:    */   private static void readNodeShortcuts(org.w3c.dom.Node moduleNode, TDataBox box, ActionListener shortcutAction)
/* 451:    */   {
/* 452:416 */     NodeList children = moduleNode.getChildNodes();
/* 453:417 */     if (children != null) {
/* 454:418 */       for (int i = 0; i < children.getLength(); i++)
/* 455:    */       {
/* 456:419 */         org.w3c.dom.Node child = children.item(i);
/* 457:420 */         if ((child.getNodeType() == 1) && 
/* 458:421 */           (child.getNodeName().equalsIgnoreCase("shortcuts")))
/* 459:    */         {
/* 460:422 */           NodeList shortcuts = child.getChildNodes();
/* 461:423 */           if (shortcuts != null) {
/* 462:424 */             for (int j = 0; j < shortcuts.getLength(); j++)
/* 463:    */             {
/* 464:425 */               org.w3c.dom.Node shortcut = shortcuts.item(j);
/* 465:426 */               if (shortcut.getNodeType() == 1)
/* 466:    */               {
/* 467:427 */                 if (shortcut.getNodeName().equalsIgnoreCase("shortcut"))
/* 468:    */                 {
/* 469:428 */                   String text = getStringAttribute(shortcut, "text");
/* 470:429 */                   String tooltip = getStringAttribute(shortcut, "tooltip");
/* 471:430 */                   String iconURL = getStringAttribute(shortcut, "icon");
/* 472:431 */                   String command = getStringAttribute(shortcut, "action");
/* 473:    */                   
/* 474:433 */                   twaver.Node node = new twaver.Node();
/* 475:434 */                   node.setName(text);
/* 476:435 */                   node.setToolTipText(tooltip);
/* 477:436 */                   if ((iconURL == null) || (iconURL.trim().isEmpty())) {
/* 478:437 */                     node.setIcon("-");
/* 479:    */                   } else {
/* 480:439 */                     node.setIcon(iconURL);
/* 481:    */                   }
/* 482:441 */                   node.setUserObject(shortcutAction);
/* 483:442 */                   node.setBusinessObject(command);
/* 484:443 */                   box.addElement(node);
/* 485:    */                 }
/* 486:445 */                 if (shortcut.getNodeName().equalsIgnoreCase("separator"))
/* 487:    */                 {
/* 488:446 */                   Group group = new Group();
/* 489:447 */                   String text = getStringAttribute(shortcut, "text");
/* 490:448 */                   group.setName(text);
/* 491:449 */                   box.addElement(group);
/* 492:    */                 }
/* 493:    */               }
/* 494:    */             }
/* 495:    */           }
/* 496:    */         }
/* 497:    */       }
/* 498:    */     }
/* 499:    */   }
/* 500:    */   
/* 501:    */   private static String getHtmlLabelText(String text)
/* 502:    */   {
/* 503:462 */     if ((text != null) && (!text.isEmpty()))
/* 504:    */     {
/* 505:463 */       text = text.trim();
/* 506:464 */       while (text.contains("\\n"))
/* 507:    */       {
/* 508:465 */         int index = text.indexOf("\\n");
/* 509:466 */         String leading = text.substring(0, index).trim();
/* 510:467 */         String tailing = text.substring(index + 2).trim();
/* 511:468 */         text = leading + "<br>" + tailing;
/* 512:    */       }
/* 513:470 */       text = "<html><center>" + text + "</center></html>";
/* 514:    */       
/* 515:472 */       return text;
/* 516:    */     }
/* 517:474 */     return null;
/* 518:    */   }
/* 519:    */   
/* 520:    */   private static int getArrowDirection(String directionInXML)
/* 521:    */   {
/* 522:478 */     if (directionInXML.equalsIgnoreCase("right")) {
/* 523:479 */       return 3;
/* 524:    */     }
/* 525:481 */     if (directionInXML.equalsIgnoreCase("left")) {
/* 526:482 */       return 7;
/* 527:    */     }
/* 528:484 */     if (directionInXML.equalsIgnoreCase("up")) {
/* 529:485 */       return 1;
/* 530:    */     }
/* 531:487 */     if (directionInXML.equalsIgnoreCase("down")) {
/* 532:488 */       return 5;
/* 533:    */     }
/* 534:490 */     if (directionInXML.equalsIgnoreCase("right_up")) {
/* 535:491 */       return 2;
/* 536:    */     }
/* 537:493 */     if (directionInXML.equalsIgnoreCase("right_down")) {
/* 538:494 */       return 4;
/* 539:    */     }
/* 540:496 */     if (directionInXML.equalsIgnoreCase("left_up")) {
/* 541:497 */       return 8;
/* 542:    */     }
/* 543:499 */     if (directionInXML.equalsIgnoreCase("left_down")) {
/* 544:500 */       return 6;
/* 545:    */     }
/* 546:503 */     throw new RuntimeException("Unknown direction: " + directionInXML);
/* 547:    */   }
/* 548:    */   
/* 549:    */   private static void readNodeButtons(org.w3c.dom.Node moduleNode, FreeNode twaverNode, ActionListener action)
/* 550:    */   {
/* 551:507 */     NodeList buttons = moduleNode.getChildNodes();
/* 552:508 */     if (buttons != null) {
/* 553:509 */       for (int i = 0; i < buttons.getLength(); i++)
/* 554:    */       {
/* 555:510 */         org.w3c.dom.Node buttonNode = buttons.item(i);
/* 556:511 */         if (buttonNode.getNodeType() == 1)
/* 557:    */         {
/* 558:512 */           boolean isButton1 = buttonNode.getNodeName().equalsIgnoreCase("button1");
/* 559:513 */           boolean isButton2 = buttonNode.getNodeName().equalsIgnoreCase("button2");
/* 560:514 */           boolean isButton3 = buttonNode.getNodeName().equalsIgnoreCase("button3");
/* 561:515 */           if ((isButton1) || (isButton2) || (isButton3))
/* 562:    */           {
/* 563:516 */             String tooltip = getStringAttribute(buttonNode, "tooltip");
/* 564:517 */             String iconURL = getStringAttribute(buttonNode, "icon");
/* 565:518 */             String command = getStringAttribute(buttonNode, "action");
/* 566:520 */             if (isButton1)
/* 567:    */             {
/* 568:521 */               twaverNode.setButtonTooltip1(tooltip);
/* 569:522 */               twaverNode.setButtonIcon1(iconURL);
/* 570:523 */               twaverNode.setActionCommand1(command);
/* 571:524 */               twaverNode.setButtonAction1(action);
/* 572:    */             }
/* 573:526 */             if (isButton2)
/* 574:    */             {
/* 575:527 */               twaverNode.setButtonTooltip2(tooltip);
/* 576:528 */               twaverNode.setButtonIcon2(iconURL);
/* 577:529 */               twaverNode.setActionCommand2(command);
/* 578:530 */               twaverNode.setButtonAction2(action);
/* 579:    */             }
/* 580:532 */             if (isButton3)
/* 581:    */             {
/* 582:533 */               twaverNode.setButtonTooltip3(tooltip);
/* 583:534 */               twaverNode.setButtonIcon3(iconURL);
/* 584:535 */               twaverNode.setActionCommand3(command);
/* 585:536 */               twaverNode.setButtonAction3(action);
/* 586:    */             }
/* 587:    */           }
/* 588:    */         }
/* 589:    */       }
/* 590:    */     }
/* 591:    */   }
/* 592:    */   
/* 593:    */   public static FreePagePane getPagePane(Component component)
/* 594:    */   {
/* 595:545 */     if ((component != null) && 
/* 596:546 */       (component.getParent() != null))
/* 597:    */     {
/* 598:547 */       Component parent = component.getParent();
/* 599:548 */       if ((parent instanceof FreePagePane)) {
/* 600:549 */         return (FreePagePane)parent;
/* 601:    */       }
/* 602:551 */       return getPagePane(parent);
/* 603:    */     }
/* 604:555 */     return null;
/* 605:    */   }
/* 606:    */   
/* 607:    */   public static Image iconToImage(Icon icon)
/* 608:    */   {
/* 609:559 */     if ((icon instanceof ImageIcon)) {
/* 610:560 */       return ((ImageIcon)icon).getImage();
/* 611:    */     }
/* 612:562 */     int w = icon.getIconWidth();
/* 613:563 */     int h = icon.getIconHeight();
/* 614:564 */     BufferedImage image = new BufferedImage(w, h, 2);
/* 615:565 */     Graphics2D g = image.createGraphics();
/* 616:566 */     icon.paintIcon(null, g, 0, 0);
/* 617:567 */     g.dispose();
/* 618:568 */     return image;
/* 619:    */   }
/* 620:    */   
/* 621:    */   public static ImageIcon createDyedIcon(ImageIcon icon, Color color)
/* 622:    */   {
/* 623:573 */     return createDyedIcon(icon, color, false);
/* 624:    */   }
/* 625:    */   
/* 626:    */   public static ImageIcon createDyedIcon(ImageIcon icon, Color color, boolean useTWaverFilter)
/* 627:    */   {
/* 628:577 */     if (color == null) {
/* 629:578 */       return icon;
/* 630:    */     }
/* 631:580 */     int iconWidth = icon.getIconWidth();
/* 632:581 */     int iconHeight = icon.getIconHeight();
/* 633:582 */     BufferedImage bi = new BufferedImage(iconWidth, iconHeight, 2);
/* 634:583 */     Graphics2D g2d = bi.createGraphics();
/* 635:584 */     icon.paintIcon(null, g2d, 0, 0);
/* 636:585 */     g2d.dispose();
/* 637:586 */     Image dyedImage = createDyedImage(bi, color, useTWaverFilter);
/* 638:587 */     return new ImageIcon(dyedImage);
/* 639:    */   }
/* 640:    */   
/* 641:    */   public static Image createDyedImage(Image image, Color color, boolean useTWaverFilter)
/* 642:    */   {
/* 643:592 */     if (color == null) {
/* 644:593 */       return image;
/* 645:    */     }
/* 646:595 */     if (image != null)
/* 647:    */     {
/* 648:596 */       int w = image.getWidth(null);
/* 649:597 */       int h = image.getHeight(null);
/* 650:    */       
/* 651:599 */       int[] pixels = new int[w * h];
/* 652:600 */       PixelGrabber pg = new PixelGrabber(image, 0, 0, w, h, pixels, 0, w);
/* 653:    */       try
/* 654:    */       {
/* 655:602 */         pg.grabPixels();
/* 656:    */       }
/* 657:    */       catch (InterruptedException ex)
/* 658:    */       {
/* 659:604 */         ex.printStackTrace();
/* 660:605 */         return null;
/* 661:    */       }
/* 662:608 */       BufferedImage bi = new BufferedImage(w > 1 ? w : 1, h > 1 ? h : 1, 2);
/* 663:    */       
/* 664:    */ 
/* 665:611 */       PixelFilter pixelFilter = TWaverUtil.getPixelFilter();
/* 666:612 */       for (int i = 0; i < pixels.length; i++)
/* 667:    */       {
/* 668:613 */         int pixel = pixels[i];
/* 669:614 */         int row = i / w;
/* 670:615 */         int col = i % w;
/* 671:616 */         if ((color != null) && 
/* 672:617 */           (pixel != 0)) {
/* 673:618 */           if (useTWaverFilter) {
/* 674:619 */             pixel = pixelFilter.filter(pixel, color);
/* 675:    */           } else {
/* 676:621 */             pixel = color.getRGB();
/* 677:    */           }
/* 678:    */         }
/* 679:625 */         bi.setRGB(col, row, pixel);
/* 680:    */       }
/* 681:628 */       return bi;
/* 682:    */     }
/* 683:630 */     return null;
/* 684:    */   }
/* 685:    */   
/* 686:    */   public static Icon createMovedIcon(Icon icon)
/* 687:    */   {
/* 688:636 */     return createMovedIcon(icon, 1, 1);
/* 689:    */   }
/* 690:    */   
/* 691:    */   public static Icon createMovedIcon(Icon icon, final int offsetX, final int offsetY)
/* 692:    */   {
/* 693:640 */     new Icon()
/* 694:    */     {
/* 695:    */       public void paintIcon(Component c, Graphics g, int x, int y)
/* 696:    */       {
/* 697:643 */         this.val$icon.paintIcon(c, g, x + offsetX, y + offsetY);
/* 698:    */       }
/* 699:    */       
/* 700:    */       public int getIconWidth()
/* 701:    */       {
/* 702:647 */         return this.val$icon.getIconWidth();
/* 703:    */       }
/* 704:    */       
/* 705:    */       public int getIconHeight()
/* 706:    */       {
/* 707:651 */         return this.val$icon.getIconHeight();
/* 708:    */       }
/* 709:    */     };
/* 710:    */   }
/* 711:    */   
/* 712:    */   public static void setupLookAndFeel()
/* 713:    */   {
/* 714:657 */     Locale.setDefault(TWaverConst.EN_US);
/* 715:658 */     TWaverUtil.setLocale(TWaverConst.EN_US);
/* 716:659 */     PlasticTheme theme = new ExperienceGreen()
/* 717:    */     {
/* 718:    */       public FontUIResource getControlTextFont()
/* 719:    */       {
/* 720:663 */         return new FontUIResource(new Font("Calibri", 0, 11));
/* 721:    */       }
/* 722:665 */     };
/* 723:666 */     PlasticLookAndFeel.setPlasticTheme(theme);
/* 724:    */     try
/* 725:    */     {
/* 726:668 */       UIManager.setLookAndFeel("com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
/* 727:    */     }
/* 728:    */     catch (Exception ex)
/* 729:    */     {
/* 730:670 */       ex.printStackTrace();
/* 731:    */     }
/* 732:673 */     UIManager.getDefaults().put("TabbedPaneUI", FreeTabbedPaneUI.class.getName());
/* 733:674 */     UIManager.put("Menu.selectionBackground", NO_COLOR);
/* 734:675 */     UIManager.put("MenuItem.selectionBackground", MENUITEM_SELECTED_BACKGROUND);
/* 735:676 */     UIManager.put("PopupMenu.border", new FreePopupMenuBorder());
/* 736:677 */     UIManager.put("ToolTip.font", FONT_14_BOLD);
/* 737:678 */     UIManager.put("TabbedPane.contentBorderInsets", ZERO_INSETS);
/* 738:679 */     UIManager.put("TabbedPane.tabInsets", ZERO_INSETS);
/* 739:680 */     UIManager.put("TabbedPane.selectedTabPadInsets", ZERO_INSETS);
/* 740:681 */     UIManager.put("TabbedPane.tabAreaInsets", ZERO_INSETS);
/* 741:    */   }
/* 742:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeUtil
 * JD-Core Version:    0.7.0.1
 */
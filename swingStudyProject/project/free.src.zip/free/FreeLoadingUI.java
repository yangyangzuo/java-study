/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import com.sun.awt.AWTUtilities;
/*  4:   */ import java.awt.Container;
/*  5:   */ import java.awt.Dialog;
/*  6:   */ import java.awt.Frame;
/*  7:   */ import java.net.URL;
/*  8:   */ import javax.swing.Icon;
/*  9:   */ import javax.swing.ImageIcon;
/* 10:   */ import javax.swing.JDialog;
/* 11:   */ import javax.swing.JLabel;
/* 12:   */ import twaver.TWaverUtil;
/* 13:   */ 
/* 14:   */ public class FreeLoadingUI
/* 15:   */   extends JDialog
/* 16:   */ {
/* 17:17 */   private String imageURL = FreeUtil.getImageURL("loading.gif");
/* 18:18 */   private ImageIcon imageIcon = TWaverUtil.getImageIcon(this.imageURL);
/* 19:19 */   private int imageWidth = this.imageIcon.getIconWidth();
/* 20:20 */   private int imageHeight = this.imageIcon.getIconHeight();
/* 21:21 */   private static FreeLoadingUI instance = null;
/* 22:   */   
/* 23:   */   private FreeLoadingUI(Dialog parent)
/* 24:   */   {
/* 25:24 */     super(parent);
/* 26:25 */     init();
/* 27:   */   }
/* 28:   */   
/* 29:   */   private FreeLoadingUI(Frame parent)
/* 30:   */   {
/* 31:29 */     super(parent);
/* 32:30 */     init();
/* 33:   */   }
/* 34:   */   
/* 35:   */   private void init()
/* 36:   */   {
/* 37:34 */     setModal(true);
/* 38:35 */     setUndecorated(true);
/* 39:36 */     AWTUtilities.setWindowOpaque(this, false);
/* 40:37 */     URL url = Class.class.getResource(this.imageURL);
/* 41:38 */     Icon icon = new ImageIcon(url);
/* 42:39 */     JLabel label = new JLabel(icon);
/* 43:40 */     getContentPane().add(label, "Center");
/* 44:41 */     setDefaultCloseOperation(2);
/* 45:42 */     setSize(this.imageWidth, this.imageHeight);
/* 46:43 */     TWaverUtil.centerWindow(this);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static FreeLoadingUI showInstance(Dialog parent)
/* 50:   */   {
/* 51:47 */     if ((instance != null) && (instance.isShowing())) {
/* 52:48 */       instance.dispose();
/* 53:   */     }
/* 54:50 */     instance = new FreeLoadingUI(parent);
/* 55:51 */     instance.setVisible(true);
/* 56:52 */     return instance;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static FreeLoadingUI createInstance(Frame parent)
/* 60:   */   {
/* 61:56 */     if ((instance != null) && (instance.isShowing())) {
/* 62:57 */       instance.dispose();
/* 63:   */     }
/* 64:59 */     instance = new FreeLoadingUI(parent);
/* 65:60 */     return instance;
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeLoadingUI
 * JD-Core Version:    0.7.0.1
 */
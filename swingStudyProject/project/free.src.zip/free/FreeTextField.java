/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Graphics2D;
/*  7:   */ import java.awt.Image;
/*  8:   */ import java.awt.TexturePaint;
/*  9:   */ import javax.swing.BorderFactory;
/* 10:   */ import javax.swing.ImageIcon;
/* 11:   */ import javax.swing.JTextField;
/* 12:   */ import javax.swing.border.Border;
/* 13:   */ import javax.swing.plaf.metal.MetalTextFieldUI;
/* 14:   */ import twaver.TWaverUtil;
/* 15:   */ 
/* 16:   */ public class FreeTextField
/* 17:   */   extends JTextField
/* 18:   */ {
/* 19:18 */   private String backgroundImageURL = FreeUtil.getImageURL("textfield_background.png");
/* 20:19 */   private Image backgroundLeftImage = FreeUtil.getImage("textfield_background_left.png");
/* 21:20 */   private Image backgroundRightImage = FreeUtil.getImage("textfield_background_right.png");
/* 22:21 */   private ImageIcon backgroundImageIcon = TWaverUtil.getImageIcon(this.backgroundImageURL);
/* 23:22 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 24:23 */   private Border border = BorderFactory.createEmptyBorder(1, 3, 1, 3);
/* 25:24 */   private Font font = FreeUtil.FONT_12_PLAIN;
/* 26:   */   
/* 27:   */   public FreeTextField()
/* 28:   */   {
/* 29:27 */     this(null);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public FreeTextField(String text)
/* 33:   */   {
/* 34:31 */     super(text);
/* 35:32 */     init();
/* 36:   */   }
/* 37:   */   
/* 38:   */   private void init()
/* 39:   */   {
/* 40:36 */     setBorder(this.border);
/* 41:37 */     setUI(new MetalTextFieldUI()
/* 42:   */     {
/* 43:   */       protected void paintBackground(Graphics g)
/* 44:   */       {
/* 45:41 */         Graphics2D g2d = (Graphics2D)g;
/* 46:42 */         g2d.setPaint(FreeTextField.this.paint);
/* 47:43 */         g2d.fillRect(0, 0, FreeTextField.this.getWidth(), FreeTextField.this.getHeight());
/* 48:   */         
/* 49:   */ 
/* 50:46 */         g2d.drawImage(FreeTextField.this.backgroundLeftImage, 0, 0, null);
/* 51:   */         
/* 52:   */ 
/* 53:49 */         g2d.drawImage(FreeTextField.this.backgroundRightImage, FreeTextField.this.getWidth() - FreeTextField.this.backgroundRightImage.getWidth(null), 0, null);
/* 54:   */       }
/* 55:51 */     });
/* 56:52 */     setFont(this.font);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public Dimension getPreferredSize()
/* 60:   */   {
/* 61:57 */     return new Dimension(super.getPreferredSize().width, this.backgroundImageIcon.getIconHeight());
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTextField
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import java.lang.management.ManagementFactory;
/*  6:   */ import java.lang.management.MemoryMXBean;
/*  7:   */ import java.lang.management.MemoryUsage;
/*  8:   */ import java.text.NumberFormat;
/*  9:   */ import javax.swing.Timer;
/* 10:   */ 
/* 11:   */ public class FreeMemoryBar
/* 12:   */   extends FreeProgressBar
/* 13:   */ {
/* 14:   */   private static final int kilo = 1024;
/* 15:   */   private static final String mega = "M";
/* 16:14 */   private static MemoryMXBean memorymbean = ;
/* 17:15 */   private static NumberFormat format = NumberFormat.getInstance();
/* 18:16 */   private int delay = 2000;
/* 19:   */   
/* 20:   */   public FreeMemoryBar()
/* 21:   */   {
/* 22:19 */     super(0, 0, 100);
/* 23:20 */     ActionListener taskPerformer = new ActionListener()
/* 24:   */     {
/* 25:   */       public void actionPerformed(ActionEvent evt)
/* 26:   */       {
/* 27:23 */         long usedMemory = FreeMemoryBar.memorymbean.getHeapMemoryUsage().getUsed();
/* 28:24 */         long totalMemory = FreeMemoryBar.memorymbean.getHeapMemoryUsage().getMax();
/* 29:25 */         FreeMemoryBar.this.updateMemoryUsage(usedMemory, totalMemory);
/* 30:   */       }
/* 31:27 */     };
/* 32:28 */     new Timer(this.delay, taskPerformer).start();
/* 33:   */   }
/* 34:   */   
/* 35:   */   private void updateMemoryUsage(long usedMemory, long totalMemory)
/* 36:   */   {
/* 37:32 */     int percent = (int)(usedMemory * 100L / totalMemory);
/* 38:33 */     setValue(percent);
/* 39:34 */     String usedMega = format.format(usedMemory / 1024L / 1024L) + "M";
/* 40:35 */     String totalMega = format.format(totalMemory / 1024L / 1024L) + "M";
/* 41:36 */     String message = usedMega + "/" + totalMega;
/* 42:37 */     setString(message);
/* 43:   */     
/* 44:39 */     setToolTipText("Memory used " + format.format(usedMemory) + " of total " + format.format(totalMemory));
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeMemoryBar
 * JD-Core Version:    0.7.0.1
 */
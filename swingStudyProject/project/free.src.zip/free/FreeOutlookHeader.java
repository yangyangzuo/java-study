/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionListener;
/*  4:   */ import javax.swing.BorderFactory;
/*  5:   */ import javax.swing.Icon;
/*  6:   */ import javax.swing.ImageIcon;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import javax.swing.JLabel;
/*  9:   */ import javax.swing.JPanel;
/* 10:   */ import javax.swing.border.Border;
/* 11:   */ import twaver.swing.SingleFiledLayout;
/* 12:   */ 
/* 13:   */ public class FreeOutlookHeader
/* 14:   */   extends FreeHeader
/* 15:   */ {
/* 16:16 */   private SingleFiledLayout toolbarLayout = new SingleFiledLayout(1, 0, 2);
/* 17:20 */   private JPanel toolbar = new JPanel(this.toolbarLayout);
/* 18:21 */   private ImageIcon separatorIcon = FreeUtil.getImageIcon("toolbar_separator.png");
/* 19:   */   
/* 20:   */   public FreeOutlookHeader()
/* 21:   */   {
/* 22:24 */     init();
/* 23:   */   }
/* 24:   */   
/* 25:   */   private void init()
/* 26:   */   {
/* 27:28 */     this.toolbar.setOpaque(false);
/* 28:29 */     this.toolbar.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));
/* 29:   */     
/* 30:31 */     add(this.toolbar, "Center");
/* 31:   */   }
/* 32:   */   
/* 33:   */   public FreeToolbarButton addButton(Icon icon, String tooltip, ActionListener action, String command)
/* 34:   */   {
/* 35:35 */     FreeToolbarButton button = new FreeToolbarButton();
/* 36:36 */     button.setIcon(icon);
/* 37:37 */     button.setToolTipText(tooltip);
/* 38:38 */     if (action != null) {
/* 39:39 */       button.addActionListener(action);
/* 40:   */     }
/* 41:41 */     button.setActionCommand(command);
/* 42:42 */     this.toolbar.add(button);
/* 43:43 */     return button;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void addSeparator()
/* 47:   */   {
/* 48:47 */     this.toolbar.add(new JLabel(this.separatorIcon));
/* 49:   */   }
/* 50:   */   
/* 51:   */   protected Object getResizeHandlerLayoutConstraint()
/* 52:   */   {
/* 53:52 */     return "East";
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected Object getShrinkHandlerLayoutConstraint()
/* 57:   */   {
/* 58:57 */     return "West";
/* 59:   */   }
/* 60:   */   
/* 61:   */   protected FreeListSplitListener createSplitListener()
/* 62:   */   {
/* 63:62 */     return new FreeOutlookSplitListener(this);
/* 64:   */   }
/* 65:   */   
/* 66:   */   protected Border createBorder()
/* 67:   */   {
/* 68:67 */     return BorderFactory.createEmptyBorder(4, 0, 0, 7);
/* 69:   */   }
/* 70:   */   
/* 71:   */   protected ImageIcon getShrinkIcon(boolean shrinked)
/* 72:   */   {
/* 73:72 */     if (shrinked) {
/* 74:73 */       return RIGHT_ARROW_ICON;
/* 75:   */     }
/* 76:75 */     return LEFT_ARROW_ICON;
/* 77:   */   }
/* 78:   */   
/* 79:   */   protected JComponent getCenterComponent()
/* 80:   */   {
/* 81:81 */     return null;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public void setShrink(boolean shrinked)
/* 85:   */   {
/* 86:86 */     super.setShrink(shrinked);
/* 87:87 */     this.toolbar.setVisible(!shrinked);
/* 88:   */   }
/* 89:   */   
/* 90:   */   protected int getShrinkedWidth()
/* 91:   */   {
/* 92:92 */     return 37;
/* 93:   */   }
/* 94:   */   
/* 95:   */   public JPanel getToolBar()
/* 96:   */   {
/* 97:96 */     return this.toolbar;
/* 98:   */   }
/* 99:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookHeader
 * JD-Core Version:    0.7.0.1
 */
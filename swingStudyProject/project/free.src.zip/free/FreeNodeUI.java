/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Graphics2D;
/*  4:   */ import java.awt.Image;
/*  5:   */ import java.awt.Point;
/*  6:   */ import java.awt.Rectangle;
/*  7:   */ import twaver.Element;
/*  8:   */ import twaver.TWaverUtil;
/*  9:   */ import twaver.network.ui.NodeUI;
/* 10:   */ 
/* 11:   */ public class FreeNodeUI
/* 12:   */   extends NodeUI
/* 13:   */ {
/* 14:11 */   private int imageContentWidth = 100;
/* 15:12 */   private int moduleIconY = 12;
/* 16:13 */   private Image selectedImage = FreeUtil.getImage("module_node_selected.png");
/* 17:   */   
/* 18:   */   public FreeNodeUI(FreeNetwork network, FreeNode node)
/* 19:   */   {
/* 20:16 */     super(network, node);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void paintBody(Graphics2D g2d)
/* 24:   */   {
/* 25:21 */     super.paintBody(g2d);
/* 26:   */     
/* 27:23 */     FreeNode node = (FreeNode)getNode();
/* 28:24 */     if (node.isSelected()) {
/* 29:25 */       g2d.drawImage(this.selectedImage, node.getLocation().x, node.getLocation().y, null);
/* 30:   */     }
/* 31:28 */     Rectangle bounds = this.element.getBounds();
/* 32:29 */     if (node.getModuleIcon() != null)
/* 33:   */     {
/* 34:30 */       Image image = TWaverUtil.getImage(node.getModuleIcon());
/* 35:31 */       if (image != null)
/* 36:   */       {
/* 37:32 */         int x = bounds.x + (this.imageContentWidth - image.getWidth(null)) / 2;
/* 38:33 */         int y = bounds.y + this.moduleIconY;
/* 39:34 */         g2d.drawImage(image, x, y, null);
/* 40:   */       }
/* 41:   */     }
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeNodeUI
 * JD-Core Version:    0.7.0.1
 */
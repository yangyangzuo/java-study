/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Point;
/*  5:   */ import java.awt.event.MouseEvent;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ 
/*  8:   */ public class FreeOutlookSplitListener
/*  9:   */   extends FreeListSplitListener
/* 10:   */ {
/* 11:   */   public FreeOutlookSplitListener(FreeOutlookHeader header)
/* 12:   */   {
/* 13:11 */     super(header);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void mouseDragged(MouseEvent e)
/* 17:   */   {
/* 18:16 */     if ((!this.header.isShrinked()) && 
/* 19:17 */       (this.lastPoint != null))
/* 20:   */     {
/* 21:18 */       JComponent parent = (JComponent)this.header.getParent();
/* 22:19 */       Dimension size = parent.getPreferredSize();
/* 23:20 */       Point thisPoint = e.getPoint();
/* 24:21 */       int xMovement = thisPoint.x - this.lastPoint.x;
/* 25:22 */       size.width += xMovement;
/* 26:23 */       size.width = Math.max(size.width, 37);
/* 27:24 */       parent.setPreferredSize(size);
/* 28:25 */       this.header.revalidateParent();
/* 29:   */     }
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookSplitListener
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import com.sun.awt.AWTUtilities;
/*   4:    */ import java.awt.BorderLayout;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Graphics2D;
/*   7:    */ import java.awt.Point;
/*   8:    */ import java.awt.Rectangle;
/*   9:    */ import java.awt.TexturePaint;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.ActionListener;
/*  12:    */ import java.awt.event.MouseAdapter;
/*  13:    */ import java.awt.event.MouseEvent;
/*  14:    */ import java.util.Locale;
/*  15:    */ import javax.swing.BorderFactory;
/*  16:    */ import javax.swing.ImageIcon;
/*  17:    */ import javax.swing.JButton;
/*  18:    */ import javax.swing.JCheckBox;
/*  19:    */ import javax.swing.JComponent;
/*  20:    */ import javax.swing.JFrame;
/*  21:    */ import javax.swing.JLabel;
/*  22:    */ import javax.swing.JPanel;
/*  23:    */ import javax.swing.SwingUtilities;
/*  24:    */ import twaver.TWaverUtil;
/*  25:    */ import twaver.swing.LabelValueLayout;
/*  26:    */ 
/*  27:    */ public class FreeLoginUI
/*  28:    */   extends JFrame
/*  29:    */ {
/*  30: 28 */   private int width = 332;
/*  31: 29 */   private int height = 344;
/*  32: 30 */   private ImageIcon buttonIcon = FreeUtil.getImageIcon("login_button.png");
/*  33: 31 */   private ImageIcon buttonRoverIcon = FreeUtil.getImageIcon("login_button_rover.png");
/*  34: 32 */   private ImageIcon buttonPressedIcon = FreeUtil.getImageIcon("login_button_pressed.png");
/*  35: 33 */   private ImageIcon logoIcon = FreeUtil.getImageIcon("login_logo.png");
/*  36: 34 */   private String logoRoverURL = FreeUtil.getImageURL("login_logo_rover.png");
/*  37: 35 */   private ImageIcon logoRoverIcon = TWaverUtil.getImageIcon(this.logoRoverURL);
/*  38: 36 */   private JLabel logoLabel = createDraggableLabel(this.logoIcon);
/*  39: 37 */   private JButton btnLogin = new JButton();
/*  40: 38 */   private JPanel inputPane = new JPanel()
/*  41:    */   {
/*  42: 40 */     private String backgroundImageURL = FreeUtil.getImageURL("login_background.png");
/*  43: 41 */     private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/*  44:    */     
/*  45:    */     protected void paintComponent(Graphics g)
/*  46:    */     {
/*  47: 45 */       super.paintComponent(g);
/*  48:    */       
/*  49: 47 */       Graphics2D g2d = (Graphics2D)g;
/*  50: 48 */       g2d.setPaint(this.paint);
/*  51: 49 */       g2d.fillRect(0, 0, getWidth(), getHeight());
/*  52:    */     }
/*  53:    */   };
/*  54: 52 */   private MouseAdapter moveWindowListener = new MouseAdapter()
/*  55:    */   {
/*  56: 54 */     private Point lastPoint = null;
/*  57:    */     
/*  58:    */     public void mousePressed(MouseEvent e)
/*  59:    */     {
/*  60: 58 */       this.lastPoint = e.getLocationOnScreen();
/*  61:    */     }
/*  62:    */     
/*  63:    */     public void mouseDragged(MouseEvent e)
/*  64:    */     {
/*  65: 63 */       Point point = e.getLocationOnScreen();
/*  66: 64 */       int offsetX = point.x - this.lastPoint.x;
/*  67: 65 */       int offsetY = point.y - this.lastPoint.y;
/*  68: 66 */       Rectangle bounds = FreeLoginUI.this.getBounds();
/*  69: 67 */       bounds.x += offsetX;
/*  70: 68 */       bounds.y += offsetY;
/*  71: 69 */       FreeLoginUI.this.setBounds(bounds);
/*  72: 70 */       this.lastPoint = point;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public void mouseEntered(MouseEvent e)
/*  76:    */     {
/*  77: 75 */       if (e.getSource() == FreeLoginUI.this.logoLabel) {
/*  78: 76 */         FreeLoginUI.this.logoLabel.setIcon(FreeLoginUI.this.logoRoverIcon);
/*  79:    */       }
/*  80:    */     }
/*  81:    */     
/*  82:    */     public void mouseExited(MouseEvent e)
/*  83:    */     {
/*  84: 82 */       if (e.getSource() == FreeLoginUI.this.logoLabel) {
/*  85: 83 */         FreeLoginUI.this.logoLabel.setIcon(FreeLoginUI.this.logoIcon);
/*  86:    */       }
/*  87:    */     }
/*  88:    */   };
/*  89:    */   
/*  90:    */   public FreeLoginUI()
/*  91:    */   {
/*  92: 89 */     init();
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void init()
/*  96:    */   {
/*  97: 93 */     setDefaultCloseOperation(2);
/*  98: 94 */     setUndecorated(true);
/*  99:    */     
/* 100: 96 */     AWTUtilities.setWindowOpaque(this, false);
/* 101:    */     
/* 102: 98 */     JPanel centerPane = new JPanel(new BorderLayout());
/* 103: 99 */     centerPane.add(this.btnLogin, "South");
/* 104:100 */     setContentPane(centerPane);
/* 105:101 */     setSize(this.width, this.height);
/* 106:102 */     TWaverUtil.centerWindow(this);
/* 107:    */     
/* 108:104 */     this.btnLogin.setBorder(null);
/* 109:105 */     this.btnLogin.setMargin(null);
/* 110:106 */     this.btnLogin.setOpaque(false);
/* 111:107 */     this.btnLogin.setIcon(this.buttonIcon);
/* 112:108 */     this.btnLogin.setRolloverEnabled(true);
/* 113:109 */     this.btnLogin.setRolloverIcon(this.buttonRoverIcon);
/* 114:110 */     this.btnLogin.setPressedIcon(this.buttonPressedIcon);
/* 115:111 */     this.btnLogin.setContentAreaFilled(false);
/* 116:112 */     this.btnLogin.setRequestFocusEnabled(false);
/* 117:113 */     this.btnLogin.addActionListener(new ActionListener()
/* 118:    */     {
/* 119:    */       public void actionPerformed(ActionEvent e)
/* 120:    */       {
/* 121:116 */         FreeLoginUI.this.login();
/* 122:    */       }
/* 123:119 */     });
/* 124:120 */     JPanel topPane = new JPanel(new BorderLayout());
/* 125:    */     
/* 126:122 */     this.logoLabel.setOpaque(false);
/* 127:123 */     topPane.setOpaque(false);
/* 128:    */     
/* 129:125 */     this.logoLabel.addMouseListener(this.moveWindowListener);
/* 130:126 */     this.logoLabel.addMouseMotionListener(this.moveWindowListener);
/* 131:127 */     topPane.addMouseListener(this.moveWindowListener);
/* 132:128 */     topPane.addMouseMotionListener(this.moveWindowListener);
/* 133:    */     
/* 134:130 */     topPane.add(this.logoLabel, "Center");
/* 135:131 */     topPane.add(createDraggableLabel(FreeUtil.getImageIcon("login_left_top.png")), "West");
/* 136:132 */     topPane.add(createDraggableLabel(FreeUtil.getImageIcon("login_right_top.png")), "East");
/* 137:    */     
/* 138:134 */     centerPane.add(createDraggableLabel(FreeUtil.getImageIcon("login_left.png")), "West");
/* 139:135 */     centerPane.add(createDraggableLabel(FreeUtil.getImageIcon("login_right.png")), "East");
/* 140:136 */     centerPane.add(topPane, "North");
/* 141:137 */     centerPane.add(this.inputPane, "Center");
/* 142:    */     
/* 143:139 */     this.inputPane.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
/* 144:140 */     this.inputPane.setLayout(new LabelValueLayout(10, 12, false));
/* 145:141 */     this.inputPane.add(createInputLabel("Server:"));
/* 146:142 */     this.inputPane.add(new FreeTextField("localhost"));
/* 147:143 */     this.inputPane.add(createInputLabel("Company:"));
/* 148:144 */     this.inputPane.add(new FreeSearchTextField());
/* 149:145 */     this.inputPane.add(createInputLabel("User Name:"));
/* 150:146 */     this.inputPane.add(new FreeTextField("admin"));
/* 151:147 */     this.inputPane.add(createInputLabel("Password:"));
/* 152:148 */     this.inputPane.add(new FreePasswordField());
/* 153:149 */     this.inputPane.add(createInputLabel("Language:"));
/* 154:150 */     this.inputPane.add(new FreeTextField(TWaverUtil.getLocale().toString()));
/* 155:151 */     this.inputPane.add(new JLabel());
/* 156:    */     
/* 157:153 */     JCheckBox cbRememberMe = new JCheckBox("Remember me");
/* 158:154 */     cbRememberMe.setOpaque(false);
/* 159:155 */     setupComponent(cbRememberMe);
/* 160:156 */     this.inputPane.add(cbRememberMe);
/* 161:    */     
/* 162:158 */     this.inputPane.addMouseListener(this.moveWindowListener);
/* 163:159 */     this.inputPane.addMouseMotionListener(this.moveWindowListener);
/* 164:    */   }
/* 165:    */   
/* 166:    */   private JLabel createDraggableLabel(ImageIcon icon)
/* 167:    */   {
/* 168:163 */     JLabel label = new JLabel(icon);
/* 169:164 */     label.addMouseListener(this.moveWindowListener);
/* 170:165 */     label.addMouseMotionListener(this.moveWindowListener);
/* 171:166 */     return label;
/* 172:    */   }
/* 173:    */   
/* 174:    */   private JLabel createInputLabel(String text)
/* 175:    */   {
/* 176:170 */     JLabel label = new JLabel(text);
/* 177:171 */     setupComponent(label);
/* 178:172 */     return label;
/* 179:    */   }
/* 180:    */   
/* 181:    */   private void setupComponent(JComponent c)
/* 182:    */   {
/* 183:176 */     c.setFont(FreeUtil.FONT_14_BOLD);
/* 184:177 */     c.setForeground(FreeUtil.DEFAULT_TEXT_COLOR);
/* 185:    */   }
/* 186:    */   
/* 187:    */   protected void login() {}
/* 188:    */   
/* 189:    */   public static void main(String[] args)
/* 190:    */   {
/* 191:203 */     SwingUtilities.invokeLater(new Runnable()
/* 192:    */     {
/* 193:    */       public void run()
/* 194:    */       {
/* 195:206 */         FreeUtil.setupLookAndFeel();
/* 196:207 */         FreeLoginUI ui = new FreeLoginUI();
/* 197:208 */         ui.setVisible(true);
/* 198:    */       }
/* 199:    */     });
/* 200:    */   }
/* 201:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeLoginUI
 * JD-Core Version:    0.7.0.1
 */
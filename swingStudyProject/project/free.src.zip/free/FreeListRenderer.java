/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Font;
/*   8:    */ import javax.swing.BorderFactory;
/*   9:    */ import javax.swing.JLabel;
/*  10:    */ import javax.swing.JList;
/*  11:    */ import javax.swing.JPanel;
/*  12:    */ import javax.swing.OverlayLayout;
/*  13:    */ import twaver.Element;
/*  14:    */ import twaver.Group;
/*  15:    */ import twaver.Node;
/*  16:    */ import twaver.list.TListCellRenderer;
/*  17:    */ 
/*  18:    */ public class FreeListRenderer
/*  19:    */   extends TListCellRenderer
/*  20:    */ {
/*  21: 23 */   private JPanel itemRender = new JPanel(new BorderLayout());
/*  22: 24 */   private int separatorHeight = 30;
/*  23: 25 */   private JPanel separatorRender = new JPanel()
/*  24:    */   {
/*  25:    */     public Dimension getPreferredSize()
/*  26:    */     {
/*  27: 29 */       Dimension size = super.getPreferredSize();
/*  28: 30 */       return new Dimension(size.width, FreeListRenderer.this.separatorHeight);
/*  29:    */     }
/*  30:    */   };
/*  31: 33 */   private JLabel separatorLabel = new JLabel();
/*  32: 34 */   private FreeSeparator separator = new FreeSeparator(0);
/*  33: 35 */   private Color itemTextColor = FreeUtil.LIST_TEXT_COLOR;
/*  34: 36 */   private Color separatorTextColor = Color.white;
/*  35: 37 */   private Color itemSelectedBackground = new Color(199, 198, 200);
/*  36: 38 */   private Color itemSelectedBorder = new Color(163, 163, 163);
/*  37: 39 */   private Font separatorFont = FreeUtil.FONT_12_BOLD;
/*  38:    */   
/*  39:    */   public FreeListRenderer(FreeList list)
/*  40:    */   {
/*  41: 42 */     super(list);
/*  42:    */     
/*  43: 44 */     this.itemRender.setOpaque(false);
/*  44: 45 */     this.itemRender.add(this, "Center");
/*  45: 46 */     this.separatorRender.setLayout(new OverlayLayout(this.separatorRender));
/*  46:    */     
/*  47: 48 */     JPanel separatorHelpPane = new JPanel(new BorderLayout());
/*  48: 49 */     separatorHelpPane.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));
/*  49: 50 */     separatorHelpPane.add(this.separator);
/*  50: 51 */     separatorHelpPane.setOpaque(false);
/*  51: 52 */     this.separatorRender.setOpaque(false);
/*  52: 53 */     this.separatorLabel.setOpaque(true);
/*  53: 54 */     this.separatorLabel.setBackground(FreeUtil.LIST_BACKGROUND);
/*  54: 55 */     this.separatorLabel.setForeground(this.separatorTextColor);
/*  55: 56 */     this.separatorLabel.setFont(this.separatorFont);
/*  56: 57 */     this.separatorLabel.setVerticalAlignment(1);
/*  57: 58 */     this.separatorLabel.setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
/*  58: 59 */     JPanel labelHelpPane = new JPanel(new BorderLayout());
/*  59: 60 */     labelHelpPane.setBorder(BorderFactory.createEmptyBorder(6, 15, 0, 0));
/*  60: 61 */     labelHelpPane.add(this.separatorLabel, "West");
/*  61: 62 */     labelHelpPane.setOpaque(false);
/*  62:    */     
/*  63: 64 */     this.separatorRender.add(labelHelpPane);
/*  64: 65 */     this.separatorRender.add(separatorHelpPane);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*  68:    */   {
/*  69: 71 */     if ((value instanceof Group))
/*  70:    */     {
/*  71: 72 */       String groupName = ((Group)value).getName();
/*  72: 73 */       this.separatorLabel.setText(groupName);
/*  73: 74 */       this.separatorRender.setToolTipText(groupName);
/*  74: 77 */       if ((list.getParent() instanceof FreeListPane))
/*  75:    */       {
/*  76: 78 */         FreeListPane pane = (FreeListPane)list.getParent();
/*  77: 79 */         if (pane.isShrinked())
/*  78:    */         {
/*  79: 80 */           this.separatorLabel.setText(" ");
/*  80: 81 */           this.separatorLabel.setOpaque(false);
/*  81:    */         }
/*  82:    */         else
/*  83:    */         {
/*  84: 83 */           this.separatorLabel.setOpaque(true);
/*  85:    */         }
/*  86:    */       }
/*  87: 87 */       return this.separatorRender;
/*  88:    */     }
/*  89: 89 */     super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/*  90:    */     
/*  91:    */ 
/*  92: 92 */     setToolTipText(getText());
/*  93: 93 */     if ((value instanceof Node))
/*  94:    */     {
/*  95: 94 */       Node node = (Node)value;
/*  96: 95 */       if (node.getToolTipText() != null)
/*  97:    */       {
/*  98: 96 */         String tooltip = "<html>" + getText() + "<br>" + node.getToolTipText() + "</html>";
/*  99: 97 */         this.itemRender.setToolTipText(tooltip);
/* 100:    */       }
/* 101:    */     }
/* 102:101 */     if ((list.getParent() instanceof FreeListPane))
/* 103:    */     {
/* 104:102 */       FreeListPane pane = (FreeListPane)list.getParent();
/* 105:103 */       if (pane.isShrinked())
/* 106:    */       {
/* 107:104 */         setBorder(BorderFactory.createEmptyBorder(2, 7, 1, 2));
/* 108:105 */         setText("");
/* 109:    */       }
/* 110:    */       else
/* 111:    */       {
/* 112:107 */         setBorder(BorderFactory.createEmptyBorder(2, 20, 1, 2));
/* 113:    */       }
/* 114:    */     }
/* 115:110 */     if (isSelected)
/* 116:    */     {
/* 117:111 */       setBackground(this.itemSelectedBackground);
/* 118:112 */       this.itemRender.setBorder(BorderFactory.createLineBorder(this.itemSelectedBorder));
/* 119:    */     }
/* 120:    */     else
/* 121:    */     {
/* 122:114 */       this.itemRender.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
/* 123:    */     }
/* 124:116 */     setForeground(this.itemTextColor);
/* 125:118 */     if (((Element)value).getIconURL().equals("-")) {
/* 126:119 */       setIcon(FreeUtil.BLANK_ICON);
/* 127:    */     }
/* 128:121 */     return this.itemRender;
/* 129:    */   }
/* 130:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeListRenderer
 * JD-Core Version:    0.7.0.1
 */
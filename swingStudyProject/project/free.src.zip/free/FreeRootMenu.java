/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Graphics2D;
/*  6:   */ import java.awt.TexturePaint;
/*  7:   */ import javax.swing.BorderFactory;
/*  8:   */ import javax.swing.JMenu;
/*  9:   */ import javax.swing.border.Border;
/* 10:   */ 
/* 11:   */ public class FreeRootMenu
/* 12:   */   extends JMenu
/* 13:   */ {
/* 14:13 */   private Color foregroundColor = FreeUtil.DEFAULT_TEXT_COLOR;
/* 15:14 */   private String selectedBackgroundImageURL = FreeUtil.getImageURL("menubar_background_selected.png");
/* 16:15 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.selectedBackgroundImageURL);
/* 17:16 */   private Border border = BorderFactory.createEmptyBorder(0, 5, 0, 4);
/* 18:   */   
/* 19:   */   public FreeRootMenu()
/* 20:   */   {
/* 21:19 */     init();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public FreeRootMenu(String text)
/* 25:   */   {
/* 26:23 */     super(text);
/* 27:24 */     init();
/* 28:   */   }
/* 29:   */   
/* 30:   */   private void init()
/* 31:   */   {
/* 32:28 */     setFont(FreeUtil.FONT_14_BOLD);
/* 33:29 */     setBorder(this.border);
/* 34:30 */     setForeground(this.foregroundColor);
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected void paintComponent(Graphics g)
/* 38:   */   {
/* 39:36 */     if (isSelected())
/* 40:   */     {
/* 41:37 */       Graphics2D g2d = (Graphics2D)g;
/* 42:38 */       g2d.setPaint(this.paint);
/* 43:39 */       g2d.fillRect(0, 0, getWidth(), getHeight());
/* 44:   */       
/* 45:41 */       super.paintComponent(g);
/* 46:   */     }
/* 47:   */     else
/* 48:   */     {
/* 49:43 */       super.paintComponent(g);
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeRootMenu
 * JD-Core Version:    0.7.0.1
 */
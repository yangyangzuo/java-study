/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Cursor;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Insets;
/*  10:    */ import java.util.Hashtable;
/*  11:    */ import javax.swing.Icon;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import twaver.swing.TableLayout;
/*  16:    */ 
/*  17:    */ public class FreeOutlookPane
/*  18:    */   extends JPanel
/*  19:    */ {
/*  20: 19 */   private FreeOutlookHeader header = new FreeOutlookHeader()
/*  21:    */   {
/*  22:    */     public void setShrink(boolean shrinked)
/*  23:    */     {
/*  24: 23 */       super.setShrink(shrinked);
/*  25:    */       
/*  26: 25 */       FreeOutlookPane.this.shrinkChanged(shrinked);
/*  27:    */     }
/*  28:    */   };
/*  29: 28 */   private TableLayout barPaneLayout = new TableLayout();
/*  30: 29 */   private JPanel barPane = new JPanel(this.barPaneLayout);
/*  31: 30 */   private JPanel split = new JPanel();
/*  32: 31 */   private int splitWidth = 1;
/*  33: 32 */   private Color splitColor = new Color(166, 172, 174);
/*  34: 33 */   private JPanel additionalPane = new JPanel(new BorderLayout());
/*  35: 34 */   private Hashtable<Component, Integer> componentLayoutRows = new Hashtable();
/*  36: 35 */   private JPanel centerPane = new JPanel(new BorderLayout());
/*  37: 36 */   private FreeOutlookSplitListener splitListener = new FreeOutlookSplitListener(this.header);
/*  38: 37 */   private Color additionalPaneBackground = new Color(217, 218, 219);
/*  39: 38 */   private FreeListPane shortcutPane = null;
/*  40:    */   
/*  41:    */   public FreeOutlookPane(FreeListPane shortcutPane)
/*  42:    */   {
/*  43: 41 */     this.shortcutPane = shortcutPane;
/*  44: 42 */     init();
/*  45:    */   }
/*  46:    */   
/*  47:    */   private void init()
/*  48:    */   {
/*  49: 47 */     this.split.setPreferredSize(new Dimension(this.splitWidth, 0));
/*  50: 48 */     this.split.setOpaque(true);
/*  51: 49 */     this.split.setBackground(this.splitColor);
/*  52: 50 */     this.split.setCursor(Cursor.getPredefinedCursor(10));
/*  53: 51 */     this.split.addMouseListener(this.splitListener);
/*  54: 52 */     this.split.addMouseMotionListener(this.splitListener);
/*  55:    */     
/*  56:    */ 
/*  57: 55 */     this.additionalPane.setBackground(this.additionalPaneBackground);
/*  58: 56 */     this.additionalPane.setPreferredSize(new Dimension(0, 0));
/*  59: 57 */     this.additionalPane.setBorder(new Border()
/*  60:    */     {
/*  61:    */       public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*  62:    */       {
/*  63: 61 */         g.setColor(FreeUtil.OUTLOOK_SPLIT_COLOR);
/*  64: 62 */         g.drawLine(0, 0, width, 0);
/*  65:    */       }
/*  66:    */       
/*  67:    */       public Insets getBorderInsets(Component c)
/*  68:    */       {
/*  69: 66 */         return new Insets(1, 0, 0, 0);
/*  70:    */       }
/*  71:    */       
/*  72:    */       public boolean isBorderOpaque()
/*  73:    */       {
/*  74: 70 */         return true;
/*  75:    */       }
/*  76: 74 */     });
/*  77: 75 */     this.centerPane.add(this.barPane, "North");
/*  78: 76 */     this.centerPane.add(this.additionalPane, "Center");
/*  79:    */     
/*  80: 78 */     this.barPaneLayout.insertColumn(0, -1.0D);
/*  81:    */     
/*  82:    */ 
/*  83: 81 */     setLayout(new BorderLayout());
/*  84: 82 */     add(this.header, "North");
/*  85: 83 */     add(this.centerPane, "Center");
/*  86: 84 */     add(this.split, "East");
/*  87:    */   }
/*  88:    */   
/*  89:    */   public FreeOutlookBar addBar(String title, Icon icon, Icon selectedIcon)
/*  90:    */   {
/*  91: 88 */     FreeOutlookBar bar = new FreeOutlookBar(this);
/*  92: 89 */     bar.setSelected(false);
/*  93: 90 */     bar.setTitle(title);
/*  94: 91 */     bar.setIcon(icon);
/*  95: 92 */     bar.setSelectedIcon(selectedIcon);
/*  96: 93 */     int rowCount = this.barPaneLayout.getRow().length;
/*  97:    */     
/*  98: 95 */     this.barPaneLayout.insertRow(rowCount, -2.0D);
/*  99: 96 */     this.barPane.add(bar, "0," + rowCount);
/* 100: 97 */     this.componentLayoutRows.put(bar, Integer.valueOf(rowCount));
/* 101: 98 */     rowCount++;
/* 102:    */     
/* 103:100 */     this.barPaneLayout.insertRow(rowCount, -3.0D);
/* 104:101 */     this.barPane.add(bar.getContentComponent(), "0," + rowCount);
/* 105:102 */     this.componentLayoutRows.put(bar.getContentComponent(), Integer.valueOf(rowCount));
/* 106:    */     
/* 107:104 */     return bar;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void updateLayoutConstraint(Component component, boolean selected)
/* 111:    */   {
/* 112:108 */     int rowIndex = ((Integer)this.componentLayoutRows.get(component)).intValue();
/* 113:109 */     double constraint = -1.0D;
/* 114:110 */     if (!selected) {
/* 115:111 */       constraint = -3.0D;
/* 116:    */     }
/* 117:113 */     this.barPaneLayout.setRow(rowIndex, constraint);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public JComponent getAdditionalPane()
/* 121:    */   {
/* 122:117 */     return this.additionalPane;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setAdditionalPaneVisible(boolean visible)
/* 126:    */   {
/* 127:121 */     this.centerPane.remove(this.barPane);
/* 128:122 */     this.centerPane.remove(this.additionalPane);
/* 129:123 */     if (visible)
/* 130:    */     {
/* 131:124 */       this.centerPane.add(this.barPane, "North");
/* 132:125 */       this.centerPane.add(this.additionalPane, "Center");
/* 133:    */     }
/* 134:    */     else
/* 135:    */     {
/* 136:127 */       this.centerPane.add(this.barPane, "Center");
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void closeAllBars()
/* 141:    */   {
/* 142:132 */     for (int i = 0; i < this.barPane.getComponentCount(); i++)
/* 143:    */     {
/* 144:133 */       Component c = this.barPane.getComponent(i);
/* 145:134 */       if ((c instanceof FreeOutlookBar))
/* 146:    */       {
/* 147:135 */         FreeOutlookBar bar = (FreeOutlookBar)c;
/* 148:136 */         if (bar.isSelected()) {
/* 149:137 */           bar.setSelected(false);
/* 150:    */         }
/* 151:    */       }
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   public FreeOutlookBar getSelectedBar()
/* 156:    */   {
/* 157:144 */     for (int i = 0; i < this.barPane.getComponentCount(); i++)
/* 158:    */     {
/* 159:145 */       Component c = this.barPane.getComponent(i);
/* 160:146 */       if ((c instanceof FreeOutlookBar))
/* 161:    */       {
/* 162:147 */         FreeOutlookBar bar = (FreeOutlookBar)c;
/* 163:148 */         if (bar.isSelected()) {
/* 164:149 */           return bar;
/* 165:    */         }
/* 166:    */       }
/* 167:    */     }
/* 168:153 */     return null;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public FreeOutlookBar getBarByNetwork(FreeNetwork network)
/* 172:    */   {
/* 173:157 */     for (int i = 0; i < this.barPane.getComponentCount(); i++)
/* 174:    */     {
/* 175:158 */       Component c = this.barPane.getComponent(i);
/* 176:159 */       if ((c instanceof FreeOutlookBar))
/* 177:    */       {
/* 178:160 */         FreeOutlookBar bar = (FreeOutlookBar)c;
/* 179:161 */         if (bar.getNetwork() == network) {
/* 180:162 */           return bar;
/* 181:    */         }
/* 182:    */       }
/* 183:    */     }
/* 184:166 */     return null;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void setShrink(boolean shrinked)
/* 188:    */   {
/* 189:170 */     this.header.setShrink(shrinked);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public boolean isShrinked()
/* 193:    */   {
/* 194:174 */     return this.header.isShrinked();
/* 195:    */   }
/* 196:    */   
/* 197:    */   private void shrinkChanged(boolean shrinked)
/* 198:    */   {
/* 199:178 */     if (shrinked) {
/* 200:179 */       this.split.setCursor(Cursor.getDefaultCursor());
/* 201:    */     } else {
/* 202:181 */       this.split.setCursor(Cursor.getPredefinedCursor(10));
/* 203:    */     }
/* 204:185 */     for (int i = 0; i < this.barPane.getComponentCount(); i++)
/* 205:    */     {
/* 206:186 */       Component c = this.barPane.getComponent(i);
/* 207:187 */       if ((c instanceof FreeOutlookBar))
/* 208:    */       {
/* 209:188 */         FreeOutlookBar bar = (FreeOutlookBar)c;
/* 210:189 */         bar.headerShrinkChanged(shrinked);
/* 211:190 */         FreeOutlookList list = bar.getList();
/* 212:    */         
/* 213:    */ 
/* 214:    */ 
/* 215:194 */         list.firePropertyChange("layoutOrientation", true, false);
/* 216:    */       }
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public FreeOutlookHeader getHeader()
/* 221:    */   {
/* 222:200 */     return this.header;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public FreeListPane getShortcutPane()
/* 226:    */   {
/* 227:204 */     return this.shortcutPane;
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookPane
 * JD-Core Version:    0.7.0.1
 */
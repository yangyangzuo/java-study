/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.Graphics2D;
/*   9:    */ import java.awt.Image;
/*  10:    */ import java.awt.Insets;
/*  11:    */ import java.awt.TexturePaint;
/*  12:    */ import java.awt.event.MouseAdapter;
/*  13:    */ import java.awt.event.MouseEvent;
/*  14:    */ import java.awt.event.MouseListener;
/*  15:    */ import javax.swing.BorderFactory;
/*  16:    */ import javax.swing.Icon;
/*  17:    */ import javax.swing.ImageIcon;
/*  18:    */ import javax.swing.JComponent;
/*  19:    */ import javax.swing.JLabel;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import javax.swing.JScrollPane;
/*  22:    */ import javax.swing.border.Border;
/*  23:    */ import twaver.DataBoxSelectionEvent;
/*  24:    */ import twaver.DataBoxSelectionListener;
/*  25:    */ import twaver.DataBoxSelectionModel;
/*  26:    */ import twaver.Element;
/*  27:    */ import twaver.TDataBox;
/*  28:    */ import twaver.TWaverUtil;
/*  29:    */ 
/*  30:    */ public class FreeOutlookBar
/*  31:    */   extends JPanel
/*  32:    */ {
/*  33: 33 */   private String backgroundImageURL = FreeUtil.getImageURL("outlook_bar_background.png");
/*  34: 34 */   private Image backgroundSelectedLeft = FreeUtil.getImage("outlook_bar_background_selected_left.png");
/*  35: 35 */   private Image backgroundSelectedRight = FreeUtil.getImage("outlook_bar_background_selected_right.png");
/*  36: 36 */   private String backgroundSelectedImageURL = FreeUtil.getImageURL("outlook_bar_background_selected.png");
/*  37: 37 */   private Image backgroundImage = TWaverUtil.getImage(this.backgroundImageURL);
/*  38: 38 */   private ImageIcon handlerIcon = FreeUtil.getImageIcon("outlook_bar_handler.png");
/*  39: 39 */   private ImageIcon handlerSelectedIcon = FreeUtil.getImageIcon("outlook_bar_handler_selected.png");
/*  40: 40 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/*  41: 41 */   private TexturePaint selectedPaint = FreeUtil.createTexturePaint(this.backgroundSelectedImageURL);
/*  42: 42 */   private JLabel lbHandler = new JLabel();
/*  43: 43 */   private Border handlerBorder = BorderFactory.createEmptyBorder(0, 0, 0, 16);
/*  44: 44 */   private Border handlerShrinkedBorder = BorderFactory.createEmptyBorder(0, 0, 0, 22);
/*  45: 45 */   private JLabel lbIcon = new JLabel();
/*  46: 46 */   private JLabel lbTitle = new JLabel();
/*  47: 47 */   private boolean selected = false;
/*  48: 48 */   private Color titleColor = FreeUtil.OUTLOOK_TEXT_COLOR;
/*  49: 49 */   private Color selectedTitleColor = Color.white;
/*  50: 50 */   private MouseListener mouseListener = new MouseAdapter()
/*  51:    */   {
/*  52:    */     public void mouseReleased(MouseEvent e)
/*  53:    */     {
/*  54: 54 */       if (((JComponent)e.getSource()).contains(e.getPoint())) {
/*  55: 55 */         FreeOutlookBar.this.changeStatus();
/*  56:    */       }
/*  57:    */     }
/*  58:    */   };
/*  59: 59 */   private FreeOutlookPane pane = null;
/*  60: 60 */   private TDataBox box = new TDataBox();
/*  61: 61 */   private FreeOutlookList list = new FreeOutlookList(this, this.box);
/*  62: 62 */   private FreeNetwork network = new FreeNetwork(this.box);
/*  63: 63 */   private JScrollPane scroll = new JScrollPane(this.list);
/*  64: 64 */   private Color scrollBorderColor = new Color(233, 223, 207);
/*  65: 65 */   private Border scrollBorder = new Border()
/*  66:    */   {
/*  67:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*  68:    */     {
/*  69: 68 */       g.setColor(FreeOutlookBar.this.scrollBorderColor);
/*  70: 69 */       g.drawLine(0, height, x, height);
/*  71:    */     }
/*  72:    */     
/*  73:    */     public Insets getBorderInsets(Component c)
/*  74:    */     {
/*  75: 73 */       return new Insets(0, 0, 1, 0);
/*  76:    */     }
/*  77:    */     
/*  78:    */     public boolean isBorderOpaque()
/*  79:    */     {
/*  80: 77 */       return true;
/*  81:    */     }
/*  82:    */   };
/*  83: 80 */   private Icon icon = null;
/*  84: 81 */   private Icon selectedIcon = null;
/*  85:    */   
/*  86:    */   public FreeOutlookBar(FreeOutlookPane pane)
/*  87:    */   {
/*  88: 84 */     this.pane = pane;
/*  89: 85 */     init();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public JComponent getContentComponent()
/*  93:    */   {
/*  94: 89 */     return this.scroll;
/*  95:    */   }
/*  96:    */   
/*  97:    */   private void init()
/*  98:    */   {
/*  99: 93 */     setLayout(new BorderLayout());
/* 100: 94 */     this.lbHandler.setVerticalAlignment(0);
/* 101: 95 */     this.lbHandler.setIcon(this.handlerIcon);
/* 102: 96 */     this.lbHandler.setBorder(this.handlerBorder);
/* 103: 97 */     add(this.lbHandler, "East");
/* 104:    */     
/* 105: 99 */     this.lbIcon.setVerticalAlignment(0);
/* 106:100 */     this.lbIcon.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 0));
/* 107:101 */     add(this.lbIcon, "West");
/* 108:    */     
/* 109:103 */     this.lbTitle.setVerticalAlignment(0);
/* 110:104 */     this.lbTitle.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
/* 111:105 */     this.lbTitle.setFont(FreeUtil.FONT_14_BOLD);
/* 112:106 */     this.lbTitle.setForeground(this.titleColor);
/* 113:107 */     add(this.lbTitle, "Center");
/* 114:    */     
/* 115:109 */     this.lbHandler.addMouseListener(this.mouseListener);
/* 116:110 */     this.lbTitle.addMouseListener(this.mouseListener);
/* 117:111 */     this.lbIcon.addMouseListener(this.mouseListener);
/* 118:    */     
/* 119:113 */     this.scroll.setMinimumSize(new Dimension(0, 0));
/* 120:114 */     this.scroll.setBorder(this.scrollBorder);
/* 121:    */     
/* 122:    */ 
/* 123:117 */     this.box.getSelectionModel().addDataBoxSelectionListener(new DataBoxSelectionListener()
/* 124:    */     {
/* 125:    */       public void selectionChanged(DataBoxSelectionEvent e)
/* 126:    */       {
/* 127:120 */         FreeListPane shortcutPane = FreeOutlookBar.this.pane.getShortcutPane();
/* 128:121 */         if (shortcutPane != null)
/* 129:    */         {
/* 130:122 */           DataBoxSelectionModel model = e.getBoxSelectionModel();
/* 131:123 */           if (model.size() == 1)
/* 132:    */           {
/* 133:124 */             Element element = model.lastElement();
/* 134:125 */             if ((element instanceof FreeNode))
/* 135:    */             {
/* 136:126 */               FreeNode node = (FreeNode)element;
/* 137:127 */               TDataBox shortcutBox = node.getShortcuts();
/* 138:128 */               shortcutPane.getList().setDataBox(shortcutBox);
/* 139:    */             }
/* 140:    */           }
/* 141:    */         }
/* 142:    */       }
/* 143:    */     });
/* 144:    */   }
/* 145:    */   
/* 146:    */   protected void paintComponent(Graphics g)
/* 147:    */   {
/* 148:138 */     super.paintComponent(g);
/* 149:    */     
/* 150:140 */     Graphics2D g2d = (Graphics2D)g;
/* 151:141 */     if (isSelected())
/* 152:    */     {
/* 153:142 */       g2d.setPaint(this.selectedPaint);
/* 154:143 */       if (this.selectedIcon != null) {
/* 155:144 */         this.lbIcon.setIcon(this.selectedIcon);
/* 156:    */       } else {
/* 157:146 */         this.lbIcon.setIcon(getIcon());
/* 158:    */       }
/* 159:    */     }
/* 160:    */     else
/* 161:    */     {
/* 162:149 */       g2d.setPaint(this.paint);
/* 163:150 */       this.lbIcon.setIcon(getIcon());
/* 164:    */     }
/* 165:152 */     g2d.fillRect(0, 0, getWidth(), getHeight());
/* 166:154 */     if (isSelected())
/* 167:    */     {
/* 168:156 */       g2d.drawImage(this.backgroundSelectedLeft, 0, 0, null);
/* 169:    */       
/* 170:    */ 
/* 171:159 */       g2d.drawImage(this.backgroundSelectedRight, getWidth() - this.backgroundSelectedRight.getWidth(null), 0, null);
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public Dimension getPreferredSize()
/* 176:    */   {
/* 177:165 */     return new Dimension(super.getPreferredSize().width, this.backgroundImage.getHeight(null));
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setSelected(boolean selected)
/* 181:    */   {
/* 182:169 */     if (selected != this.selected)
/* 183:    */     {
/* 184:170 */       if (!isSelected()) {
/* 185:171 */         this.pane.closeAllBars();
/* 186:    */       }
/* 187:173 */       this.selected = selected;
/* 188:174 */       if (selected)
/* 189:    */       {
/* 190:175 */         this.lbHandler.setIcon(this.handlerSelectedIcon);
/* 191:176 */         this.lbTitle.setForeground(this.selectedTitleColor);
/* 192:    */       }
/* 193:    */       else
/* 194:    */       {
/* 195:178 */         this.lbHandler.setIcon(this.handlerIcon);
/* 196:179 */         this.lbTitle.setForeground(this.titleColor);
/* 197:    */       }
/* 198:181 */       this.pane.updateLayoutConstraint(getContentComponent(), selected);
/* 199:182 */       this.pane.setAdditionalPaneVisible(!selected);
/* 200:183 */       this.pane.revalidate();
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void changeStatus()
/* 205:    */   {
/* 206:188 */     setSelected(!isSelected());
/* 207:    */   }
/* 208:    */   
/* 209:    */   public boolean isSelected()
/* 210:    */   {
/* 211:192 */     return this.selected;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public Icon getIcon()
/* 215:    */   {
/* 216:196 */     return this.icon;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setIcon(Icon icon)
/* 220:    */   {
/* 221:200 */     this.icon = icon;
/* 222:201 */     createAndUpdateIcon();
/* 223:    */   }
/* 224:    */   
/* 225:    */   public Icon getSelectedIcon()
/* 226:    */   {
/* 227:205 */     return this.selectedIcon;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void setSelectedIcon(Icon selectedIcon)
/* 231:    */   {
/* 232:209 */     this.selectedIcon = selectedIcon;
/* 233:    */   }
/* 234:    */   
/* 235:    */   private void createAndUpdateIcon()
/* 236:    */   {
/* 237:213 */     if (this.selectedIcon == null)
/* 238:    */     {
/* 239:215 */       Color dyeColor = Color.white;
/* 240:216 */       ImageIcon imageIcon = new ImageIcon(FreeUtil.iconToImage(this.icon));
/* 241:217 */       this.selectedIcon = FreeUtil.createDyedIcon(imageIcon, dyeColor, false);
/* 242:    */     }
/* 243:219 */     if (this.selected) {
/* 244:220 */       this.lbIcon.setIcon(this.selectedIcon);
/* 245:    */     } else {
/* 246:222 */       this.lbIcon.setIcon(this.icon);
/* 247:    */     }
/* 248:    */   }
/* 249:    */   
/* 250:    */   public void setTitle(String title)
/* 251:    */   {
/* 252:227 */     this.lbTitle.setText(title);
/* 253:228 */     this.lbTitle.setToolTipText(title);
/* 254:229 */     this.lbHandler.setToolTipText(title);
/* 255:230 */     this.lbIcon.setToolTipText(title);
/* 256:    */   }
/* 257:    */   
/* 258:    */   public String getTitle()
/* 259:    */   {
/* 260:234 */     return this.lbTitle.getText();
/* 261:    */   }
/* 262:    */   
/* 263:    */   public FreeOutlookPane getFreeOutlookPane()
/* 264:    */   {
/* 265:238 */     return this.pane;
/* 266:    */   }
/* 267:    */   
/* 268:    */   public FreeOutlookList getList()
/* 269:    */   {
/* 270:242 */     return this.list;
/* 271:    */   }
/* 272:    */   
/* 273:    */   public void headerShrinkChanged(boolean headShrinked)
/* 274:    */   {
/* 275:246 */     if (headShrinked) {
/* 276:247 */       this.lbHandler.setBorder(this.handlerShrinkedBorder);
/* 277:    */     } else {
/* 278:249 */       this.lbHandler.setBorder(this.handlerBorder);
/* 279:    */     }
/* 280:    */   }
/* 281:    */   
/* 282:    */   public FreeNetwork getNetwork()
/* 283:    */   {
/* 284:254 */     return this.network;
/* 285:    */   }
/* 286:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeOutlookBar
 * JD-Core Version:    0.7.0.1
 */
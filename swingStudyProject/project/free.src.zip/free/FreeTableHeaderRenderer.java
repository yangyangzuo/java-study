/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Dimension;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ import java.awt.Insets;
/*  8:   */ import javax.swing.JTable;
/*  9:   */ import javax.swing.border.Border;
/* 10:   */ import javax.swing.table.DefaultTableCellRenderer;
/* 11:   */ 
/* 12:   */ public class FreeTableHeaderRenderer
/* 13:   */   extends DefaultTableCellRenderer
/* 14:   */ {
/* 15:14 */   private Color background = FreeUtil.TABLE_HEADER_BACKGROUND_COLOR;
/* 16:15 */   private Color textColor = new Color(126, 104, 127);
/* 17:16 */   private Color borderLightColor = FreeUtil.TABLE_HEADER_BORDER_BRIGHT_COLOR;
/* 18:17 */   private Color borderDarkColor = FreeUtil.TABLE_HEADER_BORDER_DARK_COLOR;
/* 19:18 */   private int tableHeaderHeight = 20;
/* 20:19 */   private Border border = new Border()
/* 21:   */   {
/* 22:   */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 23:   */     {
/* 24:22 */       g.setColor(FreeTableHeaderRenderer.this.borderDarkColor);
/* 25:23 */       g.drawRect(x, y, width - 1, height - 1);
/* 26:   */       
/* 27:25 */       g.setColor(FreeTableHeaderRenderer.this.borderLightColor);
/* 28:26 */       g.drawLine(x, y, x, height - 1);
/* 29:   */     }
/* 30:   */     
/* 31:   */     public Insets getBorderInsets(Component c)
/* 32:   */     {
/* 33:30 */       return new Insets(1, 5, 1, 1);
/* 34:   */     }
/* 35:   */     
/* 36:   */     public boolean isBorderOpaque()
/* 37:   */     {
/* 38:34 */       return true;
/* 39:   */     }
/* 40:   */   };
/* 41:   */   
/* 42:   */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 43:   */   {
/* 44:41 */     super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 45:   */     
/* 46:   */ 
/* 47:44 */     setFont(FreeUtil.TABLE_HEADER_FONT);
/* 48:45 */     setBackground(this.background);
/* 49:46 */     setForeground(this.textColor);
/* 50:47 */     setBorder(this.border);
/* 51:48 */     return this;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Dimension getPreferredSize()
/* 55:   */   {
/* 56:53 */     Dimension size = super.getPreferredSize();
/* 57:54 */     return new Dimension(size.width, this.tableHeaderHeight);
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTableHeaderRenderer
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.GridLayout;
/*  5:   */ import java.awt.Point;
/*  6:   */ import java.awt.event.ActionEvent;
/*  7:   */ import java.awt.event.ActionListener;
/*  8:   */ import java.awt.event.MouseAdapter;
/*  9:   */ import java.awt.event.MouseEvent;
/* 10:   */ import java.awt.event.MouseListener;
/* 11:   */ import javax.swing.JPanel;
/* 12:   */ import twaver.TWaverUtil;
/* 13:   */ 
/* 14:   */ public class FreeNodeButtonAttachment
/* 15:   */   extends JPanel
/* 16:   */ {
/* 17:14 */   private FreeToolbarButton button1 = createButton();
/* 18:15 */   private FreeToolbarButton button2 = createButton();
/* 19:16 */   private FreeToolbarButton button3 = createButton();
/* 20:17 */   private FreeNode node = null;
/* 21:   */   
/* 22:   */   public FreeNodeButtonAttachment(FreeNode node)
/* 23:   */   {
/* 24:20 */     this.node = node;
/* 25:21 */     init();
/* 26:   */   }
/* 27:   */   
/* 28:   */   private void init()
/* 29:   */   {
/* 30:25 */     setLayout(new GridLayout(3, 1, 0, 12));
/* 31:26 */     setOpaque(false);
/* 32:27 */     add(this.button1);
/* 33:28 */     add(this.button2);
/* 34:29 */     add(this.button3);
/* 35:   */     
/* 36:31 */     this.button1.addActionListener(new ActionListener()
/* 37:   */     {
/* 38:   */       public void actionPerformed(ActionEvent e)
/* 39:   */       {
/* 40:34 */         ActionListener listener = FreeNodeButtonAttachment.this.node.getButtonAction1();
/* 41:35 */         if (listener != null)
/* 42:   */         {
/* 43:36 */           ActionEvent event = FreeNodeButtonAttachment.this.createActionEvent(e, FreeNodeButtonAttachment.this.node.getActionCommand1());
/* 44:37 */           listener.actionPerformed(event);
/* 45:   */         }
/* 46:   */       }
/* 47:40 */     });
/* 48:41 */     this.button2.addActionListener(new ActionListener()
/* 49:   */     {
/* 50:   */       public void actionPerformed(ActionEvent e)
/* 51:   */       {
/* 52:44 */         ActionListener listener = FreeNodeButtonAttachment.this.node.getButtonAction2();
/* 53:45 */         if (listener != null)
/* 54:   */         {
/* 55:46 */           ActionEvent event = FreeNodeButtonAttachment.this.createActionEvent(e, FreeNodeButtonAttachment.this.node.getActionCommand2());
/* 56:47 */           listener.actionPerformed(event);
/* 57:   */         }
/* 58:   */       }
/* 59:50 */     });
/* 60:51 */     this.button3.addActionListener(new ActionListener()
/* 61:   */     {
/* 62:   */       public void actionPerformed(ActionEvent e)
/* 63:   */       {
/* 64:54 */         ActionListener listener = FreeNodeButtonAttachment.this.node.getButtonAction3();
/* 65:55 */         if (listener != null)
/* 66:   */         {
/* 67:56 */           ActionEvent event = FreeNodeButtonAttachment.this.createActionEvent(e, FreeNodeButtonAttachment.this.node.getActionCommand3());
/* 68:57 */           listener.actionPerformed(event);
/* 69:   */         }
/* 70:   */       }
/* 71:61 */     });
/* 72:62 */     MouseListener mouseListener = new MouseAdapter()
/* 73:   */     {
/* 74:   */       public void mousePressed(MouseEvent e)
/* 75:   */       {
/* 76:66 */         FreeNodeButtonAttachment.this.node.setSelected(true);
/* 77:   */       }
/* 78:68 */     };
/* 79:69 */     addMouseListener(mouseListener);
/* 80:70 */     this.button1.addMouseListener(mouseListener);
/* 81:71 */     this.button2.addMouseListener(mouseListener);
/* 82:72 */     this.button3.addMouseListener(mouseListener);
/* 83:   */   }
/* 84:   */   
/* 85:   */   private FreeToolbarButton createButton()
/* 86:   */   {
/* 87:76 */     FreeToolbarButton button = new FreeToolbarButton();
/* 88:77 */     button.setOpaque(false);
/* 89:78 */     return button;
/* 90:   */   }
/* 91:   */   
/* 92:   */   public void updateBounds()
/* 93:   */   {
/* 94:82 */     int width = getPreferredSize().width;
/* 95:83 */     int height = getPreferredSize().height;
/* 96:84 */     int x = this.node.getLocation().x + this.node.getWidth() - width - 3;
/* 97:85 */     int y = this.node.getLocation().y + 6;
/* 98:86 */     setBounds(x, y, width, height);
/* 99:   */   }
/* :0:   */   
/* :1:   */   public void updateProperties()
/* :2:   */   {
/* :3:90 */     this.button1.setIcon(TWaverUtil.getImageIcon(this.node.getButtonIcon1()));
/* :4:91 */     this.button1.setToolTipText(this.node.getButtonTooltip1());
/* :5:92 */     this.button2.setIcon(TWaverUtil.getImageIcon(this.node.getButtonIcon2()));
/* :6:93 */     this.button2.setToolTipText(this.node.getButtonTooltip2());
/* :7:94 */     this.button3.setIcon(TWaverUtil.getImageIcon(this.node.getButtonIcon3()));
/* :8:95 */     this.button3.setToolTipText(this.node.getButtonTooltip3());
/* :9:   */   }
/* ;0:   */   
/* ;1:   */   private ActionEvent createActionEvent(ActionEvent e, String command)
/* ;2:   */   {
/* ;3:99 */     return new ActionEvent(e.getSource(), e.getID(), command, e.getWhen(), e.getModifiers());
/* ;4:   */   }
/* ;5:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeNodeButtonAttachment
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import javax.swing.JPanel;
/*  5:   */ 
/*  6:   */ public class FreeContentPane
/*  7:   */   extends JPanel
/*  8:   */ {
/*  9:   */   public FreeContentPane()
/* 10:   */   {
/* 11: 9 */     setLayout(new BorderLayout());
/* 12:10 */     setBackground(FreeUtil.CONTENT_PANE_BACKGROUND);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeContentPane
 * JD-Core Version:    0.7.0.1
 */
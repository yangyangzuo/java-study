/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import javax.swing.BorderFactory;
/*  6:   */ import javax.swing.JMenuItem;
/*  7:   */ import javax.swing.border.Border;
/*  8:   */ 
/*  9:   */ public class FreeMenuItem
/* 10:   */   extends JMenuItem
/* 11:   */ {
/* 12:11 */   private Color backgroundColor = FreeUtil.MENUITEM_BACKGROUND;
/* 13:12 */   private Color foregroundColor = FreeUtil.DEFAULT_TEXT_COLOR;
/* 14:13 */   private int borderThickness = 1;
/* 15:14 */   private Border border = BorderFactory.createLineBorder(this.backgroundColor, this.borderThickness);
/* 16:15 */   private int preferredHeight = 23;
/* 17:   */   
/* 18:   */   public FreeMenuItem()
/* 19:   */   {
/* 20:18 */     init();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public FreeMenuItem(String text)
/* 24:   */   {
/* 25:22 */     super(text);
/* 26:23 */     init();
/* 27:   */   }
/* 28:   */   
/* 29:   */   private void init()
/* 30:   */   {
/* 31:27 */     setForeground(this.foregroundColor);
/* 32:28 */     setFont(FreeUtil.FONT_14_BOLD);
/* 33:29 */     setBackground(this.backgroundColor);
/* 34:30 */     setBorder(this.border);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Dimension getPreferredSize()
/* 38:   */   {
/* 39:35 */     return new Dimension(super.getPreferredSize().width, this.preferredHeight);
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeMenuItem
 * JD-Core Version:    0.7.0.1
 */
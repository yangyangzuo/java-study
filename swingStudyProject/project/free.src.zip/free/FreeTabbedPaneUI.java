/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.FontMetrics;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Rectangle;
/*  6:   */ import javax.swing.plaf.metal.MetalTabbedPaneUI;
/*  7:   */ 
/*  8:   */ public class FreeTabbedPaneUI
/*  9:   */   extends MetalTabbedPaneUI
/* 10:   */ {
/* 11:11 */   private FreeTabbedPane tab = null;
/* 12:12 */   private int firstTabIndent = 5;
/* 13:   */   
/* 14:   */   public FreeTabbedPaneUI(FreeTabbedPane tab)
/* 15:   */   {
/* 16:15 */     this.tab = tab;
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected Rectangle getTabBounds(int tabIndex, Rectangle dest)
/* 20:   */   {
/* 21:20 */     Rectangle bounds = super.getTabBounds(tabIndex, dest);
/* 22:   */     
/* 23:22 */     bounds.x += this.firstTabIndent;
/* 24:23 */     return bounds;
/* 25:   */   }
/* 26:   */   
/* 27:   */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/* 28:   */   {
/* 29:32 */     g.setColor(FreeUtil.TAB_BOTTOM_LINE_COLOR);
/* 30:33 */     int lineY = this.tab.getPreferredTabHeight() - 1;
/* 31:34 */     g.drawLine(0, lineY, this.firstTabIndent, lineY);
/* 32:   */   }
/* 33:   */   
/* 34:   */   protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {}
/* 35:   */   
/* 36:   */   protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics)
/* 37:   */   {
/* 38:46 */     int width = super.calculateTabWidth(tabPlacement, tabIndex, metrics);
/* 39:   */     
/* 40:48 */     return width - 5;
/* 41:   */   }
/* 42:   */   
/* 43:   */   protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight)
/* 44:   */   {
/* 45:53 */     return this.tab.getPreferredTabHeight();
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTabbedPaneUI
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import java.util.Date;
/*  6:   */ import javax.swing.Timer;
/*  7:   */ 
/*  8:   */ public class FreeStatusTimeLabel
/*  9:   */   extends FreeStatusLabel
/* 10:   */ {
/* 11:10 */   private int delay = 1000;
/* 12:   */   
/* 13:   */   public FreeStatusTimeLabel()
/* 14:   */   {
/* 15:13 */     ActionListener taskPerformer = new ActionListener()
/* 16:   */     {
/* 17:   */       public void actionPerformed(ActionEvent evt)
/* 18:   */       {
/* 19:16 */         FreeStatusTimeLabel.this.setText(new Date().toString());
/* 20:   */       }
/* 21:18 */     };
/* 22:19 */     new Timer(this.delay, taskPerformer).start();
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeStatusTimeLabel
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.FlowLayout;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ import java.awt.Graphics2D;
/*  8:   */ import java.awt.Image;
/*  9:   */ import java.awt.TexturePaint;
/* 10:   */ import javax.swing.BorderFactory;
/* 11:   */ import javax.swing.ImageIcon;
/* 12:   */ import javax.swing.JPanel;
/* 13:   */ import javax.swing.border.Border;
/* 14:   */ import twaver.TWaverUtil;
/* 15:   */ 
/* 16:   */ public class FreeStatusBar
/* 17:   */   extends JPanel
/* 18:   */ {
/* 19:18 */   private String backgroundImageURL = FreeUtil.getImageURL("statusbar_background.png");
/* 20:19 */   private Image backgroundLeftImage = FreeUtil.getImage("statusbar_background_left.png");
/* 21:20 */   private Image backgroundRightImage = FreeUtil.getImage("statusbar_background_right.png");
/* 22:21 */   private ImageIcon backgroundImageIcon = TWaverUtil.getImageIcon(this.backgroundImageURL);
/* 23:22 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 24:23 */   private JPanel leftPane = new JPanel(new BorderLayout());
/* 25:24 */   private JPanel rightPane = new JPanel(new FlowLayout(3, 0, 0));
/* 26:25 */   private Border border = BorderFactory.createEmptyBorder(2, 10, 0, 0);
/* 27:   */   
/* 28:   */   public FreeStatusBar()
/* 29:   */   {
/* 30:28 */     init();
/* 31:   */   }
/* 32:   */   
/* 33:   */   private void init()
/* 34:   */   {
/* 35:32 */     setLayout(new BorderLayout());
/* 36:33 */     add(this.leftPane, "Center");
/* 37:34 */     add(this.rightPane, "East");
/* 38:35 */     setBorder(this.border);
/* 39:36 */     this.leftPane.setOpaque(false);
/* 40:37 */     this.rightPane.setOpaque(false);
/* 41:   */   }
/* 42:   */   
/* 43:   */   protected void paintComponent(Graphics g)
/* 44:   */   {
/* 45:42 */     super.paintComponent(g);
/* 46:   */     
/* 47:44 */     Graphics2D g2d = (Graphics2D)g;
/* 48:45 */     g2d.setPaint(this.paint);
/* 49:46 */     g2d.fillRect(0, 0, getWidth(), getHeight());
/* 50:   */     
/* 51:   */ 
/* 52:49 */     g2d.drawImage(this.backgroundLeftImage, 0, 0, null);
/* 53:   */     
/* 54:   */ 
/* 55:52 */     g2d.drawImage(this.backgroundRightImage, getWidth() - this.backgroundRightImage.getWidth(null), 0, null);
/* 56:   */   }
/* 57:   */   
/* 58:   */   public JPanel getLeftPane()
/* 59:   */   {
/* 60:56 */     return this.leftPane;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public JPanel getRightPane()
/* 64:   */   {
/* 65:60 */     return this.rightPane;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void addSeparator()
/* 69:   */   {
/* 70:64 */     this.rightPane.add(new FreeStatusSeparator());
/* 71:   */   }
/* 72:   */   
/* 73:   */   public Dimension getPreferredSize()
/* 74:   */   {
/* 75:69 */     return new Dimension(super.getPreferredSize().width, this.backgroundImageIcon.getIconHeight());
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeStatusBar
 * JD-Core Version:    0.7.0.1
 */
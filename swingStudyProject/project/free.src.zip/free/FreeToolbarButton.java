/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Graphics;
/*   7:    */ import java.awt.Insets;
/*   8:    */ import java.awt.event.MouseAdapter;
/*   9:    */ import java.awt.event.MouseEvent;
/*  10:    */ import javax.swing.BorderFactory;
/*  11:    */ import javax.swing.Icon;
/*  12:    */ import javax.swing.JButton;
/*  13:    */ import javax.swing.border.Border;
/*  14:    */ 
/*  15:    */ public class FreeToolbarButton
/*  16:    */   extends JButton
/*  17:    */ {
/*  18: 18 */   private int buttonSize = 20;
/*  19: 19 */   private Color roverBorderColor = FreeUtil.BUTTON_ROVER_COLOR;
/*  20: 20 */   private Border roverBorder = new Border()
/*  21:    */   {
/*  22:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*  23:    */     {
/*  24: 23 */       g.setColor(FreeToolbarButton.this.roverBorderColor);
/*  25: 24 */       g.drawRect(x, y, width - 1, height - 1);
/*  26:    */     }
/*  27:    */     
/*  28:    */     public Insets getBorderInsets(Component c)
/*  29:    */     {
/*  30: 28 */       return new Insets(1, 1, 1, 1);
/*  31:    */     }
/*  32:    */     
/*  33:    */     public boolean isBorderOpaque()
/*  34:    */     {
/*  35: 32 */       return true;
/*  36:    */     }
/*  37:    */   };
/*  38: 35 */   private Border emptyBorder = BorderFactory.createEmptyBorder(1, 1, 1, 1);
/*  39:    */   
/*  40:    */   public FreeToolbarButton()
/*  41:    */   {
/*  42: 38 */     this(null, null);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public FreeToolbarButton(String text)
/*  46:    */   {
/*  47: 42 */     this(text, null);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public FreeToolbarButton(Icon icon)
/*  51:    */   {
/*  52: 46 */     this(null, icon);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public FreeToolbarButton(String text, Icon icon)
/*  56:    */   {
/*  57: 50 */     super(text, icon);
/*  58: 51 */     init();
/*  59:    */   }
/*  60:    */   
/*  61:    */   private void init()
/*  62:    */   {
/*  63: 55 */     setVerticalAlignment(0);
/*  64: 56 */     setFont(FreeUtil.FONT_12_BOLD);
/*  65: 57 */     setOpaque(false);
/*  66: 58 */     setBorder(this.emptyBorder);
/*  67: 59 */     setContentAreaFilled(false);
/*  68: 60 */     setFocusPainted(false);
/*  69: 61 */     setRolloverEnabled(true);
/*  70:    */     
/*  71: 63 */     addMouseListener(new MouseAdapter()
/*  72:    */     {
/*  73:    */       public void mouseEntered(MouseEvent e)
/*  74:    */       {
/*  75: 67 */         if (FreeToolbarButton.this.isRolloverEnabled()) {
/*  76: 68 */           FreeToolbarButton.this.setBorder(FreeToolbarButton.this.roverBorder);
/*  77:    */         }
/*  78:    */       }
/*  79:    */       
/*  80:    */       public void mouseExited(MouseEvent e)
/*  81:    */       {
/*  82: 74 */         if (FreeToolbarButton.this.isRolloverEnabled()) {
/*  83: 75 */           FreeToolbarButton.this.setBorder(FreeToolbarButton.this.emptyBorder);
/*  84:    */         }
/*  85:    */       }
/*  86:    */     });
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void setIcon(Icon icon)
/*  90:    */   {
/*  91: 83 */     super.setIcon(icon);
/*  92: 86 */     if (icon == null)
/*  93:    */     {
/*  94: 87 */       setPressedIcon(null);
/*  95: 88 */       setRolloverIcon(null);
/*  96:    */     }
/*  97:    */     else
/*  98:    */     {
/*  99: 90 */       Icon pressedIcon = FreeUtil.createMovedIcon(icon);
/* 100: 91 */       setPressedIcon(pressedIcon);
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Dimension getPreferredSize()
/* 105:    */   {
/* 106: 97 */     int width = super.getPreferredSize().width;
/* 107: 98 */     width = Math.max(width, this.buttonSize);
/* 108: 99 */     int height = this.buttonSize;
/* 109:100 */     return new Dimension(width, height);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setRoverBorder(Border roverBorder)
/* 113:    */   {
/* 114:104 */     this.roverBorder = roverBorder;
/* 115:105 */     repaint();
/* 116:    */   }
/* 117:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeToolbarButton
 * JD-Core Version:    0.7.0.1
 */
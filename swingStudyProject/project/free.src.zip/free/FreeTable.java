/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import javax.swing.JTable;
/*  5:   */ import javax.swing.table.JTableHeader;
/*  6:   */ import javax.swing.table.TableCellRenderer;
/*  7:   */ 
/*  8:   */ public class FreeTable
/*  9:   */   extends JTable
/* 10:   */ {
/* 11: 9 */   private Color verticalGridColor = Color.white;
/* 12:10 */   private FreeTableCellRenderer renderer = new FreeTableCellRenderer();
/* 13:11 */   private FreeTableHeaderRenderer headerRenderer = new FreeTableHeaderRenderer();
/* 14:   */   
/* 15:   */   public FreeTable()
/* 16:   */   {
/* 17:14 */     init();
/* 18:   */   }
/* 19:   */   
/* 20:   */   private void init()
/* 21:   */   {
/* 22:18 */     setFont(FreeUtil.FONT_12_PLAIN);
/* 23:19 */     getTableHeader().setFont(FreeUtil.FONT_12_BOLD);
/* 24:20 */     getTableHeader().setDefaultRenderer(this.headerRenderer);
/* 25:21 */     setBorder(null);
/* 26:22 */     setRowSelectionAllowed(true);
/* 27:23 */     setShowHorizontalLines(false);
/* 28:24 */     setShowVerticalLines(true);
/* 29:25 */     setGridColor(this.verticalGridColor);
/* 30:26 */     setRowMargin(0);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public TableCellRenderer getCellRenderer(int row, int column)
/* 34:   */   {
/* 35:31 */     return this.renderer;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean isCellEditable(int row, int column)
/* 39:   */   {
/* 40:36 */     return false;
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeTable
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Graphics2D;
/*  4:   */ import java.awt.Image;
/*  5:   */ import java.awt.Point;
/*  6:   */ import java.util.Iterator;
/*  7:   */ import twaver.Node;
/*  8:   */ import twaver.TDataBox;
/*  9:   */ import twaver.network.CanvasCushion;
/* 10:   */ 
/* 11:   */ public class FreeNetworkShadowCushion
/* 12:   */   implements CanvasCushion
/* 13:   */ {
/* 14:11 */   private FreeNetwork network = null;
/* 15:   */   
/* 16:   */   public FreeNetworkShadowCushion(FreeNetwork network)
/* 17:   */   {
/* 18:14 */     this.network = network;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void paint(Graphics2D g2d)
/* 22:   */   {
/* 23:18 */     Iterator it = this.network.getDataBox().iterator();
/* 24:19 */     while (it.hasNext())
/* 25:   */     {
/* 26:20 */       Object o = it.next();
/* 27:21 */       if ((o instanceof Node))
/* 28:   */       {
/* 29:22 */         Node node = (Node)o;
/* 30:   */         
/* 31:   */ 
/* 32:25 */         Image shadowImage = FreeUtil.getNodeShadowImage(node);
/* 33:26 */         if (shadowImage != null)
/* 34:   */         {
/* 35:27 */           int shadowSize = this.network.getShadowSize();
/* 36:28 */           int offset = 5;
/* 37:29 */           int x = node.getLocation().x - shadowSize * 2 + offset;
/* 38:30 */           int y = node.getLocation().y - shadowSize * 2 + offset;
/* 39:31 */           g2d.drawImage(shadowImage, x, y, null);
/* 40:   */         }
/* 41:   */       }
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeNetworkShadowCushion
 * JD-Core Version:    0.7.0.1
 */
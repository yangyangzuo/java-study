/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Point;
/*  5:   */ import java.awt.event.MouseEvent;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ import javax.swing.event.MouseInputAdapter;
/*  8:   */ 
/*  9:   */ public class FreeListSplitListener
/* 10:   */   extends MouseInputAdapter
/* 11:   */ {
/* 12:11 */   protected Point lastPoint = null;
/* 13:12 */   protected FreeHeader header = null;
/* 14:   */   
/* 15:   */   public FreeListSplitListener(FreeHeader header)
/* 16:   */   {
/* 17:15 */     this.header = header;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void mousePressed(MouseEvent e)
/* 21:   */   {
/* 22:20 */     if (!this.header.isShrinked()) {
/* 23:21 */       this.lastPoint = e.getPoint();
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void mouseReleased(MouseEvent e)
/* 28:   */   {
/* 29:27 */     this.lastPoint = null;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void mouseDragged(MouseEvent e)
/* 33:   */   {
/* 34:32 */     if ((!this.header.isShrinked()) && 
/* 35:33 */       (this.lastPoint != null))
/* 36:   */     {
/* 37:34 */       JComponent parent = (JComponent)this.header.getParent();
/* 38:35 */       Dimension size = parent.getPreferredSize();
/* 39:36 */       Point thisPoint = e.getPoint();
/* 40:37 */       int xMovement = thisPoint.x - this.lastPoint.x;
/* 41:38 */       size.width -= xMovement;
/* 42:39 */       size.width = Math.max(size.width, 37);
/* 43:40 */       parent.setPreferredSize(size);
/* 44:41 */       this.header.revalidateParent();
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeListSplitListener
 * JD-Core Version:    0.7.0.1
 */
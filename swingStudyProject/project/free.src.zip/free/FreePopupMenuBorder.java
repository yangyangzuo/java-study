/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Insets;
/*  7:   */ import javax.swing.border.Border;
/*  8:   */ 
/*  9:   */ public class FreePopupMenuBorder
/* 10:   */   implements Border
/* 11:   */ {
/* 12:11 */   private Color borderColor = FreeUtil.MENUITEM_SELECTED_BACKGROUND;
/* 13:12 */   private Color leftSider = new Color(214, 225, 200);
/* 14:13 */   private int lineThickness = 1;
/* 15:14 */   private int leftHeaderWidth = 7;
/* 16:15 */   private Insets insets = new Insets(this.lineThickness, this.lineThickness + this.leftHeaderWidth, this.lineThickness, this.lineThickness);
/* 17:   */   
/* 18:   */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 19:   */   {
/* 20:19 */     g.setColor(this.leftSider);
/* 21:20 */     g.fillRect(this.lineThickness, this.lineThickness, this.leftHeaderWidth, height);
/* 22:   */     
/* 23:22 */     g.setColor(this.borderColor);
/* 24:23 */     g.drawRect(0, 0, width - this.lineThickness, height - this.lineThickness);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Insets getBorderInsets(Component c)
/* 28:   */   {
/* 29:27 */     return this.insets;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean isBorderOpaque()
/* 33:   */   {
/* 34:31 */     return true;
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreePopupMenuBorder
 * JD-Core Version:    0.7.0.1
 */
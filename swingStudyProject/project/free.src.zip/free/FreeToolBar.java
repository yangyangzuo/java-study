/*  1:   */ package free;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.FlowLayout;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Graphics2D;
/*  7:   */ import java.awt.TexturePaint;
/*  8:   */ import javax.swing.BorderFactory;
/*  9:   */ import javax.swing.ImageIcon;
/* 10:   */ import javax.swing.JPanel;
/* 11:   */ import twaver.TWaverUtil;
/* 12:   */ 
/* 13:   */ public class FreeToolBar
/* 14:   */   extends JPanel
/* 15:   */ {
/* 16:14 */   private String backgroundImageURL = FreeUtil.getImageURL("toolbar_background.png");
/* 17:15 */   private int preferredHeight = TWaverUtil.getImageIcon(this.backgroundImageURL).getIconHeight();
/* 18:16 */   private TexturePaint paint = FreeUtil.createTexturePaint(this.backgroundImageURL);
/* 19:17 */   private int buttonGap = 2;
/* 20:   */   
/* 21:   */   public FreeToolBar()
/* 22:   */   {
/* 23:20 */     init();
/* 24:   */   }
/* 25:   */   
/* 26:   */   private void init()
/* 27:   */   {
/* 28:24 */     setLayout(new FlowLayout(3, this.buttonGap, 0));
/* 29:25 */     setBorder(BorderFactory.createEmptyBorder(2, 5, 0, 5));
/* 30:   */   }
/* 31:   */   
/* 32:   */   protected void paintComponent(Graphics g)
/* 33:   */   {
/* 34:30 */     super.paintComponent(g);
/* 35:   */     
/* 36:32 */     Graphics2D g2d = (Graphics2D)g;
/* 37:33 */     g2d.setPaint(this.paint);
/* 38:34 */     g2d.fillRect(0, 0, getWidth(), getHeight());
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Dimension getPreferredSize()
/* 42:   */   {
/* 43:39 */     return new Dimension(super.getPreferredSize().width, this.preferredHeight);
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.FreeToolBar
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package free;
/*   2:    */ 
/*   3:    */ import java.awt.Graphics;
/*   4:    */ import java.awt.Graphics2D;
/*   5:    */ import java.awt.GraphicsConfiguration;
/*   6:    */ import java.awt.GraphicsDevice;
/*   7:    */ import java.awt.GraphicsEnvironment;
/*   8:    */ import java.awt.RenderingHints;
/*   9:    */ import java.awt.image.BufferedImage;
/*  10:    */ import java.awt.image.ColorModel;
/*  11:    */ import java.awt.image.Raster;
/*  12:    */ import java.awt.image.WritableRaster;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.net.URL;
/*  15:    */ import javax.imageio.ImageIO;
/*  16:    */ 
/*  17:    */ public class GraphicsUtilities
/*  18:    */ {
/*  19:    */   private static GraphicsConfiguration getGraphicsConfiguration()
/*  20:    */   {
/*  21: 61 */     return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static BufferedImage createColorModelCompatibleImage(BufferedImage image)
/*  25:    */   {
/*  26: 77 */     ColorModel cm = image.getColorModel();
/*  27: 78 */     return new BufferedImage(cm, cm.createCompatibleWritableRaster(image.getWidth(), image.getHeight()), cm.isAlphaPremultiplied(), null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static BufferedImage createCompatibleImage(BufferedImage image)
/*  31:    */   {
/*  32:100 */     return createCompatibleImage(image, image.getWidth(), image.getHeight());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static BufferedImage createCompatibleImage(BufferedImage image, int width, int height)
/*  36:    */   {
/*  37:122 */     return getGraphicsConfiguration().createCompatibleImage(width, height, image.getTransparency());
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static BufferedImage createCompatibleImage(int width, int height)
/*  41:    */   {
/*  42:141 */     return getGraphicsConfiguration().createCompatibleImage(width, height);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static BufferedImage createCompatibleTranslucentImage(int width, int height)
/*  46:    */   {
/*  47:160 */     return getGraphicsConfiguration().createCompatibleImage(width, height, 3);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static BufferedImage loadCompatibleImage(URL resource)
/*  51:    */     throws IOException
/*  52:    */   {
/*  53:181 */     BufferedImage image = ImageIO.read(resource);
/*  54:182 */     return toCompatibleImage(image);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static BufferedImage toCompatibleImage(BufferedImage image)
/*  58:    */   {
/*  59:200 */     if (image.getColorModel().equals(getGraphicsConfiguration().getColorModel())) {
/*  60:202 */       return image;
/*  61:    */     }
/*  62:205 */     BufferedImage compatibleImage = getGraphicsConfiguration().createCompatibleImage(image.getWidth(), image.getHeight(), image.getTransparency());
/*  63:    */     
/*  64:    */ 
/*  65:    */ 
/*  66:209 */     Graphics g = compatibleImage.getGraphics();
/*  67:210 */     g.drawImage(image, 0, 0, null);
/*  68:211 */     g.dispose();
/*  69:    */     
/*  70:213 */     return compatibleImage;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static BufferedImage createThumbnailFast(BufferedImage image, int newSize)
/*  74:    */   {
/*  75:241 */     int width = image.getWidth();
/*  76:242 */     int height = image.getHeight();
/*  77:244 */     if (width > height)
/*  78:    */     {
/*  79:245 */       if (newSize >= width) {
/*  80:246 */         throw new IllegalArgumentException("newSize must be lower than the image width");
/*  81:    */       }
/*  82:248 */       if (newSize <= 0) {
/*  83:249 */         throw new IllegalArgumentException("newSize must be greater than 0");
/*  84:    */       }
/*  85:253 */       float ratio = width / height;
/*  86:254 */       width = newSize;
/*  87:255 */       height = (int)(newSize / ratio);
/*  88:    */     }
/*  89:    */     else
/*  90:    */     {
/*  91:257 */       if (newSize >= height) {
/*  92:258 */         throw new IllegalArgumentException("newSize must be lower than the image height");
/*  93:    */       }
/*  94:260 */       if (newSize <= 0) {
/*  95:261 */         throw new IllegalArgumentException("newSize must be greater than 0");
/*  96:    */       }
/*  97:265 */       float ratio = height / width;
/*  98:266 */       height = newSize;
/*  99:267 */       width = (int)(newSize / ratio);
/* 100:    */     }
/* 101:270 */     BufferedImage temp = createCompatibleImage(image, width, height);
/* 102:271 */     Graphics2D g2 = temp.createGraphics();
/* 103:272 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 104:    */     
/* 105:274 */     g2.drawImage(image, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 106:275 */     g2.dispose();
/* 107:    */     
/* 108:277 */     return temp;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static BufferedImage createThumbnailFast(BufferedImage image, int newWidth, int newHeight)
/* 112:    */   {
/* 113:304 */     if ((newWidth >= image.getWidth()) || (newHeight >= image.getHeight())) {
/* 114:306 */       throw new IllegalArgumentException("newWidth and newHeight cannot be greater than the image dimensions");
/* 115:    */     }
/* 116:309 */     if ((newWidth <= 0) || (newHeight <= 0)) {
/* 117:310 */       throw new IllegalArgumentException("newWidth and newHeight must be greater than 0");
/* 118:    */     }
/* 119:314 */     BufferedImage temp = createCompatibleImage(image, newWidth, newHeight);
/* 120:315 */     Graphics2D g2 = temp.createGraphics();
/* 121:316 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 122:    */     
/* 123:318 */     g2.drawImage(image, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 124:319 */     g2.dispose();
/* 125:    */     
/* 126:321 */     return temp;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static BufferedImage createThumbnail(BufferedImage image, int newSize)
/* 130:    */   {
/* 131:347 */     int width = image.getWidth();
/* 132:348 */     int height = image.getHeight();
/* 133:    */     
/* 134:350 */     boolean isWidthGreater = width > height;
/* 135:352 */     if (isWidthGreater)
/* 136:    */     {
/* 137:353 */       if (newSize >= width) {
/* 138:354 */         throw new IllegalArgumentException("newSize must be lower than the image width");
/* 139:    */       }
/* 140:    */     }
/* 141:357 */     else if (newSize >= height) {
/* 142:358 */       throw new IllegalArgumentException("newSize must be lower than the image height");
/* 143:    */     }
/* 144:362 */     if (newSize <= 0) {
/* 145:363 */       throw new IllegalArgumentException("newSize must be greater than 0");
/* 146:    */     }
/* 147:367 */     float ratioWH = width / height;
/* 148:368 */     float ratioHW = height / width;
/* 149:    */     
/* 150:370 */     BufferedImage thumb = image;
/* 151:    */     do
/* 152:    */     {
/* 153:373 */       if (isWidthGreater)
/* 154:    */       {
/* 155:374 */         width /= 2;
/* 156:375 */         if (width < newSize) {
/* 157:376 */           width = newSize;
/* 158:    */         }
/* 159:378 */         height = (int)(width / ratioWH);
/* 160:    */       }
/* 161:    */       else
/* 162:    */       {
/* 163:380 */         height /= 2;
/* 164:381 */         if (height < newSize) {
/* 165:382 */           height = newSize;
/* 166:    */         }
/* 167:384 */         width = (int)(height / ratioHW);
/* 168:    */       }
/* 169:388 */       BufferedImage temp = createCompatibleImage(image, width, height);
/* 170:389 */       Graphics2D g2 = temp.createGraphics();
/* 171:390 */       g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 172:    */       
/* 173:392 */       g2.drawImage(thumb, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 174:393 */       g2.dispose();
/* 175:    */       
/* 176:395 */       thumb = temp;
/* 177:396 */     } while (newSize != (isWidthGreater ? width : height));
/* 178:398 */     return thumb;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static BufferedImage createThumbnail(BufferedImage image, int newWidth, int newHeight)
/* 182:    */   {
/* 183:423 */     int width = image.getWidth();
/* 184:424 */     int height = image.getHeight();
/* 185:426 */     if ((newWidth >= width) || (newHeight >= height)) {
/* 186:427 */       throw new IllegalArgumentException("newWidth and newHeight cannot be greater than the image dimensions");
/* 187:    */     }
/* 188:430 */     if ((newWidth <= 0) || (newHeight <= 0)) {
/* 189:431 */       throw new IllegalArgumentException("newWidth and newHeight must be greater than 0");
/* 190:    */     }
/* 191:435 */     BufferedImage thumb = image;
/* 192:    */     do
/* 193:    */     {
/* 194:438 */       if (width > newWidth)
/* 195:    */       {
/* 196:439 */         width /= 2;
/* 197:440 */         if (width < newWidth) {
/* 198:441 */           width = newWidth;
/* 199:    */         }
/* 200:    */       }
/* 201:445 */       if (height > newHeight)
/* 202:    */       {
/* 203:446 */         height /= 2;
/* 204:447 */         if (height < newHeight) {
/* 205:448 */           height = newHeight;
/* 206:    */         }
/* 207:    */       }
/* 208:452 */       BufferedImage temp = createCompatibleImage(image, width, height);
/* 209:453 */       Graphics2D g2 = temp.createGraphics();
/* 210:454 */       g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 211:    */       
/* 212:456 */       g2.drawImage(thumb, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 213:457 */       g2.dispose();
/* 214:    */       
/* 215:459 */       thumb = temp;
/* 216:460 */     } while ((width != newWidth) || (height != newHeight));
/* 217:462 */     return thumb;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static int[] getPixels(BufferedImage img, int x, int y, int w, int h, int[] pixels)
/* 221:    */   {
/* 222:485 */     if ((w == 0) || (h == 0)) {
/* 223:486 */       return new int[0];
/* 224:    */     }
/* 225:489 */     if (pixels == null) {
/* 226:490 */       pixels = new int[w * h];
/* 227:491 */     } else if (pixels.length < w * h) {
/* 228:492 */       throw new IllegalArgumentException("pixels array must have a length >= w*h");
/* 229:    */     }
/* 230:496 */     int imageType = img.getType();
/* 231:497 */     if ((imageType == 2) || (imageType == 1))
/* 232:    */     {
/* 233:499 */       Raster raster = img.getRaster();
/* 234:500 */       return (int[])raster.getDataElements(x, y, w, h, pixels);
/* 235:    */     }
/* 236:504 */     return img.getRGB(x, y, w, h, pixels, 0, w);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static void setPixels(BufferedImage img, int x, int y, int w, int h, int[] pixels)
/* 240:    */   {
/* 241:524 */     if ((pixels == null) || (w == 0) || (h == 0)) {
/* 242:525 */       return;
/* 243:    */     }
/* 244:526 */     if (pixels.length < w * h) {
/* 245:527 */       throw new IllegalArgumentException("pixels array must have a length >= w*h");
/* 246:    */     }
/* 247:531 */     int imageType = img.getType();
/* 248:532 */     if ((imageType == 2) || (imageType == 1))
/* 249:    */     {
/* 250:534 */       WritableRaster raster = img.getRaster();
/* 251:535 */       raster.setDataElements(x, y, w, h, pixels);
/* 252:    */     }
/* 253:    */     else
/* 254:    */     {
/* 255:538 */       img.setRGB(x, y, w, h, pixels, 0, w);
/* 256:    */     }
/* 257:    */   }
/* 258:    */ }


/* Location:           C:\Users\Administrator\Desktop\download\free.jar
 * Qualified Name:     free.GraphicsUtilities
 * JD-Core Version:    0.7.0.1
 */
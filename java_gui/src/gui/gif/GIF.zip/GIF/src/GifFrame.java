
import java.awt.image.BufferedImage;

public class GifFrame {

    public BufferedImage image;
    public int x;
    public int y;
    public int width;
    public int height;
    public int disposalMethod;
    public int delayTime;
}
